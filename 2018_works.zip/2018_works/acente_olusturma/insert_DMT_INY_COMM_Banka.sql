INSERT INTO Alz_Dmt_Int_Comm(BATCH_ID,
                                     REFERENCE_CODE,
                                     COMM_DEV_TYPE,
                                     EXPLANATION,
                                     STATUS)
         SELECT a.BATCH_ID, 
              a.Reference_Code, 
              '0060' COMM_DEV_TYPE, 
              b.mobile EXPLANATION,
              a.status
        FROM Alz_Dmt_Int_Partner a,            
             tmp_COMM_TPA b           
       WHERE a.Batch_Id = 23
         AND a.institution_name = b.unvan
         AND b.mobile IS NOT NULL
       UNION
       SELECT a.BATCH_ID, 
              a.Reference_Code, 
              '0070' COMM_DEV_TYPE, 
              b.fax EXPLANATION,
              a.status
        FROM Alz_Dmt_Int_Partner a,            
             tmp_COMM_TPA b           
       WHERE a.Batch_Id = 23
         AND a.institution_name = b.unvan
         AND b.fax IS NOT NULL
       UNION 
         SELECT a.BATCH_ID, 
              a.Reference_Code, 
              '0090' COMM_DEV_TYPE, 
              b.email EXPLANATION,
              a.status
        FROM Alz_Dmt_Int_Partner a,            
             tmp_COMM_TPA b           
       WHERE a.Batch_Id = 23
         AND a.institution_name = b.unvan
         AND b.email IS NOT NULL;
