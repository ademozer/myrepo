INSERT INTO Alz_Dmt_Int_Tech_Emp(
            BATCH_ID, 
            Reference_Code, 
            EMP_ID_NO,
            identity_no,
             EMPLOYEE_NAME,
            EMPLOYEE_SURNAME,
           POSITION,
            VALIDITY_START_DATE,
           COMPANY_TYPE,      
            status
         )
        SELECT a.BATCH_ID, 
               a.Reference_Code, 
               b.TCKN EMP_ID_NO,
               b.TCKN identity_no,
               b.first_name EMPLOYEE_NAME,
               b.last_name EMPLOYEE_SURNAME,
               b.gorev  POSITION,
               SYSDATE VALIDITY_START_DATE,
               18 COMPANY_TYPE,      
               a.status
        FROM  Alz_Dmt_Int_Partner a,  tmp_tech_pers_tpa b      
       WHERE a.Batch_Id = 23 
         AND a.institution_name = b.unvan;
