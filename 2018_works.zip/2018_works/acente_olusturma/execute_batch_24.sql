begin
  customer.alz_dmt_int_pkg.p_execute_create(24);
  commit;
end;
/


