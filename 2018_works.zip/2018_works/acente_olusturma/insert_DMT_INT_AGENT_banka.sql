INSERT INTO Alz_Dmt_Int_Agent(
     BATCH_ID,
     REFERENCE_CODE,
     TITLE,
     RTYP_REF_CODE,
     AGENCY_TYPE,
     ACTUAL_START_DATE,
     ACTUAL_END_DATE,
     REGION_CODE,
     MIS_MAIN_GROUP,
     MIS_SUB_GROUP,
     AGENT_CATEGORY_TYPE,
     RETENTION_AGENT_GRP_TYPE,
     SIGNBOARD_NO,
     AGENCY_TYPE_CODE,
     SALES_AGENCY_TYPE_CODE,
     COMMISSION_GROUP,
     AGENT_SHORT_NAME,
     SAP_DIST_CHANNEL,
     COMPANY_CODE,
     TCKN,
     Mobile,
     email,
     status,
     tpa_agent_code      
    ) 
    SELECT a.BATCH_ID, 
             a.Reference_Code, 
             a.institution_name TITLE,
             'TPAAGENT' RTYP_REF_CODE,
             'ACENTE' AGENCY_TYPE,
             SYSDATE ACTUAL_START_DATE,
             TO_DATE('31/12/4596','DD/MM/YYYY') ACTUAL_END_DATE,
             100 REGION_CODE,
             4 MIS_MAIN_GROUP,
             50 MIS_SUB_GROUP,
             7 AGENT_CATEGORY_TYPE,
             2 RETENTION_AGENT_GRP_TYPE,
             b.Levha_No SIGNBOARD_NO,
             'BANKA' AGENCY_TYPE_CODE,
             'BANKA' SALES_AGENCY_TYPE_CODE,
             'Direkt' COMMISSION_GROUP,
             b.unvan AGENT_SHORT_NAME,
             75 SAP_DIST_CHANNEL,
             100 COMPANY_CODE,
             d.TCKN,
             c.Mobile ,
             c.email,
             a.status,
             '300001' tpa_agent_code             
        FROM Alz_Dmt_Int_Partner a,
             tmp_agent_info_tpa b,
             tmp_COMM_TPA c,
             tmp_tech_pers_tpa d
       WHERE a.Batch_Id =  23
         AND a.institution_name = b.unvan
         AND b.eft_subsidiary_code = c.eft_subsidiary_code
         AND b.eft_subsidiary_code = d.eft_subsidiary_code;
         
       /*  select * from tmp_agent_info_tpa
         select * from  Alz_Dmt_Int_Partner where Batch_Id =  23
         select * from tmp_comm_tpa 
        -- select * from tmp_agent_code_tpa
        
       select * from Alz_Dmt_Int_Agent@opusprep
        
        select * from all_tab_columns where column_name='AGENCY_TYPE'*/
        
      --  select * from all_source where upper(text) like '%AGENCY_TYPE%'
