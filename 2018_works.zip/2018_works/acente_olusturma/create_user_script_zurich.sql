begin
  customer.alz_tpa_definition_utils.vp_Company_Code := '018';
  customer.alz_tpa_definition_utils.vp_Merkez_Reference_Code := '80000';
  customer.alz_tpa_definition_utils.crt_agent_tpa_user;
end;
/
