DECLARE 
   p_new_batch_id NUMBER := 22;
   p_old_batch_id NUMBER := 21;
   p_base_ref_code NUMBER := 72000;
   
   
  CURSOR c2 IS 
          SELECT     
            p_new_batch_id BATCH_ID,          
            TO_CHAR(p_base_ref_code+ROWNUM) REFERENCE_CODE,
            CASE a.FIRM_TYPE1 WHEN '�ZEL' THEN 'G'
                            ELSE 'T' END PARTNER_TYPE,
            NVL(a.FIRM_TYPE2,'�AHIS') COMPANY_TYPE,
            a.UNVAN INSTITUTION_NAME,
            a.TAX_OFFICE,
            a.TAX_NUMBER,
            NVL(a.TCKN,b.Tckn) IDENTITY_NO,
            NVL(a.FIRST_NAME,b.First_Name) FIRST_NAME,            
            NVL(a.LAST_NAME,b.Last_Name) SURNAME,
            LPAD((CASE WHEN INSTR(b.Date_Of_Birth,'/')>0 
              THEN substr(b.Date_Of_Birth,INSTR(b.Date_Of_Birth,'/')+1,INSTR(b.Date_Of_Birth,'/',-1)-INSTR(b.Date_Of_Birth,'/')-1) 
              ELSE substr(b.Date_Of_Birth,INSTR(b.Date_Of_Birth,'.')+1,INSTR(b.Date_Of_Birth,'.',-1)-INSTR(b.Date_Of_Birth,'.')-1)
            END),2,'0')||'/'||
            LPAD((CASE WHEN INSTR(b.Date_Of_Birth,'/')>0 
              THEN SUBSTR(b.DATE_OF_BIRTH,0,INSTR(b.Date_Of_Birth,'/')-1) 
              ELSE SUBSTR(b.DATE_OF_BIRTH,0,INSTR(b.Date_Of_Birth,'.')-1) 
            END),2,'0')||'/'||        
            TO_CHAR(CASE WHEN INSTR(b.Date_Of_Birth,'/')>0 
              THEN substr(b.Date_Of_Birth,INSTR(b.Date_Of_Birth,'/',-1)+1) 
              ELSE substr(b.Date_Of_Birth,INSTR(b.Date_Of_Birth,'.',-1)+1)
            END) DATE_OF_BIRTH,                 
            'RUNNING' STATUS
      FROM TMP_UNSUR_TPA a, TMP_AGENT_PARTNER_TPA b
      WHERE a.Levha_No = b.Levha_No; 
     
 
BEGIN
    --Master Tablosunun Yeni Batch ID ile doldurulmas�
    /*DELETE Alz_Int_Hist_Master WHERE BATCH_ID = p_new_batch_id;
    
    INSERT INTO Alz_Int_Hist_Master(BATCH_ID,
                                      P1_VAL,
                                      P2_VAL,
                                      P3_VAL, 
                                      P4_VAL, 
                                      P5_VAL,
                                      P6_VAL,
                                      P7_VAL) 
       SELECT p_new_batch_id BATCH_ID,
             p1_val,
             p2_val,
             p3_val,
             p4_val,
             p5_val,
             p6_val,
             p7_val             
      FROM Alz_Int_Hist_Master
      WHERE BATCH_ID = p_old_batch_id;  */  

    -- Acente Partner Bilgilerinin olu�turulmas� --- 
    DELETE Alz_Dmt_Int_Partner WHERE BATCH_ID =  p_new_batch_id; 
    FOR r2 IN c2 LOOP
        DBMS_OUTPUT.PUT_LINE(r2.REFERENCE_CODE||'-'||TRIM(r2.DATE_OF_BIRTH)||'-'||r2.FIRST_NAME||'-'||r2.SURNAME);
        INSERT INTO Alz_Dmt_Int_Partner(
                                      BATCH_ID,
                                      REFERENCE_CODE,
                                      PARTNER_TYPE,
                                      COMPANY_TYPE, 
                                      INSTITUTION_NAME, 
                                      TAX_OFFICE,
                                      TAX_NUMBER,
                                      IDENTITY_NO,
                                      FIRST_NAME,
                                      SURNAME,
                                      DATE_OF_BIRTH,
                                      STATUS
                                      ) 
                                VALUES(r2.BATCH_ID,
                                      r2.REFERENCE_CODE,
                                      r2.PARTNER_TYPE,
                                      r2.COMPANY_TYPE, 
                                      r2.INSTITUTION_NAME, 
                                      r2.TAX_OFFICE,
                                      r2.TAX_NUMBER,
                                      r2.IDENTITY_NO,
                                      r2.FIRST_NAME,
                                      r2.SURNAME,
                                      TO_DATE(SUBSTR(TRIM(r2.DATE_OF_BIRTH),1,10),'DD/MM/YYYY'),
                                      r2.STATUS);       
    END LOOP;
    -- Acente Bilgileri -- 
    DELETE Alz_Dmt_Int_Agent WHERE BATCH_ID = p_new_batch_id; 
    INSERT INTO Alz_Dmt_Int_Agent(
     BATCH_ID,
     REFERENCE_CODE,
     TITLE,
     RTYP_REF_CODE,
     AGENCY_TYPE,
     ACTUAL_START_DATE,
     ACTUAL_END_DATE,
     REGION_CODE,
     MIS_MAIN_GROUP,
     MIS_SUB_GROUP,
     AGENT_CATEGORY_TYPE,
     RETENTION_AGENT_GRP_TYPE,
     SIGNBOARD_NO,
     AGENCY_TYPE_CODE,
     SALES_AGENCY_TYPE_CODE,
     COMMISSION_GROUP,
     AGENT_SHORT_NAME,
     SAP_DIST_CHANNEL,
     COMPANY_CODE,
     TCKN,
     Mobile,
     email,
     status,
     tpa_agent_code      
    ) 
    SELECT a.BATCH_ID, 
             a.Reference_Code, 
             a.institution_name TITLE,
             'TPAAGENT' RTYP_REF_CODE,
             'ACENTE' AGENCY_TYPE,
             SYSDATE ACTUAL_START_DATE,
             TO_DATE('31/12/4596','DD/MM/YYYY') ACTUAL_END_DATE,
             100 REGION_CODE,
             4 MIS_MAIN_GROUP,
             50 MIS_SUB_GROUP,
             7 AGENT_CATEGORY_TYPE,
             2 RETENTION_AGENT_GRP_TYPE,
             b.Levha_No SIGNBOARD_NO,
             b.agent_type AGENCY_TYPE_CODE,
             b.agent_type SALES_AGENCY_TYPE_CODE,
             'Direkt' COMMISSION_GROUP,
             b.unvan AGENT_SHORT_NAME,
             75 SAP_DIST_CHANNEL,
             100 COMPANY_CODE,
             a.Identity_No TCKN,
             c.Mobile ,
             c.email,
             a.status,
             d.tpa_agent_code             
        FROM Alz_Dmt_Int_Partner a,
             tmp_agent_info_tpa b,
             tmp_VIP_COMM_TPA c,
             tmp_agent_code_tpa d
       WHERE a.Batch_Id =  p_new_batch_id
         AND a.institution_name = b.unvan
         AND b.Levha_No = c.Levha_No
         AND b.Unvan = d.unvan;
       --Acente Ileti�in Bilgileri --
        DELETE  Alz_Dmt_Int_Comm  WHERE batch_id = p_new_batch_id;
        INSERT INTO Alz_Dmt_Int_Comm(BATCH_ID,
                                     REFERENCE_CODE,
                                     COMM_DEV_TYPE,
                                     EXPLANATION,
                                     STATUS)
         SELECT a.BATCH_ID, 
              a.Reference_Code, 
              '0060' COMM_DEV_TYPE, 
              b.mobile EXPLANATION,
              a.status
        FROM Alz_Dmt_Int_Partner a,            
             tmp_COMM_TPA b           
       WHERE a.Batch_Id = p_new_batch_id
         AND a.institution_name = b.unvan
         AND b.mobile IS NOT NULL
       UNION 
         SELECT a.BATCH_ID, 
              a.Reference_Code, 
              '0090' COMM_DEV_TYPE, 
              b.email EXPLANATION,
              a.status
        FROM Alz_Dmt_Int_Partner a,            
             tmp_COMM_TPA b           
       WHERE a.Batch_Id = p_new_batch_id
         AND a.institution_name = b.unvan
         AND b.email IS NOT NULL;
       -- Acente Adresleri --
       DELETE Alz_Dmt_Int_Address  WHERE BATCH_ID =  p_new_batch_id;
       INSERT INTO Alz_Dmt_Int_Address(Batch_Id,
                                       Reference_Code,
                                       COUNTRY,
                                       CITY,
                                       DISTRICT_CODE,
                                       NEIGHBORHOOD1,
                                       NEIGHBORHOOD2,
                                       STREET,
                                       ROAD_NAME,
                                       gate_name,
                                       gate_no,
                                       apartment_no,
                                       FULL_ADDRESS,                              
                                       status)                                       
         SELECT a.BATCH_ID, 
              a.Reference_Code, 
              NVL(b.Country,'TR') COUNTRY,
              b.city,
              b.district DISTRICT_CODE,
              b.neigborhood_1 NEIGHBORHOOD1,
              b.neigborhood_2 NEIGHBORHOOD2,
              TRIM(b.Street_1||' '||b.street_2) STREET,
              b.road ROAD_NAME,
              b.gate_name,
              b.gate_no,
              b.apartment_no,
              TRIM(b.NEIGBORHOOD_1||
              (CASE WHEN b.NEIGBORHOOD_1 IS NOT NULL THEN ' MH.' END) ||' '||
              b.NEIGBORHOOD_2||
              (CASE WHEN b.NEIGBORHOOD_2 IS NOT NULL THEN ' MH.' END) ||' '||
              b.STREET_1||
              (CASE WHEN b.STREET_1 IS NOT NULL THEN ' CD.' END) ||' '||
              b.STREET_2||
              (CASE WHEN b.STREET_2 IS NOT NULL THEN ' SK.' END) ||' '||
              b.road||
              (CASE WHEN b.road IS NOT NULL THEN ' ' END) ||
              b.gate_name||' No: '||
              b.gate_no||'/'||
              b.apartment_no||' '||
              b.district ||' '||
              b.city) FULL_ADDRESS,                              
              a.status
        FROM Alz_Dmt_Int_Partner a,            
             tmp_ADRES_TPA b         
       WHERE a.Batch_Id = p_new_batch_id
         AND a.institution_name = b.unvan;
      -- Acente Personelleri -- 
      DELETE   Alz_Dmt_Int_Agency_Persons WHERE BATCH_ID = p_new_batch_id;
       INSERT INTO Alz_Dmt_Int_Agency_Persons(
       BATCH_ID,
       Reference_Code,
       PARTNER_TYPE,
       NAME,
       surname,
       date_of_birth,
       mobile,
       TCKN,
       SH_TITLE,
       status
       ) 
             SELECT a.BATCH_ID, 
               a.Reference_Code, 
               CASE a.PARTNER_TYPE WHEN 'G' THEN '�ZEL' ELSE 'T�ZEL' END PARTNER_TYPE,
               a.first_name NAME, 
               a.surname,   
               a.date_of_birth,
               b.mobile,
               a.identity_no TCKN,
               c.TITLE SH_TITLE,                   
               a.status
        FROM Alz_Dmt_Int_Partner a, tmp_comm_tpa b, tmp_agent_partner_tpa c         
       WHERE a.Batch_Id = p_new_batch_id
         AND a.institution_name = b.unvan
         AND b.levha_no = c.levha_no;
       -- Acente Ip Adresleri ---
        DELETE ALZ_DMT_INT_AGENCY_IP WHERE BATCH_ID = p_new_batch_id;
         INSERT INTO ALZ_DMT_INT_AGENCY_IP(BATCH_ID,
               Reference_Code, 
               SUB_AGENT_INT_ID,
               IP,
               ADDRESS_TYPE,
               VALIDITY_START_DATE,
               ADDRESS,
               IS_MANUAL,
               IP_WILL_BE_CONTROLLED,            
               status
         )
        SELECT a.BATCH_ID, 
               a.Reference_Code, 
               0 SUB_AGENT_INT_ID,
               b.ip_address IP,
               'Merkez' ADDRESS_TYPE,
               SYSDATE VALIDITY_START_DATE,
               a.full_address ADDRESS,
               0 IS_MANUAL,
               0 IP_WILL_BE_CONTROLLED,            
               a.status
        FROM Alz_Dmt_Int_Address a, tmp_agent_ip_tpa b, Alz_Dmt_Int_Partner c        
       WHERE c.Batch_Id = p_new_batch_id
         AND a.Batch_Id = c.batch_id
         AND a.reference_code = c.Reference_Code
         AND c.institution_name = b.unvan;
        -- Teknik Personel Olu�tur 
         DELETE Alz_Dmt_Int_Tech_Emp WHERE BATCH_ID =  p_new_batch_id;
         INSERT INTO Alz_Dmt_Int_Tech_Emp(
            BATCH_ID, 
            Reference_Code, 
            EMP_ID_NO,
            identity_no,
             EMPLOYEE_NAME,
            EMPLOYEE_SURNAME,
           POSITION,
            VALIDITY_START_DATE,
           COMPANY_TYPE,      
            status
         )
            SELECT a.BATCH_ID, 
               a.Reference_Code, 
               a.Identity_No EMP_ID_NO,
               a.identity_no,
               a.first_name EMPLOYEE_NAME,
               a.surname EMPLOYEE_SURNAME,
               b.Title  POSITION,
               SYSDATE VALIDITY_START_DATE,
               18 COMPANY_TYPE,      
               a.status
        FROM  Alz_Dmt_Int_Partner a,  tmp_agent_partner_tpa b      
       WHERE a.Batch_Id = p_new_batch_id  
         AND a.institution_name = b.unvan;
               
END;
              
       
