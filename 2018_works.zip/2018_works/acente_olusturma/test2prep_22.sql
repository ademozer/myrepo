INSERT INTO Alz_Dmt_Int_Agency_Persons     
SELECT * from Alz_Dmt_Int_Agency_Persons@opustest where reference_code='60000' and batch_id=22
/
INSERT INTO Alz_Dmt_Int_Tech_Emp 
SELECT * from Alz_Dmt_Int_Tech_Emp@opustest where reference_code='60000' and batch_id=22
/
INSERT INTO Alz_Dmt_Int_Partner 
SELECT * from Alz_Dmt_Int_Partner@opustest where reference_code='60000' and batch_id=22
/
INSERT INTO Alz_Dmt_Int_Agent
SELECT * from Alz_Dmt_Int_Agent@opustest where batch_id=22 and tpa_agent_code='300001'
/  
INSERT INTO Alz_Int_Hist_Master
select * from Alz_Int_Hist_Master@opustest where batch_id=22
/
