begin
  customer.alz_tpa_definition_utils.crt_agent_tpa_user;
end;
/
