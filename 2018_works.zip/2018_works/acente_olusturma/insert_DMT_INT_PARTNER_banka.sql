INSERT INTO Alz_Dmt_Int_Partner(
                                      BATCH_ID,
                                      REFERENCE_CODE,
                                      PARTNER_TYPE,
                                      COMPANY_TYPE, 
                                      INSTITUTION_NAME, 
                                      TAX_OFFICE,
                                      TAX_NUMBER,                                                                       
                                      STATUS
                                      ) 
     SELECT     
            23 BATCH_ID,          
            '61000-00'||b.eft_subsidiary_code REFERENCE_CODE,
            CASE a.FIRM_TYPE1 WHEN '�ZEL' THEN 'G'
                            ELSE 'T' END PARTNER_TYPE,
            NVL(a.FIRM_TYPE2,a.firm_type1) COMPANY_TYPE,
            a.UNVAN INSTITUTION_NAME,
            a.TAX_OFFICE,
            a.TAX_NUMBER,                       
            'RUNNING' STATUS
      FROM ademo.TMP_UNSUR_TPA a, TMP_TECH_PERS_TPA b
      WHERE a.unvan = b.unvan
      
     
    --  WHERE a.Levha_No = b.Levha_No; 
    
   --select * from TMP_UNSUR_TPA
    --select * from TMP_TECH_PERS_TPA
    
--select * from  Alz_Dmt_Int_Partner where batch_id=23
