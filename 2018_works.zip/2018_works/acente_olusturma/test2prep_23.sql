insert into Alz_Int_Hist_Master
select * from Alz_Int_Hist_Master@opustest where batch_id=23
/
insert into Alz_Dmt_Int_Partner
SELECT * from Alz_Dmt_Int_Partner@opustest where batch_id=23
/ 
insert into Alz_Dmt_Int_Agent
SELECT * from Alz_Dmt_Int_Agent@opustest where batch_id=23 and int_id IS NULL
/ 
insert into Alz_Dmt_Int_Comm
SELECT * from Alz_Dmt_Int_Comm@opustest where batch_id=23
/ 
insert into Alz_Dmt_Int_Address
SELECT * from Alz_Dmt_Int_Address@opustest where batch_id=23
/ 
insert into Alz_Dmt_Int_Agency_Persons
SELECT * from Alz_Dmt_Int_Agency_Persons@opustest where batch_id=23 and int_id IS NULL
/ 
insert into Alz_Dmt_Int_Tech_Emp
SELECT * from Alz_Dmt_Int_Tech_Emp@opustest where batch_id=23 and int_id IS NULL
/ 
insert into Alz_Dmt_Int_AGENCY_IP
SELECT * From ALZ_DMT_INT_AGENCY_IP@opustest where batch_id=23
/
