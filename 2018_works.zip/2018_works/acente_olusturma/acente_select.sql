select * from Alz_Int_Hist_Master where batch_id=25;
SELECT * from Alz_Int_Hist_Det where batch_id=25; 
SELECT * from Alz_Dmt_Int_Partner where reference_code='60000';--batch_id=22 order by reference_code
SELECT * from Alz_Dmt_Int_Agent where  reference_code='60000'; --int_id=71671--batch_id=22;
SELECT * from Alz_Dmt_Int_Comm where reference_code='60000';
SELECT * from Alz_Dmt_Int_Address where reference_code='60000' for update;---batch_id=24;
SELECT * from Alz_Dmt_Int_Agency_Persons where reference_code='60000' and batch_id=24;
SELECT * from Alz_Dmt_Int_Tech_Emp where reference_code='60000';--int_id=71671--batch_id=22;
SELECT * From ALZ_DMT_INT_AGENCY_IP where reference_code='60000'; 

create table tmp_agent_partner_tpa_22
as select * from tmp_agent_partner_tpa

create table tmp_adres_22
as select * from tmp_adres_tpa

create table tmp_agent_code_tpa_22
as select * from tmp_agent_code_tpa

create table tmp_agent_info_tpa_22
as select * from tmp_agent_info_tpa

create table tmp_comm_tpa_22
as select * from tmp_comm_tpa

create table tmp_tech_pers_tpa_22
as select * from tmp_tech_pers_tpa

create table tmp_unsur_tpa_22
as select * from tmp_unsur_tpa

create table tmp_vip_comm_tpa_22
as select * from tmp_vip_comm_tpa


truncate table tmp_vip_comm_tpa
