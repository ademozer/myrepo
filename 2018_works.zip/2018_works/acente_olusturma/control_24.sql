select * from Alz_Int_Hist_Master where batch_id=24;
select * from Alz_Int_Hist_Det where batch_id=24;
SELECT * from Alz_Dmt_Int_Partner where batch_id=24; 
SELECT * from Alz_Dmt_Int_Agent where batch_id=24;
SELECT * from Alz_Dmt_Int_Comm where batch_id=24;
SELECT * from Alz_Dmt_Int_Address where batch_id=24;
SELECT * from Alz_Dmt_Int_Agency_Persons where batch_id=24;
SELECT * from Alz_Dmt_Int_Tech_Emp where batch_id=24;

