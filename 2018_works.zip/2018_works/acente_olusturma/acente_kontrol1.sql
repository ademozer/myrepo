      SELECT a.yks_agent_code
           , a.yks_hlth_agent_code
           , a.reference_code
           , a.title
           , a.region_code
           , a.retention_agent_grp_type
           , a.agent_category_type --kategori_tipi
           , DECODE (agency_type
                   , 'B�LGE M�D�RL���', 2
                   , 'TEMS�LC�L�K', 2
                   , DECODE (INSTR (a.reference_code, '-', 1
                                  , 1)
                           , 0, 1
                           , 3))
               agency_type -- Tmm
           , a.mis_main_group
           , a.mis_sub_group
           , DECODE (p.partner_type,  'T', 'I',  'G', 'P',  NULL) agent_type --Tmm
           , DECODE (rtyp_ref_code
                   , 'A', 'A'
                   , 'B', 'BTRFA'
                   , 'Direkt', 'SCAPGEN'
                   , 'YKB', 'YKB'
                   , 'YKL', 'YKL'
                   , 'SA�LIK', 'SAGLIK'
                   , 'ARACIABROAD', 'ARACIABROAD'
                   , 'TPAAGENT', 'TPAAGENT',rtyp_ref_code)
               rtyp_ref_code -- Tmm ROL her seferinde yeni yarat�l�yor...
           , 'KA' chn_ref_code
           , TRUNC (SYSDATE) start_date
           , NULL end_date
           , (SELECT pol_rec_acc_grp
                FROM koc_dmt_agent_cat_ref c
               WHERE a.agent_category_type = c.agent_category_type)
               pol_rec_acc_grp
           , DECODE (NVL (retention_agent_grp_type, 0), 0, 1, retention_agent_grp_type) kod --Tmm
           , DECODE (collection_authority,  'KK1', 'SADECE KK',  'KK2', 'SADECE KK2',  collection_authority) collection_authority -- Tmm
           , DECODE (NVL (agency_type_code, 'X'), '�OKLU', 2, 1) agency_type_code --Tmm temsil_tipi
           , DECODE (NVL (sales_agency_type_code, 'X'), '�OKLU', 2, 1) sales_agency_type_code -- Tmm satis_temsil_tipi
           , DECODE (SUBSTR (NVL (a.activity_type, 'Pro'), 1, 3),  'Pro', 1,  'Kur', 2) activity_type -- Tmm faaliyet_ozelligi
           , DECODE (SUBSTR (NVL (a.is_dask_authority, 'H'), 1, 1),  'E', 1,  'H', 0) is_dask_authority -- Tmm
           , a.association_no -- birlik_sicil_no
           , a.signboard_no -- levha_no
           , a.sap_dist_channel
           , DECODE (a.commission_group,  'A', '001',  'B', '002',  'C', '003',  'YKB', '004',  '001') commission_group -- Tmm
           , cust_rep_name
           , (SELECT cust_rep_no
                FROM koc_cp_cust_rep_ref rr
               WHERE explanation = a.cust_rep_name AND SYSDATE BETWEEN TRUNC (rr.validity_start_date) AND NVL (rr.validity_end_date, SYSDATE + 1))
               cust_rep_no
           , substr(agent_short_name, 1,50) agent_short_name
           , actual_start_date
           , actual_end_date
           , partner_type
           , institution_name
           , SUBSTR (tax_office, 1, 30) tax_office
           , tax_number
           , identity_no
           , first_name
           , surname
           , date_of_birth
           , nationality
           , CASE SUBSTR (UPPER (company_type), 1, 3)
               WHEN 'KOO' THEN 'KOP'
               WHEN 'ANO' THEN 'A.�.'
               WHEN 'KOL' THEN 'KOLL'
               WHEN 'L�M' THEN 'LTD'
               WHEN 'VAK' THEN 'VKF'
             END
               company_type
           , p.part_id
           , p.partner_ref
           , a.company_code
           , a.proxy_notary_name
           , a.agreement_date
           , a.trade_office_city_code
           , a.notary_date
           , a.journal_entry_no
           , a.trade_reg_date
           , a.trade_reg_no
           , a.accept_date
           , a.apply_date
           , a.tckn
           , a.mobile
           , a.email
           , a.int_id
           , a.tpa_agent_code
        FROM alz_dmt_int_partner p
           , alz_dmt_int_agent a
       WHERE a.batch_id = 20
         AND p.batch_id = 20
        -- AND p.reference_code = a.reference_code(+)
        --- AND (p.status = gcc_run_status OR a.status = gcc_run_status)
    ORDER BY LENGTH (p.reference_code), p.reference_code;
