Select a.User_Name,
                     Alz_Web_User_Security.Aesdecrypt(a.User_Password_Aes) Pass,
                     Password_Expired,
                     e.Email,e.Mobile,
                     --'Altan.Firidin@allianz.com.tr' Email,'905337642044' Mobile,
                     --'extern.serdal-turgut@allianz.com.tr' Email,'905322235290' Mobile,
                     b.Name,
                     b.Surname,
                     d.Int_Id,
                     d.Reference_Code,
                     e.Title,
                     e.Company_Code
                From Koc_Dmt_Agents_Ext   e,
                     Web_Sec_System_Users a,
                     Cp_Partners          b,
                     Koc_Cp_Partners_Ext  c,
                     Dmt_Agents           d
               Where a.Customer_Partner_Id = b.Part_Id
                     And b.Part_Id = c.Part_Id
                     And c.Agen_Int_Id = d.Int_Id
                     And d.Int_Id = e.Int_Id
                     And e.Company_Code = 777     
                     And d.Reference_Code LIKE  '61000%'   
                     And a.user_name like '%FIBA%'           
                   --  And a.User_Name = nvl(p_User_Name,a.User_Name)
               Order By d.Reference_Code
