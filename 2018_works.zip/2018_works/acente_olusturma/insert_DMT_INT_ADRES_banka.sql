INSERT INTO Alz_Dmt_Int_Address(Batch_Id,
                                       Reference_Code,
                                       COUNTRY,
                                       CITY,
                                       DISTRICT_CODE,
                                       NEIGHBORHOOD1,
                                       NEIGHBORHOOD2,
                                       STREET,
                                       ROAD_NAME,
                                       gate_name,
                                       gate_no,
                                       apartment_no,
                                       FULL_ADDRESS,                              
                                       status)                                       
         SELECT a.BATCH_ID, 
              a.Reference_Code, 
              NVL(b.Country,'TR') COUNTRY,
              b.city,
              b.district DISTRICT_CODE,
              b.neigborhood_1 NEIGHBORHOOD1,
              b.neigborhood_2 NEIGHBORHOOD2,
              TRIM(b.Street_1||' '||b.street_2) STREET,
              b.road ROAD_NAME,
              b.gate_name,
              b.gate_no,
              b.apartment_no,
              TRIM(b.NEIGBORHOOD_1||
              (CASE WHEN b.NEIGBORHOOD_1 IS NOT NULL THEN ' MH.' END) ||' '||
              b.NEIGBORHOOD_2||
              (CASE WHEN b.NEIGBORHOOD_2 IS NOT NULL THEN ' MH.' END) ||' '||
              b.STREET_1||
              (CASE WHEN b.STREET_1 IS NOT NULL THEN ' CD.' END) ||' '||
              b.STREET_2||
              (CASE WHEN b.STREET_2 IS NOT NULL THEN ' SK.' END) ||' '||
              b.road||
              (CASE WHEN b.road IS NOT NULL THEN ' ' END) ||
              b.gate_name||' No: '||
              b.gate_no||'/'||
              b.apartment_no||' '||
              b.district ||' '||
              b.city) FULL_ADDRESS,                              
              a.status
        FROM Alz_Dmt_Int_Partner a,            
             tmp_ADRES_TPA b         
       WHERE a.Batch_Id = 23
         AND a.institution_name = b.unvan;
         
         
        -- select * from alz_tpa_companies
