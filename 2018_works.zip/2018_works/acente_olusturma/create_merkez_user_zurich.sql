DECLARE 
Procedure Crt_Agent_TPA_Merkez_User Is
    P_OPUS_USER_NAME VARCHAR2(32767);
    P_USER_NAME VARCHAR2(32767);
    P_EMAIL VARCHAR2(32767);
    P_PARTNER_ID NUMBER;
    P_NAME VARCHAR2(32767);
    P_SURNAME VARCHAR2(32767);
    P_TAX_NUMBER VARCHAR2(32767);
    P_USER_TYPE NUMBER;
    P_REFERENCE_CODE VARCHAR2(32767);
    P_INSERT_USER_NAME VARCHAR2(32767);
    P_ROLE_TABLE customer.char_array;
    P_HSBC_REGISTRY_NO VARCHAR2(32767);
    P_TCK_NO VARCHAR2(32767);
    P_RESULT_CUR SYS_REFCURSOR;
    P_PROCESS_RESULTS customer.process_result_table;
    P_TECH_STAFF VARCHAR2(32767);
    P_BGD_USER VARCHAR2(32767);
    P_CALL_CENTER VARCHAR2(32767);
    P_FATHER_NAME VARCHAR2(32767);
    P_MOTHER_NAME VARCHAR2(32767);
    P_ADDRESSE VARCHAR2(32767);
    P_BIRTH_PLACE VARCHAR2(32767);
    P_MARITAL_STATUS VARCHAR2(32767);
    P_PASSPORT_NUMBER VARCHAR2(32767);
    P_EMPLOYEE_ID VARCHAR2(32767);
    P_MOBILE_PHONE VARCHAR2(32767);
    P_DOMAIN_USER_NAME VARCHAR2(32767);
    P_COMPANY_CODE VARCHAR2(32767);
    Pragma Autonomous_Transaction;
    v_Log Clob;
  BEGIN
    P_OPUS_USER_NAME := NULL ;
    P_USER_NAME := 'WZRCH_AOZER';
    P_EMAIL := 'adem.ozer@zurichsigorta.com.tr';
    P_PARTNER_ID := 0;
    P_NAME := 'ADEM';
    P_SURNAME := '�ZER';
    P_TAX_NUMBER := NULL;
    P_USER_TYPE := 0;
    P_REFERENCE_CODE := '80000';
    P_INSERT_USER_NAME := 'WADEMOZER';
    P_ROLE_TABLE := NULL;
    P_HSBC_REGISTRY_NO := NULL;
    P_TCK_NO := 22222222222;
    P_TECH_STAFF := 0;
    P_BGD_USER := 0;
    P_CALL_CENTER := 0;
    P_FATHER_NAME := NULL;
    P_MOTHER_NAME := NULL;
    P_ADDRESSE := NULL;
    P_BIRTH_PLACE := NULL;
    P_MARITAL_STATUS := NULL;
    P_PASSPORT_NUMBER := NULL;
    P_EMPLOYEE_ID := 22222222222;
    P_MOBILE_PHONE := NULL;
    P_DOMAIN_USER_NAME := NULL;
    P_COMPANY_CODE := '018';

    CUSTOMER.ALZ_WEB_USER_UTILS.CREATENEWWEBUSER2 ( P_OPUS_USER_NAME, P_USER_NAME, P_EMAIL, P_PARTNER_ID, P_NAME, P_SURNAME, P_TAX_NUMBER, P_USER_TYPE, P_REFERENCE_CODE, P_INSERT_USER_NAME, P_ROLE_TABLE, P_HSBC_REGISTRY_NO, P_TCK_NO, P_RESULT_CUR, P_PROCESS_RESULTS, P_TECH_STAFF, P_BGD_USER, P_CALL_CENTER, P_FATHER_NAME, P_MOTHER_NAME, P_ADDRESSE, P_BIRTH_PLACE, P_MARITAL_STATUS, P_PASSPORT_NUMBER, P_EMPLOYEE_ID, P_MOBILE_PHONE, P_DOMAIN_USER_NAME, P_COMPANY_CODE );

    update web_sec_system_users t set user_password_aes = ALZ_WEB_USER_SECURITY.AESENCRYPT('Aa123456'),t.password_expired=0
    where user_name = P_USER_NAME;

    insert into koc_auth_user_role_rel (USERNAME, ROLE_CODE, VALIDITY_START_DATE, VALIDITY_END_DATE, IS_AUTHORIZED_AGENCY_USER, REGION_CODE)
    values (P_USER_NAME, 'SAGENT', sysdate, null, null, null);

    insert into koc_auth_user_role_rel (USERNAME, ROLE_CODE, VALIDITY_START_DATE, VALIDITY_END_DATE, IS_AUTHORIZED_AGENCY_USER, REGION_CODE)
    values (P_USER_NAME, 'WTPACNOPER', sysdate, null, null, null);

/*    insert into koc_auth_user_role_rel (USERNAME, ROLE_CODE, VALIDITY_START_DATE, VALIDITY_END_DATE, IS_AUTHORIZED_AGENCY_USER, REGION_CODE)
    values (P_USER_NAME, 'WTPALOGIN', sysdate, null, null, null);
*/
    insert into koc_auth_user_role_rel (USERNAME, ROLE_CODE, VALIDITY_START_DATE, VALIDITY_END_DATE, IS_AUTHORIZED_AGENCY_USER, REGION_CODE)
    values (P_USER_NAME, 'WLOGIN', sysdate, null, null, null);


    --Dbms_Lob_Append(v_Log,'Crt_Agent_TPA_Merkez_User Bitti');
    --Def_ErrLog('Crt_Agent_TPA_Merkez_User',Null,v_Log,'Success');
    Commit;
  Exception
    When Others Then
     -- Def_ErrLog('Crt_Agent_TPA_Merkez_User',substr(sqlerrm || '--' || dbms_utility.format_error_backtrace, 1, 1000),v_Log,'Error');
      Rollback;
  End;
  
  BEGIN
    Crt_Agent_TPA_Merkez_User;
  END;
