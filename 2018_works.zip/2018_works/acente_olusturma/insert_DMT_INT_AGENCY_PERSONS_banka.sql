INSERT INTO Alz_Dmt_Int_Agency_Persons(
       BATCH_ID,
       Reference_Code,
       PARTNER_TYPE,
       NAME,
       surname,
      -- date_of_birth,
       mobile,
       TCKN,
       SH_TITLE,
       status
       ) 
             SELECT a.BATCH_ID, 
               a.Reference_Code, 
               CASE a.PARTNER_TYPE WHEN 'G' THEN '�ZEL' ELSE 'T�ZEL' END PARTNER_TYPE,
               c.first_name NAME, 
               c.last_name  surname,   
               --a.date_of_birth,
               b.mobile,
               c.TCKN,
               c.gorev TITLE,                   
               a.status
        FROM Alz_Dmt_Int_Partner a, tmp_comm_tpa b, tmp_tech_pers_tpa c         
       WHERE a.Batch_Id = 23
         AND a.institution_name = b.unvan
         AND a.institution_name = c.unvan
       --  AND b.levha_no = c.levha_no;
         
       
      -- select * from tmp_tech_pers_tpa
         
