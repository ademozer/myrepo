     INSERT INTO Alz_Dmt_Int_Agency_Persons(
       BATCH_ID,
       Reference_Code,
       PARTNER_TYPE,
       NAME,
       surname,
       date_of_birth,
       mobile,
       TCKN,
       SH_TITLE,
       status
       ) 
     select 22 BATCH_ID,
            60000 REFERENCE_CODE,
            'T�ZEL' PARTNER_TYPE,
            b.FIRST_NAME NAME,
            b.LAST_NAME SURNAME,
             LPAD((CASE WHEN INSTR(b.Date_Of_Birth,'/')>0 
              THEN substr(b.Date_Of_Birth,INSTR(b.Date_Of_Birth,'/')+1,INSTR(b.Date_Of_Birth,'/',-1)-INSTR(b.Date_Of_Birth,'/')-1) 
              ELSE substr(b.Date_Of_Birth,INSTR(b.Date_Of_Birth,'.')+1,INSTR(b.Date_Of_Birth,'.',-1)-INSTR(b.Date_Of_Birth,'.')-1)
            END),2,'0')||'/'||
            LPAD((CASE WHEN INSTR(b.Date_Of_Birth,'/')>0 
              THEN SUBSTR(b.DATE_OF_BIRTH,0,INSTR(b.Date_Of_Birth,'/')-1) 
              ELSE SUBSTR(b.DATE_OF_BIRTH,0,INSTR(b.Date_Of_Birth,'.')-1) 
            END),2,'0')||'/'||        
            TO_CHAR(CASE WHEN INSTR(b.Date_Of_Birth,'/')>0 
              THEN substr(b.Date_Of_Birth,INSTR(b.Date_Of_Birth,'/',-1)+1) 
              ELSE substr(b.Date_Of_Birth,INSTR(b.Date_Of_Birth,'.',-1)+1)
            END) DATE_OF_BIRTH,  
            b.MOBILE,
            b.Tckn,
            b.title,
            'RUNNING' STATUS             
       from tmp_agent_partner_tpa b
