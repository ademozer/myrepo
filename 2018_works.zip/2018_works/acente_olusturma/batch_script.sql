begin
  -- Call the procedure
  customer.alz_dmt_int_pkg.p_execute_create(pn_batch_id => 22);
end;


