select * from tmp_vip_comm_tpa;
select * from tmp_comm_tpa;
select * from tmp_unsur_tpa;
select * from tmp_tech_pers_tpa;
select * from tmp_adres_tpa;
select * from tmp_agent_code_tpa;
select * from tmp_agent_info_tpa;
select * from tmp_agent_ip_tpa;
select * from tmp_agent_partner_tpa;
--select * from alz_error_log_table order by process_date desc
