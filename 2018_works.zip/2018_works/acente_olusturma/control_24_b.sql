select * from Alz_Int_Hist_Master where batch_id=24;
select * from Alz_Int_Hist_Det where batch_id=24;
SELECT * from Alz_Dmt_Int_Partner where  batch_id=24;
SELECT * from Alz_Dmt_Int_Agent where batch_id=24;
SELECT * from Alz_Dmt_Int_Comm where batch_id=24;--and reference_code='60000'
SELECT * from Alz_Dmt_Int_Address where batch_id=24;
SELECT * from Alz_Dmt_Int_Agency_Persons where batch_id=24;
SELECT * from Alz_Dmt_Int_Tech_Emp where batch_id=24;

Insert Into Alz_Dmt_Int_Tech_Emp
SELECT BATCH_ID,INT_ID,REFERENCE_CODE,TCKN EMP_ID_NO, TCKN IDENTITY_NO,NAME EMPLOYEE_NAME,SURNAME EMPLOYEE_SURNAME,SH_TITLE POSITION,(SYSDATE-3) VALIDITY_START_DATE,NULL VALIDITY_END_DATE,'18' COMPANY_TYPE,'RUNNING' STATUS, NULL ERROR_CODE
FROM Alz_Dmt_Int_Agency_Persons where batch_id=24;

13712420066 G�N�L BABACAN 5325248432  gonul.babacan@fibaemeklilik.com.tr

24809582390 AL�   KAYA  5365745764  ali.kaya@fibaemeklilik.com.tr

29308666268 DEMET   �NCE  5376777985  demet.ince@fibaemeklilik.com.tr

29998217344 ALEV  KODA�   5392930281  alev.kodas@fibaemeklilik.com.tr

22241381632 NURAN   BARAN 5375013486  nuran.baran@fibaemeklilik.com.tr

37652102196 CANAN   DEL�BA� 5368926439  canan.delibas@fibaemeklilik.com.tr


G�N�L BABACAN 12.12.1979
AL�   KAYA  10.06.1977
DEMET   �NCE  4.08.1996
ALEV  KODA�   16.04.1980
NURAN   BARAN 27.03.1991
CANAN   DEL�BA� 13.07.1983

