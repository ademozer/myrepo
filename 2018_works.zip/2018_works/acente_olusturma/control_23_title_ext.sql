select * 
  from koc_dmt_agents_title_ext 
 where int_id in(
select e.int_id 
  from alz_dmt_int_partner p,koc_dmt_agents_ext e, dmt_agents d 
 where p.batch_id=23 
   and p.reference_code = d.reference_code
   and d.int_id=e.int_id 
   and e.company_code='100'
)


