    INSERT INTO Alz_Dmt_Int_Tech_Emp(
            BATCH_ID, 
            Reference_Code, 
            EMP_ID_NO,
            identity_no,
            EMPLOYEE_NAME,
            EMPLOYEE_SURNAME,
            POSITION,
            VALIDITY_START_DATE,
            COMPANY_TYPE,      
            status
         )
            SELECT 22 BATCH_ID, 
                60000 Reference_Code, 
               b.TCKN EMP_ID_NO,
               b.TCKN identity_no,
               b.first_name EMPLOYEE_NAME,
               b.last_name EMPLOYEE_SURNAME,
               b.Title  POSITION,
               SYSDATE VALIDITY_START_DATE,
               18 COMPANY_TYPE,      
               'RUNNING' status
        FROM  tmp_agent_partner_tpa b      
      
    
   
    
         
