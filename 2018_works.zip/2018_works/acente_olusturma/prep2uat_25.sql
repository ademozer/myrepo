insert into Alz_Int_Hist_Master
select * from Alz_Int_Hist_Master@opusprep where batch_id=25; 
/
insert into Alz_Dmt_Int_Partner
SELECT * from Alz_Dmt_Int_Partner@opusprep where  batch_id=25;
/
insert into Alz_Dmt_Int_Agent
SELECT * from Alz_Dmt_Int_Agent@opusprep where batch_id=25
/
insert into Alz_Dmt_Int_Comm
SELECT * from Alz_Dmt_Int_Comm@opusprep where batch_id=25
/
insert into Alz_Dmt_Int_Address
SELECT * from Alz_Dmt_Int_Address@opusprep where batch_id=25
/
insert into Alz_Dmt_Int_Agency_Persons
SELECT * from Alz_Dmt_Int_Agency_Persons@opusprep where batch_id=25
/
insert into Alz_Dmt_Int_Tech_Emp
SELECT * from Alz_Dmt_Int_Tech_Emp@opusprep where batch_id=25
/
