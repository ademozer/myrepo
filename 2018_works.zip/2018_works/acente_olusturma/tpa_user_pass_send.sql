begin
  customer.alz_tpa_definition_utils.crt_agent_tpa_userpasssend(p_company_code => '100',
                                                               p_user_name => null);
  commit;														   
end;
/
