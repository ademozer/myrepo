SELECT * from Alz_Dmt_Int_Agency_Persons where reference_code='60000' and batch_id=22
/
SELECT * from Alz_Dmt_Int_Tech_Emp where reference_code='60000' and batch_id=22
/
SELECT * from Alz_Dmt_Int_Partner where reference_code='60000' and batch_id=22
/
SELECT * from Alz_Dmt_Int_Agent where batch_id=22 and tpa_agent_code='300001'
/  
select * from Alz_Int_Hist_Master where batch_id=22
/
