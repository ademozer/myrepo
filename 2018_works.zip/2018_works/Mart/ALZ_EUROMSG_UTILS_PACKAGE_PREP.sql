
  CREATE OR REPLACE PACKAGE "CUSTOMER"."ALZ_EUROMSG_UTILS" Is


    g_mail_to constant varchar2(250) := '<br/>'||
                                        '<br/>'||
                                        'to:@mail_to_inf@ / cc:@mail_cc_inf@ / bcc:@mail_bcc_inf@';

    g_gsm_to constant varchar2(250) :=  'cep_tel:@gsm_no@';

    PROCEDURE getcontenterr(p_value  in varchar2,
                            p_hata   in varchar2,
                            p_Response_Rec in out Customer.EuroMsg_Mail_Response_Table);

    PROCEDURE before_send_mailsms (p_Mail_Input  In Out Customer.EuroMsg_Mail_Input_Rec,
                                   p_Body        In Out varchar2,
                                   p_Gsm_No      In Out Varchar2,
                                   pmessage_type In varchar2);

    Function Convert_Mail_Input_To_Payload(p_Mail_Input        In          Customer.EuroMsg_Mail_Input_Rec)
    Return Clob;

    Function Convert_Sms_Input_To_Payload(p_Sms_Input         In          Customer.EuroMsg_Sms_Input_Rec)
    Return Clob;

    Procedure Call_TPA_Service(p_Method            In          Varchar2,
                               p_Payload           In          Clob,
                               p_User              In          Varchar2,
                               p_Response_Rec      In Out      Customer.EuroMsg_Mail_Response_Table,
                               p_Process_Results   In Out      Customer.Process_Result_Table);

    Procedure Send_Mail(p_Mail_Input        In          Customer.EuroMsg_Mail_Input_Rec,
                        p_User              In          Varchar2,
                        p_Response_Rec      In Out      Customer.EuroMsg_Mail_Response_Table,
                        p_Process_Results   In Out      Customer.Process_Result_Table );

    Procedure Send_Mail_With_Template(p_Mail_Input        In          Customer.EuroMsg_Mail_Input_Rec,
                                      p_User              In          Varchar2,
                                      p_Response_Rec      In Out      Customer.EuroMsg_Mail_Response_Table,
                                      p_Process_Results   In Out      Customer.Process_Result_Table);

    Procedure Send_Sms(p_Gsm_No            In          Varchar2,
                       p_Sms_Content       In          Varchar2,
                       p_Company_code      In          Varchar2,
                       p_Message_Type      In          Number,
                       p_User              In          Varchar2,
                       p_Response_Rec      In Out      Customer.EuroMsg_Mail_Response_Table,
                       p_Process_Results   In Out      Customer.Process_Result_Table);
    --ademo.29.11.2017
    Procedure Send_Sms(p_Sms_Input         In          Customer.EuroMsg_Sms_Input_Rec,
                       p_Message_Type      In          Number,
                       p_User              In          Varchar2,
                       p_Response_Rec      In Out      Customer.EuroMsg_Mail_Response_Table,
                       p_Process_Results   In Out      Customer.Process_Result_Table);

End;

CREATE OR REPLACE PACKAGE BODY "CUSTOMER"."ALZ_EUROMSG_UTILS" Is

   PROCEDURE getcontenterr(p_value  in varchar2,
                           p_hata   in varchar2,
                           p_Response_Rec in out Customer.EuroMsg_Mail_Response_Table) is

    x_Name varchar2(2000);
    X_Value varchar2(2000);
    y_value varchar2(4000);
    v_Response_Rec  customer.EuroMsg_Mail_Response_Table :=customer.EuroMsg_Mail_Response_Table();

    BEGIN

       SELECT replace(replace(replace(replace(p_value,'[{', ''),'}',''),'}]',''),'{','') into y_value
                      FROM DUAL;

       For Xt
            In (Select Regexp_Substr (y_value,
                                      '[^,]+',
                                      1,
                                      Level)
                              Element
                      From Dual
                Connect By Level <=
                              Length (Regexp_Replace (y_value, '[^,]+')) + 1)
         Loop

            x_Name  :=  replace (Regexp_Substr (Xt.Element, '[^:]+', 1) , '"','');
            x_Value :=  replace (Regexp_Substr (Xt.Element, '[^:]+', 1, 2), '"','');

            v_Response_Rec.extend;
            v_Response_Rec(v_Response_Rec.count) :=EuroMsg_Mail_Response_Rec(p_hata,
                                                                             x_Name,
                                                                             x_Value);

            p_Response_Rec:= v_Response_Rec;
       End Loop;

   END getcontenterr;

   PROCEDURE before_send_mailsms (p_Mail_Input  In Out Customer.EuroMsg_Mail_Input_Rec,
                                  p_Body        In Out varchar2,
                                  p_Gsm_No      In Out Varchar2,
                                  pmessage_type In varchar2) is


   BEGIN

    if pmessage_type='sendMail' then

      If KOC_GENERAL_UTILS.GET_DB_NAME = 'OPUSDEV' then
        p_Mail_Input.Subject:=p_Mail_Input.Subject||' UATTEST';
      else
        p_Mail_Input.Subject:=p_Mail_Input.Subject||' PREPTEST';
      End if;

/*      If p_Mail_Input.To_List Is Not Null And p_Mail_Input.To_List.Count > 0 Then
        For i In 1..p_Mail_Input.To_List.Count
         Loop

           if p_Mail_Input.To_List(i).Str is not null then
            p_Mail_Input.To_List(i).Str:='huseyins.danisman@allianz.com.tr';
            p_Mail_Input.Mail_Body:=p_Mail_Input.Mail_Body||g_mail_to;
            p_Mail_Input.Mail_Body:= replace(p_Mail_Input.Mail_Body, '@mail_to_inf@',p_Mail_Input.To_List(i).Str);
            p_Mail_Input.Mail_Body:= replace(p_Mail_Input.Mail_Body, '@mail_cc_inf@','');
            p_Mail_Input.Mail_Body:= replace(p_Mail_Input.Mail_Body, '@mail_bcc_inf@','');
           end if;

        end loop;
      End if;

      If p_Mail_Input.Cc_List Is Not Null And p_Mail_Input.Cc_List.Count > 0 Then
       For i In 1..p_Mail_Input.Cc_List.Count
         Loop

           if p_Mail_Input.Cc_List(i).Str is not null then
            p_Mail_Input.Cc_List(i).Str:='huseyins.danisman@allianz.com.tr';
            p_Mail_Input.Mail_Body:=p_Mail_Input.Mail_Body||g_mail_to;
            p_Mail_Input.Mail_Body:= replace(p_Mail_Input.Mail_Body, '@mail_cc_inf@',p_Mail_Input.Cc_List(i).Str);
            p_Mail_Input.Mail_Body:= replace(p_Mail_Input.Mail_Body, '@mail_to_inf@','');
            p_Mail_Input.Mail_Body:= replace(p_Mail_Input.Mail_Body, '@mail_bcc_inf@','');
          end if;

       end loop;
      End if;

      If p_Mail_Input.Bcc_List Is Not Null And p_Mail_Input.Bcc_List.Count > 0 Then
       For i In 1..p_Mail_Input.Bcc_List.Count
        Loop

         if p_Mail_Input.Bcc_List(i).Str is not null then
           p_Mail_Input.Bcc_List(i).Str:='huseyins.danisman@allianz.com.tr';
           p_Mail_Input.Mail_Body:=p_Mail_Input.Mail_Body||g_mail_to;
           p_Mail_Input.Mail_Body:= replace(p_Mail_Input.Mail_Body, '@mail_bcc_inf@',p_Mail_Input.Bcc_List(i).Str);
           p_Mail_Input.Mail_Body:= replace(p_Mail_Input.Mail_Body, '@mail_to_inf@','');
           p_Mail_Input.Mail_Body:= replace(p_Mail_Input.Mail_Body, '@mail_cc_inf@','');
        end if;

       end loop;
      End if;*/

    else
      -- p_Gsm_No:='905334115363';
       p_Body:=p_Body||'  '||g_gsm_to;
       p_Body:= replace(p_Body, '@gsm_no@',p_Gsm_No);

    end if;

   END before_send_mailsms;

   Function Convert_Mail_Input_To_Payload( p_Mail_Input In  Customer.EuroMsg_Mail_Input_Rec)
    Return Clob Is
        v_Payload           Clob;
        v_ndx               Number := 0;
    Begin
        v_Payload := '{';

        If p_Mail_Input Is Not Null Then

            /* attachmentList */
           If p_Mail_Input.Attachment_List Is Not Null And p_Mail_Input.Attachment_List.Count > 0 Then

              v_Payload := v_Payload||'"attachmentList":[';

              For i In 1..p_Mail_Input.Attachment_List.Count
              Loop

                  If i=1 and (p_Mail_Input.Attachment_List(i).Document_Name Is Not Null or p_Mail_Input.Attachment_List(i).Content_Type Is Not Null
                         or   p_Mail_Input.Attachment_List(i).Attachment Is Not Null or  p_Mail_Input.Attachment_List(i).Document_Size Is Not Null) Then
                      v_Payload := v_Payload||'{';
                  End if;

                  If p_Mail_Input.Attachment_List(i).Document_Name Is Not Null Then
                     v_Payload := v_Payload||'"documentName":"'||p_Mail_Input.Attachment_List(i).Document_Name||'",';
                  End If;
                  If p_Mail_Input.Attachment_List(i).Content_Type Is Not Null Then
                     v_Payload := v_Payload||'"contentType":"'||p_Mail_Input.Attachment_List(i).Content_Type||'",';
                  End If;
                  If p_Mail_Input.Attachment_List(i).Attachment Is Not Null Then
                     v_Payload := v_Payload||'"attachment":['||p_Mail_Input.Attachment_List(i).Attachment||'],'; --AliSakalli TPA-FAZ2 - 075
                  End If;
                  If p_Mail_Input.Attachment_List(i).Document_Size Is Not Null Then
                     v_Payload := v_Payload||'"documentSize":"'||p_Mail_Input.Attachment_List(i).Document_Size||'"';
                  End If;

                  if p_Mail_Input.Attachment_List.Count>1 then
                    v_Payload := v_Payload||',';
                  End if;
                  /* v_Payload en sondaki virg�l sil */

                  If i = p_Mail_Input.Attachment_List.Count and
                    (p_Mail_Input.Attachment_List(i).Document_Name Is Not Null or p_Mail_Input.Attachment_List(i).Content_Type Is Not Null
                     or p_Mail_Input.Attachment_List(i).Attachment Is Not Null or p_Mail_Input.Attachment_List(i).Document_Size Is Not Null) Then
                    v_Payload := v_Payload||'}';
                  End if;

                  If i < p_Mail_Input.Attachment_List.Count Then
                    v_Payload := v_Payload||',';
                  End If;

              End Loop;

              v_Payload := v_Payload||'],';

           End If;

           /* templateName */

           If p_Mail_Input.Template_Name Is Not Null Then
              v_Payload := v_Payload||'"templateName":"'||p_Mail_Input.Template_Name||'",';
           End If;

            /* templateParameters */
           --[ademo.start
           If p_Mail_Input.Template_Parameters Is Not Null And p_Mail_Input.Template_Parameters.Count>0 Then
              v_Payload := v_Payload||'"templateParameters":[';
              v_ndx := 0;
              FOR rec IN (SELECT Parameter_Name,Parameter_Value FROM TABLE(p_Mail_Input.Template_Parameters)) LOOP
                  IF v_ndx>0 THEN
                      v_Payload := v_Payload||',';
                  END IF;
                  v_Payload := v_Payload||'{';
                  v_Payload := v_Payload||'"name":"'||rec.Parameter_Name||'",';
                  v_Payload := v_Payload||'"value":"'||rec.Parameter_Value||'"';
                  v_Payload := v_Payload||'}';
                  v_ndx := v_ndx + 1;
              END LOOP;
              v_Payload := v_Payload||'],';
           End If;
           --ademo.end]
           /* toList */

           If p_Mail_Input.To_List Is Not Null And p_Mail_Input.To_List.Count > 0 Then

              v_Payload := v_Payload||'"toList":[';

              For i In 1..p_Mail_Input.To_List.Count
              Loop

                  v_Payload := v_Payload||'"'||p_Mail_Input.To_List(i).Str||'"';
                  If i < p_Mail_Input.To_List.Count Then
                    v_Payload := v_Payload||',';
                  End If;

              End Loop;

              v_Payload := v_Payload||'],';

           End If;

           /* ccList */

           If p_Mail_Input.Cc_List Is Not Null And p_Mail_Input.Cc_List.Count > 0 Then

              v_Payload := v_Payload||'"ccList":[';

              For i In 1..p_Mail_Input.Cc_List.Count
              Loop

                  v_Payload := v_Payload||'"'||p_Mail_Input.Cc_List(i).Str||'"';
                  If i < p_Mail_Input.Cc_List.Count Then
                    v_Payload := v_Payload||',';
                  End If;

              End Loop;

              v_Payload := v_Payload||'],';

           End If;

           /* bccList */

           If p_Mail_Input.Bcc_List Is Not Null And p_Mail_Input.Bcc_List.Count > 0 Then

              v_Payload := v_Payload||'"bccList":[';

              For i In 1..p_Mail_Input.Bcc_List.Count
              Loop

                  v_Payload := v_Payload||'"'||p_Mail_Input.Bcc_List(i).Str||'"';
                  If i < p_Mail_Input.Bcc_List.Count Then
                    v_Payload := v_Payload||',';
                  End If;

              End Loop;

              v_Payload := v_Payload||'],';

           End If;

           /* subject */

           If p_Mail_Input.Subject Is Not Null Then
              v_Payload := v_Payload||'"subject":"'||p_Mail_Input.Subject||'",';
           End If;

           /* body */

           If p_Mail_Input.Mail_Body Is Not Null Then
              v_Payload := v_Payload||'"body":"'||p_Mail_Input.Mail_Body||'",';
           End If;

           /* applicationName */

           If p_Mail_Input.Application_Name Is Not Null Then
              v_Payload := v_Payload||'"applicationName":"'||p_Mail_Input.Application_Name||'",';
           End If;

           /* reportList */
           If  p_Mail_Input.Report_List Is Not Null And p_Mail_Input.Report_List.Count > 0 Then
              v_Payload := v_Payload||'"reportList":[';
              v_Payload := v_Payload||'{';
            For i In 1..p_Mail_Input.Report_List.Count
            Loop
              v_Payload := v_Payload||'"fileLang":"'||p_Mail_Input.Report_List(i).File_Lang||'",';
              v_Payload := v_Payload||'"fileParamForHandleException":"'||p_Mail_Input.Report_List(i).File_Param_For_Handle_Ex||'",';
              v_Payload := v_Payload||'"fileName":"'||p_Mail_Input.Report_List(i).File_Name||'",';
              v_Payload := v_Payload||'"reportName":"'||p_Mail_Input.Report_List(i).Report_Name||'",';

              v_Payload := v_Payload||'"reportParameters":[';
             For j In 1..p_Mail_Input.Report_List(i).Report_Parameters.Count
              Loop
                v_Payload := v_Payload||'{';
                v_Payload := v_Payload||'"name":"'||p_Mail_Input.Report_List(i).Report_Parameters(j).Parameter_Name||'",';
                v_Payload := v_Payload||'"value":"'||p_Mail_Input.Report_List(i).Report_Parameters(j).Parameter_Value||'"';

                if j<p_Mail_Input.Report_List(i).Report_Parameters.Count then
                v_Payload := v_Payload||'},';
                end if;

             end loop ;

              v_Payload := v_Payload||'}],';

              v_Payload := v_Payload||'"contentType":"'||p_Mail_Input.Report_List(i).Content_Type||'"';

              If i < p_Mail_Input.Report_List.Count Then
                v_Payload := v_Payload||',';
              End If;

            End Loop;
            v_Payload := v_Payload||'}';
            v_Payload := v_Payload||'],';
          End if;

           /* companyCode */
           If p_Mail_Input.Company_Code Is Not Null Then
              v_Payload := v_Payload||'"companyCode":"'||p_Mail_Input.Company_Code||'"';
              v_Payload := v_Payload||',';
           End If;

            If p_Mail_Input.Client_Key Is Not Null Then
              v_Payload := v_Payload||'"clientKey":"'||p_Mail_Input.Client_Key||'"';
           End If;
           --[ademo.start
           If p_Mail_Input.Parameter_Map Is Not Null And p_Mail_Input.Parameter_Map.Count>0 Then
              v_Payload := v_Payload||',"parameterMap":{';
              v_ndx := 0;
              FOR rec IN (SELECT Parameter_Name,Parameter_Value FROM TABLE(p_Mail_Input.Parameter_Map)) LOOP
                  IF v_ndx>0 THEN
                      v_Payload := v_Payload||',';
                  END IF;
                  v_Payload := v_Payload||'"'||rec.Parameter_Name||'":"'||rec.Parameter_Value||'"';
                  v_ndx := v_ndx + 1;
              END LOOP;
              v_Payload := v_Payload||'}';
           End If;
           --ademo.end]
        End If;

        /* v_Payload en sondaki virg�l sil */

        v_Payload := v_Payload||'}';

        Return v_Payload;

    End;

    Function Convert_Sms_Input_To_Payload(p_Sms_Input  In  Customer.EuroMsg_Sms_Input_Rec)
        Return Clob Is
        v_Payload           Clob;
        v_ndx               Number := 0;
    Begin

      v_Payload := '{';
      If p_Sms_Input.Sms_Body Is Not Null Then

        v_Payload := v_Payload||'"smsBody":'||'"'||p_Sms_Input.Sms_Body||'",';
        v_Payload := v_Payload||'"gsmNo":'||'"'||p_Sms_Input.Gsm_No||'",';
        v_Payload := v_Payload||'"companyCode":'||'"'||p_Sms_Input.Company_code||'"';
        --[ademo.start
        If p_Sms_Input.Client_Key Is Not Null Then
           v_Payload := v_Payload||',"clientKey":'||'"'||p_Sms_Input.Client_Key||'"';
        End If;

        If p_Sms_Input.Parameter_Map Is Not Null And p_Sms_Input.Parameter_Map.Count>0 Then
              v_Payload := v_Payload||',"parameterMap":{';
              v_ndx := 0;
              FOR rec IN (SELECT Parameter_Name,Parameter_Value FROM TABLE(p_Sms_Input.Parameter_Map)) LOOP
                  IF v_ndx>0 THEN
                      v_Payload := v_Payload||',';
                  END IF;
                  v_Payload := v_Payload||'"'||rec.Parameter_Name||'":"'||rec.Parameter_Value||'"';
                  v_ndx := v_ndx + 1;
              END LOOP;
              v_Payload := v_Payload||'}';
        End If;
        --ademo.end]
        v_Payload := v_Payload||'}';

      End If;

        Return v_Payload;
    End;

    Procedure Call_TPA_Service(p_Method            In          Varchar2,
                               p_Payload           In          Clob,
                               p_User              In          Varchar2,
                               p_Response_Rec      In Out      Customer.EuroMsg_Mail_Response_Table,
                               p_Process_Results   In Out      Customer.Process_Result_Table) Is

        ---v_URL               Varchar2(500) := get_url_link('http://esb.allianz.com.tr:12000/external/Tpa/rest/euroMessageService');
        v_URL               Varchar2(500) := get_url_link('http://esb.allianz.com.tr:12000/external/MessageService/rest/euroMessageService');

        v_Req               utl_http.req;
        v_Req_Length        Number;
        v_Res               utl_http.resp;

        v_Buffer            Varchar2(32767);
        v_Offset            Number := 1;
        v_Amount            Number :=32767;
        v_Utl_Err           Varchar2(1000);
        v_value             varchar2(4000);
        hata_code           varchar2(10);
        v_output            varchar2(10);
        v_Response_Rec      customer.EuroMsg_Mail_Response_Table :=customer.EuroMsg_Mail_Response_Table();
    Begin

        v_Req_Length := dbms_lob.getlength(p_Payload);

        v_Req := utl_http.begin_request(v_URL||'/'||p_Method, 'POST', 'HTTP/1.1');

        --utl_http.set_header(v_Req, 'Auth','Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJwbGF0Zm9ybSI6IkFMWl9UUEFEQiJ9.0yhHtB8X9taBuJ5h-8ZYmz7aVK7LnMiGhKr5tP6wXfY');
        utl_http.set_header(v_Req, 'Auth','Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJwbGF0Zm9ybSI6IkRCIn0.Vcq2uIMGOq3N8o9S-E-O93YuZ8qJVH0Or7tSfTxV_Qk');

        utl_http.set_header(v_Req, 'Content-Length', v_Req_Length);
        utl_http.set_header(v_Req, 'Content-Type', 'application/json;charset=UTF-8');
        utl_http.set_header (v_Req,'Transfer-Encoding', 'chunked' );
        utl_http.set_body_charset(v_Req,'UTF-8');

        While (v_Offset < v_Req_Length)
        Loop
           dbms_lob.read(p_Payload, v_Amount, v_Offset, v_Buffer);
           utl_http.write_text(r    => v_Req, data => v_Buffer);
           v_Offset := v_Offset + v_Amount;
        End Loop;

        v_Res := utl_http.get_response(v_Req);
        Begin
           loop
              utl_http.read_line(v_Res, v_value);

              hata_code:=v_Res.status_code;

              getcontenterr(v_value,
                            hata_code,
                            v_Response_Rec);

              p_Response_Rec:=v_Response_Rec;
           end loop;

              utl_http.end_response(v_Res);
        Exception
        When utl_http.end_of_body Then
             utl_http.end_response(v_Res);
        When utl_http.too_many_requests Then
             utl_http.end_response(v_Res);
        When Others Then
             utl_http.end_response(v_Res);
       End;

    exception when others then
    utl_http.end_response(v_Res);
    v_utl_err:= Utl_Http.Get_Detailed_Sqlerrm;
    alz_web_process_utils.process_result (0,
                                          9,
                                          -1,
                                          'INVOKE ERR',
                                          substr (sqlcode || ' - ' || sqlerrm || ' - ' || dbms_utility.format_error_backtrace, 1, 1000),
                                          v_utl_err,
                                          null,
                                          null,
                                          'Alz_Euromsg_Utils.Call_TPA_Service',
                                          p_User,
                                          p_process_results);

    End;

   Procedure Send_Mail(p_Mail_Input        In          Customer.EuroMsg_Mail_Input_Rec,
                       p_User              In          Varchar2,
                       p_Response_Rec      In Out      Customer.EuroMsg_Mail_Response_Table,
                       p_Process_Results   In Out      Customer.Process_Result_Table) Is

         v_Payload           Clob;
         v_status_code       varchar2(10);
         v_body              varchar2(4000):=null;
         v_gsm_no            varchar2(20):=null;
         v_Mail_Input        Customer.EuroMsg_Mail_Input_Rec;

    Begin
         v_Mail_Input:=p_Mail_Input;

        if koc_general_utils.get_db_name not in ('OPUSDATA') then
         before_send_mailsms (v_Mail_Input,
                              v_body,
                              v_gsm_no,
                              'sendMail');
        end if;

        v_Payload := Convert_Mail_Input_To_Payload(v_Mail_Input);
        Call_TPA_Service('sendMail',
                         v_Payload,
                         p_User,
                         p_Response_Rec,
                         p_Process_Results);

     exception when others then
     alz_web_process_utils.process_result (0,
                                            9,
                                            -1,
                                            'INVOKE ERR',
                                            substr (sqlcode || ' - ' || sqlerrm || ' - ' || dbms_utility.format_error_backtrace, 1, 1000),
                                            null,
                                            null,
                                            null,
                                            'Alz_Euromsg_Utils.Send_Mail',
                                            p_User,
                                            p_process_results);
    End;

    Procedure Send_Mail_With_Template(p_Mail_Input        In          Customer.EuroMsg_Mail_Input_Rec,
                                      p_User              In          Varchar2,
                                      p_Response_Rec      In Out      Customer.EuroMsg_Mail_Response_Table,
                                      p_Process_Results   In Out      Customer.Process_Result_Table) Is

        v_Payload           Clob;
        v_status_code       varchar2(10);
    Begin

        v_Payload := Convert_Mail_Input_To_Payload(p_Mail_Input);
        Call_TPA_Service('sendMailWithTemplate',
                         v_Payload,
                         p_User,
                         p_Response_Rec,
                         p_Process_Results);
     exception when others then
     alz_web_process_utils.process_result (0,
                                            9,
                                            -1,
                                            'INVOKE ERR',
                                            substr (sqlcode || ' - ' || sqlerrm || ' - ' || dbms_utility.format_error_backtrace, 1, 1000),
                                            null,
                                            null,
                                            null,
                                            'Alz_Euromsg_Utils.Send_Mail_With_Template',
                                            p_User,
                                            p_process_results);

    End;

    Procedure Send_Sms(p_Gsm_No            In     Varchar2,
                       p_Sms_Content       In     Varchar2,
                       p_Company_code      In     Varchar2,
                       p_Message_Type      In     Number,
                       p_User              In     Varchar2,
                       p_Response_Rec      In Out Customer.EuroMsg_Mail_Response_Table,
                       p_Process_Results   In Out Customer.Process_Result_Table) Is


     v_Sms_Input         Customer.EuroMsg_Sms_Input_Rec;

    Begin
        v_Sms_Input :=  Customer.EuroMsg_Sms_Input_Rec(p_Gsm_No,
                                                       p_Sms_Content,
                                                       p_Company_code,
                                                       null, --client_key
                                                       null  --parameterMap
                                                        );
        Send_Sms(v_Sms_Input,
                 p_Message_Type,
                 p_User,
                 p_Response_Rec,
                 p_Process_Results);

    End Send_Sms;

    Procedure Send_Sms(p_Sms_Input         In          Customer.EuroMsg_Sms_Input_Rec,
                       p_Message_Type      In          Number,
                       p_User              In          Varchar2,
                       p_Response_Rec      In Out      Customer.EuroMsg_Mail_Response_Table,
                       p_Process_Results   In Out      Customer.Process_Result_Table) IS
     v_Payload           Clob;
     v_status_code       varchar2(10);
     v_Mail_Input        Customer.EuroMsg_Mail_Input_Rec;
     v_Sms_Content       varchar2(4000);
     v_Gsm_No            varchar2(20);
     v_Method            Varchar2(100);
     v_Sms_Input         Customer.EuroMsg_Sms_Input_Rec;
    BEGIN
       v_Sms_Input := p_Sms_Input;
       if koc_general_utils.get_db_name not in ('OPUSDATA') then
           v_Sms_Content := v_Sms_Input.Sms_Body;
           v_Gsm_No      := v_Sms_Input.Gsm_No;
           before_send_mailsms (v_Mail_Input,
                              v_Sms_Content,
                              v_Gsm_No,
                              'sendSms');
           v_Sms_Input.Sms_Body := v_Sms_Content;
        end if;

        v_Payload := Convert_Sms_Input_To_Payload(v_Sms_Input);

        if Nvl(p_Message_Type, 0) = 0 then
             v_Method := 'sendSms';
        else
             v_Method := 'quickSendSms';
        end if;

        Call_TPA_Service(v_Method,
                         v_Payload,
                         p_User,
                         p_Response_Rec,
                         p_Process_Results);

    EXCEPTION
    WHEN OTHERS THEN
     alz_web_process_utils.process_result (0,
                                           9,
                                           -1,
                                           'INVOKE ERR',
                                            substr (sqlcode || ' - ' || sqlerrm || ' - ' || dbms_utility.format_error_backtrace, 1, 1000),
                                            null,
                                            null,
                                            null,
                                            'Alz_Euromsg_Utils.Send_Sms',
                                            p_User,
                                            p_process_results);
    END Send_Sms;
End;

/
