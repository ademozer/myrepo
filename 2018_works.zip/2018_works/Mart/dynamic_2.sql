DECLARE
       v_status VARCHAR2(10000);
             
       PROCEDURE execute_script(p_params IN VARCHAR2, p_out OUT VARCHAR2) IS
         v_script VARCHAR2(1000);
  
         cur_ SYS_REFCURSOR; 
         tbl_ customer.process_result_table := customer.process_result_table();
         var_ VARCHAR2(1000);
         num_ NUMBER;
         dat_ DATE;
          
         v_ndx NUMBER;
         v_payload CLOB;
         v_out_param_type VARCHAR2(100);
         v_ndx_point NUMBER;
         v_pkg_name  VARCHAR2(100);
         v_prc_name  VARCHAR2(100);
         v_arg_name VARCHAR2(100);
         v_data_type  VARCHAR2(100);
         v_smp_type   VARCHAR2(100); 
         v_cur_type   VARCHAR2(100); 
         v_tbl_type  VARCHAR2(100); 
         v_cur_found  BOOLEAN := FALSE;
         v_tbl_found  BOOLEAN := FALSE;
         v_smp_found  BOOLEAN := FALSE; 
         v_arg_count  NUMBER := 0;
         v_type       NUMBER := 0;
         v_err        VARCHAR2(1000);
         v_arg_found  BOOLEAN := FALSE;
         v_params VARCHAR2(4000);
         v_tmp_params VARCHAR2(4000);
         v_method VARCHAR2(1000);
         v_data_found BOOLEAN := FALSE;
         v_data_msg   VARCHAR2(4000);
         v_err_found  BOOLEAN := FALSE;
         v_err_message VARCHAR2(4000);
         v_param_count NUMBER;
         v_object_id   NUMBER;
       BEGIN
         v_ndx := 0;
         v_param_count := 0;
         v_tmp_params := p_params;
         v_tmp_params := replace(replace(replace(replace(v_tmp_params,'[{', ''),'}',''),'}]',''),'{','');
         v_params := '';
         FOR rec IN 
               ( SELECT trim(replace (Regexp_Substr (Xt.Element, '[^:]+', 1) , '"',''))   KEY,
                       trim(replace (Regexp_Substr (Xt.Element, '[^:]+', 1, 2), '"','')) VALUE 
                  FROM (Select Regexp_Substr (v_tmp_params,
                                              '[^,]+',
                                              1,
                                              Level)
                                      Element
                              From Dual
                        Connect By Level <= Length (Regexp_Replace (v_tmp_params, '[^,]+')) + 1) Xt) LOOP
               IF LOWER(rec.KEY)  = 'service' THEN
                   v_method := rec.VALUE; 
                   v_ndx_point :=  INSTR(v_method,'.');
                   IF v_ndx_point>0 THEN
                       v_pkg_name  :=  SUBSTR(UPPER(v_method), 0, v_ndx_point - 1);
                       v_prc_name  :=  SUBSTR(UPPER(v_method), v_ndx_point + 1);
                   ELSE
                       v_pkg_name  := NULL;
                       v_prc_name  := UPPER(v_method);
                   END IF;
                   BEGIN
                        select OBJECT_ID 
                        into v_object_id
                        from all_procedures 
                        where ((v_pkg_name IS NULL AND object_name = v_prc_name AND procedure_name IS NULL)
                             OR (v_pkg_name IS NOT NULL AND object_name = v_pkg_name AND procedure_name = v_prc_name))
                          and NVL(overload,1) = 1;                        
                   EXCEPTION
                   WHEN NO_DATA_FOUND THEN
                         Raise_Application_Error(-20200,'Alt Rutin Bulunamad�:'||v_method);
                   /*WHEN TOO_MANY_ROWS THEN
                         Raise_Application_Error(-20200,'Birden Fazla Alt Rutin Bulundu:'||v_method);*/
                   END;
               ELSE
                   IF v_ndx>0 THEN
                      v_params := v_params || ', ';
                   END IF;
                   
                   IF UPPER(rec.VALUE) = 'NULL' THEN
                       v_params := v_params || rec.VALUE;
                   ELSE 
                       BEGIN                            
                          --DBMS_OUTPUT.PUT_LINE(rec.KEY||':'||rec.VALUE);
                           select DATA_TYPE
                            INTO v_data_type
                            from all_arguments 
                           where object_name=  v_prc_name
                             AND ((v_pkg_name IS NOT NULL AND PACKAGE_NAME = v_pkg_name) OR (v_pkg_name IS NULL AND PACKAGE_NAME IS NULL))
                             AND IN_OUT = 'IN'
                             AND ARGUMENT_NAME =  UPPER(rec.KEY)
                             AND ARGUMENT_NAME IS NOT NULL;
                       EXCEPTION 
                       WHEN NO_DATA_FOUND THEN
                          Raise_Application_Error(-20200,'Ge�ersiz Parametre:'||rec.KEY);
                       END; 
                       IF v_data_type = 'VARCHAR2' THEN                    
                             v_params := v_params || ''''|| rec.VALUE ||'''';                     
                       ELSIF v_data_type = 'DATE' THEN
                          v_params := v_params || 'TO_DATE('''||rec.VALUE||''',''DD/MM/YYYY'')';   
                       ELSIF v_data_type = 'NUMBER' THEN                   
                          v_params := v_params || rec.VALUE;
                       ELSE 
                          Raise_Application_Error(-20200, 'Desteklenmeyen Veri Tipi:'||rec.KEY||':'||v_data_type);
                       END IF;    
                   END IF;                        
                   v_ndx := v_ndx + 1;                   
               END IF;              
           END LOOP;
           v_param_count := v_ndx;  
             FOR rec IN (
                      select ARGUMENT_NAME, DATA_TYPE, IN_OUT 
                        from all_arguments 
                       where object_name= v_prc_name
                         AND ((v_pkg_name IS NOT NULL AND PACKAGE_NAME = v_pkg_name) OR (v_pkg_name IS NULL AND PACKAGE_NAME IS NULL))
                         AND IN_OUT != 'IN'
                         AND ARGUMENT_NAME IS NOT NULL)
                LOOP
                    IF rec.Data_Type = 'REF CURSOR' AND NOT v_cur_found THEN
                        v_cur_found := TRUE;
                        v_cur_type := rec.In_Out;
                        v_arg_count := v_arg_count + 1;
                    ELSIF rec.Data_Type = 'TABLE' AND NOT v_tbl_found THEN
                        v_tbl_found := TRUE;
                        v_tbl_type := rec.In_Out;
                        v_arg_count := v_arg_count + 1;
                    ELSIF rec.Data_Type IN ('NUMBER', 'VARCHAR2', 'DATE') THEN
                        v_smp_found := TRUE;
                        v_data_type := rec.Data_Type;
                        v_smp_type  := rec.In_Out;
                        v_arg_count := v_arg_count + 1;               
                    END IF;
                    v_arg_found := TRUE;               
                END LOOP;
                IF v_arg_found THEN
                    IF v_cur_found THEN
                       IF v_tbl_found THEN
                           IF v_arg_count != 2 THEN              
                               Raise_Application_Error(-20200, 'Bir Adet Curs�r  ve Table Olabilir');
                           END IF;                                                                         
                           v_type := 0 ; -- cursor and table
                       ELSE 
                           IF v_arg_count != 1 THEN
                               Raise_Application_Error(-20200, 'Bir Adet Curs�r Olabilir');
                           END IF;
                           v_type := 1; --cursor only
                       END IF;   
                    ELSE
                       IF v_tbl_found THEN
                           IF v_arg_count != 1 THEN
                               Raise_Application_Error(-20200, 'Bir Adet Table Olabilir');
                           END IF;
                           v_type := 2; -- table only
                       ELSE 
                           IF v_smp_found THEN
                               IF v_arg_count != 1 THEN
                                   Raise_Application_Error(-20200, 'Bir Adet Simple Type Olabilir');
                               END IF;
                               v_type := 3; --simple only
                           ELSE 
                               Raise_Application_Error(-20200, 'Desteklenmeyen Prosed�r'); 
                               --v_type := 5; -- no available out param
                           END IF;
                       END IF;
                    END IF;
                ELSE
                  DBMS_OUTPUT.PUT_LINE('Type='||v_type||':'||v_params);               
                    select DATA_TYPE
                      into v_data_type
                      from all_arguments 
                     where object_name= v_prc_name
                       AND ((v_pkg_name IS NOT NULL AND PACKAGE_NAME = v_pkg_name) OR (v_pkg_name IS NULL AND PACKAGE_NAME IS NULL))
                       AND IN_OUT = 'OUT'
                       AND ARGUMENT_NAME IS NULL;                                                     
                    v_type := 4; -- no out param
                END IF;
            DBMS_OUTPUT.PUT_LINE('Type='||v_type||':'||v_params);
            v_script := 'BEGIN '||v_method||'('||v_params;          
           CASE v_type
              WHEN 0 THEN    
                v_script := v_script || ', :v_cur, :v_tbl); END;'; 
                IF v_cur_type = 'IN/OUT' AND v_tbl_type = 'IN/OUT' THEN
                    --DBMS_OUTPUT.PUT_LINE('1');
                    EXECUTE IMMEDIATE v_script USING IN OUT cur_, IN OUT tbl_;                                   
                END IF;  
                IF v_cur_type = 'IN/OUT' AND v_tbl_type = 'OUT' THEN
                    --DBMS_OUTPUT.PUT_LINE('2');
                    EXECUTE IMMEDIATE v_script USING IN OUT cur_, OUT tbl_;                                   
                END IF;  
                IF v_cur_type = 'OUT' AND v_tbl_type = 'IN/OUT' THEN
                    --DBMS_OUTPUT.PUT_LINE('3:'||v_script);
                    EXECUTE IMMEDIATE v_script USING OUT cur_, IN OUT tbl_;                                   
                END IF;  
                IF v_cur_type = 'OUT' AND v_tbl_type = 'OUT' THEN
                    --DBMS_OUTPUT.PUT_LINE('4'); 
                    EXECUTE IMMEDIATE v_script USING OUT cur_, OUT tbl_;                                   
                END IF;                                  
              WHEN 1 THEN
                v_script := v_script ||', :v_cur); END;'; 
                IF v_cur_type = 'IN/OUT' THEN
                    EXECUTE IMMEDIATE v_script USING IN OUT cur_;  
                ELSE
                    EXECUTE IMMEDIATE v_script USING OUT cur_;                                  
                END IF;
              WHEN 2 THEN
                v_script := v_script || ', :v_tbl); END;'; 
                IF v_tbl_type = 'IN/OUT' THEN
                    EXECUTE IMMEDIATE v_script USING IN OUT tbl_;  
                ELSE
                    EXECUTE IMMEDIATE v_script USING OUT tbl_;                                  
                END IF; 
              WHEN 3 THEN
                v_script := v_script ||', :v_arg); END;'; 
                --DBMS_OUTPUT.PUT_LINE('script='||v_script);
                IF v_smp_type = 'IN/OUT' THEN
                    IF v_data_type = 'VARCHAR2' THEN
                        EXECUTE IMMEDIATE v_script USING IN OUT var_; 
                    END IF;
                    IF v_data_type = 'NUMBER' THEN
                        EXECUTE IMMEDIATE v_script USING IN OUT num_; 
                    END IF;
                    IF v_data_type = 'DATE' THEN
                        EXECUTE IMMEDIATE v_script USING IN OUT dat_; 
                    END IF;
                ELSE 
                    IF v_data_type = 'VARCHAR2' THEN
                        EXECUTE IMMEDIATE v_script USING OUT var_; 
                    END IF;
                    IF v_data_type = 'NUMBER' THEN
                        EXECUTE IMMEDIATE v_script USING OUT num_; 
                    END IF;
                    IF v_data_type = 'DATE' THEN
                        EXECUTE IMMEDIATE v_script USING OUT dat_; 
                    END IF;
                END IF;  
             WHEN 4 THEN                 
                 v_script := 'BEGIN :v_out := '||v_method;
                 IF v_param_count>0 THEN
                     v_script := v_script||'('||v_params||')';
                 END IF; 
                 v_script := v_script ||'; END;'; 
                 --DBMS_OUTPUT.PUT_LINE('script='||v_script||'-'||v_data_type);
                 IF v_data_type IN ('VARCHAR2','CHAR') THEN                   
                      EXECUTE IMMEDIATE v_script USING OUT var_;
                       v_smp_found := true;
                 END IF;    
                 IF v_data_type = 'NUMBER' THEN                   
                      EXECUTE IMMEDIATE v_script USING OUT num_;
                       v_smp_found := true;
                 END IF;
                 IF v_data_type = 'DATE' THEN                   
                      EXECUTE IMMEDIATE v_script USING OUT dat_;
                      v_smp_found := true;
                 END IF;   
                 IF v_data_type = 'REF CURSOR' THEN                   
                      EXECUTE IMMEDIATE v_script USING OUT cur_;
                      v_cur_found := true;
                 END IF;                                
           END CASE;            
           v_payload := '{"status" : "SUCCESS"';
           IF v_cur_found THEN              
             IF cur_%ISOPEN THEN     
                 v_ndx := 0;                 
                 v_data_msg := v_data_msg || '[';
                 FOR rec_1 IN (SELECT ROWNUM ROW_NO, 
                                      t1.column_value.getStringVal() ROW_DATA
                                 FROM (SELECT * FROM TABLE (XMLSEQUENCE(cur_))) t1)    
                 LOOP                   
                     IF rec_1.ROW_NO>1 THEN
                         v_data_msg := v_data_msg || ',';
                     END IF;
                     v_data_msg := v_data_msg || '{';
                     v_ndx := 0;
                     FOR rec_2 IN (SELECT EXTRACTVALUE (t.COLUMN_VALUE, '/*') AS NODE_VALUE,
                                                        t.COLUMN_VALUE.getrootelement () AS NODE_NAME
                                     FROM TABLE (XMLSEQUENCE (EXTRACT(EXTRACT(XMLTYPE(rec_1.ROW_DATA), '//*'), '/ROW/*'))) t)
                     LOOP
                        IF v_ndx>0 THEN
                           v_data_msg := v_data_msg || ',';
                        END IF;
                        v_data_msg := v_data_msg || '"' || LOWER(rec_2.NODE_NAME) || '":"' || TRIM(rec_2.Node_Value) || '"';
                        v_ndx := v_ndx + 1;                         
                     END LOOP;
                     v_data_msg := v_data_msg || '}';
                 END LOOP;   
                 v_data_msg := v_data_msg || ']';
                 IF v_ndx>0 THEN
                      v_data_found := TRUE;
                 END IF;
                CLOSE cur_;                           
             END IF;                      
          END IF;
          IF v_tbl_found THEN                          
               v_err_message := '[';         
               OPEN cur_ FOR SELECT * FROM TABLE (tbl_);            
               v_ndx := 0;
               FOR rec_1 IN (SELECT ROWNUM ROW_NO, 
                                      t1.column_value.getStringVal() ROW_DATA
                                 FROM (SELECT * FROM TABLE (XMLSEQUENCE(cur_))) t1)    
                 LOOP                   
                     IF rec_1.ROW_NO>1 THEN
                         v_err_message := v_err_message || ',';
                     END IF;
                     v_err_message := v_err_message || '{';
                     v_ndx := 0;                    
                     FOR rec_2 IN (SELECT EXTRACTVALUE (t.COLUMN_VALUE, '/*') AS NODE_VALUE,
                                                        t.COLUMN_VALUE.getrootelement () AS NODE_NAME
                                     FROM TABLE (XMLSEQUENCE (EXTRACT(EXTRACT(XMLTYPE(rec_1.ROW_DATA), '//*'), '/ROW/*'))) t)
                     LOOP
                        IF v_ndx>0 THEN
                           v_err_message := v_err_message || ',';
                        END IF;
                        IF LOWER(rec_2.NODE_NAME) LIKE '%error%' THEN
                           v_err_found := TRUE;  
                        END IF;
                        v_err_message := v_err_message || '"' || LOWER(rec_2.NODE_NAME) || '":"' || REPLACE(REPLACE(TRIM(rec_2.NODE_VALUE),'"',''),CHR(10),'') || '"';
                        v_ndx := v_ndx + 1;                         
                     END LOOP;
                     v_err_message := v_err_message || '}';
                 END LOOP;   
                 v_err_message := v_err_message || ']';                 
                 CLOSE cur_;                                   
          END IF;
      
          IF v_smp_found THEN
               DBMS_OUTPUT.PUT_LINE(v_data_type||'1:'||var_);
               v_payload := v_payload || '", "data" : "';
               IF v_data_type IN ('VARCHAR2','CHAR') THEN
                   v_payload := v_payload || var_ || '"';
               END IF;
               IF v_data_type = 'NUMBER' THEN
                   v_payload := v_payload || TO_CHAR(num_) || '"';
               END IF;
               IF v_data_type = 'DATE' THEN
                   v_payload := v_payload || TO_CHAR(dat_,'DD/MM/YYYY') || '"';
               END IF;
               v_payload := v_payload || ', "detail" : []';
          ELSE 
              IF v_err_found THEN
                  Raise_Application_Error(-20200, 'Hata Olu�tu');
              ELSE 
                  IF NOT v_tbl_found THEN
                      v_err_message := '[]';
                  END IF;
                  IF v_data_found THEN
                      DBMS_OUTPUT.PUT_LINE(v_data_type||':'||var_); 
                      v_payload := v_payload || ', "data" :'||v_data_msg;
                      IF v_ndx>0 THEN                          
                          v_payload := v_payload || ', "detail" :'||v_err_message;
                      ELSE
                          v_payload := v_payload || ', "detail" : []';                             
                      END IF;
                  ELSE   
                      DBMS_OUTPUT.PUT_LINE(v_data_type||':'||var_);
                      v_payload := v_payload || ', "data" : []';   
                      IF v_ndx>0 THEN                                      
                          v_payload := v_payload || ', "detail" :'||v_err_message;
                      ELSE
                          Raise_Application_Error(-20200, 'Veri Bulunamad�');
                      END IF;                          
                  END IF;                
              END IF;
          END IF;          
          v_payload := v_payload || '}';
          p_out := v_payload;
       EXCEPTION 
       WHEN OTHERS THEN
           p_out := '{"status" : "FAIL", "data" : [], "detail" : ';
           IF NOT v_err_found  THEN
                --p_out := p_out || 'Alt Rutin Hata D�nd�", "data":[], "detail" : '||v_err_message;
           --ELSE
                v_err_message := '[{';
                v_err_message := v_err_message || '"process_no":"0",';
                v_err_message := v_err_message || '"severity":"0",';
                v_err_message := v_err_message || '"type":"-1",';
                v_err_message := v_err_message || '"code":"ORACLE_EXCEPTION",';   
                v_err_message := v_err_message || '"reason":"' || REPLACE(REPLACE(TRIM(dbms_utility.format_error_stack),'"',''),CHR(10),'') || '",';   
                v_err_message := v_err_message || '"action":"",';   
                v_err_message := v_err_message || '"key_value1":"'|| SQLCODE || '",';    
                v_err_message := v_err_message || '"key_value2":"' || REPLACE(REPLACE(TRIM(dbms_utility.format_error_backtrace),'"',''),CHR(10),'')|| '",';
                v_err_message := v_err_message || '"error_origin":"EXECUTE_SCRIPT"';               
                v_err_message := v_err_message || '}]';  
                --p_out := p_out || 'Hata Olu�tu", "data":[], "detail" : '||v_err_message;             
           END IF;           
           p_out := p_out || v_err_message || '}';
       END execute_script;
    BEGIN
       -- execute_script('{"service" : "ALZ_ACC_DEFINITION_UTILS.get_payment_types", "p_bank_instalment" : "NULL"}', v_status);
       -- execute_script('{"service" : "ALZ_TPA_UW_REJECT_UTILS.Tpa_Uw_Reject_Log_Query", "p_identity_no" : "67816057482", "p_quote_id" : "null", "p_first_name" : "null", "p_surname" : "null", "p_user" : "null"}', v_status);  
        --execute_script('{"service" : "ALZ_ACC_DEFINITION_UTILS.get_bank_cc_info_by_cc_no", "p_cc_no" : "427308"}', v_status);
        --execute_script('{"service" : "ALZ_AEN_UTILS.GET_VKN_TYPE","p_ref_no" : "TKN-00002906","p_vkn" : "NULL"}',v_status);
        --execute_script('{"service" : "ALZ_ACC_DEFINITION_UTILS.get_banks_by_instalment_no", "p_instalment_no" : "1"}', v_status);
        --execute_script('{"service" : "ALZ_TPA_CLAIM_UTILS.get_company_code_by_policy_ref", "p_policies" : [1,2]}', v_status); 
        --execute_script('{"service" : "KOC_CLM_UTILS.check_policy_exists", "p_policy_ref" : "1", "p_old_policy_no" : "2"}', v_status);
        --execute_script('{"service" : "check_ip_for_agency"}, "p_remoteAddress" : "", "p_reference_code" : "60000"}', v_status);
        --execute_script('{"service" : "find_round_digit", "p_swift_code" : "TL", "p_type" : "T"}', v_status);
        --execute_script('{"service" : "ALZ_TPA_CLOSE_MONTH_UTILS.get_company_premium", "p_company_code" : "100"}', v_status);
        --execute_script('{"service" : "ALZ_TPA_CORE_UTILS.f_get_company_fullname", "p_company_code" : "100"}', v_status);
       -- execute_script('{"service" : "KOC_CLM_UTILS.Return_Supplier_Accounts"}', v_status);
        execute_script('{"service" : "KOC_CLM_UTILS.INS_NAME_BUL", "p_claim_id" : "33539183"}', v_status);
        DBMS_OUTPUT.PUT_LINE(v_status);
       
    END;
    
