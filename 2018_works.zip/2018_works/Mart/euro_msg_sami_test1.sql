declare

    v_Payload CLOB;

    sgoper_admin_mail_body constant  varchar2(4000) := 'Sayin Kullanici;<br/>'

                                                   || 'Asagida detaylari belirtilen poli�elerin �st gruplar�n�n portal y�neticisi olusturulmamistir. L�tfen gerekli tanimlari yapiniz.<br/>';

  

    sgoper_admin_mail_subject constant varchar2(4000) := 'Admin Tanimi Eksik Gruplar';

    v_admin_count                  number;

    v_mail_content                 varchar2(32767);

    p_mail                         varchar2(32767);

    v_mail_to                      varchar2(100) := 'extern.adem-ozer@allianz.com.tr';

    v_counter                      number := 1;

    v_index                        number := 1;

    v_main_group_code              KOC_CP_GROUP_MASTER.MAIN_GROUP_CODE%TYPE;

    v_Mail_Input                   Customer.EuroMsg_Mail_Input_Rec;

    p_Response_Rec                 Customer.EuroMsg_Mail_Response_Table:=Customer.EuroMsg_Mail_Response_Table();

    v_String_Rec_to                customer.String_Table :=customer.String_Table();

    v_Email_Sent                   INT;

    p_process_results              process_result_table;
    
     Procedure Call_TPA_Service(p_Method            In          Varchar2,
                               p_Payload           In          Clob,
                               p_User              In          Varchar2,
                               p_Response_Rec      In Out      Customer.EuroMsg_Mail_Response_Table,
                               p_Process_Results   In Out      Customer.Process_Result_Table) Is

        ---v_URL               Varchar2(500) := get_url_link('http://esb.allianz.com.tr:12000/external/Tpa/rest/euroMessageService');
        v_URL               Varchar2(500) := get_url_link('http://esb.allianz.com.tr:12000/external/MessageService/rest/euroMessageService');

        v_Req               utl_http.req;
        v_Req_Length        Number;
        v_Res               utl_http.resp;

        v_Buffer            Varchar2(32767);
        v_Offset            Number := 1;
        v_Amount            Number :=32767;
        v_Utl_Err           Varchar2(1000);
        v_value             varchar2(4000);
        hata_code           varchar2(10);
        v_output            varchar2(10);
        v_Response_Rec      customer.EuroMsg_Mail_Response_Table :=customer.EuroMsg_Mail_Response_Table();
    Begin

        v_Req_Length := dbms_lob.getlength(p_Payload);

        v_Req := utl_http.begin_request(v_URL||'/'||p_Method, 'POST', 'HTTP/1.1');

        --utl_http.set_header(v_Req, 'Auth','Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJwbGF0Zm9ybSI6IkFMWl9UUEFEQiJ9.0yhHtB8X9taBuJ5h-8ZYmz7aVK7LnMiGhKr5tP6wXfY');
        utl_http.set_header(v_Req, 'Auth','Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJwbGF0Zm9ybSI6IkRCIn0.Vcq2uIMGOq3N8o9S-E-O93YuZ8qJVH0Or7tSfTxV_Qk');

        utl_http.set_header(v_Req, 'Content-Length', v_Req_Length);
        utl_http.set_header(v_Req, 'Content-Type', 'application/json;charset=UTF-8');
        utl_http.set_header (v_Req,'Transfer-Encoding', 'chunked' );
        utl_http.set_body_charset(v_Req,'UTF-8');

        While (v_Offset < v_Req_Length)
        Loop
           dbms_lob.read(p_Payload, v_Amount, v_Offset, v_Buffer);
           utl_http.write_text(r    => v_Req, data => v_Buffer);
             dbms_output.put_line('Buffer='||v_Buffer);
           v_Offset := v_Offset + v_Amount;
        End Loop;
      
        v_Res := utl_http.get_response(v_Req);
        Begin
           loop
              utl_http.read_line(v_Res, v_value);

              hata_code:=v_Res.status_code;

              Alz_EuroMsg_Utils.getcontenterr(v_value,
                            hata_code,
                            v_Response_Rec);

              p_Response_Rec:=v_Response_Rec;
           end loop;

              utl_http.end_response(v_Res);
        Exception
        When utl_http.end_of_body Then
             utl_http.end_response(v_Res);
        When utl_http.too_many_requests Then
             utl_http.end_response(v_Res);
        When Others Then
             utl_http.end_response(v_Res);
       End;

    exception when others then
    utl_http.end_response(v_Res);
    dbms_output.put_line('HataX');
    v_utl_err:= Utl_Http.Get_Detailed_Sqlerrm;
    alz_web_process_utils.process_result (0,
                                          9,
                                          -1,
                                          'INVOKE ERR',
                                          substr (sqlcode || ' - ' || sqlerrm || ' - ' || dbms_utility.format_error_backtrace, 1, 1000),
                                          v_utl_err,
                                          null,
                                          null,
                                          'Alz_Euromsg_Utils.Call_TPA_Service',
                                          p_User,
                                          p_process_results);

    End;


   begin

        p_process_results := process_result_table();

        v_mail_content    := sgoper_admin_mail_body;

        FOR rec_info in (SELECT distinct MAIN_GROUP_CODE

                         FROM   KOC_CP_GROUP_MASTER G

                         WHERE  G.VALIDITY_END_DATE IS NULL

                         AND    G.GROUP_CODE IN(SELECT a.child_group

                                                  FROM koc_cp_groups_of_agent a,

                                                       koc_dmt_agents_ext b

                                                WHERE b.int_id = a.agent_int_id

                                                   AND (NVL(b.mis_sub_group,'0') = '140' OR b.int_id = 12354)

                                                   AND EXISTS (SELECT 1

                                                                 FROM koc_mv_policies_asat c

                                                                WHERE c.product_id = 64

                                                                  AND c.group_code = a.child_group)

                                                   AND a.validity_start_date <= TRUNC(SYSDATE)

                                                   AND a.validity_end_date >= TRUNC(SYSDATE)))

        LOOP

            v_main_group_code := rec_info.Main_Group_Code;

            begin

                 SELECT count(*) into v_admin_count

                 FROM   ALZ_GHLTH_PORTAL_USER P,

                        ALZ_GHLTH_PORTAL_USER_REL PR

                 WHERE  P.USER_NAME = PR.USER_NAME

                 AND    P.VALIDITY_END_DATE IS NULL

                 AND    PR.VALIDITY_END_DATE IS NULL

                 AND    P.ACTION_CODE <> 'D'

                 AND    P.IS_ADMIN = 1

                 AND    PR.MAIN_GROUP_CODE = rec_info.MAIN_GROUP_CODE;

                

                 EXCEPTION WHEN NO_DATA_FOUND THEN

                     v_admin_count := 0;

            end;

             -- bu ust grup kodu icin hic admin tanimi yoksa sgoper e mail gonder.

             IF v_admin_count = 0 THEN

                v_counter := v_counter + 1;

                v_mail_content := v_mail_content || rec_info.MAIN_GROUP_CODE || ' - ' || ALZ_GHLTH_POLICY_UTILS7.get_main_group_name(rec_info.MAIN_GROUP_CODE) || '<br/>';
                -- v_mail_content := rec_info.MAIN_GROUP_CODE || ' - ' || ALZ_GHLTH_POLICY_UTILS7.get_main_group_name(rec_info.MAIN_GROUP_CODE) || '<br/>';
             END IF;

            

             IF v_counter = 29 THEN

                dbms_output.put_line('v_counter : ' || v_counter);

                p_mail := '<p><span>'|| v_mail_content ||'</span></p>';

               

                v_String_Rec_to.extend;

                v_String_Rec_to(1) := String_Rec(v_mail_to);

                   

                v_Mail_Input := customer.EuroMsg_Mail_Input_Rec (null,

                                                                 'Template',

                                                                 null,

                                                                 v_String_Rec_to,

                                                                 null,

                                                                 null,

                                                                 sgoper_admin_mail_subject || '-' || v_index,

                                                                 p_mail,

                                                                 'GROUP_PORTAL_MAIL',

                                                                 null, --v_Report_Parameters,

                                                                 '045',

                                                                 'grupsaglikuretimyeniisyenileme - ' || rec_info.MAIN_GROUP_CODE,

                                                                 null);

                v_Payload := Alz_euromsg_utils.Convert_Mail_Input_To_Payload(v_Mail_Input);

                dbms_output.put_line('payload : ' || v_Payload);
                dbms_output.put_line('p mail : ' || p_mail);
                dbms_output.put_line('p mail len : ' || length(p_mail));
                  
               
               /* Alz_euromsg_utils.Send_Mail(v_Mail_Input,

                                            'GROUP_PORTAL_MAIL',

                                            p_Response_Rec,

                                            p_process_results);*/
                                            
                 -- v_Payload := Convert_Mail_Input_To_Payload(v_Mail_Input);
        Call_TPA_Service('sendMail',
                         v_Payload,
                         USER,
                         p_Response_Rec,
                         p_Process_Results);                                            

                                              

                v_Email_Sent := 0;

 

                FOR i IN 1 .. p_Response_Rec.COUNT

                LOOP

                     If  v_Email_Sent = 0

                         and p_Response_Rec(i).Hata_Code = '200'

                         and lower(p_Response_Rec(i).Response_Name) = 'code'

                         and p_Response_Rec(i).Response_Value = '0' then

                     --Mail G�nderimi ba�ar�l�

                     v_Email_Sent := 1;

                 End if;

                END LOOP;

               

                v_index := v_index + 1;

                v_counter := 0;

                v_mail_content := sgoper_admin_mail_body;

             END IF;

        END LOOP;

        /*IF v_counter < 29 and v_counter > 0 THEN

             dbms_output.put_line('v_counter : ' || v_counter);

             p_mail := '<p><span><p>'|| v_mail_content ||'</p></span></p>';

            

             dbms_output.put_line('mail content : ' || v_mail_content);          

             v_String_Rec_to.extend;

             v_String_Rec_to(1) := String_Rec(v_mail_to);

                   

             v_Mail_Input := customer.EuroMsg_Mail_Input_Rec (null,

                                                             'Template',

                                                             null,

                                                             v_String_Rec_to,

                                                             null,

                                                             null,

                                                             sgoper_admin_mail_subject || '-' || v_index,

                                                             p_mail,

                                                             'GROUP_PORTAL_MAIL',

                                                             null, --v_Report_Parameters,

                                                             '045',

                                                             'grupsaglikuretimyeniisyenileme - ' || v_main_group_code,

                                                             null);

                                                             

             v_Payload := Alz_euromsg_utils.Convert_Mail_Input_To_Payload(v_Mail_Input);

             dbms_output.put_line('payload : ' || v_Payload);

             dbms_output.put_line('p mail len : ' || length(p_mail));

            

             Alz_euromsg_utils.Send_Mail(v_Mail_Input,

                                         'GROUP_PORTAL_MAIL',

                                         p_Response_Rec,

                                         p_Process_Results);

                                        

             dbms_output.put_line('sami 3');*/

            

             FOR rec IN (SELECT * FROM TABLE(p_Process_Results)) LOOP

                   dbms_output.put_line(rec.REASON||'-'||rec.KEY_VALUE1||'-'||rec.ERROR_ORIGIN);

             END LOOP;

                

             v_Email_Sent := 0;

 

             FOR i IN 1 .. p_Response_Rec.COUNT

             LOOP

                 dbms_output.put_line('response name : ' || p_Response_Rec(i).Response_Name);

                 If  v_Email_Sent = 0

                     and p_Response_Rec(i).Hata_Code = '200'

                     and lower(p_Response_Rec(i).Response_Name) = 'code'

                     and p_Response_Rec(i).Response_Value = '0' then

                   --Mail G�nderimi ba�ar�l�

                   v_Email_Sent := 1;

                 End if;

             END LOOP;

        --END IF;

        dbms_output.put_line('mail gonderiminden sonra, email_sent : ' || v_Email_Sent);

        exception when others then

            alz_web_process_utils.process_result (0,

                                                  9,

                                                  -1,

                                                  'EXCEPTION',

                                                  substr (sqlcode||' - '||sqlerrm||' - '||dbms_utility.format_error_backtrace, 1, 1000),

                                                  null,

                                                  null,

                                                  null,

                                                  'alz_ghlth_policy_utils7.send_mail_to_sgoper_4_admin',

                                                  'GHLTH_PORTAL',

                                                  p_process_results);

   end;
