 DECLARE 
   v_prc_name VARCHAR2(100) := UPPER('get_partition_list');  
   v_pkg_name VARCHAR2(100) := 'ALZ_ACC_DEFINITION_UTILS';
   v_arg_name VARCHAR2(100);
   v_data_type  VARCHAR2(100);
   v_smp_type   VARCHAR2(100); 
   v_cur_type   VARCHAR2(100); 
   v_tbl_type  VARCHAR2(100); 
   v_cur_found  BOOLEAN := FALSE;
   v_tbl_found  BOOLEAN := FALSE;
   v_smp_found  BOOLEAN := FALSE; 
   v_arg_count  NUMBER := 0;
   v_type       NUMBER := 0;
   v_err        VARCHAR2(1000);
   v_arg_found  BOOLEAN := FALSE;
 BEGIN
   
  FOR rec IN (
          select ARGUMENT_NAME, DATA_TYPE, IN_OUT 
            from all_arguments 
           where object_name= v_prc_name
             AND PACKAGE_NAME = v_pkg_name
             AND IN_OUT != 'IN'
             AND ARGUMENT_NAME IS NOT NULL)
    LOOP
        IF rec.Data_Type = 'REF CURSOR' AND NOT v_cur_found THEN
            v_cur_found := TRUE;
            v_cur_type := rec.In_Out;
            v_arg_count := v_arg_count + 1;
        ELSIF rec.Data_Type = 'TABLE' AND NOT v_tbl_found THEN
            v_tbl_found := TRUE;
            v_tbl_type := rec.In_Out;
            v_arg_count := v_arg_count + 1;
        ELSIF rec.Data_Type IN ('NUMBER', 'VARCHAR2', 'DATE') THEN
            v_smp_found := TRUE;
            v_data_type := rec.Data_Type;
            v_smp_type  := rec.In_Out;
            v_arg_count := v_arg_count + 1;               
        END IF;
        v_arg_found := TRUE;               
    END LOOP;
    IF v_arg_found THEN
        IF v_cur_found THEN
           IF v_tbl_found THEN
               IF v_arg_count != 2 THEN              
                   Raise_Application_Error(-20200, 'Bir Adet Curs�r  ve Table Olabilir');
               END IF;
               v_type := 0 ; -- cursor and table
           ELSE 
               IF v_arg_count != 1 THEN
                   Raise_Application_Error(-20200, 'Bir Adet Curs�r Olabilir');
               END IF;
               v_type := 1; --cursor only
           END IF;   
        ELSE
           IF v_tbl_found THEN
               IF v_arg_count != 1 THEN
                   Raise_Application_Error(-20200, 'Bir Adet Table Olabilir');
               END IF;
               v_type := 2; -- table only
           ELSE 
               IF v_smp_found THEN
                   IF v_arg_count != 1 THEN
                       Raise_Application_Error(-20200, 'Bir Adet Simple Type Olabilir');
                   END IF;
                   v_type := 3; --simple only
               ELSE 
                   v_type := 4; -- no available out param
               END IF;
           END IF;
        END IF;
    ELSE
        v_type := 4; -- no out param
    END IF;
    DBMS_OUTPUT.PUT_LINE('Type='||v_type||' Data Type = '||v_data_type);   
   EXCEPTION WHEN OTHERS THEN
     
       v_err := SUBSTR(SQLERRM,1,200);
       DBMS_OUTPUT.PUT_LINE(v_err);
  END;
     
          
