DECLARE 
           cur_ SYS_REFCURSOR; 
         
             
         /* CURSOR get_columns IS  
              SELECT ROWNUM ROW_NO, 
                     t1.column_value.getStringVal() ROW_DATA--, 
              --t2.column_value.getrootelement() name, 
              --EXTRACTVALUE(t2.column_value, '/node()')  VALUE 
             FROM (SELECT * FROM TABLE (XMLSEQUENCE(cur_))) t1;--, 
               --TABLE (XMLSEQUENCE(EXTRACT(t1.column_value, '/ROW/node()'))) t2; */
           v_payload VARCHAR2(32000);
           v_ndx NUMBER;
        BEGIN 
           OPEN cur_ FOR 'SELECT COMPANY_CODE, TITLE,SHORT_NAME FROM ALZ_TPA_COMPANIES'; 
           v_payload := '{"data" : [';
           FOR rec_1 IN (SELECT ROWNUM ROW_NO, 
                                t1.column_value.getStringVal() ROW_DATA
                           FROM (SELECT * FROM TABLE (XMLSEQUENCE(cur_))) t1)    
           LOOP 
               --DBMS_OUTPUT.put_line(rec_.id_value||':'||rec_.name || ': ' || rec_.VALUE); 
               --DBMS_OUTPUT.put_line(rec_1.ROW_NO||'-'||rec_1.ROW_DATA); 
               IF rec_1.ROW_NO>1 THEN
                   v_payload := v_payload || ',';
               END IF;
               v_payload := v_payload || '{';
               v_ndx := 0;
               FOR rec_2 IN (SELECT EXTRACTVALUE (t.COLUMN_VALUE, '/*') AS NODE_VALUE,
                                                  t.COLUMN_VALUE.getrootelement () AS NODE_NAME
                               FROM TABLE (XMLSEQUENCE (EXTRACT(EXTRACT(XMLTYPE(rec_1.ROW_DATA), '//*'), '/ROW/*'))) t)
               LOOP
                  IF v_ndx>0 THEN
                     v_payload := v_payload || ',';
                  END IF;
                  v_payload := v_payload || '"' || LOWER(rec_2.NODE_NAME) || '":"' || TRIM(rec_2.Node_Value) || '"';
                  v_ndx := v_ndx + 1;
                     --DBMS_OUTPUT.put_line(rec_2.NODE_NAME || ' - ' || rec_2.NODE_VALUE); 
               END LOOP;
               v_payload := v_payload || '}';
           END LOOP;   
           v_payload := v_payload || ']}';
           
           DBMS_OUTPUT.PUT_LINE(v_payload);
        END;
