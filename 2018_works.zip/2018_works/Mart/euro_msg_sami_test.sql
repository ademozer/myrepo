DECLARE
  v_Payload CLOB;
  p_Response_Rec                 Customer.EuroMsg_Mail_Response_Table:=Customer.EuroMsg_Mail_Response_Table();
  p_process_results              process_result_table;
  Procedure Call_TPA_Service(p_Method            In          Varchar2,
                               p_Payload           In          Clob,
                               p_User              In          Varchar2,
                               p_Response_Rec      In Out      Customer.EuroMsg_Mail_Response_Table,
                               p_Process_Results   In Out      Customer.Process_Result_Table) Is

        ---v_URL               Varchar2(500) := get_url_link('http://esb.allianz.com.tr:12000/external/Tpa/rest/euroMessageService');
        v_URL               Varchar2(500) := get_url_link('http://esb.allianz.com.tr:12000/external/MessageService/rest/euroMessageService');

        v_Req               utl_http.req;
        v_Req_Length        Number;
        v_Res               utl_http.resp;

        v_Buffer            Varchar2(32767);
        v_Offset            Number := 1;
        v_Amount            Number :=32767;
        v_Utl_Err           Varchar2(1000);
        v_value             varchar2(32767);
        hata_code           varchar2(10);
        v_output            varchar2(10);
        v_Response_Rec      customer.EuroMsg_Mail_Response_Table :=customer.EuroMsg_Mail_Response_Table();
    Begin

        v_Req_Length := dbms_lob.getlength(p_Payload);

        v_Req := utl_http.begin_request(v_URL||'/'||p_Method, 'POST', 'HTTP/1.1');

        --utl_http.set_header(v_Req, 'Auth','Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJwbGF0Zm9ybSI6IkFMWl9UUEFEQiJ9.0yhHtB8X9taBuJ5h-8ZYmz7aVK7LnMiGhKr5tP6wXfY');
        utl_http.set_header(v_Req, 'Auth','Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJwbGF0Zm9ybSI6IkRCIn0.Vcq2uIMGOq3N8o9S-E-O93YuZ8qJVH0Or7tSfTxV_Qk');

        utl_http.set_header(v_Req, 'Content-Length', v_Req_Length);
        utl_http.set_header(v_Req, 'Content-Type', 'application/json;charset=UTF-8');
        utl_http.set_header (v_Req,'Transfer-Encoding', 'chunked' );
        utl_http.set_body_charset(v_Req,'UTF-8');

        While (v_Offset < v_Req_Length)
        Loop
           dbms_lob.read(p_Payload, v_Amount, v_Offset, v_Buffer);
           utl_http.write_text(r    => v_Req, data => v_Buffer);
             dbms_output.put_line('Buffer='||v_Buffer);
           v_Offset := v_Offset + v_Amount;
        End Loop;
      
        v_Res := utl_http.get_response(v_Req);
        Begin
           loop
              utl_http.read_line(v_Res, v_value);
             
              hata_code:=v_Res.status_code;

              Alz_EuroMsg_Utils.getcontenterr(v_value,
                            hata_code,
                            v_Response_Rec);

              p_Response_Rec:=v_Response_Rec;
              dbms_output.put_line('Res_Value:'||v_value);   
           end loop;

              utl_http.end_response(v_Res);
              
        Exception
        When utl_http.end_of_body Then
             utl_http.end_response(v_Res);
              dbms_output.put_line('Hata3:'||SUBSTR(SQLERRM,1,200));   
        When utl_http.too_many_requests Then
             utl_http.end_response(v_Res);
              dbms_output.put_line('Hata2:'||SUBSTR(SQLERRM,1,200));   
        When Others Then              
             utl_http.end_response(v_Res);
             dbms_output.put_line('Hata1:'||SUBSTR(SQLERRM,1,200));   
       End;

    exception when others then
    utl_http.end_response(v_Res);
    dbms_output.put_line('HataX');
    v_utl_err:= Utl_Http.Get_Detailed_Sqlerrm;
    alz_web_process_utils.process_result (0,
                                          9,
                                          -1,
                                          'INVOKE ERR',
                                          substr (sqlcode || ' - ' || sqlerrm || ' - ' || dbms_utility.format_error_backtrace, 1, 1000),
                                          v_utl_err,
                                          null,
                                          null,
                                          'Alz_Euromsg_Utils.Call_TPA_Service',
                                          p_User,
                                          p_process_results);

    End;
    
    BEGIN
      
     -- v_Payload := '{"templateName":"Template","toList":["extern.adem-ozer@allianz.com.tr"],"subject":"Admin Tanimi Eksik Gruplar-1","body":"<p><span>Sayin Kullanici;<br/>Asagida detaylari belirtilen poli�elerin �st gruplar�n�n portal y�neticisi olusturulmamistir. L�tfen gerekli tanimlari yapiniz.<br/>S9397 - ING BANK A.�.<br/>S9539 - TURKISH BANK A.�.<br/>S7700 - KRM Y�NET�M DANI�MANLIK A.�.<br/>S9543 - TAN S�GORTA ARACILIK H�Z. A.�.<br/>S5001 - KO� HOLD�NG EMEKL� VE YARDIM SANDI�I VAKFI<br/>S6880 - ALLIANZ S�GORTA/ALLIANZ YA�AM/ALLIANZ HAYAT/BEYKOZ GAYR�MENKUL-L�M�TL�<br/>S9535 - SA�LIK VE E��T�M VAKFI<br/>S9376 - ABBVIE TIBB� �LA�LAR SAN.VE T�C.LTD.�T�.<br/>S13091 - SOCAR TURKEY AKARYAKIT DEPOLAMA A.�.<br/>S5820 - YILDIZ ME�RUBAT PAZ. SAN. VE T�C. LTD. �T�.<br/>S1424 - ALK�M ALKAL� K�MYA A.�.<br/>S1815 - SEL�UK ECZA DEPOSU T�C.VE SAN.A.�.<br/>S1788 - DHL WORLDWIDE EXPRESS TA�IMACILIK VE T�C. A.�.<br/>S11783 - HOYA TURKEY OPT�K LENS SANAY� VE T�CARET A.�.<br/>S9734 - ATOS B�L���M DAN. VE M��. H�ZM. SAN. VE T�C. A.�.1<br/>S12284 - MSH INTERNATIONAL ( DUBAI) LTD.  <br/>S12381 - PRUVA TURIZM GIDA ITH.IHR.INS.SAN.VETIC.LTD.STI.<br/>S9716 - AKTAES DA�ITIM VE PAZARLAMA A.�.<br/>S9506 - �TALYAN T�CARET ODASI DERNE��<br/>S12888 - MARS LOJISTIK ULUS.TAS.DEP.DAG.VE TIC AS.<br/>S4985 - ACCENTURE END�STR�YEL YAZILIM��Z�MLER� LTD.�T�<br/>S10041 - �ZEL NOTRE DAME DE S�ON FRANSIZ L�SES�<br/>S9714 - ECZACIBA�I SPOR KUL�B� DERNE��<br/>S9507 - COCA COLA ��ECEK A.�.<br/>S4909 - T.C. YED�TEPE �N�VERS�TES�<br/>S9396 - METLIFE EMEKL�L�K VE HAYAT A.�.<br/>S12485 - MONDIAL MEDICAL CARE ASSOCIATION<br/>S12180 - SE�KO OPT�CAL EUROPE GMBH MERKEZ� ALMANYA �STANBUL MERKEZ �UBES�<br/></span></p>","applicationName":"GROUP_PORTAL_MAIL","companyCode":"045","clientKey":"grupsaglikuretimyeniisyenileme - S12180"}';
     --v_Payload := '{"templateName":"Template","toList":["extern.adem-ozer@allianz.com.tr"],"subject":"Admin Tanimi Eksik Gruplar-1","body":"<p><span>Sayin Kullanici;<br/>Asagida detaylari belirtilen poli�elerin �st gruplar�n�n portal y�neticisi olusturulmamistir. L�tfen gerekli tanimlari yapiniz.<br/>S9397 - ING BANK A.�.<br/>S9539 - TURKISH BANK A.�.<br/>S7700 - KRM Y�NET�M DANI�MANLIK A.�.<br/>S9543 - TAN S�GORTA ARACILIK H�Z. A.�.<br/>S5001 - KO� HOLD�NG EMEKL� VE YARDIM SANDI�I VAKFI<br/>S6880 - ALLIANZ S�GORTA/ALLIANZ YA�AM/ALLIANZ HAYAT/BEYKOZ GAYR�MENKUL-L�M�TL�<br/>S9535 - SA�LIK VE E��T�M VAKFI<br/>S9376 - ABBVIE TIBB� �LA�LAR SAN.VE T�C.LTD.�T�.<br/>S13091 - SOCAR TURKEY AKARYAKIT DEPOLAMA A.�.<br/>S5820 - YILDIZ ME�RUBAT PAZ. SAN. VE T�C. LTD. �T�.<br/>S1424 - ALK�M ALKAL� K�MYA A.�.<br/>S1815 - SEL�UK ECZA DEPOSU T�C.VE SAN.A.�.<br/>S11783 - HOYA TURKEY OPT�K LENS SANAY� VE T�CARET A.�.<br/>S12284 - MSH INTERNATIONAL ( DUBAI) LTD.	<br/>S1788 - DHL WORLDWIDE EXPRESS TA�IMACILIK VE T�C. A.�.<br/>S9734 - ATOS B�L���M DAN. VE M��. H�ZM. SAN. VE T�C. A.�.1<br/>S12381 - PRUVA TURIZM GIDA ITH.IHR.INS.SAN.VETIC.LTD.STI.<br/>S9716 - AKTAES DA�ITIM VE PAZARLAMA A.�.<br/>S9506 - �TALYAN T�CARET ODASI DERNE��<br/>S12888 - MARS LOJISTIK ULUS.TAS.DEP.DAG.VE TIC AS.<br/>S4985 - ACCENTURE END�STR�YEL YAZILIM��Z�MLER� LTD.�T�<br/>S10041 - �ZEL NOTRE DAME DE S�ON FRANSIZ L�SES�<br/>S9714 - ECZACIBA�I SPOR KUL�B� DERNE��<br/>S9507 - COCA COLA ��ECEK A.�.<br/>S4909 - T.C. YED�TEPE �N�VERS�TES�<br/>S9396 - METLIFE EMEKL�L�K VE HAYAT A.�.<br/>S12180 - SE�KO OPT�CAL EUROPE GMBH MERKEZ� ALMANYA �STANBUL MERKEZ �UBES�<br/>S12485 - MONDIAL MEDICAL CARE ASSOCIATION<br/></span></p>","applicationName":"GROUP_PORTAL_MAIL","companyCode":"045","clientKey":"grupsaglikuretimyeniisyenileme - S12485"}';
     /*  v_Payload := '{
   "templateName": "Template",
   "toList": ["extern.adem-ozer@allianz.com.tr"],
   "subject": "Admin Tanimi Eksik Gruplar-1",
   "body": "<p><span>Sayin Kullanici;<br/>Asagida detaylari belirtilen poli�elerin �st gruplar�n�n portal y�neticisi olusturulmamistir. L�tfen gerekli tanimlari yapiniz.<br/>S9397 - ING BANK A.�.<br/>S9539 - TURKISH BANK A.�.<br/>S7700 - KRM Y�NET�M DANI�MANLIK A.�.<br/>S9543 - TAN S�GORTA ARACILIK H�Z. A.�.<br/>S5001 - KO� HOLD�NG EMEKL� VE YARDIM SANDI�I VAKFI<br/>S6880 - ALLIANZ S�GORTA/ALLIANZ YA�AM/ALLIANZ HAYAT/BEYKOZ GAYR�MENKUL-L�M�TL�<br/>S9535 - SA�LIK VE E��T�M VAKFI<br/>S9376 - ABBVIE TIBB� �LA�LAR SAN.VE T�C.LTD.�T�.<br/>S13091 - SOCAR TURKEY AKARYAKIT DEPOLAMA A.�.<br/>S5820 - YILDIZ ME�RUBAT PAZ. SAN. VE T�C. LTD. �T�.<br/>S1424 - ALK�M ALKAL� K�MYA A.�.<br/>S1815 - SEL�UK ECZA DEPOSU T�C.VE SAN.A.�.<br/>S11783 - HOYA TURKEY OPT�K LENS SANAY� VE T�CARET A.�.<br/>S12284 - MSH INTERNATIONAL ( DUBAI) LTD.\t<br/>S1788 - DHL WORLDWIDE EXPRESS TA�IMACILIK VE T�C. A.�.<br/>S9734 - ATOS B�L���M DAN. VE M��. H�ZM. SAN. VE T�C. A.�.1<br/>S12381 - PRUVA TURIZM GIDA ITH.IHR.INS.SAN.VETIC.LTD.STI.<br/>S9716 - AKTAES DA�ITIM VE PAZARLAMA A.�.<br/>S9506 - �TALYAN T�CARET ODASI DERNE��<br/>S12888 - MARS LOJISTIK ULUS.TAS.DEP.DAG.VE TIC AS.<br/>S4985 - ACCENTURE END�STR�YEL YAZILIM��Z�MLER� LTD.�T�<br/>S10041 - �ZEL NOTRE DAME DE S�ON FRANSIZ L�SES�<br/>S9714 - ECZACIBA�I SPOR KUL�B� DERNE��<br/>S9507 - COCA COLA ��ECEK A.�.<br/>S4909 - T.C. YED�TEPE �N�VERS�TES�<br/>S9396 - METLIFE EMEKL�L�K VE HAYAT A.�.<br/>S12180 - SE�KO OPT�CAL EUROPE GMBH MERKEZ� ALMANYA �STANBUL MERKEZ �UBES�<br/>S12485 - MONDIAL MEDICAL CARE ASSOCIATION</span></p>",
   "applicationName": "GROUP_PORTAL_MAIL",
   "companyCode": "045",
   "clientKey": "grupsaglikuretimyeniisyenileme - S12485"
}';*/
/*v_Payload := '{
   "templateName": "Template",
   "toList": [
      "extern.adem-ozer@allianz.com.tr"
   ],
   "subject": "Admin Tanimi Eksik Gruplar-1",
   "body": "S12284 - MSH INTERNATIONAL ( DUBAI) LTD.	<br/>S1788 - DHL WORLDWIDE EXPRESS TA�IMACILIK VE T�C. A.�.<br/>S9734 - ATOS B�L���M DAN. VE M��. H�ZM. SAN. VE T�C. A.�.1<br/>S12381 - PRUVA TURIZM GIDA ITH.IHR.INS.SAN.VETIC.LTD.STI.<br/>S9716 - AKTAES DA�ITIM VE PAZARLAMA A.�.<br/>S9506 - �TALYAN T�CARET ODASI DERNE��<br/>S12888 - MARS LOJISTIK ULUS.TAS.DEP.DAG.VE TIC AS.<br/>S4985 - ACCENTURE END�STR�YEL YAZILIM��Z�MLER� LTD.�T�<br/>S10041 - �ZEL NOTRE DAME DE S�ON FRANSIZ L�SES�<br/>S9714 - ECZACIBA�I SPOR KUL�B� DERNE��<br/>S9507 - COCA COLA ��ECEK A.�.<br/>S4909 - T.C. YED�TEPE �N�VERS�TES�<br/>S9396 - METLIFE EMEKL�L�K VE HAYAT A.�.<br/>S12180 - SE�KO OPT�CAL EUROPE GMBH MERKEZ� ALMANYA �STANBUL MERKEZ �UBES�<br/>S12485 - MONDIAL MEDICAL CARE ASSOCIATION",
   "applicationName": "GROUP_PORTAL_MAIL",
   "companyCode": "045",
   "clientKey": "grupsaglikuretimyeniisyenileme - S12485"
}';*/
--v_Payload := '{"toList":["extern.adem-ozer@allianz.com.tr"],"ccList":["extern.ali-sakalli@allianz.com.tr"],"bccList":["extern.adem-ozer@allianz.com.tr"],"subject":"Bireysel Sa�l�k Poli�e Ba�vurunuz Hakk�nda - 341009614 (TEST)","body":"Sn. �A�LA PEL�N KIZGIN,<br/><br/>�irketimiz''de sigortalanmak �zere yapm�� oldu�unuz Bireysel Sa�l�k Poli�e ba�vurunuzun kabul edilemedi�ini �z�lerek bildirir sa�l�kl� g�nler dileriz.<br/>Detaylar i�in sat�� kanal�n�zla g�r��ebilirsiniz.<br/><br/>Sayg�lar�m�zla<br/>Fiba Emeklilik<br/><br/> ** Bu e-posta <b>TEST</b> ama�l� at�lm��t�r. L�tfen dikkate <b>almay�n�z</b>. **","reportList":[{"fileLang":"TR","fileParamForHandleException":"quote","fileName":"Basvuru.PDF","reportName":"KOCREPOCP432","reportParameters":[{"name":"P_CONTRACT_ID","value":"341009614"},{"name":"P_KIME","value":"INS"}],"contentType":"application/pdf"}],"companyCode":"100","clientKey":"OBF_RED_341009614","parameterMap":{"EM_EMAIL_OTHER":"true","EM_SMS_OTHER":"true"}}';
--v_Payload := '{"toList":["extern.adem.ozer@allianz.com.tr"],"subject":"Bireysel Sa�l�k Poli�e Ba�vurunuz Hakk�nda - 380606516 (TEST)","body":"    Sn. �ZAY �ZDEM�R,<br/><br/>�irketimiz''de sigortalanmak �zere yapm�� oldu�unuz Bireysel Sa�l�k Poli�e ba�vurunuzun kabul edilemedi�ini �z�lerek bildirir sa�l�kl� g�nler dileriz.<br/>Detaylar i�in sat�� kanal�n�zla g�r��ebilirsiniz.<br/><br/>Sayg�lar�m�zla<br/>Fiba Emeklilik Ve Hayat A.�.<br/><br/> ** Bu e-posta <b>TEST</b> ama�l� at�lm��t�r. L�tfen dikkate <b>almay�n�z</b>. **","reportList":[{"fileLang":"TR","fileParamForHandleException":"quote","fileName":"Basvuru.PDF","reportName":"KOCREPOCP432","reportParameters":[{"name":"P_CONTRACT_ID","value":"380606516"},{"name":"P_FAMILY_CODE","value":"1"},{"name":"P_AY_TIPI","value":"T024"},{"name":"P_GROUP_CODE","value":""},{"name":"P_TIP","value":"T024"},{"name":"P_OBF_NO","value":"FO2822592"},{"name":"P_USER_NAME","value":"ALLZWEBPOL"},{"name":"P_USER","value":"AL"},{"name":"P_USER2","value":"ALLZWEBPOL"},{"name":"P_DEPARTMAN","value":"1"},{"name":"P_DATE","value":"13-04-2018"},{"name":"P_USER_TYPE","value":"SFOPER"},{"name":"P_DEPARTMANT_CODE","value":"5310"},{"name":"P_INSERT","value":"0"},{"name":"BACKGROUND","value":"YES"},{"name":"COPIES","value":"1"},{"name":"MODE","value":"BITMAP"},{"name":"BATCH","value":"YES"},{"name":"PARAMFORM","value":"NO"},{"name":"P_PARTITION_NO","value":"2"},{"name":"P_TITLE","value":"0"},{"name":"P_RAPOR_ID","value":"45864"},{"name":"P_KIME","value":"INS"}],"contentType":"application/pdf"}],"companyCode":"045","clientKey":"OBF_RED_380606516","parameterMap":{"EM_EMAIL_OTHER":"true"}}';
v_Payload := '{"toList":["extern.adem.ozer@allianz.com.tr"],"subject":"test","body":"deneme","companyCode":"100","clientKey":"OBF_RED_380606517","parameterMap":{"EM_EMAIL_OTHER":"true"}}';
v_Payload := regexp_replace(v_Payload, '([^[:graph:] | ^[:blank:]])', ''); 
  --v_Payload := REPLACE(v_Payload,CHR(9),' ');
      Alz_Euromsg_Utils.Call_TPA_Service('sendMail',
                         v_Payload,
                         USER,
                         p_Response_Rec,
                         p_Process_Results);   
       FOR rec IN (SELECT Hata_Code,Response_Name, Response_Value FROM TABLE(p_Response_Rec)) LOOP
         DBMS_OUTPUT.PUT_LINE('resp='||rec.Hata_Code||'-'||rec.Response_Name||'-'||rec.Response_Value);
       END LOOP;                   
       FOR rec IN (SELECT * FROM TABLE(p_Process_Results)) LOOP
              dbms_output.put_line(rec.REASON||'-'||rec.KEY_VALUE1||'-'||rec.ERROR_ORIGIN);
       END LOOP;
     EXCEPTION WHEN OTHERS THEN
           dbms_output.put_line('Hata:'||SUBSTR(SQLERRM,1,200));      
     END;
                         
