DECLARE

   v_email  koc_smtp_wa_util.par_list;
   v_String_Rec_Bcc  customer.String_Table := customer.String_Table();
      
BEGIN
    v_String_Rec_Bcc.EXTEND;
    v_String_Rec_Bcc(v_String_Rec_Bcc.COUNT) := String_Rec('extern.adem-ozer@allianz.com.tr');
        
    v_email := alz_tpa_hlth_policy_utils.get_emails ('045', 'REJECT_MAIL', 'N', 'N');
    
    
    FOR ndx IN 1 .. v_email.v_bcc.COUNT LOOP
        v_String_Rec_Bcc.EXTEND;
        v_String_Rec_Bcc(v_String_Rec_Bcc.COUNT) := String_Rec(v_email.v_bcc(ndx));
    END LOOP;
          
    FOR rec IN (SELECT * FROM TABLE(v_String_Rec_Bcc)) LOOP
       DBMS_OUTPUT.PUT_LINE(rec.str);
    END LOOP;
   
END;


