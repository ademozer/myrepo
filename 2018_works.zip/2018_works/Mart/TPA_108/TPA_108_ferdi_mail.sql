DECLARE
 --mail parametreleri
   L_TOMAIL          VARCHAR2 (500);
   L_CCMAIL          VARCHAR2 (500);
   L_TO_XML          VARCHAR2 (500);      
   L_CC_XML          VARCHAR2 (500);
   L_BCC_XML         VARCHAR2 (500);
   L_SUBJECT         VARCHAR2 (500);
   SERVIS            VARCHAR2 (30);
   L_BODY            VARCHAR2 (32000);
   L_RAPOR_XML       VARCHAR2 (32767);
   L_SUB_RAPOR_XML   VARCHAR2 (32767);
   HOST              VARCHAR2 (30000)
      := GET_URL_LINK (
            'http://esb.allianz.com.tr:12000/MailSenderService?wsdl');
   HOST_EUR          VARCHAR2 (1000)
      := GET_URL_LINK (
            'http://batchesb.allianz.com.tr:12000/EuroMessageReportSender/EuroMessageReportSenderProxy?wsdl');
   HTTP_REQ          UTL_HTTP.REQ;
   HTTP_RESP         UTL_HTTP.RESP;
   SOAP_REQUEST      VARCHAR2 (32767);
   SOAP_RESPOND      VARCHAR2 (32767);
   V_ERROR           VARCHAR2 (32767);
   V_DB              VARCHAR2 (100);


   L_PARTITION_TYPE  VARCHAR2(100);
   L_PARTITION_NAME  VARCHAR2(1000);
   
  PROCEDURE P_FERDI_SAGLIK_AUTH_RED_MAIL (
      PCONTRACT_ID    IN NUMBER,
      PVERSION_NO     IN NUMBER,
      PQUOTE_STATUS   IN VARCHAR2,
      PPARTITION_NO   IN NUMBER DEFAULT NULL,
      PAPP_CODE       IN VARCHAR2,
      P_SMS_FLAG      IN NUMBER DEFAULT NULL)
   IS
      -- Mail i�eri�i i�in gerekli datalar --

      V_AGENCY_ADDRESS               VARCHAR2 (200);
      N_AGENT_ROLE                   NUMBER;
      D_DUMMY                        DATE;
      N_PARTITION_NO                 NUMBER;
      V_SMS_EXP                      VARCHAR2 (1000);
      V_SIG_BODY                     VARCHAR2 (1000);
      V_SMS_CONTENT                  VARCHAR2 (1000);
      V_DEPARTMAN                    VARCHAR2 (50);
      V_ACENTE_EMAIL                 VARCHAR2 (100);
      V_REPORT_NAME                  VARCHAR2 (50);
      B_INS_EMAIL_GONDERILDI         BOOLEAN;
      B_SMS_GONDERILDI               BOOLEAN;
      B_EMAIL_GONDERILDI             BOOLEAN;
      V_SMS_RESPONSE                 VARCHAR2 (30);
      V_SMS_RESULT                   VARCHAR2 (30);
      V_DB                           VARCHAR2 (50);
      N_RAPOR_ID                     NUMBER;
      D_SYSDATE                      DATE;
      V_PARTITION_TYPE               VARCHAR2 (50);
      V_PARTITION_NAME               VARCHAR2 (100);
      --[ademo.TPA-108 12.03.2018
      V_PARTITION_NAME_TEXT          VARCHAR2 (100); 
      V_TPA_COMPANY_CODE             ALZ_TPA_COMPANIES.COMPANY_CODE%TYPE;
      V_TPA_COMPANY_NAME             ALZ_TPA_COMPANIES.SHORT_NAME%TYPE; 
      V_MUHATAP                      VARCHAR2 (100);
      v_email           koc_smtp_wa_util.par_list;
      v_String_Rec_To   customer.String_Table := Customer.String_Table(); 
      v_String_Rec_Cc   customer.String_Table := Customer.String_Table();
      v_String_Rec_Bcc  customer.String_Table := Customer.String_Table();
      v_EuroMsg_Mail_Input_Rec      Customer.EuroMsg_Mail_Input_Rec;
      v_EuroMsg_Mail_Parameter_Rec  Customer.EuroMsg_Mail_Parameter_Table := customer.EuroMsg_Mail_Parameter_Table();
      v_Response_rec                Customer.euromsg_mail_response_table := customer.EuroMsg_Mail_Response_Table();
      v_Process_Results             Customer.process_result_table;
      v_Parameter_Map               Customer.EuroMsg_Mail_Parameter_Table := customer.EuroMsg_Mail_Parameter_Table();       
      v_Sms_Input                   Customer.EuroMsg_Sms_Input_Rec;
      --ademo]
      -- Agency role
      CURSOR CUR_AGENCY_ROLE
      IS
         SELECT B.AGENT_ROLE
           FROM WIP_POLICY_BASES B
          WHERE B.CONTRACT_ID = PCONTRACT_ID
         UNION ALL
         SELECT Q.AGENT_ROLE
           FROM OCQ_POLICY_BASES Q
          WHERE     Q.CONTRACT_ID = PCONTRACT_ID
                AND Q.QUOTE_ID = (SELECT MAX (Q2.QUOTE_ID)
                                    FROM OCQ_QUOTES Q2
                                   WHERE Q2.CONTRACT_ID = Q.CONTRACT_ID);

      -- Agency address
      CURSOR CUR_AGENCY_ADDRESS
      IS
           SELECT DISTINCT B.START_DATE, D.ADDRESS_LINE1
             FROM DMT_AGENTS B, CP_PARTNERS C, KOC_CP_V_ADDRESSES D
            WHERE     C.PARTNER_REF = B.CUST_PART_UNIQUE_CODE
                  AND B.INT_ID = N_AGENT_ROLE
                  AND B.START_DATE <= TRUNC (SYSDATE)
                  AND (B.END_DATE IS NULL OR B.END_DATE >= TRUNC (SYSDATE))
                  AND D.ADD_ID = C.ADD_ID
         ORDER BY B.START_DATE DESC;

      -- Policy holder name
      V_AGENT_CAT_TYPE               KOC_DMT_AGENTS_EXT.AGENT_CATEGORY_TYPE%TYPE;
      V_PH_NAME                      VARCHAR2 (350);

      CURSOR CUR_AGENT_TYPE
      IS
         SELECT A.AGENT_CATEGORY_TYPE
           FROM KOC_DMT_AGENTS_EXT A
          WHERE A.INT_ID = N_AGENT_ROLE;

      CURSOR C_MT
      IS
         SELECT X.TITLE
           FROM KOC_DMT_AGENTS_EXT X
          WHERE X.INT_ID IN (SELECT A.SUB_AGENT
                               FROM OCQ_KOC_OCP_POL_VERSIONS_EXT A,
                                    OCQ_QUOTES B
                              WHERE     B.CONTRACT_ID = PCONTRACT_ID
                                    AND A.QUOTE_ID = B.QUOTE_ID);

      CURSOR CUR_OBF
      IS
           SELECT OFFICIAL_FORM_SERIAL_NO, OFFICIAL_FORM_NO
             FROM KOC_HPF H
            WHERE     CONTRACT_ID = PCONTRACT_ID
                  AND H.OFFICIAL_FORM_SERIAL_NO IN ('SF', 'FO', 'FM')
                  AND H.PRO_FORM_USE_STATUS = '1'
                  AND H.VALIDITY_END_DATE IS NULL
         ORDER BY FIRST_START_DATE DESC NULLS LAST;

      -- Bas�lacak mektuplar sorgusu (KOCOCPREP432 L�STELE butonu)
      CURSOR CUR_BASILACAK_MEKTUPLAR
      IS
           SELECT O.PARTITION_NO,
                  O.QUOTE_STATUS,
                  O.SUB_COMPANY_CODE,
                  O.QUOTE_ID,
                  VQ.GROUP_CODE,
                  HQ.FAMILY_CODE
             FROM OCQ_KOC_OCP_PARTITIONS_EXT O,
                  OCQ_QUOTES OQ,
                  OCQ_KOC_OCP_POL_VERSIONS_EXT VQ,
                  OCQ_IP_LINKS LQ,
                  OCQ_INTERESTED_PARTIES IQ,
                  OCQ_KOC_OCP_HEALTH HQ
            WHERE     OQ.CONTRACT_ID = PCONTRACT_ID
                  AND O.PARTITION_NO = NVL (PPARTITION_NO, O.PARTITION_NO)
                  AND O.QUOTE_STATUS = PQUOTE_STATUS                   -- T023
                  AND OQ.CONTRACT_ID = O.CONTRACT_ID
                  AND OQ.QUOTE_ID = O.QUOTE_ID
                  AND O.CONTRACT_ID = VQ.CONTRACT_ID
                  AND O.QUOTE_ID = VQ.QUOTE_ID
                  AND O.CONTRACT_ID = LQ.CONTRACT_ID
                  AND O.PARTITION_NO = LQ.PARTITION_NO
                  AND O.QUOTE_ID = LQ.QUOTE_ID
                  AND IQ.CONTRACT_ID = LQ.CONTRACT_ID
                  AND IQ.IP_NO = LQ.IP_NO
                  AND IQ.QUOTE_ID = LQ.QUOTE_ID
                  AND O.CONTRACT_ID = HQ.CONTRACT_ID
                  AND O.PARTITION_NO = HQ.PARTITION_NO
                  AND O.PARTITION_NO NOT IN (SELECT A.PARTITION_NO
                                               FROM KOC_OC_HLTH_DOC_PROC_REF A
                                              WHERE     A.REPORT_TYPE = 6
                                                    AND A.CONTRACT_ID =
                                                           O.CONTRACT_ID
                                                    AND SUBSTR (
                                                           SUB_REPORT_TYPE,
                                                           1,
                                                           1) = '1' -- Bireysel saglik departman�
                                                    AND NVL (A.IS_PRINTABLE, 0) =
                                                           2
                                                    AND SUBSTR (
                                                           SUB_REPORT_TYPE,
                                                           3,
                                                           4) = PQUOTE_STATUS)
                  AND O.QUOTE_ID = HQ.QUOTE_ID
                  AND O.QUOTE_ID =
                         (SELECT MAX (Q.QUOTE_ID)
                            FROM OCQ_QUOTES Q, OCQ_KOC_OCP_PARTITIONS_EXT QB
                           WHERE     Q.CONTRACT_ID = O.CONTRACT_ID
                                 AND QB.PARTITION_NO = O.PARTITION_NO
                                 AND Q.QUOTE_ID = QB.QUOTE_ID)
         ORDER BY HQ.FAMILY_NAME ASC, LQ.TYPE_OF_INTEREST DESC;

      REC_BASILACAK_MEKTUPLAR        CUR_BASILACAK_MEKTUPLAR%ROWTYPE;
      REC_NEXT_BASILACAK_MEKTUPLAR   CUR_BASILACAK_MEKTUPLAR%ROWTYPE;

      N_FAMILY_CODE                  OCQ_KOC_OCP_HEALTH.FAMILY_CODE%TYPE;
      N_NEXT_FAMILY_CODE             OCQ_KOC_OCP_HEALTH.FAMILY_CODE%TYPE;
      V_PARTITIONS                   VARCHAR2 (200);
      V_SORGU                        VARCHAR2 (1000);

      V_CONTACT                      VARCHAR2 (50);

      V_POLICY_REF                   VARCHAR2 (50);
      v_term_start_date              date;
      v_product_id                   number;
      v_is_mnor                      number := 0;

      CURSOR CUR_POLICY_REF
      IS
           SELECT POLICY_REF, term_start_date
             FROM (SELECT POLICY_REF, term_start_date
                     FROM OCQ_POLICY_BASES PB
                    WHERE PB.CONTRACT_ID = PCONTRACT_ID
                   UNION ALL
                   SELECT POLICY_REF, term_start_date
                     FROM WIP_POLICY_BASES PB
                    WHERE PB.CONTRACT_ID = PCONTRACT_ID
                   UNION ALL
                   SELECT POLICY_REF, term_start_date
                     FROM OCP_POLICY_BASES PB
                    WHERE PB.CONTRACT_ID = PCONTRACT_ID)
            WHERE POLICY_REF IS NOT NULL
         ORDER BY POLICY_REF ASC;

      cursor c_product_id is
         select product_id
           from (select distinct product_id
                   from wip_policy_contracts
                  where contract_id = pcontract_id
                 union all
                 select distinct product_id
                   from ocp_policy_contracts
                  where contract_id = pcontract_id);

      N_PH_SIG_AYNI                  NUMBER;

      CURSOR CUR_EMAIL_LOG (
         P_PART_ID   IN NUMBER)
      IS
         SELECT 1
           FROM ALZ_MAIL_DETAIL_LOG L
          WHERE     L.CONTRACT_ID = PCONTRACT_ID
                AND L.PARTITION_NO IS NULL
                AND L.REF1 = P_PART_ID
                AND L.ERROR_TEXT IS NULL;

      CURSOR CUR_SMS_LOG (
         P_PART_ID   IN NUMBER)
      IS
         SELECT 1, SMS_KEY
           FROM ALZ_SMS_LOG L
          WHERE     L.CONTRACT_ID = PCONTRACT_ID
                AND L.PARTITION_NO IS NULL
                AND L.PART_ID = P_PART_ID
                AND L.RESULT = '0';

      -- Sigorta ettiren ve t�m sigortal�lar i�in ileti�im bilgisi
      CURSOR CUR_CONTACT_INFO
      IS
           SELECT DISTINCT L.CUSTOMER_NAME_TEXT,
                           L.PARTITION_NO,
                           L.PARTNER_ID,
                           L.ROLE_TYPE,
                           L.TYPE_OF_INTEREST
             FROM (SELECT DISTINCT P1.CUSTOMER_NAME_TEXT,
                                   L1.PARTITION_NO,
                                   P1.PARTNER_ID,
                                   L1.ROLE_TYPE,
                                   L1.TYPE_OF_INTEREST
                     FROM OCQ_INTERESTED_PARTIES P1,
                          OCQ_IP_LINKS L1,
                          OCQ_KOC_OCP_PARTITIONS_EXT PR
                    WHERE     P1.CONTRACT_ID = L1.CONTRACT_ID
                          AND P1.IP_NO = L1.IP_NO
                          AND P1.CONTRACT_ID = PCONTRACT_ID
                          AND PR.CONTRACT_ID = L1.CONTRACT_ID
                          AND PR.PARTITION_NO = L1.PARTITION_NO
                          AND PR.QUOTE_ID = P1.QUOTE_ID
                          AND P1.QUOTE_ID =
                                 (SELECT NVL (MAX (Q.QUOTE_ID), P1.QUOTE_ID)
                                    FROM OCQ_QUOTES Q,
                                         OCQ_KOC_OCP_PARTITIONS_EXT QB
                                   WHERE     Q.CONTRACT_ID = P1.CONTRACT_ID
                                         AND QB.PARTITION_NO = L1.PARTITION_NO
                                         AND Q.QUOTE_ID = QB.QUOTE_ID)
                          AND P1.ACTION_CODE <> 'D'
                          AND L1.ACTION_CODE <> 'D'
                   UNION ALL
                   SELECT DISTINCT P2.CUSTOMER_NAME_TEXT,
                                   L2.PARTITION_NO,
                                   P2.PARTNER_ID,
                                   L2.ROLE_TYPE,
                                   L2.TYPE_OF_INTEREST
                     FROM OCP_INTERESTED_PARTIES P2, OCP_IP_LINKS L2
                    WHERE     P2.CONTRACT_ID = L2.CONTRACT_ID
                          AND P2.IP_NO = L2.IP_NO
                          AND P2.CONTRACT_ID = PCONTRACT_ID
                          AND P2.ACTION_CODE <> 'D'
                          AND L2.ACTION_CODE <> 'D'
                          AND P2.TOP_INDICATOR = 'Y'
                          AND L2.TOP_INDICATOR = 'Y'
                   UNION ALL
                   SELECT DISTINCT P3.CUSTOMER_NAME_TEXT,
                                   L3.PARTITION_NO,
                                   P3.PARTNER_ID,
                                   L3.ROLE_TYPE,
                                   L3.TYPE_OF_INTEREST
                     FROM OCQ_INTERESTED_PARTIES P3, OCQ_IP_LINKS L3
                    WHERE     P3.CONTRACT_ID = L3.CONTRACT_ID
                          AND P3.IP_NO = L3.IP_NO
                          AND P3.CONTRACT_ID = PCONTRACT_ID
                          AND P3.QUOTE_ID =
                                 (SELECT NVL (MAX (Q.QUOTE_ID), P3.QUOTE_ID)
                                    FROM OCQ_QUOTES Q
                                   WHERE Q.CONTRACT_ID = P3.CONTRACT_ID)
                          AND L3.QUOTE_ID = P3.QUOTE_ID
                          AND P3.ACTION_CODE <> 'D'
                          AND L3.ACTION_CODE <> 'D'
                          AND L3.ROLE_TYPE = 'PH') L
         ORDER BY DECODE (L.ROLE_TYPE, 'PH', 1, 2), -- En �stte sigorta ettiren
                  DECODE (L.TYPE_OF_INTEREST, 'K', 1, 2); -- Sonra �stte sigortal� kendisi, daha sonra ba��ml�lar�

      -- Ask�n�n otorize oldu�u merkezi kullan�c�n�n maili
      V_AUTH_USER_MAIL               VARCHAR2 (50);

      CURSOR CUR_AUTH_MAIL
      IS
         SELECT KOC_PARTNER_UTILS.GET_EMAIL (
                   NVL (UD.CUSTOMER_PARTNER_ID, U.CUSTOMER_PARTNER_ID))
           FROM KOC_HPF_TRANS HT, KOC_CP_USER_DETAIL UD, SEC_V_SYSTEM_USERS U
          WHERE     HT.CONTRACT_ID = PCONTRACT_ID
                AND NVL (HT.VERSION_NO, 1) = NVL (PVERSION_NO, 1)
                AND HT.TRANS_ORDER_NO =
                       (SELECT MAX (HT2.TRANS_ORDER_NO)
                          FROM KOC_HPF_TRANS HT2
                         WHERE     HT2.CONTRACT_ID = HT.CONTRACT_ID
                               AND HT2.VERSION_NO = HT.VERSION_NO
                               AND HT2.TO_ROLE = 'SFOPER')
                AND HT.TO_USER = UD.USERID
                AND U.ORACLE_USERNAME = HT.FROM_USER
                AND U.END_DATE IS NULL
                AND UD.VALIDITY_END_DATE IS NULL
         UNION ALL
         SELECT KOC_PARTNER_UTILS.GET_EMAIL (U.PARTNER_ID)
           FROM KOC_HPF_TRANS HT, WEB_V_SYSTEM_USERS U
          WHERE     HT.CONTRACT_ID = PCONTRACT_ID
                AND NVL (HT.VERSION_NO, 1) = NVL (PVERSION_NO, 1)
                AND HT.TRANS_ORDER_NO =
                       (SELECT MAX (HT2.TRANS_ORDER_NO)
                          FROM KOC_HPF_TRANS HT2
                         WHERE     HT2.CONTRACT_ID = HT.CONTRACT_ID
                               AND HT2.VERSION_NO = HT.VERSION_NO
                               AND HT2.TO_ROLE = 'SFOPER')
                AND HT.TO_USER = U.USER_NAME
                AND U.END_DATE IS NULL;

      N_OBF_NO                       NUMBER;
      V_OBF_S_NO                     VARCHAR2 (10);
      V_ODEME_TIPI                   VARCHAR2 (10);

      CURSOR CUR_ODEME_TIPI
      IS
         SELECT A.PAYMENT_KIND
           FROM KOC_HPF_COLLECTION A
          WHERE     A.OFFICIAL_FORM_SERIAL_NO = V_OBF_S_NO
                AND A.OFFICIAL_FORM_NO = N_OBF_NO;

      N_PRINTABLE                    NUMBER;

      CURSOR CUR_PRINT (
         P_CONTRACT_ID    IN NUMBER,
         P_PARTITION_NO   IN NUMBER)
      IS
             SELECT 1
               FROM KOC_OC_HLTH_DOC_PROC_REF R
              WHERE     R.CONTRACT_ID = P_CONTRACT_ID
                    AND R.PARTITION_NO = P_PARTITION_NO
                    AND R.REPORT_TYPE = 6
                    AND SUBSTR (R.SUB_REPORT_TYPE, 1, 1) = '1' -- Bireysel saglik departman�
                    AND SUBSTR (R.SUB_REPORT_TYPE, 3, 4) = PQUOTE_STATUS
         FOR UPDATE OF R.IS_PRINTABLE, R.PRINT_DATE, R.UPDATED_BY;

      V_BGD_EMP_ID                   ALZ_SALESPERSON_INFO.EMPLOYEE_ID%TYPE;
      V_BGD_EMAIL                    ALZ_SALESPERSON_INFO.EMAIL%TYPE;
      V_BGD_MNG_ID                   ALZ_SALESPERSON_INFO.MANAGER_ID%TYPE;

      V_BGD_EL_EMAIL                 ALZ_SALESPERSON_INFO.EMAIL%TYPE;
      V_BGD_BSY_EMAIL                ALZ_SALESPERSON_INFO.EMAIL%TYPE;

      CURSOR CUR_BGD
      IS
         SELECT S.EMPLOYEE_ID, S.EMAIL, S.MANAGER_ID
           FROM OCQ_QUOTES Q, ALZ_SALESPERSON_INFO S
          WHERE     Q.QUOTE_ID =
                       (SELECT MAX (QUOTE_ID)
                          FROM OCQ_QUOTES Q2
                         WHERE     Q2.CONTRACT_ID = PCONTRACT_ID
                               AND NVL (Q2.VERSION_NO, 0) =
                                      NVL (PVERSION_NO, 0))
                AND ALZ_SALESPERSON.IS_SALESPERSON (Q.USERNAME) =
                       S.EMPLOYEE_ID
                AND D_SYSDATE BETWEEN S.VALIDITY_START
                                  AND NVL (S.VALIDITY_END, D_SYSDATE);

      CURSOR CUR_BGD_MNG (
         P_MNG_ID   IN NUMBER)
      IS
         SELECT S.EMPLOYEE_ID, S.EMAIL, S.MANAGER_ID
           FROM ALZ_SALESPERSON_INFO S
          WHERE     S.EMPLOYEE_ID = P_MNG_ID
                AND D_SYSDATE BETWEEN S.VALIDITY_START
                                  AND NVL (S.VALIDITY_END, D_SYSDATE);

      PROCEDURE P_RAPOR_PAR_INSERT
      IS
         PRAGMA AUTONOMOUS_TRANSACTION;
      BEGIN
         SELECT NVL (MAX (RAPOR_ID), 0) + 1
           INTO N_RAPOR_ID
           FROM ALZ_PARAMS_FOR054;

         INSERT INTO ALZ_PARAMS_FOR054 (RAPOR_ID,
                                        P_ACIKLAMA, -- Bu program�n ismi/sebep
                                        P_HASAR_KONUSU,             -- P_Adres
                                        P_KIMDEN,    -- P_POLICY_HOLDERv_sorgu
                                        P_KIME                        -- SORGU
                                              )
              VALUES (N_RAPOR_ID,
                      V_REPORT_NAME,--'KOCREPOCP432',
                      V_AGENCY_ADDRESS,
                      V_PH_NAME,
                      V_SORGU);

         COMMIT;
      END P_RAPOR_PAR_INSERT;


      --PARTAJ ���N MAIL HAZIRLAYAN PROSEDUR

      PROCEDURE P_REFRESH_PARTAJ_MAIL_PAR
      IS
      BEGIN
         L_TO_XML := NULL;
         L_CC_XML := NULL;
         L_BCC_XML := NULL;

         --------------------------TO--------------------------------------------------------
         IF V_ACENTE_EMAIL IS NOT NULL
         THEN
            --L_TO_XML := '<toList>' || V_ACENTE_EMAIL || '</toList>';
             v_String_Rec_To.EXTEND;
             v_String_Rec_To(v_String_Rec_To.COUNT) := String_Rec(V_ACENTE_EMAIL);
         END IF;

         -- BGD bilg. - Ilker TASCI - 15.04.2015
         IF V_BGD_EMAIL IS NOT NULL
         THEN
            --L_TO_XML := L_TO_XML || '<toList>' || V_BGD_EMAIL || '</toList>';
             v_String_Rec_To.EXTEND;
             v_String_Rec_To(v_String_Rec_To.COUNT) := String_Rec(V_ACENTE_EMAIL);  
            IF V_BGD_EL_EMAIL IS NOT NULL
            THEN
               --L_CC_XML :=
                  --L_CC_XML || '<ccList>' || V_BGD_EL_EMAIL || '</ccList>';
                v_String_Rec_Cc.EXTEND;
                v_String_Rec_Cc(v_String_Rec_Cc.COUNT) := String_Rec(V_BGD_EL_EMAIL);   
            END IF;

            IF V_BGD_BSY_EMAIL IS NOT NULL
            THEN
               --L_CC_XML :=
                  --L_CC_XML || '<ccList>' || V_BGD_BSY_EMAIL || '</ccList>';
                v_String_Rec_Cc.EXTEND;
                v_String_Rec_Cc(v_String_Rec_Cc.COUNT) := String_Rec(V_BGD_BSY_EMAIL);  
            END IF;
         END IF;


         IF V_AUTH_USER_MAIL IS NOT NULL
         THEN
            --L_BCC_XML := '<bccList>' || V_AUTH_USER_MAIL || '</bccList>';
              v_String_Rec_Bcc.EXTEND;
              v_String_Rec_Bcc(v_String_Rec_Bcc.COUNT) := String_Rec(V_AUTH_USER_MAIL);
         END IF;

         /*L_BCC_XML :=
               L_BCC_XML
            || '<bccList>'
            || 'Mine.Buyukkartal@allianz.com.tr'
            || '</bccList>'
            || '<bccList>'
            || 'Dilek.ANLAR@allianz.com.tr' --basakk :kvem d�zenlemeleri
            || '</bccList>'
            || '<bccList>'
            || 'Emine.OLMEZ@allianz.com.tr'
            || '</bccList>'
            || '<bccList>'
            || 'Elvan.Kucuktiryaki@allianz.com.tr'
            || '</bccList>'
            || '<bccList>'
            || 'Sevgi.Gunay@allianz.com.tr'
            || '</bccList>';*/
            
         v_email := alz_tpa_hlth_policy_utils.get_emails (V_TPA_COMPANY_CODE, 'REJECT_MAIL', 'N', 'N');
   
         FOR ndx IN 1 .. v_email.v_bcc.COUNT LOOP
              v_String_Rec_Bcc.EXTEND;
              v_String_Rec_Bcc(v_String_Rec_Bcc.COUNT) := String_Rec(v_email.v_bcc(ndx));
         END LOOP;

         V_ODEME_TIPI := NULL;

         OPEN CUR_ODEME_TIPI;

         FETCH CUR_ODEME_TIPI INTO V_ODEME_TIPI;

         CLOSE CUR_ODEME_TIPI;

         IF V_ODEME_TIPI = 'N'
         THEN
           /* L_CC_XML :=
                  L_CC_XML
               || '<ccList>'
               || 'serkan.istar@allianz.com.tr '
               || '</ccList>'
               || '<ccList>'
               || 'onur.korkmaz@allianz.com.tr'
               || '</ccList>';*/
            FOR ndx IN 1 .. v_email.v_bcc.COUNT LOOP
              v_String_Rec_Cc.EXTEND;
              v_String_Rec_Cc(v_String_Rec_Cc.COUNT) := String_Rec(v_email.v_cc(ndx));
            END LOOP;
         END IF;


         --IF v_db <> 'OPUSDATA' THEN
         --KOC_GENERAL_UTILS.P_OUT_TEST('Mail test ama�l� at�lacak');
         --l_to_xml := '<toList>'||'IlkerT.Danisman@allianz.com.tr'|| '</toList>';
         --l_cc_xml := '<ccList>' ||'IlkerT.Danisman@allianz.com.tr'||'</ccList>'||
         -- '<ccList>' ||'IlkerT.Danisman@allianz.com.tr'||'</ccList>';
         --END IF;

         /*IF KOC_GENERAL_UTILS.F_IS_LIVE = 0
         THEN
            L_BCC_XML :=
                  L_BCC_XML
               || '<bccList>'
               || 'IlkerT.Danisman@allianz.com.tr'
               || '</bccList>';
         END IF;*/

         --------------------------TO--------------------------------------------------------
         --------------------------SUBJECT----------------------------------------------------
         IF L_PARTITION_TYPE = 'GRUP' THEN --basak : kvem d�zenlemeleri
            L_SUBJECT := L_PARTITION_TYPE || 'Poli�e Ba�vurunuz Hakk�nda - ' || PCONTRACT_ID;
         ELSE
            L_SUBJECT := 'Bireysel Sa�l�k Poli�e Ba�vurunuz Hakk�nda - ' || PCONTRACT_ID;
         END IF;

         IF KOC_GENERAL_UTILS.F_IS_LIVE = 0 THEN
            L_SUBJECT := L_SUBJECT || ' (TEST)';
         END IF;

         --------------------------SUBJECT----------------------------------------------------
         --------------------------BODY----------------------------------------------------
         L_BODY := '<![CDATA[';
         L_BODY :=
               L_BODY
            || '    Merhaba, '
            || '<br/>'
            || '    '
            || PCONTRACT_ID
            || ' ask� numaras� ile otorizasyona sundu�unuz �nbilgi Formu teklifiniz taraf�m�zdan'
            || ' red edilmi�, red mektubu ekte taraf�n�za sunulmu�tur.'
            || '<br/>'
            || '<br/>'
            || ' Sayg�lar�m�zla bilginize sunar�z,'
            || '<br/>'
            || '<br/>'
            || 'G�nderen: '
            || V_DEPARTMAN
            || ' ';

         IF KOC_GENERAL_UTILS.F_IS_LIVE = 0
         THEN
            L_BODY :=
                  L_BODY
               || '<br/><br/> Bu e-posta <b>TEST</b> ama�l� at�lm��t�r. L�tfen dikkate <b>almay�n�z</b>.';
         END IF;

         L_BODY := L_BODY || ']]>';
      --------------------------BODY----------------------------------------------------

      END P_REFRESH_PARTAJ_MAIL_PAR;
      
      --Sigortal�lar i�in MAIL HAZIRLAYAN PROSEDUR
      PROCEDURE REFRESH_SIG_MAIL_PARAMETERS (PTO_EMAIL   IN VARCHAR2,
                                             PBODY       IN VARCHAR2)
      IS
      BEGIN
         --------------------------  ALICILAR ------------------------------------------------------
         --L_TO_XML := '<toList>' || PTO_EMAIL || '</toList>';
         v_String_Rec_To.EXTEND;
         v_String_Rec_To(v_String_Rec_To.COUNT) := String_Rec(PTO_EMAIL);
         IF V_ACENTE_EMAIL IS NOT NULL
         THEN
            --L_CC_XML := '<ccList>' || V_ACENTE_EMAIL || '</ccList>';
            v_String_Rec_Cc.EXTEND;
            v_String_Rec_Cc(v_String_Rec_Cc.COUNT) := String_Rec(V_ACENTE_EMAIL);
         END IF;

         -- BGD bilg. - Ilker TASCI - 15.04.2015
         IF V_BGD_EMAIL IS NOT NULL
         THEN
            --L_CC_XML := L_CC_XML || '<ccList>' || V_BGD_EMAIL || '</ccList>';
            v_String_Rec_Cc.EXTEND;
            v_String_Rec_Cc(v_String_Rec_Cc.COUNT) := String_Rec(V_BGD_EMAIL);

            IF V_BGD_EL_EMAIL IS NOT NULL
            THEN
               --L_CC_XML :=
                  --L_CC_XML || '<ccList>' || V_BGD_EL_EMAIL || '</ccList>';
                v_String_Rec_Cc.EXTEND;
                v_String_Rec_Cc(v_String_Rec_Cc.COUNT) := String_Rec(V_BGD_EL_EMAIL);
            END IF;

            IF V_BGD_BSY_EMAIL IS NOT NULL
            THEN
               --L_CC_XML :=
                  --L_CC_XML || '<ccList>' || V_BGD_BSY_EMAIL || '</ccList>';
                v_String_Rec_Cc.EXTEND;
                v_String_Rec_Cc(v_String_Rec_Cc.COUNT) := String_Rec(V_BGD_BSY_EMAIL);  
            END IF;
         END IF;

         IF V_AUTH_USER_MAIL IS NOT NULL
         THEN
            --L_BCC_XML := '<bccList>' || V_AUTH_USER_MAIL || '</bccList>';
             v_String_Rec_Bcc.EXTEND;
             v_String_Rec_Bcc(v_String_Rec_Bcc.COUNT) := String_Rec(V_AUTH_USER_MAIL);  
         END IF;

         /*L_BCC_XML :=
               L_BCC_XML
            || '<bccList>'
            || 'Mine.Buyukkartal@allianz.com.tr'
            || '</bccList>'
            || '<bccList>'
            || 'Dilek.ANLAR@allianz.com.tr' --basakk :kvem d�zenlemeleri
            || '</bccList>'
            || '<bccList>'
            || 'Emine.OLMEZ@allianz.com.tr'
            || '</bccList>'
            || '<bccList>'
            || 'Elvan.Kucuktiryaki@allianz.com.tr'
            || '</bccList>'
            || '<bccList>'
            || 'Sevgi.Gunay@allianz.com.tr'
            || '</bccList>';*/
            
              
         v_email := alz_tpa_hlth_policy_utils.get_emails (V_TPA_COMPANY_CODE, 'REJECT_MAIL', 'N', 'N');
   
         FOR ndx IN 1 .. v_email.v_bcc.COUNT LOOP
              v_String_Rec_Bcc.EXTEND;
              v_String_Rec_Bcc(v_String_Rec_Bcc.COUNT) := String_Rec(v_email.v_bcc(ndx));
         END LOOP; 

         /*
         IF v_db <> 'OPUSDATA' THEN
           KOC_GENERAL_UTILS.P_OUT_TEST('Mail test ama�l� at�lacak');
           l_to_xml := '<toList>'||'IlkerT.Danisman@allianz.com.tr'||'</toList>';
           l_cc_xml := '<ccList>'||'IlkerT.Danisman@allianz.com.tr'|| '</ccList>';
           l_bcc_xml := '<bccList>'|| 'IlkerT.Danisman@allianz.com.tr' || '</bccList>';
         END IF;
         */
         /*IF KOC_GENERAL_UTILS.F_IS_LIVE = 0
         THEN
            L_BCC_XML :=
                  L_BCC_XML
               || '<bccList>'
               || 'IlkerT.Danisman@allianz.com.tr'
               || '</bccList>';
         END IF;*/

         --------------------------  ALICILAR OK --------------------------------------------------------
         --------------------------  SUBJECT  ----------------------------------------------------
         IF L_PARTITION_TYPE = 'GRUP' THEN --basak : kvem d�zenlemeleri
            L_SUBJECT := L_PARTITION_TYPE || 'Poli�e Ba�vurunuz Hakk�nda - ' || PCONTRACT_ID;
         ELSE
            L_SUBJECT := 'Bireysel Sa�l�k Poli�e Ba�vurunuz Hakk�nda - ' || PCONTRACT_ID;
         END IF;

         IF KOC_GENERAL_UTILS.F_IS_LIVE = 0
         THEN
            L_SUBJECT := L_SUBJECT || ' (TEST)';
         END IF;

         --------------------------SUBJECT OK ----------------------------------------------------

         --------------------------  BODY  ----------------------------------------------------
         L_BODY := '<![CDATA[';
         L_BODY := L_BODY || PBODY;

         IF KOC_GENERAL_UTILS.F_IS_LIVE = 0
         THEN
            L_BODY :=
                  L_BODY
               || '<br/><br/> ** Bu e-posta <b>TEST</b> ama�l� at�lm��t�r. L�tfen dikkate <b>almay�n�z</b>. **';
         END IF;

         L_BODY := L_BODY || ']]>';
      --------------------------BODY OK----------------------------------------------------
      END REFRESH_SIG_MAIL_PARAMETERS;
      PROCEDURE ADD_PARAM_TO_EM(P_PARAM_NAME IN VARCHAR2, P_PARAM_VALUE IN VARCHAR2) IS 
      BEGIN
           v_EuroMsg_Mail_Parameter_Rec.EXTEND;
           v_EuroMsg_Mail_Parameter_Rec(v_EuroMsg_Mail_Parameter_Rec.Count) := EuroMsg_Mail_Parameter_Rec(P_PARAM_NAME, P_PARAM_VALUE);
      END; 
   BEGIN
      RESET_MAIL_PARAMETERS;
      V_DB := NVL (V_DB, KOC_GENERAL_UTILS.GET_DB_NAME);
      D_SYSDATE := SYSDATE;

      V_REPORT_NAME := 'KOCREPOCP432';

      V_PARTITION_TYPE :=  ALZ_MDLR_HLTH_POLICY_UTILS13.get_partition_type (PCONTRACT_ID);
      V_PARTITION_NAME :=  alz_mdlr_hlth_policy_utils13.get_partition_name (V_PARTITION_TYPE, 'TR');

      L_PARTITION_TYPE := V_PARTITION_TYPE;
      L_PARTITION_NAME := V_PARTITION_NAME;
      
      V_TPA_COMPANY_CODE := ALZ_TPA_CORE_UTILS.get_company_code(PCONTRACT_ID);
      V_TPA_COMPANY_NAME := ALZ_TPA_CORE_UTILS.f_get_company_shortname(V_TPA_COMPANY_CODE);  
      v_Parameter_Map.Extend;
      v_Parameter_Map(v_Parameter_Map.Count) := euromsg_mail_parameter_rec ('EM_EMAIL_OTHER', 'true');  
      v_Parameter_Map.Extend;
      v_Parameter_Map.(v_Parameter_Map.Count) := euromsg_mail_parameter_rec ('EM_SMS_OTHER', 'true');  
      -- Agency role
      OPEN CUR_AGENCY_ROLE;

      FETCH CUR_AGENCY_ROLE INTO N_AGENT_ROLE;

      CLOSE CUR_AGENCY_ROLE;

      -- Acente adresi
      OPEN CUR_AGENCY_ADDRESS;

      FETCH CUR_AGENCY_ADDRESS INTO D_DUMMY, V_AGENCY_ADDRESS;

      CLOSE CUR_AGENCY_ADDRESS;

      KOC_GENERAL_UTILS.P_OUT_TEST ('Agency address: ' || V_AGENCY_ADDRESS);
      KOC_GENERAL_UTILS.P_OUT_TEST ('n_agent_role: ' || N_AGENT_ROLE);

      -- Policy holder name
      OPEN CUR_AGENT_TYPE;

      FETCH CUR_AGENT_TYPE INTO V_AGENT_CAT_TYPE;

      CLOSE CUR_AGENT_TYPE;

      KOC_GENERAL_UTILS.P_OUT_TEST ('v_agent_cat_type: ' || V_AGENT_CAT_TYPE);

      IF V_AGENT_CAT_TYPE = 5
      THEN
         OPEN C_MT;

         FETCH C_MT INTO V_PH_NAME;

         CLOSE C_MT;

         KOC_GENERAL_UTILS.P_OUT_TEST ('v_ph_name: ' || V_PH_NAME);
      ELSE
         V_PH_NAME := KOC_HEALTH_POLICY_UTILS3.FIND_AGENT_TITLE (N_AGENT_ROLE);
         KOC_GENERAL_UTILS.P_OUT_TEST ('Policy holder name 2: ' || V_PH_NAME);
      END IF;
      
      -- Contract_id
      --ADD_PARAM_TO_XML ('P_CONTRACT_ID', PCONTRACT_ID);
      ADD_PARAM_TO_EM('P_CONTRACT_ID', PCONTRACT_ID);
      -- Policy ref
      OPEN CUR_POLICY_REF;

      FETCH CUR_POLICY_REF INTO V_POLICY_REF, v_term_start_date;

      CLOSE CUR_POLICY_REF;

      open c_product_id;
        fetch c_product_id into v_product_id;
      close c_product_id;

      V_DEPARTMAN := 'Bireysel Sa�l�k Operasyon Departman�';

      V_ACENTE_EMAIL := KOC_OCP_HLTH_UTILS.GET_AGENT_EMAIL (N_AGENT_ROLE);
      KOC_GENERAL_UTILS.P_OUT_TEST ('v_acente_email: ' || V_ACENTE_EMAIL);
  
      -- Otorizasyon kullan�c�s� maili
      V_AUTH_USER_MAIL := NULL;

      OPEN CUR_AUTH_MAIL;

      FETCH CUR_AUTH_MAIL INTO V_AUTH_USER_MAIL;

      CLOSE CUR_AUTH_MAIL;

      KOC_GENERAL_UTILS.P_OUT_TEST ('v_auth_user_mail: ' || V_AUTH_USER_MAIL);


      -- BGD i�in bilgilendirme - 13.04.2015 - Ilker TASCI
      V_BGD_EMP_ID := NULL;

      OPEN CUR_BGD;

      FETCH CUR_BGD INTO V_BGD_EMP_ID, V_BGD_EMAIL, V_BGD_MNG_ID;

      CLOSE CUR_BGD;

      IF V_BGD_EMP_ID IS NOT NULL
      THEN
         -- 1.seviye manager: Ekip Liderini bulmaca
         V_BGD_EL_EMAIL := NULL;

         OPEN CUR_BGD_MNG (V_BGD_MNG_ID);

         FETCH CUR_BGD_MNG INTO V_BGD_EMP_ID, V_BGD_EL_EMAIL, V_BGD_MNG_ID;

         CLOSE CUR_BGD_MNG;

         -- 2.seviye manager: Bsy bulmaca
         V_BGD_BSY_EMAIL := NULL;

         OPEN CUR_BGD_MNG (V_BGD_MNG_ID);

         FETCH CUR_BGD_MNG INTO V_BGD_EMP_ID, V_BGD_BSY_EMAIL, V_BGD_MNG_ID;

         CLOSE CUR_BGD_MNG;
      END IF;

      -- Aileler haz�rlan�yor , acenteye mail bu loopta g�nderilecek
      OPEN CUR_BASILACAK_MEKTUPLAR;

      LOOP
         REC_NEXT_BASILACAK_MEKTUPLAR := NULL;

         FETCH CUR_BASILACAK_MEKTUPLAR INTO REC_NEXT_BASILACAK_MEKTUPLAR;

         KOC_GENERAL_UTILS.P_OUT_TEST (
            'Basilacak mektuplar LOOP ba�lang�c�');

         IF N_FAMILY_CODE IS NULL AND N_NEXT_FAMILY_CODE IS NULL
         THEN                                       -- �lk iterationda girecek
            N_FAMILY_CODE := REC_NEXT_BASILACAK_MEKTUPLAR.FAMILY_CODE;
         END IF;

         N_NEXT_FAMILY_CODE := REC_NEXT_BASILACAK_MEKTUPLAR.FAMILY_CODE;
         KOC_GENERAL_UTILS.P_OUT_TEST ('n_family_code: ' || N_FAMILY_CODE);
         KOC_GENERAL_UTILS.P_OUT_TEST (
            'n_next_family_code: ' || N_NEXT_FAMILY_CODE);

         IF     N_FAMILY_CODE IS NOT NULL
            AND N_FAMILY_CODE <> NVL (N_NEXT_FAMILY_CODE, -1)
         THEN                    -- Family code de�i�mi�, mevcut aileyi g�nder
            V_SORGU := ' and o.partition_no in ( ' || V_PARTITIONS || ') ';

            KOC_GENERAL_UTILS.P_OUT_TEST ('v_partitions: ' || V_PARTITIONS);
            --ADD_PARAM_TO_XML ('P_FAMILY_CODE', TO_CHAR (N_FAMILY_CODE));
            ADD_PARAM_TO_EM('P_FAMILY_CODE', TO_CHAR (N_FAMILY_CODE));  
            
            --ADD_PARAM_TO_XML ('P_AY_TIPI',
                              --TO_CHAR (REC_BASILACAK_MEKTUPLAR.QUOTE_STATUS));
            ADD_PARAM_TO_EM('P_AY_TIPI', TO_CHAR (REC_BASILACAK_MEKTUPLAR.QUOTE_STATUS));
                               
            --ADD_PARAM_TO_XML ('P_GROUP_CODE',
               --               REC_BASILACAK_MEKTUPLAR.GROUP_CODE);
            ADD_PARAM_TO_EM('P_GROUP_CODE', REC_BASILACAK_MEKTUPLAR.GROUP_CODE);   
            --ADD_PARAM_TO_XML (
              -- 'P_TIP',
              -- NVL (REC_BASILACAK_MEKTUPLAR.QUOTE_STATUS, 'T023'));
            ADD_PARAM_TO_EM('P_TIP', NVL (REC_BASILACAK_MEKTUPLAR.QUOTE_STATUS, 'T023'));
               
            KOC_GENERAL_UTILS.P_OUT_TEST (
                  'rec_basilacak_mektuplar.quote_status: '
               || REC_BASILACAK_MEKTUPLAR.QUOTE_STATUS);

            N_OBF_NO :=
               KOC_HPF_UTILS2.GET_OFN (PCONTRACT_ID,
                                       REC_BASILACAK_MEKTUPLAR.PARTITION_NO);
            V_OBF_S_NO :=
               KOC_HPF_UTILS2.GET_OFSN (PCONTRACT_ID,
                                        REC_BASILACAK_MEKTUPLAR.PARTITION_NO);

            IF V_OBF_S_NO IS NULL OR N_OBF_NO IS NULL
            THEN
               OPEN CUR_OBF;

               FETCH CUR_OBF INTO V_OBF_S_NO, N_OBF_NO;

               CLOSE CUR_OBF;
            END IF;

            --ADD_PARAM_TO_XML ('P_OBF_NO', V_OBF_S_NO || TO_CHAR (N_OBF_NO));
            ADD_PARAM_TO_EM ('P_OBF_NO', V_OBF_S_NO || TO_CHAR (N_OBF_NO));

            IF REC_BASILACAK_MEKTUPLAR.QUOTE_STATUS IS NOT NULL
            THEN
               V_SORGU :=
                     V_SORGU
                  || ' And o.quote_status = '''
                  || REC_BASILACAK_MEKTUPLAR.QUOTE_STATUS
                  || ''' ';
            ELSE
               V_SORGU :=
                     V_SORGU
                  || ' And o.quote_status =TO_CHAR( '''
                  || PQUOTE_STATUS
                  || ''') ';
            END IF;

            /*ADD_PARAM_TO_XML ('P_USER_NAME', USER);
            ADD_PARAM_TO_XML ('P_USER', SUBSTR (USER, 1, 2));
            ADD_PARAM_TO_XML ('P_USER2', USER);
            ADD_PARAM_TO_XML ('P_DEPARTMAN', '1');
            ADD_PARAM_TO_XML ('P_DATE',
                              TO_CHAR (TRUNC (SYSDATE), 'DD-MM-YYYY'));

            ADD_PARAM_TO_XML ('P_USER_TYPE', 'SFOPER');
            --add_param_to_xml ('P_EK_BILGI','' );
            ADD_PARAM_TO_XML ('P_DEPARTMANT_CODE', '5310');
            ADD_PARAM_TO_XML ('P_INSERT', 0);
            ADD_PARAM_TO_XML ('BACKGROUND', 'YES');
            ADD_PARAM_TO_XML ('COPIES', 1);
            ADD_PARAM_TO_XML ('MODE', 'BITMAP');
            ADD_PARAM_TO_XML ('BATCH', 'YES');
            ADD_PARAM_TO_XML ('PARAMFORM', 'NO');*/
            
            ADD_PARAM_TO_EM ('P_USER_NAME', USER);
            ADD_PARAM_TO_EM ('P_USER', SUBSTR (USER, 1, 2));
            ADD_PARAM_TO_EM ('P_USER2', USER);
            ADD_PARAM_TO_EM ('P_DEPARTMAN', '1');
            ADD_PARAM_TO_EM ('P_DATE',
                              TO_CHAR (TRUNC (SYSDATE), 'DD-MM-YYYY'));

            ADD_PARAM_TO_EM ('P_USER_TYPE', 'SFOPER');
            --add_param_to_em ('P_EK_BILGI','' );
            ADD_PARAM_TO_EM ('P_DEPARTMANT_CODE', '5310');
            ADD_PARAM_TO_EM ('P_INSERT', 0);
            ADD_PARAM_TO_EM ('BACKGROUND', 'YES');
            ADD_PARAM_TO_EM ('COPIES', 1);
            ADD_PARAM_TO_EM ('MODE', 'BITMAP');
            ADD_PARAM_TO_EM ('BATCH', 'YES');
            ADD_PARAM_TO_EM ('PARAMFORM', 'NO');

            -- Eger tek bir sigortal� i�in bas�m aliniyorsa, onun ismi ��ks�n
            IF PPARTITION_NO IS NOT NULL
            THEN
               --ADD_PARAM_TO_XML ('P_PARTITION_NO', PPARTITION_NO);
               ADD_PARAM_TO_EM ('P_PARTITION_NO', PPARTITION_NO);
            END IF;

            --ADD_PARAM_TO_XML ('P_TITLE', 0);
            ADD_PARAM_TO_EM ('P_TITLE', 0);

            -- T�rk�e karakter sorunu i�in baz� parametreler tablodan okunacak
            P_RAPOR_PAR_INSERT;

            --ADD_PARAM_TO_XML ('P_RAPOR_ID', TO_CHAR (N_RAPOR_ID));
            ADD_PARAM_TO_EM ('P_RAPOR_ID', TO_CHAR (N_RAPOR_ID));

            -- Mail g�nderme k�sm� (Partaja)
            --ADD_PARAM_TO_XML ('P_KIME', 'X'); -- �lerde degistirmek uzere dummy olarak olusturulur
            --ADD_PARAM_TO_EM ('P_KIME', 'X'); 
            --ADD_HEADER_TRAILER_TO_XML ('KOCREPOCP432', 'Basvuru');

            /*
            KOC_GENERAL_UTILS.P_OUT_TEST('P_EMAIL_GONDER GIRIS');
            P_REFRESH_PARTAJ_MAIL_PAR;
            P_EMAIL_GONDER('OpusMail');
            KOC_GENERAL_UTILS.P_OUT_TEST('P_EMAIL_GONDER CIKIS');
            */
            -- Partaja Mail g�nderme kald�r�ld�

            -- Bas�m tarih�esi kay�t yarat�lmas�
            WHILE INSTR (V_PARTITIONS, ',') > 0
            LOOP
               KOC_GENERAL_UTILS.P_OUT_TEST (
                  'v_partitions: ' || V_PARTITIONS);
               N_PARTITION_NO :=
                  SUBSTR (V_PARTITIONS, 1, INSTR (V_PARTITIONS, ',') - 1);

               N_PRINTABLE := 0;

               OPEN CUR_PRINT (PCONTRACT_ID, N_PARTITION_NO);

               FETCH CUR_PRINT INTO N_PRINTABLE;

               IF N_PRINTABLE = 1
               THEN                                                -- G�ncelle
                  UPDATE KOC_OC_HLTH_DOC_PROC_REF
                     SET IS_PRINTABLE = 2,
                         PRINT_DATE = SYSDATE,
                         UPDATED_BY = USER
                   WHERE CURRENT OF CUR_PRINT;
               ELSE                                     -- Yeni bas�m kayd� at
                  INSERT
                    INTO KOC_OC_HLTH_DOC_PROC_REF A (CONTRACT_ID,
                                                     PARTITION_NO,
                                                     REF_NO,
                                                     REPORT_TYPE,
                                                     SUB_REPORT_TYPE,
                                                     VERSION_NO,
                                                     REPORT_OCCURANCE_DATE,
                                                     CREATED_BY,
                                                     PRINT_DATE,
                                                     PRODUCT_IDS,
                                                     GROUP_CODE,
                                                     FAMILY_CODE,
                                                     SUB_COMPANY_CODE,
                                                     PH_NAME,
                                                     PH_ADDRESS,
                                                     IS_PRINTABLE,
                                                     PARAGRAPH_1)
                  VALUES (PCONTRACT_ID,
                          N_PARTITION_NO,
                          NVL (V_POLICY_REF, PCONTRACT_ID),
                          6,
                          '1-' || PQUOTE_STATUS,
                          1,
                          SYSDATE,
                          USER,
                          SYSDATE,
                          63,
                          NULL,
                          N_FAMILY_CODE,
                          NULL,
                          V_PH_NAME,
                          V_AGENCY_ADDRESS,
                          2,
                          NULL);
               END IF;

               CLOSE CUR_PRINT;

               V_PARTITIONS :=
                  SUBSTR (V_PARTITIONS, INSTR (V_PARTITIONS, ',') + 1);
            END LOOP;                              -- V_PARTITIONS parse loopu


            IF V_PARTITIONS IS NOT NULL
            THEN                                              -- Tek partition
               N_PARTITION_NO := V_PARTITIONS;
               N_PRINTABLE := 0;

               OPEN CUR_PRINT (PCONTRACT_ID, N_PARTITION_NO);

               FETCH CUR_PRINT INTO N_PRINTABLE;

               IF N_PRINTABLE = 1
               THEN                                                -- G�ncelle
                  UPDATE KOC_OC_HLTH_DOC_PROC_REF
                     SET IS_PRINTABLE = 2,
                         PRINT_DATE = SYSDATE,
                         UPDATED_BY = USER
                   WHERE CURRENT OF CUR_PRINT;
               ELSE                                     -- Yeni bas�m kayd� at
                  INSERT
                    INTO KOC_OC_HLTH_DOC_PROC_REF A (CONTRACT_ID,
                                                     PARTITION_NO,
                                                     REF_NO,
                                                     REPORT_TYPE,
                                                     SUB_REPORT_TYPE,
                                                     VERSION_NO,
                                                     REPORT_OCCURANCE_DATE,
                                                     CREATED_BY,
                                                     PRINT_DATE,
                                                     PRODUCT_IDS,
                                                     GROUP_CODE,
                                                     FAMILY_CODE,
                                                     SUB_COMPANY_CODE,
                                                     PH_NAME,
                                                     PH_ADDRESS,
                                                     IS_PRINTABLE,
                                                     PARAGRAPH_1)
                  VALUES (PCONTRACT_ID,
                          N_PARTITION_NO,
                          NVL (V_POLICY_REF, PCONTRACT_ID),
                          6,
                          '1-' || PQUOTE_STATUS,
                          1,
                          SYSDATE,
                          USER,
                          SYSDATE,
                          63,
                          NULL,
                          N_FAMILY_CODE,
                          NULL,
                          V_PH_NAME,
                          V_AGENCY_ADDRESS,
                          2,
                          NULL);
               END IF;

               CLOSE CUR_PRINT;
            END IF;

            -- Reset
            V_PARTITIONS := NULL;
            N_FAMILY_CODE := N_NEXT_FAMILY_CODE;
         END IF;

         IF V_PARTITIONS IS NULL
         THEN
            V_PARTITIONS := REC_NEXT_BASILACAK_MEKTUPLAR.PARTITION_NO;
         ELSIF N_FAMILY_CODE = REC_NEXT_BASILACAK_MEKTUPLAR.FAMILY_CODE
         THEN
            V_PARTITIONS :=
                  V_PARTITIONS
               || ','
               || REC_NEXT_BASILACAK_MEKTUPLAR.PARTITION_NO;
         END IF;

         KOC_GENERAL_UTILS.P_OUT_TEST ('v_partitions: ' || V_PARTITIONS);
         EXIT WHEN CUR_BASILACAK_MEKTUPLAR%NOTFOUND;
         REC_BASILACAK_MEKTUPLAR := REC_NEXT_BASILACAK_MEKTUPLAR;
      END LOOP;                                                             --

      B_INS_EMAIL_GONDERILDI := FALSE;
      B_SMS_GONDERILDI := FALSE;
      B_EMAIL_GONDERILDI := FALSE;

      -- �imdi sigorta ettiren ve sigortal�lara mail atal�m --
      FOR REC_CONTACT IN CUR_CONTACT_INFO
      LOOP
         V_CONTACT := NULL;
         V_ERROR := NULL;

         -- 1.MAIL GONDERIMI
         V_CONTACT := KOC_PARTNER_UTILS.GET_EMAIL (REC_CONTACT.PARTNER_ID);
         V_CONTACT :=
            NVL (V_CONTACT, GET_PRE_PARTNER_EMAIL (REC_CONTACT.PARTNER_ID)); -- Pre partner i�in

         KOC_GENERAL_UTILS.P_OUT_TEST ('v_contact: ' || V_CONTACT);
         KOC_GENERAL_UTILS.P_OUT_TEST (
               'rec_contact.customer_name_text: '
            || REC_CONTACT.CUSTOMER_NAME_TEXT);
         KOC_GENERAL_UTILS.P_OUT_TEST (
            'rec_contact.partition_no: ' || REC_CONTACT.PARTITION_NO);

         IF (   REC_CONTACT.ROLE_TYPE = 'PH'
             OR (    REC_CONTACT.ROLE_TYPE = 'INS'
                 AND NOT (B_INS_EMAIL_GONDERILDI)))
         THEN
            IF (V_CONTACT IS NOT NULL AND (INSTR (V_CONTACT, '@') > 0))
            THEN                                     -- Mail adresi d�zg�n ise
               V_AUTH_USER_MAIL := NULL;

               OPEN CUR_AUTH_MAIL;

               FETCH CUR_AUTH_MAIL INTO V_AUTH_USER_MAIL;

               CLOSE CUR_AUTH_MAIL;

               KOC_GENERAL_UTILS.P_OUT_TEST (
                  'v_auth_user_mail: ' || V_AUTH_USER_MAIL);

               -- E�er sigorta ettiren/sigortal� ayn� ise mail atma ve sigortal�ya da mail at�lm�� gibi log at.
               N_PH_SIG_AYNI := 0;

               -----duyguaksu partitionname
               if  nvl(koc_health_policy_utils5.get_prod_part_mdlr(v_product_id, v_partition_type, trunc(v_term_start_date)), 'X') = 'MNOR' then
                 v_is_mnor := 1;
               end if;

               IF REC_CONTACT.ROLE_TYPE = 'INS'
               THEN
                  OPEN CUR_EMAIL_LOG (REC_CONTACT.PARTNER_ID);

                  FETCH CUR_EMAIL_LOG INTO N_PH_SIG_AYNI;

                  CLOSE CUR_EMAIL_LOG;
               END IF;

               /*IF nvl(v_is_mnor, 0) = 0
               THEN
                  ----MD, NZB OLMAYAN TYPELARA DOKUNMA!!

                  V_SIG_BODY :=
                        '    Sn. '
                     || REC_CONTACT.CUSTOMER_NAME_TEXT
                     || ','
                     || '<br/>'
                     || '<br/>'
                     || '�irketimiz''de sigortalanmak �zere yapm�� oldu�unuz Bireysel Sa�l�k Poli�e ba�vurunuzun kabul edilemedi�ini �z�lerek bildirir sa�l�kl� g�nler dileriz.'
                     || '<br/><br/>'
                     || 'Sayg�lar�m�zla'
                     || '<br/>'
                     || 'Allianz Sigorta A.�.';
               ELSE
                  -----------------MD OLAN TYPE LAR DA SADECE ASAGIDAKI SEKILDE OLUYOR.
                  V_SIG_BODY :=
                        '    Sn. '
                     || REC_CONTACT.CUSTOMER_NAME_TEXT
                     || ','
                     || '<br/>'
                     || '<br/>'
                     || '�irketimiz''de sigortalanmak �zere yapm�� oldu�unuz '
                     || V_PARTITION_NAME
                     || 'Poli�e'
                     || ' ba�vurunuzun kabul edilemedi�ini �z�lerek bildirir sa�l�kl� g�nler dileriz.'
                     || '<br/><br/>'
                     || 'Sayg�lar�m�zla'
                     || '<br/>'
                     || 'Allianz Sigorta A.�.';
               END IF;*/
               IF NVL(v_is_mnor,0) = 0 THEN
                   V_PARTITION_NAME_TEXT := 'Bireysel Sa�l�k ';
               ELSE 
                   V_PARTITION_NAME_TEXT :=  V_PARTITION_NAME;    
               END IF;
               V_SIG_BODY :=
                        '    Sn. '
                     || REC_CONTACT.CUSTOMER_NAME_TEXT
                     || ','
                     || '<br/>'
                     || '<br/>'
                     || '�irketimiz''de sigortalanmak �zere yapm�� oldu�unuz '
                     || V_PARTITION_NAME_TEXT
                     || 'Poli�e'
                     || ' ba�vurunuzun kabul edilemedi�ini �z�lerek bildirir sa�l�kl� g�nler dileriz.';
               IF V_TPA_COMPANY_CODE != '045' THEN
                      V_SIG_BODY :=  V_SIG_BODY || '<br/>Detaylar i�in sat�� kanal�n�zla g�r��ebilirsiniz.';
               END IF;
               V_SIG_BODY :=  V_SIG_BODY ||  '<br/><br/>'
                                         || 'Sayg�lar�m�zla'
                                         || '<br/>'
                                         || V_TPA_COMPANY_NAME;
                                    
               -- Raporun kime gidece�i bilgisi rapora g�nderilir
               IF PQUOTE_STATUS = 'T023'
               THEN
                  /*L_RAPOR_XML :=
                     REPLACE (
                        L_RAPOR_XML,
                        '<parameters><name>P_KIME</name><value>X</value></parameters>',
                           '<parameters><name>P_KIME</name><value>'
                        || UPPER (REC_CONTACT.ROLE_TYPE)
                        || '</value></parameters>');
                                             
                  -- Sigorta ettireni replace edebilmek i�in
                  L_RAPOR_XML :=
                     REPLACE (
                        L_RAPOR_XML,
                        '<parameters><name>P_KIME</name><value>PH</value></parameters>',
                           '<parameters><name>P_KIME</name><value>'
                        || UPPER (REC_CONTACT.ROLE_TYPE)
                        || '</value></parameters>');

                  -- Sigortal�y� replace edebilmek i�in
                  L_RAPOR_XML :=
                     REPLACE (
                        L_RAPOR_XML,
                        '<parameters><name>P_KIME</name><value>INS</value></parameters>',
                           '<parameters><name>P_KIME</name><value>'
                        || UPPER (REC_CONTACT.ROLE_TYPE)
                        || '</value></parameters>');*/
                        ADD_PARAM_TO_EM ('P_KIME', UPPER (REC_CONTACT.ROLE_TYPE));    
               ELSE
                  /*L_RAPOR_XML :=
                     REPLACE (
                        L_RAPOR_XML,
                        '<parameters><name>P_KIME</name><value>X</value></parameters>',
                        '<parameters><name>P_KIME</name><value>INS</value></parameters>');*/
                        ADD_PARAM_TO_EM ('P_KIME', 'INS');  
               END IF;


               --

               REFRESH_SIG_MAIL_PARAMETERS (V_CONTACT, V_SIG_BODY);

               IF N_PH_SIG_AYNI = 0
               THEN
                  --P_EMAIL_GONDER ('OpusMail', 0);
                  v_EuroMsg_Mail_Report_Rec.EXTEND;
                  v_EuroMsg_Mail_Report_Rec(v_EuroMsg_Mail_Report_Rec.COUNT) := EuroMsg_Mail_Report_Rec('TR',
                                                                                                        'quote', --File_Param_For_Handle_Ex
                                                                                                        'Basvuru.PDF', --File_Name
                                                                                                        V_REPORT_NAME, --Report_Name
                                                                                                        v_EuroMsg_Mail_Parameter_Rec, --Report_Parameters
                                                                                                        'application/pdf'); --Content_Ty            
                  
                      
                  v_EuroMsg_Mail_Input_Rec := customer.EuroMsg_Mail_Input_Rec(NULL, 
                                                                              v_Template_Name,
                                                                              NULL,
                                                                              v_String_Rec_to,
                                                                              v_String_Rec_cc,
                                                                              v_String_Rec_bcc,
                                                                              v_Subject,
                                                                              v_Mail_Body,
                                                                              NULL,
                                                                              v_EuroMsg_Mail_Report_Rec,
                                                                              v_Company_Code, 
                                                                              v_Contract_Id,
                                                                              v_Parameter_Map);
                  alz_euromsg_utils.Send_Mail(v_EuroMsg_Mail_Input_Rec,
                                USER,
                                v_Response_Rec,
                                v_Process_Results);
                
                    FOR rec IN (SELECT Hata_Code,Response_Name, Response_Value FROM TABLE(v_Response_Rec)) LOOP
                        DBMS_OUTPUT.PUT_LINE('resp='||rec.Hata_Code||'-'||rec.Response_Name||'-'||rec.Response_Value);
                    END LOOP;                   
                    FOR rec IN (SELECT * FROM TABLE(v_Process_Results)) LOOP
                       dbms_output.put_line(rec.REASON||'-'||rec.KEY_VALUE1||'-'||rec.ERROR_ORIGIN);
                    END LOOP;  
                                              
                  B_EMAIL_GONDERILDI := TRUE;
                  KOC_GENERAL_UTILS.P_OUT_TEST ('-- E-mail g�nderildi. --');
               ELSE
                  KOC_GENERAL_UTILS.P_OUT_TEST (
                     '-- E-mail g�nderimi YAPILMADI (ph-sig ayni oldugu icin). --');
               END IF;

               IF REC_CONTACT.ROLE_TYPE = 'INS'
               THEN      -- E�er sigortal�ya mail g�nderdiysek daha gerek yok.
                  B_INS_EMAIL_GONDERILDI := TRUE;
               END IF;
            ELSE
               V_ERROR := 'E-posta adresi bulunamadi.';
            END IF;

            P_EMAIL_LOG (
               PAPP_NAME       => PAPP_CODE,
               PEMAIL          => V_CONTACT,
               PMAIL_NAME      => 'OBF RED',
               PCONTRACT_ID    => PCONTRACT_ID,
               PPARTITION_NO   => REC_CONTACT.PARTITION_NO,
               PREF1           => REC_CONTACT.PARTNER_ID,
               PMAIL_TEXT      =>    'SOAP REQUEST: '
                                  || SOAP_REQUEST
                                  || CHR (10)
                                  || '|SOAP RESPONSE: '
                                  || SOAP_RESPOND,
               PERROR_TEXT     => V_ERROR);
         END IF;

         -- Sigortal�/Sigorta ettiren e-Mail g�nderimi tamamland�

         -- Mail i�lemleri OK --

         V_CONTACT := NULL;
         -- 2.SMS G�NDER�M�

         V_SMS_RESPONSE := NULL;
         V_CONTACT := KOC_PARTNER_UTILS.GET_CEP_TEL (REC_CONTACT.PARTNER_ID);
         V_CONTACT :=
            NVL (V_CONTACT, GET_PRE_PARTNER_CEP_TEL (REC_CONTACT.PARTNER_ID)); -- Pre partner i�in

         IF     P_SMS_FLAG = 1
            AND LENGTH (V_CONTACT) >= 10             -- Do�ru cep telefonu mu?
            AND (   REC_CONTACT.ROLE_TYPE = 'PH'
                 OR (REC_CONTACT.ROLE_TYPE = 'INS' AND NOT (B_SMS_GONDERILDI)))
         THEN
            -- E�er sigorta ettiren/sigortal� ayn� ise sms g�nderme ve sigortal�ya da sms g�nderilmi� gibi log at.
            N_PH_SIG_AYNI := 0;

            IF REC_CONTACT.ROLE_TYPE = 'INS'
            THEN
               OPEN CUR_SMS_LOG (REC_CONTACT.PARTNER_ID);

               FETCH CUR_SMS_LOG INTO N_PH_SIG_AYNI, V_SMS_RESPONSE;

               CLOSE CUR_SMS_LOG;
            END IF;

            V_SMS_CONTENT := NULL;

            -- Red koduna g�re sms i�eri�i degisecek
            IF V_TPA_COMPANY_CODE = '045' THEN
               V_MUHATAP := 'acentenizle';
               IF P_QUOTE_STATUS IN ('T021','T023') AND nvl(v_is_mnor, 0) = 1 THEN
                  V_MUHATAP := V_MUHATAP || '/m��teri temsilcinizle';                                   
               END IF;
            ELSE 
               V_MUHATAP := 'sat�� kanal�n�zla';
            END IF; 
             
            IF nvl(v_is_mnor, 0) = 1
            THEN      ----DUYGUAKSU MD YE GORE GIDEN SMS TIPLERI BASKA OLUYOR.
               IF PQUOTE_STATUS = 'T024'
               THEN
                  V_SMS_CONTENT :=
                        'Sn. '
                     || REC_CONTACT.CUSTOMER_NAME_TEXT
                     || ' '
                     || V_OBF_S_NO
                     || N_OBF_NO
                     || ' ba�vurunuz '
                     || V_PARTITION_NAME
                     || ' Sigortas� Poli�e �zel �art / Genel �art / Uygulamalar�m�z nedeniyle kabul edilememi�tir.'
                     || 'Detaylar i�in '||V_MUHATAP||' g�r��ebilirsiniz.';
               ELSIF PQUOTE_STATUS = 'T023'
               THEN
                  V_SMS_CONTENT :=
                        'Sn. '
                     || REC_CONTACT.CUSTOMER_NAME_TEXT
                     || ' '
                     || V_OBF_S_NO
                     || N_OBF_NO
                     || ' numaral� '
                     || 'Ba�vuru ve Bilgilendirme Formu''nun teklif de�erlendirme s�resi doldu�u i�in kabul edilememi�tir.'
                     || 'Detaylar i�in '||V_MUHATAP||' g�r��ebilirsiniz.';
               ELSIF PQUOTE_STATUS = 'T021'
               THEN
                  V_SMS_CONTENT :=
                        'Sn. '
                     || REC_CONTACT.CUSTOMER_NAME_TEXT
                     || ' '
                     || V_OBF_S_NO
                     || N_OBF_NO
                     || ' numaral� '
                     || V_PARTITION_NAME
                     || 'Sigortas� ba�vurunuzun risk de�erlendirme kriterleri �er�evesinde kabul edilemedi�ini �z�lerek bildiririz.'
                     || 'Detaylar i�in '||V_MUHATAP||' g�r��ebilirsiniz.';
               ELSIF PQUOTE_STATUS = 'T015'
               THEN
                  V_SMS_CONTENT :=
                        'Sn. '
                     || REC_CONTACT.CUSTOMER_NAME_TEXT
                     || ' '
                     || V_OBF_S_NO
                     || N_OBF_NO
                     || ' numaral� '
                     || 'formla yapm�� oldu�unuz ba�vuru, talebiniz �zerine iptal edilmi�tir.';
               END IF;
            ELSE
               IF PQUOTE_STATUS = 'T023'
               THEN
                  V_SMS_CONTENT :=
                        'Sn. '
                     || REC_CONTACT.CUSTOMER_NAME_TEXT
                     || ' '
                     || V_OBF_S_NO
                     || N_OBF_NO
                     || ' numaral� '
                     || 'Ba�vuru ve Bilgilendirme Formu''nun teklif de�erlendirme s�resi doldu�u i�in kabul edilememi�tir.'
                     || 'Detaylar i�in '||V_MUHATAP||' g�r��ebilirsiniz.';
               ELSIF PQUOTE_STATUS = 'T021'
               THEN
                  V_SMS_CONTENT :=
                        'Sn. '
                     || REC_CONTACT.CUSTOMER_NAME_TEXT
                     || ' '
                     || V_OBF_S_NO
                     || N_OBF_NO
                     || ' numaral� '
                     || 'ba�vurunuzun risk de�erlendirme kriterleri �er�evesinde kabul edilmedi�ini '
                     || '�z�lerek bildiririz.Detaylar i�in '||V_MUHATAP||' g�r��ebilirsiniz.';
               ELSIF PQUOTE_STATUS = 'T015'
               THEN
                  V_SMS_CONTENT :=
                        'Sn. '
                     || REC_CONTACT.CUSTOMER_NAME_TEXT
                     || ' '
                     || V_OBF_S_NO
                     || N_OBF_NO
                     || ' numaral� '
                     || 'formla yapm�� oldu�unuz ba�vuru, talebiniz �zerine iptal edilmi�tir..';
               ELSIF PQUOTE_STATUS = 'T024'
               THEN
                  IF L_PARTITION_TYPE = 'GRUP' THEN --basakk :kvem d�zenlemeleri
                     V_SMS_CONTENT :=
                            'Sn. '
                         || REC_CONTACT.CUSTOMER_NAME_TEXT
                         || ' '
                         || V_OBF_S_NO
                         || N_OBF_NO
                         || ' ba�vurunuz '
                         || 'Sa�l�k Sigortas� K�lavuz / Genel �art / Uygulamalar�m�z nedeniyle kabul edilememi�tir.'
                         || 'Detaylar i�in '||V_MUHATAP||' g�r��ebilirsiniz.';
                  ELSE
                      V_SMS_CONTENT :=
                            'Sn. '
                         || REC_CONTACT.CUSTOMER_NAME_TEXT
                         || ' '
                         || V_OBF_S_NO
                         || N_OBF_NO
                         || ' ba�vurunuz '
                         || 'Sa�l�k Sigortas� �zel �art / Genel �art / Uygulamalar�m�z nedeniyle kabul edilememi�tir.'
                         || 'Detaylar i�in '||V_MUHATAP||' g�r��ebilirsiniz.';
                  END IF;
               END IF;
            END IF;



            IF NVL (N_PH_SIG_AYNI, 0) = 0
            THEN
               /*V_SMS_RESPONSE :=
                  KOC_SMS_UTILS.SENDSMS_WS (V_CONTACT,
                                            V_SMS_CONTENT,
                                            V_SMS_RESPONSE         -- Gereksiz
                                                          );*/
                                                         
                 
                 v_Sms_Input :=  Customer.EuroMsg_Sms_Input_Rec(V_CONTACT,
                                                                V_SMS_CONTENT,
                                                                V_TPA_COMPANY_CODE,
                                                                'RED_SMS_'||PCONTRACTID,
                                                                v_Parameter_Map);

                 Alz_Euromsg_Utils.Send_Sms(v_Sms_Input,
                                            2,
                                            USER,
                                            v_Response_Rec,
                                            v_Process_Results);  
               
               V_SMS_RESULT := '1';                             
               FOR rec IN (SELECT Hata_Code,Response_Name, Response_Value FROM TABLE(p_Response_Rec)) LOOP             
                  IF rec.Hata_Code = '200'
                  AND rec.Response_Name = 'code' THEN
                     V_SMS_RESULT := rec.Response_Value;
                  END IF;
                  IF rec.Response_Name = 'message' THEN
                     V_SMS_RESPONSE := rec.Response_Value;
                  END IF;
               END LOOP;
                                            
                                                                         
            END IF;

            KOC_GENERAL_UTILS.P_OUT_TEST ('-- SMS g�nderildi. --');

            --IF V_SMS_RESPONSE > 0 AND LENGTH (V_SMS_RESPONSE) = 19
            IF V_SMS_RESULT = '0' THEN
            THEN                                        -- Ba�ar�l� sms, logla
               --V_SMS_RESULT := '0';
               V_SMS_EXP :=
                     'Ref1: quote_id,Ref2: �BF no|�BF zaman a��m�ndan red sms g�nderimi - '
                  || REC_CONTACT.CUSTOMER_NAME_TEXT;
            ELSE
               V_SMS_RESULT := 'X';
               V_SMS_EXP := V_SMS_RESPONSE;
            END IF;

            IF V_CONTACT IS NULL
            THEN
               V_SMS_EXP := '0040 - Cep telefonu bulunamadi.';
            END IF;

            KOC_SMS_UTILS.P_SMS_LOG (
               PRESULT           => V_SMS_RESULT,
               PSMS_KEY          => V_SMS_RESPONSE,
               PCONTACT_INFO     => V_CONTACT,
               PCONTRACT_ID      => PCONTRACT_ID,
               PVERSION_NO       => PVERSION_NO,
               PPARTITION_NO     => REC_CONTACT.PARTITION_NO,
               PPART_ID          => REC_CONTACT.PARTNER_ID,
               PEXPLANATION      => V_SMS_EXP,
               PPROGRAM_NAME     => PAPP_CODE,
               PREFERENCE_1      => PQUOTE_STATUS,
               PREFERENCE_2      => V_OBF_S_NO || N_OBF_NO,
               PSENT_DATE        => TRUNC (SYSDATE),
               PSENT_DATE_TIME   => SYSDATE);

            -- koc_sms_utils.getSmsReport_ws(c.sms_key); = SMS'in ger�ekten ula�t���n� Turkcellden sorgulamak i�in

            IF REC_CONTACT.ROLE_TYPE = 'INS'
            THEN -- E�er herhangi bir sigortal�ya sms g�nderdiysek daha gerek yok.
               B_SMS_GONDERILDI := TRUE;
            END IF;
         END IF;
      END LOOP;                        -- cur_contacts loop / e-mail sms loopu

      -- E�er hi� e-mail g�nderemediysek acentenin redden haberi olmayacak.
      -- Acenteye ayr�ca mail g�nderimi - Ilker TASCI - 24/10/2014
      IF NOT (B_EMAIL_GONDERILDI)
      THEN
         KOC_GENERAL_UTILS.P_OUT_TEST (
            'Sigortal�/sigorta ettirende mail bulunamad�.Acenteye mail g�nderilecek...');

         IF V_ACENTE_EMAIL IS NULL
         THEN
            V_ACENTE_EMAIL :=
               KOC_OCP_HLTH_UTILS.GET_AGENT_EMAIL (N_AGENT_ROLE);
         END IF;

         P_REFRESH_PARTAJ_MAIL_PAR;
         P_EMAIL_GONDER ('OpusMail', 0);
         B_EMAIL_GONDERILDI := TRUE;

         IF V_ACENTE_EMAIL IS NULL
         THEN
            V_ERROR := 'Acente kodu ve e-posta adresi bulunamadi';
         END IF;

         P_EMAIL_LOG (
            PAPP_NAME       => PAPP_CODE,
            PEMAIL          => V_ACENTE_EMAIL,
            PMAIL_NAME      => 'OBF RED',
            PCONTRACT_ID    => PCONTRACT_ID,
            PPARTITION_NO   => 999,
            PREF1           => NVL (
                                 TO_CHAR (N_AGENT_ROLE),
                                 'Acente kodu ve e-posta adresi bulunamadi'),
            PMAIL_TEXT      =>    'SOAP REQUEST: '
                               || SOAP_REQUEST
                               || CHR (10)
                               || '|SOAP RESPONSE: '
                               || SOAP_RESPOND,
            PERROR_TEXT     => V_ERROR);

         KOC_GENERAL_UTILS.P_OUT_TEST (
               'Acenteye mail g�nderimi tamamland�|E-mail: '
            || V_ACENTE_EMAIL
            || '|Sonu�: '
            || NVL (V_ERROR, 'Ba�ar�l�'));
      END IF;

   END P_FERDI_SAGLIK_AUTH_RED_MAIL;
  BEGIN
    
  END;
