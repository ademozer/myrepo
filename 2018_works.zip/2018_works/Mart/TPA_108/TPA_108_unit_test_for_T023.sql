DECLARE
  v_script_id   NUMBER := 504;
  v_job_id      NUMBER := NULL;
  d_ref_date    DATE;
  v_log         CLOB;
  n_queue_treshold NUMBER;

  -- 45 g�n� ge�mi� otorizasyonda bekleyen ferdi saglik teklifleri
  CURSOR cur_contracts IS
    SELECT DISTINCT HT.CONTRACT_ID, ht.version_no,
                    koc_hpf_utils3.get_auth_term_start (ht.contract_id, ht.version_no, ht.partition_no) term_start
      FROM koc_hpf_trans ht, wip_ip_links il
     WHERE trans_entry_date > d_ref_date   -- �ok eski poli�elere bakmayal�m
       AND ht.is_sent = 1
       AND NVL(ht.hpf_status, NVL(KOC_HPF_UTILS3.partition_quote_status(ht.contract_id, ht.version_no, ht.partition_no)  ,'T055') ) IN ('T055','T053')
       AND EXISTS
              (SELECT 1
                 FROM koc_hpf h
                WHERE h.contract_id = ht.contract_id
                  --and h.version_no = ht.version_no
                  AND H.OFFICIAL_FORM_SERIAL_NO IN ('SF', 'FO', 'FM')
                  AND H.PRO_FORM_USE_STATUS = '1'
                  AND H.VALIDITY_END_DATE IS NULL)
     AND NOT EXISTS (SELECT 1
          FROM wip_koc_ocp_pol_contracts_ext e
         WHERE e.contract_id = ht.contract_id
           AND NVL(is_renewal, 0) = 1) --basakk : yenilemeler iptal edilmemeli
       AND il.contract_id = ht.contract_id
       AND il.partition_no = ht.partition_no
       AND il.action_code = 'A'
       AND HT.VERSION_NO = KOC_HPF_UTILS3.get_top_version (HT.CONTRACT_ID)
       AND koc_hpf_utils3.get_auth_term_start (ht.contract_id,
                                               ht.version_no,
                                               ht.partition_no) BETWEEN TO_DATE('27.10.2014','DD.MM.YYYY') AND TRUNC(SYSDATE - 10)
      --AND alz_mdlr_hlth_policy_utils13.get_partition_type(ht.contract_id) = 'TSSF'  
      AND ht.contract_id = 381397867                                       
         AND koc_hpf_utils3.get_auth_term_start (ht.contract_id, ht.version_no, ht.partition_no) <= TRUNC(SYSDATE - 30)  
         AND ht.hpf_status IS NULL;                                                  

  -- Update edilecek otorizasyon kay�tlar� (tekrar bu i�e d��mesini engellemek i�in)
  CURSOR cur_upd_trans(pcontract_id IN NUMBER, pversion_no IN NUMBER) IS
    SELECT ht.hpf_status
      FROM koc_hpf_trans ht
     WHERE ht.contract_id = pcontract_id
       AND ht.version_no = pversion_no
       FOR UPDATE OF ht.hpf_status;

  v_exp VARCHAR2(200);
  CURSOR cur_exp IS
    SELECT explanation
      FROM KOC_HPF_STATUS_REF
     WHERE hlth_code_status = 'T023'
       AND SYSDATE BETWEEN VALIDITY_START_DATE AND NVL(VALIDITY_END_DATE , TO_DATE ('01/01/3000','DD/MM/YYYY'));

  PROCEDURE P_LOG_LN(p_msg IN VARCHAR2) IS

  BEGIN
    IF v_log IS NULL THEN
      v_log := p_msg||CHR(10);
    ELSE
      dbms_lob.append(v_log,p_msg||CHR(10));
    END IF;
  END P_LOG_LN;


  --- TEKLIF RED ---
  PROCEDURE P_TEKLIF_RED(pcontract_id IN NUMBER, pversion_no IN NUMBER) IS

    v_move_code VARCHAR2(20);
    v_result VARCHAR2(20);
    CURSOR cur_move_code IS
      SELECT move_code
        FROM wip_policy_versions
       WHERE contract_id = pcontract_id;

    -- Policy quote
    CURSOR cur_quote_update IS
      SELECT hlth_quote_status, hlth_quote_status_exp, QUOTE_STATUS_DATE,
             QUOTE_STATUS_USER
        FROM ocq_koc_ocp_pol_contracts_ext
       WHERE contract_id = pcontract_id
         AND quote_id = (SELECT MAX(quote_id)
                           FROM ocq_quotes
                          WHERE contract_id = pcontract_id
                         )
         FOR UPDATE OF hlth_quote_status, hlth_quote_status_exp, QUOTE_STATUS_DATE,
             QUOTE_STATUS_USER ;

     -- Partitions
     CURSOR cur_partitions IS
      SELECT E.quote_status, E.QUOTE_STATUS_EXP, E.QUOTE_STATUS_DATE , E.QUOTE_STATUS_USER,
             E.PARTITION_NO
        FROM ocq_koc_ocp_partitions_ext E, ocq_ip_links il
       WHERE E.contract_id = pcontract_id
         AND il.contract_id = E.contract_id
         AND il.action_code = 'A'
         AND IL.PARTITION_NO = E.partition_no
         AND E.quote_id = (SELECT MAX (A.quote_id)
                           FROM ocq_koc_ocp_partitions_ext A, ocq_quotes b
                          WHERE A.quote_ID = b.quote_ID
                            AND A.partition_no = E.partition_no
                            AND b.contract_id = pcontract_id)
         AND NVL(E.quote_status,'T055') = 'T055'
         AND il.quote_id = E.quote_id
         FOR UPDATE OF E.quote_status, E.QUOTE_STATUS_EXP, E.QUOTE_STATUS_DATE,
             E.QUOTE_STATUS_USER;
  BEGIN

    P_LOG_LN('  P_TEKLIF_RED ba�l�yor...');

    -- 1. Update policy quote
    FOR rec_quote_update IN cur_quote_update LOOP
      UPDATE ocq_koc_ocp_pol_contracts_ext
         SET hlth_quote_status = 'T023',
             hlth_quote_status_exp = v_exp,
             --quote_status = 'DECLINED',
             QUOTE_STATUS_DATE = SYSDATE,
             QUOTE_STATUS_USER = USER
       WHERE CURRENT OF cur_quote_update;

    END LOOP;

    P_LOG_LN('  Teklif durumu redde �ekildi(ocq_koc_ocp_pol_contracts_ext)');

    IF NVL(pversion_no,1) = 1 THEN -- Yeni i� poli�e red

      P_LOG_LN('  Yeni i� teklifi silinecek|version_no: '||pversion_no);

      OPEN cur_move_code;
      FETCH cur_move_code INTO v_move_code;
      CLOSE cur_move_code;

      P_LOG_LN('  v_move_code: '||v_move_code);

      IF v_move_code IN ('DEMO','HNBQ','HBEXR','HIEXR') THEN
        v_result := quo_api.abort_quote(pcontract_id);
        P_LOG_LN('  Abort_quote �al��t�');
      ELSE
        v_result := pme_public.wip_abort(pcontract_id);
        P_LOG_LN('  wip_abort �al��t�');
      END IF;
    ELSE -- Zeyil red
      P_LOG_LN('  ZEY�L teklifi silinecek.|version_no: '||pversion_no);
      v_result := quo_api.abort_quote(pcontract_id);
      P_LOG_LN('  Abort_quote �al��t�: '||pversion_no);
    END IF;
    --

    P_LOG_LN('  ABORT prosed�rleri tamamland�.');

    P_LOG_LN('  Teklifteki ki�ilerin durumlar� g�ncellenecek ve silinecek...');
    -- 2. Update and delete parititons
    FOR rec_partitions IN cur_partitions LOOP

      UPDATE ocq_koc_ocp_partitions_ext
         SET quote_status = 'T023',
             QUOTE_STATUS_EXP=v_exp,
             QUOTE_STATUS_DATE=SYSDATE,
             QUOTE_STATUS_USER=USER
       WHERE CURRENT OF cur_partitions;

       Koc_health_policy_utils.delete_partition (pcontract_id,rec_partitions.partition_no) ;

       DELETE FROM WIP_KOC_OCP_GENERAL_SUP_LIST
        WHERE contract_id = pcontract_id
          AND partition_no =  rec_partitions.partition_no;

       -- Wip_partitionstan silemezsek action_code update edelim
       BEGIN
        DELETE FROM wip_partitions
          WHERE contract_id = pcontract_id
            AND partition_no =  rec_partitions.partition_no;
       EXCEPTION
        WHEN OTHERS THEN
            UPDATE wip_partitions
               SET action_code = 'D'
             WHERE contract_id = pcontract_id
               AND partition_no =  rec_partitions.partition_no;
       END;

       DELETE FROM KOC_HLTH_TRANS_POL_DETAIL
        WHERE main_contract_id = pcontract_id
          AND main_partition_no =  rec_partitions.partition_no;

    END LOOP;

    P_LOG_LN('  Teklifteki ki�ilerin g�ncellenmesi/silinmesi tamamland�.');

    P_LOG_LN('  -- P_TEKLIF_RED SON --');
  END P_TEKLIF_RED;

BEGIN

  P_LOG_LN('ferdi_saglik_auth_red script ba�l�yor...');

  IF koc_general_utils.run_script (v_script_id, v_job_id) = 1 THEN

    -- Ne kadar eskiye bakaca��m�z� hesaplama
    d_ref_date := (TRUNC(SYSDATE) - NVL(KOC_GENERAL_UTILS.getSystemParameter('AUTH_REJECT_DAY_DIFF',NULL), 45));
    P_LOG_LN('Otz. giri� tarihi milad�|d_ref_date: '||d_ref_date);

    -- Reports server i�in bekletme de�eri
    n_queue_treshold := NVL (KOC_GENERAL_UTILS.getSystemParameter('QUEUE_TRESHOLD',NULL), 50);

    OPEN cur_exp;
    FETCH cur_exp INTO v_exp;
    CLOSE cur_exp;
    P_LOG_LN('RED kodu a��klamas� bulundu: '||v_exp);

    P_LOG_LN('Ask�lar� bulan loop''a girilecek....');

    FOR rec_contracts IN cur_contracts LOOP

      P_LOG_LN('-----------------------------------');
      P_LOG_LN('Ask�lar� gezen LOOP '||cur_contracts%ROWCOUNT||'|contract_id: '||rec_contracts.contract_id||'|version_no: '||
                    rec_contracts.version_no||'|term_start: '||TO_CHAR(rec_contracts.term_start,'DD.MM.YYYY'));

      IF rec_contracts.term_start <= TRUNC(SYSDATE - 30) THEN -- �PTAL/RED
        P_LOG_LN('Ask� 30 G�N''den eski, REDED�LECEK...');

        --1. �ptal i�lemi yap�lacak (Teklif ve t�m ki�iler reddedilir)
        P_TEKLIF_RED(rec_contracts.contract_id, rec_contracts.version_no);
        P_LOG_LN('Teklif red �al��t�.(P_TEKLIF_RED �al��t�)');

        --2. PARTAJ ve sigortal�lara mail g�ndermece
        IF cur_contracts%ROWCOUNT MOD 3 = 0 THEN
          P_REP_QUEUE_BEKLE (n_queue_treshold);
        END IF;

        P_LOG_LN('RED maili g�nderilecek...');
        CUSTOMER.ALZ_PDF_MAIL.P_FERDI_SAGLIK_AUTH_RED_MAIL(pcontract_id => rec_contracts.contract_id,
            pversion_no => rec_contracts.version_no,
            pquote_status => 'T023',
            papp_code => 'ferdi_saglik_auth_red.SQL',
            p_sms_flag => 1);

        P_LOG_LN('RED maili �al��t�.');

        --3. Otorizasyon kayd�n� update edelim ki bir daha gelmesin
        FOR rec_upd IN cur_upd_trans(rec_contracts.contract_id,rec_contracts.version_no) LOOP
          UPDATE koc_hpf_trans
             SET hpf_status = 'T023'
           WHERE CURRENT OF cur_upd_trans;
        END LOOP;

        P_LOG_LN('Otorizasyon kay�tlar� g�ncellendi.');

      ELSIF rec_contracts.term_start IN (TRUNC(SYSDATE-10),TRUNC(SYSDATE-20),TRUNC(SYSDATE-25) ) THEN -- UYARI
        P_LOG_LN('Ask� 30 g�n� doldurmamu�, UYARI g�nderilecek...');
        CUSTOMER.ALZ_PDF_MAIL.P_FERDI_SAGLIK_AUTH_UYARI_MAIL(rec_contracts.contract_id, rec_contracts.version_no,TRUNC(SYSDATE - rec_contracts.term_start) );
        P_LOG_LN('Uyar� maili g�nderildi.');
      END IF;

      COMMIT;

      P_LOG_LN('Ask�lar� gezen LOOP '||cur_contracts%ROWCOUNT||'|'||rec_contracts.contract_id||' i�in SONA ERD�');
      P_LOG_LN('-----------------------------------');
    END LOOP;

    P_LOG_LN('Ask�lar� gezen LOOP tamamland�. ��lemler kaydediliyor....');
    koc_general_utils.success (v_script_id, v_job_id);

  END IF;

  P_LOG_LN('ferdi_saglik_auth_red TAMAMLANDI.');

  -- Log kayd� at�l�r
  ALZ_MDLR_HLTH_POLICY_UTILS7.P_INSERT_MDLR_LOG(p_contract_id => NULL, p_partition_no => NULL, P_log_detail => v_log,
  p_application_name => 'ferdi_saglik_auth_red', P_ref_1 => ('Script_id: '||v_script_id) , P_ref_2 => ('Job_id: '||v_job_id), P_ref_3 => NULL,
    p_result => 1);

EXCEPTION
  WHEN OTHERS THEN
    --
    BEGIN
      P_LOG_LN('ferdi_saglik_auth_red EXCEPTION!! Hata: '||SUBSTR(SQLERRM,1,200));
      -- Log kayd� at�l�r
      ALZ_MDLR_HLTH_POLICY_UTILS7.P_INSERT_MDLR_LOG(p_contract_id => NULL, p_partition_no => NULL, P_log_detail => v_log,
      p_application_name => 'ferdi_saglik_auth_red', P_ref_1 => ('Script_id: '||v_script_id) , P_ref_2 => ('Job_id: '||v_job_id), P_ref_3 => NULL,
      p_result => 1);
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    --

    koc_general_utils.ERROR (v_script_id, v_job_id);
END;

