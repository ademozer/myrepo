BEGIN
 INSERT INTO ALZ_TPA_HLTH_EMAILS
 select * from ALZ_TPA_HLTH_EMAILS@opusdev where type='OBF_RED';
 
 update koc_hpf_status_ref 
    set validity_end_date = SYSDATE
  where hlth_code_status = 'T031';
  
 COMMIT;
END;
/

  
