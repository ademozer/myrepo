BEGIN

update koc_hpf_status_ref
   set status_type = null
 where status_type = 2
   and hlth_code_status = 'T031';
   
COMMIT;

END;
/
