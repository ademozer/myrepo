select * from ALZ_MAIL_DETAIL_LOG where contract_id= 205853584 --381047457--send_date>=TO_DATE('12/04/2018','DD/MM/YYYY')
and APPLICATION_NAME='ALZ_MDLR_HLTH'
order by send_date desc


select * from ocp_policy_bases where policy_ref='0001071002934515'

 select * from ALZ_TPA_HLTH_EMAILS where type='OBF_RED';
 
 select * from ALZ_PARAMS_FOR054 where P_ACIKLAMA='KOCREPOCP432' and rapor_id=3604
 
 	SELECT P_HASAR_KONUSU AGENCY_ADDRESS, -- P_Adres                 
	         P_KIMDEN POLICY_HOLDER, -- P_POLICY_HOLDER
	         P_KIME SORGU -- SORGU	         
	 FROM ALZ_PARAMS_FOR054
	WHERE rapor_id = P_RAPOR_ID;
