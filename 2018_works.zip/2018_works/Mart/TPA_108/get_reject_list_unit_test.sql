DECLARE 
 TYPE t_cur_type IS REF CURSOR;
 v_cur2 t_cur_type;
 v_status VARCHAR2(100);
 v_exp    VARCHAR2(1000);
FUNCTION get_reject_list(p_product_id IN NUMBER) RETURN t_cur_type IS
  v_cur t_cur_type;
 BEGIN
   OPEN v_cur FOR    
      select a.hlth_code_status, a.explanation
         from koc_hpf_status_ref a
        where a.status_type = 2
        --  and ((nvl(v_is_renewal, 0) = 1 and (a.is_new_work = 1 or a.hlth_code_status in ('T025', 'T029', 'T062', 'T069', 'T021')))
            --    or (nvl(v_is_renewal, 0) = 1 and p_official_form_serial_no not in ('YM', 'YO', 'FZ'))
             --   or (nvl(v_is_renewal, 0) = 0 and (nvl(a.is_new_work, 0) = 0 or (nvl(v_is_cancelled, 0) = 1 and a.hlth_code_status in ('T063', 'T064')))))
          and trunc(sysdate) between a.validity_start_date
          and nvl(a.validity_end_date, '01/01/3000')
          and (a.has_reject_letter = decode(p_product_id, 63, 1, 64, 2, null) or a.has_reject_letter = 3)
          and ((p_product_id = 63 AND a.hlth_code_status != 'T031') OR p_product_id != 63)
     order by a.status_order;
    RETURN v_cur;
   END get_reject_list;
 BEGIN
    v_cur2 := get_reject_list(64);
    IF v_cur2%ISOPEN THEN
      LOOP
         FETCH v_cur2 INTO v_status,v_exp;         
         EXIT WHEN v_cur2%NOTFOUND;  
         DBMS_OUTPUT.PUT_LINE(v_status||':'||v_exp);
      END LOOP;
      CLOSE v_cur2;
    END IF;
 END;
      
  
