begin
  -- Call the procedure
  CUSTOMER.alz_pdf_mail.p_ferdi_saglik_auth_red_mail(pcontract_id => 380606516,
                                                     pversion_no => 1,
                                                     pquote_status => 'T023',
                                                     ppartition_no => NULL,
                                                     papp_code => 'RED_MAIL',
                                                     p_sms_flag => 1);
end;

/*select * from koc_cp_partners_ext where contract_id = 341009614
select * from wip_policy_bases  where contract_id = 341009614
select * from wip_interested_parties  where contract_id = 341009614

SELECT KOC_PARTNER_UTILS.GET_CEP_TEL(8005698129) FROM DUAL
*/

/*SELECT   cd.*
             FROM   KOC_CP_COMM_DEVICES cd
            WHERE   cd.part_id =8005698129  for update AND cd.comm_dev_type = '0040'
                    AND (cd.validity_end_date IS NULL
                         OR cd.validity_end_date > SYSDATE)
         ORDER BY   validity_start_date DESC;
         
         
         SELECT KOC_PARTNER_UTILS.GET_EMAIL (8005698129) FROM DUAL*/
         
         
   -- SELECT * FROM ALZ_TPA_HLTH_EMAILS for update
    
    
    
  select * from  ALZ_MAIL_DETAIL_LOG where contract_id=380606516
