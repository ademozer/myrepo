DECLARE
  p_Response_Rec                 Customer.EuroMsg_Mail_Response_Table:=Customer.EuroMsg_Mail_Response_Table();
  p_process_results              process_result_table; 
  v_payload CLOB;
  v_err VARCHAR2(1000);
  
    Procedure Call_TPA_Service(p_Method            In          Varchar2,
                               p_Payload           In        CLOB) IS

        ---v_URL               Varchar2(500) := get_url_link('http://esb.allianz.com.tr:12000/external/Tpa/rest/euroMessageService');
        v_URL               Varchar2(500) := get_url_link('http://esb.allianz.com.tr:12000/external/MessageService/rest/euroMessageService');

        v_Req               utl_http.req;
        v_Req_Length        Number;
        v_Res               utl_http.resp;

        v_Buffer            Varchar2(4000);
        v_Offset            Number := 1;
        v_Amount            Number :=1000;
        v_Utl_Err           Varchar2(4000);
        v_value             varchar2(32767);
        hata_code           varchar2(10);
        v_output            varchar2(10);
        v_Response_Rec      customer.EuroMsg_Mail_Response_Table :=customer.EuroMsg_Mail_Response_Table();
    Begin

        v_Req_Length := dbms_lob.getlength(p_Payload);

        v_Req := utl_http.begin_request(v_URL||'/'||p_Method, 'POST', 'HTTP/1.1');

        --utl_http.set_header(v_Req, 'Auth','Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJwbGF0Zm9ybSI6IkFMWl9UUEFEQiJ9.0yhHtB8X9taBuJ5h-8ZYmz7aVK7LnMiGhKr5tP6wXfY');
        utl_http.set_header(v_Req, 'Auth','Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJwbGF0Zm9ybSI6IkRCIn0.Vcq2uIMGOq3N8o9S-E-O93YuZ8qJVH0Or7tSfTxV_Qk');

        utl_http.set_header(v_Req, 'Content-Length', v_Req_Length);
        utl_http.set_header(v_Req, 'Content-Type', 'application/json;charset=UTF-8');
        utl_http.set_header (v_Req,'Transfer-Encoding', 'chunked' );
        utl_http.set_body_charset(v_Req,'UTF-8');

        While (v_Offset < v_Req_Length)
        Loop
           dbms_lob.read(p_Payload, v_Amount, v_Offset, v_Buffer);
           utl_http.write_text(r    => v_Req, data => v_Buffer);
           dbms_output.put_line('Buffer='||v_Buffer);
           v_Offset := v_Offset + v_Amount;
        End Loop;
      
        v_Res := utl_http.get_response(v_Req);
        Begin
           loop
              utl_http.read_line(v_Res, v_value);
             
              hata_code:=v_Res.status_code;

              Alz_EuroMsg_Utils.getcontenterr(v_value,
                            hata_code,
                            v_Response_Rec);

              --p_Response_Rec:=v_Response_Rec;
              dbms_output.put_line('Res_Value:'||v_value);   
           end loop;

              utl_http.end_response(v_Res);
              
        Exception
        When utl_http.end_of_body Then
             utl_http.end_response(v_Res);
              dbms_output.put_line('Hata3:'||SUBSTR(SQLERRM,1,200));   
        When utl_http.too_many_requests Then
             utl_http.end_response(v_Res);
              dbms_output.put_line('Hata2:'||SUBSTR(SQLERRM,1,200));   
        When Others Then              
             utl_http.end_response(v_Res);
             dbms_output.put_line('Hata1:'||SUBSTR(SQLERRM,1,200));   
       End;

    exception when others then
    utl_http.end_response(v_Res);
    dbms_output.put_line('HataX');
    v_utl_err:= Utl_Http.Get_Detailed_Sqlerrm;
        dbms_output.put_line('HataX'||v_utl_err);
    End;
BEGIN
  
  --v_payload := '{"toList":["extern.adem-ozer@allianz.com.tr"],"subject":"Bireysel Sa�l�k Poli�e Ba�vurunuz Hakk�nda - 371212268 (TEST)","body":"Test",'||v_report_params||',"contentType":"application/pdf"}],"companyCode":"045","clientKey":"OBF_RED_371212268","parameterMap":{"EM_EMAIL_OTHER":"true"}}';
  --v_payload := '{"toList":["extern.adem-ozer@allianz.com.tr"],"subject":"Bireysel Sa�l�k Poli�e Ba�vurunuz Hakk�nda - 380606516 (TEST)","body":"    Sn. �ZAY �ZDEM�R,<br/><br/>�irketimiz''de sigortalanmak �zere yapm�� oldu�unuz Bireysel Sa�l�k Poli�e ba�vurunuzun kabul edilemedi�ini �z�lerek bildirir sa�l�kl� g�nler dileriz.<br/>Detaylar i�in sat�� kanal�n�zla g�r��ebilirsiniz.<br/><br/>Sayg�lar�m�zla<br/>Fiba Emeklilik Ve Hayat A.�.<br/><br/> ** Bu e-posta <b>TEST</b> ama�l� at�lm��t�r. L�tfen dikkate <b>almay�n�z</b>. **","reportList":[{"fileLang":"TR","fileParamForHandleException":"quote","fileName":"Basvuru.PDF","reportName":"KOCREPOCP432","reportParameters":[{"name":"P_CONTRACT_ID","value":"371212268"},{"name":"P_FAMILY_CODE","value":"1"},{"name":"P_AY_TIPI","value":"T024"},{"name":"P_GROUP_CODE","value":""},{"name":"P_TIP","value":"T023"},{"name":"P_OBF_NO","value":"FO2822592"},{"name":"P_USER_NAME","value":"ALLZWEBPOL"},{"name":"P_USER","value":"AL"},{"name":"P_USER2","value":"ALLZWEBPOL"},{"name":"P_DEPARTMAN","value":"1"},{"name":"P_DATE","value":"16-04-2018"},{"name":"P_USER_TYPE","value":"SFOPER"},{"name":"P_DEPARTMANT_CODE","value":"1"},{"name":"P_INSERT","value":"0"},{"name":"BACKGROUND","value":"YES"},{"name":"COPIES","value":"1"},{"name":"MODE","value":"BITMAP"},{"name":"BATCH","value":"YES"},{"name":"PARAMFORM","value":"NO"},{"name":"P_PARTITION_NO","value":"1"},{"name":"P_TITLE","value":"0"},{"name":"P_RAPOR_ID","value":"45864"},{"name":"P_KIME","value":"INS"}],"contentType":"application/pdf"}],"companyCode":"100","clientKey":"OBF_RED_380606516","parameterMap":{"EM_EMAIL_OTHER":"true"}}';
 --v_payload := '{"toList":["extern.adem-ozer@allianz.com.tr"],"ccList":[],"bccList":["extern.adem-ozer@allianz.com.tr"],"subject":"Bireysel Sa�l�k Poli�e Ba�vurunuz Hakk�nda - 285337639 (TEST)","body":"    Sn. D�DEM �ZENG�N,<br/><br/>�irketimiz''de sigortalanmak �zere yapm�� oldu�unuz Bireysel Sa�l�k Poli�e ba�vurunuzun kabul edilemedi�ini �z�lerek bildirir sa�l�kl� g�nler dileriz.<br/><br/>Sayg�lar�m�zla<br/>Allianz Sigorta A.�.<br/><br/> ** Bu e-posta <b>TEST</b> ama�l� at�lm��t�r. L�tfen dikkate <b>almay�n�z</b>. **","reportList":[{"fileLang":"TR","fileParamForHandleException":"quote","fileName":"Basvuru.PDF","reportName":"KOCREPOCP432","reportParameters":[],"contentType":"application/pdf"}],"companyCode":"100","clientKey":"OBF_RED_285337639","parameterMap":{"EM_EMAIL_OTHER":"true"}}';
 --v_payload := '{"toList":["extern.adem-ozer@allianz.com.tr"],"subject":"Bireysel Sa�l�k Poli�e Ba�vurunuz Hakk�nda - 381047457 (TEST)","body":"    Sn. ZEL�HA �ZDEM�R,<br/><br/>�irketimiz''de sigortalanmak �zere yapm�� oldu�unuz Bireysel Sa�l�k Poli�e ba�vurunuzun kabul edilemedi�ini �z�lerek bildirir sa�l�kl� g�nler dileriz.<br/>Detaylar i�in sat�� kanal�n�zla g�r��ebilirsiniz.<br/><br/>Sayg�lar�m�zla<br/>Fiba Emeklilik Ve Hayat A.�.<br/><br/> ** Bu e-posta <b>TEST</b> ama�l� at�lm��t�r. L�tfen dikkate <b>almay�n�z</b>. **","reportList":[{"fileLang":"TR","fileParamForHandleException":"quote","fileName":"Basvuru.PDF","reportName":"KOCREPOCP432","reportParameters":[{"name":"P_CONTRACT_ID","value":"381047457"},{"name":"P_FAMILY_CODE","value":"1"},{"name":"P_AY_TIPI","value":"T024"},{"name":"P_GROUP_CODE","value":""},{"name":"P_TIP","value":"T024"},{"name":"P_OBF_NO","value":""},{"name":"P_USER_NAME","value":"ALLZWEBPOL"},{"name":"P_USER","value":"AL"},{"name":"P_USER2","value":"ALLZWEBPOL"},{"name":"P_DEPARTMAN","value":"1"},{"name":"P_DATE","value":"16-04-2018"},{"name":"P_USER_TYPE","value":"SFOPER"},{"name":"P_DEPARTMANT_CODE","value":"1"},{"name":"P_INSERT","value":"0"},{"name":"BACKGROUND","value":"YES"},{"name":"COPIES","value":"1"},{"name":"MODE","value":"BITMAP"},{"name":"BATCH","value":"YES"},{"name":"PARAMFORM","value":"NO"},{"name":"P_PARTITION_NO","value":"1"},{"name":"P_TITLE","value":"0"},{"name":"P_RAPOR_ID","value":"46014"},{"name":"P_KIME","value":"INS"}],"contentType":"application/pdf"}],"companyCode":"100","clientKey":"OBF_RED_381047457","parameterMap":{"EM_EMAIL_OTHER":"true"}}';
 --v_payload := '{"toList":["extern.adem-ozer@allianz.com.tr"],"ccList":[],"bccList":["extern.adem-ozer@allianz.com.tr"],"subject":"Bireysel Sa�l�k Poli�e Ba�vurunuz Hakk�nda - 205853584 (TEST)","body":"    Sn. G�LTEK�N PARLAK,<br/><br/>�irketimiz''de sigortalanmak �zere yapm�� oldu�unuz Bireysel Sa�l�k Poli�e ba�vurunuzun kabul edilemedi�ini �z�lerek bildirir sa�l�kl� g�nler dileriz.<br/><br/>Sayg�lar�m�zla<br/>Allianz Sigorta A.�.<br/><br/> ** Bu e-posta <b>TEST</b> ama�l� at�lm��t�r. L�tfen dikkate <b>almay�n�z</b>. **","reportList":[{"fileLang":"TR","fileParamForHandleException":"quote","fileName":"Basvuru.PDF","reportName":"KOCREPOCP432","reportParameters":[{"name":"P_CONTRACT_ID","value":"205853584"},{"name":"P_FAMILY_CODE","value":"1"},{"name":"P_AY_TIPI","value":"T023"},{"name":"P_GROUP_CODE","value":""},{"name":"P_TIP","value":"T023"},{"name":"P_OBF_NO","value":"FM272969"},{"name":"P_USER_NAME","value":"ADEMO"},{"name":"P_USER","value":"AD"},{"name":"P_USER2","value":"ADEMO"},{"name":"P_DEPARTMAN","value":"1"},{"name":"P_DATE","value":"17-04-2018"},{"name":"P_USER_TYPE","value":"SFOPER"},{"name":"P_DEPARTMANT_CODE","value":"5310"},{"name":"P_INSERT","value":"0"},{"name":"BACKGROUND","value":"YES"},{"name":"COPIES","value":"1"},{"name":"MODE","value":"BITMAP"},{"name":"BATCH","value":"YES"},{"name":"PARAMFORM","value":"NO"},{"name":"P_TITLE","value":"0"},{"name":"P_RAPOR_ID","value":"46045"},{"name":"P_KIME","value":"PH"}],"contentType":"application/pdf"}],"companyCode":"045","clientKey":"OBF_RED_205853584","parameterMap":{"EM_EMAIL_OTHER":"true"}}';
  /*Alz_Euromsg_Utils.Call_TPA_Service('sendMail',
                         v_Payload,
                         USER,
                         p_Response_Rec,
                         p_Process_Results);
                         
       FOR rec IN (SELECT Hata_Code,Response_Name, Response_Value FROM TABLE(p_Response_Rec)) LOOP
         DBMS_OUTPUT.PUT_LINE('resp='||rec.Hata_Code||'-'||rec.Response_Name||'-'||rec.Response_Value);
       END LOOP;                   
       FOR rec IN (SELECT * FROM TABLE(p_Process_Results)) LOOP
              dbms_output.put_line(rec.REASON||'-'||rec.KEY_VALUE1||'-'||rec.ERROR_ORIGIN);
       END LOOP;*/
       Call_TPA_Service('sendMail',
                         v_payload);
 EXCEPTION
 WHEN OTHERS THEN
   v_err := SQLERRM;
   dbms_output.put_line('Hata:'||v_err);
END;                        
