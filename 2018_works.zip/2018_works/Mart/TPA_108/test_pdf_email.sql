DECLARE  
   v_EuroMsg_Mail_Input_Rec      customer.EuroMsg_Mail_Input_Rec;
    --v_Report_Parameters           customer.EuroMsg_Mail_Parameter_Table := customer.EuroMsg_Mail_Parameter_Table();
    --v_EuroMsg_Mail_Attachment_Rec customer.EuroMsg_Mail_Attachment_Table := customer.EuroMsg_Mail_Attachment_Table();
    v_EuroMsg_Mail_Parameter_Rec  customer.EuroMsg_Mail_Parameter_Table := customer.EuroMsg_Mail_Parameter_Table();
    v_String_Rec_to               customer.String_Table := customer.String_Table();
    v_String_Rec_cc               customer.String_Table := customer.String_Table();
    v_String_Rec_bcc              customer.String_Table := customer.String_Table();
    v_EuroMsg_Mail_Report_Rec     customer.EuroMsg_Mail_Report_Table := customer.EuroMsg_Mail_Report_Table();
    v_response_rec                customer.euromsg_mail_response_table := customer.EuroMsg_Mail_Response_Table();
    v_process_results             customer.process_result_table;
    v_Mail_Body                   VARCHAR2(32000) := NULL;
    v_Template_Name               VARCHAR2(50) := NULL;
    v_Application_Name            VARCHAR2(50) := 'KOCREPACC030CRON';
    v_subject                     VARCHAR2(500);
    v_adi                         VARCHAR2(250);
    v_bastar                      VARCHAR2(250);
    v_bittar                      VARCHAR2(250);
    v_company_name                VARCHAR2(500) := 'Allianz';
    v_Company_Code                VARCHAR2(50)  := '045';
    v_partaj                      VARCHAR2(100) := '1000';
    v_contract_id                 VARCHAR2(100) := '11111111'; 
BEGIN
   

    v_bastar := '01/09/2017';
    v_bittar := '01/12/2017';
              
    v_String_Rec_to.EXTEND;
    v_String_Rec_to(v_String_Rec_to.COUNT) := String_Rec('extern.adem-ozer@allianz.com.tr');
               
            
    v_adi := 'ADEM';--KOC_CLM_UTILS.PARTNER_NAME_BUL(loaded_rec.part_id);
            
    v_subject := 'Kredi Kartlar� Servisi : Partaj - ' ||
                             TO_CHAR(TO_NUMBER(v_partaj), 'FM00000') ||
                             ' - ' || v_bastar || '-' || v_bittar ||
                             ' Red Olan KK Bilgileri';
            
    v_Mail_Body := 'PARTAJ : ' || v_partaj || '<br><br>' ||
                                 'Say�n ' || v_adi || ', <br><br>' ||
                                 'Ekteki dosyada red olan kk bilgileriniz bulunmaktad�r.<br><br>' ||
                                 'NOT : BU MA�L YALNIZCA B�LG� AMA�LIDIR. BU MA�L ADRES�NE G�NDERECE��N�Z CEVAPLAR D�KKATE ALINMAYACAKTIR.<br><br>' ||
                                 'Sayg�lar�m�zla,<br><br>' || v_company_name;
            
    -- Reports Parameters Start
    v_EuroMsg_Mail_Parameter_Rec.EXTEND;
    v_EuroMsg_Mail_Parameter_Rec(v_EuroMsg_Mail_Parameter_Rec.Count) := EuroMsg_Mail_Parameter_Rec('P_START_DATE', v_bastar);
    v_EuroMsg_Mail_Parameter_Rec.EXTEND;
    v_EuroMsg_Mail_Parameter_Rec(v_EuroMsg_Mail_Parameter_Rec.Count) := EuroMsg_Mail_Parameter_Rec('P_END_DATE', v_bittar);
    v_EuroMsg_Mail_Parameter_Rec.EXTEND;
    v_EuroMsg_Mail_Parameter_Rec(v_EuroMsg_Mail_Parameter_Rec.Count) := EuroMsg_Mail_Parameter_Rec('P_INT_ID', '1234');
    v_EuroMsg_Mail_Parameter_Rec.EXTEND;
    v_EuroMsg_Mail_Parameter_Rec(v_EuroMsg_Mail_Parameter_Rec.Count) := EuroMsg_Mail_Parameter_Rec('P_SUB_AGENT', '1234');
    -- Reports Rec
    v_EuroMsg_Mail_Report_Rec.EXTEND;
    v_EuroMsg_Mail_Report_Rec(v_EuroMsg_Mail_Report_Rec.COUNT) := EuroMsg_Mail_Report_Rec('TR',
                                                                                          'quote', --File_Param_For_Handle_Ex
                                                                                          'KK_RED_' ||
                                                                                           v_partaj ||
                                                                                          '.PDF', --File_Name
                                                                                          v_Application_Name, --Report_Name
                                                                                          v_EuroMsg_Mail_Parameter_Rec, --Report_Parameters
                                                                                          'application/pdf'); --Content_Ty            
    v_EuroMsg_Mail_Input_Rec := customer.EuroMsg_Mail_Input_Rec(NULL, --v_EuroMsg_Mail_Attachment_Rec,
                                                                v_Template_Name,
                                                                NULL, --v_EuroMsg_Mail_Parameter_Rec,
                                                                v_String_Rec_to,
                                                                v_String_Rec_cc,
                                                                v_String_Rec_bcc,
                                                                v_Subject,
                                                                v_Mail_Body,
                                                                NULL, --v_Application_Name,
                                                                v_EuroMsg_Mail_Report_Rec,
                                                                v_Company_Code, --UAT'den sonra kald�r�lacak !!!!!!!!!! --AliSakalli
                                                                v_contract_id,
                                                                NULL);
    alz_euromsg_utils.Send_Mail(v_EuroMsg_Mail_Input_Rec,
                                USER,
                                v_Response_Rec,
                                v_Process_Results);
                
    FOR rec IN (SELECT Hata_Code,Response_Name, Response_Value FROM TABLE(v_Response_Rec)) LOOP
        DBMS_OUTPUT.PUT_LINE('resp='||rec.Hata_Code||'-'||rec.Response_Name||'-'||rec.Response_Value);
    END LOOP;                   
    FOR rec IN (SELECT * FROM TABLE(v_Process_Results)) LOOP
       dbms_output.put_line(rec.REASON||'-'||rec.KEY_VALUE1||'-'||rec.ERROR_ORIGIN);
    END LOOP;  
              
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('HATA:'||SUBSTR(SQLERRM,1,200));
END;
