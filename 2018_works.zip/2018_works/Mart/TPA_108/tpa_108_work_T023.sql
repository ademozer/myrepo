(TRUNC(SYSDATE) - NVL(KOC_GENERAL_UTILS.getSystemParameter('AUTH_REJECT_DAY_DIFF',NULL), 45))

SELECT DISTINCT HT.CONTRACT_ID, ht.version_no,
                    koc_hpf_utils3.get_auth_term_start (ht.contract_id, ht.version_no, ht.partition_no) term_start,ht.hpf_status 
      FROM koc_hpf_trans ht, wip_ip_links il
     WHERE trans_entry_date > (TRUNC(SYSDATE) - NVL(KOC_GENERAL_UTILS.getSystemParameter('AUTH_REJECT_DAY_DIFF',NULL), 45))   -- �ok eski poli�elere bakmayal�m
       AND ht.is_sent = 1
       AND NVL(ht.hpf_status, NVL(KOC_HPF_UTILS3.partition_quote_status(ht.contract_id, ht.version_no, ht.partition_no)  ,'T055') ) IN ('T055','T053')
       AND EXISTS
              (SELECT 1
                 FROM koc_hpf h
                WHERE h.contract_id = ht.contract_id
                  --and h.version_no = ht.version_no
                  AND H.OFFICIAL_FORM_SERIAL_NO IN ('SF', 'FO', 'FM')
                  AND H.PRO_FORM_USE_STATUS = '1'
                  AND H.VALIDITY_END_DATE IS NULL)
     AND NOT EXISTS (SELECT 1
          FROM wip_koc_ocp_pol_contracts_ext e
         WHERE e.contract_id = ht.contract_id
           AND NVL(is_renewal, 0) = 1) --basakk : yenilemeler iptal edilmemeli
       AND il.contract_id = ht.contract_id
       AND il.partition_no = ht.partition_no
       AND il.action_code = 'A'
       AND HT.VERSION_NO = KOC_HPF_UTILS3.get_top_version (HT.CONTRACT_ID)
       AND koc_hpf_utils3.get_auth_term_start (ht.contract_id,
                                               ht.version_no,
                                               ht.partition_no) BETWEEN TO_DATE('27.10.2014','DD.MM.YYYY') AND TRUNC(SYSDATE - 10)
         AND alz_mdlr_hlth_policy_utils13.get_partition_type(ht.contract_id) = 'TSSF'                                          
         AND koc_hpf_utils3.get_auth_term_start (ht.contract_id, ht.version_no, ht.partition_no) <= TRUNC(SYSDATE - 30)  
         AND ht.hpf_status IS NULL   
         
         
          SELECT *--A.term_start_date
           FROM wip_koc_ocp_partitions_ext A
          WHERE A.contract_id = 341031223 AND A.partition_no = 1 for update
                                          
      SELECT hlth_quote_status, hlth_quote_status_exp, QUOTE_STATUS_DATE,
             QUOTE_STATUS_USER
        FROM ocq_koc_ocp_pol_contracts_ext
       WHERE contract_id = 341012571
         AND quote_id = (SELECT MAX(quote_id)
                           FROM ocq_quotes
                          WHERE contract_id = 341012571
                         )
                                         
                         
SELECT *-- kc.runonholiday,NVL(half_day,0)
--INTO v_runonholiday,v_half_day
FROM Koc_cron_script_def kc
WHERE kc.script_id = 504
 select * from all_source where lower(text) like '%run_script%'
      -- AND ht.hpf_status = 'T023'                                         
      -- select * from koc_hpf_trn_det where contract_id=341012571
                                             -- select * from wip_koc_ocp_pol_contracts_ext where  alz_mdlr_hlth_policy_utils13.get_partition_type(contract_id) = 'TSSF'


select * from alz_tpa_hlth_emails where TYPE='OBF_RED' and USING_SYSTEM = 'TEST' for update

select * from wip_policy_bases where contract_id = 341031223

 select * from  wip_policy_bases where contract_id = 341037664
     
     select * from koc_dmt_agency_tech_emp where agent_int_id=71075
     
     SELECT KOC_OCP_HLTH_UTILS.GET_AGENT_EMAIL(71075) FROM DUAL
     
     select * from ALZ_TPA_HLTH_EMAILS where type='OBF_RED' and USING_SYSTEM='TEST' for update--and 
     
     select * from ALZ_MAIL_DETAIL_LOG where contract_id = 341009614 order by send_date desc
