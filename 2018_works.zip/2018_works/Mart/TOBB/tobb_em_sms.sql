  --{"smsBody":"De�erli Acentemiz T�LAY K���O�LU kullan�c�s�n�n DIGITALL sistemine giri� i�in kullan�c� ad� WDA0890_15176 ve �ifresi omTG3LPn9 olu�turulmu�tur. DIGITALL sistemine giri� yapabilirsiniz. https://digitall.allianz.com.tr","gsmNo":"905322165846","companyCode":"045","clientKey":"ALZ_TOBB_USER_905322165846","parameterMap":{"EM_SMS_OTHER":"true"}}
 DECLARE
   p_company_code                 VARCHAR2(100) := '045';
   p_gsm VARCHAR2(100) := '905423547375';
   p_message_body VARCHAR2(1000) := 'De�erli Acentemiz T�LAY K���O�LU kullan�c�s�n�n DIGITALL sistemine giri� i�in kullan�c� ad� WDA0890_15176 ve �ifresi omTG3LPn9 olu�turulmu�tur. DIGITALL sistemine giri� yapabilirsiniz. https://digitall.allianz.com.tr","gsmNo":"905322165846","companyCode":"045","clientKey":"ALZ_TOBB_USER_905322165846';
   v_Response_Rec                 Customer.euromsg_mail_response_table := Customer.EuroMsg_Mail_Response_Table();
   v_Process_Results              Customer.process_result_table;
   v_Sms_Input                    Customer.EuroMsg_Sms_Input_Rec;
   v_Sms_Message_Type             NUMBER := 1;
   v_Parameter_Map                Customer.EuroMsg_Mail_Parameter_Table := Customer.EuroMsg_Mail_Parameter_Table();
   v_Sms_Result                   VARCHAR2(1000);
   v_Sms_Response                 VARCHAR2(1000);
 BEGIN
   v_Parameter_Map.Extend;
   v_Parameter_Map(v_Parameter_Map.Count) := euromsg_mail_parameter_rec ('EM_SMS_OTHER', 'true'); --allclubdan g�nderim i�in
    
   v_Sms_Input :=  Customer.EuroMsg_Sms_Input_Rec(p_gsm,
                                                  p_message_body,
                                                  p_company_code,
                                                  'ALZ_TOBB_USER_'||p_gsm,
                                                  v_Parameter_Map);

    Alz_Euromsg_Utils.Send_Sms(v_Sms_Input,
                               v_Sms_Message_Type,
                               USER,
                               v_Response_Rec,
                               v_Process_Results);

    v_SMS_RESULT := '1';
    FOR rec IN (SELECT Hata_Code,Response_Name, Response_Value FROM TABLE(v_Response_Rec)) LOOP
        IF rec.Hata_Code = '200'
        AND rec.Response_Name = 'code' THEN
            v_SMS_RESULT := rec.Response_Value;
        END IF;
        IF rec.Response_Name = 'message' THEN
            v_SMS_Response := SUBSTR(rec.Response_Value,1,30);
        END IF;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE(v_Sms_Result||':'||v_Sms_Response);
  END;
