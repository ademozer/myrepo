BEGIN
  insert into koc_dmt_agency_tech_emp   
  select * from koc_dmt_agency_tech_emp@opusprep 
     where agent_int_id = 71671
     and identity_no IN('16933598330',
                        '44749093640',
                        '14231290574');
  COMMIT;
END;  
/ 


