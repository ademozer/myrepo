DECLARE 
    v_Yeni_Tp_Sms    Varchar2(1000);
    v_Yeni_Tp_Email  Varchar2(1000);
    Pragma Autonomous_Transaction;
    v_Log Clob;
  Begin
    --sms-mail ataca��m�z yetkili ki�i bilgileri
    For i In (Select a.User_Name,
                     Alz_Web_User_Security.Aesdecrypt(a.User_Password_Aes) Pass,
                     Password_Expired,
                     e.Email,e.Mobile,
                     --'Altan.Firidin@allianz.com.tr' Email,'905337642044' Mobile,
                     --'extern.serdal-turgut@allianz.com.tr' Email,'905322235290' Mobile,
                     b.Name,
                     b.Surname,
                     d.Int_Id,
                     d.Reference_Code,
                     e.Title,
                     e.Company_Code
                From Koc_Dmt_Agents_Ext   e,
                     Web_Sec_System_Users a,
                     Cp_Partners          b,
                     Koc_Cp_Partners_Ext  c,
                     Dmt_Agents           d
               Where a.Customer_Partner_Id = b.Part_Id
                     And b.Part_Id = c.Part_Id
                     And c.Agen_Int_Id = d.Int_Id
                     And d.Int_Id = e.Int_Id
                     And e.Company_Code = '100'
                     And a.User_Name like 'WFIBA%'
                     And trunc(a.create_date) = to_date('23/03/2018','DD/MM/YYYY')     
               Order By d.Reference_Code) Loop

      If i.Mobile Is Not Null Then
        v_Yeni_Tp_Sms := 'De�erli Acentemiz ' || i.Name || ' ' || i.Surname ||
                         ' kullan�c�s�n�n ALLCLUB sistemine giri� i�in kullan�c� ad� ' ||
                         i.User_Name || ' ve �ifresi ' || i.Pass ||
                         ' olu�turulmu�tur. ALLCLUB sistemine giri� yapabilirsiniz. https://acente.allclub.com.tr/AgencyWebPortal';
         --ALZ_TPA_DEFINITION_UTILS.Sendsms(i.Mobile, v_Yeni_Tp_Sms, i.Company_Code);
      End If;
      --mail
      If i.Email Is Not Null Then
        v_Yeni_Tp_Email := i.Mobile || ' nolu cep telefonunuza ' || i.Name || ' ' ||
                           i.Surname ||
                           ' kullan�c�s�n�n ALLCLUB �ifresi sms olarak iletilmi�tir. ' ||
                           i.User_Name ||
                           ' kullan�c�s� ile ALLCLUB sistemine giri� yapmak i�in ' ||
                           ' <a href='||CHR(38)||'quot;https://acente.allclub.com.tr/AgencyWebPortal'||CHR(38)||'quot;>t�klay�n�z </a>';
        --v_Yeni_Tp_Email := i.Mobile || ' nolu cep telefonunuza ' || i.Name || ' ' ;
          ALZ_TPA_DEFINITION_UTILS.Sendemail(i.Email, v_Yeni_Tp_Email, i.Company_Code);
          --DBMS_OUTPUT.PUT_LINE(v_Yeni_Tp_Email);
      End If;
    End Loop;
  Exception
    When Others Then
      Dbms_Output.Put_Line('Hata = ' || Substr(Sqlerrm, 1, 2000));
  End;
