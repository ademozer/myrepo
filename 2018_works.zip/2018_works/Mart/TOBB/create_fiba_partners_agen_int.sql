CREATE TABLE FIBA_PARTNERS2 AS
      select e.part_id, (SELECT USER_NAME 
                           FROM web_sec_system_users@opusprep 
                           where customer_partner_id = e.part_id) USER_NAME, 
                    (select a.int_id 
                                  from dmt_agents@opusprep a
                                 where a.reference_code = (select SUBSTR(u.user_name,11) 
                                                             from web_sec_system_users@opusprep u
                                                            where u.customer_partner_id = e.part_id)) AGENT_INT_ID, 
                    (select t.identity_no 
                                  from koc_dmt_agency_tech_emp@opusprep t
                                 where exists (select 1 from dmt_agents@opusprep a, web_sec_system_users@opusprep u
                                                where u.customer_partner_id = e.part_id
                                                  and a.reference_code = SUBSTR(u.user_name,11)
                                                  and a.int_id = t.agent_int_id
                                                  and SUBSTR(t.identity_no,-4) = SUBSTR(u.user_name,6,4))) IDENTITY_NO
                                                           
        FROM Koc_Cp_Partners_Ext@opusprep e
        WHERE e.part_id in ( 
               select customer_partner_id 
                 from web_sec_system_users@opusprep
                where user_name like 'WFIBA%'
                and user_name NOT IN('WFIBA55941_60039','WFIBA55941_60098'))
          AND e.agen_int_id IS NULL;
          
          
          GRANT SELECT ON FIBA_PARTNERS2 TO PUBLIC;
