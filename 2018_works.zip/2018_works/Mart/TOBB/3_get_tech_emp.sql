BEGIN
--teknik personellerin tobbdan �ekilmesi
FOR rec IN (select signboard_no from koc_dmt_agents_ext
               where int_id IN( 73973,
                                73891,
                                73890,
                                73881,
                                73880,
                                73879,
                                73878,
                                73877,
                                73876,
                                73875,
                                73873,
                                73872,
                                73871,
                                73870,
                                73869,
                                73371,
                                73370,
                                73369
                               )) LOOP                                      
    customer.alz_tobb_ip.main(rec.SIGNBOARD_NO, null);   
 END LOOP;
COMMIT;
END;
/