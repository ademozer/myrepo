BEGIN
  
  delete customer.koc_auth_user_role_rel r
   where exists (select 1 from web_sec_system_users u
    where u.user_name like 'WFIBA%' 
      and r.username = u.user_name     
      and trunc(u.create_date) = to_date('23/03/2018','DD/MM/YYYY'));
      
     insert into customer.koc_auth_user_role_rel(username, role_code, validity_start_date)
     select user_name, 'SAGENT' role_code , create_date 
     from  web_sec_system_users  
     where user_name like 'WFIBA%' 
      and trunc(create_date) = to_date('23/03/2018','DD/MM/YYYY'); 
      
      
     insert into customer.koc_auth_user_role_rel(username, role_code, validity_start_date)
     select user_name, 'WLOGIN' role_code , create_date 
     from  web_sec_system_users  
     where user_name like 'WFIBA%' 
      and trunc(create_date) = to_date('23/03/2018','DD/MM/YYYY'); 
      
     insert into customer.koc_auth_user_role_rel(username, role_code, validity_start_date)
     select user_name, 'WTPAAGENT' role_code , create_date 
     from  web_sec_system_users  
     where user_name like 'WFIBA%' 
      and trunc(create_date) = to_date('23/03/2018','DD/MM/YYYY'); 
  
    COMMIT; 
 END;
/

     
