BEGIN

insert into koc_auth_user_role_rel(username, role_code, validity_start_date)
select user_name username, 'WTPACNOPER' ROLE_CODE, TO_DATE('30/03/2018','DD/MM/YYYY') VALIDITY_START_DATE 
  from web_sec_system_users
 where user_name in ('WFIBA0574_60000','WFIBA8330_60000', 'WFIBA3640_60000');
 
COMMIT;

END;
/ 
