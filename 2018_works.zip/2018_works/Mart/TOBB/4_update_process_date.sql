 BEGIN
   update koc_dmt_agency_tech_emp 
      set process_date = SYSDATE
    where agent_int_id IN(73973,
                          73891,
                          73890,
                          73881,
                          73880,
                          73879,
                          73878,
                          73877,
                          73876,
                          73875,
                          73873,
                          73872,
                          73871,
                          73870,
                          73869,
                          73371,
                          73370,
                          73369
                          );
    COMMIT;
END;
/ 
