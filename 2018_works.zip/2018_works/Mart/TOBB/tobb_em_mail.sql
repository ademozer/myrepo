DECLARE
    p_company_code                 VARCHAR2(100) := '100';
    v_Mail_Input                   Customer.EuroMsg_Mail_Input_Rec;
    v_String_Rec_To                Customer.String_Table := Customer.String_Table();
    v_Response_Rec                 Customer.euromsg_mail_response_table := Customer.EuroMsg_Mail_Response_Table();
    v_Process_Results              Customer.process_result_table;
    v_Parameter_Map                Customer.EuroMsg_Mail_Parameter_Table := Customer.EuroMsg_Mail_Parameter_Table();
    v_subject VARCHAR2(100) := 'Allclub Kullanici Bilgileri';
    p_mail_body VARCHAR2(1000);
    v_Error  VARCHAR2(1000);
    v_Payload                      CLOB;
BEGIN  
  
    p_mail_body :=
                  ' nolu cep telefonunuza ' ||
                  ' kullan�c�s�n�n ALLCLUB �ifresi sms olarak iletilmi�tir. ' ||
                  ' kullan�c�s� ile ALLCLUB sistemine giri� yapmak i�in ' || CHR(38) ||
                  'lt;a href='||CHR(38)||'quot;http://acente.allclub.com.tr/AgencyWebPortal'||CHR(38)||'quot;' || CHR(38) || 'gt;t�klay�n�z' || CHR(38) || 'lt;/a' ||CHR(38) || 'gt;';
    v_String_Rec_To.EXTEND;
    v_String_Rec_To(v_String_Rec_To.COUNT) := String_Rec('extern.adem-ozer@allianz.com.tr');   
   
    v_Parameter_Map.Extend;
    v_Parameter_Map(v_Parameter_Map.Count) := euromsg_mail_parameter_rec ('EM_EMAIL_OTHER', 'true');
    
    v_Mail_Input  := customer.EuroMsg_Mail_Input_Rec(NULL,
                                                      NULL,
                                                      NULL,
                                                      v_String_Rec_to,
                                                      NULL,
                                                      NULL,
                                                      v_subject,
                                                      p_mail_body,
                                                      NULL,
                                                      NULL,
                                                      p_company_code,
                                                      'ALZ_TOBB_USER',
                                                      v_Parameter_Map);
      
      v_Payload := Alz_Euromsg_Utils.Convert_Mail_Input_To_Payload(v_Mail_Input); 
      DBMS_OUTPUT.PUT_LINE(v_Payload);                                                          
      Alz_Euromsg_Utils.Send_Mail(v_Mail_Input,
                                  USER,
                                  v_Response_Rec,
                                  v_Process_Results);
       FOR rec IN (SELECT Hata_Code,Response_Name, Response_Value FROM TABLE(v_Response_Rec)) LOOP
           IF rec.Response_Name = 'message' THEN
               V_ERROR := rec.Response_Value;
           END IF;
       END LOOP;
       FOR rec IN (SELECT * FROM TABLE(v_Process_Results)) LOOP
             V_ERROR := V_ERROR
                     ||' - '||rec.REASON
                     ||' - '||rec.KEY_VALUE1
                     ||' - '||rec.ERROR_ORIGIN;
       END LOOP;
       DBMS_OUTPUT.PUT_LINE(v_Error);
    
 END;
 
