BEGIN
     update Koc_Cp_Partners_Ext e
         set (e.agen_int_id, e.identity_no) = (select agent_int_id,identity_no from ADEMO.FIBA_PARTNERS2@opusdev WHERE PART_ID = e.part_id)
       where e.part_id IN (select PART_ID from ADEMO.FIBA_PARTNERS2@opusdev WHERE AGENT_INT_ID IS NOT NULL);
         
     COMMIT;
END;
/ 
     
