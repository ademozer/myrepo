declare
  -- Non-scalar parameters require additional processing 
  p_kimlikinfo alz_tobb_user.kisi_liste_type;
  p_message VARCHAR2(4000);
  p_acente_kod VARCHAR2(100) := '60159';
  p_tckimlikno VARCHAR2(100) := '13069569099';
  
begin
  -- Call the procedure
  alz_tobb_user.bireysorgubytckimlikno(p_acente_kod => p_acente_kod,
                                       p_tckimlikno => p_tckimlikno,
                                       p_kimlikinfo => p_kimlikinfo,
                                       p_message => p_message);
  IF p_message IS NOT NULL THEN
      Raise_Application_Error(-20200, p_message);
  END IF;                                     
  FOR ndx IN 1..p_kimlikinfo.COUNT LOOP
     DBMS_OUTPUT.PUT_LINE(p_kimlikinfo(ndx).adi||' '||p_kimlikinfo(ndx).soyadi);
  END LOOP;
  DBMS_OUTPUT.PUT_LINE(p_message);
EXCEPTION 
WHEN NO_DATA_FOUND THEN
   p_message := p_message||' NDF'||SQLERRM;
   DBMS_OUTPUT.PUT_LINE(p_message);   
WHEN OTHERS THEN
   p_message := SQLERRM;
   DBMS_OUTPUT.PUT_LINE(p_message);
end;
/
