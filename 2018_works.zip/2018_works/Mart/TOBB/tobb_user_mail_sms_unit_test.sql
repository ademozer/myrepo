DECLARE
  v_yeni_tp_email VARCHAR2(32000);
   v_sms_mail_gsm  VARCHAR2(200) := '5423547375';
   p_employee_name VARCHAR2(200) := 'ADEM';
   p_employee_surname VARCHAR2(200) := '�ZER';
   v_new_user_name VARCHAR2(200) := 'ademo';
PROCEDURE sendemail (p_mail_adress VARCHAR2, p_mail_body VARCHAR2, p_company_code VARCHAR2)
  IS
    v_errnum  NUMBER (5);
  --[ademo
  v_Mail_Input                   Customer.EuroMsg_Mail_Input_Rec;
    v_String_Rec_To                Customer.String_Table := Customer.String_Table();
    v_Response_Rec                 Customer.euromsg_mail_response_table := Customer.EuroMsg_Mail_Response_Table();
    v_Process_Results              Customer.process_result_table;
    v_Parameter_Map                Customer.EuroMsg_Mail_Parameter_Table := Customer.EuroMsg_Mail_Parameter_Table();
  --ademo]
    /*v_dbname  VARCHAR2 (30);
    soap_request VARCHAR2 (32767);
    soap_respond VARCHAR2 (32767);
    http_req  UTL_HTTP.req;
    http_resp UTL_HTTP.resp;
    HOST      VARCHAR2 (30000);
    v_resp_xml XMLTYPE; */
    v_msg     VARCHAR2 (5000);
    v_request VARCHAR2 (4000);
    v_response VARCHAR2 (4000);
    --v_em_campaign_code VARCHAR2 (20); --ademo
    v_subject    VARCHAR2(250); --AliSakalli TPA-FAZ3 TPA_104 - 15.02.2018
  --   Yeni kurulan acente oldu�unda:
  --    v_yeni_acente_mail VARCHAR2 (1000)
  --      := '5**3*5***1 no?lu cep telefonunuza xxxx kullan�c�s�n�n DIGITALL �ifresi sms olarak iletilmi�tir.
  --             XXxx kullan�c�s� ile DIGITALL sistemine giri� yapmak i�in t�klay�n�z? (t�klay�n�za bas�nca DigitALL sayfas�na y�nlendirme olacak.)';
  --    Yeni teknik personel user� olu�turuldu�unda:
  --    v_tp_mail VARCHAR2 (1000)
  --      := '5**3*5***1 no?lu cep telefonunuza xxxx kullan�c�s�n�n DIGITALL �ifresi sms olarak iletilmi�tir.
  --         XXxx kullan�c�s� ile DIGITALL sistemine giri� yapmak i�in t�klay�n�z? (t�klay�n�za bas�nca DigitALL sayfas�na y�nlendirme olacak.)';
  --    Kapat�lan acente i�in:
  --    v_kapatilan_acente_mail VARCHAR2 (1000) := 'xxxx TCKN?li personelinize ait XXxx kullan�c� hesab� kapat�lm��t�r.';
  --    Kapat�lan teknik personeli user� oldu�unda:
  --    v_kapatilan_tp_mail VARCHAR2 (1000) := 'xxxx TCKN?li teknik personelinize ait XXxx kullan�c� hesab� kapat�lm��t�r.';
  BEGIN
  --if p_company_code='045' Then--TPA2 Serdal 2017-12-05 --AliSakalli TPA-FAZ3 TPA_104 - 15.02.2018
    /*BEGIN
      SELECT em_campaign_code
        INTO v_em_campaign_code
        FROM alz_tpa_companies
       WHERE company_code = p_company_code;
    EXCEPTION
      WHEN OTHERS THEN
        v_em_campaign_code := NULL;
    END;*/

    --AliSakalli TPA-FAZ3 TPA_104 - 15.02.2018
    v_subject := NULL;
    IF p_company_code = '045' THEN
      v_subject := 'Allianz DigitALL Kullanici Bilgileri';
    ELSE
      v_subject := 'Allclub Kullanici Bilgileri';
    END IF;

    /*soap_request :=
      '<S:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/" xmlns:S="http://schemas.xmlsoap.org/soap/envelope/">' || '<env:Header/>' ||
      '<S:Body>' || '<ns0:execute xmlns:ns0="gs.az.tr">' || '<arg0>' || '<command>' || '<commandName>SENDMESSAGE</commandName>' ||
      '<commandText>Mesaj G�nder</commandText>' || '</command>' || '<key>' || '</key>' || '<objectData>' || '<fields>' ||
      '<fieldName>obj.emAttachment1.attachmentBody</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment1.attachmentName</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment2.attachmentBody</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment2.attachmentName</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment3.attachmentBody</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment3.attachmentName</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment4.attachmentBody</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment4.attachmentName</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment5.attachmentBody</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment5.attachmentName</fieldName>' || '<value/>' || '</fields>' || '<fields>' || '<fieldName>obj.emBody</fieldName>' ||
      '<value>' || p_mail_body || '</value>' || '</fields>' || '<fields>' || '<fieldName>obj.emMessageType</fieldName>' || '<value>1</value>' ||
      '</fields>' || '<fields>' || '<fieldName>obj.emCampaingCode</fieldName>' || '<value>' || v_em_campaign_code || '</value>' || '</fields>' ||
      '<fields>' || '<fieldName>obj.emSubject</fieldName>' || '<value>' || v_subject || '</value>' || '</fields>' || '<fields>'
      || '<fieldName>obj.emTo</fieldName>' || '<value>' || p_mail_adress || '</value>' || --Seda.Guven@allianz.com.tr
                                                                                         '</fields>' ||
      '<objcetName>ServiceEuroMessageObject</objcetName>' || '</objectData>' || '<processCode>AZS_EURO_MESSAGE</processCode>' ||
      '<processStepName>EUROMESSAGESENDER</processStepName>' || '</arg0>' || '</ns0:execute>' || '</S:Body>' || '</S:Envelope>'; --p_mail_adress mail eklenecek
    v_errnum := 1;
    BEGIN
      --SELECT name INTO v_dbname FROM v$database;
      SELECT get_db_name INTO v_dbname FROM dual; --AliSakalli TPA_104
    EXCEPTION
      WHEN OTHERS THEN
        v_dbname := NULL;
    END;

    IF v_dbname NOT IN ('OPUSDATA') THEN
      HOST   := 'http://test-services.allianz.com.tr/GenericService/GPE?wsdl'; --'http://irisapp1tnd1.yksigorta.com.tr:9090/GenericService/GPE?wsdl';
    ELSE
      --HOST := 'https://services.allianz.com.tr/gws/GPE?wsdl';
      HOST   := 'http://esb.allianz.com.tr:12000/external/gws/GPE?wsdl'; --'http://services.allianz.com.tr/gws/GPE?wsdl';  --'http://10.70.2.85:17101/gws/GPE?wsdl';
    END IF;

    v_request := SUBSTR (soap_request, 1, 3999);
    http_req := UTL_HTTP.begin_request (HOST, 'POST', 'HTTP/1.1');
    v_errnum := 2;
    UTL_HTTP.set_header (http_req, 'Keep-Alive', 'TE');
    v_errnum := 3;
    UTL_HTTP.set_header (http_req, 'Connection', 'keep-alive');
    v_errnum := 4;
--    UTL_HTTP.set_header (http_req, 'Content-Type', 'text/xml; charset=UTF-8');
     UTL_HTTP.SET_HEADER (http_req,
                        'Content-Type',
                        'text/xml; charset=ISO-8859-9');

    v_errnum := 5;
    UTL_HTTP.set_header (http_req, 'Content-Length', LENGTH (soap_request));
    v_errnum := 6;
    -- UTL_HTTP.set_header(http_req, 'SOAPAction', 'http://kpsbs.sbm.org.tr//kpsAileSorguByTcKimlikNo');
    v_errnum := 7;
    UTL_HTTP.write_text (http_req, soap_request);
    v_errnum := 8;
    http_resp := UTL_HTTP.get_response (http_req);
    v_errnum := 9;
    UTL_HTTP.read_text (http_resp, soap_respond, 32000);
    v_errnum := 10;
    UTL_HTTP.end_response (http_resp);
    v_errnum := 11;
    --soap_respond := Replace(Replace(Replace(soap_respond, 'ns2:', ''), ' xsi:nil="1"', ''), 'S:', '');
    v_response := SUBSTR (soap_respond, 1, 3999);
    v_errnum := 12;
    v_resp_xml := xmltype (soap_respond);
    v_errnum := 13;
    v_errnum := 14; --ba�ar�l�
    */ 
  v_errnum := 1;
  v_String_Rec_To.EXTEND;
    v_String_Rec_To(v_String_Rec_To.COUNT) := String_Rec(p_mail_adress);   
    v_errnum := 2;
    v_Parameter_Map.Extend;
    v_Parameter_Map(v_Parameter_Map.Count) := euromsg_mail_parameter_rec ('EM_EMAIL_OTHER', 'true');
    v_errnum := 3;
    v_Mail_Input  := customer.EuroMsg_Mail_Input_Rec(NULL,
                                                      NULL,
                                                      NULL,
                                                      v_String_Rec_to,
                                                      NULL,
                                                      NULL,
                                                      v_subject,
                                                      p_mail_body,
                                                      NULL,
                                                      NULL,
                                                      p_company_code,
                                                      'ALZ_TOBB_USER',
                                                      v_Parameter_Map);
      v_errnum := 4;
      v_request := Alz_Euromsg_Utils.Convert_Mail_Input_To_Payload(v_Mail_Input); 
      v_errnum := 5;                                                       
      Alz_Euromsg_Utils.Send_Mail(v_Mail_Input,
                                  USER,
                                  v_Response_Rec,
                                  v_Process_Results);
    v_errnum := 5;                
       FOR rec IN (SELECT Hata_Code,Response_Name, Response_Value FROM TABLE(v_Response_Rec)) LOOP
           IF rec.Response_Name = 'message' THEN
               v_response := rec.Response_Value;
           END IF;
       END LOOP;
     v_errnum := 6;
       FOR rec IN (SELECT * FROM TABLE(v_Process_Results)) LOOP
             v_response := v_response
                     ||' - '||rec.REASON
                     ||' - '||rec.KEY_VALUE1
                     ||' - '||rec.ERROR_ORIGIN;
       END LOOP;
     v_errnum := 7;
    --basar�l� mailleri tutuluyor
    INSERT INTO alz_tobb_user_hist (
                  gsm
                , email
                , v_errnum
                , err_text
                , creation_date
                , request
                , response)
         VALUES (NULL
               , p_mail_adress
               , v_errnum
               , 'sendmail/basarili'
               , SYSDATE
               , v_request
               , v_response);

    COMMIT;
  --end if;--TPA2 Serdal 2017-12-05 --AliSakalli TPA-FAZ3 TPA_104 - 15.02.2018
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_msg  := SUBSTR (SQLERRM, 1, 3000);

      INSERT INTO alz_tobb_user_error (
                    v_errnum
                  , err_text
                  , creation_date
                  , request
                  , response
                  , email
                  , process)
           VALUES (v_errnum
                 , v_msg
                 , SYSDATE
                 , v_request
                 , v_response
                 , p_mail_adress
                 , 'ALZ_TOBB_USER/sendemail');

      COMMIT;
      /*BEGIN
        UTL_HTTP.end_response (http_resp);
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;*/
  END sendemail;
  PROCEDURE sendsms (p_gsm VARCHAR2, p_message_body VARCHAR2, p_company_code VARCHAR2)
  IS
    v_errnum  NUMBER (5);
    /*v_dbname  VARCHAR2 (30);
    soap_request VARCHAR2 (32767);
    soap_respond VARCHAR2 (32767);
    http_req  UTL_HTTP.req;
    http_resp UTL_HTTP.resp;
    HOST      VARCHAR2 (30000);
    v_resp_xml XMLTYPE;*/
	v_Response_Rec                 Customer.euromsg_mail_response_table := Customer.EuroMsg_Mail_Response_Table();
    v_Process_Results              Customer.process_result_table;
	v_Sms_Input                    Customer.EuroMsg_Sms_Input_Rec;
    v_Sms_Message_Type             NUMBER := 1;
    v_Parameter_Map                Customer.EuroMsg_Mail_Parameter_Table := Customer.EuroMsg_Mail_Parameter_Table();
    v_Sms_Result                   VARCHAR2(1000);
    v_Sms_Response                 VARCHAR2(1000);
    v_Payload                      CLOB;
    v_msg     VARCHAR2 (5000);
    v_request VARCHAR2 (4000);
    v_response VARCHAR2 (4000);  
   -- v_em_campaign_code VARCHAR2 (20); --ademo
  --    yeni kurulan acente mesaj i�eri�i
  --    v_yeni_acente_msg VARCHAR2 (500) := 'abcdef12 �ifreniz ve XXxx kullan�c� ad�n�z ile DIGITALL sistemine giri� yapabilirsiniz.';
  --    yeni teknik user olusturuldugunda
  --    v_yeni_tuser_msg VARCHAR2 (500)
  --      := '5**3*5***1 nolu cep telefonunuza xxxx kullan�c�s�n�n DIGITALL �ifresi sms olarak iletilmi�tir.
  --                   XXxx kullan�c�s� ile DIGITALL sistemine giri� yapmak i�in t�klay�n�z? (t�klay�n�za bas�nca DigitALL sayfas�na y�nlendirme olacak.)';
  --    kapat�lan acente i�in
  --    v_kapat�lan_acente_msg VARCHAR2 (500) := 'xxxx TCKN?li personelinize ait XXxx kullan�c� hesab� kapat�lm��t�r.';
  --    kapat�lan teknik personel user�
  --    v_kapat�lan_tp_new VARCHAR2 (500) := 'xxxx TCKN?li teknik personelinize ait XXxx kullan�c� hesab� kapat�lm��t�r.';
  BEGIN
  --if p_company_code='045' Then--TPA2 Serdal 2017-12-05 --AliSakalli TPA-FAZ3 TPA_104 - 15.02.2018
    /*BEGIN
      SELECT em_campaign_code
        INTO v_em_campaign_code
        FROM alz_tpa_companies
       WHERE company_code = p_company_code;
    EXCEPTION
      WHEN OTHERS THEN
        v_em_campaign_code := NULL;
    END;
    soap_request :=
      '<S:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/" xmlns:S="http://schemas.xmlsoap.org/soap/envelope/">' || '<env:Header/>' ||
      '<S:Body>' || '<ns0:execute xmlns:ns0="gs.az.tr">' || '<arg0>' || '<command>' || '<commandName>SENDMESSAGE</commandName>' ||
      '<commandText>Mesaj G�nder</commandText>' || '</command>' || '<key>' || '</key>' || '<objectData>' || '<fields>' ||
      '<fieldName>obj.emAttachment1.attachmentBody</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment1.attachmentName</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment2.attachmentBody</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment2.attachmentName</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment3.attachmentBody</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment3.attachmentName</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment4.attachmentBody</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment4.attachmentName</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment5.attachmentBody</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment5.attachmentName</fieldName>' || '<value/>' || '</fields>' || '<fields>' || '<fieldName>obj.emBody</fieldName>' ||
      '<value>' || p_message_body || '</value>' || '</fields>' || '<fields>' || '<fieldName>obj.emMessageType</fieldName>' || '<value>0</value>' ||
      '</fields>' || '<fields>' || '<fieldName>obj.emSubject</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emTo</fieldName>' || '<value>' || p_gsm || '</value>' || --seda.g�ven canl�da de�i�ecek 905346675266
                                                                              '</fields>' || '<fields>' ||
      '<fieldName>obj.emCampaingCode</fieldName>' || '<value>' || v_em_campaign_code || '</value>' || --ENGINT campaign code added
                                                                                                     '</fields>' ||
      '<objcetName>ServiceEuroMessageObject</objcetName>' || '</objectData>' || '<processCode>AZS_EURO_MESSAGE</processCode>' ||
      '<processStepName>EUROMESSAGESENDER</processStepName>' || '</arg0>' || '</ns0:execute>' || '</S:Body>' || '</S:Envelope>';
    v_errnum := 1;
    BEGIN
      --SELECT name INTO v_dbname FROM v$database;
      SELECT get_db_name INTO v_dbname FROM dual; --AliSakalli TPA_104
    EXCEPTION
      WHEN OTHERS THEN
        v_dbname := NULL;
    END;

    IF v_dbname NOT IN ('OPUSDATA') THEN
      HOST   := 'http://test-services.allianz.com.tr/GenericService/GPE?wsdl'; --'http://irisapp1tnd1.yksigorta.com.tr:9090/GenericService/GPE?wsdl';
    ELSE
      -- HOST := 'https://services.allianz.com.tr/gws/GPE?wsdl'; sonradan testi yap�l�p d�zeltilecek
      HOST   := 'http://esb.allianz.com.tr:12000/external/gws/GPE?wsdl'; --'http://services.allianz.com.tr/gws/GPE?wsdl'; --'http://10.70.2.85:17101/gws/GPE?wsdl';
    END IF;

    v_request := SUBSTR (soap_request, 1, 3999);
    http_req := UTL_HTTP.begin_request (HOST, 'POST', 'HTTP/1.1');
    v_errnum := 2;
    UTL_HTTP.set_header (http_req, 'Keep-Alive', 'TE');
    v_errnum := 3;
    UTL_HTTP.set_header (http_req, 'Connection', 'keep-alive');
    v_errnum := 4;
    --UTL_HTTP.set_header (http_req, 'Content-Type', 'text/xml; charset=UTF-8');
    UTL_HTTP.SET_HEADER (http_req,
                        'Content-Type',
                        'text/xml; charset=ISO-8859-9');
    v_errnum := 5;
    UTL_HTTP.set_header (http_req, 'Content-Length', LENGTH (soap_request));
    v_errnum := 6;
    -- UTL_HTTP.set_header(http_req, 'SOAPAction', 'http://kpsbs.sbm.org.tr//kpsAileSorguByTcKimlikNo');
    v_errnum := 7;
    UTL_HTTP.write_text (http_req, soap_request);
    v_errnum := 8;
    http_resp := UTL_HTTP.get_response (http_req);
    v_errnum := 9;
    UTL_HTTP.read_text (http_resp, soap_respond, 32000);
    v_errnum := 10;
    UTL_HTTP.end_response (http_resp);
    v_errnum := 11;
    soap_respond := REPLACE (REPLACE (REPLACE (soap_respond, 'ns2:', ''), ' xsi:nil="1"', ''), 'S:', '');
    v_response := SUBSTR (soap_respond, 1, 3999);
    v_errnum := 12;
    v_resp_xml := xmltype (soap_respond);
    v_errnum := 13;
    v_errnum := 14; --ba�ar�l�
    */
	--[ademo
	v_errnum := 1;
	v_Parameter_Map.Extend;
    v_Parameter_Map(v_Parameter_Map.Count) := euromsg_mail_parameter_rec ('EM_SMS_OTHER', 'true'); --allclubdan g�nderim i�in
    v_errnum := 2;
    v_Sms_Input :=  Customer.EuroMsg_Sms_Input_Rec(p_gsm,
                                                   p_message_body,
                                                   p_company_code,
                                                   'ALZ_TOBB_USER_'||p_gsm,
                                                   v_Parameter_Map);
    v_errnum := 3;
    v_request := Alz_Euromsg_Utils.Convert_Sms_Input_To_Payload(v_Sms_Input);
    v_errnum := 4;
    Alz_Euromsg_Utils.Send_Sms(v_Sms_Input,
                               v_Sms_Message_Type,
                               USER,
                               v_Response_Rec,
                               v_Process_Results);
    v_errnum := 5;
    v_sms_result := '1';
    FOR rec IN (SELECT Hata_Code,Response_Name, Response_Value FROM TABLE(v_Response_Rec)) LOOP
        IF rec.Hata_Code = '200'
        AND rec.Response_Name = 'code' THEN
            v_sms_result := rec.Response_Value;
        END IF;
        IF rec.Response_Name = 'message' THEN
            v_sms_response := SUBSTR(rec.Response_Value,1,30);
        END IF;
    END LOOP;
	v_errNum := 6;
	v_response := v_sms_result || '-' || v_sms_response;
	--ademo]
    --basar�l� mesajlar tutuluyor
    INSERT INTO alz_tobb_user_hist (
                  gsm
                , email
                , v_errnum
                , err_text
                , creation_date
                , request
                , response)
         VALUES (p_gsm
               , NULL
               , v_errnum
               , 'sendsms/basarili'
               , SYSDATE
               , v_request
               , v_response);

    COMMIT;
  --end if;--TPA2 Serdal 2017-12-05 --AliSakalli TPA-FAZ3 TPA_104 - 15.02.2018
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_msg  := SUBSTR (SQLERRM, 1, 3000);

      INSERT INTO alz_tobb_user_error (
                    v_errnum
                  , err_text
                  , creation_date
                  , request
                  , response
                  , gsm
                  , process)
           VALUES (v_errnum
                 , v_msg
                 , SYSDATE
                 , v_request
                 , v_response
                 , p_gsm
                 , 'ALZ_TOBB_USER/sendsms');

      COMMIT;
      /*BEGIN
        UTL_HTTP.end_response (http_resp);
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;*/
  END sendsms;
 
  BEGIN
     v_yeni_tp_email :=
                  v_sms_mail_gsm || ' nolu cep telefonunuza ' || p_employee_name || ' ' || p_employee_surname ||
                  ' kullan�c�s�n�n ALLCLUB �ifresi sms olarak iletilmi�tir. ' || v_new_user_name ||
                  ' kullan�c�s� ile ALLCLUB sistemine giri� yapmak i�in ' || CHR(38) ||
                  'lt;a href='|| CHR(38) || 'quot;https://acente.allclub.com.tr/AgencyWebPortal'|| CHR(38) || 'quot;' || CHR(38) || 'gt;t�klay�n�z' || CHR(38) || 'lt;/a' || CHR(38) || 'gt;';
    sendemail('extern.adem-ozer@allianz.com.tr', v_yeni_tp_email, '100');
   -- sendsms('905423547375','deneme','100');
  END;
