 DECLARE

 PROCEDURE createusermain(p_Merkez VarChar2:='H')--TPA2 Serdalt
  IS
    v_new_user_name VARCHAR2 (30);
    v_opus_user_name VARCHAR2 (30);
    v_reference_code VARCHAR (15);
    v_salesperson_emp_id VARCHAR (100) := NULL;
    v_yet_cont NUMBER;
    v_refcur  alz_web_user_utils.refcur;
    v_process_results customer.process_result_table;
    v_carray  customer.char_array;
    i         NUMBER := 0;
    v_ayk     NUMBER;
    vc_reference_code VARCHAR2 (200);
    v_new_password VARCHAR2 (100);
    v_user_control NUMBER;
    v_yeni_tp_sms VARCHAR2 (1000);
    v_yeni_tp_email VARCHAR2 (1000);
    v_sms_mail_tckn VARCHAR2 (100);
    v_sms_mail_gsm VARCHAR2 (100);
    v_sms_mail_email VARCHAR2 (100);
    v_yetki   VARCHAR2 (30);
    v_tahsilat_yetki VARCHAR2 (30);
    v_ornek_user_name VARCHAR2 (30);
    v_errnum  NUMBER (5);
    v_errtext VARCHAR2 (4000);
    v_kl      alz_tobb_user.kisi_liste_type;
    p_message VARCHAR2 (32467);
    v_bes_ctrl NUMBER;
    v_trafik_ctrl NUMBER;
    v_agen_int_id NUMBER; 
    --Web user yarat�lacak teknik personel listesi
    CURSOR c_tp
    IS -- ENGINT
      SELECT a.agent_int_id
           , a.emp_id_no
           , a.identity_no
           , a.employee_type
           , a.employee_name
           , a.employee_surname
           , a.validity_start_date
           , a.validity_end_date
           , a.userid
           , a.process_date
           , NVL (x.company_code, '045') company_code -- Default Allianz ENGINT
        FROM koc_dmt_agency_tech_emp a
           , koc_dmt_agents_ext x
       WHERE TRUNC (a.process_date) = TRUNC (SYSDATE) -- Engint Neden Process gece 12 de mi cal�s�yor ??
         AND (a.validity_end_date IS NULL OR a.validity_end_date > TRUNC (SYSDATE))
        -- AND ((p_Merkez='H' and x.signboard_no IS NOT NULL) or (p_Merkez='E' AND x.signboard_no IS NULL))--TPA2 Serdal
         AND x.int_id = a.agent_int_id
         AND ( (NVL (x.company_code, '045') = '045' AND x.mis_sub_group IN ('11', '12', '14', '61', '62', '63', '140'))
           OR  (NVL (x.company_code, '045') <> '045'
            AND EXISTS
                  (SELECT 1
                     FROM alz_tpa_company_mis_rel cmr
                    WHERE NVL (x.company_code, '045') = cmr.company_code
                      AND x.mis_main_group = cmr.mis_main_group
                      AND x.mis_sub_group = cmr.mis_sub_group
                      AND cmr.agent_type = 'AGENT'
                      AND SYSDATE BETWEEN TRUNC (cmr.validity_start_date) AND NVL (cmr.validity_end_date, SYSDATE + 1))))
         AND NOT EXISTS (SELECT 1 
                           FROM koc_cp_partners_ext e, web_sec_system_users u 
                          WHERE e.part_id = u.customer_partner_id 
                            AND e.agen_int_id = a.agent_int_id
                            AND e.identity_no = a.identity_no);   
    --
    CURSOR cr_ayk
    IS
      SELECT DISTINCT int_id
                    , tckn
        FROM koc_dmt_agents_ext_hist
       WHERE tckn IS NOT NULL
         AND (process_flag = 'I' OR (process_flag = 'U' AND updated_date = TRUNC (SYSDATE)))
         AND TRUNC (process_date) = TRUNC (SYSDATE)
         AND 1 = 2;

    --acente yetkili ki�isi i�in user olu�turulmayacak karar� al�nd�.
    --Sonraki bir zamanda bu karar de�i�irse diye bu k�sm� kald�rm�yoruz 1=2 ko�ulu koyuyoruz
    CURSOR c_role (
      p_int_id NUMBER
    , p_user_name VARCHAR2)
    IS
      SELECT DISTINCT role_code
        FROM koc_auth_user_role_rel
       WHERE username = p_user_name
         AND role_code NOT IN ('DAPMERKEZ', 'WPPPAGENT')
         AND (validity_end_date IS NULL OR TRUNC (validity_end_date) > TRUNC (SYSDATE));

    --DAPMERKEZ rol� belli employee type kullan�c�lar�na insert den sonra ayr�ca veriliyor
    --BES yetkisi WPPPAGENT rolu ile verilir, ekrandan kontrol le verilmesi gerekti�inden acente yetkili ki�i �zerinden kontrol ile kod i�inde veriliyor
    CURSOR c_yetki (p_int_id NUMBER)
    IS
      SELECT DISTINCT koc_dmt_utils.dmt_company_type (ext.int_id) --yetki
                    , NVL (ext.collection_authority, '9999999999') --tahsilat yetki
        FROM koc_dmt_agents_ext ext
       WHERE ext.int_id = p_int_id;

    --Acentenin yetkisine g�re bize verilen �rnek user rolleri al�yoruz.
    CURSOR c_ornek_user (p_yetki VARCHAR2, p_tahsilat_yetki VARCHAR2)
    IS
      SELECT a.acente_user_name
        FROM alz_tobb_ornek_userrole a
       WHERE a.yetki_kod = p_yetki AND a.tahsilat_yetki = DECODE (p_tahsilat_yetki,  'SADECE KK', 'KK1',  'SADECE KK2', 'KK2',  'A��k'); --mail d�n���ne g�re de�i�tirilecek
  BEGIN
    v_errnum := 1;

    -- user name alan�na v_new_user_name'i g�nderece�iz
    -- G�nl�k TP listesi
    FOR cr IN c_tp LOOP
      BEGIN
        v_errnum := 2;
        v_bes_ctrl := NULL;
        v_trafik_ctrl :=NULL;
        --7.T�m bu i�lemler acente yetkilisi bilgisinin dolu oldu�u acenteler �zerinden yap�lacakt�r.
        --Acente yetkili bilgisi dolumu kontrolu yap�yoruz
        BEGIN
          SELECT COUNT (*)
            INTO v_yet_cont
            FROM koc_dmt_agents_ext
           WHERE int_id = cr.agent_int_id;
        EXCEPTION
          WHEN OTHERS THEN
            v_yet_cont := 0;
        END;
        v_errnum := 3;
       
        IF v_yet_cont <> 0 THEN --Acente yetkili bilgisi dolumu kontrolu yap�yoruz
          v_errnum := 4;
          --v_ornek_user_name := 'WDA01_677';
          IF cr.company_code = '045' THEN
              v_yetki := NULL;
              v_tahsilat_yetki := NULL;
              v_ornek_user_name := NULL;  
              --userdan role gidebilmek i�in yetki ve tahsilat yetki bilgilerini al�yoruz
              OPEN c_yetki (cr.agent_int_id);
              FETCH c_yetki
              INTO v_yetki, v_tahsilat_yetki;
              CLOSE c_yetki;
              
              --�rnek user_name'i al�yoruz
              OPEN c_ornek_user (v_yetki, v_tahsilat_yetki);
              FETCH c_ornek_user INTO v_ornek_user_name;
              CLOSE c_ornek_user;
               
              -- User� olu�turulan TP'in acente �zerinden/�rnek user �zerinden role al�n�p,olu�turulan user'a at�l�yor
              v_carray := customer.char_array (); -- Initiliazing

              FOR cr_role IN c_role (cr.agent_int_id, v_ornek_user_name) LOOP
                BEGIN
                  v_errnum := 5;                    
                  v_carray.EXTEND;
                  v_carray (v_carray.LAST) := cr_role.role_code;
                END;
              END LOOP;

          --
          ELSE 
              v_carray := customer.char_array ();
              v_carray.EXTEND;
              v_carray (v_carray.LAST) := 'SAGENT';
              v_carray.EXTEND;
              if p_Merkez<>'E' Then--TPA2 Serdal               
                 v_carray (v_carray.LAST) := 'WTPAAGENT';
              else              
                 v_carray (v_carray.LAST) := 'WTPACNOPER';
              end if;
              v_carray.EXTEND;
              v_carray (v_carray.LAST) := 'WLOGIN';--TPA2 Serdal
          END IF;

          --
          v_errnum := 6;
          --
          BEGIN
            SELECT DISTINCT reference_code
              INTO v_reference_code
              FROM dmt_agents
             WHERE int_id = cr.agent_int_id;
          EXCEPTION
            WHEN OTHERS THEN
              v_reference_code := NULL;
          END;
          --burada mail-sms de ayk isim soyisim alabilmek i�in kullan�yoruz

          BEGIN
            v_errnum := 6.0;
            alz_tobb_user.bireysorgubytckimlikno (v_reference_code, cr.identity_no, v_kl
                                                , p_message);
          --  dbms_output.put_line(v_kl(1).adi||v_kl(1).soyadi||' and '|| p_Message);
        --[ademo
        IF p_message IS NOT NULL THEN
          Raise_Application_Error(-20200, p_message);
      END IF;
      --ademo]
          EXCEPTION
            WHEN OTHERS THEN  --ademo
              v_errnum := 6.01;
              v_errtext := SUBSTR ('BireySorguByTcKimlikNo - ' || SQLERRM, 1, 4000);

              INSERT INTO alz_tobb_user_error (
                            agent_int_id
                          , identity_no
                          , v_errnum
                          , err_text
                          , creation_date)
                   VALUES (cr.agent_int_id
                         , cr.identity_no
                         , v_errnum
                         , v_errtext
                         , TRUNC (SYSDATE));
          END;

          v_errnum := 7;
          BEGIN
            SELECT DISTINCT reference_code
              INTO vc_reference_code
              FROM dmt_agents
             WHERE int_id = (SELECT DISTINCT parent_agent_int_id
                               FROM koc_dmt_agents_ext
                              WHERE int_id = cr.agent_int_id);
          EXCEPTION
            WHEN OTHERS THEN
              vc_reference_code := 'X';

              INSERT INTO alz_tobb_user_error (
                            agent_int_id
                          , identity_no
                          , v_errnum
                          , err_text
                          , creation_date)
                   VALUES (cr.agent_int_id
                         , cr.identity_no
                         , v_errnum
                         , 'User olustutulmadan �nce Partaj Bulunamad�.'
                         , SYSDATE);
          END;
          alz_tobb_user.createusername (v_new_user_name, v_opus_user_name, cr.identity_no
                                      , vc_reference_code, cr.company_code); --ENGINT
          v_errnum := 8;
          alz_web_user_utils.createnewwebuser2 (p_opus_user_name => v_opus_user_name, p_user_name => v_new_user_name, p_email => NULL
                                              , p_partner_id => 0, p_name => cr.employee_name, p_surname => cr.employee_surname
                                              , p_tax_number => NULL, p_user_type => 0, p_reference_code => v_reference_code
                                              , p_insert_user_name => 'ADEMO', p_role_table => v_carray, p_hsbc_registry_no => NULL
                                              , p_tck_no => cr.identity_no, p_result_cur => v_refcur, p_process_results => v_process_results
                                              , p_tech_staff => '1', p_bgd_user => '0', p_call_center => '0'
                                              , p_father_name => NULL, p_mother_name => NULL, p_addresse => NULL
                                              , p_birth_place => NULL, p_marital_status => NULL, p_passport_number => NULL
                                              , p_employee_id => NULL, p_mobile_phone => NULL, p_domain_user_name => NULL
                                              , p_company_code => cr.company_code);
           DBMS_OUTPUT.PUT_LINE('USER_NAME='||v_new_user_name);                                              
           
          IF cr.company_code = '045' THEN
           /* IF (cr.employee_type IN ('1', '2', '4', '8', '9', '11')) THEN
              INSERT INTO koc_auth_user_role_rel (
                            username
                          , role_code
                          , validity_start_date)
                   VALUES (v_new_user_name
                         , 'DAPMERKEZ'
                         , TRUNC (SYSDATE) - 3);
            END IF;*/

            --user olusurken hatalar select * from alz_error_log_table tablosunda tutuluyor
            --Bes yetkisi kontrol edilip,bes rolu verilecek
            --Trafik rolu kontrol edilip, trafik rolu verilecek
            BEGIN
              SELECT DISTINCT a.is_bes_authority,a.AGENCY_MENU_TYPE
                INTO v_bes_ctrl,v_trafik_ctrl
                FROM koc_dmt_agents_ext a
               WHERE a.int_id = cr.agent_int_id;
            EXCEPTION
              WHEN OTHERS THEN
                v_bes_ctrl := 0;
                v_trafik_ctrl :=0;
            END;

            IF (v_bes_ctrl = 1) THEN
              BEGIN
                INSERT INTO koc_auth_user_role_rel (
                              username
                            , role_code
                            , validity_start_date)
                     VALUES (v_new_user_name
                           , 'WPPPAGENT'
                           , TRUNC (SYSDATE) - 3);
                /* ALZ_WEB_USER_UTILS.log_user_role_history(p_user_name       => v_new_user_name,
                              p_role_code       => 'WPPPAGENT',
                              p_action_type     => 'I',
                              p_update_user     => v_tobb_user_name,
                              p_process_results => v_process_results);*/
              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;
            END IF;

            IF (v_trafik_ctrl = 1) THEN
              BEGIN
                INSERT INTO koc_auth_user_role_rel (
                              username
                            , role_code
                            , validity_start_date)
                     VALUES (v_new_user_name
                           , 'WPMTPLMADF'
                           , TRUNC (SYSDATE) - 3);

/*ALZ_WEB_USER_UTILS.log_user_role_history(p_user_name       => v_new_user_name,
                              p_role_code       => 'WPMTPLMADF',
                              p_action_type     => 'I',
                              p_update_user     => v_tobb_user_name,
                              p_process_results => v_process_results);*/
                INSERT INTO koc_auth_user_role_rel (
                          username
                        , role_code
                        , validity_start_date)
                 VALUES (v_new_user_name
                       , 'WPTAGENTP'
                       , TRUNC (SYSDATE) - 3);
                 /*ALZ_WEB_USER_UTILS.log_user_role_history(p_user_name       => v_new_user_name,
                              p_role_code       => 'WPTAGENTP',
                              p_action_type     => 'I',
                              p_update_user     => v_tobb_user_name,
                              p_process_results => v_process_results);*/
              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;
            END IF;

            --Bes ve trafik yetkisi kontrol edilip,bes rolu verilecek
            v_errnum := 9;
            COMMIT;
          ELSE 
              DBMS_OUTPUT.PUT_LINE('post_create..TPA');
              BEGIN
                  v_agen_int_id := 0;
                  
                  SELECT MAX(AGEN_INT_ID) 
                    INTO v_agen_int_id 
                   FROM koc_cp_partners_ext 
                   WHERE part_id IN (select customer_partner_id 
                                       from web_sec_system_users 
                                      where user_name = v_new_user_name);
                   
                  IF NVL(v_agen_int_id,0) = 0 THEN 
                    
                      UPDATE koc_cp_partners_ext
                         SET agen_int_id = cr.agent_int_id,
                             identity_no = cr.identity_no
                       WHERE part_id IN (select customer_partner_id 
                                           from web_sec_system_users 
                                          where user_name = v_new_user_name);                                           
                         
                    v_errnum := 16;
                    v_errtext := 'Unsur Bilgileri Eksik Olu�tu';
                   
                   INSERT INTO alz_tobb_user_error (
                            agent_int_id
                          , identity_no
                          , v_errnum
                          , err_text
                          , creation_date
                          , gsm
                          , process)
                   VALUES (cr.agent_int_id
                         , cr.identity_no
                         , v_errnum
                         , v_errtext
                         , TRUNC (SYSDATE)
                         , v_sms_mail_gsm
                         , 'ALZ_TOBB_USER/CreateUserMain/koc_dmt_agents_ext agen_int_id update edilmedi');
                     COMMIT;    
                  END IF;
              EXCEPTION 
              WHEN OTHERS THEN
                 --DBMS_OUTPUT.PUT_LINE('hata');
                 v_errnum := 17;
                  v_errtext := 'Unsur Bilgileri Eksik Olu�tu'||SUBSTR(SQLERRM,1,100);
                   
                   INSERT INTO alz_tobb_user_error (
                            agent_int_id
                          , identity_no
                          , v_errnum
                          , err_text
                          , creation_date
                          , gsm
                          , process)
                   VALUES (cr.agent_int_id
                         , cr.identity_no
                         , v_errnum
                         , v_errtext
                         , TRUNC (SYSDATE)
                         , v_sms_mail_gsm
                         , 'ALZ_TOBB_USER/CreateUserMain/koc_dmt_agents_ext agen_int_id update edilmedi');
              END;
          END IF;

          --user olustumu kontrolu yap�yoruz,olusan kisiler i�in mail sms g�nderiyoruz
          BEGIN
            SELECT COUNT (*)
              INTO v_user_control
              FROM web_sec_system_users
             WHERE user_name = v_new_user_name AND TRUNC (create_date) = TRUNC (SYSDATE);
          EXCEPTION
            WHEN OTHERS THEN
              v_user_control := 0;
          END;

          IF v_user_control <> 0 THEN
            --sms-mail ataca��m�z yetkili ki�i bilgileri
            BEGIN
              SELECT tckn
                   , mobile
                   , email
                INTO v_sms_mail_tckn
                   , v_sms_mail_gsm
                   , v_sms_mail_email
                FROM koc_dmt_agents_ext a
               WHERE a.int_id = cr.agent_int_id;
            EXCEPTION
              WHEN OTHERS THEN
                v_sms_mail_tckn := NULL;
                v_sms_mail_gsm := NULL;
                v_sms_mail_email := NULL;
            END;
            v_errnum := 10;
            BEGIN
              SELECT alz_web_user_security.aesdecrypt (a.user_password_aes)
                INTO v_new_password
                FROM web_sec_system_users a
               WHERE user_name = v_new_user_name;
            EXCEPTION
              WHEN OTHERS THEN
                v_new_password := NULL;
            END;

            IF v_sms_mail_tckn IS NOT NULL AND v_sms_mail_gsm IS NOT NULL THEN
              v_errnum := 11;
              --v_yeni_tp_sms := v_sms_mail_gsm||' nolu cep telefonunuza '||v_new_user_name||' kullan�c�s�n�n DIGITALL �ifresi sms olarak iletilmi�tir. '||v_new_password ||' �ifreniz ve '|| v_new_user_name||' kullan�c�s� ile DIGITALL sistemine giri� yapmak i�in t�klay�n�z. https://digitall.allianz.com.tr';
              v_yeni_tp_sms :=
                'De�erli Acentemiz ' || cr.employee_name || ' ' || cr.employee_surname ||
                ' kullan�c�s�n�n DIGITALL sistemine giri� i�in kullan�c� ad� ' || v_new_user_name || ' ve �ifresi ' || v_new_password ||
                ' olu�turulmu�tur. DIGITALL sistemine giri� yapabilirsiniz. https://digitall.allianz.com.tr';

              IF cr.company_code <> '045' THEN
                v_yeni_tp_sms :=
                  'De�erli Acentemiz ' || cr.employee_name || ' ' || cr.employee_surname ||
                  ' kullan�c�s�n�n ALLCLUB sistemine giri� i�in kullan�c� ad� ' || v_new_user_name || ' ve �ifresi ' || v_new_password ||
                  ' olu�turulmu�tur. ALLCLUB sistemine giri� yapabilirsiniz. https://acente.allclub.com.tr/AgencyWebPortal';
              END IF;

              --alz_tobb_user.sendsms (v_sms_mail_gsm, v_yeni_tp_sms, cr.company_code); -- ENGINT
            ELSE
              INSERT INTO alz_tobb_user_error (
                            agent_int_id
                          , identity_no
                          , v_errnum
                          , err_text
                          , creation_date
                          , gsm
                          , process)
                   VALUES (cr.agent_int_id
                         , cr.identity_no
                         , v_errnum
                         , v_errtext
                         , TRUNC (SYSDATE)
                         , v_sms_mail_gsm
                         , 'ALZ_TOBB_USER/CreateUserMain/sendsms-gsm yada tckn bos');
            END IF;

            v_errnum := 12;

            --mail
            IF v_sms_mail_tckn IS NOT NULL AND v_sms_mail_email IS NOT NULL THEN
              v_errnum := 13;
              v_yeni_tp_email :=
                v_sms_mail_gsm || ' nolu cep telefonunuza ' || cr.employee_name || ' ' || cr.employee_surname ||
                ' kullan�c�s�n�n DIGITALL �ifresi sms olarak iletilmi�tir. ' || v_new_user_name ||
                ' kullan�c�s� ile DIGITALL sistemine giri� yapmak i�in ' || CHR(38) || 'lt;a href=' || CHR(38) || 'quot;https://digitall.allianz.com.tr' || CHR(38) || 'quot;' || CHR(38) ||
                'gt;t�klay�n�z' || CHR(38) || 'lt;/a' || CHR(38) || 'gt;';

              IF cr.company_code <> '045' THEN
                v_yeni_tp_email :=
                  v_sms_mail_gsm || ' nolu cep telefonunuza ' || cr.employee_name || ' ' || cr.employee_surname ||
                  ' kullan�c�s�n�n ALLCLUB �ifresi sms olarak iletilmi�tir. ' || v_new_user_name ||
                  ' kullan�c�s� ile ALLCLUB sistemine giri� yapmak i�in ' || CHR(38) ||
                  'lt;a href=' || CHR(38) || 'quot;https://acente.allclub.com.tr/AgencyWebPortal' || CHR(38) || 'quot;' || CHR(38) || 'gt;t�klay�n�z' || CHR(38) || 'lt;/a' || CHR(38) || 'gt;';
              END IF;

              --alz_tobb_user.sendemail (v_sms_mail_email, v_yeni_tp_email, cr.company_code); -- ENGINT
            ELSE
              INSERT INTO alz_tobb_user_error (
                            agent_int_id
                          , identity_no
                          , v_errnum
                          , err_text
                          , creation_date
                          , email
                          , process)
                   VALUES (cr.agent_int_id
                         , cr.identity_no
                         , v_errnum
                         , v_errtext
                         , TRUNC (SYSDATE)
                         , v_sms_mail_email
                         , 'ALZ_TOBB_USER/CreateUserMain/sendmail-email yada tckn bos');

              COMMIT;
            END IF;
          END IF;

          v_errnum := 14;
        ELSE
          v_errnum := 15;
          v_errtext := 'Acente yetkili Ki�isi Tan�ml� de�ildir..';

          INSERT INTO alz_tobb_user_error (
                        agent_int_id
                      , identity_no
                      , v_errnum
                      , err_text
                      , creation_date
                      , process)
               VALUES (cr.agent_int_id
                     , cr.identity_no
                     , v_errnum
                     , v_errtext
                     , TRUNC (SYSDATE)
                     , 'ALZ_TOBB_USER/CreateUserMain');

          COMMIT;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          v_errtext := SUBSTR ('create user - ' || SQLERRM, 1, 4000);

          INSERT INTO alz_tobb_user_error (
                        agent_int_id
                      , identity_no
                      , v_errnum
                      , err_text
                      , creation_date
                      , process)
               VALUES (cr.agent_int_id
                     , cr.identity_no
                     , v_errnum
                     , v_errtext
                     , TRUNC (SYSDATE)
                     , 'ALZ_TOBB_USER/CreateUserMain');
      END;
    END LOOP;
END createusermain;

BEGIN
   createusermain('H');
END;
   
