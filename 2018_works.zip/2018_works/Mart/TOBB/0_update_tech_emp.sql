BEGIN
--teknik personellerin silinmesi
delete koc_dmt_agency_tech_emp 
 where agent_int_id IN( 73973,
                        73891,
                        73890,
                        73881,
                        73880,
                        73879,
                        73878,
                        73877,
                        73876,
                        73875,
                        73873,
                        73872,
                        73871,
                        73870,
                        73869,
                        73371,
                        73370,
                        73369
                        );
                        
--hatal� title lar�n d�zeltilmesi
 update koc_dmt_agents_ext e
     set e.title = (select title from koc_dmt_agents_title_ext where int_id = e.int_id)
   where e.int_id IN(73877,73878,73370);                         
--kullan�c�lar�n silinmesi
DELETE Web_Sec_System_Users 
 WHERE USER_NAME IN
('WFIBA3482_60159',
'WFIBA5924_60160',
'WFIBA6640_60161',
'WFIBA3992_60162',
'WFIBA9328_60164',
'WFIBA0794_60165',
'WFIBA9808_60166',
'WFIBA8970_60167',
'WFIBA0198_60170',
'WFIBA8560_60174');
COMMIT;
END;
/

