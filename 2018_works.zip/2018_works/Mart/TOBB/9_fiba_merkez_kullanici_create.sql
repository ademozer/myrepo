BEGIN
  UPDATE koc_dmt_agency_tech_emp 
  SET PROCESS_DATE = SYSDATE
  where agent_int_id = 71671
    and identity_no IN('16933598330',
                        '44749093640',
                        '14231290574');  
  ALZ_TOBB_USER.createusermain('E');  
  COMMIT;  
  END;  
/ 
