BEGIN
        update Koc_Cp_Partners_Ext e 
           set e.agen_int_id = (select a.int_id 
                                  from dmt_agents a
                                 where a.reference_code = (select SUBSTR(u.user_name,11) 
                                                             from web_sec_system_users u
                                                            where u.customer_partner_id = e.part_id)),
               e.identity_no = (select t.identity_no 
                                  from koc_dmt_agency_tech_emp t
                                 where exists (select 1 from dmt_agents a, web_sec_system_users u
                                                where u.customer_partner_id = e.part_id
                                                  and a.reference_code = SUBSTR(u.user_name,11)
                                                  and a.int_id = t.agent_int_id
                                                  and SUBSTR(t.identity_no,-4) = SUBSTR(u.user_name,6,4)))
                                                           
         where e.part_id in (
               select customer_partner_id from ( 
               select u.customer_partner_id, u.user_name, SUBSTR(u.user_name,11) reference_code 
                 from web_sec_system_users u
                where u.user_name like 'WFIBA%' 
                  and trunc(u.create_date) = to_date('23/03/2018','DD/MM/YYYY')));
COMMIT;
END;                  
/



