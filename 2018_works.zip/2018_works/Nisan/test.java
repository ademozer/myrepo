private Boolean checkingRiskSubjectWeightAndHeightControlRequired(
			RiskSubject riskSubject) {
	    Boolean	control=Boolean.FALSE;		
		Boolean renDaycontrol=Boolean.FALSE;
		//Boy kilo kontrolu yapilmamali
		if(!isRenderHealthQuestions()){
			return control;
		}
		if(riskSubject != null){
			
			if (isAmendment()){ // HMP-45 meriyet zeyili istek;
                control = Boolean.TRUE;
            }
			if(getPolicyBean().getPolicy().getPolicyBase().getIsRenewal()!= null ){//yenileme,kişi giriş zeyil
				if(getPolicyBean().getPolicy().getPolicyBase().getIsRenewal().intValue()==1){
					if(riskSubject.getRiskSubjectBase().getOldPartitionNo()==null 
							||( riskSubject.getRiskSubjectBase().getHasCoverIncreased()!=null &&										
									!BigDecimal.ZERO.equals(riskSubject.getRiskSubjectBase().getHasCoverIncreased() )
									&& (getPolicyBean().getPolicy().getPolicyBase().getVersionNo()==null 
						    		||BigDecimal.ZERO.equals(getPolicyBean().getPolicy().getPolicyBase().getVersionNo()) ))  ){							
						       //  isOK = Boolean.FALSE;
						         control=Boolean.TRUE;
	                } 
					}
				
			}
			else if (isAmendment()){ // HMP-45 meriyet zeyili istek;
                control = Boolean.TRUE;
            }
			else{//yeni işte-yürürlükteki bir poliçede kişi girişi
				if(riskSubject.getRiskSubjectBase().getActionCode().equals("A")){
					// isOK = Boolean.FALSE;
					control=Boolean.TRUE;
					
				}
			}
		} 
		if(isRenewal() && !(ActionCodeEnum.ReferenceContract.getValue().equals(getPolicyBean().getAction().getActionCode())
				||ActionCodeEnum.ReferenceContractHpf.getValue().equals(getPolicyBean().getAction().getActionCode())))
			if((renewalDayControl!=null&&(BigDecimal.ONE).compareTo(renewalDayControl)==0)){//36.gün iptali ise
				//isOK = Boolean.FALSE;
				renDaycontrol=Boolean.TRUE;
			}
			
			return(control||renDaycontrol);
	}