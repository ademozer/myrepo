DECLARE
   p_product_id          number := 63;
   p_partition_type      varchar2(100) := 'TSS';
   p_term_start_date     date := SYSDATE; --added by egezer for TPA project 20.11.2017
   p_user                varchar2(100) := 'WETIRYAKI';
   p_contract_id         number := 358455610;  --added by egezer for TPA project 27.02.2018
   p_endorsement_no      number := 2; --added by egezer for TPA project 27.02.2018
   p_endors_reason_code  varchar2(100) := NULL; --added by egezer for TPA project 27.02.2018
   TYPE cur_type              IS REF CURSOR;
   cur_ cur_type;               
   p_process_results   customer.process_result_table :=  customer.process_result_table();
   v_ndx NUMBER;
   v_data_msg  VARCHAR2(32000);
   v_data_found BOOLEAN := FALSE;
   PROCEDURE get_tpa_payment_type_list(p_product_id          in  number,
                                       p_partition_type     in  varchar2,
                                       p_term_start_date    in  date, --added by egezer for TPA project 20.11.2017
                                       p_user               in  varchar2,
                                       p_contract_id        in  number, --added by egezer for TPA project 27.02.2018
                                       p_endorsement_no     in  number, --added by egezer for TPA project 27.02.2018
                                       p_endors_reason_code in  varchar2, --added by egezer for TPA project 27.02.2018
                                       p_cur                out cur_type,
                                       p_process_results    out customer.process_result_table) IS --basakk: gorky

    v_result cur_type;

 cursor c_policy_info (p_contract_id in number) is
 select payment_type
   from koc_ocp_pol_versions_ext
  where contract_id = p_contract_id
    and version_no = 1;

 cursor c_wip_info (p_contract_id in number) is
 select payment_type
   from wip_koc_ocp_pol_versions_ext
  where contract_id = p_contract_id;

 cursor c_kk_odeme_varmi (p_contract_id in number) is
 select 1
   from koc_acc_policy_details a ,
        koc_acc_v_cc_transaction b
  where a.contract_id = p_contract_id
    and a.receipt_id = b.receipt_id
    and a.order_no = b.order_no
    and b.status = 'YOLP';
    
  cursor c_havl_odeme_varmi(p_contract_id in number) is
      select count(*) havale_count 
        from Koc_acc_receipt_master 
       where receipt_id in(select receipt_id 
        from Koc_acc_policy_details 
       where contract_id = p_contract_id)
         and receipt_type = 'HAVL';

  v_main_partition_type koc_oc_prod_partition_rel.main_partition_type%type;
  v_main_payment_type   koc_ocp_pol_versions_ext.payment_type%type;
  v_payment_type        koc_ocp_pol_versions_ext.payment_type%type default null;
  v_kk_odeme_count      number;
  v_havale_count        number;
  contract_id_not_found  exception;
  payment_type_not_found exception;

    BEGIN

    /*endorsement_no  = 1  GENEL ZEYIL  p_endors_reason_code = SGCK
     endorsement_no  = 1  GENEL ZEYIL  p_endors_reason_code = SGIR
     endorsement_no  = 2  FESIH
     endorsement_no  = 14 MEBDEINDEN IPTAL
     endorsement_no  = 11 MERIYET ZEYILI*/

     v_main_partition_type := alz_tpa_hlth_policy_utils.get_main_partition_type(p_product_id, p_partition_type , trunc(sysdate));

     --IF v_main_partition_type <> 'TSS' or (v_main_partition_type = 'TSS' and p_endorsement_no is null) THEN
     --     v_payment_type := null;
     IF v_main_partition_type not in ('TSS', 'MD') or (v_main_partition_type in ('TSS', 'MD') and p_endorsement_no is null) THEN -- hazala_22032018_mdts md icin ana policenin odeme tipi zeylde de gelsin.
          v_payment_type := null;
     ELSIF v_main_partition_type in ('TSS', 'MD') and p_endorsement_no is not null THEN -- hazala_22032018_mdts md icin ana policenin odeme tipi zeylde de gelsin.
      --Ana poli�enin �deme tipi bulunuyor.
        open c_policy_info(p_contract_id);
        fetch c_policy_info into v_main_payment_type;
           if c_policy_info%notfound or v_main_payment_type is null  then
               open c_wip_info(p_contract_id);
              fetch c_wip_info into v_main_payment_type;
                if c_wip_info%notfound then
                 v_main_payment_type:= null;
                 raise contract_id_not_found;
                elsif v_main_payment_type is null then
                 v_main_payment_type:= null;
                 raise payment_type_not_found;
                end if;
              close c_wip_info;
           end if;
        close c_policy_info;
      IF v_main_payment_type = '3' THEN
         --Ana poli�enin �deme tipi KKB ise zeyiller i�inde KKB olacak.
         v_payment_type:=v_main_payment_type;
      ELSE
       IF p_endorsement_no = 11 or (p_endorsement_no = 1 and p_endors_reason_code ='SGIR')  THEN
          --Meriyet zeyili veya sigortali giris zeyili ise listede hem KK hemde Havale �ikacak
          v_payment_type:='9';
       ELSIF p_endorsement_no in (2,14) or (p_endorsement_no = 1 and p_endors_reason_code ='SGCK') THEN
          --Fesih ve mebdeinden iptal veya sigortali �ikis zeyili ise ana poli�e KK ise zeyillerde KK olacak
        IF v_main_payment_type = '2' THEN
           v_payment_type:= v_main_payment_type;
           --[ademo.T4834737 07.05.2018
           --Ana poli�e �deme Tipi KK olup Havale ile �demesi varsa listede hem KK hem de Havale ��kmas�
           open c_havl_odeme_varmi(p_contract_id);
           fetch c_havl_odeme_varmi into v_havale_count;
           close c_havl_odeme_varmi;
           
           IF NVL(v_havale_count, 0) > 0 THEN
               open c_kk_odeme_varmi(p_contract_id);
               fetch c_kk_odeme_varmi into v_kk_odeme_count;           
               close c_kk_odeme_varmi;
           
               IF NVL(v_kk_odeme_count, 0) = 0 THEN
                  v_payment_type := '1'; -- KK �demesi olmay�p havale �demesi varsa �deme tipi Havale ��kmas�
               ELSE
                  v_payment_type := '9'; -- Hem KK �demesi olup Hem de Havale �demesi varsa KK ve Havale ��kmas�
               END IF;
           END IF;
           --ademo.T4834737]
           
        ELSIF v_main_payment_type = '1' THEN
          --Fesih ve mebdeinden iptal veya sigortali �ikis zeyili ise ana poli�e HAVL ise KK ile �deme var mi kontrol ediliyor.
           open c_kk_odeme_varmi(p_contract_id);
          fetch c_kk_odeme_varmi into v_kk_odeme_count;
             if c_kk_odeme_varmi%notfound then
                  v_kk_odeme_count := 0;
            end if;
         close c_kk_odeme_varmi;
         --KK'li �deme var ise zeyil KK olacak yok ise zeyil Havale olacak
         IF v_kk_odeme_count <> 0 THEN
            v_payment_type:= '2';
         ELSE
            v_payment_type:= '1';
         END IF;
        END IF;
       END IF;
      END IF;
     ELSE
     v_payment_type := null;
     END IF;

     OPEN v_result FOR
     select a.payment_type, b.long_name
      from alz_tpa_prod_payment_rel a, cur_translations b
     where a.desc_int_id        = b.desc_int_id
       and a.product_id         = p_product_id
       and a.partition_type     = p_partition_type
       and b.sula_ora_nls_code  = 'TR'
       and a.payment_type = nvl(to_number(v_payment_type) ,a.payment_type)
       and a.validity_start_date <= p_term_start_date
       and (a.validity_end_date  >= p_term_start_date or a.validity_end_date is null)
     union all
    select a.payment_type, b.long_name
      from alz_tpa_prod_payment_rel a,cur_translations b
     where a.desc_int_id        = b.desc_int_id
       and a.product_id         = p_product_id
       and a.partition_type     = p_partition_type
       and b.sula_ora_nls_code  = 'TR'
       and a.payment_type in (1,2)
       and v_payment_type = '9'
       and a.validity_start_date <= p_term_start_date
       and (a.validity_end_date  >= p_term_start_date or a.validity_end_date is null);

      p_cur := v_result;

    EXCEPTION WHEN contract_id_not_found  THEN
       alz_web_process_utils.process_result(0,
                         9,
                         -1,
                         'Askiya ait herhangi bir kayit bulunamadi.',
                         SQLCODE || ' - ' || SQLERRM,
                         NULL,
                         NULL,
                         NULL,
                         'alz_lookup_utils.get_tpa_payment_type_list',
                         NULL,
                         p_process_results);
             WHEN payment_type_not_found  then
      alz_web_process_utils.process_result(0,
                         9,
                         -1,
                         '�deme tipi bilgisi bulunamadi.',
                         SQLCODE || ' - ' || SQLERRM,
                         NULL,
                         NULL,
                         NULL,
                         'alz_lookup_utils.get_tpa_payment_type_list',
                         NULL,
                         p_process_results);
            WHEN OTHERS THEN
      alz_web_process_utils.process_result(0,
                         9,
                         -1,
                         'ORACLE_EXCEPTION',
                         SQLCODE || ' - ' || SQLERRM,
                         NULL,
                         NULL,
                         NULL,
                         'alz_lookup_utils.get_tpa_payment_type_list',
                         NULL,
                         p_process_results);
    END get_tpa_payment_type_list;
BEGIN
   get_tpa_payment_type_list(p_product_id,
                                       p_partition_type,
                                       p_term_start_date, --added by egezer for TPA project 20.11.2017
                                       p_user,
                                       p_contract_id, --added by egezer for TPA project 27.02.2018
                                       p_endorsement_no, --added by egezer for TPA project 27.02.2018
                                       p_endors_reason_code, --added by egezer for TPA project 27.02.2018
                                       cur_,
                                       p_process_results);

   IF cur_%ISOPEN THEN     
               v_ndx := 0;                 
               v_data_msg := v_data_msg || '[';
               FOR rec_1 IN (SELECT ROWNUM ROW_NO, 
                                    t1.column_value.getStringVal() ROW_DATA
                               FROM (SELECT * FROM TABLE (XMLSEQUENCE(cur_))) t1)    
               LOOP                   
                   IF rec_1.ROW_NO>1 THEN
                       v_data_msg := v_data_msg || ',';
                   END IF;
                   v_data_msg := v_data_msg || '{';
                   v_ndx := 0;
                   FOR rec_2 IN (SELECT EXTRACTVALUE (t.COLUMN_VALUE, '/*') AS NODE_VALUE,
                                                      t.COLUMN_VALUE.getrootelement () AS NODE_NAME
                                   FROM TABLE (XMLSEQUENCE (EXTRACT(EXTRACT(XMLTYPE(rec_1.ROW_DATA), '//*'), '/ROW/*'))) t)
                   LOOP
                      IF v_ndx>0 THEN
                         v_data_msg := v_data_msg || ',';
                      END IF;
                      v_data_msg := v_data_msg || '"' || LOWER(rec_2.NODE_NAME) || '":"' || TRIM(rec_2.Node_Value) || '"';
                      v_ndx := v_ndx + 1;                         
                   END LOOP;
                   v_data_msg := v_data_msg || '}';
               END LOOP;   
               v_data_msg := v_data_msg || ']';
               IF v_ndx>0 THEN
                    v_data_found := TRUE;
               END IF;
              CLOSE cur_;                           
           END IF; 
           
 DBMS_OUTPUT.PUT_LINE(v_data_msg);                                                                       
END; 
