BEGIN 
    update Koc_Cp_Partners_Ext e 
       set e.agen_int_id = (select a.int_id 
                              from dmt_agents a
                             where a.reference_code = (select SUBSTR(u.user_name,11) 
                                                         from web_sec_system_users u
                                                        where u.customer_partner_id = e.part_id)),
           e.identity_no = (select t.identity_no 
                              from koc_dmt_agency_tech_emp t
                             where exists (select 1 from dmt_agents a, web_sec_system_users u
                                            where u.customer_partner_id = e.part_id
                                              and a.reference_code = SUBSTR(u.user_name,11)
                                              and a.int_id = t.agent_int_id
                                              and SUBSTR(t.identity_no,-4) = SUBSTR(u.user_name,6,4)))
                                                           
     where e.part_id in (
           select customer_partner_id from ( 
           select u.customer_partner_id, u.user_name, SUBSTR(u.user_name,11) reference_code 
             from web_sec_system_users u
            where u.user_name IN ('WFIBA5396_60201',
                                  'WFIBA3400_60200',
                                  'WFIBA5852_60200',
                                  'WFIBA8492_60204',
                                  'WFIBA5792_60205')));
                                      
  delete koc_auth_user_role_rel  
  where username IN ('WFIBA5396_60201',
                     'WFIBA3400_60200',
                     'WFIBA5852_60200',
                     'WFIBA8492_60204',
                     'WFIBA5792_60205');
                     
     insert into customer.koc_auth_user_role_rel(username, role_code, validity_start_date)
     select user_name, 'SAGENT' role_code , create_date 
     from  web_sec_system_users  
     where user_name IN ('WFIBA5396_60201',
                         'WFIBA3400_60200',
                         'WFIBA5852_60200',
                         'WFIBA8492_60204',
                         'WFIBA5792_60205');                                       
     
    insert into customer.koc_auth_user_role_rel(username, role_code, validity_start_date)
     select user_name, 'WLOGIN' role_code , create_date 
     from  web_sec_system_users  
     where user_name IN ('WFIBA5396_60201',
                         'WFIBA3400_60200',
                         'WFIBA5852_60200',
                         'WFIBA8492_60204',
                         'WFIBA5792_60205'); 
                         
   insert into customer.koc_auth_user_role_rel(username, role_code, validity_start_date)
     select user_name, 'WTPAAGENT' role_code , create_date 
     from  web_sec_system_users  
     where user_name IN ('WFIBA5396_60201',
                         'WFIBA3400_60200',
                         'WFIBA5852_60200',
                         'WFIBA8492_60204',
                         'WFIBA5792_60205');                          
COMMIT;
END;
/
                     
          
      
                     
