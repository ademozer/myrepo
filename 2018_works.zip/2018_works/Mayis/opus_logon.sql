DECLARE

  v_ok boolean;
  v_pass VARCHAR2(200);
  
 BEGIN
   
  v_ok := OPUS_CORE.inf_sec_user_verify_api.val_gios_user('MEDISER38',
                                                          'Aa123456');
                                              
  IF v_ok THEN
        v_pass := OPUS_CORE.inf_sec_user_verify_api.get_gios_oracle_password( 'MEDISER38',
                                                                              'Aa123456');
       DBMS_OUTPUT.PUT_LINE('ok:'||v_pass);
  ELSE 
       DBMS_OUTPUT.PUT_LINE('no');
  END IF;
  
 END;       
                                                
