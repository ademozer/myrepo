DECLARE
  v_carray customer.char_array;
  p_process_results customer.process_result_table;
  v_params VARCHAR2(400);
BEGIN
     v_carray := customer.char_array (); -- ademo 26.05.2018
   --  v_carray.EXTEND;
    -- v_carray (v_carray.LAST) := 'SAGENT';
     v_carray.EXTEND;           
     v_carray (v_carray.LAST) := 'WTPAAGENT';
     v_carray.EXTEND;
     v_carray (v_carray.LAST) := 'WTPACNOPER'; -- ademo 26.05.2018          
     v_carray.EXTEND;
     v_carray (v_carray.LAST) := 'WLOGIN';--TPA2 Serdal
     
     FOR rec IN (SELECT COLUMN_VALUE FROM TABLE(v_carray)) LOOP
         DBMS_OUTPUT.PUT_LINE(rec.COLUMN_VALUE);
     END LOOP;
     IF v_carray.COUNT > 0 THEN
       FOR ndx IN v_carray.FIRST .. v_carray.LAST LOOP
           DBMS_OUTPUT.PUT_LINE(v_carray(ndx));
           BEGIN
              v_params := 'username='||'WFIBA7482_60000'||':role='||v_carray(ndx)||':vsd='||SYSDATE;
              DBMS_OUTPUT.PUT_LINE(v_params);
             INSERT INTO koc_auth_user_role_rel (
                          username
                        , role_code
                        , validity_start_date)
                 VALUES ('WFIBA7482_60000'
                       , v_carray(ndx)
                       , SYSDATE);
                       
           EXCEPTION 
           WHEN OTHERS THEN
               DBMS_OUTPUT.PUT_LINE('Hata:'||SUBSTR(SQLERRM,1,200));
           END;
           ALZ_WEB_USER_UTILS.log_user_role_history(p_user_name    => 'WFIBA7482_60000',
                              p_role_code       => v_carray(ndx),
                              p_action_type     => 'I',
                              p_update_user     => 'ADEMO',
                              p_process_results => p_process_results);
       END LOOP;
       COMMIT;
     END IF;
END;
       
    
