BEGIN 
   update web_sec_system_users set end_date = null where user_name = 'WFIBA6150_60149';
   
   update koc_dmt_agency_tech_emp 
     set validity_end_date = null
   where agent_int_id = 73225
     and identity_no = 20705406150
     and validity_end_date IS NOT NULL;
   
    update Koc_Cp_Partners_Ext e 
       set e.agen_int_id = (select a.int_id 
                              from dmt_agents a
                             where a.reference_code = (select SUBSTR(u.user_name,11) 
                                                         from web_sec_system_users u
                                                        where u.customer_partner_id = e.part_id)),
           e.identity_no = (select t.identity_no 
                              from koc_dmt_agency_tech_emp t
                             where exists (select 1 from dmt_agents a, web_sec_system_users u
                                            where u.customer_partner_id = e.part_id
                                              and a.reference_code = SUBSTR(u.user_name,11)
                                              and a.int_id = t.agent_int_id
                                              and SUBSTR(t.identity_no,-4) = SUBSTR(u.user_name,6,4)))
                                                           
     where e.part_id in (
           select customer_partner_id from ( 
           select u.customer_partner_id, u.user_name, SUBSTR(u.user_name,11) reference_code 
             from web_sec_system_users u
            where u.user_name IN ('WFIBA6732_60134',
                                  'WFIBA5810_60134',
                                  'WFIBA1158_60141',
                                  'WFIBA8306_60094'
                                  )));
                                      
  delete koc_auth_user_role_rel  
  where username IN ('WFIBA6732_60134',
                      'WFIBA5810_60134',
                      'WFIBA1158_60141',
                      'WFIBA8306_60094'
                      );
                     
     insert into customer.koc_auth_user_role_rel(username, role_code, validity_start_date)
     select user_name, 'SAGENT' role_code , create_date 
     from  web_sec_system_users  
     where user_name IN ('WFIBA6732_60134',
                          'WFIBA5810_60134',
                          'WFIBA1158_60141',
                          'WFIBA8306_60094'
                          );                                      
     
    insert into customer.koc_auth_user_role_rel(username, role_code, validity_start_date)
     select user_name, 'WLOGIN' role_code , create_date 
     from  web_sec_system_users  
     where user_name IN ('WFIBA6732_60134',
                         'WFIBA5810_60134',
                         'WFIBA1158_60141',
                         'WFIBA8306_60094'
                          ); 
                         
   insert into customer.koc_auth_user_role_rel(username, role_code, validity_start_date)
     select user_name, 'WTPAAGENT' role_code , create_date 
     from  web_sec_system_users  
     where user_name IN ('WFIBA6732_60134',
                          'WFIBA5810_60134',
                          'WFIBA1158_60141',
                          'WFIBA8306_60094'
                          );                         
COMMIT;
END;
/
                     
          
      
                     
