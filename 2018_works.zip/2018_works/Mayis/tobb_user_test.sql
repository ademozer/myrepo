select * from koc_dmt_agency_tech_emp where employee_surname like '%�ZER%' and userid='ALISA'

select * from alz_tobb_user_error where identity_no = 19780213565

select * from koc_auth_user_role_rel where username = 'WFIBA3565_60000'

select * from web_sec_system_users where user_name LIKE '%WFIBA3565%'

select * from CUSTOMER.KOC_AUTH_USER_ROLE_REL where username in ('WFIBA7482_60000', 'WFIBA3562_60190');

select * from CF_ROLE_CHANGE_HISTORY where user_name = 'WFIBA7482_60000';

select * from alz_error_log_table where TRUNC(process_date) = '25.05.2018' and reason like 'LOG_USER_ROLE_HISTORY%' 
