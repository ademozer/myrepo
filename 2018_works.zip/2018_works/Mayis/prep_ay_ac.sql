prompt Importing table koc_process_close...
set feedback off
set define off
insert into koc_process_close (AGENT_INT_ID, PROCESS_TYPE, BRANCH_ID, CLOSE_DATE, PROCESS_DATE, STATUS_CODE, I_STATUS_CODE, BRANCH_TYPE, DASK_STATUS_CODE, USERNAME, I_USERNAME, MONTH_CLOSE_DATE, I_MONTH_CLOSE_DATE, SYSTEM_DATE)
values (12354, 'ACCH', 1, to_date('31-05-2018', 'dd-mm-yyyy'), to_date('01-05-2018', 'dd-mm-yyyy'), 1, null, 0, null, 'USERNAME', null, null, null, to_date('01-07-2014 09:19:12', 'dd-mm-yyyy hh24:mi:ss'));

insert into koc_process_close (AGENT_INT_ID, PROCESS_TYPE, BRANCH_ID, CLOSE_DATE, PROCESS_DATE, STATUS_CODE, I_STATUS_CODE, BRANCH_TYPE, DASK_STATUS_CODE, USERNAME, I_USERNAME, MONTH_CLOSE_DATE, I_MONTH_CLOSE_DATE, SYSTEM_DATE)
values (12354, 'CLAM', 1, to_date('31-05-2018', 'dd-mm-yyyy'), to_date('01-05-2018', 'dd-mm-yyyy'), 1, 1, null, null, null, null, null, null, null);

insert into koc_process_close (AGENT_INT_ID, PROCESS_TYPE, BRANCH_ID, CLOSE_DATE, PROCESS_DATE, STATUS_CODE, I_STATUS_CODE, BRANCH_TYPE, DASK_STATUS_CODE, USERNAME, I_USERNAME, MONTH_CLOSE_DATE, I_MONTH_CLOSE_DATE, SYSTEM_DATE)
values (12354, 'CLOH', 1, to_date('31-05-2018', 'dd-mm-yyyy'), to_date('01-05-2018', 'dd-mm-yyyy'), 1, null, null, null, null, null, null, null, null);

insert into koc_process_close (AGENT_INT_ID, PROCESS_TYPE, BRANCH_ID, CLOSE_DATE, PROCESS_DATE, STATUS_CODE, I_STATUS_CODE, BRANCH_TYPE, DASK_STATUS_CODE, USERNAME, I_USERNAME, MONTH_CLOSE_DATE, I_MONTH_CLOSE_DATE, SYSTEM_DATE)
values (12354, 'CLMH', 1, to_date('31-05-2018', 'dd-mm-yyyy'), to_date('01-05-2018', 'dd-mm-yyyy'), 1, null, null, null, null, null, null, null, null);

insert into koc_process_close (AGENT_INT_ID, PROCESS_TYPE, BRANCH_ID, CLOSE_DATE, PROCESS_DATE, STATUS_CODE, I_STATUS_CODE, BRANCH_TYPE, DASK_STATUS_CODE, USERNAME, I_USERNAME, MONTH_CLOSE_DATE, I_MONTH_CLOSE_DATE, SYSTEM_DATE)
values (12354, 'ACA', 1, to_date('31-05-2018', 'dd-mm-yyyy'), to_date('01-05-2018', 'dd-mm-yyyy'), 1, null, 0, null, 'USERNAME', null, null, null, to_date('01-04-2014 09:46:06', 'dd-mm-yyyy hh24:mi:ss'));

insert into koc_process_close (AGENT_INT_ID, PROCESS_TYPE, BRANCH_ID, CLOSE_DATE, PROCESS_DATE, STATUS_CODE, I_STATUS_CODE, BRANCH_TYPE, DASK_STATUS_CODE, USERNAME, I_USERNAME, MONTH_CLOSE_DATE, I_MONTH_CLOSE_DATE, SYSTEM_DATE)
values (12354, 'PRDC', 1, to_date('31-05-2018', 'dd-mm-yyyy'), to_date('01-05-2018', 'dd-mm-yyyy'), 1, 1, 1, 1, null, null, null, null, null);

insert into koc_process_close (AGENT_INT_ID, PROCESS_TYPE, BRANCH_ID, CLOSE_DATE, PROCESS_DATE, STATUS_CODE, I_STATUS_CODE, BRANCH_TYPE, DASK_STATUS_CODE, USERNAME, I_USERNAME, MONTH_CLOSE_DATE, I_MONTH_CLOSE_DATE, SYSTEM_DATE)
values (12354, 'PRDC', 119, to_date('31-05-2018', 'dd-mm-yyyy'), to_date('01-05-2018', 'dd-mm-yyyy'), 1, 2, 0, 2, null, null, null, null, null);

insert into koc_process_close (AGENT_INT_ID, PROCESS_TYPE, BRANCH_ID, CLOSE_DATE, PROCESS_DATE, STATUS_CODE, I_STATUS_CODE, BRANCH_TYPE, DASK_STATUS_CODE, USERNAME, I_USERNAME, MONTH_CLOSE_DATE, I_MONTH_CLOSE_DATE, SYSTEM_DATE)
values (12354, 'PRDC', 120, to_date('31-05-2018', 'dd-mm-yyyy'), to_date('01-05-2018', 'dd-mm-yyyy'), 1, 1, 1, 1, null, null, null, null, null);

insert into koc_process_close (AGENT_INT_ID, PROCESS_TYPE, BRANCH_ID, CLOSE_DATE, PROCESS_DATE, STATUS_CODE, I_STATUS_CODE, BRANCH_TYPE, DASK_STATUS_CODE, USERNAME, I_USERNAME, MONTH_CLOSE_DATE, I_MONTH_CLOSE_DATE, SYSTEM_DATE)
values (12354, 'PRDC', 124, to_date('31-05-2018', 'dd-mm-yyyy'), to_date('01-05-2018', 'dd-mm-yyyy'), 1, 1, 1, 1, null, null, null, null, null);

insert into koc_process_close (AGENT_INT_ID, PROCESS_TYPE, BRANCH_ID, CLOSE_DATE, PROCESS_DATE, STATUS_CODE, I_STATUS_CODE, BRANCH_TYPE, DASK_STATUS_CODE, USERNAME, I_USERNAME, MONTH_CLOSE_DATE, I_MONTH_CLOSE_DATE, SYSTEM_DATE)
values (12354, 'PRDC', 125, to_date('31-05-2018', 'dd-mm-yyyy'), to_date('01-05-2018', 'dd-mm-yyyy'), 1, 1, 1, 1, null, null, null, null, null);

insert into koc_process_close (AGENT_INT_ID, PROCESS_TYPE, BRANCH_ID, CLOSE_DATE, PROCESS_DATE, STATUS_CODE, I_STATUS_CODE, BRANCH_TYPE, DASK_STATUS_CODE, USERNAME, I_USERNAME, MONTH_CLOSE_DATE, I_MONTH_CLOSE_DATE, SYSTEM_DATE)
values (12354, 'PRDC', 126, to_date('31-05-2018', 'dd-mm-yyyy'), to_date('01-05-2018', 'dd-mm-yyyy'), 1, 1, 1, 2, null, null, null, null, null);

insert into koc_process_close (AGENT_INT_ID, PROCESS_TYPE, BRANCH_ID, CLOSE_DATE, PROCESS_DATE, STATUS_CODE, I_STATUS_CODE, BRANCH_TYPE, DASK_STATUS_CODE, USERNAME, I_USERNAME, MONTH_CLOSE_DATE, I_MONTH_CLOSE_DATE, SYSTEM_DATE)
values (12354, 'PRDC', 139, to_date('31-05-2018', 'dd-mm-yyyy'), to_date('01-05-2018', 'dd-mm-yyyy'), 1, 1, 1, 1, null, null, null, null, null);

insert into koc_process_close (AGENT_INT_ID, PROCESS_TYPE, BRANCH_ID, CLOSE_DATE, PROCESS_DATE, STATUS_CODE, I_STATUS_CODE, BRANCH_TYPE, DASK_STATUS_CODE, USERNAME, I_USERNAME, MONTH_CLOSE_DATE, I_MONTH_CLOSE_DATE, SYSTEM_DATE)
values (12354, 'PRDC', 140, to_date('31-05-2018', 'dd-mm-yyyy'), to_date('01-05-2018', 'dd-mm-yyyy'), 1, 1, 1, 1, null, null, null, null, null);

insert into koc_process_close (AGENT_INT_ID, PROCESS_TYPE, BRANCH_ID, CLOSE_DATE, PROCESS_DATE, STATUS_CODE, I_STATUS_CODE, BRANCH_TYPE, DASK_STATUS_CODE, USERNAME, I_USERNAME, MONTH_CLOSE_DATE, I_MONTH_CLOSE_DATE, SYSTEM_DATE)
values (12354, 'PRDC', 141, to_date('31-05-2018', 'dd-mm-yyyy'), to_date('01-05-2018', 'dd-mm-yyyy'), 1, 1, 1, 1, null, null, null, null, null);

prompt Done.
