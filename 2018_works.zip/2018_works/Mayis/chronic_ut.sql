DECLARE
   p_query_table customer.hlth_chr_dis_query_table := customer.hlth_chr_dis_query_table();
   p_process_results  customer.process_result_table := customer.process_result_table();
   p_user VARCHAR2(100) := 'ADEMO';
   PROCEDURE query_policy_status (p_query_table IN OUT customer.hlth_chr_dis_query_table, p_user IN VARCHAR2
  , p_process_results IN OUT customer.process_result_table)
  IS
    CURSOR c (p_part_id NUMBER)
    IS       
      SELECT p.policy_ref, p.partner_id, p.partition_type, p.contract_id
        FROM CUSTOMER.KOC_V_HEALTH_INSURED_INFO p
       WHERE p.partner_id IN (SELECT part_id
                                FROM koc_cp_partners_ext e1
                               WHERE identity_no IN (SELECT identity_no
                                                       FROM koc_cp_partners_ext e2
                                                      WHERE part_id = p_part_id))
         AND p.partition_type IN ('MDSG', 'KOCV', 'GRUP')
         AND p.contract_status = 'I'
         AND p.action_code <> 'D'
         AND SYSDATE BETWEEN TRUNC (p.term_start_date) AND p.term_end_date
       ORDER BY DECODE (p.partition_type,  'MDSG', 1,  'KOCV', 2,  'GRUP', 3);

    cr        c%ROWTYPE;
    v_part_id NUMBER;
    v_count_own_diabetes   NUMBER := 0;
    v_count_other_diabetes NUMBER := 0;
  BEGIN
    FOR i IN 1 .. p_query_table.COUNT LOOP
      v_part_id := p_query_table (i).part_id;

      OPEN c (v_part_id);
      FETCH c INTO cr;

      IF c%NOTFOUND THEN
        p_query_table (i).status := 1;
        p_query_table (i).explanation := 'Bu kriterlere uygun poli�e bulunamad�';
        p_query_table (i).policy_ref := NULL;
        p_query_table (i).policy_part_id := NULL;
      ELSE
        --[ademo
        SELECT SUM (CASE WHEN part_id = v_part_id THEN 1 ELSE 0 END) count_own_diabetes,
               SUM (CASE WHEN part_id != v_part_id THEN 1 ELSE 0 END) count_other_diabetes
          INTO v_count_own_diabetes,
               v_count_other_diabetes
          FROM koc_cp_partners_ext e1
         WHERE identity_no IN (SELECT identity_no
                                 FROM koc_cp_partners_ext
                                WHERE part_id = v_part_id)
           AND NVL (has_diabetes, 0) = 1;

        IF NVL(v_count_own_diabetes,0) = 0 AND NVL(v_count_other_diabetes,0) = 0 THEN
            p_query_table (i).status := 1;
            p_query_table (i).explanation := 'Sigortal�n�n aktif poli�esi vard�r. Diyabet tan�m� bulunmamaktad�r.';
            p_query_table (i).policy_ref := cr.policy_ref;
            p_query_table (i).policy_part_id := cr.partner_id;
        ELSE
          --ademo]
          IF cr.partition_type IN ('MDSG', 'KOCV') THEN
            p_query_table (i).status := 2;
            p_query_table (i).explanation := 'Sorgu Ba�ar�l�';
            p_query_table (i).policy_ref := cr.policy_ref;
            p_query_table (i).policy_part_id := cr.partner_id;
          ELSIF cr.partition_type = 'GRUP' THEN
            DECLARE
              lc_policy_ref VARCHAR2 (30);
            BEGIN
              SELECT policy_ref
                INTO lc_policy_ref
                FROM ocp_policy_bases
               WHERE contract_id IN
                       (SELECT contract_id
                          FROM koc_oc_hlth_expack_cov_rel
                         WHERE part_id = cr.partner_id
                           AND SYSDATE BETWEEN TRUNC (validity_start_date) AND NVL (validity_end_date, SYSDATE + 1)
                           AND sub_rule_code = 11
                           AND child_cover_code = 'S425')
                 AND top_indicator = 'Y'
                 AND action_code <> 'D'
                 AND SYSDATE BETWEEN TRUNC (term_start_date) AND term_end_date;

              --
              p_query_table (i).status := 2;
              p_query_table (i).explanation := 'Sorgu Ba�ar�l�';
              p_query_table (i).policy_ref := lc_policy_ref;
              p_query_table (i).policy_part_id := cr.partner_id;
            --
            EXCEPTION
              WHEN NO_DATA_FOUND THEN
                p_query_table (i).status := 1;
                p_query_table (i).explanation := 'Grup poli�esinde teminat tan�m� mevcut de�ildir.'; --ademo
                p_query_table (i).policy_ref := cr.policy_ref; --ademo
                p_query_table (i).policy_part_id := cr.partner_id; --ademo
              WHEN OTHERS THEN
                p_query_table (i).status := 1;
                p_query_table (i).explanation := SUBSTR (SQLERRM, 1, 100);
                p_query_table (i).policy_ref := cr.policy_ref; --ademo
                p_query_table (i).policy_part_id := cr.partner_id; --ademo
            END;
          END IF;
        END IF;
      END IF;

      CLOSE c;
    END LOOP;
  -------------------------------------------------------------------------
  EXCEPTION
    WHEN OTHERS THEN --sistemsel hata olu�tu
      alz_web_process_utils.process_result (-1, 'SYSTEM_ERROR', SUBSTR (SQLERRM || '--' || DBMS_UTILITY.format_error_backtrace, 1, 1000)
                                          , 0, p_process_results);
  END query_policy_status;
  
  BEGIN
       p_query_table.EXTEND;
       p_query_table(p_query_table.LAST) := CUSTOMER.Hlth_Chr_Dis_Query_Rec(39468981,null,null,null,null);
       query_policy_status(p_query_table, p_user, p_process_results);
       FOR rec IN (SELECT REASON,ERROR_ORIGIN FROM TABLE(p_process_results)) LOOP
          DBMS_OUTPUT.PUT_LINE(rec.REASON||' - '||rec.ERROR_ORIGIN);
       END LOOP;
       DBMS_OUTPUT.PUT_LINE(p_query_table(p_query_table.LAST).explanation); 
   END;
  
