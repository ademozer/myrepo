BEGIN
    UPDATE web_sec_system_users
      SET retry_password_count = 0
    WHERE user_name = 'WFIBA3658_60181';
    COMMIT;
END;
/