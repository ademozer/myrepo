select * from koc_dmt_agency_tech_emp where agent_int_id = 75078 for update
select * from alz_tobb_user_hist where TRUNC(creation_date) = TO_DATE('15/05/2018','DD/MM/YYYY') and email='ebruserbetci@ulasimsigorta.com.tr'
select * from web_sec_system_users where user_name LIKE '%60189'
select * from dmt_agents where int_id=75077--75078 
select * from koc_dmt_agents_ext where int_id=75078
select * from cp_partners where part_id=89030171
select * from koc_cp_partners_ext where part_id=89030183--89030171
SELECT a.agent_int_id
           , a.emp_id_no
           , a.identity_no
           , a.employee_type
           , a.employee_name
           , a.employee_surname
           , a.validity_start_date
           , a.validity_end_date
           , a.userid
           , a.process_date
           , NVL (x.company_code, '045') company_code -- Default Allianz ENGINT
        FROM koc_dmt_agency_tech_emp a
           , koc_dmt_agents_ext x
       WHERE TRUNC (a.process_date) = TO_DATE('15/05/2018','DD/MM/YYYY')--TRUNC (SYSDATE) -- Engint Neden Process gece 12 de mi cal�s�yor ??
         AND (a.validity_end_date IS NULL OR a.validity_end_date > TRUNC (SYSDATE))
         AND ((&p_Merkez='H' and x.signboard_no IS NOT NULL) or (&p_Merkez='E' AND x.signboard_no IS NULL))--TPA2 Serdal
         AND x.int_id = a.agent_int_id
         AND ( (NVL (x.company_code, '045') = '045' AND x.mis_sub_group IN ('11', '12', '14', '61', '62', '63', '140'))
           OR  (NVL (x.company_code, '045') <> '045'
            AND EXISTS
                  (SELECT 1
                     FROM alz_tpa_company_mis_rel cmr
                    WHERE NVL (x.company_code, '045') = cmr.company_code
                      AND x.mis_main_group = cmr.mis_main_group
                      AND x.mis_sub_group = cmr.mis_sub_group
                      AND cmr.agent_type = 'AGENT'
                      AND SYSDATE BETWEEN TRUNC (cmr.validity_start_date) AND NVL (cmr.validity_end_date, SYSDATE + 1))));
                      
                      
                      
                   select * from  koc_auth_user_role_rel where username='WFIBA9099_60190' and ROLE_CODE='SAGENT'
                   select * from web_sec_system_users where user_name LIKE 'WFIBA9098%'
                   select * from koc_cp_partners_ext where part_id=89283030
                   select * from alz_tobb_user_error where identity_no=13069569098
                   select * from ademo.fiba_users@opusdev
                   
                    SELECT a.acente_user_name
        FROM alz_tobb_ornek_userrole a
        
        
         SELECT a.user_name
           , d.reference_code
       -- INTO v_username_control
         --  , v_acente_kod_cont
        FROM web_sec_system_users a
           , cp_partners b
           , koc_cp_partners_ext c
           , dmt_agents d
           , koc_dmt_agents_ext e
       WHERE a.customer_partner_id = b.part_id
         AND b.part_id = c.part_id
         AND c.agen_int_id = d.int_id
         AND d.int_id = e.int_id
         --AND c.agen_int_id = p_acentekod
         AND c.IDENTITY_NO <> '13069569099'
         AND a.user_name = 'WFIBA9098_60190'
         
        select * from koc_cp_customers_of_agent where agent_int_id = 75078
        
        
        
        
  DELETE KOC_AUTH_USER_ROLE_REL WHERE USERNAME =

 INSERT INTO CUSTOMER.KOC_AUTH_USER_ROLE_REL(USERNAME,ROLE_CODE,VALIDITY_START_DATE) 
        SELECT USERNAME, 'WLOGIN' ROLE_CODE, TRUNC(SYSDATE) VALIDITY_START_DATE FROM DUAL
  UNION SELECT USERNAME, 'SAGENT' ROLE_CODE, TRUNC(SYSDATE) VALIDITY_START_DATE FROM DUAL 
  UNION SELECT USERNAME, 'WTPAAGENT' ROLE_CODE, TRUNC(SYSDATE) VALIDITY_START_DATE FROM DUAL
  
  
  select * from CUSTOMER.KOC_AUTH_USER_ROLE_REL where username in ('WFIBA7482_60000', 'WFIBA3562_60190');
