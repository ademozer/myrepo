BEGIN
  FOR rec_1 IN (
             SELECT COLUMN_VALUE 
               FROM TABLE(CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.convertPayloadToTable('[{"AD":"ADEM"},{"SOYAD":"OZER"}]'))
              ) 
          LOOP
        DBMS_OUTPUT.PUT_LINE('AA');
END LOOP;
END;

select * from user_errors
select * from dba_tab_privs WHERE TABLE_NAME='ALZ_HCL_SPECIALITY_SUBJECT_TBL'
customer.ALZ_HLTH_KARMA_UTILS.doktor_brans_list_kontrol(:Koc_Clm_Hlth_Detail.product_id,
                                                                      customer.ALZ_HLTH_KARMA_UTILS.is_police_Complementary (:koc_clm_hlth_detail.contract_id),
                                                                      decode(:koc_clm_hlth_detail.plan_tip, 'KARMA', 2, 'TSS', 1, '�SS', 0, null, customer.ALZ_HLTH_KARMA_UTILS.is_police_Complementary (:koc_clm_hlth_detail.contract_id), 0),
                                                                      :koc_clm_hlth_detail.institute_code,
                                                                      :STAT_INFO.SGK_ANLASMA,
                                                                      specialty_subject
                                                                      
                                                                      
                                                                      
                                                                     SELECT TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS') FROM DUAL
                                                                     SELECT EXTRACT (HH24:MI FROM SYSDATE) FROM DUAL
                                                                     
select identity_no,count(*) 
from koc_cp_partners_ext 
where identity_no IS NOT NULL 
AND is_health_partner=1
AND identity_no !='00000000000' 
AND identity_no != ' '
AND  rownum<100000
group by identity_no 
having count(*)>2


koc_clm_hlth_utils.getClassDiseaseDesc

SELECT a.class_disease_child_code,Substr(b.Long_Name, 1, 200)
      
      FROM Koc_Oc_Icd_Levels a, Inf_v_Lang_Trans_Api_Tr b
     WHERE a.Desc_Int_Id = b.Desc_Int_Id
      -- AND a.Class_Disease_Child_Code = p_Class_Disease_Code;
      SELECT RTRIM('19759,',',') XX FROM DUAL
