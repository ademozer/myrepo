DECLARE 
  v_tmp_params VARCHAR2(4000) := '{"key1" : "value1", "key2" : ["value2.1","value2.2"]}';  
BEGIN
      
       v_tmp_params := replace(replace(replace(replace(v_tmp_params,'[{', ''),'}',''),'}]',''),'{','');

         FOR rec IN 
               ( SELECT trim(replace (Regexp_Substr (Xt.Element, '[^:]+', 1) , '"',''))   KEY,
                       trim(replace (Regexp_Substr (Xt.Element, '[^:]+', 1, 2), '"','')) VALUE 
                  FROM (Select Regexp_Substr (v_tmp_params,
                                              '[^,]+',
                                              1,
                                              Level)
                                      Element
                              From Dual
                        Connect By Level <= Length (Regexp_Replace (v_tmp_params, '[^,]+')) + 1) Xt) LOOP
   
                  DBMS_OUTPUT.PUT_LINE(rec.KEY || '-' || rec.VALUE);     
           END LOOP;
 END;
