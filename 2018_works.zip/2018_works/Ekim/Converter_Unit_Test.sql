--Converter Unit_Test
--PASS HRCL1-404 
SELECT CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.getTDAProcessDesc(10,10,101,SYSDATE) FROM DUAL;
--PASS HRCL1-404 
SELECT SPECIALTY_SUBJECT doctor_type_code, EXPLANATION Doctor_Type FROM TABLE(CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.getDoctorAgreementTypeList);
--PASS HRCL1-403 
SELECT CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.getClassDiseaseDesc('5Z1386') FROM DUAL;
--PASS HRCL1-406 
SELECT * FROM TABLE(CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.getSpecialitySubjectList(SYSDATE,64,356215039,'KARMA', 8, '1'));
--PASS HRCL1-407 
SELECT CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.getUnitHierarchy(13,SYSDATE) FROM DUAL;


--test kart no : 5152938


select a.POLICY_REF,a.POLICY_START_DATE,a.CONTRACT_ID,b.PART_ID,b.CARD_NO,c.IDENTITY_NO, a.COMPANY_CODE
  from KOC_V_HEALTH_INSURED_INFO a, koc_hlth_customer_id_cards b, koc_cp_partners_ext c
 WHERE a.PARTNER_ID = b.PART_ID
   AND c.PART_ID = b.PART_ID
   AND a.POLICY_REF='0001171006126709' 
   AND b.VALIDITY_END_DATE IS NULL


SELECT a.*
FROM Koc_v_Cp_Health_Look_Up a
WHERE a.Look_Up_Code = 'CLIT2'
AND a.Sula_Ora_Nls_Code = 'TR'
AND a.Parameter IN ('1', '2', '3', '4', '5')
ORDER BY Parameter


select * from clm_pol_bases where contract_id=356215039
select * from clm_pol_oar where claim_id=34396769
select * from koc_clm_hlth_detail where contract_id=356215039


koc_clm_hlth_utils.getTDAProcessInfo

SELECT koc_clm_hlth_utils.Getspecialtydesc(1620) FROM DUAL
