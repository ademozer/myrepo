KOC_CLM_HLTH_TRNX.Set_sms_deny
 Koc_Clm_Hlth_Bpm_Utils.Getauthinf
 
 koc_clm_hlth_match_api.match
 
 ALZ_HLTH_KARMA_UTILS
 
 KOC_CLM_HLTH_TRNX
 
 SELECT name,
        SUM(CASE WHEN UPPER(text) LIKE '%TYPE%' THEN 1 ELSE 0 END) column_type,
        SUM(CASE WHEN UPPER(text) NOT LIKE '%TYPE%' THEN 1 ELSE 0 END) table_access
 from all_source where TYPE='TYPE' and  UPPER(text) like '%KOC_CLM_HLTH_INDEM_TOTALS%'
 group by name
 --and UPPER(text) NOT LIKE '%TYPE%' 
 
 SELECT COUNT(*) from all_source where  name='ALZ_HLTPRV_UTILS' and TYPE='PACKAGE BODY' and UPPER(text) like '%KOC_CLM_HLTH_INDEM_TOTALS%'
 and UPPER(text) LIKE '%TYPE%' 
