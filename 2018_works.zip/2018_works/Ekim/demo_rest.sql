--SELECT UTL_HTTP.request('http://10.70.225.202:7001/hclm-utility-service/api/v1/specialtysubjects/list') FROM DUAL

--SELECT UTL_HTTP.request('www.google.com') FROM DUAL
DECLARE
  --v_URL VARCHAR2(500) := 'http://10.70.225.202:7001/hclm-utility-service/api/v1/specialtysubjects/list';
  v_Url               VARCHAR2(1000);
  v_Response          CLOB;
  v_Request           CLOB;
  v_Status            NUMBER;
  v_Message           VARCHAR2(4000);
 -- v_converter_col CUSTOMER.alz_hcl_converter_col := CUSTOMER.alz_hcl_converter_col(null,null);
 -- v_converter_row CUSTOMER.alz_hcl_converter_row := CUSTOMER.alz_hcl_converter_row();
  --v_converter_tbl CUSTOMER.alz_hcl_converter_tbl := CUSTOMER.alz_hcl_converter_tbl();
  v_tmp_data CLOB; 
  v_first_node_name VARCHAR2(400);
  v_count PLS_INTEGER := 0;
  v_key VARCHAR2(400);
  v_value VARCHAR2(400);
  v_result NUMBER;
Procedure Call_Rest_Service(p_Url               In          Varchar2,
                            p_Method            In          Varchar2, -- GET,POST                                                                              
                            p_Request           In          Clob,                    
                            p_Response          Out         Clob, 
                            p_Status            Out         Number, -- 0-SUCCESS, 1-FAIL
                            p_Message           Out         Varchar2 
                          ) Is             
        v_Req               utl_http.req;
        v_Req_Length        Number;
        v_Res               utl_http.resp;
        v_Buffer            Varchar2(32767);
        v_Offset            Number := 1;
        v_Amount            Number :=32767;
        v_Utl_Err           Varchar2(1000);
        v_value             varchar2(4000);
        hata_code           varchar2(10);
        v_output            varchar2(10);
        v_Response          CLOB;
        v_Line_Number       NUMBER := 0;
    Begin
        v_Req_Length := dbms_lob.getlength(p_Request);
        v_Req := utl_http.begin_request(p_Url, p_Method, 'HTTP/1.1');       
        utl_http.set_header(v_Req, 'Content-Length', v_Req_Length);
        utl_http.set_header(v_Req, 'Content-Type', 'application/json;charset=UTF-8');
        utl_http.set_header (v_Req,'Transfer-Encoding', 'chunked' );
        utl_http.set_body_charset(v_Req,'UTF-8');
        While (v_Offset < v_Req_Length)
        Loop
           dbms_lob.read(p_Request, v_Amount, v_Offset, v_Buffer);
           utl_http.write_text(r    => v_Req, data => v_Buffer);
           v_Offset := v_Offset + v_Amount;
        End Loop;
        v_Res := utl_http.get_response(v_Req);
        IF v_Res.status_code != 200  THEN 
            Raise_Application_Error(-20200, v_Res.status_code || ' - Hata Olu�tu');      
        END IF; 
        Begin
           loop
              utl_http.read_line(v_Res, v_value);
              IF v_Line_Number = 0 THEN               
                 v_value := '';
              END IF;
              --dbms_output.put_line(v_value);
              IF REGEXP_LIKE(v_value, '"uiMessages" :') THEN                
                  v_value := TRIM(LTRIM(TRIM(v_value),'"uiMessages" :'));                 
                  IF NOT REGEXP_LIKE(v_value, 'null') THEN                      
                       p_Status := 1;
                       p_Message := v_value;
                  END IF; 
              ELSE 
                  IF REGEXP_LIKE(TRIM(v_value),  '"data" :') THEN
                      v_value := TRIM(LTRIM(TRIM(v_value),'"data" :'));                       
                      IF INSTR(v_value,',')>0 THEN
                           v_value := TRIM(regexp_replace(v_value, '([^[:graph:] | ^[:blank:]])', ''));
                           v_value := RTRIM(v_value,','); 
                           --dbms_output.put_line('aa');
                      END IF;                  
                  END IF;
                  IF TRIM(v_value) IN ('{','}') THEN
                     -- dbms_output.put_line(v_value); 
                      v_value := '';                 
                  END IF;  
                  IF REGEXP_LIKE(TRIM(v_value),  '} ],') THEN 
                      --dbms_output.put_line(v_value); 
                      v_value := '}]';                 
                  END IF;   
                  --v_value := RTRIM(v_value,',');                  
                  v_Response := v_Response || v_value;
                  --dbms_output.put_line(v_value);
              END IF;
              v_Line_Number := v_Line_Number + 1;
           end loop;
             utl_http.end_response(v_Res);
        Exception
        When utl_http.end_of_body Then
             utl_http.end_response(v_Res);
        When utl_http.too_many_requests Then
             utl_http.end_response(v_Res);
        When Others Then
             utl_http.end_response(v_Res);
       End;      
       IF p_Status = 1 THEN
           p_Response := '';
           RETURN;
       END IF;
       p_Response := TRIM(v_Response);
       p_Status := 0;
       p_Message := 'Sorgulama Ba�ar�l�';
    exception when others then
    utl_http.end_response(v_Res);
    v_utl_err:= Utl_Http.Get_Detailed_Sqlerrm;
    p_Status := 1;
    p_Response := '';
    p_Message := v_utl_err||' - '||p_url;
End Call_Rest_Service;

BEGIN
    --v_Url := 'http://10.70.225.202:7001/hclm-utility-service/api/v1/specialtysubjects/list';
    v_Url := --'http://10.70.225.42:7001/hclm-process-service/api/v1/tdaprocess/name/get';
    'http://10.70.225.202:7001/hclm-utility-service/api/v1/unitHierarchy';
    
    v_Url:= v_Url || '/'||'13'
            ||'?validityDate='||TO_CHAR(SYSDATE,'YYYY-MM-DD');
   /* v_Request := '{
                    "processCodeMain": 10,
                    "processCodeSub1": 10,
                    "processCodeSub2": 101,
                    "validityStartDate": "2018-10-31"
                  }';*/
    DBMS_OUTPUT.put_line(SYSTIMESTAMP);
    --Call_Rest_Service(v_Url, 'POST', v_Request, v_Response, v_Status, v_Message);
    Call_Rest_Service(v_Url, 'GET', v_Request, v_Response, v_Status, v_Message);
    DBMS_OUTPUT.PUT_LINE('Response='||v_Response);
    BEGIN
       v_result := TO_NUMBER(v_Response);
    EXCEPTION
      WHEN OTHERS THEN
          v_result := 0;
    END;
    DBMS_OUTPUT.put_line(v_result);
    DBMS_OUTPUT.put_line (SYSTIMESTAMP);
   /* v_tmp_data := v_Response;
    v_tmp_data := replace(replace(replace(replace(v_tmp_data,'[{', ''),'}',''),'}]',''),'{','');

      FOR rec IN ( SELECT trim(replace (Regexp_Substr (Xt.Element, '[^:]+', 1) , '"',''))   KEY,
                          trim(replace (Regexp_Substr (Xt.Element, '[^:]+', 1, 2), '"','')) VALUE
                    FROM (SELECT Regexp_Substr (v_tmp_data,'[^,]+',1,Level) Element
                            FROM Dual
                         CONNECT BY LEVEL <= Length (Regexp_Replace (v_tmp_data, '[^,]+')) + 1) Xt) LOOP
         -- v_key := REPLACE(rec.KEY,'[','');
         -- v_key := TRIM(regexp_replace(v_key, '([^[:graph:] | ^[:blank:]])', ''));
         -- v_value :=  REPLACE(rec.VALUE,']','');
         -- v_value := TRIM(regexp_replace(v_value, '([^[:graph:] | ^[:blank:]])', ''));
          IF v_count = 0 THEN
             v_first_node_name := v_key;
          END IF;
          IF v_count>0 AND v_first_node_name = v_key THEN
              v_converter_tbl.EXTEND;
              v_converter_tbl(v_converter_tbl.COUNT) := v_converter_row;
              v_converter_row := alz_hcl_converter_row();
          END IF;
          v_converter_col.field_name := v_key;
          v_converter_col.field_value := v_value;
          v_converter_row.EXTEND;
          v_converter_row(v_converter_row.COUNT) := v_converter_col;
          v_count := v_count + 1;
          IF v_count = 10 THEN EXIT; END IF;
     END LOOP;
     v_converter_tbl.EXTEND;
     v_converter_tbl(v_converter_tbl.COUNT) := v_converter_row;*/
     DBMS_OUTPUT.put_line (SYSTIMESTAMP);
     --v_converter_tbl := CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.convertPayloadToTable(v_Response);
     --v_tmp_data := '[{"specialitySubject":"1600"}]';
     v_tmp_data := v_Response;
     --v_converter_tbl := CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.convertPayloadToTable(v_tmp_data);
     v_count := 0;
    FOR rec_1 IN (SELECT COLUMN_VALUE FROM TABLE(CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.convertPayloadToTable(v_tmp_data))) LOOP
        dbms_output.put_line(v_count || ' .row ...............');
        FOR rec_2 IN (SELECT FIELD_NAME, FIELD_VALUE FROM TABLE(rec_1.COLUMN_VALUE)) LOOP
              dbms_output.put_line(rec_2.FIELD_NAME||' - '||rec_2.FIELD_VALUE);
        END LOOP;
        v_count := v_count + 1;
        IF (v_count = 10) THEN EXIT; END IF;
    END LOOP;
    DBMS_OUTPUT.put_line (SYSTIMESTAMP);
       --RETURN v_converter_tbl;

    dbms_output.put_line('status='||v_Status);
    dbms_output.put_line('message='||v_Message);
    --dbms_output.put_line(v_Response);  
END;
--SELECT * FROM TABLE(CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.convertPayloadToTable('{["a":"A","B":"B"}]'));
--koc_clm_hlth_detail
