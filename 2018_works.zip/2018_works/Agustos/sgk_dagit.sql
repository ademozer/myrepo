PROCEDURE Sgk_Dagit IS

	v_Sgk_Total_Used     NUMBER := 0;
	v_Sgk_Used_For_Cover NUMBER := 0;
	Currblock            VARCHAR2(100);
	Currrecord           VARCHAR2(100);
	Curritem             VARCHAR2(100);
	Currrecord_Prv       VARCHAR2(100);
	v_Refusal_Total      NUMBER;
	Currec               NUMBER;

BEGIN
null;
/*
	IF Nvl(:Koc_Clm_Hlth_Detail.Is_Complementary, 0) <> 1 --TSS değilse dağıt
	THEN
	
		--
		IF :Koc_Clm_Hlth_Detail.Status_Code = 'P'
		THEN
			:Koc_Clm_Hlth_Detail.Status_Code := 'CP';
		ELSIF :Koc_Clm_Hlth_Detail.Status_Code = 'R'
		THEN
			:Koc_Clm_Hlth_Detail.Status_Code := 'CPR';
		END IF;
	
		Currec     := Get_Block_Property('CONTROL', Current_Record);
		Currblock  := :System.Cursor_Block;
		Currrecord := :System.Cursor_Record;
		Curritem   := :System.Cursor_Item;
	
		IF Currblock <> 'KOC_CLM_HLTH_PROVISIONS'
		THEN
			Go_Block('KOC_CLM_HLTH_PROVISIONS');
		END IF;
	
		Currrecord_Prv := :System.Cursor_Record;
	
		Koc_Clm_Hlth_Trnx.Find_Exemption_Limit('E', :Koc_Clm_Hlth_Detail.Claim_Id, :Koc_Clm_Hlth_Detail.Sf_No, :Koc_Clm_Hlth_Detail.Add_Order_No,
																					 :Koc_Clm_Hlth_Detail.Rel_Claim_Id, :Control.Exemption_Amount);
	
		IF :Control.Exemption_Amount IS NULL
		THEN
			:Control.Exemption_Amount := 0;
		END IF;
	
		:Control.Exemption_Tmp := :Control.Exemption_Amount;
	
		IF Currblock <> 'KOC_CLM_HLTH_PROVISIONS'
		THEN
			Go_Block('KOC_CLM_HLTH_PROVISIONS');
		END IF;
	
		First_Record;
		LOOP
			:Koc_Clm_Hlth_Provisions.Exemption_Amount := 0;
			:Koc_Clm_Hlth_Provisions.Sgk_Amount       := 0;
		
			IF :Koc_Clm_Hlth_Provisions.Status_Code = 'P'
			THEN
				:Koc_Clm_Hlth_Provisions.Status_Code := 'CP';
				Set_Location_Items(:Koc_Clm_Hlth_Provisions.Status_Code, :Koc_v_Hlth_Users.Banko_User); --
			ELSIF :Koc_Clm_Hlth_Provisions.Status_Code = 'R'
			THEN
				:Koc_Clm_Hlth_Provisions.Status_Code := 'CPR';
				Set_Location_Items(:Koc_Clm_Hlth_Provisions.Status_Code, :Koc_v_Hlth_Users.Banko_User); --
			END IF;
		
			IF :Koc_Clm_Hlth_Provisions.Status_Code IN ('CPR', 'PR', 'R')
			THEN
				v_Refusal_Total := Nvl(v_Refusal_Total, 0) + Nvl(:Koc_Clm_Hlth_Provisions.Request_Amount, 0);
			ELSE
				v_Refusal_Total := Nvl(v_Refusal_Total, 0) + Nvl(:Koc_Clm_Hlth_Provisions.Refusal_Amount, 0);
			END IF;
		
			EXIT WHEN :System.Last_Record = 'TRUE';
			Next_Record;
		END LOOP;
	
		Synchronize;
		v_Sgk_Total_Used := 0;
	
		First_Record;
		LOOP
			Talep_Edilmemesi_Gereken_Tutar;
			IF Nvl(v_Refusal_Total, 0) - Nvl(:Koc_Clm_Hlth_Detail.Talep_Edilmemesi_Gereken, 0) < Nvl(:Koc_Clm_Hlth_Detail.Sgk_Total, 0)
			THEN
				IF Nvl(:Koc_Clm_Hlth_Provisions.Status_Code, 'PP') NOT IN ('CP', 'P', 'PP')
				THEN
					v_Sgk_Used_For_Cover := 0;
				ELSE
					v_Sgk_Used_For_Cover := 0;
					IF v_Sgk_Total_Used < Nvl(:Koc_Clm_Hlth_Detail.Sgk_Total, 0)
					THEN
						:Koc_Clm_Hlth_Provisions.Talep_Edilmemesi_Gereken_Cover := 0;
						Talep_Edilmemesi_Gereken_Cover(:Koc_Clm_Hlth_Provisions.Cover_Code);
					
						IF Nvl(:Koc_Clm_Hlth_Provisions.Request_Amount, 0) - Nvl(:Koc_Clm_Hlth_Provisions.Talep_Edilmemesi_Gereken_Cover, 0) >=
							 Nvl(:Koc_Clm_Hlth_Detail.Sgk_Total, 0) - Nvl(v_Sgk_Total_Used, 0)
						THEN
							v_Sgk_Used_For_Cover := Nvl(:Koc_Clm_Hlth_Detail.Sgk_Total, 0) - Nvl(v_Sgk_Total_Used, 0);
						ELSE
							v_Sgk_Used_For_Cover := :Koc_Clm_Hlth_Provisions.Request_Amount - Nvl(:Koc_Clm_Hlth_Provisions.Talep_Edilmemesi_Gereken_Cover, 0);
						END IF;
						v_Sgk_Total_Used := Nvl(v_Sgk_Total_Used, 0) + Nvl(v_Sgk_Used_For_Cover, 0);
					END IF;
				END IF;
				:Koc_Clm_Hlth_Provisions.Sgk_Amount := v_Sgk_Used_For_Cover;
				Set_Item_Instance_Property('CONTROL.SGK_TMP', Currec, Visual_Attribute, 'VA_DISPLAY_ITEM');
			ELSE
				Set_Item_Instance_Property('CONTROL.SGK_TMP', Currec, Visual_Attribute, 'VA_PROVISION');
			END IF;
 
		
			EXIT WHEN :System.Last_Record = 'TRUE';
			Next_Record;
		END LOOP;
	
		Synchronize;
		:Control.Sgk_Calis := 1;
	
		IF Currrecord_Prv IS NOT NULL
		THEN
			Go_Record(Currrecord_Prv);
		END IF;
	
		IF Currblock <> 'KOC_CLM_HLTH_PROVISIONS'
		THEN
			IF Currblock IS NOT NULL
			THEN
				Go_Block(Currblock);
			END IF;
		END IF;
	
		Go_Item(Curritem);
	END IF; --TSS değilse
	*/
END;