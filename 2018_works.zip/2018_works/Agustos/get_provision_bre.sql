PROCEDURE Get_Provision_Bre(p_Give_Message NUMBER) IS
	Clmdetail               Koc_Clm_Hlth_Trnx.Clmdetailtype;
	Clmprovision            Koc_Clm_Hlth_Trnx.Clmprovisiontype;
	Clmprocdetail           Koc_Clm_Hlth_Trnx.Clmprocdetailtyp;
	Clmrejection            Koc_Clm_Hlth_Trnx.Clmrejectiontype;
	Clmmedicineindem        Koc_Clm_Hlth_Trnx.Clmmedicineindemtype;
	Clmvaccindem            Koc_Clm_Hlth_Trnx.Clmvaccindemtype;
	Clmitemdetail           Koc_Clm_Hlth_Trnx.Clmitemindemtype;
	v_Diseases              Alz_Hltprv_Utils.Diseases := Alz_Hltprv_Utils.Diseases();
	v_Diseases_Count        NUMBER;
	v_Claim_Id              NUMBER;
	v_Sf_No                 NUMBER;
	v_Detail_No             NUMBER;
	v_Can_Be_Recourse       NUMBER;
	v_Recourse_Amount       NUMBER;
	v_Recourse_Clm_Amount   NUMBER;
	v_Recourse_Rate_100     NUMBER;
	v_Recourse_Rate_8       NUMBER;
	v_Recourse_Status       NUMBER;
	v_Contract_Id           NUMBER;
	v_Partition_No          NUMBER;
	v_User_Id               VARCHAR2(30) := :Boiler.Userid;
	Is_All_Auth             BOOLEAN := FALSE;
	Is_All_Refuse           BOOLEAN := TRUE;
	i                       NUMBER := 0;
	j                       NUMBER := 0;
	k                       NUMBER := 0;
	v_Reject                NUMBER;
	p_Process_Status        NUMBER;
	Timerid                 Timer;
	p_Out_Over_Price        VARCHAR2(200);
	v_Checkrunningtimercode VARCHAR2(2000);
	v_Cml_Total             NUMBER;
	p_Valid                 BOOLEAN;
	v_Ext                   NUMBER;
	v_Exemption_Sum         NUMBER;
	v_Status                NUMBER;
	v_Message_Claim         VARCHAR2(1000);
	v_Error_Claim           VARCHAR2(1000);
	v_Has_Error_Claim       NUMBER;
	v_Message_Cover         VARCHAR2(1000);
	v_Error_Cover           VARCHAR2(1000);
	v_Has_Error_Cover       NUMBER;
	v_Message_Process       VARCHAR2(1000);
	v_Error_Process         VARCHAR2(1000);
	v_Has_Error_Process     NUMBER;
	v_Message_Vacine        VARCHAR2(1000);
	v_Error_Vacine          VARCHAR2(1000);
	v_Has_Error_Vacine      NUMBER;
	Startreq                Customer.Web_Provision.Startazprovision_Req;
	Startres                Customer.Web_Provision.Startazprovision_Res;
	v_Msg_Level             NUMBER;
	Providereq              Customer.Web_Provision.Provideprovision_Req;
	Provideres              Customer.Web_Provision.Provideprovision_Res;
	v_Is_Authorized         NUMBER;
	v_User_Name             VARCHAR2(15);
	p_Status_Code           VARCHAR2(10);
	v_Vip_Degree            VARCHAR2(10);
	v_Is_Rejected           NUMBER;
	v_Devam                 BOOLEAN;
	v_Cover_Table           Koc_Clm_Hlth_Hosp_Med_Utils.Covermsg_Table;
	v_Process_Table         Koc_Clm_Hlth_Hosp_Med_Utils.Processmsg_Table;
	v_Clm_Check             NUMBER := 0;
	v_Error_Exp             VARCHAR2(500);
	v_Cover_Code            NUMBER DEFAULT 0;
	v_Adet                  NUMBER;
	v_Fax_Claim_Id          NUMBER;
	v_Indem_Type            Koc_Clm_Hlth_Indem_Totals.Indemnity_Payment_Type%TYPE;
	Uyari_Listesi           Koc_Clm_Hlth_Hosp_Med_Utils.Message_Table := Koc_Clm_Hlth_Hosp_Med_Utils.Message_Table();
	v_Current_Item          VARCHAR(100);
	v_Aso                   NUMBER;

	-- 20150102 --emre.elcik--
	-- BRERuleEngineWs için eklenen degiskenler
	TYPE Io_Cursor1 IS REF CURSOR;
	Io_Cursor     Io_Cursor1;
	v_Errmessage  VARCHAR2(32000);
	v_Ind         NUMBER := 0;
	v_Processrecs Customer.Alz_Hltprv_Utils.Processrecs := Customer.Alz_Hltprv_Utils.Processrecs();
	v_Coverrecs   Customer.Alz_Hltprv_Utils.Coverrecs := Customer.Alz_Hltprv_Utils.Coverrecs();

	v_Last          NUMBER;
	v_Maincode      NUMBER;
	v_Itemcode      NUMBER;
	v_Subitemcode   NUMBER;
	v_Screenmessage VARCHAR2(1000);
	v_Printmessage  VARCHAR2(1000);
	v_Decision_Type VARCHAR2(10);
	v_Barcode       NUMBER;

	TYPE Message_Table_Va_Type IS TABLE OF VARCHAR2(50);
	Message_Table_Va Message_Table_Va_Type := Message_Table_Va_Type();
	--

	CURSOR C1 IS
		SELECT COUNT(b.Claim_Id) v_Cnt,
					 SUM(Recourse_Clm_Amount) Recourse_Clm_Amount
			FROM Koc_Clm_Detail b
		 WHERE b.Claim_Id = :Koc_Clm_Hlth_Detail.Claim_Id
			 AND b.Sf_No = :Koc_Clm_Hlth_Detail.Sf_No
			 AND b.Detail_No = 1
			 AND b.Can_Be_Recourse = 1
			 AND Nvl(b.Recourse_Status, 1) IN (1, 2, 5, 6);

	C1_Rec C1%ROWTYPE;

	CURSOR c_Indem_Type IS
		SELECT a.Indemnity_Payment_Type
			FROM Koc_Clm_Hlth_Indem_Totals a
		 WHERE Contract_Id = :Koc_Clm_Hlth_Detail.Contract_Id
			 AND Partition_No = :Koc_Clm_Hlth_Detail.Partition_No
			 AND Country_Group = :Koc_Clm_Hlth_Detail.Country_Group
			 AND Claim_Inst_Type = :Koc_Clm_Hlth_Detail.Claim_Inst_Type
			 AND Claim_Inst_Loc = :Koc_Clm_Hlth_Detail.Claim_Inst_Loc
			 AND Is_Pool_Cover = :Koc_Clm_Hlth_Provisions.Is_Pool_Cover
			 AND Is_Special_Cover = :Koc_Clm_Hlth_Provisions.Is_Special_Cover
			 AND Cover_Code = :Koc_Clm_Hlth_Provisions.Cover_Code
			 AND Package_Id = :Koc_Clm_Hlth_Detail.Package_Id
			 AND Package_Date = :Koc_Clm_Hlth_Detail.Package_Date;

	CURSOR c_Silinen_Islemler IS
		SELECT Process_Code_Main,
					 Process_Code_Sub1,
					 Process_Code_Sub2
			FROM Web_Clm_Hlth_Proc_Detail
		 WHERE Claim_Id = :Koc_Clm_Hlth_Detail.Claim_Id
			 AND Sf_No = :Koc_Clm_Hlth_Detail.Sf_No
			 AND Location_Code = :Koc_Clm_Hlth_Provisions.Location_Code
			 AND Add_Order_No = :Koc_Clm_Hlth_Detail.Add_Order_No
			 AND Cover_Code = :Koc_Clm_Hlth_Provisions.Cover_Code
		MINUS
		SELECT Process_Code_Main,
					 Process_Code_Sub1,
					 Process_Code_Sub2
			FROM Koc_Clm_Hlth_Proc_Detail
		 WHERE Claim_Id = :Koc_Clm_Hlth_Detail.Claim_Id
			 AND Sf_No = :Koc_Clm_Hlth_Detail.Sf_No
			 AND Location_Code = :Koc_Clm_Hlth_Provisions.Location_Code
			 AND Add_Order_No = :Koc_Clm_Hlth_Detail.Add_Order_No
			 AND Cover_Code = :Koc_Clm_Hlth_Provisions.Cover_Code;

	Rec_Silinen_Islemler c_Silinen_Islemler%ROWTYPE;
	v_Yt_Count           NUMBER;

	CURSOR c_Status_Code(Pp_Claim_Id NUMBER,
											 Pp_Sf_No    NUMBER) IS
		SELECT Status_Code
			FROM Koc_Clm_Hlth_Detail x
		 WHERE x.Claim_Id = Pp_Claim_Id
			 AND x.Sf_No = Pp_Sf_No;

	CURSOR Cur_Aso IS
		SELECT COUNT(*)
			FROM Koc_Clm_Hlth_Aso_Prov
		 WHERE Claim_Id = :Koc_Clm_Hlth_Detail.Claim_Id
			 AND Sf_No = :Koc_Clm_Hlth_Detail.Sf_No
			 AND Add_Order_No = :Koc_Clm_Hlth_Detail.Add_Order_No
			 AND Location_Code = :Koc_Clm_Hlth_Provisions.Location_Code
			 AND Cover_Code = :Koc_Clm_Hlth_Provisions.Cover_Code;

BEGIN
  v_Devam                 := TRUE;
	v_Checkrunningtimercode := Checkrunningtimercode;

	IF v_Checkrunningtimercode IS NOT NULL
	THEN
		Opu001.Msg(999999, 'W', NULL, NULL, NULL, v_Checkrunningtimercode);
		RAISE Form_Trigger_Failure;
	END IF;

	IF :Koc_Clm_Hlth_Detail.Claim_Id IS NULL
	THEN
		RAISE Form_Trigger_Failure;
	END IF;

	IF :Koc_Clm_Hlth_Detail.Contract_Id IS NULL AND
		 :Koc_v_Hlth_Users.Banko_User != 1 AND
		 Nvl(:Koc_Clm_Hlth_Detail.Status_Code, 'PP') != 'GECERSIZ'
	THEN
		Opu001.Msg(999999, 'Q', NULL, NULL, NULL, 'Uygun bir poliçe belirlenemedi. Devam etmek istediğinizden emin misiniz?');
	
		IF Opu001.v_Alert_Button != Alert_Button1
		THEN
			RAISE Form_Trigger_Failure;
		END IF;
	END IF;
 
	Koc_Clm_Hlth_Bpm_Utils.Getvipdegree(:Koc_Clm_Hlth_Detail.Part_Id, :Koc_Clm_Hlth_Detail.Claim_Id, v_Vip_Degree, v_Is_Rejected);
 
	IF v_Vip_Degree = '3' AND
		 v_Is_Rejected = 1
	THEN
		Opu001.Msg(999999, 'Q', NULL, NULL, NULL,
							 '3.derece VIP sigortalıdır, red işlemi yöneticinizden onay almanız gerekmektedir, devam etmek istiyor musunuz?');
		IF Opu001.v_Alert_Button != Alert_Button1
		THEN
			v_Devam := FALSE;
		END IF;
	END IF;

	IF v_Devam
	THEN
		BEGIN
			IF Nvl(:Koc_Clm_Hlth_Detail.Status_Code, 'PP') IN ('PP', 'I', 'PR', 'PI', 'P', 'KI', 'MI', 'CPR', 'CPI', 'CIR', 'CP', 'GECERSIZ')
			THEN
			
				Go_Item('KOC_CLM_HLTH_TMP_PROC_DETAIL.process_code_desc');
				Next_Item;
				Go_Item('koc_clm_hlth_provisions.LOCATION_CODE_DESC');
				Next_Item;
			
				Collectrejectdata(v_Reject, Clmrejection);
			
				Setmedicineindem(Clmmedicineindem, Clmrejection);
			
				Setclmrucudata(v_Claim_Id, v_Sf_No, v_Detail_No, v_Can_Be_Recourse, v_Recourse_Amount, v_Recourse_Clm_Amount, v_Recourse_Rate_100,
											 v_Recourse_Rate_8, v_Recourse_Status);
			
				i := 0;
	
				Go_Block('koc_clm_hlth_detail');
				v_Contract_Id  := :Koc_Clm_Hlth_Detail.Contract_Id;
				v_Partition_No := :Koc_Clm_Hlth_Detail.Partition_No;
			
				IF v_Reject != 0
				THEN
					IF Nvl(:Koc_Clm_Hlth_Detail.Status_Code, 'PP') = 'PP'
					THEN
						:Koc_Clm_Hlth_Detail.Status_Code := 'PR';
					ELSIF Nvl(:Koc_Clm_Hlth_Detail.Status_Code, 'PP') IN ('CP', 'P', 'KI', 'MI')
					THEN
						:Koc_Clm_Hlth_Detail.Status_Code := 'CPR';
					ELSIF Nvl(:Koc_Clm_Hlth_Detail.Status_Code, 'PP') = 'I'
					THEN
						:Koc_Clm_Hlth_Detail.Status_Code := 'R';
					ELSIF Nvl(:Koc_Clm_Hlth_Detail.Status_Code, 'PP') = 'PI'
					THEN
						:Koc_Clm_Hlth_Detail.Status_Code := 'PR';
					END IF;
				END IF;
			
				IF Nvl(:Koc_Clm_Hlth_Detail.Status_Code, 'PP') = 'GECERSIZ'
				THEN
					:Koc_Clm_Hlth_Detail.Status_Code        := 'PR';
					:Koc_Clm_Hlth_Provisions.Status_Code    := 'PR';
					:Koc_Clm_Hlth_Provisions.Refusal_Amount := :Koc_Clm_Hlth_Provisions.Request_Amount;
				ELSE
					IF v_Contract_Id IS NULL
					THEN
						:Koc_Clm_Hlth_Detail.Status_Code := 'PI';
					END IF;
				END IF;
			
				Setclaimdetail(Clmdetail);
			
				i := 0;
			
				v_Cover_Table.Delete;
				v_Process_Table.Delete;
				Clmprovision.Delete;
				Clmprocdetail.Delete;
				Clmitemdetail.Delete;
			
				Go_Block('koc_clm_hlth_provisions');
				First_Record;
				LOOP
					IF Nvl(:Koc_Clm_Hlth_Provisions.Status_Code, 'PP') NOT IN ('P', 'R', 'C', 'TAH', 'ODE', 'PE')
					THEN
						-- ha muallak  13944:14/12/2009
						-- Task 12317 - e-provizyon -  her bir teminat için kontrol yapilmasi için eklendi.
						Go_Item('koc_clm_hlth_provisions.LOCATION_CODE_DESC');
						Next_Item;
					
						IF Nvl(:Koc_Clm_Hlth_Provisions.Provision_Total, 0) = 0
						THEN
							Opu001.Msg(999999, 'I', NULL, NULL, NULL, 'Şirket payı sıfır, hasar dosyasını reddetmelisiniz , provizyon veremezsiniz');
						END IF;
					
						IF :Koc_Clm_Hlth_Provisions.Location_Code IS NOT NULL
						THEN
							IF Nvl(:Koc_Clm_Hlth_Provisions.Request_Amount, 0) = 0
							THEN
								Opu001.Msg(999999, 'Q', NULL, NULL, NULL, 'Talep tutarı sıfır. Provizyon almak istediğinizden emin misiniz.?');
								--
								IF Opu001.v_Alert_Button != Alert_Button1
								THEN
									GOTO Son;
								END IF;
							END IF;
						
							--cozbay task_187995_YKS Grup saglik Poliçelerinin Opustan Yenilemesinin yapilmasi
							--ASO teminatlarinda detay girilmedi ise kizalim
							IF :Koc_Clm_Hlth_Provisions.Cover_Code IN ('S767', 'S768')
							THEN
								v_Aso := NULL;
							
								OPEN Cur_Aso;
								FETCH Cur_Aso
									INTO v_Aso;
								CLOSE Cur_Aso;
							
								IF Nvl(v_Aso, 0) = 0 AND
									 Nvl(:Koc_Clm_Hlth_Provisions.Inst_Request_Amount, 0) > 0 --mustafaku & gkorkmaz aso yu sıfır girip ret etmek istiyorlar 25.05.2015
								THEN
									Opu001.Msg(999999, 'E', NULL, NULL, NULL, 'Lütfen ASO bilgilerini giriniz!!');
									GOTO Son;
								END IF;
							END IF;
						
							--Task 12317
							IF Nvl(:Koc_Clm_Hlth_Provisions.Provision_Total, 0) = 0
							THEN
								Opu001.Msg(999999, 'I', NULL, NULL, NULL, 'Şirket payı sıfır.Varsa 2. poliçesinden kayıt giriniz, yoksa red giriniz!');
							END IF;
						
							IF :Koc_Clm_Hlth_Detail.Partition_Type = 'EKO1' AND
								 :Koc_Clm_Hlth_Provisions.Cover_Code IN ('S183', 'S552', 'S657', 'S508', 'S509', 'S557') AND
								 Trunc(Months_Between(:Koc_Clm_Hlth_Detail.Provision_Date, :Koc_Clm_Hlth_Detail.v_Plan_Entry_Date)) < 18
							THEN
								Opu001.Msg(999999, 'W', NULL, NULL, NULL, 'Dinamik Sağlık ürününde hamilelik için bekleme süresi 18 aydır !!!');
							END IF;
						
							--Task 12317
							OPEN c_Indem_Type;
						
							FETCH c_Indem_Type
								INTO v_Indem_Type;
						
							CLOSE c_Indem_Type;
						
							IF v_Indem_Type = 'DEFA'
							THEN
								OPEN c_Silinen_Islemler;
							
								FETCH c_Silinen_Islemler
									INTO Rec_Silinen_Islemler;
							
								IF c_Silinen_Islemler%FOUND
								THEN
									Opu001.Msg(999999, 'Q', NULL, NULL, NULL,
														 'İptal edilen işlem nedeniyle sigortalı teminat limitlerinin güncellenmesi gerekebilir.' || Chr(10) ||
															'Kalan limiti onay için girdiğiniz tutardan daha az ise bu dosyayı iptal ederek yeniden dosya açmanız gerekmektedir.' ||
															Chr(10) || 'Devam etmek istiyor musunuz? ');
								
									IF Opu001.v_Alert_Button != Alert_Button1
									THEN
										GOTO Son;
									END IF;
								END IF;
							
								CLOSE c_Silinen_Islemler;
							END IF;
						
							IF Nvl(:Koc_Clm_Hlth_Provisions.Inst_Request_Amount, 0) = 0
							THEN
								:Koc_Clm_Hlth_Provisions.Inst_Request_Amount := :Koc_Clm_Hlth_Provisions.Sys_Request_Amount;
							END IF;
						
							IF :Koc_Clm_Hlth_Provisions.Cover_Cat_Group = 'YT' AND
								 :Koc_Clm_Hlth_Detail.Hospitalize_Date IS NULL AND
								 :Koc_Clm_Hlth_Provisions.Cover_Code NOT IN ('S767', 'S768', 'S736', 'S692', 'S505', 'S539', 'S762', 'S520') --cozbay  asolar bu kontrole takilmasin task_187995_YKS Grup saglik Poliçelerinin Opustan Yenilemesinin yapilmasi / S736, 'S692','S505','S539','S762','S520' mustafaku iyanıkcan
							THEN
								Opu001.Msg(999999, 'E', NULL, NULL, NULL, 'Lütfen yatış tarihini giriniz.');
								Go_Item('koc_clm_hlth_detail.hospitalize_date');
								Show_View('CAN_HOSPITALIZE');
								Show_Window('WINDOW_HOSPITALIZE');
								Go_Item('koc_clm_hlth_detail.hospitalize_date');
								GOTO Son;
							END IF;
						
							IF Clmrejection.Count = 0 AND
								 Nvl(:Koc_Clm_Hlth_Provisions.Refusal_Amount, 0) != 0
							THEN
								Message('adet:' || Clmrejection.Count || 'tutar:' || Nvl(:Koc_Clm_Hlth_Provisions.Refusal_Amount, 0));
								Opu001.Msg(999999, 'E', NULL, NULL, NULL, 'Red nedeni seçiminde hata oluştu. Red nedenlerini kontrol ediniz !!!');
								RAISE Form_Trigger_Failure;
							END IF;
						
							IF Nvl(:Koc_Clm_Hlth_Provisions.Refusal_Amount, 0) = Nvl(:Koc_Clm_Hlth_Provisions.Request_Amount, 0)
							THEN
								IF Nvl(:Koc_Clm_Hlth_Provisions.Status_Code, 'PP') = 'PP' OR
									 (Nvl(:Koc_Clm_Hlth_Provisions.Status_Code, 'PP') = 'PI' AND :Koc_v_Hlth_Users.Banko_User != 1)
								THEN
									:Koc_Clm_Hlth_Provisions.Status_Code := 'PR';
								ELSIF Nvl(:Koc_Clm_Hlth_Provisions.Status_Code, 'PP') IN ('CP')
								THEN
									:Koc_Clm_Hlth_Provisions.Status_Code := 'CPR';
								END IF;
							END IF;
						
							IF :Koc_Clm_Hlth_Detail.Status_Code IN ('R', 'PR', 'CPR') AND
								 Nvl(:Koc_Clm_Hlth_Provisions.Status_Code, 'PP') IN ('PP')
							THEN
								:Koc_Clm_Hlth_Provisions.Status_Code := 'PR';
							END IF;
						
							i       := i + 1;
							p_Valid := TRUE;
						
							Setclaimprovisions(i, Clmprovision, v_Cover_Table, p_Valid);
						
							IF NOT p_Valid
							THEN
								Opu001.Msg(999999, 'E', NULL, NULL, NULL, 'Aynı teminat lokasyonu sadece 1 kez girebilirsiniz!');
								GOTO Son;
							END IF;
						
							IF Nvl(:Koc_Clm_Hlth_Provisions.Status_Code, 'PP') IN ('PI')
							THEN
								Is_All_Auth := TRUE;
							END IF;
						
							--
							Go_Block('KOC_CLM_HLTH_TMP_PROC_DETAIL');
							First_Record;
							LOOP
								IF :Koc_Clm_Hlth_Tmp_Proc_Detail.Process_Code_Main IS NOT NULL OR
									 :Koc_Clm_Hlth_Tmp_Proc_Detail.Process_Code_Sub1 IS NOT NULL OR
									 :Koc_Clm_Hlth_Tmp_Proc_Detail.Process_Code_Sub2 IS NOT NULL
								THEN
									j := j + 1;
									Setclaimprocdetail(j, Clmprocdetail, v_Process_Table);
								
									v_Processrecs.Extend;
									v_Ind := v_Processrecs.Last;
								
									v_Processrecs(v_Ind).Process_Code_Main := :Koc_Clm_Hlth_Tmp_Proc_Detail.Process_Code_Main;
									v_Processrecs(v_Ind).Process_Code_Sub1 := :Koc_Clm_Hlth_Tmp_Proc_Detail.Process_Code_Sub1;
									v_Processrecs(v_Ind).Process_Code_Sub2 := :Koc_Clm_Hlth_Tmp_Proc_Detail.Process_Code_Sub2;
									v_Processrecs(v_Ind).Inst_Indemnity_Amount := :Koc_Clm_Hlth_Tmp_Proc_Detail.Inst_Indemnity_Amount;
								
								END IF;
							
								EXIT WHEN :System.Last_Record = 'TRUE';
								Next_Record;
							END LOOP;
						
							--
						
							Go_Block('KOC_CLM_HLTH_TMP_ITEM_DETAIL');
							First_Record;
							LOOP
								IF :Koc_Clm_Hlth_Tmp_Item_Detail.Ubb_Code IS NOT NULL
								THEN
									k := k + 1;
								
									Pk_Item_Api.Setclaimitemdetail(k, Clmitemdetail);
								END IF;
							
								EXIT WHEN :System.Last_Record = 'TRUE';
								Next_Record;
							END LOOP;
						
							--  
						END IF;
					END IF;
				
					Go_Block('koc_clm_hlth_provisions');
					EXIT WHEN :System.Last_Record = 'TRUE';
					Next_Record;
				END LOOP;
			
  
				-- tüm lokasyonlar red ise hasar dosya red
				-- tüm lokasyonlar inceleme ise hasar dosya inceleme
				IF Is_All_Auth
				THEN
					IF Nvl(Clmdetail(1).Status_Code, 'PP') IN ('PP', 'PI')
					THEN
						Clmdetail(1).Status_Code := 'PI';
					ELSIF Clmdetail(1).Status_Code IN ('P')
					THEN
						Clmdetail(1).Status_Code := 'CPI';
					ELSIF Clmdetail(1).Status_Code IN ('R', 'PR', 'CPR')
					THEN
						NULL;
					ELSE
						Clmdetail(1).Status_Code := 'I';
					END IF;
				END IF;
		
  	
				--Task 12317 - claim, cover, process ve vacine mesajlari
				v_Message_Claim   := NULL;
				v_Message_Cover   := NULL;
				v_Message_Process := NULL;
				v_Message_Vacine  := NULL;
				-- Grup saglik için uyarilar simdilik kapatildi - Ilker TASCI - 03/07/2014
				IF :Koc_Clm_Hlth_Detail.Product_Id IN (63, 64)
				THEN
					BEGIN
					
						-- Tanıları al
						IF v_Diseases IS NOT NULL
						THEN
							v_Diseases.Delete;
						END IF;
					
						IF :Koc_Clm_Hlth_Detail.Class_Disease_1 IS NOT NULL
						THEN
							v_Diseases.Extend;
							v_Ind := v_Diseases.Last;
							v_Diseases(v_Ind).Code := :Koc_Clm_Hlth_Detail.Class_Disease_1;
							v_Diseases(v_Ind).Type := 'ON_TANI';
						END IF;
					
						IF :Koc_Clm_Hlth_Detail.Class_Disease_2 IS NOT NULL
						THEN
							v_Diseases.Extend;
							v_Ind := v_Diseases.Last;
							v_Diseases(v_Ind).Code := :Koc_Clm_Hlth_Detail.Class_Disease_2;
							v_Diseases(v_Ind).Type := 'ON_TANI';
						END IF;
					
						IF :Koc_Clm_Hlth_Detail.Class_Disease_3 IS NOT NULL
						THEN
							v_Diseases.Extend;
							v_Ind := v_Diseases.Last;
							v_Diseases(v_Ind).Code := :Koc_Clm_Hlth_Detail.Class_Disease_3;
							v_Diseases(v_Ind).Type := 'ON_TANI';
						END IF;
					
						IF :Koc_Clm_Hlth_Detail.Final_Class_Disease_1 IS NOT NULL
						THEN
							v_Diseases.Extend;
							v_Ind := v_Diseases.Last;
							v_Diseases(v_Ind).Code := :Koc_Clm_Hlth_Detail.Final_Class_Disease_1;
							v_Diseases(v_Ind).Type := 'KESIN_TANI';
						END IF;
					
						IF :Koc_Clm_Hlth_Detail.Final_Class_Disease_2 IS NOT NULL
						THEN
							v_Diseases.Extend;
							v_Ind := v_Diseases.Last;
							v_Diseases(v_Ind).Code := :Koc_Clm_Hlth_Detail.Final_Class_Disease_2;
							v_Diseases(v_Ind).Type := 'KESIN_TANI';
						END IF;
					
						IF :Koc_Clm_Hlth_Detail.Final_Class_Disease_3 IS NOT NULL
						THEN
							v_Diseases.Extend;
							v_Ind := v_Diseases.Last;
							v_Diseases(v_Ind).Code := :Koc_Clm_Hlth_Detail.Final_Class_Disease_3;
							v_Diseases(v_Ind).Type := 'KESIN_TANI';
						END IF;
			
  	
						/*Customer.Alz_Hltprv_Utils.Callhospitalbreservice(:Koc_Clm_Hlth_Detail.Claim_Id, :Koc_Clm_Hlth_Detail.Ext_Reference,
																														 :Koc_Clm_Hlth_Provisions.Location_Code, :Boiler.Userid,
																														 :Koc_Clm_Hlth_Detail.Specialty_Subject, :Koc_Clm_Hlth_Detail.Provision_Date,
																														 :Koc_Clm_Hlth_Detail.Policy_Ref, :Koc_Clm_Hlth_Detail.Partition_No,
																														 :Koc_Clm_Hlth_Detail.Institute_Code, :Koc_Clm_Hlth_Detail.Group_Code
																														 --, :Koc_clm_hlth_detail.Class_disease_1
																														 --, 'KESIN_TANI'
																														, v_Diseases, v_Processrecs, Io_Cursor, v_Errmessage, v_Coverrecs, NULL);*/
																														 
						/* Gülserin istegi üzerine OPUS üzerinden BRE çagrimi kapatilmistir. Gülser zaten çalismadigini iddia ediyor. 
						   Sonra tekrar açilabilir
						   Ademo - BoraD. 18.07.2017 */
					
						IF Io_Cursor IS NOT NULL
						THEN
							LOOP
								FETCH Io_Cursor
									INTO v_Barcode,
											 v_Maincode,
											 v_Itemcode,
											 v_Subitemcode,
											 v_Screenmessage,
											 v_Decision_Type; --, v_printmessage; v_decision_type--OTR / RET
								EXIT WHEN Io_Cursor%NOTFOUND;
								Uyari_Listesi.Extend;
								Message_Table_Va.Extend;
								Uyari_Listesi(Uyari_Listesi.Count) := v_Screenmessage;
								IF v_Decision_Type = 'RET'
								THEN
									Message_Table_Va(Uyari_Listesi.Count) := 'VA_BRE_RET';
								ELSIF v_Decision_Type = 'OTR'
								THEN
									Message_Table_Va(Uyari_Listesi.Count) := 'VA_BRE_OTR';
								END IF;
							
							END LOOP;
						END IF;
					
						IF v_Errmessage IS NOT NULL
						THEN
							Opu001.Msg(999999, 'W', NULL, NULL, NULL, 'Medikal BRE kararları teknik hata(işlem devam edecek): ' || Substr(v_Errmessage, 1, 100));
						
						END IF;
				
					EXCEPTION
						WHEN OTHERS THEN
							Opu001.Msg(999999, 'W', NULL, NULL, NULL,
												 'Medikal BRE kararları uyarı mesajlarinda hata(işlem devam edecek): ' || Substr(SQLERRM, 1, 100));
					END;
				
					IF Uyari_Listesi.Count > 0
					THEN
					
						v_Current_Item := :System.Current_Block || '.' || :System.Current_Item;
						Set_Item_Property('RET_UYARI.RET_MESAJ', Navigable, Property_True);
						Go_Block('RET_UYARI');
						Clear_Block(No_Validate);
						First_Record;
						FOR i IN Uyari_Listesi.First .. Uyari_Listesi.Last
						LOOP
							:Ret_Uyari.Ret_Mesaj := Uyari_Listesi(i);
						
							IF Message_Table_Va(i) = 'VA_BRE_RET'
							THEN
								Set_Item_Instance_Property('RET_UYARI.RET_MESAJ', Current_Record, Visual_Attribute, 'VA_BRE_RET');
							ELSE
								Set_Item_Instance_Property('RET_UYARI.RET_MESAJ', Current_Record, Visual_Attribute, 'VA_BRE_OTR');
							END IF;
						
							Next_Record;
						END LOOP;
						First_Record;
						--
						Show_View('CV_RET_UYARI');
						Go_Item('RET_UYARI.RET_MESAJ');
					
						Opu001.Msg(99999, 'Q', NULL, NULL, NULL, 'Medikal red var, provizyonu gerçekleştirmek istiyor musunuz?');
				
  
						Hide_View('CV_RET_UYARI');
						Go_Item(v_Current_Item);
						Set_Item_Property('RET_UYARI.RET_MESAJ', Navigable, Property_False);
					
						--alert buton
						IF Opu001.v_Alert_Button <> Alert_Button1
						THEN
							RAISE Form_Trigger_Failure;
						END IF;
					END IF;
				END IF;
				-- Uyarilar gösterildi
			
				IF :Koc_Clm_Hlth_Detail.Partition_Type = 'EKO1' AND
					 :Koc_Clm_Hlth_Provisions.Cover_Code IN ('S183', 'S552', 'S657', 'S508', 'S509', 'S557') AND
					 Trunc(Months_Between(:Koc_Clm_Hlth_Detail.Provision_Date, :Koc_Clm_Hlth_Detail.v_Plan_Entry_Date)) < 18
				THEN
					Opu001.Msg(999999, 'W', NULL, NULL, NULL, 'Dinamik Sağlık ürününde hamilelik için bekleme süresi 18 aydır !!!');
				
					IF :Koc_Clm_Hlth_Provisions.Status_Code IN ('P', 'PP', 'CP')
					THEN
						GOTO Son;
					ELSE
						NULL;
					END IF;
				END IF;
			
				Set_Application_Property(Cursor_Style, 'BUSY');
			
  
				Koc_Clm_Hlth_Bpm_Utils.Getauthinf(:Koc_Clm_Hlth_Provisions.Claim_Id, :Parameter.Instance_Id, v_Is_Authorized, v_User_Name,
																					:Parameter.State_Date, :Parameter.Is_Emergency, p_Status_Code);
			
				:System.Message_Level := 20;
			
				IF :Global.Status_Code IS NULL
				THEN
					:Global.Status_Code := 'X';
				END IF;
			
	 		
				IF :Global.Status_Code IN ('PP', 'CP') AND
					 Nvl(v_User_Name, 'X') <> v_User_Name
				THEN
					Opu001.Msg(999999, 'W', NULL, NULL, NULL, 'İlgili provizyon kaydi üzerinizden düsmüs oldugundan islem yapamazsınız!');
				ELSE
	 
  		     
					Koc_Clm_Hlth_Trnx.Get_Provisions(v_Contract_Id, v_Partition_No, Clmdetail(1).Provision_Date, v_User_Id, Clmdetail, Clmprovision,
																					 Clmprocdetail, Clmrejection, Clmmedicineindem, Clmitemdetail, Clmvaccindem, p_Out_Over_Price);
				
					Koc_Clm_Hlth_Hospt_Utils.Resetsyt0(Clmdetail(1).Claim_Id, Clmdetail(1).Sf_No);
				  insertstatus;  
					IF p_Give_Message = 1
					THEN
						Koc_Clm_Hlth_Trnx.Is_Hlth_Clm_Check(Clmdetail(1).Claim_Id, Clmdetail(1).Sf_No, 1, v_Clm_Check, v_Error_Exp);
					END IF;
				
					IF v_Clm_Check = 1
					THEN
						Opu001.Msg(999999, 'W', NULL, NULL, NULL, 'HATA:' || v_Error_Exp);
						Set_Application_Property(Cursor_Style, 'DEFAULT');
						GOTO Son;
					ELSE
						NULL;
					END IF;
				
					:Parameter.Time_Stamp := SYSDATE;
					Koc_Clm_Hlth_Hospt_Utils.Delete_Clm_From_Web(Clmdetail(1).Claim_Id);
					Koc_Clm_Hlth_Hospt_Utils.Resetsyt0(Clmdetail(1).Claim_Id, Clmdetail(1).Sf_No);
				
					IF Get_Item_Property('HORIZONTAL_TOOLBAR.SAVE', Visible) = 'TRUE'
					THEN
						Providereq.User_Name   := :Boiler.Userid;
						Providereq.Instance_Id := :Parameter.Instance_Id;
					
						--Task 14191 - 09/12/2009 yg
						OPEN c_Status_Code(Clmdetail(1).Claim_Id, Clmdetail(1).Sf_No);
					
						FETCH c_Status_Code
							INTO Providereq.Status_Code;
					
						CLOSE c_Status_Code;
					
						IF Nvl(:Parameter.Instance_Id, 'X') IN ('999999', 'X')
						THEN
							INSERT INTO Koc_Web_Prov_Err_Log
								(Contract_Id, Claim_Id, Sf_No, Error_Text, Username, Entry_Date)
							VALUES
								(:Koc_Clm_Hlth_Detail.Contract_Id,
								 Clmdetail(1).Claim_Id,
								 Clmdetail(1).Sf_No,
								 'INSTANCE SORUNLU :parameter.instance_id:' || Nvl(:Parameter.Instance_Id, 'X'),
								 USER,
								 SYSDATE);
						END IF;
					
						IF :Parameter.Instance_Id IS NOT NULL
						THEN
							BEGIN
								Provideres := Customer.Web_Provision.Provideprovision(Providereq);
							EXCEPTION
								WHEN OTHERS THEN
									Web_Clm_Hlth_Hospt_Utils.Koc_Bpm_Project_Log_Write(SYSDATE, 'WEB PROVISON', 'KOCCLM300', 'get_provison', Clmdetail(1).Claim_Id,
																																		 :Boiler.Userid, 'customer.web_provision.provideProvision', SQLERRM);
							END;
						END IF;
					END IF;
			
        
          
        
        
					Koc_Clm_Hlth_Trnx2.Setclmdetail(v_Claim_Id, v_Sf_No, v_Detail_No, v_Can_Be_Recourse, v_Recourse_Amount, v_Recourse_Clm_Amount,
																					v_Recourse_Rate_100, v_Recourse_Rate_8, v_Recourse_Status);
					Koc_Clm_Hlth_Trnx.Datacommit;
				
					Koc_Clm_Hlth_Utils.Insertclmprintvals(:Koc_Clm_Hlth_Detail.Claim_Id, :Koc_Clm_Hlth_Detail.Sf_No, :Koc_Clm_Hlth_Detail.Add_Order_No);
					Koc_Clm_Hlth_Trnx.Datacommit;
					v_Msg_Level           := :System.Message_Level;
					:System.Message_Level := 20;
				
  
					IF Nvl(:Global.Detail_Status, 'X') NOT IN ('PP', 'CP')
					THEN
						--Web islemi degil ise surecte basla-bitir calistirilir. yg 02/06/2009
						Startreq.User_Name      := :Boiler.Userid;
						Startreq.Claim_Id       := :Koc_Clm_Hlth_Detail.Claim_Id;
						Startreq.Institute_Code := :Koc_Clm_Hlth_Detail.Institute_Code;
						Startreq.Location_Code  := :Koc_Clm_Hlth_Provisions.Location_Code;
						Startreq.Part_Id        := :Koc_Clm_Hlth_Detail.Part_Id;
						Startreq.Unit_Id        := Koc_Clm_Hlth_Bpm_Utils.Gettounitinfobyinstitutecode(:Koc_Clm_Hlth_Detail.Institute_Code,
																																													 :Koc_Clm_Hlth_Detail.Provision_Date);
						Startreq.Package_Id     := :Koc_Clm_Hlth_Detail.Package_Id;
						Startreq.Product_Id     := :Koc_Clm_Hlth_Detail.Product_Id;
						Startreq.Partition_Type := :Koc_Clm_Hlth_Detail.Partition_Type;
						Startreq.Group_Code     := :Koc_Clm_Hlth_Detail.Group_Code;
						Startreq.Policy_Ref     := :Koc_Clm_Hlth_Detail.Policy_Ref;
						Startreq.Agency_Code    := Koc_Clm_Hlth_Utils.Getacencycode(Pk_General_Utils.Policyinfo.Agent_Int_Id, :Koc_Clm_Hlth_Detail.Provision_Date);
						Startreq.Provision_Type := Koc_Clm_Hlth_Bpm_Utils.Getuserroletype(:Boiler.Userid);
					
						--Task 14191 - 09/12/2009 - yg --
						IF Nvl(:Koc_Clm_Hlth_Detail.Status_Code, 'PP') = 'PP'
						THEN
							Startreq.Processtype := 'FALSE';
						ELSE
							Startreq.Processtype := 'TRUE';
						END IF;
					
						--Task 14191 - 09/12/2009 yg
						OPEN c_Status_Code(Clmdetail(1).Claim_Id, Clmdetail(1).Sf_No);
					
						FETCH c_Status_Code
							INTO Startreq.Status_Code;
					
						CLOSE c_Status_Code;
					
						BEGIN
							Startres := Customer.Web_Provision.Startazprovision(Startreq);
						EXCEPTION
							WHEN OTHERS THEN
								Web_Clm_Hlth_Hospt_Utils.Koc_Bpm_Project_Log_Write(SYSDATE, 'WEB PROVISON', 'KOCCLM300', 'get_provison', Clmdetail(1).Claim_Id,
																																	 :Boiler.Userid, 'customer.web_provision.startAZProvision', SQLERRM);
						END;
					END IF;
				
					:System.Message_Level := v_Msg_Level;
				
					OPEN C1;
				
					FETCH C1
						INTO C1_Rec;
				
					CLOSE C1;
				
  
					IF C1_Rec.v_Cnt > 0
					THEN
						v_Status := Koc_Clm_Hlth_Utils.Hasrecoursefile(Clmdetail(1).Claim_Id, Clmdetail(1).Sf_No);
					
						IF v_Status = 0
						THEN
							v_Cml_Total := Koc_Clm_Hlth_Utils.Getsumprvbyclaim(Clmdetail(1).Claim_Id, Clmdetail(1).Sf_No, NULL) +
														 Koc_Clm_Hlth_Utils.Getsumtransbyclaim(Clmdetail(1).Claim_Id, Clmdetail(1).Sf_No, NULL);
						
							IF v_Cml_Total <> Nvl(C1_Rec.Recourse_Clm_Amount, 0)
							THEN
								v_Recourse_Clm_Amount := v_Cml_Total;
								v_Recourse_Amount     := v_Cml_Total;
							
								Koc_Clm_Hlth_Trnx2.Setclmdetail(v_Claim_Id, v_Sf_No, v_Detail_No, v_Can_Be_Recourse, v_Recourse_Amount, v_Recourse_Clm_Amount,
																								v_Recourse_Rate_100, v_Recourse_Rate_8, v_Recourse_Status);
								Koc_Clm_Hlth_Trnx.Datacommit;
								Opu001.Msg(999999, 'W', NULL, NULL, NULL,
													 'Dosya Rakamları ile Rücu Rakamları Farklı olduğundan, Rücu Rakamları güncellendi.Lütfen kontrol edniz !');
							END IF;
						END IF;
					END IF;
					Koc_Clm_Hlth_Trnx.Datacommit;
				END IF;
		
  
				Set_Application_Property(Cursor_Style, 'DEFAULT');
			
				v_Adet         := :Boiler.Fax_Adet;
				v_Fax_Claim_Id := :Boiler.Fax_Claim_Id;
				Clear_Form(No_Commit, Full_Rollback);
				Synchronize;
				:Boiler.Fax_Adet     := v_Adet;
				:Boiler.Fax_Claim_Id := v_Fax_Claim_Id;
			
				Post_New_Form;
				Synchronize;
			
				:Global.Rucu            := 'Old';
				:Control.Query_Claim_Id := Clmdetail(1).Claim_Id;
				:Global.Query_Claim_Id  := :Control.Query_Claim_Id;
				Queryhlthdetail;
				Synchronize;
			
				---YT den AT lokasyonuna geçiste yatis tarihinin bosaltilmasi 13-08-2009
				IF :Koc_Clm_Hlth_Detail.Hospitalize_Date IS NOT NULL
				THEN
					v_Yt_Count := 0;
					Go_Block('KOC_CLM_HLTH_PROVISIONS');
					First_Record;
				
					LOOP
						IF (:Koc_Clm_Hlth_Provisions.Cover_Cat_Group = 'YT' OR :Koc_Clm_Hlth_Provisions.Cover_Code   IN ('S777', 'S768', 'S767', 'S764', 'S762', 'S741', 'S706', 'S689', 'S683', 'S678', 'S660', 'S574', 'S572', 'S559', 'S521', 'S520', 'S514',
						 'S353', 'ST353', 'ST504', 'S660', 'S767', 'S768', 'S736', 'S692', 'S505', 'S539', 'S762', 'S520')) AND
							 :Koc_Clm_Hlth_Provisions.Status_Code NOT IN ('R', 'C', 'PR', 'CPR')
						THEN
							v_Yt_Count := v_Yt_Count + 1;
						END IF;
					
						EXIT WHEN :System.Last_Record = 'TRUE';
						Next_Record;
					END LOOP;
				END IF;
			
				Koc_Pk_Hlth_Provision.Updateweblocationcode(:Koc_Clm_Hlth_Detail.Claim_Id, :Koc_Clm_Hlth_Detail.Sf_No, :Koc_Clm_Hlth_Detail.Add_Order_No,
																										v_Yt_Count);
			
				Polus.Quiet_Commit;
		
  
				Set_Application_Property(Cursor_Style, 'DEFAULT');
				v_Adet         := :Boiler.Fax_Adet;
				v_Fax_Claim_Id := :Boiler.Fax_Claim_Id;
				Clear_Form(No_Commit, Full_Rollback);
			
				:Boiler.Fax_Adet     := v_Adet;
				:Boiler.Fax_Claim_Id := v_Fax_Claim_Id;
				Post_New_Form;
			
				:Global.Rucu            := 'Old';
				:Control.Query_Claim_Id := Clmdetail(1).Claim_Id;
				:Global.Query_Claim_Id  := :Control.Query_Claim_Id;
			
				Queryhlthdetail;
			
				BEGIN
					--
					IF :Koc_Clm_Hlth_Detail.Ext_Reference IS NULL OR
						 :Koc_Clm_Hlth_Detail.Ext_Reference = ''
					THEN
						v_Ext := 0;
					ELSE
						v_Ext := :Koc_Clm_Hlth_Detail.Ext_Reference;
					END IF;
				
					SELECT SUM(Nvl(a.r_Exemption_Sum, 0))
						INTO v_Exemption_Sum
						FROM Koc_Clm_Hlth_Indem_Totals a
					 WHERE Contract_Id = :Koc_Clm_Hlth_Detail.Contract_Id
						 AND Partition_No = :Koc_Clm_Hlth_Detail.Partition_No
						 AND Is_Valid = 1
						 AND a.Cover_Code = :Koc_Clm_Hlth_Provisions.Cover_Code
						 AND a.Country_Group = Nvl(:Koc_Clm_Hlth_Detail.Country_Group, 0)
						 AND a.Claim_Inst_Type = :Koc_Clm_Hlth_Detail.Claim_Inst_Type
						 AND a.Claim_Inst_Loc = :Koc_Clm_Hlth_Detail.Claim_Inst_Loc;
				EXCEPTION
					WHEN OTHERS THEN
						v_Exemption_Sum := 0;
				END;
			
				Synchronize;
				:Control.Exemption_Tmp := :Koc_Clm_Hlth_Detail.Sum_Exemption_Amount;
			END IF;
		
			IF ((f_Provision_Limit_User < :Koc_Clm_Hlth_Detail.Sum_Provision_Total) OR
				 (Nvl(Trunc(:Koc_Clm_Hlth_Detail.Discharge_Date), Trunc(SYSDATE)) - Trunc(:Koc_Clm_Hlth_Detail.Hospitalize_Date) > 10))
			THEN
				Opu001.Msg(999999, 'W', NULL, NULL, NULL,
									 'Yetki limitinizin üzerindeki işlem için lütfen dosyanızı Tazminat Onay Formunu doldurarak onaya sununuz.');
				Opu001.Msg(999999, 'Q', NULL, NULL, NULL, 'Tazminat Onay Formunu Basmak istemisiniz ');
			
				IF Opu001.v_Alert_Button = Alert_Button1
				THEN
					p_Print_Indemnity_Apply_Form;
				END IF;
			END IF;
		
			Koc_Clm_Hlth_Pharmacy_Utils.Setautoprescription(v_Claim_Id, v_Contract_Id, v_Partition_No, :Boiler.Userid, Trunc(SYSDATE), 2,
																											Clmdetail(1).Provision_Date);
		EXCEPTION
			WHEN OTHERS THEN
				Set_Application_Property(Cursor_Style, 'DEFAULT');
				IF SQLCODE <> -100501
				THEN
				
					Message('HATA: ' || SQLERRM);
					Opu001.Msg(999999, 'E', NULL, NULL, NULL, 'GET_PROVISION_BRE - Beklenemdik bir hata oluştu, hata bilgisi ekranın sol altındadır.');
				END IF;
		END;
	END IF;

  
	BEGIN
		UPDATE Koc_Clm_Hlth_Incomp_Papers
			 SET Status_Code = 'C'
		 WHERE Claim_Id = v_Claim_Id
			 AND Status_Code = 'A';
	
		Polus.Quiet_Commit;
	EXCEPTION
		WHEN OTHERS THEN
			NULL;
	END;

	<<son>>
	NULL;
	--------------------------------------------------------------------
EXCEPTION
	WHEN OTHERS THEN
	
		Message('HATA: ' || SQLERRM);
		Opu001.Msg(999999, 'E', NULL, NULL, NULL, 'GET_PROVISION_BRE - Beklenemdik bir hata oluştu, hata bilgisi ekranın sol altındadır.');
END;