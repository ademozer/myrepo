DECLARE
	v_Match_Result  Koc_Clm_Hlth_Match_Api.Reject_Table;
	Rejmess         VARCHAR2(4000);
	Wmess           VARCHAR2(4000);
	Otomess         VARCHAR2(4000);
	Rej             NUMBER;
	v_Yt_Kontrol    NUMBER := 0;
	v_S500_Kontrol  NUMBER := 0;
	v_Is_Authorized NUMBER;
	v_User_Name     VARCHAR2(15);
	p_Status_Code   VARCHAR2(10);
	v_Msg_Level     NUMBER;
	v_Key           NUMBER DEFAULT 0;
	v_Sonuc         VARCHAR2(1000);

BEGIN
  
  
  KOC_CLM_HLTH_TRNX.Set_sms_deny(:KOC_CLM_HLTH_DETAIL.DENY_SMS);
	
	
	IF :System.Current_Block = 'KOC_CLM_HLTH_PROVISIONS'
	THEN
		NULL;
	ELSE
		Go_Block('KOC_CLM_HLTH_PROVISIONS');
	END IF;

	IF :Koc_Clm_Hlth_Detail.Hibrit = 2 AND
		 Ishibritvalid = -1
	THEN
		RAISE Form_Trigger_Failure;
	END IF;

	IF Forms_Utils.v_Pol_Fail = 1
	THEN
		Opu001.Msg(999999, 'E', NULL, NULL, NULL, 'Poli�e bu kurumda ge�ersizdir yada teminat bu poli�ede ge�ersizdir.');
		RAISE Form_Trigger_Failure;
	END IF;

	Pr_Doctor_Null_Cont;

	Checkemergency_Status(:Koc_Clm_Hlth_Detail.Group_Code, :Koc_Clm_Hlth_Detail.Term_Start_Date, :Koc_Clm_Hlth_Detail.Term_End_Date, 1);

	IF :System.Current_Block = 'KOC_CLM_HLTH_PROVISIONS'
	THEN
	
		v_Msg_Level           := :System.Message_Level;
		:System.Message_Level := 20;
	
		IF Nvl(:Koc_Clm_Hlth_Detail.Is_Web, 0) = 1 AND
			 Nvl(:Global.Status_Code, 'X') IN ('PP', 'CP')
		THEN
		
			Koc_Clm_Hlth_Bpm_Utils.Getauthinf(:Koc_Clm_Hlth_Provisions.Claim_Id, :Parameter.Instance_Id, v_Is_Authorized, v_User_Name,
																				:Parameter.State_Date, :Parameter.Is_Emergency, p_Status_Code);
		
			IF Nvl(v_User_Name, 'X') <> :Boiler.Userid
			THEN
				--27.05.2010 AYSEL
				IF Nvl(v_User_Name, 'X') = 'X'
				THEN
					Opu001.Msg(999999, 'E', NULL, NULL, NULL, 'Hasar dosyas� �zerinizde g�z�km�yor! BSS ye haber veriniz ');
					GOTO Son;
				END IF;
			
				IF v_User_Name IS NOT NULL AND
					 v_User_Name <> :Boiler.Userid
				THEN
					Opu001.Msg(999999, 'E', NULL, NULL, NULL, 'Hasar dosyas� ' || v_User_Name || ' �zerinde g�r�n�yor !');
					Clear_Form(No_Commit, Full_Rollback); --duygu         
					Exit_Form; --duygu               
					GOTO Son;
				END IF;
			END IF;
		
			Kontrol_Dogum_Hakedis;
		END IF;
	
		:System.Message_Level := v_Msg_Level;
		Opu001.Msg(999999, 'Q', NULL, NULL, NULL, 'Provizyon almak istedi�inizden emin misiniz?');
	
		IF Opu001.v_Alert_Button = Alert_Button1
		THEN
			--Task 12317 - Kontrollerin t�m kayitlar i�in yapilabilmesi icin loop da d�nme b�l�m� eklendi yg
			IF :Koc_Clm_Hlth_Detail.Partition_Type = 'KEKS'
			THEN
				IF Nvl(:Koc_Clm_Hlth_Provisions.Status_Code, 'PP') NOT IN ('P', 'C', 'R', 'TAH', 'ODE', 'PE')
				THEN
					:Control.Timer_Validate_Control           := 0;
					:Koc_Clm_Hlth_Provisions.Sum_Claim_Amount := (Nvl(:Koc_Clm_Hlth_Provisions.Request_Amount, 0) -
																											 Nvl(:Koc_Clm_Hlth_Provisions.Refusal_Amount, 0));
				
					IF :Koc_Clm_Hlth_Provisions.Sum_Claim_Amount < 0
					THEN
						:Koc_Clm_Hlth_Provisions.Sum_Claim_Amount := 0;
					END IF;
				
					IF :Koc_Clm_Hlth_Provisions.Proc_Request_Amount > 0
					THEN
						:Koc_Clm_Hlth_Provisions.Swift_Code := Base_Swift_Code;
					END IF;
				
					Sgk_Dagit;
				
					IF Round(Nvl(:Koc_Clm_Hlth_Provisions.Refusal_Amount, 0), 2) > Round(Nvl(:Koc_Clm_Hlth_Provisions.Sys_Request_Amount, 0), 2) AND
						 Nvl(:Koc_Clm_Hlth_Provisions.Cover_Distribution_Amount, 0) = 0 --complex
					THEN
						Opu001.Msg(999999, 'E', NULL, NULL, NULL, '1-Talep edilenden daha fazla red tutar� var. L�tfen red tutarlar�n� kontrol ediniz.....');
					END IF;
				
					Go_Block('KOC_CLM_HLTH_TMP_PROC_DETAIL');
					IF :Global.Currec IS NOT NULL
					THEN
						Go_Record(:Global.Currec);
					END IF;
					Go_Item(:Global.Curitem);
				
					Synchronize;
					:Control.Timer_Validate_Control := 1;
				END IF;
			
			END IF;
		
			Go_Block('koc_clm_hlth_provisions');
			First_Record;
			LOOP
				--Task 12317 - yukaridaydi loop icerisine tasindi.
				Detaildatavalidation;
				Synchronize;
			
				IF Nvl(:Koc_Clm_Hlth_Provisions.Status_Code, 'PP') NOT IN ('P', 'R', 'C', 'TAH', 'ODE', 'PE')
				THEN
					-- ha muallak  13944:14/12/2009   
					IF :Koc_Clm_Hlth_Provisions.Cover_Cat_Group = 'YT' AND
						 :Koc_Clm_Hlth_Detail.Class_Disease_1 in ( '10099' , '10099' ,'20099' ,'30999' ,'49999' ) AND
						 :Koc_Clm_Hlth_Provisions.Cover_Code NOT IN ('S767', 'S768', 'S736', 'S692', 'S505', 'S539', 'S762', 'S520') --cozbay aso kodlari ise hata vermesin task_187995_YKS Grup saglik Poli�elerinin Opustan Yenilemesinin yapilmasi / 'S736','S692','S505','S539','S762','S520' mustafaku i yanikcan
					THEN
						-- Task 12317 e-provizyon yg
						Opu001.Msg(999999, 'E', NULL, NULL, NULL, 'YT se�ti�inizde Bilinmiyor tan� kodunu se�emezsiniz.');
						Go_Item('KOC_CLM_HLTH_DETAIL.CLASS_DISEASE_1');
						GOTO Son;
					END IF;
				
					IF :Koc_Clm_Hlth_Detail.Provision_Date >= To_Date('01-08-2009', 'dd-mm-yyyy') AND
						 :Koc_Clm_Hlth_Provisions.Cover_Cat_Group = 'YT' AND
						 :Koc_Clm_Hlth_Provisions.Cover_Code IN ('S500', 'S175') AND
						 Nvl(:Koc_Clm_Hlth_Detail.Request_System, '.') <> 'WS'
					THEN
					
						v_S500_Kontrol := 0;
						SELECT COUNT(1)
							INTO v_S500_Kontrol
							FROM Koc_Clm_Hlth_Tmp_Proc_Detail
						 WHERE Claim_Id = :Koc_Clm_Hlth_Provisions.Claim_Id
							 AND Sf_No = :Koc_Clm_Hlth_Provisions.Sf_No
							 AND Cover_Code = :Koc_Clm_Hlth_Provisions.Cover_Code
							 AND (((Process_Code_Main IN (1, 151)) AND Process_Code_Sub1 = 10 AND Process_Code_Sub2 = 101) OR
									 ((Process_Code_Main IN (1, 151)) AND Process_Code_Sub1 = 20 AND Process_Code_Sub2 = 101) OR
									 ((Process_Code_Main IN (1, 151)) AND Process_Code_Sub1 = 30 AND Process_Code_Sub2 = 101));
					
						IF Nvl(v_S500_Kontrol, 0) <> 3
						THEN
							Opu001.Msg(999999, 'E', NULL, NULL, NULL,
												 'YT se�ti�inizde ameliyat i�in malzeme-cerrahi tedavi-hastane �cretleri i�lemleri girilmesi zorunludur!');
							Go_Item('LOV.PB_PROCESS_CODE_DESC');
							GOTO Son;
						END IF;
					END IF;
				
					IF :Koc_Clm_Hlth_Detail.Provision_Date >= To_Date('01-08-2009', 'dd-mm-yyyy') AND
						 :Koc_Clm_Hlth_Provisions.Cover_Cat_Group = 'YT' AND
						 :Koc_Clm_Hlth_Provisions.Cover_Code IN ('S176', 'S501', 'S177', 'S502') AND
						 Nvl(:Koc_Clm_Hlth_Detail.Request_System, '.') <> 'WS'
					THEN
						v_S500_Kontrol := 0;
					
						SELECT COUNT(1)
							INTO v_Yt_Kontrol
							FROM Koc_Clm_Hlth_Tmp_Proc_Detail
						 WHERE Claim_Id = :Koc_Clm_Hlth_Provisions.Claim_Id
							 AND Sf_No = :Koc_Clm_Hlth_Provisions.Sf_No
							 AND Cover_Code = :Koc_Clm_Hlth_Provisions.Cover_Code
							 AND ((Process_Code_Main = 1 AND Process_Code_Sub1 = 30 AND Process_Code_Sub2 = 101) OR
									 (Process_Code_Main = 1 AND Process_Code_Sub1 = 20 AND Process_Code_Sub2 = 102));
					
						IF Nvl(v_Yt_Kontrol, 0) <> 2
						THEN
							Opu001.Msg(999999, 'E', NULL, NULL, NULL, 'YT se�ti�inizde dahili tedavi-hastane �cretleri i�lemleri girilmesi zorunludur!');
							Go_Item('LOV.PB_PROCESS_CODE_DESC');
							GOTO Son;
						END IF;
					END IF;
				
					IF :Koc_Clm_Hlth_Provisions.Location_Code IS NOT NULL
					THEN
						IF :Koc_Clm_Hlth_Provisions.Swift_Code IS NULL
						THEN
							Opu001.Msg(999999, 'E', NULL, NULL, NULL, 'L�tfen d�viz cinsini giriniz.');
							Go_Item('koc_clm_hlth_provisions.swift_code');
							GOTO Son;
						END IF;
					
						IF :Koc_Clm_Hlth_Provisions.Provision_Explanation IS NULL
						THEN
							Opu001.Msg(999999, 'E', NULL, NULL, NULL, 'L�tfen a��klama giriniz.');
							Go_Item('koc_clm_hlth_provisions.provision_explanation');
							Do_Key('edit_textitem');
							GOTO Son;
						END IF;
					
						IF Nvl(:Koc_Clm_Hlth_Provisions.Refusal_Amount, 0) > Nvl(:Koc_Clm_Hlth_Provisions.Request_Amount, 0) AND
							 Nvl(:Koc_Clm_Hlth_Provisions.Cover_Distribution_Amount, 0) = 0 --complex
						THEN
							Opu001.Msg(999999, 'E', NULL, NULL, NULL, 'L�tfen red tutarlar�n� kontrol ediniz. Talep edilen tutardan daha fazla red tutar� var.');
							Go_Item('koc_clm_hlth_provisions.sys_request_amount');
							GOTO Son;
						END IF;
					
						IF :Koc_Clm_Hlth_Provisions.Cover_Cat_Group = 'YT' AND
							 :Koc_Clm_Hlth_Detail.Hospitalize_Date IS NULL AND
							 :Koc_Clm_Hlth_Provisions.Cover_Code NOT IN ('S767', 'S768', 'S736', 'S505', 'S692', 'S539', 'S762', 'S520') --cozbay asolarda bu kontrol calismasin task_187995_YKS Grup saglik Poli�elerinin Opustan Yenilemesinin yapilmasi ,'S736','S692','S505','S539','S762','S520' mustafaku iyan�kcan
						THEN
							Opu001.Msg(999999, 'E', NULL, NULL, NULL, 'L�tfen yat�� tarihini giriniz.');
							Go_Item('koc_clm_hlth_detail.hospitalize_date');
							Show_View('CAN_HOSPITALIZE');
							Show_Window('WINDOW_HOSPITALIZE');
							Go_Item('koc_clm_hlth_detail.hospitalize_date');
							GOTO Son;
						END IF;
					
						IF Nvl(:Koc_Clm_Hlth_Provisions.f_Max_Day_Seance, 0) > 0 AND
							 Nvl(:Koc_Clm_Hlth_Provisions.Req_Cure_Day_Count, 0) <= 0 AND
							 Nvl(:Koc_Clm_Hlth_Provisions.Status_Code, 'PP') NOT IN ('PR', 'R')
						THEN
							Opu001.Msg(999999, 'E', NULL, NULL, NULL, 'L�tfen g�n/seans bilgisini giriniz.');
							Go_Item('koc_clm_hlth_provisions.req_cure_day_count');
							GOTO Son;
						END IF;
					
						IF Nvl(:Koc_Clm_Hlth_Provisions.f_Max_Day_Seance, 0) > 0 AND
							 Nvl(:Koc_Clm_Hlth_Provisions.Day_Seance, 0) = 0 AND
							 Nvl(:Koc_Clm_Hlth_Provisions.Status_Code, 'PP') NOT IN ('PR', 'R', 'CPR') --27.05.2010 AYSEL
						THEN
							Opu001.Msg(999999, 'E', NULL, NULL, NULL,
												 :Koc_Clm_Hlth_Provisions.Cover_Code || '-' || :Koc_Clm_Hlth_Provisions.Cover_Code_Desc ||
													' teminat� kullan�lm��. Provizyon verilemiyor.');
							Go_Item('koc_clm_hlth_provisions.req_cure_day_count');
							GOTO Son;
						END IF;
					END IF;
				END IF;
			
				EXIT WHEN :System.Last_Record = 'TRUE';
				Next_Record;
			END LOOP;
		
			Callmatchapiforprov(v_Match_Result);
		
			IF v_Match_Result.Count > 0
			THEN
				Rejmess := '';
				Wmess   := '';
				Otomess := '';
				Rej     := 1;
			
				WHILE Rej <= v_Match_Result.Count
				LOOP
					IF v_Match_Result(Rej).Action_Type = 'RED'
					THEN
						Rejmess := Rejmess || ' ' || v_Match_Result(Rej).Print_Explanation;
						Insertlocreject(v_Match_Result(Rej).Main_Code, v_Match_Result(Rej).Item_Code, v_Match_Result(Rej).Sub_Item_Code,
														v_Match_Result(Rej).Print_Explanation);
					END IF;
				
					IF v_Match_Result(Rej).Action_Type = 'MESS'
					THEN
						Wmess := Wmess || ' ' || v_Match_Result(Rej).Print_Explanation;
					END IF;
				
					IF v_Match_Result(Rej).Action_Type = 'OTO'
					THEN
						Otomess := Otomess || ' ' || v_Match_Result(Rej).Print_Explanation;
					END IF;
				
					Rej := Rej + 1;
				END LOOP;
			
				IF Length(Rejmess) > 0
				THEN
					Set_Location_Items(:Koc_Clm_Hlth_Provisions.Status_Code, :Koc_v_Hlth_Users.Banko_User);
					Opu001.Msg(999999, 'E', NULL, NULL, NULL, Rejmess);
				ELSIF Length(Otomess) > 0
				THEN
					:Koc_Clm_Hlth_Provisions.Status_Code := 'PI';
					Set_Location_Items(:Koc_Clm_Hlth_Provisions.Status_Code, :Koc_v_Hlth_Users.Banko_User);
					Opu001.Msg(999999, 'E', NULL, NULL, NULL, Otomess);
				ELSIF Length(Wmess) > 0
				THEN
					Opu001.Msg(999999, 'E', NULL, NULL, NULL, Wmess);
				END IF;
			END IF;
		
			IF Nvl(:Koc_Clm_Hlth_Provisions.Cover_Code, '0') = '0'
			THEN
				Opu001.Msg(999999, 'E', NULL, NULL, NULL, 'Teminat kodu 0 olamaz!!');
				Go_Item('koc_clm_hlth_provisions.LOCATION_CODE_DESC');
				RAISE Form_Trigger_Failure;
			END IF;
		
			IF :Koc_Clm_Hlth_Detail.Status_Code = 'GECERSIZ'
			THEN
				Opu001.Msg(999999, 'E', NULL, NULL, NULL,
									 'Poli�e hasara kapat�lm��t�r. Sigortal�n�n ge�erli poli�esi bulunmamaktad�r. Sigortal�m�za l�tfen anla�mal� kurum fiyatlar�n� uygulamay� unutmay�n�z.');
				Go_Item('control.explanation');
				Show_View('CAN_EXPLANATION');
				Show_Window('WINDOW_EXP');
				Go_Item('control.explanation');
			ELSE
			
				Get_Provision_Bre(1);
			END IF;
		ELSE
		
			IF Name_In(':SYSTEM.Current_Item') NOT IN ('CALC_BUTTON', 'USER_DEF_BUTT_2') AND
				 (:Global.Calculatebutton IN (0, 1))
			THEN
				:Global.Calculatebutton := 0;
				Calculatebutton_Visible(:Global.Calculatebutton);
			
				IF Name_In(':SYSTEM.Current_Item') = 'USER_DEF_BUTT_2'
				THEN
					Go_Block('KOC_CLM_HLTH_PROVISIONS');
					First_Record;
				END IF;
			
			END IF;
		
		END IF;
	
		<<son>>
	
		NULL;
	END IF;

  Deletestatus; --duygu
  --insertstatus;
	Get_Oss_Date(:Koc_Clm_Hlth_Detail.Part_Id, Pk_General_Utils.Policyinfo.Group_Code, Pk_General_Utils.Policyinfo.Term_End_Date);

	IF Get_Ren_Guaranty_Status(:Koc_Clm_Hlth_Detail.Contract_Id, :Koc_Clm_Hlth_Detail.Partition_No) = 1
	THEN
		:Koc_Clm_Hlth_Detail.Obyg := 'OBYG';
	ELSE
		:Koc_Clm_Hlth_Detail.Obyg := NULL;
	END IF;
  
  If :Koc_clm_hlth_detail.Status_Code = 'P'
  Then 
		:Global.Calculatebutton := 2;
  Else
  		:Global.Calculatebutton := 0;	
  End If;
  --ademo TPA
  set_tpa_company(:koc_clm_hlth_detail.policy_ref);
	Exception 
		When Others Then
	:Global.Calculatebutton := 0;		
END;