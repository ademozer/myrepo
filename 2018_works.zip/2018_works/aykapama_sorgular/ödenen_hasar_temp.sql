              Select '�denen Hasar' Rapor,
                   CASE WHEN REGEXP_COUNT(LISTAGG(t.Explanation) WITHIN GROUP(ORDER BY t.Account_Code), 'KISM� FATURA �ADES�', 1, 'i')= 1 THEN 'iade'
                        WHEN REGEXP_COUNT(LISTAGG(t.Explanation) WITHIN GROUP(ORDER BY t.Account_Code), '�SKONTO', 1, 'i') = 1 THEN 'iskonto'
                        ELSE CASE MAX(t.Account_Code) 
                                  WHEN '7850211105' THEN 'Dosya Masraf�'
                                  WHEN '7850211106' THEN 'Dosya Masraf�'
                                  WHEN '7850211201' THEN 'Ruc�'
                                  WHEN '7850211203' THEN 'Ruc�'
                                  ELSE '�deme'
                              END
                        END Tip_0,       
                   Decode(REGEXP_COUNT(LISTAGG(t.Explanation) WITHIN GROUP(ORDER BY t.Account_Code), 'KISM� FATURA �ADES�', 1, 'i'),0,
                          Decode(REGEXP_COUNT(LISTAGG(t.Explanation) WITHIN GROUP(ORDER BY t.Account_Code), '�SKONTO', 1, 'i'),0,
                                 Decode(AVG(t.Account_Code),'7850211105','Dosya Masraf�',
                                                       '7850211106','Dosya Masraf�',
                                                       '7850211201','Ruc�',
                                                       '7850211203','Ruc�',
                                 '�deme'),
                                 'iskonto'),
                          'iade') Tip,
                    CASE t.Account_Code
                           WHEN '7850211101' THEN 'Direkt'
                           WHEN '7850211103' THEN 'Direkt'
                           WHEN '7850211102' THEN 'Endirekt'
                           WHEN '7850211104' THEN 'Endirekt'
                           ELSE ''
                    END D_E,
                    CASE t.Account_Code
                           WHEN '7850211101' THEN 'Cari Y�l'
                           WHEN '7850211102' THEN 'Cari Y�l'
                           WHEN '7850211103' THEN '�nceki Y�l'
                           WHEN '7850211104' THEN '�nceki Y�l'
                           ELSE ''
                    END YIL,
                    Decode(t.Product_Id,63,'Bireysel',64,'Grup',t.Product_Id) G_B,
                       Round(Sum(Nvl(t.Borc,0)),2) Borc,
                       Round(Sum(Nvl(t.Alacak,0)),2) Alacak,
                       Round(Sum(Nvl(t.Borc,0)-Nvl(t.Alacak,0)),2) FARK
                  From Koc_Acc_v_Posting_Details t
                Where t.Account_Code In ('7850211101', '7850211103', '7850211102', '7850211104',
                                          '7850211105', '7850211106', '7850211201', '7850211203')
                   And t.Posting_Date Between to_date('01/12/2017','dd/mm/yyyy') and to_date('31/12/2017','dd/mm/yyyy')
                Group By t.Account_Code, t.Product_Id
                    
