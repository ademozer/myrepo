SELECT b.*,a.*--Long_Name
           FROM Cur_Translations b, Koc_Cp_Health_Look_Up a
          WHERE     a.Look_Up_Code = 'DOCTYPE'
                AND a.Desc_Int_Id = b.Desc_Int_Id
                AND b.Sula_Ora_Nls_Code = 'TR'
               -- AND Short_Code = p_Doctor_Type;


select * from Koc_Cp_Health_Look_Up where Look_Up_Code='DOCTYPE'

SELECT d_type,CUSTOMER.KOC_CLM_HLTH_UTILS.Getlookupparamdesc('DOCTYPE',TO_CHAR(d_type),NULL) DURUM_ACIKLAMA 
  FROM (select distinct regexp_substr(b.name, '[^ ]+', 1, level) d_type, level
          from (select '1 2 3 4 5' name from dual) b
        connect by regexp_substr(b.name, '[^ ]+', 1, level) is not null
        order by d_type)
  
  
       select distinct regexp_substr(b.name, '[^ ]+', 1, level) d_type, level
          from (select '1 2 3 4 5' name from dual) b
        connect by regexp_substr(b.name, '[^ ]+', 1, level) is not null
        order by d_type
        
        
        SELECT level, CUSTOMER.KOC_CLM_HLTH_UTILS.Getlookupparamdesc('DOCTYPE',TO_CHAR(level),NULL) DURUM_ACIKLAMA
          FROM dual
        CONNECT BY LEVEL <= 5
        
  SELECT d_type,CUSTOMER.KOC_CLM_HLTH_UTILS.Getlookupparamdesc('DOCTYPE',TO_CHAR(d_type),NULL) DURUM_ACIKLAMA 
    FROM ( SELECT level d_type 
             FROM DUAL 
          CONNECT BY LEVEL <=5)
          
          
          SELECT ' ' proc_name, 
                 ' ' start_date, 
                 ' ' end_date, 
                 ' ' is_permanant_data, 
                 ' ' status_exp, 
                 ' ' user_id,
                 0 BRANCH_ID FROM DUAL
                 
                 
                 
         SELECT c.*
           FROM dba_jobs_running a, alz_cron_proc_job b, alz_cron_proc_log c
          WHERE a.job(+) = b.dbms_job_id
            AND b.ID = c.ID
--and c.id=28
            --AND c.status IN (2)
          --  and c.BRANCH_ID = '126'
          --  and c.IS_INDUSTRIAL = 'B'
            AND YEAR = TO_NUMBER (TO_CHAR (ADD_MONTHS (SYSDATE, -1), 'yyyy'))
            AND MONTH = TO_NUMBER (TO_CHAR (ADD_MONTHS (SYSDATE, -1), 'mm'))
          --  AND a.job IS NULL;
          
          
          select * from koc_cmi_pro_rata
          
          SELECT * FROM KOC_CLM_XL_BORDRO_REP
          
          SELECT * FROM ALZ_ADJUSTMENT_DATA
