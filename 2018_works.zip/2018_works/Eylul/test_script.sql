DECLARE
   p_company_code    varchar2(100) := '100'; 
   p_user               varchar2(100) := 'WFIBA9194_61000';
   p_partition_type     varchar2(100);
   p_template_id        number;
   p_question_no        number;
   p_process_results    customer.process_result_table;
   
 BEGIN
   
    alz_tpa_hlth_policy_utils.get_company_tss_info(p_company_code, p_user, p_partition_type, p_template_id, p_question_no, p_process_results);

    DBMS_OUTPUT.PUT_LINE('p_part_type='||p_partition_type);
    DBMS_OUTPUT.PUT_LINE('p_temp_id='||p_template_id); 
    DBMS_OUTPUT.PUT_LINE('p_q_no='||p_question_no);
   
    FOR rec IN (SELECT * FROM TABLE (p_process_results)) LOOP
       DBMS_OUTPUT.PUT_LINE('error_origin='||rec.error_origin);
    END LOOP;    
 END;
