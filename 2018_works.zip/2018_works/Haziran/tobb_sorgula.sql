 DECLARE
   v_input VARCHAR2(100) := 'T091215-3FF1';
   v_output VARCHAR2(32000);
   v_keys  VARCHAR2(4000);
   PROCEDURE tobb_sorgula(pi_levha_no IN VARCHAR2, po_data OUT VARCHAR2, po_keys OUT VARCHAR2) IS 
     v_errnum  NUMBER (5) := -2;
     v_clob    CLOB;
     v_resp_xml XMLTYPE;
     v_soap_request VARCHAR2 (32767);
     v_soap_respond VARCHAR2 (32767);
     v_http_req UTL_HTTP.req;
     v_http_resp UTL_HTTP.resp; 
     p_levha_no     VARCHAR2(100);
     v_glbl_HOST      constant     varchar2(30000) := 'http://sigortaws.tobb.org.tr/SigSirketWS.asmx?wsdl';
     v_err VARCHAR2(4000);
     cur_ SYS_REFCURSOR; 
     ndx NUMBER := 0;
  BEGIN
      
       v_soap_request := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
                           <soapenv:Header/>
                           <soapenv:Body>
                              <tem:GetAcente>       
                                 <tem:levhaNo>'||pi_levha_no||'</tem:levhaNo>         
                                 <tem:user>seda.guven@allianz.com.tr</tem:user>
                              </tem:GetAcente>
                           </soapenv:Body>
                          </soapenv:Envelope>';      
        v_errnum := 2;
          v_clob := EMPTY_CLOB;
          DBMS_LOB.createtemporary (v_clob, FALSE);
          v_errnum := 3;
          v_soap_respond := NULL;       
          v_errnum := 4;
          --utl_http.set_proxy('172.16.64.74:8080');
          v_errnum := 5;
          v_http_req := UTL_HTTP.begin_request (v_glbl_host, 'POST', 'HTTP/1.1');
          v_errnum := 6;
          UTL_HTTP.set_header (v_http_req, 'Keep-Alive', 'TE');
          v_errnum := 7;
          UTL_HTTP.set_header (v_http_req, 'Connection', 'keep-alive');
          v_errnum := 8;
          UTL_HTTP.set_header (v_http_req, 'Content-Type', 'text/xml; charset=utf-8');
          v_errnum := 9;
          UTL_HTTP.set_header (v_http_req, 'Content-Length', LENGTH (v_soap_request));
          v_errnum := 10;
          UTL_HTTP.set_header (v_http_req, 'SOAPAction', 'http://tempuri.org/GetAcente');
          v_errnum := 11;
          UTL_HTTP.write_text (v_http_req, v_soap_request);
          v_errnum := 12;
          v_http_resp := UTL_HTTP.get_response (v_http_req);
          BEGIN
            LOOP
              v_errnum := 13;
              UTL_HTTP.read_text (v_http_resp, v_soap_respond, 32767);
             -- dbms_output.put_line('Resp:'||LENGTH(v_soap_respond)||'---'||v_soap_respond);
              v_errnum := 14;
              DBMS_LOB.writeappend (v_clob, LENGTH (v_soap_respond), v_soap_respond);
            END LOOP;
          EXCEPTION
            WHEN UTL_HTTP.end_of_body THEN
              UTL_HTTP.end_response (v_http_resp);
          END;
          v_clob := REPLACE(v_clob, 'soap:','');
          v_clob := REPLACE(v_clob, 'env:','');
          v_clob := REPLACE(v_clob, 'ns2:','');
          v_clob := REPLACE(v_clob, 'S:','');
          v_clob := REPLACE(v_clob, ' xsi:nil="1"', '');
          v_clob := REPLACE(v_clob, ' xsi:nil="true"', '');
          v_clob := REPLACE(v_clob, ' xmlns="http://tempuri.org/"', '');
          v_clob := REPLACE(v_clob, ' xmlns=""', '');
          v_clob := REPLACE(v_clob, ' xmlns=', '');
          v_clob := REPLACE(v_clob, ' xmlns:ns2=', '');
          
          --print Error
          SELECT NVL(EXTRACTVALUE(XMLTYPE(v_clob), '/Envelope/Body/Fault/Reason/Text'),
                     EXTRACTVALUE(XMLTYPE(v_clob), '/Envelope/Body/Fault/faultstring'))   
            INTO v_err
            FROM DUAL;
            
          IF v_err IS NOT NULL THEN
                po_data := '{"status" : "FAIL","error_message":'||v_err||'}'; 
                po_keys := 'status,error_message';
                --DBMS_OUTPUT.PUT_LINE('Hata:'||v_err);           
          ELSE  
               po_data := '{"status" : "SUCCESS",'; 
               po_keys := 'status,acente,calisan,adres';        
               po_data := po_data || '"acente":['; 
              --print acente adi,oda,levhano
              FOR rec IN (SELECT * FROM XMLTABLE('/Envelope/Body/GetAcenteResponse/GetAcenteResult'
                               PASSING XMLTYPE(v_clob)
                         COLUMNS 
                         AcenteAdi      VARCHAR2(400) PATH 'AcenteAdi',
                         LevhaNo        VARCHAR2(100) PATH 'LevhaNo',
                         Oda            VARCHAR2(400) PATH 'Oda')) LOOP
                         IF ndx>0 THEN
                            po_data := po_data || ',';
                         END IF;
                         po_data := po_data || '{"acente_adi":"' || rec.AcenteAdi || '",'||
                                               '"levha_no":"' || rec.LevhaNo || '",'||
                                               '"oda":"'|| rec.Oda||'"}';
                 --DBMS_OUTPUT.PUT_LINE('AcenteAdi:'||rec.AcenteAdi||' Levha No:'||rec.LevhaNo||' Oda:'||rec.Oda);
              END LOOP; 
               ndx := 0;
               po_data := po_data || '],"calisan":[';
              --print calisan list 
              FOR rec IN (SELECT * FROM XMLTABLE('/Envelope/Body/GetAcenteResponse/GetAcenteResult/Calisanlist/Calisan'
                               PASSING XMLTYPE(v_clob)
                         COLUMNS 
                         TcKimlikNo      VARCHAR2(100) PATH 'TcKimlikNo',
                         Adi             VARCHAR2(100) PATH 'Adi',
                         Soyadi          VARCHAR2(100) PATH 'Soyadi',
                         SicilNo         VARCHAR2(100) PATH 'SicilNo',
                         KayitDurumuAdi  VARCHAR2(100) PATH 'KayitDurumuAdi',
                         CalisanTipiAdi  VARCHAR2(100) PATH 'CalisanTipiAdi',
                         BaslangicTarihi VARCHAR2(100) PATH 'BaslangicTarihi',
                         BitisTarihi     VARCHAR2(100) PATH 'BitisTarihi')) LOOP
                         po_data := po_data || '{"tc_kimlik_no":"' || rec.TcKimlikNo || '",'||
                                               '"adi":"' || rec.Adi || '",'||
                                               '"soyadi":"' || rec.Soyadi || '",'||
                                               '"sicil_no":"' || rec.SicilNo || '",'||
                                               '"kayit_durumu_adi":"' || rec.KayitDurumuAdi || '",'||
                                               '"calisan_tipi_adi":"' || rec.CalisanTipiAdi || '",'||
                                               '"baslangic_tarihi":"' || rec.BaslangicTarihi || '",'||
                                               '"bitis_tarihi":"'|| rec.BitisTarihi||'"}';
                 --DBMS_OUTPUT.PUT_LINE('Tckn:'||rec.TcKimlikNo||' Ad�:'||rec.Adi||' Soyadi:'||rec.Soyadi||' SicilNo: '||rec.SicilNo||' KayitDurumAdi: '||rec.KayitDurumuAdi ||' CalisanTipAdi:'||rec.CalisanTipiAdi||' BaslangicTarihi:'||rec.BaslangicTarihi||' BitisTarihi:'||rec.BitisTarihi);
              END LOOP; 
               po_data := po_data || '],"adres":[';
              --print adres list
              FOR rec IN (SELECT * FROM XMLTABLE('/Envelope/Body/GetAcenteResponse/GetAcenteResult/Adreslist/Adres'
                               PASSING XMLTYPE(v_clob)
                         COLUMNS 
                         AdresTipi      VARCHAR2(100) PATH 'AdresTipi',
                         Adresi         VARCHAR2(100) PATH 'Adresi',
                         IpAdresi       VARCHAR2(100) PATH 'IpAdresi')) LOOP
                         po_data := po_data || '{"adres_tipi":"' || rec.AdresTipi || '",'||
                                                '"adresi":"' || rec.Adresi || '",'||
                                                '"ip_adresi":"'|| rec.IpAdresi||'"}';
                 --DBMS_OUTPUT.PUT_LINE('AdresTipi:'||rec.AdresTipi||' Adresi:'||rec.Adresi||' IpAdresi:'||rec.IpAdresi);
              END LOOP; 
              po_data := po_data || ']}';
        END IF;
         --DBMS_OUTPUT.PUT_LINE(v_clob);   
        EXCEPTION
          WHEN OTHERS THEN
            v_err  := SUBSTR ('WS okunamad�.. Hata Yer: ' || v_errnum || ' Hata: ' || SQLERRM, 1, 4000);
            po_data := '{"status" : "FAIL","error_message":'||v_err||'}'; 
            UTL_HTTP.end_response (v_http_resp);
            --DBMS_OUTPUT.PUT_LINE(v_err);
            po_keys := 'status,error_message';
        END tobb_sorgula;
      BEGIN
          tobb_sorgula(v_input, v_output, v_keys);
          
          DBMS_OUTPUT.PUT_LINE(v_output);
          
      END;
