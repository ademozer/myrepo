select  alz_tpa_hlth_policy_utils.get_main_partition_type(391859520,1) FROM DUAL;

select * from all_source where lower(text) like '%ademo%' and NAME IN(
select NAME from all_source where lower(text) like '%alz_tpa_hlth_policy_utils.get_main_partition_type%')

select * from koc_clm_hlth_detail where process_date IS NOT NULL and process_date>to_date('01/06/2018','DD/MM/YYYY') order by process_date desc
