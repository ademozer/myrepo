SELECT F.EXPLANATION,C.REGION_CODE
--INTO :KONTROL.REGION_CODE,:KONTROL.A_REGION_CODE
FROM SEC_V_SYSTEM_USERS,
     KOC_CP_PARTNERS_EXT B,
     KOC_DMT_V_CURRENT_AGENTS C,
     KOC_DMT_REGION_CODE_REF F,
     KOC_DMT_V_AGENTS K
WHERE  ORACLE_USERNAME='VCEYHAN'
   AND B.PART_ID=CUSTOMER_PARTNER_ID
   AND C.AGEN_INT_ID=B.AGEN_INT_ID
   AND C.REGION_CODE=F.REGION_CODE
   AND K.INT_ID=C.AGEN_INT_ID;
   
     select  S.INT_ID 
        from SEC_V_SYSTEM_USERS u, koc_cp_partners_ext e,DMT_AGENTS S,CP_PARTNERS C
  where e.PART_ID = u.CUSTOMER_PARTNER_ID
    and s.INT_ID = e.AGEN_INT_ID
    and ORACLE_USERNAME = 'VCEYHAN'
    and S.CUST_PART_UNIQUE_CODE = C.PARTNER_REF;
    
    select * from koc_dmt_agents_ext where int_id=12354
    
    
   -- SELECT SEQ_ALZ_DOCS.NEXTVAL FROM DUAL
   
   select * from ALZ_FN_MIG_CONTRACTS where mig_status='DONE'
   select * from alz_prod_docs where contract_id=156310000
   select distinct mime_type from alz_doc_infos where object_id = 30617311
   select * from alz_doc_recovery where object_id = 30617267
   
   
     SELECT a.contract_id, a.policy_ref
     -- INTO :koc_clm_v_trans.contract_id,:koc_clm_v_trans.POLICY_REF 
      FROM clm_pol_bases a, koc_ocp_pol_versions_ext b--, koc_ocp_pol_contracts_ext c
     WHERE a.claim_id = 27092500--:koc_clm_v_trans.claim_id 
       AND a.contract_id = b.contract_id 
       AND b.version_no = 1
       AND rownum<2;
       
       select * from  koc_clm_v_trans where rownum<3
       
      select AGENT_CATEGORY_TYPE from koc_dmt_agents_ext
      
       select b.email  from sec_v_system_users a,cp_partners b
        where a.ORACLE_USERNAME='VCEYHAN' and a.CUSTOMER_PARTNER_ID=b.PART_ID;
        
        select koc_clm_utils.PARTNER_NAME_BUL(b.part_id), b.email from sec_v_system_users a,cp_partners b
          where a.ORACLE_USERNAME='VCEYHAN' and a.CUSTOMER_PARTNER_ID=b.PART_ID;
      
   select * from all_source where lower(text) like '% aso %' and owner='CUSTOMER'
 
