select * from koc_clm_subfile_cause4_rel


select alz_tpa_core_utils.get_company_code('344748432') from dual

select * from all_tables where table_name like '%ROLE_REL%'

select * from KOC_AUTH_USER_ROLE_REL WHERE username='WFIBA6150_60149'

select * from web_sec_system_users 
      -- set end_date = NULL
     where user_name='WFIBA6150_60149';
     
   select * from all_procedures where object_name like '%BORDRO%'
   select * from all_source where lower(text) like '%r�cu%'
   
   
   KOC_CLM_BORDRO
   
select * from  KOC_CLM_COV_SF_LINKS_EXT

select * from web_sec_system_users where user_name = 'WFIBA_EOLMEZ' for update--like '%WFIBA%'

5080435EDA84D9904F9BDE363E0DEA87

SELECT Alz_Web_User_Security.Aesdecrypt('5080435EDA84D9904F9BDE363E0DEA87') from dual

select * from BV_KOC_OCP_PARTITIONS_EXT
