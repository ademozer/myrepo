BEGIN  
  update alz_doc_recovery a
     set a.tpa_company_code =  NVL((select b.company_code 
                                      from WIP_KOC_OCP_POL_CONTRACTS_EXT b,alz_prod_docs c 
                                     where b.contract_id = c.contract_id
                                       and c.object_id = a.object_id
                                     UNION
                                    select b.company_code 
                                      from KOC_OCP_POL_CONTRACTS_EXT b,alz_prod_docs c 
                                     where b.contract_id = c.contract_id
                                       and c.object_id = a.object_id),'045')                                                                       
  where a.object_id in ( 
        select a.object_id from alz_prod_docs a, ALZ_FN_MIG_CONTRACTS b
        where a.contract_id = b.contract_id
          and a.old_doc_id = b.document_id       
    )
    and a.tpa_company_code IS NULL;
    
    update alz_doc_recovery 
       set try_count = 1         
     where IMPL_CLASS = 'com.allianz.filenet.impl.FilenetProcessHealthProdImpl' 
       and STATUS = 'FILENET_ERROR'
       and try_count > 1;
      
COMMIT;
END;
/  
