DECLARE 
   v_stmt VARCHAR2(32000);  
   l_try      NUMBER;
   l_status   NUMBER;
BEGIN
  DBMS_PARALLEL_EXECUTE.create_task (task_name => 'filenet_mig'); 
  DBMS_PARALLEL_EXECUTE.create_chunks_by_rowid(task_name   => 'filenet_mig',
                                               table_owner => 'ALLZWEBPOL',
                                               table_name  => 'ALZ_FN_MIG_CONTRACTS',
                                               by_row      => TRUE,
                                               chunk_size  => 1000);
  v_stmt := 'DECLARE v_count NUMBER := 0;
    v_commit NUMBER := 100;
    v_limit NUMBER := 1000;
    v_err_msg VARCHAR2(1000); 
    v_source_id NUMBER;
    v_mime_type VARCHAR2(10);
    v_Binary_Data BLOB;
    v_date_1 DATE := SYSDATE;
    v_date_2 DATE;
    v_object_id ALZ_PROD_DOCS.OBJECT_ID%TYPE;
    v_doc_name VARCHAR2(1000);
   
CURSOR c_main IS
   SELECT m.CONTRACT_ID,
          m.DOCUMENT_GROUP_ID,
          m.DOCUMENT_TYPE,
          m.DOCUMENT_NAME,
          m.IS_ORIGINAL,
          m.EXPLANATION,
          m.CREATED_BY,
          m.CREATE_DATE,                         
          m.DOCUMENT_ID,       
          ROWID ROW_ID     
     FROM ALZ_FN_MIG_CONTRACTS m
    WHERE m.MIG_STATUS=''TODO''       
     AND ROWID BETWEEN :start_id AND :end_id;
     
  CURSOR c_meta_wip(p_contractId IN WIP_INTERESTED_PARTIES.CONTRACT_ID%TYPE) IS
      SELECT  A.CONTRACT_ID,  
              NVL(C.IDENTITY_NO, C.TAX_NUMBER) AS IDENTITY_OR_TAXNO,  
              CASE WHEN C.PARTNER_TYPE = ''P'' THEN ''I'' ELSE C.PARTNER_TYPE END AS PARTNER_TYPE,
              (SELECT COMPANY_CODE FROM WIP_KOC_OCP_POL_CONTRACTS_EXT WHERE CONTRACT_ID = a.CONTRACT_ID) COMPANY_CODE    
              FROM WIP_INTERESTED_PARTIES A, WIP_IP_LINKS B, KOC_CP_V_HLTH_PARTNERS C  
              WHERE A.CONTRACT_ID = B.CONTRACT_ID
              AND A.IP_NO = B.IP_NO  
              AND A.PARTNER_ID = C.PART_ID  
              AND B.ROLE_TYPE = ''PH''
              AND B.ACTION_CODE <> ''D''             
              AND C.FROM_DATE <= SYSDATE
              AND C.END_DATE >= SYSDATE
              AND A.CONTRACT_ID = p_contractId; 
              
   CURSOR c_meta_pol(p_contractId IN WIP_INTERESTED_PARTIES.CONTRACT_ID%TYPE) IS
      SELECT
          A.CONTRACT_ID,  
        NVL(C.IDENTITY_NO, C.TAX_NUMBER) AS IDENTITY_OR_TAXNO,  
        CASE WHEN C.PARTNER_TYPE = ''P'' THEN ''I'' ELSE C.PARTNER_TYPE END AS PARTNER_TYPE,
        (SELECT COMPANY_CODE FROM KOC_OCP_POL_CONTRACTS_EXT WHERE CONTRACT_ID = a.CONTRACT_ID) COMPANY_CODE    
        FROM OCP_INTERESTED_PARTIES A, OCP_IP_LINKS B, KOC_CP_V_HLTH_PARTNERS C  
        WHERE A.CONTRACT_ID = B.CONTRACT_ID
        AND A.IP_NO = B.IP_NO  
        AND A.PARTNER_ID = C.PART_ID  
        AND B.ROLE_TYPE = ''PH''
        AND B.ACTION_CODE <> ''D''
        AND B.TOP_INDICATOR = ''Y''
        AND C.FROM_DATE <= SYSDATE
          AND C.END_DATE >= SYSDATE
          AND A.CONTRACT_ID = p_contractId;                
  v_not_found BOOLEAN:= FALSE;
  r_meta c_meta_wip%ROWTYPE;

BEGIN

    select source_id 
    into v_source_id
    from ALZ_DMS_SOURCE_DEF 
    where source_username = ''WAZNETHLTH'';

  FOR r_main IN c_main LOOP  
       v_object_id := SEQ_ALZ_DOCS.NEXTVAL;
       v_doc_name := r_main.DOCUMENT_NAME;      
      IF INSTR(r_main.DOCUMENT_NAME,''.'') = 0 THEN
         v_err_msg := ''Content Type Not Defined. Document_Name : ''||r_main.DOCUMENT_NAME||'' - Document_Id : ''||r_main.DOCUMENT_ID;     
         v_mime_type := ''image/png'';   
      ELSE 
         v_mime_type := UPPER(SUBSTR(r_main.DOCUMENT_NAME,INSTR(r_main.DOCUMENT_NAME,''.'',-1)+1));       
      END IF;  
      IF LENGTH(r_main.DOCUMENT_NAME) >= 100 THEN
         v_err_msg := ''Document Name Is Too Long. Document_Name : ''||r_main.DOCUMENT_NAME||'' - Document_Id : ''||r_main.DOCUMENT_ID;       
         v_doc_name := SUBSTR(r_main.DOCUMENT_NAME,1,90)||''.''||v_mime_type;  
      END IF;         
          INSERT INTO ALZ_PROD_DOCS(OBJECT_ID,
                                    CONTRACT_ID,
                                    DOCUMENT_GROUP_ID,
                                    DOC_CODE,
                                    IS_ORIGINAL,
                                    EXPLANATION,
                                    CREATED_BY,
                                    CREATE_DATE,                         
                                    OLD_DOC_ID)
                 VALUES(v_OBJECT_ID,
                        r_main.CONTRACT_ID,
                        r_main.DOCUMENT_GROUP_ID,
                        r_main.DOCUMENT_TYPE,
                        r_main.IS_ORIGINAL,
                        r_main.EXPLANATION,
                        r_main.CREATED_BY,
                        r_main.CREATE_DATE,                         
                        r_main.DOCUMENT_ID);          
             v_not_found :=FALSE;
             OPEN c_meta_wip(r_main.CONTRACT_ID);             
             FETCH c_meta_wip INTO r_meta;
             v_not_found := c_meta_wip%NOTFOUND;            
             CLOSE c_meta_wip;
             
             IF v_not_found THEN
                 OPEN c_meta_pol(r_main.CONTRACT_ID);             
                 FETCH c_meta_pol INTO r_meta;                 
                 CLOSE c_meta_pol;
             END IF;
               
                INSERT INTO ALZ_DOC_INFOS(OBJECT_ID,
                                          IDENTITY_NO,
                                          IDENTITY_TYPE,
                                          DOC_CODE,
                                          DOC_SOURCE_ID,                                     
                                          IS_MASAK,                                     
                                          COMM_ID,                                    
                                          STMT_ID,                                      
                                          IS_RECOVERY,                                      
                                          FILE_NAME,
                                          MIME_TYPE,
                                          CREATE_DATE,                                      
                                          RECOVERY_TRY_COUNT,
                                          DMS_DOC_CODE)
                VALUES(v_OBJECT_ID,
                       r_meta.IDENTITY_OR_TAXNO,
                       r_meta.PARTNER_TYPE,
                       r_main.DOCUMENT_TYPE,   -- 1 ve 0 durumunda de�i�ecek. 
                       v_source_id,
                       0,
                       0,
                       0,
                       0,
                       v_doc_name,--r_main.DOCUMENT_NAME,
                       v_mime_type,
                       SYSTIMESTAMP,
                       0,
                       r_main.DOCUMENT_TYPE); -- 1 ve 0 durumunda de�i�ecek.
               
             
            SELECT ATTACHMENT 
              INTO v_Binary_Data
              FROM ALZ_DOCUMENTS 
             WHERE document_id = r_main.DOCUMENT_ID;
          
             INSERT INTO ALZ_DOC_RECOVERY(OBJECT_ID,
                                          UPLOAD_DATE,
                                          UPLOAD_HOST,                                         
                                          BINARY_DATA,
                                          STATUS,  -- ba�lacak
                                          TRY_COUNT,
                                          MIME_TYPE,
                                          FILE_NAME,                                         
                                          IMPL_CLASS,                                        
                                          TPA_COMPANY_CODE)
                    VALUES(v_OBJECT_ID,
                           SYSTIMESTAMP,
                           ''287avcw10dvp'',                                         
                            v_Binary_Data,
                            ''FILENET_ERROR'',
                            1,
                            v_mime_type,
                            v_doc_name,--r_main.DOCUMENT_NAME,                                         
                            ''com.allianz.filenet.impl.FilenetProcessHealthProdImpl'',                                        
                            r_meta.COMPANY_CODE);                                          
            
         
               
        UPDATE ALZ_FN_MIG_CONTRACTS 
           SET MIG_STATUS = ''DONE''
         WHERE ROWID = r_main.ROW_ID;
         
      
        IF MOD(v_count, v_commit) = 0 THEN 
           COMMIT;
        END IF;
        v_count := v_count +1;          
   END LOOP;
   COMMIT;
   v_date_2 := SYSDATE;
   DBMS_OUTPUT.PUT_LINE(v_count||'' adet kay�t insert edildi. d1:''||TO_CHAR(v_date_1,''DD/MM/YYYY HH24:MI:SS'')||'' date_2:''||TO_CHAR(v_date_2,''DD/MM/YYYY HH24:MI:SS''));
EXCEPTION
WHEN OTHERS THEN
     v_err_msg := SQLERRM;
     DBMS_OUTPUT.PUT_LINE(''Hata:''||SUBSTR(v_err_msg,1,200));
     ROLLBACK;   
 END;';
  DBMS_PARALLEL_EXECUTE.run_task(task_name      => 'filenet_mig',
                                 sql_stmt       => v_stmt,
                                 language_flag  => DBMS_SQL.NATIVE,
                                 parallel_level => 6);
   l_try := 0;
  l_status := DBMS_PARALLEL_EXECUTE.task_status('filenet_mig');
  dbms_output.put_line(l_status);
  /*WHILE(l_try < 2 and l_status != DBMS_PARALLEL_EXECUTE.FINISHED) 
  Loop
    l_try := l_try + 1;
    DBMS_PARALLEL_EXECUTE.resume_task('filenet_mig');
    l_status := DBMS_PARALLEL_EXECUTE.task_status('filenet_mig');
  END LOOP;*/

  --DBMS_PARALLEL_EXECUTE.drop_task('filenet_mig');                               
                                             
END;
/
