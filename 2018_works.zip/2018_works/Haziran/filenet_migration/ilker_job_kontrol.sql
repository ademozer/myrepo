SELECT *
FROM   user_parallel_execute_tasks;

SELECT *--chunk_id, status, start_rowid, end_rowid
FROM   user_parallel_execute_chunks
WHERE  task_name = 'alz_fn_migration_run'
ORDER BY chunk_id;

select count(*) from ALZ_FN_MIG_CONTRACTS where mig_status='DONE'


SELECT status, COUNT (status) FROM user_parallel_execute_chunks GROUP BY status

SELECT *
FROM   user_scheduler_job_run_details
WHERE  job_name LIKE (SELECT job_prefix || '%'
                      FROM   user_parallel_execute_tasks
                      WHERE  task_name = 'alz_fn_migration_run');
                      
                      
             
