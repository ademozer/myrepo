DECLARE 
   v_stmt VARCHAR2(32000);  
   v_max_sira_no NUMBER;
BEGIN
  SELECT MAX(SIRA_NO)
    INTO v_max_sira_no
    FROM CUSTOMER.ALZ_FN_MIG_CONTRACTS
   WHERE SIRA_NO IS NOT NULL;
     
  -- 1 (HPF) --
  INSERT INTO CUSTOMER.ALZ_FN_MIG_CONTRACTS(
    CONTRACT_ID,
    SRC_TYPE,
    DOCUMENT_ID,  
    DOCUMENT_NAME,  
    DOCUMENT_TYPE,  
    EXPLANATION,  
    VALIDITY_START_DATE,  
    VALIDITY_END_DATE,   
    CREATE_DATE,  
    CREATED_BY,  
    DOCUMENT_GROUP_ID,  
    CONTENT_TYPE,  
    IS_ORIGINAL,
    MIG_STATUS
    ) 
    SELECT
    WIPPOL.CONTRACT_ID,
    WIPPOL.POL_STATUS SRC_TYPE,
    ALZD.DOCUMENT_ID,  
    ALZD.DOCUMENT_NAME,  
    ALZD.DOCUMENT_TYPE,
    ALZD.EXPLANATION,  
    ALZD.VALIDITY_START_DATE,  
    ALZD.VALIDITY_END_DATE,
    ALZD.CREATE_DATE,  
    ALZD.CREATED_BY,  
    ALZD.DOCUMENT_GROUP_ID,  
    ALZD.CONTENT_TYPE,  
    ALZD.IS_ORIGINAL,
    'TODO' MIG_STATUS
    FROM (
      SELECT DISTINCT 'HPF' AS POL_STATUS, HP.CONTRACT_ID, HP.DOCUMENT_GROUP_ID AUTH_DOCUMENT_GROUP_ID
        FROM KOC_HPF_TRN_DET HP
      WHERE HP.DOCUMENT_GROUP_ID IS NOT NULL
    ) WIPPOL
    INNER JOIN (
    SELECT CONTRACT_ID
    FROM WIP_POLICY_CONTRACTS
    WHERE PRODUCT_ID = 63
      UNION
    SELECT CONTRACT_ID 
    FROM OCP_POLICY_CONTRACTS
    WHERE PRODUCT_ID = 63
    ) PRD
    ON PRD.CONTRACT_ID = WIPPOL.CONTRACT_ID
    INNER JOIN ALZ_DOCUMENTS ALZD  
    ON WIPPOL.AUTH_DOCUMENT_GROUP_ID = ALZD.DOCUMENT_GROUP_ID 
    LEFT JOIN CUSTOMER.ALZ_PROD_DOCS ALZP
    ON WIPPOL.AUTH_DOCUMENT_GROUP_ID = ALZP.DOCUMENT_GROUP_ID
    AND ALZD.DOCUMENT_ID = ALZP.OLD_DOC_ID
    WHERE 1=1
    AND WIPPOL.AUTH_DOCUMENT_GROUP_ID <> 0
    AND ALZP.OBJECT_ID IS NULL
    AND ALZD.ATTACHMENT IS NOT NULL
    AND NOT EXISTS (SELECT 1 FROM CUSTOMER.ALZ_FN_MIG_CONTRACTS A
            WHERE A.DOCUMENT_GROUP_ID = WIPPOL.AUTH_DOCUMENT_GROUP_ID
            AND A.CONTRACT_ID = WIPPOL.CONTRACT_ID
            AND A.DOCUMENT_ID = ALZD.DOCUMENT_ID);
            
 
    -- 2 (POL) --
    INSERT INTO ALZ_FN_MIG_CONTRACTS(
    CONTRACT_ID,
    SRC_TYPE,
    DOCUMENT_ID,  
    DOCUMENT_NAME,  
    DOCUMENT_TYPE,  
    EXPLANATION,  
    VALIDITY_START_DATE,  
    VALIDITY_END_DATE,   
    CREATE_DATE,  
    CREATED_BY,  
    DOCUMENT_GROUP_ID,  
    CONTENT_TYPE,  
    IS_ORIGINAL,
    MIG_STATUS
    ) 
    SELECT
    WIPPOL.CONTRACT_ID,
    WIPPOL.POL_STATUS SRC_TYPE,
    ALZD.DOCUMENT_ID,  
    ALZD.DOCUMENT_NAME,  
    ALZD.DOCUMENT_TYPE,
    ALZD.EXPLANATION,  
    ALZD.VALIDITY_START_DATE,  
    ALZD.VALIDITY_END_DATE,
    ALZD.CREATE_DATE,  
    ALZD.CREATED_BY,  
    ALZD.DOCUMENT_GROUP_ID,  
    ALZD.CONTENT_TYPE,  
    ALZD.IS_ORIGINAL,
    'TODO' MIG_STATUS
    FROM (
      SELECT DISTINCT 'POL' AS POL_STATUS, PC.CONTRACT_ID, PV.AUTH_DOCUMENT_GROUP_ID
        FROM KOC_OCP_POL_VERSIONS_EXT PV, KOC_OCP_POL_CONTRACTS_EXT PC
      WHERE PV.CONTRACT_ID = PC.CONTRACT_ID
      AND PV.AUTH_DOCUMENT_GROUP_ID IS NOT NULL
    ) WIPPOL
    INNER JOIN (
    SELECT CONTRACT_ID
    FROM WIP_POLICY_CONTRACTS
    WHERE PRODUCT_ID = 63
      UNION
    SELECT CONTRACT_ID 
    FROM OCP_POLICY_CONTRACTS
    WHERE PRODUCT_ID = 63
    ) PRD
    ON PRD.CONTRACT_ID = WIPPOL.CONTRACT_ID
    INNER JOIN ALZ_DOCUMENTS ALZD  
    ON WIPPOL.AUTH_DOCUMENT_GROUP_ID = ALZD.DOCUMENT_GROUP_ID 
    LEFT JOIN CUSTOMER.ALZ_PROD_DOCS ALZP
    ON WIPPOL.AUTH_DOCUMENT_GROUP_ID = ALZP.DOCUMENT_GROUP_ID
    AND ALZD.DOCUMENT_ID = ALZP.OLD_DOC_ID
    WHERE 1=1
    AND WIPPOL.AUTH_DOCUMENT_GROUP_ID <> 0
    AND ALZP.OBJECT_ID IS NULL
    AND ALZD.ATTACHMENT IS NOT NULL
    AND NOT EXISTS (SELECT 1 FROM ALZ_FN_MIG_CONTRACTS A
            WHERE A.DOCUMENT_GROUP_ID = WIPPOL.AUTH_DOCUMENT_GROUP_ID
            AND A.CONTRACT_ID = WIPPOL.CONTRACT_ID
            AND A.DOCUMENT_ID = ALZD.DOCUMENT_ID);
          
        
   -- 3 (WIP) --
   INSERT INTO ALZ_FN_MIG_CONTRACTS(
    CONTRACT_ID,
    SRC_TYPE,
    DOCUMENT_ID,  
    DOCUMENT_NAME,  
    DOCUMENT_TYPE,  
    EXPLANATION,  
    VALIDITY_START_DATE,  
    VALIDITY_END_DATE,   
    CREATE_DATE,  
    CREATED_BY,  
    DOCUMENT_GROUP_ID,  
    CONTENT_TYPE,  
    IS_ORIGINAL,
    MIG_STATUS
    ) 
    SELECT
    WIPPOL.CONTRACT_ID,
    WIPPOL.POL_STATUS SRC_TYPE,
    ALZD.DOCUMENT_ID,  
    ALZD.DOCUMENT_NAME,  
    ALZD.DOCUMENT_TYPE,
    ALZD.EXPLANATION,  
    ALZD.VALIDITY_START_DATE,  
    ALZD.VALIDITY_END_DATE,
    ALZD.CREATE_DATE,  
    ALZD.CREATED_BY,  
    ALZD.DOCUMENT_GROUP_ID,  
    ALZD.CONTENT_TYPE,  
    ALZD.IS_ORIGINAL,
    'TODO' MIG_STATUS
    FROM (
      SELECT DISTINCT 'WIP' AS POL_STATUS, WC.CONTRACT_ID, WV.AUTH_DOCUMENT_GROUP_ID
        FROM WIP_KOC_OCP_POL_VERSIONS_EXT WV, WIP_KOC_OCP_POL_CONTRACTS_EXT WC
      WHERE WV.CONTRACT_ID = WC.CONTRACT_ID
      AND WV.AUTH_DOCUMENT_GROUP_ID IS NOT NULL
    ) WIPPOL
    INNER JOIN (
    SELECT CONTRACT_ID
    FROM WIP_POLICY_CONTRACTS
    WHERE PRODUCT_ID = 63
      UNION
    SELECT CONTRACT_ID 
    FROM OCP_POLICY_CONTRACTS
    WHERE PRODUCT_ID = 63
    ) PRD
    ON PRD.CONTRACT_ID = WIPPOL.CONTRACT_ID
    INNER JOIN ALZ_DOCUMENTS ALZD  
    ON WIPPOL.AUTH_DOCUMENT_GROUP_ID = ALZD.DOCUMENT_GROUP_ID 
    LEFT JOIN CUSTOMER.ALZ_PROD_DOCS ALZP
    ON WIPPOL.AUTH_DOCUMENT_GROUP_ID = ALZP.DOCUMENT_GROUP_ID
    AND ALZD.DOCUMENT_ID = ALZP.OLD_DOC_ID
    WHERE 1=1
    AND WIPPOL.AUTH_DOCUMENT_GROUP_ID <> 0
    AND ALZP.OBJECT_ID IS NULL
    AND ALZD.ATTACHMENT IS NOT NULL
    AND NOT EXISTS (SELECT 1 FROM ALZ_FN_MIG_CONTRACTS A
            WHERE A.DOCUMENT_GROUP_ID = WIPPOL.AUTH_DOCUMENT_GROUP_ID
            AND A.CONTRACT_ID = WIPPOL.CONTRACT_ID
            AND A.DOCUMENT_ID = ALZD.DOCUMENT_ID);
  
           
  UPDATE ALZ_FN_MIG_CONTRACTS
    SET SIRA_NO = (v_max_sira_no + ROWNUM) 
  WHERE SIRA_NO IS NULL;
  
  COMMIT;
  
  v_stmt := 'DECLARE v_count NUMBER := 0;
    v_commit NUMBER := 100;
    v_limit NUMBER := 1000;
    v_err_msg VARCHAR2(10000); 
    v_source_id NUMBER;
    v_mime_type VARCHAR2(1000);
    v_Binary_Data BLOB;
    v_date_1 DATE := SYSDATE;
    v_date_2 DATE;
    v_object_id ALZ_PROD_DOCS.OBJECT_ID%TYPE;
    v_doc_name VARCHAR2(2000);  
    v_doc_type VARCHAR2(10); 
CURSOR c_main IS
   SELECT m.CONTRACT_ID,
          m.DOCUMENT_GROUP_ID,
          m.DOCUMENT_TYPE,
          m.DOCUMENT_NAME,
          m.IS_ORIGINAL,
          m.EXPLANATION,
          m.CREATED_BY,
          m.CREATE_DATE,                         
          m.DOCUMENT_ID,
          m.SRC_TYPE,
         (select NVL(IDENTITY_NO,TAX_NUMBER) from koc_cp_partners_ext where part_id = p.partner_id) IDENTITY_OR_TAXNO,
         (select CASE WHEN PARTNER_TYPE = ''P'' THEN ''I'' ELSE PARTNER_TYPE END from cp_partners where part_id = p.partner_id) PARTNER_TYPE,
         (SELECT COMPANY_CODE FROM KOC_OCP_POL_CONTRACTS_EXT WHERE CONTRACT_ID = m.CONTRACT_ID
          UNION
          SELECT COMPANY_CODE FROM WIP_KOC_OCP_POL_CONTRACTS_EXT WHERE CONTRACT_ID = m.CONTRACT_ID
         ) COMPANY_CODE,
         (select attachment from alz_documents where document_id = m.document_id) BINARY_DATA,  
          m.ROWID ROW_ID                   
     FROM ALZ_FN_MIG_CONTRACTS m, (select ip.contract_id, ip.partner_id 
                                     from wip_interested_parties ip, wip_ip_links il                                   
                                    where ip.ip_no = il.ip_no 
                                      and ip.contract_id = il.contract_id
                                      and il.role_type = ''PH''                                    
                                      and il.action_code <> ''D''
                                     union
                                     select ip.contract_id,ip.partner_id
                                     from ocp_interested_parties ip,ocp_ip_links il                                      
                                     where ip.ip_no = il.ip_no 
                                       and ip.contract_id = il.contract_id
                                       and il.role_type = ''PH''
                                       and il.top_indicator = ''Y''
                                       and il.action_code <> ''D'') p
    WHERE m.MIG_STATUS=''TODO''
     and m.contract_id = p.contract_id          
     AND SIRA_NO>:p_max_sira_no;          
BEGIN   
   v_source_id := 44;
  FOR r_main IN c_main LOOP  
       BEGIN
         v_err_msg := '''';
         v_object_id := SEQ_ALZ_DOCS.NEXTVAL;
         v_doc_name := r_main.DOCUMENT_NAME;      
        IF INSTR(r_main.DOCUMENT_NAME,''.'') = 0 THEN
           v_err_msg := ''Content Type Not Defined. Document_Name : ''||r_main.DOCUMENT_NAME||'' - Document_Id : ''||r_main.DOCUMENT_ID;     
           v_mime_type := ''image_png'';   
        ELSE 
           v_mime_type := UPPER(SUBSTR(r_main.DOCUMENT_NAME,INSTR(r_main.DOCUMENT_NAME,''.'',-1)+1));       
        END IF;  
        IF LENGTH(r_main.DOCUMENT_NAME) >= 100 THEN
           v_err_msg := ''Document Name Is Too Long. Document_Name : ''||r_main.DOCUMENT_NAME||'' - Document_Id : ''||r_main.DOCUMENT_ID;       
           v_doc_name := SUBSTR(r_main.DOCUMENT_NAME,1,90)||''.''||v_mime_type;  
        END IF;   
        IF r_main.SRC_TYPE = ''HPF'' THEN
            v_doc_type := ''AS35099'';
        ELSE 
            IF r_main.DOCUMENT_TYPE = 0 THEN
                 v_doc_type := ''AS35099'';
            ELSE 
                 v_doc_type := ''AS03033'';
            END IF;
        END IF;    
            INSERT INTO ALZ_PROD_DOCS(OBJECT_ID,
                                      CONTRACT_ID,
                                      DOCUMENT_GROUP_ID,
                                      DOC_CODE,
                                      IS_ORIGINAL,
                                      EXPLANATION,
                                      CREATED_BY,
                                      CREATE_DATE,                         
                                      OLD_DOC_ID)
                   VALUES(v_OBJECT_ID,
                          r_main.CONTRACT_ID,
                          r_main.DOCUMENT_GROUP_ID,
                          v_doc_type,
                          r_main.IS_ORIGINAL,
                          r_main.EXPLANATION,
                          r_main.CREATED_BY,
                          r_main.CREATE_DATE,                         
                          r_main.DOCUMENT_ID);          
                     
                  INSERT INTO ALZ_DOC_INFOS(OBJECT_ID,
                                            IDENTITY_NO,
                                            IDENTITY_TYPE,
                                            DOC_CODE,
                                            DOC_SOURCE_ID,                                     
                                            IS_MASAK,                                     
                                            COMM_ID,                                    
                                            STMT_ID,                                      
                                            IS_RECOVERY,                                      
                                            FILE_NAME,
                                            MIME_TYPE,
                                            CREATE_DATE,                                      
                                            RECOVERY_TRY_COUNT,
                                            DMS_DOC_CODE)
                  VALUES(v_OBJECT_ID,
                         r_main.IDENTITY_OR_TAXNO,
                         r_main.PARTNER_TYPE,
                         v_doc_type,  
                         v_source_id,
                         0,
                         0,
                         0,
                         0,
                         v_doc_name,--r_main.DOCUMENT_NAME,
                         v_mime_type,
                         SYSTIMESTAMP,
                         0,
                         v_doc_type); -- 1 ve 0 durumunda de�i�ecek.                                
                   
               INSERT INTO ALZ_DOC_RECOVERY(OBJECT_ID,
                                            UPLOAD_DATE,
                                            UPLOAD_HOST,                                         
                                            BINARY_DATA,
                                            STATUS,  -- ba�lacak
                                            TRY_COUNT,
                                            MIME_TYPE,
                                            FILE_NAME,                                         
                                            IMPL_CLASS,                                        
                                            TPA_COMPANY_CODE)
                      VALUES(v_OBJECT_ID,
                             SYSTIMESTAMP,
                             ''287avcw10dvp'',                                         
                              r_main.BINARY_DATA,--v_Binary_Data,
                              ''FILENET_ERROR'',
                              1,
                              v_mime_type,
                              v_doc_name,--r_main.DOCUMENT_NAME,                                         
                              ''com.allianz.filenet.impl.FilenetProcessHealthProdImpl'',                                        
                              r_main.COMPANY_CODE);                                          
                              
          UPDATE ALZ_FN_MIG_CONTRACTS
             SET MIG_STATUS = ''DONE'',
                 ERROR_DESC = v_err_msg
           WHERE ROWID = r_main.ROW_ID;                   
       EXCEPTION
       WHEN OTHERS THEN
           v_err_msg := SQLERRM;
           UPDATE ALZ_FN_MIG_CONTRACTS
             SET MIG_STATUS = ''FAIL'', 
                 ERROR_DESC = SUBSTR(v_err_msg,1,400)
           WHERE ROWID = r_main.ROW_ID;
       END;
        IF MOD(v_count, v_commit) = 0 THEN 
           COMMIT;
        END IF;
        v_count := v_count +1;           
   END LOOP;
   COMMIT;
   v_date_2 := SYSDATE;
   --DBMS_OUTPUT.PUT_LINE(v_count||'' adet kay�t insert edildi. d1:''||TO_CHAR(v_date_1,''DD/MM/YYYY HH24:MI:SS'')||'' date_2:''||TO_CHAR(v_date_2,''DD/MM/YYYY HH24:MI:SS''));
EXCEPTION
WHEN OTHERS THEN
     v_err_msg := SQLERRM;
     --DBMS_OUTPUT.PUT_LINE(''Hata:''||SUBSTR(v_err_msg,1,200));
     ROLLBACK;   
 END;';

EXECUTE IMMEDIATE v_stmt USING v_max_sira_no;                            
                                             
END;
/
