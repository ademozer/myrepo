create table ALZ_FN_MIG_META
(
  contract_id         NUMBER(10),
  identity_no         VARCHAR2(30),
  partner_type        VARCHAR2(10),
  company_code        VARCHAR2(10)
)
/
ALTER TABLE ALZ_FN_MIG_META ADD (
  CONSTRAINT ALZ_FN_MIG_META_PK
  PRIMARY KEY
  (CONTRACT_ID)
  ENABLE VALIDATE)
/

CREATE PUBLIC SYNONYM ALZ_FN_MIG_META FOR CUSTOMER.ALZ_FN_MIG_META
/ 
grant select, insert, update, delete on ALZ_FN_MIG_META to PUBLIC
/
