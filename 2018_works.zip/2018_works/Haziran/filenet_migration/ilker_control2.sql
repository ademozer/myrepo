select * from alz_doc_recovery where object_id in( select a.object_id from alz_prod_docs a, ALZ_FN_MIG_CONTRACTS b
        where a.contract_id = b.contract_id
          and a.old_doc_id = b.document_id
          and b.src_type = 'POL') and tpa_company_code IS NULL

select * from alz_prod_docs where object_id = 31683497
select * from dmt_agents where reference_code='70001'

select * from wip_koc_ocp_pol_contracts_ext where contract_id=399697707

select count(*) from ALZ_FN_MIG_CONTRACTS where sira_no > 896576 and mig_status='FAIL'

select *--a.region_code
  from koc_dmt_v_current_agents a
 where agen_int_id = 72171--71075
 
   and start_date <= p_date
   and (end_date >= p_date or end_date is null);
