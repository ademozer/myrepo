SELECT 1,--alz_documents_seq.NEXTVAL DOCUMENT_ID,
       (select file_name from alz_doc_recovery where object_id = p.object_id) DOCUMENT_NAME,
       CASE p.DOC_CODE 
          WHEN 'AS03033' THEN 1
          WHEN 'AS35099' THEN 0
          ELSE 0
       END DOCUMENT_TYPE,
       p.EXPLANATION,
       null VALIDITY_START_DATE,
       null VALIDITY_END_DATE,
       (select binary_data from alz_doc_recovery where object_id = p.object_id) ATTACHMENT,
       p.CREATE_DATE,
       p.CREATED_BY,
       p.DOCUMENT_GROUP_ID,
       (SELECT CASE MIME_TYPE 
          WHEN 'PDF' THEN  'application/pdf'
          WHEN 'JPEG' THEN  'image/jpeg'
          WHEN 'PNG' THEN  'image/png'
          WHEN 'TIFF' THEN  'image/tiff'
          WHEN 'DOC' THEN  'application/msword'
          WHEN 'XLSX' THEN  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
          WHEN 'RTF' THEN  'application/rtf'
          WHEN 'TIF' THEN  'image/tiff'
          WHEN 'XLS' THEN  'application/vnd.ms-excel'
          WHEN 'DOCX' THEN  'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
          WHEN 'JPG' THEN  'image/jpeg'
          WHEN 'MSG' THEN  'application/octet-stream'
          WHEN 'PPTX' THEN  'application/vnd.openxmlformats-officedocument.presentationml.presentation'
          ELSE 'image/png' 
       END FROM alz_doc_recovery where object_id = p.object_id) CONTENT_TYPE, 
       0 IS_ORIGINAL
FROM alz_prod_docs p
WHERE p.old_doc_id IS NULL;

select * from ALZ_PROD_DOCS WHERE DOCUMENT_GROUP_ID > 2000000 ORDER BY DOCUMENT_GROUP_ID DESC


SELECT TE.EMP_ID_NO FROM KOC_DMT_AGENCY_TECH_EMP TE 
WHERE TE.AGENT_INT_ID = 72169 
