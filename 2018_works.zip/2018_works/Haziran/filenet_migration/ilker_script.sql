DECLARE 
    v_count NUMBER := 0;
    v_commit NUMBER := 100;
    v_limit NUMBER := 700;
    v_err_msg VARCHAR2(1000); 
    v_source_id NUMBER;
    v_mime_type VARCHAR2(1000);
    v_Binary_Data BLOB;
CURSOR c_main IS
   SELECT (50000000 + SEQ_ALZ_DOCS.NEXTVAL) OBJECT_ID,
          m.CONTRACT_ID,
          m.DOCUMENT_GROUP_ID,
          m.DOCUMENT_TYPE,
          m.DOCUMENT_NAME,
          m.IS_ORIGINAL,
          m.EXPLANATION,
          m.CREATED_BY,
          m.CREATE_DATE,                         
          m.DOCUMENT_ID,       
          ROWID ROW_ID 
     FROM ALZ_FN_MIG_CONTRACTS m
    WHERE m.MIG_STATUS='TODO'       
     AND ROWNUM<=v_limit;
     
CURSOR c_meta(p_contractId IN WIP_INTERESTED_PARTIES.CONTRACT_ID%TYPE) IS
   SELECT  
IDN.CONTRACT_ID,  
IDN.IDENTITY_OR_TAXNO,  
IDN.PARTNER_TYPE,  
COMP.COMPANY_CODE  
FROM  
(SELECT  
  A.CONTRACT_ID,  
  NVL(C.IDENTITY_NO, C.TAX_NUMBER) AS IDENTITY_OR_TAXNO,  
  CASE WHEN C.PARTNER_TYPE = 'P' THEN 'I' ELSE C.PARTNER_TYPE END AS PARTNER_TYPE  
  FROM WIP_INTERESTED_PARTIES A, WIP_IP_LINKS B, KOC_CP_V_HLTH_PARTNERS C  
  WHERE A.CONTRACT_ID = B.CONTRACT_ID
  AND A.IP_NO = B.IP_NO  
  AND A.PARTNER_ID = C.PART_ID  
  AND B.ROLE_TYPE = 'PH'
  AND B.ACTION_CODE <> 'D'
  --AND B.TOP_INDICATOR = 'Y'
  AND C.FROM_DATE <= SYSDATE
    AND C.END_DATE >= SYSDATE
    AND A.CONTRACT_ID = p_contractId
      UNION
    SELECT
    A.CONTRACT_ID,  
  NVL(C.IDENTITY_NO, C.TAX_NUMBER) AS IDENTITY_OR_TAXNO,  
  CASE WHEN C.PARTNER_TYPE = 'P' THEN 'I' ELSE C.PARTNER_TYPE END AS PARTNER_TYPE  
  FROM OCP_INTERESTED_PARTIES A, OCP_IP_LINKS B, KOC_CP_V_HLTH_PARTNERS C  
  WHERE A.CONTRACT_ID = B.CONTRACT_ID
  AND A.IP_NO = B.IP_NO  
  AND A.PARTNER_ID = C.PART_ID  
  AND B.ROLE_TYPE = 'PH'
  AND B.ACTION_CODE <> 'D'
  AND B.TOP_INDICATOR = 'Y'
  AND C.FROM_DATE <= SYSDATE
    AND C.END_DATE >= SYSDATE
    AND A.CONTRACT_ID = p_contractId
) IDN  
INNER JOIN (  
  SELECT CONTRACT_ID, COMPANY_CODE FROM WIP_KOC_OCP_POL_CONTRACTS_EXT  
  WHERE CONTRACT_ID = p_contractId
    UNION  
  SELECT CONTRACT_ID, COMPANY_CODE FROM KOC_OCP_POL_CONTRACTS_EXT  
  WHERE CONTRACT_ID = p_contractId
) COMP  
ON IDN.CONTRACT_ID = COMP.CONTRACT_ID;
   v_is_valid BOOLEAN := TRUE;
BEGIN

    select source_id 
    into v_source_id
    from ALZ_DMS_SOURCE_DEF 
    where source_username = 'WAZNETHLTH';

  FOR r_main IN c_main LOOP   
      IF INSTR(r_main.DOCUMENT_NAME,'.') = 0 THEN
         v_err_msg := 'Content Type Not Defined. Document_Name : '||r_main.DOCUMENT_NAME||' - Document_Id : '||r_main.DOCUMENT_ID;
         v_is_valid := FALSE;         
      END IF;  
      IF LENGTH(r_main.DOCUMENT_NAME) >= 100 THEN
         v_err_msg := 'Document Name Is Too Long. Document_Name : '||r_main.DOCUMENT_NAME||' - Document_Id : '||r_main.DOCUMENT_ID;
         v_is_valid := FALSE;   
      END IF;
      v_mime_type := UPPER(SUBSTR(r_main.DOCUMENT_NAME,INSTR(r_main.DOCUMENT_NAME,'.',-1)+1));
      IF v_is_valid THEN
          INSERT INTO ALZ_PROD_DOCS(OBJECT_ID,
                                    CONTRACT_ID,
                                    DOCUMENT_GROUP_ID,
                                    DOC_CODE,
                                    IS_ORIGINAL,
                                    EXPLANATION,
                                    CREATED_BY,
                                    CREATE_DATE,                         
                                    OLD_DOC_ID)
                 VALUES(r_main.OBJECT_ID,
                        r_main.CONTRACT_ID,
                        r_main.DOCUMENT_GROUP_ID,
                        r_main.DOCUMENT_TYPE,
                        r_main.IS_ORIGINAL,
                        r_main.EXPLANATION,
                        r_main.CREATED_BY,
                        r_main.CREATE_DATE,                         
                        r_main.DOCUMENT_ID); 
            --DBMS_OUTPUT.PUT_LINE('contract_id='||r_main.CONTRACT_ID||' Object_Id:'||r_main.OBJECT_ID);            
            FOR r_meta IN c_meta(r_main.CONTRACT_ID) LOOP
               
                INSERT INTO ALZ_DOC_INFOS(OBJECT_ID,
                                          IDENTITY_NO,
                                          IDENTITY_TYPE,
                                          DOC_CODE,
                                          DOC_SOURCE_ID,                                     
                                          IS_MASAK,                                     
                                          COMM_ID,                                    
                                          STMT_ID,                                      
                                          IS_RECOVERY,                                      
                                          FILE_NAME,
                                          MIME_TYPE,
                                          CREATE_DATE,                                      
                                          RECOVERY_TRY_COUNT,
                                          DMS_DOC_CODE)
                VALUES(r_main.OBJECT_ID,
                       r_meta.IDENTITY_OR_TAXNO,
                       r_meta.PARTNER_TYPE,
                       r_main.DOCUMENT_TYPE,   -- 1 ve 0 durumunda de�i�ecek. 
                       v_source_id,
                       0,
                       0,
                       0,
                       0,
                       r_main.DOCUMENT_NAME,
                       v_mime_type,
                       SYSTIMESTAMP,
                       0,
                       r_main.DOCUMENT_TYPE); -- 1 ve 0 durumunda de�i�ecek.
               
             
            SELECT ATTACHMENT 
              INTO v_Binary_Data
              FROM ALZ_DOCUMENTS 
             WHERE document_id = r_main.DOCUMENT_ID;

             INSERT INTO ALZ_DOC_RECOVERY(OBJECT_ID,
                                          UPLOAD_DATE,
                                          UPLOAD_HOST,                                         
                                          BINARY_DATA,
                                          STATUS,  -- ba�lacak
                                          TRY_COUNT,
                                          MIME_TYPE,
                                          FILE_NAME,                                         
                                          IMPL_CLASS,                                        
                                          TPA_COMPANY_CODE)
                    VALUES(r_main.OBJECT_ID,
                           SYSTIMESTAMP,
                           '287avcw10dvp',                                         
                            v_Binary_Data,
                            'FILENET_ERROR',
                            1,
                            v_mime_type,
                            r_main.DOCUMENT_NAME,                                         
                            'com.allianz.filenet.impl.FilenetProcessHealthProdImpl',                                        
                            r_meta.COMPANY_CODE);                                          
            
            END LOOP;    
               
        UPDATE ALZ_FN_MIG_CONTRACTS 
           SET MIG_STATUS = 'DONE'
         WHERE ROWID = r_main.ROW_ID;
         
       ELSE 
               
           UPDATE ALZ_FN_MIG_CONTRACTS 
             SET MIG_STATUS = 'FAIL',
                 ERROR_DESC = v_err_msg
           WHERE ROWID = r_main.ROW_ID;
           v_is_valid := TRUE;
           v_err_msg := '';
        END IF;
        IF MOD(v_count, v_commit) = 0 THEN 
           COMMIT;
        END IF;
        v_count := v_count +1;          
   END LOOP;
   COMMIT;
   DBMS_OUTPUT.PUT_LINE(v_count||' adet kay�t insert edildi');
EXCEPTION
WHEN OTHERS THEN
     v_err_msg := SQLERRM;
     DBMS_OUTPUT.PUT_LINE('Hata:'||SUBSTR(v_err_msg,1,200));
     ROLLBACK;   
END;              
  
         
         

