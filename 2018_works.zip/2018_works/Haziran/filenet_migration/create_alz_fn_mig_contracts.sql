create table ALZ_FN_MIG_CONTRACTS
(
  contract_id         NUMBER(10),
  src_type            CHAR(3),
  document_id         NUMBER(10),
  document_name       VARCHAR2(255),
  document_type       NUMBER(1),
  explanation         VARCHAR2(500),
  validity_start_date DATE,
  validity_end_date   DATE,
  create_date         DATE,
  created_by          VARCHAR2(30),
  document_group_id   NUMBER,
  content_type        VARCHAR2(100),
  is_original         NUMBER(1),
  mig_status          CHAR(4),
  error_desc          VARCHAR2(4000),
  sira_no             NUMBER
)
/
ALTER TABLE ALZ_FN_MIG_CONTRACTS ADD (
  CONSTRAINT ALZ_FN_MIG_CONTRACTS_PK
  PRIMARY KEY
  (CONTRACT_ID, DOCUMENT_ID)
  ENABLE VALIDATE)
/
CREATE INDEX ALZ_FN_MIG_CONTRACTS_IX1 ON ALZ_FN_MIG_CONTRACTS(MIG_STATUS)
/
  CREATE INDEX ALZ_FN_MIG_CONTRACTS_IX2 ON ALZ_FN_MIG_CONTRACTS(SIRA_NO)
/
CREATE PUBLIC SYNONYM ALZ_FN_MIG_CONTRACTS FOR CUSTOMER.ALZ_FN_MIG_CONTRACTS
/ 
grant select, insert, update, delete on ALZ_FN_MIG_CONTRACTS to PUBLIC
/
