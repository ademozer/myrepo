DECLARE 
    v_errnum  NUMBER (5);

  v_Response_Rec                 Customer.euromsg_mail_response_table := Customer.EuroMsg_Mail_Response_Table();
    v_Process_Results              Customer.process_result_table;
  v_Sms_Input                    Customer.EuroMsg_Sms_Input_Rec;
    v_Sms_Message_Type             NUMBER := 1;
    v_Parameter_Map                Customer.EuroMsg_Mail_Parameter_Table := Customer.EuroMsg_Mail_Parameter_Table();
    v_Sms_Result                   VARCHAR2(1000);
    v_Sms_Response                 VARCHAR2(1000);
    v_Payload                      CLOB;
    v_msg     VARCHAR2 (5000);
    v_request VARCHAR2 (4000);
    v_response VARCHAR2 (4000);
  
  BEGIN
  
  --[ademo
  v_errnum := 1;
  v_Parameter_Map.Extend;
    v_Parameter_Map(v_Parameter_Map.Count) := euromsg_mail_parameter_rec ('EM_SMS_OTHER', 'true'); --allclubdan g�nderim i�in
    v_errnum := 2;
   /* v_Sms_Input :=  Customer.EuroMsg_Sms_Input_Rec(p_gsm,
                                                   p_message_body,
                                                   p_company_code,
                                                   'ALZ_TOBB_USER_'||p_gsm,
                                                   v_Parameter_Map);
    v_errnum := 3;
    v_request := Alz_Euromsg_Utils.Convert_Sms_Input_To_Payload(v_Sms_Input);
    v_errnum := 4;*/
    --v_Payload := '{"smsBody":"De�erli Acentemiz ADEM �ZER kullan�c�s�n�n ALLCLUB sistemine giri� i�in kullan�c� ad� WFIBA9098_60134 ve �ifresi kwAu85SMM olu�turulmu�tur. ALLCLUB sistemine giri� yapabilirsiniz. https://acente.allclub.com.tr/AgencyWebPortal/menu/containerInner.jsp","gsmNo":"905423547375","companyCode":"045","clientKey":"ALZ_TOBB_USER_905423547375","parameterMap":{"EM_SMS_OTHER":"false"}}';
   v_Payload := '{"smsBody":"deneme","gsmNo":"905423547375","companyCode":"045","clientKey":"ALZ_TOBB_USER_905423547375","parameterMap":{"EM_SMS_OTHER":"false"}}';
    Alz_Euromsg_Utils.Send_Sms(v_Sms_Input,
                               v_Sms_Message_Type,
                               USER,
                               v_Response_Rec,
                               v_Process_Results);
    v_errnum := 5;
    v_sms_result := '1';
    FOR rec IN (SELECT Hata_Code,Response_Name, Response_Value FROM TABLE(v_Response_Rec)) LOOP
        dbms_output.put_line(rec.Hata_Code||'-'||rec.Response_Name||'-'||rec.Response_Value);
        IF rec.Hata_Code = '200'
        AND rec.Response_Name = 'code' THEN
            v_sms_result := rec.Response_Value;
        END IF;
        IF rec.Response_Name = 'message' THEN
            v_sms_response := SUBSTR(rec.Response_Value,1,30);
        END IF;
    END LOOP;
  v_errNum := 6;
  v_response := v_sms_result || '-' || v_sms_response;
   dbms_output.put_line(v_response);
  --end if;--TPA2 Serdal 2017-12-05 --AliSakalli TPA-FAZ3 TPA_104 - 15.02.2018
  EXCEPTION
    WHEN OTHERS THEN
      dbms_output.put_line('Hata:'||SQLERRM);
     
  END ;
