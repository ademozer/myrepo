select p.process_code_main
         , p.process_code_sub1
         , p.process_code_sub2
        from koc_cc_hlth_tda_proc_list p
       where p.sut_code = '614380'
         and not exists (select 1
                 from koc_cc_hlth_tda_proc_list_hie
                where parent_process_code_main = p.process_code_main
                  and parent_process_code_sub1 = p.process_code_sub1
                  and child_process_code_sub2  = p.process_code_sub2
                  and validity_start_date <= trunc(sysdate)
                  and (validity_end_date is null or validity_end_date >= trunc(sysdate)))
         and p.validity_start_date <= trunc(sysdate)
         and (p.validity_end_date is null or p.validity_end_date >= trunc(sysdate));
         
         
               select * from koc_cc_hlth_tda_proc_list_hie
                where 1=1 /*parent_process_code_main = 92
                  and parent_process_code_sub1 = 70
                  and parent_process_code_sub2 = 439*/
                  --and --child_process_code_sub2  = 503
                  and validity_start_date <= trunc(sysdate)
                  and (validity_end_date is null or validity_end_date >= trunc(sysdate))
               order by 1,2,3
                  
                  
                SELECT COUNT(1)
                    --  INTO v_Sutcount
                      FROM Koc_Cc_Hlth_Tda_Proc_List L1
                   WHERE L1.Sut_Code = (SELECT DISTINCT Sut_Code
                                          FROM Koc_Cc_Hlth_Tda_Proc_List L2
                                         WHERE Process_Code_Main = 92
                                           AND Process_Code_Sub1 = 70
                                           AND Process_Code_Sub2 = 439
                                           AND L2.Validity_Start_Date <= Trunc(SYSDATE)
                                           AND (L2.Validity_End_Date IS NULL OR L2.Validity_End_Date >= Trunc(SYSDATE)))
                       AND L1.Validity_Start_Date <= Trunc(SYSDATE)
                       AND (L1.Validity_End_Date IS NULL OR L1.Validity_End_Date >= Trunc(SYSDATE))
                       AND NOT EXISTS ( -- ademo 23.02.2017
                                  SELECT 1
                                      FROM Koc_Cc_Hlth_Tda_Proc_List_Hie h
                                   WHERE h.Parent_Process_Code_Main = L1.Process_Code_Main
                                       AND h.Parent_Process_Code_Sub1 = L1.Process_Code_Sub1
                                       AND h.Child_Process_Code_Sub2 = L1.Process_Code_Sub2
                                       AND Nvl(h.Validity_Start_Date, Trunc(SYSDATE)) <= Trunc(SYSDATE)
                                       AND Nvl(h.Validity_End_Date, Trunc(SYSDATE)) >= Trunc(SYSDATE));
                                       
                                       
                                       select internal_account_id 
     from koc_acc_v_internal_accounts 
    ---where gl_acct_ref_code ='10210010000002';
    where gl_acct_ref_code = '1200310002' ;
                  
                  
         
