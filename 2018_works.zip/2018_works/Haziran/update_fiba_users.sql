BEGIN
    delete koc_dmt_agency_tech_emp 
     where agent_int_id=73225 
       and identity_no='20705406150'
       and validity_end_date IS NOT NULL;
                           
    update web_sec_system_users 
       set end_date = NULL
     where user_name='WFIBA6150_60149';
    COMMIT;
END;
/    
