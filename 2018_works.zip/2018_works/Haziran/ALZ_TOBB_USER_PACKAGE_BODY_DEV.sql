
  CREATE OR REPLACE PACKAGE BODY "CUSTOMER"."ALZ_TOBB_USER" 
IS
    v_DapMerkezProfile CF_USERPROFILE.PROFILE_ID%TYPE := 'DAPMERKEZ';
    v_TpaAcenteProfile CF_USERPROFILE.PROFILE_ID%TYPE := 'TPAAcente';
    v_TpaMerkezProfile CF_USERPROFILE.PROFILE_ID%TYPE := 'TPAMerkez';
    v_AgencyBesProfile CF_USERPROFILE.PROFILE_ID%TYPE := 'AcenyBesProfile';
    v_AgencyTrafficProfile CF_USERPROFILE.PROFILE_ID%TYPE := 'AcenyTrafficProfile';
    v_tobb_user_name CF_ROLE_CHANGE_HISTORY.USER_NAME%TYPE := 'TobbUser';
  -- user create proc'de partner_id olusturken hatali kayitlar alz_error_log_table
  -- Bu pakette hatalar ALZ_TOBB_USER_ERROR
  -- Ba�ar�l� mail sms kay�tlar� ALZ_TOBB_USER_HIST
  PROCEDURE createusername (p_user_name OUT VARCHAR2, p_opus_user_name OUT VARCHAR2, p_tckn VARCHAR2
  , p_acentekod VARCHAR2, p_company_code VARCHAR2)
  IS --ENGINT
    v_tckn    VARCHAR2 (20);
    --v_acentekod varchar2(30);
    v_username VARCHAR (30);
    v_username_control VARCHAR (30);
    v_acente_kod_cont VARCHAR2 (100);
    v_counter NUMBER;
    v_errnum  NUMBER (5);
    v_user_prefix VARCHAR2 (10);
  BEGIN
    v_errnum := 1;
    v_tckn := SUBSTR (p_tckn, 8);

    --ENGINT TPA UPDATE
    IF p_company_code = '045' THEN
      v_username := 'WDA' || v_tckn || '_' || p_acentekod;
    ELSE
      BEGIN
        SELECT NVL (c.user_prefix, company_code)
          INTO v_user_prefix
          FROM alz_tpa_companies c
         WHERE company_code = p_company_code;
      EXCEPTION
        WHEN OTHERS THEN
          v_user_prefix := p_company_code;
      END;
      v_username := 'W' || v_user_prefix || v_tckn || '_' || p_acentekod;
    END IF;

    --
    BEGIN
      SELECT a.user_name
           , d.reference_code
        INTO v_username_control
           , v_acente_kod_cont
        FROM web_sec_system_users a
           , cp_partners b
           , koc_cp_partners_ext c
           , dmt_agents d
           , koc_dmt_agents_ext e
       WHERE a.customer_partner_id = b.part_id
         AND b.part_id = c.part_id
         AND c.agen_int_id = d.int_id
         AND d.int_id = e.int_id
         --AND c.agen_int_id = p_acentekod
         AND c.IDENTITY_NO <> p_tckn
         AND a.user_name = v_username;
    EXCEPTION
      WHEN OTHERS THEN
        v_username_control := NULL;
        v_acente_kod_cont := NULL;
    END;
    v_errnum := 2;

    IF (v_username_control IS NOT NULL AND v_acente_kod_cont IS NOT NULL) THEN
      v_errnum := 3;
      BEGIN
        --WDATCKN(son 4 hane)numarat�r_acentekodu format�nda numarat�r i�in
        SELECT COUNT (*)
          INTO v_counter
          FROM web_sec_system_users a
             , cp_partners b
             , koc_cp_partners_ext c
             , dmt_agents d
             , koc_dmt_agents_ext e
         WHERE a.customer_partner_id = b.part_id
           AND b.part_id = c.part_id
           AND c.agen_int_id = d.int_id
           AND d.int_id = e.int_id
--           AND c.agen_int_id = p_acentekod
            AND a.user_name = v_username
           AND ( (p_company_code = '045' AND a.user_name LIKE 'WDA' || v_tckn || '%' || '_' || p_acentekod)
             OR  (p_company_code <> '045' AND a.user_name LIKE 'W' || v_user_prefix || v_tckn || '%' || '_' || p_acentekod) -- ENGINT
                                                                                                                           );
      EXCEPTION
        WHEN OTHERS THEN
          v_counter := NULL;
      END;

      --
      IF p_company_code = '045' THEN --ENGINT
        p_user_name := 'WDA' || v_tckn || v_counter || '_' || p_acentekod;
        p_opus_user_name := 'DA' || v_tckn || v_counter || '_' || p_acentekod;
      ELSE
        p_user_name := 'W' || v_user_prefix || v_tckn || v_counter || '_' || p_acentekod;
        p_opus_user_name := v_user_prefix || v_tckn || v_counter || '_' || p_acentekod;
      END IF;
    ELSE
      v_errnum := 4;

      IF p_company_code = '045' THEN --ENGINT
        p_user_name := 'WDA' || v_tckn || '_' || p_acentekod;
        p_opus_user_name := 'DA' || v_tckn || '_' || p_acentekod;
      ELSE
        p_user_name := 'W' || v_user_prefix || v_tckn || '_' || p_acentekod;
        p_opus_user_name := v_user_prefix || v_tckn || '_' || p_acentekod;
      END IF;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;
  --
  PROCEDURE createusermain(p_Merkez VarChar2:='H')--TPA2 Serdalt
  IS
    v_new_user_name VARCHAR2 (30);
    v_opus_user_name VARCHAR2 (30);
    v_reference_code VARCHAR (15);
    v_salesperson_emp_id VARCHAR (100) := NULL;
    v_yet_cont NUMBER;
    v_refcur  alz_web_user_utils.refcur;
    v_process_results customer.process_result_table;
    v_carray  customer.char_array;
    i         NUMBER := 0;
    v_ayk     NUMBER;
    vc_reference_code VARCHAR2 (200);
    v_new_password VARCHAR2 (100);
    v_user_control NUMBER;
    v_yeni_tp_sms VARCHAR2 (1000);
    v_yeni_tp_email VARCHAR2 (1000);
    v_sms_mail_tckn VARCHAR2 (100);
    v_sms_mail_gsm VARCHAR2 (100);
    v_sms_mail_email VARCHAR2 (100);
    v_yetki   VARCHAR2 (30);
    v_tahsilat_yetki VARCHAR2 (30);
    v_ornek_user_name VARCHAR2 (30);
    v_errnum  NUMBER (5);
    v_errtext VARCHAR2 (4000);
    v_kl      alz_tobb_user.kisi_liste_type;
    p_message VARCHAR2 (32467);
    v_bes_ctrl NUMBER;
    v_trafik_ctrl NUMBER;
    --Orhan Polat
    v_user_in_idm   BOOLEAN := false;
    v_carray_profile  customer.char_array;

    --Web user yarat�lacak teknik personel listesi
    CURSOR c_tp
    IS -- ENGINT
      SELECT a.agent_int_id
           , a.emp_id_no
           , a.identity_no
           , a.employee_type
           , a.employee_name
           , a.employee_surname
           , a.validity_start_date
           , a.validity_end_date
           , a.userid
           , a.process_date
           , NVL (x.company_code, '045') company_code -- Default Allianz ENGINT
        FROM koc_dmt_agency_tech_emp a
           , koc_dmt_agents_ext x
       WHERE TRUNC (a.process_date) = TRUNC (SYSDATE) -- Engint Neden Process gece 12 de mi cal�s�yor ??
         AND (a.validity_end_date IS NULL OR a.validity_end_date > TRUNC (SYSDATE))
         AND ((p_Merkez='H' and x.signboard_no IS NOT NULL) or (p_Merkez='E' AND x.signboard_no IS NULL))--TPA2 Serdal
         AND x.int_id = a.agent_int_id
         AND ( (NVL (x.company_code, '045') = '045' AND x.mis_sub_group IN ('11', '12', '14', '61', '62', '63', '140'))
           OR  (NVL (x.company_code, '045') <> '045'
            AND EXISTS
                  (SELECT 1
                     FROM alz_tpa_company_mis_rel cmr
                    WHERE NVL (x.company_code, '045') = cmr.company_code
                      AND x.mis_main_group = cmr.mis_main_group
                      AND x.mis_sub_group = cmr.mis_sub_group
                      AND cmr.agent_type = 'AGENT'
                      AND SYSDATE BETWEEN TRUNC (cmr.validity_start_date) AND NVL (cmr.validity_end_date, SYSDATE + 1))));

    --
    CURSOR cr_ayk
    IS
      SELECT DISTINCT int_id
                    , tckn
        FROM koc_dmt_agents_ext_hist
       WHERE tckn IS NOT NULL
         AND (process_flag = 'I' OR (process_flag = 'U' AND updated_date = TRUNC (SYSDATE)))
         AND TRUNC (process_date) = TRUNC (SYSDATE)
         AND 1 = 2;

    --acente yetkili ki�isi i�in user olu�turulmayacak karar� al�nd�.
    --Sonraki bir zamanda bu karar de�i�irse diye bu k�sm� kald�rm�yoruz 1=2 ko�ulu koyuyoruz
    CURSOR c_role (
      p_int_id NUMBER
    , p_user_name VARCHAR2)
    IS
      SELECT DISTINCT role_code
        FROM koc_auth_user_role_rel
       WHERE username = p_user_name
         AND role_code NOT IN ('DAPMERKEZ', 'WPPPAGENT')
         AND (validity_end_date IS NULL OR TRUNC (validity_end_date) > TRUNC (SYSDATE));

    --DAPMERKEZ rol� belli employee type kullan�c�lar�na insert den sonra ayr�ca veriliyor
    --BES yetkisi WPPPAGENT rolu ile verilir, ekrandan kontrol le verilmesi gerekti�inden acente yetkili ki�i �zerinden kontrol ile kod i�inde veriliyor
    CURSOR c_yetki (p_int_id NUMBER)
    IS
      SELECT DISTINCT koc_dmt_utils.dmt_company_type (ext.int_id) --yetki
                    , NVL (ext.collection_authority, '9999999999') --tahsilat yetki
        FROM koc_dmt_agents_ext ext
       WHERE ext.int_id = p_int_id;

    --Acentenin yetkisine g�re bize verilen �rnek user rolleri al�yoruz.
    CURSOR c_ornek_user (p_yetki VARCHAR2, p_tahsilat_yetki VARCHAR2)
    IS
      SELECT a.acente_user_name
        FROM alz_tobb_ornek_userrole a
       WHERE a.yetki_kod = p_yetki AND a.tahsilat_yetki = DECODE (p_tahsilat_yetki,  'SADECE KK', 'KK1',  'SADECE KK2', 'KK2',  'A��k'); --mail d�n���ne g�re de�i�tirilecek
    --Acente �rnek kullan�c�s�na tan�ml� profiller al�n�yor.
    CURSOR c_user_profiles(p_userName VARCHAR2)
    IS
       SELECT UP.PROFILE_ID
         FROM CF_USERPROFILE UP, CF_AUTHPROFILE AP
        WHERE UP.USER_NAME = p_userName
          AND UP.PROFILE_ID = AP.PROFILE_ID
          AND AP.ISACTIVE = 'Y'
          AND (AP.VALIDENDDATE IS NULL OR TRUNC(AP.VALIDENDDATE) >= TRUNC(SYSDATE))
          AND UP.VALIDITY_END_DATE IS NULL;
  BEGIN
    v_errnum := 1;

    -- user name alan�na v_new_user_name'i g�nderece�iz
    -- G�nl�k TP listesi
    FOR cr IN c_tp LOOP
      BEGIN
        v_errnum := 2;
        v_bes_ctrl := NULL;
        v_trafik_ctrl :=NULL;
        --7.T�m bu i�lemler acente yetkilisi bilgisinin dolu oldu�u acenteler �zerinden yap�lacakt�r.
        --Acente yetkili bilgisi dolumu kontrolu yap�yoruz
        BEGIN
          SELECT COUNT (*)
            INTO v_yet_cont
            FROM koc_dmt_agents_ext
           WHERE int_id = cr.agent_int_id;
        EXCEPTION
          WHEN OTHERS THEN
            v_yet_cont := 0;
        END;
        v_errnum := 3;

        IF v_yet_cont <> 0 THEN --Acente yetkili bilgisi dolumu kontrolu yap�yoruz
          v_errnum := 4;

          --userdan role gidebilmek i�in yetki ve tahsilat yetki bilgilerini al�yoruz
          OPEN c_yetki (cr.agent_int_id);
          FETCH c_yetki
          INTO v_yetki, v_tahsilat_yetki;
          CLOSE c_yetki;

          --�rnek user_name'i al�yoruz
          OPEN c_ornek_user (v_yetki, v_tahsilat_yetki);
          FETCH c_ornek_user INTO v_ornek_user_name;
          CLOSE c_ornek_user;

          -- User� olu�turulan TP'in acente �zerinden/�rnek user �zerinden role al�n�p,olu�turulan user'a at�l�yor
          v_carray := customer.char_array (); -- Initiliazing
          v_carray_profile :=  customer.char_array();

          FOR cr_role IN c_role (cr.agent_int_id, v_ornek_user_name) LOOP
            BEGIN
              v_errnum := 5;
              v_carray.EXTEND;
              v_carray (v_carray.LAST) := cr_role.role_code;
            END;
          END LOOP;

          --
          IF cr.company_code <> '045' THEN
            v_carray.EXTEND;
            v_carray (v_carray.LAST) := 'SAGENT';
            v_user_in_idm :=  CF_IDM_AUTHORIZATION.CHECK_IDM_SWITCH(v_ornek_user_name);
            if p_Merkez<>'E' Then--TPA2 Serdal
               v_carray.EXTEND;
               v_carray (v_carray.LAST) := 'WTPAAGENT';
               IF v_user_in_idm THEN
                  v_carray_profile.Extend;
                  v_carray_profile(v_carray_profile.Last) := v_TpaAcenteProfile;
               END IF;
            ELSE
               IF v_user_in_idm THEN
                  v_carray_profile.Extend;
                  v_carray_profile(v_carray_profile.Last) := v_TpaMerkezProfile;
               END IF;
            end if;
            v_carray.EXTEND;
            v_carray (v_carray.LAST) := 'WLOGIN';--TPA2 Serdal
          END IF;

          --
          v_errnum := 6;
          --
          BEGIN
            SELECT DISTINCT reference_code
              INTO v_reference_code
              FROM dmt_agents
             WHERE int_id = cr.agent_int_id;
          EXCEPTION
            WHEN OTHERS THEN
              v_reference_code := NULL;
          END;
          --burada mail-sms de ayk isim soyisim alabilmek i�in kullan�yoruz

          BEGIN
            v_errnum := 6.0;
            alz_tobb_user.bireysorgubytckimlikno (v_reference_code, cr.identity_no, v_kl
                                                , p_message);
          --  dbms_output.put_line(v_kl(1).adi||v_kl(1).soyadi||' and '|| p_Message);
        --[ademo
        IF p_message IS NOT NULL THEN
          Raise_Application_Error(-20200, p_message);
      END IF;
      --ademo]
          EXCEPTION
            WHEN OTHERS THEN  --ademo
              v_errnum := 6.01;
              v_errtext := SUBSTR ('BireySorguByTcKimlikNo - ' || SQLERRM, 1, 4000);

              INSERT INTO alz_tobb_user_error (
                            agent_int_id
                          , identity_no
                          , v_errnum
                          , err_text
                          , creation_date)
                   VALUES (cr.agent_int_id
                         , cr.identity_no
                         , v_errnum
                         , v_errtext
                         , TRUNC (SYSDATE));
          END;

          v_errnum := 7;
          BEGIN
            SELECT DISTINCT reference_code
              INTO vc_reference_code
              FROM dmt_agents
             WHERE int_id = (SELECT DISTINCT parent_agent_int_id
                               FROM koc_dmt_agents_ext
                              WHERE int_id = cr.agent_int_id);
          EXCEPTION
            WHEN OTHERS THEN
              vc_reference_code := 'X';

              INSERT INTO alz_tobb_user_error (
                            agent_int_id
                          , identity_no
                          , v_errnum
                          , err_text
                          , creation_date)
                   VALUES (cr.agent_int_id
                         , cr.identity_no
                         , v_errnum
                         , 'User olusturulmadan �nce Partaj Bulunamad�.'
                         , SYSDATE);
          END;
          alz_tobb_user.createusername (v_new_user_name, v_opus_user_name, cr.identity_no
                                      , vc_reference_code, cr.company_code); --ENGINT
          v_errnum := 8;
          alz_web_user_utils.createnewwebuser2 (p_opus_user_name => v_opus_user_name, p_user_name => v_new_user_name, p_email => NULL
                                              , p_partner_id => 0, p_name => cr.employee_name, p_surname => cr.employee_surname
                                              , p_tax_number => NULL, p_user_type => 0, p_reference_code => v_reference_code
                                              , p_insert_user_name => v_tobb_user_name, p_role_table => v_carray, p_hsbc_registry_no => NULL
                                              , p_tck_no => cr.identity_no, p_result_cur => v_refcur, p_process_results => v_process_results
                                              , p_tech_staff => '1', p_bgd_user => '0', p_call_center => '0'
                                              , p_father_name => NULL, p_mother_name => NULL, p_addresse => NULL
                                              , p_birth_place => NULL, p_marital_status => NULL, p_passport_number => NULL
                                              , p_employee_id => NULL, p_mobile_phone => NULL, p_domain_user_name => NULL
                                              , p_company_code => cr.company_code);

          IF cr.company_code = '045' THEN
            -- IDM'de ise profil bilgisi alinacak *Orhan Polat*
            IF v_user_in_idm THEN
                BEGIN
                  FOR cr_profile IN c_user_profiles (v_ornek_user_name) LOOP
                     BEGIN
                        v_errnum := 16;
                        v_carray_profile.EXTEND;
                        v_carray_profile (v_carray_profile.LAST) := cr_profile.profile_id;
                     END;
                  END LOOP;
                EXCEPTION WHEN OTHERS THEN
                   INSERT INTO alz_tobb_user_error (
                               agent_int_id
                             , identity_no
                             , v_errnum
                             , err_text
                             , creation_date)
                       VALUES (cr.agent_int_id
                             , cr.identity_no
                             , v_errnum
                             , 'User Profil Bilgisi bulunurken Hata'
                             , SYSDATE);
                END;
            END IF;

            IF (cr.employee_type IN ('1', '2', '4', '8', '9', '11')) THEN
                IF v_user_in_idm THEN
                    v_carray_profile.Extend;
                    v_carray_profile(v_carray_profile.LAST) := v_DapMerkezProfile;
                END IF;
                INSERT INTO koc_auth_user_role_rel (
                              username
                            , role_code
                            , validity_start_date)
                     VALUES (v_new_user_name
                           , 'DAPMERKEZ'
                           , TRUNC (SYSDATE) - 3);
                ALZ_WEB_USER_UTILS.log_user_role_history(p_user_name       => v_new_user_name,
                              p_role_code       => 'DAPMERKEZ',
                              p_action_type     => 'I',
                              p_update_user     => v_tobb_user_name,
                              p_process_results => v_process_results);
            END IF;

            --user olusurken hatalar select * from alz_error_log_table tablosunda tutuluyor
            --Bes yetkisi kontrol edilip,bes rolu verilecek
            --Trafik rolu kontrol edilip, trafik rolu verilecek
            BEGIN
              SELECT DISTINCT a.is_bes_authority,a.AGENCY_MENU_TYPE
                INTO v_bes_ctrl,v_trafik_ctrl
                FROM koc_dmt_agents_ext a
               WHERE a.int_id = cr.agent_int_id;
            EXCEPTION
              WHEN OTHERS THEN
                v_bes_ctrl := 0;
                v_trafik_ctrl :=0;
            END;

            IF (v_bes_ctrl = 1) THEN
              BEGIN
                IF v_user_in_idm THEN
                   v_carray_profile.Extend;
                   v_carray_profile(v_carray_profile.LAST) := v_AgencyBesProfile;
                END IF;
                INSERT INTO koc_auth_user_role_rel (
                              username
                            , role_code
                            , validity_start_date)
                     VALUES (v_new_user_name
                           , 'WPPPAGENT'
                           , TRUNC (SYSDATE) - 3);
                 ALZ_WEB_USER_UTILS.log_user_role_history(p_user_name       => v_new_user_name,
                              p_role_code       => 'WPPPAGENT',
                              p_action_type     => 'I',
                              p_update_user     => v_tobb_user_name,
                              p_process_results => v_process_results);
              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;
            END IF;

            IF (v_trafik_ctrl = 1) THEN
              BEGIN
                IF v_user_in_idm THEN
                   v_carray_profile.Extend;
                   v_carray_profile(v_carray_profile.LAST) := v_AgencyTrafficProfile;
                END IF;
                   INSERT INTO koc_auth_user_role_rel (
                               username
                             , role_code
                             , validity_start_date)
                      VALUES (v_new_user_name
                             , 'WPMTPLMADF'
                             , TRUNC (SYSDATE) - 3);
                ALZ_WEB_USER_UTILS.log_user_role_history(p_user_name       => v_new_user_name,
                              p_role_code       => 'WPMTPLMADF',
                              p_action_type     => 'I',
                              p_update_user     => v_tobb_user_name,
                              p_process_results => v_process_results);
                INSERT INTO koc_auth_user_role_rel (
                          username
                        , role_code
                        , validity_start_date)
                 VALUES (v_new_user_name
                       , 'WPTAGENTP'
                       , TRUNC (SYSDATE) - 3);
                 ALZ_WEB_USER_UTILS.log_user_role_history(p_user_name       => v_new_user_name,
                              p_role_code       => 'WPTAGENTP',
                              p_action_type     => 'I',
                              p_update_user     => v_tobb_user_name,
                              p_process_results => v_process_results);
              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;
            END IF;

            --Bes ve trafik yetkisi kontrol edilip,bes rolu verilecek
            v_errnum := 9;
            COMMIT;
          END IF;
          -- Kullan�c� profil atamas�
          CF_IDM_UTILS.ADD_USER_PROFILES(v_new_user_name,v_carray_profile,0,v_process_results);

          --user olustumu kontrolu yap�yoruz,olusan kisiler i�in mail sms g�nderiyoruz
          BEGIN
            SELECT COUNT (*)
              INTO v_user_control
              FROM web_sec_system_users
             WHERE user_name = v_new_user_name AND TRUNC (create_date) = TRUNC (SYSDATE);
          EXCEPTION
            WHEN OTHERS THEN
              v_user_control := 0;
          END;

          IF v_user_control <> 0 THEN
            --sms-mail ataca��m�z yetkili ki�i bilgileri
            BEGIN
              SELECT tckn
                   , mobile
                   , email
                INTO v_sms_mail_tckn
                   , v_sms_mail_gsm
                   , v_sms_mail_email
                FROM koc_dmt_agents_ext a
               WHERE a.int_id = cr.agent_int_id;
            EXCEPTION
              WHEN OTHERS THEN
                v_sms_mail_tckn := NULL;
                v_sms_mail_gsm := NULL;
                v_sms_mail_email := NULL;
            END;
            v_errnum := 10;
            BEGIN
              SELECT alz_web_user_security.aesdecrypt (a.user_password_aes)
                INTO v_new_password
                FROM web_sec_system_users a
               WHERE user_name = v_new_user_name;
            EXCEPTION
              WHEN OTHERS THEN
                v_new_password := NULL;
            END;

            IF v_sms_mail_tckn IS NOT NULL AND v_sms_mail_gsm IS NOT NULL THEN
              v_errnum := 11;
              --v_yeni_tp_sms := v_sms_mail_gsm||' nolu cep telefonunuza '||v_new_user_name||' kullan�c�s�n�n DIGITALL �ifresi sms olarak iletilmi�tir. '||v_new_password ||' �ifreniz ve '|| v_new_user_name||' kullan�c�s� ile DIGITALL sistemine giri� yapmak i�in t�klay�n�z. https://digitall.allianz.com.tr';
              v_yeni_tp_sms :=
                'De�erli Acentemiz ' || cr.employee_name || ' ' || cr.employee_surname ||
                ' kullan�c�s�n�n DIGITALL sistemine giri� i�in kullan�c� ad� ' || v_new_user_name || ' ve �ifresi ' || v_new_password ||
                ' olu�turulmu�tur. DIGITALL sistemine giri� yapabilirsiniz. https://digitall.allianz.com.tr';

              IF cr.company_code <> '045' THEN
                v_yeni_tp_sms :=
                  'De�erli Acentemiz ' || cr.employee_name || ' ' || cr.employee_surname ||
                  ' kullan�c�s�n�n ALLCLUB sistemine giri� i�in kullan�c� ad� ' || v_new_user_name || ' ve �ifresi ' || v_new_password ||
                  ' olu�turulmu�tur. ALLCLUB sistemine giri� yapabilirsiniz. https://acente.allclub.com.tr/AgencyWebPortal';
              END IF;

              alz_tobb_user.sendsms (v_sms_mail_gsm, v_yeni_tp_sms, cr.company_code); -- ENGINT
            ELSE
              INSERT INTO alz_tobb_user_error (
                            agent_int_id
                          , identity_no
                          , v_errnum
                          , err_text
                          , creation_date
                          , gsm
                          , process)
                   VALUES (cr.agent_int_id
                         , cr.identity_no
                         , v_errnum
                         , v_errtext
                         , TRUNC (SYSDATE)
                         , v_sms_mail_gsm
                         , 'ALZ_TOBB_USER/CreateUserMain/sendsms-gsm yada tckn bos');
            END IF;

            v_errnum := 12;

            --mail
            IF v_sms_mail_tckn IS NOT NULL AND v_sms_mail_email IS NOT NULL THEN
              v_errnum := 13;
              v_yeni_tp_email :=
                v_sms_mail_gsm || ' nolu cep telefonunuza ' || cr.employee_name || ' ' || cr.employee_surname ||
                ' kullan�c�s�n�n DIGITALL �ifresi sms olarak iletilmi�tir. ' || v_new_user_name ||
                ' kullan�c�s� ile DIGITALL sistemine giri� yapmak i�in ' || CHR(38) || 'lt;a href="https://digitall.allianz.com.tr"' || CHR(38) ||
                'gt;t�klay�n�z' || CHR(38) || 'lt;/a' || CHR(38) || 'gt;';

              IF cr.company_code <> '045' THEN
                v_yeni_tp_email :=
                  v_sms_mail_gsm || ' nolu cep telefonunuza ' || cr.employee_name || ' ' || cr.employee_surname ||
                  ' kullan�c�s�n�n ALLCLUB �ifresi sms olarak iletilmi�tir. ' || v_new_user_name ||
                  ' kullan�c�s� ile ALLCLUB sistemine giri� yapmak i�in ' || CHR(38) ||
                  'lt;a href="https://acente.allclub.com.tr/AgencyWebPortal"' || CHR(38) || 'gt;t�klay�n�z' || CHR(38) || 'lt;/a' || CHR(38) || 'gt;';
              END IF;

              alz_tobb_user.sendemail (v_sms_mail_email, v_yeni_tp_email, cr.company_code); -- ENGINT
            ELSE
              INSERT INTO alz_tobb_user_error (
                            agent_int_id
                          , identity_no
                          , v_errnum
                          , err_text
                          , creation_date
                          , email
                          , process)
                   VALUES (cr.agent_int_id
                         , cr.identity_no
                         , v_errnum
                         , v_errtext
                         , TRUNC (SYSDATE)
                         , v_sms_mail_email
                         , 'ALZ_TOBB_USER/CreateUserMain/sendmail-email yada tckn bos');

              COMMIT;
            END IF;
          END IF;

          v_errnum := 14;
        ELSE
          v_errnum := 15;
          v_errtext := 'Acente yetkili Ki�isi Tan�ml� de�ildir..';

          INSERT INTO alz_tobb_user_error (
                        agent_int_id
                      , identity_no
                      , v_errnum
                      , err_text
                      , creation_date
                      , process)
               VALUES (cr.agent_int_id
                     , cr.identity_no
                     , v_errnum
                     , v_errtext
                     , TRUNC (SYSDATE)
                     , 'ALZ_TOBB_USER/CreateUserMain');

          COMMIT;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          v_errtext := SUBSTR ('create user - ' || SQLERRM, 1, 4000);

          INSERT INTO alz_tobb_user_error (
                        agent_int_id
                      , identity_no
                      , v_errnum
                      , err_text
                      , creation_date
                      , process)
               VALUES (cr.agent_int_id
                     , cr.identity_no
                     , v_errnum
                     , v_errtext
                     , TRUNC (SYSDATE)
                     , 'ALZ_TOBB_USER/CreateUserMain');
      END;
    END LOOP;
  /* --acente yetkili ki�isi i�in user olu�turuluyor -- Cal�sm�yor Buras� EnginT
  FOR cr IN cr_ayk LOOP
    BEGIN
      v_errnum := 2.1;
      v_bes_ctrl := NULL;
      --7.T�m bu i�lemler acente yetkilisi bilgisinin dolu oldu�u acenteler �zerinden yap�lacakt�r.
      --Acente yetkili bilgisi dolumu kontrolu yap�yoruz
      BEGIN
        SELECT COUNT (*)
          INTO v_yet_cont
          FROM koc_dmt_agents_ext
         WHERE int_id = cr.int_id;
      EXCEPTION
        WHEN OTHERS THEN
          v_yet_cont := 0;
      END;
      v_errnum := 3.1;

      IF v_yet_cont <> 0 THEN --Acente yetkili bilgisi dolumu kontrolu yap�yoruz
        v_errnum := 4.1;
        --userdan role gidebilmek i�in yetki ve tahsilat yetki bilgilerini al�yoruz
        OPEN c_yetki (cr.int_id);
        FETCH c_yetki
        INTO v_yetki, v_tahsilat_yetki;
        CLOSE c_yetki;
        --�rnek user_name'i al�yoruz
        OPEN c_ornek_user (v_yetki, v_tahsilat_yetki);
        FETCH c_ornek_user INTO v_ornek_user_name;
        CLOSE c_ornek_user;
        -- User� olu�turulan AYK'nin acente �zerinden/�rnek user �zerinden role al�n�p,olu�turulan user'a at�l�yor
        v_carray := customer.char_array (); -- Initiliazing
        FOR cr_role IN c_role (cr.int_id, v_ornek_user_name) LOOP
          BEGIN
            v_errnum := 5.1;
            --i := i+1;
            v_carray.EXTEND;
            v_carray (v_carray.LAST) := cr_role.role_code;
          END;
        END LOOP;
        v_errnum := 5.2;
        BEGIN
          SELECT DISTINCT reference_code
            INTO v_reference_code
            FROM dmt_agents
           WHERE int_id = cr.int_id;
        EXCEPTION
          WHEN OTHERS THEN
            v_reference_code := NULL;
        END;
        BEGIN
          v_errnum := 6.1;
          alz_tobb_user.bireysorgubytckimlikno (v_reference_code, cr.tckn, v_kl
                                              , p_message);
        --  dbms_output.put_line(v_kl(1).adi||v_kl(1).soyadi||' and '|| p_Message);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            v_errnum := 6.2;
            v_errtext := SUBSTR ('BireySorguByTcKimlikNo - ' || SQLERRM, 1, 4000);
            INSERT INTO alz_tobb_user_error (
                          agent_int_id
                        , identity_no
                        , v_errnum
                        , err_text
                        , creation_date)
                 VALUES (cr.int_id
                       , cr.tckn
                       , v_errnum
                       , v_errtext
                       , TRUNC (SYSDATE));
        END;
        v_errnum := 6.3;
        BEGIN
          SELECT DISTINCT reference_code
            INTO vc_reference_code
            FROM dmt_agents
           WHERE int_id = (SELECT DISTINCT parent_agent_int_id
                             FROM koc_dmt_agents_ext
                            WHERE int_id = cr.int_id);
        EXCEPTION
          WHEN OTHERS THEN
            vc_reference_code := 'X';
        END;
        alz_tobb_user.createusername (v_new_user_name, v_opus_user_name, cr.tckn
                                    , vc_reference_code);
        v_errnum := 6.4;
        alz_web_user_utils.createnewwebuser2 (v_opus_user_name, --p_opus_user_name IN varchar2,
                                                               v_new_user_name, --p_user_name IN varchar2, OK
                                                                               NULL
                                            , --p_email IN varchar2,     OK
                                             0, --p_partner_id IN number,  OK
                                               v_kl (1).adi, --p_name IN varchar2,      OK
                                                            v_kl (1).soyadi
                                            , --p_surname IN varchar2,   OK
                                             NULL, --p_tax_number IN varchar2, TP oldu�u i�in null
                                                  0, --p_user_type IN number,
                                                    v_reference_code
                                            , --p_reference_code IN varchar2, OK
                                             NULL, --p_insert_user_name IN varchar2, --**bak�lacak
                                                  v_carray, --p_role_table IN customer.char_array,
                                                           NULL
                                            , --p_hsbc_registry_no IN varchar2,
                                             cr.tckn, --p_tck_no IN varchar2,
                                                      --v_salesperson_emp_id,        --user create ederken kullan�lm�yor
                                                      v_refcur, --p_result_cur OUT refcur,
                                                               v_process_results
                                            , --p_process_results IN OUT customer.process_result_table
                                             '1', '0', '0'
                                            , NULL, NULL, NULL
                                            , NULL, NULL, NULL
                                            , NULL, NULL, NULL -- LIVE'a DOMAIN_USER_NAME bu paket ile eklenecek
                                                              );
        v_errnum := 6.5;
        --e�er acente yetkili ki�isi tp tablosunda var ise DAPMERKEZ rolude verilecek
        BEGIN
          SELECT COUNT (*)
            INTO v_ayk
            FROM koc_dmt_agency_tech_emp
           WHERE identity_no = cr.tckn;
        EXCEPTION
          WHEN OTHERS THEN
            v_ayk  := 0;
        END;

        IF v_ayk <> 0 THEN
          INSERT INTO koc_auth_user_role_rel (
                        username
                      , role_code
                      , validity_start_date)
               VALUES (v_new_user_name
                     , 'DAPMERKEZ'
                     , TRUNC (SYSDATE) - 3);
        END IF;

        --Bes yetkisi kontrol edilip,bes rolu verilecek
        BEGIN
          SELECT DISTINCT a.is_bes_authority
            INTO v_bes_ctrl
            FROM koc_dmt_agents_ext a
           WHERE a.int_id = cr.int_id;
        EXCEPTION
          WHEN OTHERS THEN
            v_bes_ctrl := 0;
        END;

        IF (v_bes_ctrl = 1) THEN
          BEGIN
            INSERT INTO koc_auth_user_role_rel (
                          username
                        , role_code
                        , validity_start_date)
                 VALUES (v_new_user_name
                       , 'WPPPAGENT'
                       , TRUNC (SYSDATE) - 3);
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
        END IF;

        --Bes yetkisi kontrol edilip,bes rolu verilecek
        BEGIN
          SELECT COUNT (*)
            INTO v_user_control
            FROM web_sec_system_users
           WHERE user_name = v_new_user_name;
        EXCEPTION
          WHEN OTHERS THEN
            v_user_control := 0;
        END;

        IF v_user_control <> 0 THEN
          --sms-mail ataca��m�z yetkili ki�i bilgileri
          BEGIN
            SELECT tckn
                 , mobile
                 , email
              INTO v_sms_mail_tckn
                 , v_sms_mail_gsm
                 , v_sms_mail_email
              FROM koc_dmt_agents_ext a
             WHERE a.int_id = cr.int_id;
          EXCEPTION
            WHEN OTHERS THEN
              v_sms_mail_tckn := NULL;
              v_sms_mail_gsm := NULL;
              v_sms_mail_email := NULL;
          END;
          BEGIN
            SELECT alz_web_user_security.aesdecrypt (a.user_password_aes)
              INTO v_new_password
              FROM web_sec_system_users a
             WHERE user_name = v_new_user_name;
          EXCEPTION
            WHEN OTHERS THEN
              v_new_password := NULL;
          END;

          IF v_sms_mail_tckn IS NOT NULL AND v_sms_mail_gsm IS NOT NULL THEN
            v_errnum := 6.6;
            --v_yeni_tp_sms := v_new_password||' �ifreniz ve '||v_new_user_name||'  kullan�c� ad�n�z ile DIGITALL sistemine giri� yapabilirsiniz. https://digitall.allianz.com.tr';
            v_yeni_tp_sms :=
              'De�erli Acentemiz ' || v_kl (1).adi || ' ' || v_kl (1).soyadi ||
              ' kullan�c�s�n�n DIGITALL sistemine giri� i�in kullan�c� ad� ' || v_new_user_name || ' ve �ifresi ' || v_new_password ||
              ' olu�turulmu�tur. DIGITALL sistemine giri� yapabilirsiniz. https://digitall.allianz.com.tr';
            --'Sayin '|| v_kl(1).adi||' '||v_kl(1).soyadi||' ' ||
            --v_sms_mail_gsm||' nolu cep telefonunuza '||v_new_user_name||' kullan�c�s�n�n DIGITALL �ifresi sms olarak iletilmi�tir.'|| v_new_user_name||' kullan�c�s� ile DIGITALL sistemine giri� yapmak i�in t�klay�n�z?';
            alz_tobb_user.sendsms (v_sms_mail_gsm, v_yeni_tp_sms);
          ELSE
            INSERT INTO alz_tobb_user_error (
                          agent_int_id
                        , identity_no
                        , v_errnum
                        , err_text
                        , creation_date
                        , gsm
                        , process)
                 VALUES (cr.int_id
                       , cr.tckn
                       , v_errnum
                       , v_errtext
                       , TRUNC (SYSDATE)
                       , v_sms_mail_gsm
                       , 'ALZ_TOBB_USER/CreateUserMain/sendsms-gsm yada tckn bos');
          END IF;

          v_errnum := 6.7;

          --mail
          IF v_sms_mail_tckn IS NOT NULL AND v_sms_mail_email IS NOT NULL THEN
            --v_yeni_tp_email := 'Sayin '|| v_kl(1).adi||' '||v_kl(1).soyadi||' ' ||v_sms_mail_gsm||' nolu cep telefonunuza '||v_new_user_name||' kullan�c�s�n�n DIGITALL �ifresi sms olarak iletilmi�tir. '||v_new_user_name||' kullan�c�s� ile DIGITALL sistemine giri� yapmak i�in '||'&'||'lt;a href="https://digitall.allianz.com.tr"'||'&'||'gt;tiklayiniz'||'&'||'lt;/a'||'&'||'gt;';
            v_yeni_tp_email :=
              v_sms_mail_gsm || ' nolu cep telefonunuza ' || v_kl (1).adi || ' ' || v_kl (1).soyadi ||
              ' kullan�c�s�n�n DIGITALL �ifresi sms olarak iletilmi�tir. ' || v_new_user_name ||
              ' kullan�c�s� ile DIGITALL sistemine giri� yapmak i�in ' || '&' || 'lt;a href="https://digitall.allianz.com.tr"' || '&' ||
              'gt;tiklayiniz' || '&' || 'lt;/a' || '&' || 'gt;';
            alz_tobb_user.sendemail (v_sms_mail_email, v_yeni_tp_email);
          ELSE
            INSERT INTO alz_tobb_user_error (
                          agent_int_id
                        , identity_no
                        , v_errnum
                        , err_text
                        , creation_date
                        , email
                        , process)
                 VALUES (cr.int_id
                       , cr.tckn
                       , v_errnum
                       , v_errtext
                       , TRUNC (SYSDATE)
                       , v_sms_mail_email
                       , 'ALZ_TOBB_USER/CreateUserMain/sendmail-email yada tckn bos');
          END IF;
        END IF;
      ELSE
        v_errnum := 9;
        v_errtext := 'Acente yetkili Ki�isi Tan�ml� de�ildir..';
        INSERT INTO alz_tobb_user_error (
                      agent_int_id
                    , identity_no
                    , v_errnum
                    , err_text
                    , creation_date
                    , process)
             VALUES (cr.int_id
                   , cr.tckn
                   , v_errnum
                   , v_errtext
                   , TRUNC (SYSDATE)
                   , 'ALZ_TOBB_USER/CreateUserMain');
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        v_errtext := SUBSTR ('create user - ' || SQLERRM, 1, 4000);
        INSERT INTO alz_tobb_user_error (
                      agent_int_id
                    , identity_no
                    , v_errnum
                    , err_text
                    , creation_date
                    , process)
             VALUES (cr.int_id
                   , cr.tckn
                   , v_errnum
                   , v_errtext
                   , TRUNC (SYSDATE)
                   , 'ALZ_TOBB_USER/CreateUserMain');
    END;
  END LOOP;*/
  END;
  --
  PROCEDURE userenddatefromtplist
  IS
    --Bu procedure i�ten ��kan TP'lerin Userlar�n� kapat�r
    v_yeni_tp_sms VARCHAR2 (1000);
    v_yeni_tp_email VARCHAR2 (1000);
    v_sms_mail_tckn VARCHAR2 (100);
    v_sms_mail_gsm VARCHAR2 (100);
    v_sms_mail_email VARCHAR2 (100);
    v_errnum  NUMBER;
    v_errtext VARCHAR2 (1000);

    --��ten ��kan Teknik Personel Listesi
    CURSOR cr_tp
    IS
      SELECT *
        FROM koc_dmt_agency_tech_emp
       WHERE validity_end_date IS NOT NULL AND TRUNC (validity_end_date) = TRUNC (SYSDATE);

    --user bilgileri
    CURSOR cr_user (
      p_tckn VARCHAR2
    , p_int_id NUMBER)
    IS
      SELECT d.int_id
           , a.user_name
           , a.customer_partner_id
           , b.surname
           , b.first_name
           , c.tax_number
           , a.reference_opus_user
           , a.user_type
           , a.start_date
           , a.end_date
           , a.active
           , d.reference_code
           , NVL (ae.company_code, '045') company_code
        FROM web_sec_system_users a
           , cp_partners b
           , koc_cp_partners_ext c
           , dmt_agents d
           , koc_dmt_agency_tech_emp e
           , koc_dmt_agents_ext ae
       WHERE a.customer_partner_id = b.part_id(+)
         AND b.part_id = c.part_id(+)
         AND c.agen_int_id = d.int_id(+)
         AND d.int_id = e.agent_int_id(+)
         AND (a.end_date IS NULL OR a.end_date >= TRUNC (SYSDATE))
         AND e.identity_no = c.identity_no
         AND e.agent_int_id = p_int_id
         AND e.identity_no = p_tckn
         AND e.agent_int_id = ae.int_id;
  BEGIN
    FOR cr IN cr_tp LOOP
      BEGIN
        FOR cr1 IN cr_user (cr.identity_no, cr.agent_int_id) LOOP
          BEGIN
            IF cr1.customer_partner_id IS NOT NULL THEN
              v_errnum := 1;

              UPDATE web_sec_system_users wssu
                 SET wssu.end_date = TRUNC (SYSDATE)
               WHERE wssu.customer_partner_id = cr1.customer_partner_id;
            ELSE
              v_errnum := 2;

              UPDATE web_sec_system_users wssu
                 SET wssu.end_date = TRUNC (SYSDATE)
               WHERE wssu.user_name = cr1.user_name;
            END IF;

            --sms ataca��m�z yetkili ki�i bilgileri
            BEGIN
              SELECT tckn
                   , mobile
                   , email
                INTO v_sms_mail_tckn
                   , v_sms_mail_gsm
                   , v_sms_mail_email
                FROM koc_dmt_agents_ext a
               WHERE a.int_id = cr.agent_int_id;
            EXCEPTION
              WHEN OTHERS THEN
                v_sms_mail_tckn := NULL;
                v_sms_mail_gsm := NULL;
                v_sms_mail_email := NULL;
            END;
            v_errnum := 3;

            IF v_sms_mail_tckn IS NOT NULL AND v_sms_mail_gsm IS NOT NULL THEN
              --v_yeni_tp_sms := v_sms_mail_tckn||' TCKNli teknik personelinize ait '||cr1.user_name||' kullan�c� hesab� kapat�lm��t�r.';
              v_yeni_tp_sms :=
                cr.employee_name || ' ' || cr.employee_surname || ' kullan�c�s�n�n ' || cr1.user_name ||
                ' kullan�c� hesab� kapat�lm��t�r.';
              v_errnum := 4;
              alz_tobb_user.sendsms (v_sms_mail_gsm, v_yeni_tp_sms, cr1.company_code);
            ELSE
              v_errnum := 5;
              v_errtext := 'Acente yetkili Ki�isi Tan�ml� de�ildir..';

              INSERT INTO alz_tobb_user_error (
                            agent_int_id
                          , identity_no
                          , v_errnum
                          , err_text
                          , creation_date
                          , gsm
                          , process)
                   VALUES (cr.agent_int_id
                         , cr.identity_no
                         , v_errnum
                         , v_errtext
                         , TRUNC (SYSDATE)
                         , v_sms_mail_gsm
                         , 'ALZ_TOBB_USER/UserEndDateFromTpList/sendsms-gsm yada tckn bos');
            END IF;

            --mail
            IF v_sms_mail_tckn IS NOT NULL AND v_sms_mail_email IS NOT NULL THEN
              v_errnum := 6;
              v_yeni_tp_email := cr.identity_no || ' TCKNli teknik personelinize ait ' || cr1.user_name || ' kullan�c� hesab� kapat�lm��t�r.'; -- v_sms_mail_tckn 01122016 tckn d�zeltildi
              alz_tobb_user.sendemail (v_sms_mail_email, v_yeni_tp_email, cr1.company_code);
            ELSE
              v_errnum := 7;
              v_errtext := 'Acente yetkili Ki�isi Tan�ml� de�ildir..';

              INSERT INTO alz_tobb_user_error (
                            agent_int_id
                          , identity_no
                          , v_errnum
                          , err_text
                          , creation_date
                          , email
                          , process)
                   VALUES (cr.agent_int_id
                         , cr.identity_no
                         , v_errnum
                         , v_errtext
                         , TRUNC (SYSDATE)
                         , v_sms_mail_email
                         , 'ALZ_TOBB_USER/UserEndDateFromTpList/sendmail-email yada tckn bos');
            END IF;
          END;
        END LOOP;
      END;
    END LOOP;
  END userenddatefromtplist;
  PROCEDURE agencyenddate
  IS
    v_yeni_tp_sms VARCHAR2 (1000);
    v_yeni_tp_email VARCHAR2 (1000);
    v_sms_mail_tckn VARCHAR2 (100);
    v_sms_mail_gsm VARCHAR2 (100);
    v_sms_mail_email VARCHAR2 (100);
    v_errnum  NUMBER;
    v_errtext VARCHAR2 (1000);

    --Kapat�lan acenteler
    CURSOR c_agency
    IS
      SELECT *
        FROM dmt_agents
       WHERE end_date IS NOT NULL AND end_date = TRUNC (SYSDATE) - 1;

    --User Bilgilerini al�yoruz
    CURSOR c_user_info (p_int_id NUMBER)
    IS
      SELECT DISTINCT d.int_id
                    , a.user_name
                    , a.customer_partner_id
                    , b.surname
                    , b.first_name
                    , c.tax_number
                    , a.reference_opus_user
                    , a.user_type
                    , a.start_date
                    , a.end_date
                    , a.active
                    , d.reference_code
                    , c.identity_no
                    , NVL (e.company_code, '045') company_code
        FROM web_sec_system_users a
           , cp_partners b
           , koc_cp_partners_ext c
           , dmt_agents d
           , koc_dmt_agents_ext e
       WHERE a.customer_partner_id = b.part_id
         AND b.part_id = c.part_id
         AND c.agen_int_id = d.int_id
         AND d.int_id = e.int_id
         AND (a.end_date IS NULL OR a.end_date > TRUNC (SYSDATE))
         AND d.int_id = p_int_id;
  BEGIN
    FOR cr IN c_agency LOOP
      BEGIN
        FOR cr1 IN c_user_info (cr.int_id) LOOP
          BEGIN
            IF cr1.customer_partner_id IS NOT NULL THEN
              UPDATE web_sec_system_users wssu
                 SET wssu.end_date = TRUNC (SYSDATE)
               WHERE wssu.customer_partner_id = cr1.customer_partner_id;
            ELSE
              UPDATE web_sec_system_users wssu
                 SET wssu.end_date = TRUNC (SYSDATE)
               WHERE wssu.user_name = cr1.user_name;
            END IF;

            --sms ataca��m�z yetkili ki�i bilgileri
            BEGIN
              SELECT tckn
                   , mobile
                   , email
                INTO v_sms_mail_tckn
                   , v_sms_mail_gsm
                   , v_sms_mail_email
                FROM koc_dmt_agents_ext a
               WHERE a.int_id = cr.int_id;
            EXCEPTION
              WHEN OTHERS THEN
                v_sms_mail_tckn := NULL;
                v_sms_mail_gsm := NULL;
                v_sms_mail_email := NULL;
            END;
            v_errnum := 3;

            IF v_sms_mail_tckn IS NOT NULL AND v_sms_mail_gsm IS NOT NULL THEN
              v_yeni_tp_sms := cr1.identity_no || ' TCKNli teknik personelinize ait ' || cr1.user_name || ' kullan�c� hesab� kapat�lm��t�r.'; --v_sms_mail_tckn
              v_errnum := 4;
              alz_tobb_user.sendsms (v_sms_mail_gsm, v_yeni_tp_sms, cr1.company_code);
            ELSE
              v_errnum := 5;
              v_errtext := 'Acente yetkili Ki�isi tckn yada mobile Tan�ml� de�ildir..';

              INSERT INTO alz_tobb_user_error (
                            agent_int_id
                          , identity_no
                          , v_errnum
                          , err_text
                          , creation_date
                          , gsm
                          , process)
                   VALUES (cr.int_id
                         , v_sms_mail_tckn
                         , v_errnum
                         , v_errtext
                         , TRUNC (SYSDATE)
                         , v_sms_mail_gsm
                         , 'ALZ_TOBB_USER/AgencyEndDate/sendsms-gsm yada tckn bos');
            END IF;

            --mail
            IF v_sms_mail_tckn IS NOT NULL AND v_sms_mail_email IS NOT NULL THEN
              v_errnum := 6;
              v_yeni_tp_email := cr1.identity_no || ' TCKNli personelinize ait ' || cr1.user_name || ' kullan�c� hesab� kapat�lm��t�r.'; --v_sms_mail_tckn
              alz_tobb_user.sendemail (v_sms_mail_email, v_yeni_tp_email, cr1.company_code);
            ELSE
              v_errnum := 7;
              v_errtext := 'Acente yetkili Ki�isi tckn yada email Tan�ml� de�ildir..';

              INSERT INTO alz_tobb_user_error (
                            agent_int_id
                          , identity_no
                          , v_errnum
                          , err_text
                          , creation_date
                          , email
                          , process)
                   VALUES (cr.int_id
                         , v_sms_mail_tckn
                         , v_errnum
                         , v_errtext
                         , TRUNC (SYSDATE)
                         , v_sms_mail_email
                         , 'ALZ_TOBB_USER/AgencyEndDate/sendmail-email yada tckn bos');
            END IF;
          END;
        END LOOP;
      END;
    END LOOP;

    COMMIT;
  END;
  --
  PROCEDURE updateagencyrole -- g�n sonu �al��an batch �al���yor olmal�
  IS
    v_yetki   VARCHAR2 (30);
    v_tahsilat_yetki VARCHAR2 (30);
    v_ornek_user_name VARCHAR2 (30);
    v_bes_user VARCHAR2 (30);
    v_rol_user VARCHAR2 (30);
    v_bes_ctrl NUMBER;
    v_trafik_ctrl NUMBER;
    --Orhan Polat
    v_user_in_idm   BOOLEAN := FALSE;
    v_carray_profile  customer.char_array;
    v_process_results customer.process_result_table;
    --Acente �rnek kullan�c�s�na tan�ml� profiller al�n�yor.
    CURSOR c_user_profiles(p_userName VARCHAR2)
    IS
       SELECT UP.PROFILE_ID
         FROM CF_USERPROFILE UP, CF_AUTHPROFILE AP
        WHERE UP.USER_NAME = p_userName
          AND UP.PROFILE_ID = AP.PROFILE_ID
          AND AP.ISACTIVE = 'Y'
          AND (AP.VALIDENDDATE IS NULL OR TRUNC(AP.VALIDENDDATE) >= TRUNC(SYSDATE))
          AND UP.VALIDITY_END_DATE IS NULL;

    --Yetkileri de�i�en acenteler
    CURSOR c_update_agency
    IS
      SELECT kdc.*
           , kdae.collection_authority,kdae.company_code--TPA2 Serdalt
        FROM koc_dmt_company_type_detail kdc
           , -- yetkisi de�i�en acente
            koc_dmt_agents_ext kdae
       WHERE kdae.int_id = kdc.agent_int_id AND (kdc.validity_end_date IS NULL OR kdc.validity_end_date > TRUNC (SYSDATE))
         AND kdc.agent_int_id IN
               (SELECT kdc.agent_int_id
                  FROM koc_dmt_company_type_detail kdc
                     , -- yetkisi de�i�en acente
                      koc_dmt_agents_ext kdae
                 WHERE kdae.int_id = kdc.agent_int_id AND kdc.validity_end_date IS NOT NULL AND kdc.validity_end_date = TRUNC (SYSDATE))
         AND kdc.company_type NOT IN
               (SELECT kdct.company_type
                  FROM koc_dmt_company_type_detail kdct
                     , -- yetkisi de�i�en acente
                      koc_dmt_agents_ext kdae
                 WHERE kdae.int_id = kdct.agent_int_id AND kdct.validity_end_date = TRUNC (SYSDATE) AND kdct.agent_int_id = kdc.agent_int_id)
            union
                select c.*,
                       b.collection_authority,b.company_code--TPA2 Serdalt
                   from KOC_DMT_AGENTS_EXT_HIST a,
                       koc_dmt_agents_ext b,
                       koc_dmt_company_type_detail c
                where trunc(a.process_date) = trunc(sysdate)
                and a.int_id = b.int_id
                and a.int_id = c.agent_int_id
                and nvl(a.COLLECTION_AUTHORITY,'XX') <> nvl(b.COLLECTION_AUTHORITY,'XX')
                and (C.VALIDITY_END_DATE is null or trunc(c.VALIDITY_END_DATE) > trunc(sysdate));

    CURSOR c_yetki (p_int_id NUMBER)
    IS
      SELECT DISTINCT koc_dmt_utils.dmt_company_type (i.agent_id)
                    , --yetki
                     NVL (ext.collection_authority, '9999999999') --tahsilat yetki
        FROM koc_dmt_cand_agent_info i
           , koc_dmt_agents_ext ext
       WHERE i.agent_id = ext.int_id AND ext.int_id = p_int_id;

    --Acentenin yetkisine g�re bize verilen �rnek user rolleri al�yoruz.
    CURSOR c_ornek_user (p_yetki VARCHAR2, p_tahsilat_yetki VARCHAR2)
    IS
      SELECT a.acente_user_name
        FROM alz_tobb_ornek_userrole a
       WHERE a.yetki_kod = p_yetki AND a.tahsilat_yetki = DECODE (p_tahsilat_yetki,  'SADECE KK', 'KK1',  'SADECE KK2', 'KK2',  'A��k'); --mail d�n���ne g�re de�i�tirilecek

    --�rnek user �zerindeki rolleri al�yoruz
    CURSOR c_role (p_user_name VARCHAR2)
    IS
      SELECT DISTINCT role_code
        FROM koc_auth_user_role_rel
       WHERE username = p_user_name AND role_code <> 'DAPMERKEZ';

    --Rolleri de�i�ecek userlar
    CURSOR c_tp (p_agent_int_id VARCHAR2)
    IS
      SELECT DISTINCT a.user_name
                    , d.reference_code
                    , e.agent_int_id
                    , e.emp_id_no
                    , e.identity_no
                    , e.employee_type
                    , e.employee_name
                    , e.employee_surname
                    , e.validity_start_date
                    , e.validity_end_date
                    , e.userid
                    , e.process_date
        FROM web_sec_system_users a
           , cp_partners b
           , koc_cp_partners_ext c
           , dmt_agents d
           , koc_dmt_agency_tech_emp e
       WHERE a.customer_partner_id = b.part_id
         AND b.part_id = c.part_id
         AND c.agen_int_id = d.int_id
         AND d.int_id = e.agent_int_id
         AND  e.identity_no = c.identity_no
         AND (validity_end_date IS NULL OR validity_end_date > TRUNC (SYSDATE))
         AND c.agen_int_id = p_agent_int_id;
  BEGIN
    FOR c_ua IN c_update_agency LOOP
      BEGIN
        OPEN c_yetki (c_ua.agent_int_id);

        FETCH c_yetki
        INTO v_yetki, v_tahsilat_yetki;

        CLOSE c_yetki;

        --�rnek user_name'i al�yoruz
        OPEN c_ornek_user (v_yetki, v_tahsilat_yetki);

        FETCH c_ornek_user INTO v_ornek_user_name;

        CLOSE c_ornek_user;

        if c_ua.company_code = '045' THEN--TPA2 Serdalt
          --rolleri de�i�ecek userlar
          FOR c_userlar IN c_tp (c_ua.agent_int_id) LOOP
            BEGIN
              --yetkisi de�i�en acentenin userlar�na end date veriyoruz
              -- SORULACAK sil denmi�
              --                     update KOC_AUTH_USER_ROLE_REL
              --                     set VALIDITY_END_DATE = trunc(sysdate)
              --                     where username = c_userlar.user_name;
              --PKden dolay� delete yap�yoruz
              DELETE koc_auth_user_role_rel
               WHERE username = c_userlar.user_name;
              ALZ_WEB_USER_UTILS.log_user_role_history(p_user_name       => c_userlar.user_name,
                              p_role_code       => 'ALL',
                              p_action_type     => 'U',
                              p_update_user     => v_tobb_user_name,
                              p_process_results => v_process_results);

              --yetkisi de�i�en acente altndaki userlar�n yeni rollerini at�yoruz
              FOR c_r IN c_role (v_ornek_user_name) LOOP
                BEGIN
                  INSERT INTO koc_auth_user_role_rel (
                                username
                              , role_code
                              , validity_start_date
                              , validity_end_date
                              , is_authorized_agency_user
                              , region_code)
                       VALUES (c_userlar.user_name
                             , c_r.role_code
                             , TRUNC (SYSDATE)
                             , NULL
                             , NULL
                             , NULL);
                   ALZ_WEB_USER_UTILS.log_user_role_history(p_user_name       => c_userlar.user_name,
                              p_role_code       => c_r.role_code,
                              p_action_type     => 'I',
                              p_update_user     => v_tobb_user_name,
                              p_process_results => v_process_results);
                  COMMIT;
                EXCEPTION
                  WHEN OTHERS THEN
                    INSERT INTO alz_tobb_user_error (
                                  err_text
                                , creation_date
                                , process)
                         VALUES ('user: ' || c_userlar.user_name || ' role: ' || c_r.role_code
                               , TRUNC (SYSDATE)
                               , 'UpdateAgencyRole');
                END;
              END LOOP;

              v_user_in_idm :=  CF_IDM_AUTHORIZATION.CHECK_IDM_SWITCH(v_ornek_user_name);
              v_carray_profile :=  customer.char_array();
              IF v_user_in_idm THEN
                BEGIN
                  FOR cr_profile IN c_user_profiles (v_ornek_user_name) LOOP
                     BEGIN
                        v_carray_profile.EXTEND;
                        v_carray_profile (v_carray_profile.LAST) := cr_profile.profile_id;
                     END;
                  END LOOP;
                EXCEPTION WHEN OTHERS THEN
                   INSERT INTO alz_tobb_user_error (
                               err_text , creation_date , process)
                       VALUES ('User Profil Bilgisi bulunurken Hata' , TRUNC(SYSDATE),'UpdateAgencyRole');
                END;
              END IF;

              IF (c_userlar.employee_type IN ('1', '2', '4', '8', '9', '11')) THEN
                INSERT INTO koc_auth_user_role_rel (
                              username
                            , role_code
                            , validity_start_date)
                     VALUES (c_userlar.user_name
                           , 'DAPMERKEZ'
                           , TRUNC (SYSDATE) - 3);
                 ALZ_WEB_USER_UTILS.log_user_role_history(p_user_name       => c_userlar.user_name,
                              p_role_code       => 'DAPMERKEZ',
                              p_action_type     => 'I',
                              p_update_user     => v_tobb_user_name,
                              p_process_results => v_process_results);
                IF v_user_in_idm THEN
                   v_carray_profile.Extend;
                   v_carray_profile(v_carray_profile.Last) := v_DapMerkezProfile;
                END IF;
              END IF;

              --Bes yetkisi kontrol edilip,bes rolu verilecek
            --Trafik rolu kontrol edilip, trafik rolu verilecek
            BEGIN
              SELECT DISTINCT a.is_bes_authority,a.AGENCY_MENU_TYPE
                INTO v_bes_ctrl,v_trafik_ctrl
                FROM koc_dmt_agents_ext a
               WHERE a.int_id = c_ua.agent_int_id;
            EXCEPTION
              WHEN OTHERS THEN
                v_bes_ctrl := 0;
                v_trafik_ctrl :=0;
            END;

            IF (v_bes_ctrl = 1) THEN
              BEGIN
                INSERT INTO koc_auth_user_role_rel (
                              username
                            , role_code
                            , validity_start_date)
                     VALUES (c_userlar.user_name
                           , 'WPPPAGENT'
                           , TRUNC (SYSDATE) - 3);
                 ALZ_WEB_USER_UTILS.log_user_role_history(p_user_name       => c_userlar.user_name,
                              p_role_code       => 'WPPPAGENT',
                              p_action_type     => 'I',
                              p_update_user     => v_tobb_user_name,
                              p_process_results => v_process_results);
              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;
              IF v_user_in_idm THEN
                 v_carray_profile.Extend;
                 v_carray_profile(v_carray_profile.Last) := v_AgencyBesProfile;
              END IF;
            END IF;

            IF (v_trafik_ctrl = 1) THEN
              BEGIN
                INSERT INTO koc_auth_user_role_rel (
                              username
                            , role_code
                            , validity_start_date)
                     VALUES (c_userlar.user_name
                           , 'WPMTPLMADF'
                           , TRUNC (SYSDATE) - 3);
                ALZ_WEB_USER_UTILS.log_user_role_history(p_user_name       => c_userlar.user_name,
                              p_role_code       => 'WPMTPLMADF',
                              p_action_type     => 'I',
                              p_update_user     => v_tobb_user_name,
                              p_process_results => v_process_results);
               INSERT INTO koc_auth_user_role_rel (
                      username
                    , role_code
                    , validity_start_date)
             VALUES (c_userlar.user_name
                   , 'WPTAGENTP'
                   , TRUNC (SYSDATE) - 3);
              ALZ_WEB_USER_UTILS.log_user_role_history(p_user_name       => c_userlar.user_name,
                              p_role_code       => 'WPTAGENTP',
                              p_action_type     => 'I',
                              p_update_user     => v_tobb_user_name,
                              p_process_results => v_process_results);
              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;
              IF v_user_in_idm THEN
                 v_carray_profile.Extend;
                 v_carray_profile(v_carray_profile.Last) := v_AgencyTrafficProfile;
              END IF;
            END IF;
            CF_IDM_UTILS.ADD_USER_PROFILES(c_userlar.user_name,v_carray_profile,1,v_process_results);
            --Bes ve trafik yetkisi kontrol edilip,bes rolu verilecek
            COMMIT;


            END;
          END LOOP;
        End if;--TPA2 Serdalt
      END;
    END LOOP;
  END;
  --
  PROCEDURE bireysorgubytckimlikno (p_acente_kod IN VARCHAR2, p_tckimlikno VARCHAR2, p_kimlikinfo OUT alz_tobb_user.kisi_liste_type
  , p_message OUT VARCHAR2          )
  IS
    soap_request VARCHAR2 (32767);
    soap_respond VARCHAR2 (32767);
    http_req  UTL_HTTP.req;
    http_resp UTL_HTTP.resp;
    HOST      VARCHAR2 (30000); --:= 'http://www.sbm.org.tr/kpsServices-test-V2.0/aileBireySorguService';
    --'http://www.sbm.org.tr/kpsServices-prod-V1.0/aileBireySorguService';
    --'http://esb.allianz.com.tr:12000/KpsServices/ProxyServices/AllianzKpsService_v2?wsdl';
    v_dbname  VARCHAR2 (50);
    v_global_host_traffic VARCHAR2 (30000);
    v_resp_xml XMLTYPE;
    v_req_group_no NUMBER;
    v_yaz     VARCHAR2 (5000);
    v_msg     VARCHAR2 (5000);
    i         NUMBER;
    v_errnum  NUMBER (5);
    v_acente_kod VARCHAR2 (100);
    v_tckimlikno VARCHAR2 (100);
    v_request VARCHAR2 (4000);
    v_response VARCHAR2 (4000);
    v_kimlikinfo alz_sagmer_ws.kimlikinfotyp;
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    -- cml sagmer_ws cagrilmasi saglandi
    v_errnum := 1;
    DECLARE
      v_session_metadata customer.session_metadata_rec; --:= CUSTOMER.SESSION_METADATA_REC (NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
      v_ipaddr  VARCHAR2 (20);
    BEGIN
      BEGIN
        SELECT SYS_CONTEXT ('USERENV', 'IP_ADDRESS', 15) ipaddr INTO v_ipaddr FROM DUAL;
      EXCEPTION
        WHEN OTHERS THEN
          v_ipaddr := NULL;
      END;
      v_session_metadata :=
        customer.session_metadata_rec (NULL, NULL, p_acente_kod
                                     , USER, NULL, NULL
                                     , 'TOBBUSER', v_ipaddr, NULL);
      alz_base_function_utils.set_session_metadata (v_session_metadata);
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    v_errnum := 2;
    alz_sagmer_ws.kpsbireysorgubytckimlikno ('045', 'koc', p_acente_kod
                                           , p_tckimlikno, v_kimlikinfo, p_message);
    v_errnum := 3;

    IF p_message IS NULL THEN
      i      := 1;

      WHILE i <= v_kimlikinfo.COUNT LOOP
        p_kimlikinfo (i).adi := v_kimlikinfo (i).adi;
        p_kimlikinfo (i).anneadi := v_kimlikinfo (i).anneadi;
        p_kimlikinfo (i).babaadi := v_kimlikinfo (i).babaadi;
        p_kimlikinfo (i).cinsiyeti := v_kimlikinfo (i).cinsiyeti;
        p_kimlikinfo (i).dogumtarihi := v_kimlikinfo (i).dogumtarihi;
        p_kimlikinfo (i).dogumyeri := v_kimlikinfo (i).dogumyeri;
        p_kimlikinfo (i).durumu := v_kimlikinfo (i).durumu;
        p_kimlikinfo (i).iladi := v_kimlikinfo (i).iladi;
        p_kimlikinfo (i).iltrafikkodu := v_kimlikinfo (i).iltrafikkodu;
        p_kimlikinfo (i).ilceadi := v_kimlikinfo (i).ilceadi;
        p_kimlikinfo (i).ilcekodu := v_kimlikinfo (i).ilcekodu;
        p_kimlikinfo (i).medenihali := v_kimlikinfo (i).medenihali;
        p_kimlikinfo (i).soyadi := v_kimlikinfo (i).soyadi;
        p_kimlikinfo (i).tckimlikno := v_kimlikinfo (i).tckimlikno;
        p_kimlikinfo (i).verikonum := v_kimlikinfo (i).verikonum;
        p_kimlikinfo (i).yakinlik := v_kimlikinfo (i).yakinlik;
        i      := i + 1;
      END LOOP;
    END IF;

    v_errnum := 4;
    /*
               soap_request :=  '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:kps="http://kpsbs.sbm.org.tr">'||
                                '    <soapenv:Header>'||
                                '      <wsse:Security xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd">'||
                                '         <wsse:UsernameToken xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">'||
                                '            <wsse:Username>koc</wsse:Username>'||
                                '            <wsse:KurumKod>045</wsse:KurumKod>'||
                                '         </wsse:UsernameToken>'||
                                '      </wsse:Security>'||
                                '   </soapenv:Header>'||
                                '   <soapenv:Body>'||
                                '      <kps:kpsBireySorgu>'||
                                '         <!--Optional:-->'||
                                '         <params>'||
                                '            <!--Optional:-->'||
                                '            <acenteKod/>'||
                                '            <!--Optional:-->'||
                                '            <kimlikNo>'||p_TcKimlikNo||'</kimlikNo>'|| --58129427222
                                '            <tumAile>true</tumAile>'||
                                '            <cacheStyle>1</cacheStyle>'||
                                '            <maxAge>180</maxAge>'||
                                '         </params>'||
                                '      </kps:kpsBireySorgu>'||
                                '   </soapenv:Body>'||
                                '</soapenv:Envelope>';

    --                   '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:kps="http://kpsbs.sbm.org.tr">'||
    --                           '<soapenv:Header/>'||
    --                             '<soapenv:Body>'||
    --                               '<kps:kpsBireySorgu>'||
    --                                   '<!--Optional:-->'||
    --                                   '<params>'||
    --                               '<!--Optional:-->'||
    --                             '<acenteKod>'||p_acente_kod||'</acenteKod>'||
    --                           '<!--Optional:-->'||
    --                           '<kimlikNo>'||p_TcKimlikNo||'</kimlikNo>'||
    --                           '<tumAile>true</tumAile>'||
    --                           '<cacheStyle>1</cacheStyle>'||
    --                           '<maxAge>180</maxAge>'||
    --                           '</params>'||
    --                           '</kps:kpsBireySorgu>'||
    --                           '</soapenv:Body>'||
    --                           '</soapenv:Envelope>';

        begin
              select name
              into v_dbname
              from v$database;
          exception when others then
             v_dbname := null;
          end;

           if v_dbname not in ('OPUSDATA') then
            HOST := 'http://www.sbm.org.tr/kpsServices-prod-V2.0/aileBireySorguService';
           elsif v_dbname not in ('OPUSDEVL') or v_dbname not in ('OPUSDEV') then
           HOST := 'http://www.sbm.org.tr/kpsServices-test-V2.0/aileBireySorguService';
          else
           HOST := 'http://www.sbm.org.tr/kpsServices-prod-V2.0/aileBireySorguService';
          end if;

       v_REQUEST := substr(soap_request,1,3999);

      http_req := UTL_HTTP.begin_request (HOST, 'POST', 'HTTP/1.1');
       v_errNum     := 2;
      UTL_HTTP.set_header(http_req, 'Keep-Alive','TE');
       v_errNum     := 3;
      UTL_HTTP.set_header(http_req, 'Connection', 'keep-alive');
       v_errNum     := 4;
      UTL_HTTP.set_header(http_req, 'Content-Type', 'text/xml; charset=UTF-8');
       v_errNum     := 5;
      UTL_HTTP.set_header(http_req, 'Content-Length', LENGTH (soap_request));
       v_errNum     := 6;
      --UTL_HTTP.set_header(http_req, 'SOAPAction', 'http://kpsbs.sbm.org.tr//kpsAileSorguByTcKimlikNo');
       v_errNum     := 7;
      UTL_HTTP.write_text(http_req, soap_request);
       v_errNum     := 8;
      http_resp := UTL_HTTP.get_response(http_req);
       v_errNum     := 9;
      UTL_HTTP.read_text(http_resp, soap_respond, 32000);
       v_errNum     := 10;
      UTL_HTTP.end_response(http_resp);
       v_errNum     := 11;


    -- Burda parse ediyoruz

      --soap_respond := REPLACE( REPLACE(REPLACE(REPLACE(REPLACE (REPLACE (REPLACE (soap_respond, 'env:', ''),'soap:',''), 'xmlns=', 'xmlns:ns2='), 'ns2:', ''), ' xsi:nil="1"', ''), 'S:', ''),'xmlns=""','');
      --soap_respond := Replace(Replace(Replace(soap_respond, 'ns2:', ''), ' xsi:nil="1"', ''), 'S:', '');
      soap_respond := replace(replace(Replace(Replace(Replace(soap_respond, 'ns2:', ''), ' xsi:nil="1"', ''), 'S:', ''),
            '<!--
                 window.location.replace("http:\u002f\u002fwww.sbm.org.tr\u002fSayfalar\u002fPageNotFoundError.aspx?requestUrl=http:\u002f\u002fwww.sbm.org.tr\u002fkpsServices-prod-V1.0\u002faileBireySorguService")
                -->',''
       ),'<!------------------------------------------------------------------------->','');

      v_RESPONSE := substr(soap_respond,1,3999);
      v_errNum     := 12;
      v_resp_xml := XMLTYPE(soap_respond);
      v_errNum     := 13;

    --dbms_output.put_line(substr(soap_respond,1,255));
    --dbms_output.put_line(substr(soap_respond,256,255));
    -- Hata var sa �ik
      Select extractvalue(v_resp_xml, '/Envelope/Body/Fault/faultstring') Into p_Message from dual;
      If p_Message is not null then

         return;
      End if;

      i :=1;
     v_errNum     := 14;
    LOOP
        Select  extractvalue(v_resp_xml, '/Envelope/Body/kpsBireySorguResponse/return['||i||']/'
          ||''
          ||'adi'),
         extractvalue(v_resp_xml, '/Envelope/Body/kpsBireySorguResponse/return['||i||']/'
          ||''
          ||'anneAdi'),
         extractvalue(v_resp_xml, '/Envelope/Body/kpsBireySorguResponse/return['||i||']/'
          ||''
          ||'babaAdi'),
         extractvalue(v_resp_xml, '/Envelope/Body/kpsBireySorguResponse/return['||i||']/'
          ||''
          ||'cinsiyeti'),
         extractvalue(v_resp_xml, '/Envelope/Body/kpsBireySorguResponse/return['||i||']/'
          ||''
          ||'dogumTarihi'),
         extractvalue(v_resp_xml, '/Envelope/Body/kpsBireySorguResponse/return['||i||']/'
          ||''
          ||'dogumYeri'),
         extractvalue(v_resp_xml, '/Envelope/Body/kpsBireySorguResponse/return['||i||']/'
          ||''
          ||'durumu'),
         extractvalue(v_resp_xml, '/Envelope/Body/kpsBireySorguResponse/return['||i||']/'
          ||''
          ||'ilAdi'),
         extractvalue(v_resp_xml, '/Envelope/Body/kpsBireySorguResponse/return['||i||']/'
          ||''
          ||'ilTrafikKodu'),
         extractvalue(v_resp_xml, '/Envelope/Body/kpsBireySorguResponse/return['||i||']/'
          ||''
          ||'ilceAdi'),
         extractvalue(v_resp_xml, '/Envelope/Body/kpsBireySorguResponse/return['||i||']/'
          ||''
          ||'ilceKodu'),
         extractvalue(v_resp_xml, '/Envelope/Body/kpsBireySorguResponse/return['||i||']/'
          ||''
          ||'medeniHali'),
         extractvalue(v_resp_xml, '/Envelope/Body/kpsBireySorguResponse/return['||i||']/'
          ||''
          ||'soyadi'),
         extractvalue(v_resp_xml, '/Envelope/Body/kpsBireySorguResponse/return['||i||']/'
          ||''
          ||'tckimlikNo'),
          extractvalue(v_resp_xml, '/Envelope/Body/kpsBireySorguResponse/return['||i||']/'
          ||''
          ||'veriKonum'),
         extractvalue(v_resp_xml, '/Envelope/Body/kpsBireySorguResponse/return['||i||']/'
          ||''
          ||'yakinlik')
         into
          p_kimlikinfo(i).adi,
        p_kimlikinfo(i).anneadi,
        p_kimlikinfo(i).babaadi,
        p_kimlikinfo(i).cinsiyeti,
        p_kimlikinfo(i).dogumtarihi,
        p_kimlikinfo(i).dogumyeri,
        p_kimlikinfo(i).durumu,
        p_kimlikinfo(i).iladi,
        p_kimlikinfo(i).iltrafikkodu,
        p_kimlikinfo(i).ilceadi,
        p_kimlikinfo(i).ilcekodu ,
        p_kimlikinfo(i).medenihali ,
        p_kimlikinfo(i).soyadi ,
        p_kimlikinfo(i).tckimlikno,
        p_kimlikinfo(i).veriKonum,
        p_kimlikinfo(i).yakinlik
           from dual;



    --  dbms_output.put_line(i||':'||p_kimlikinfo(i).adi);
      EXIT WHEN p_kimlikinfo(i).adi is null;

    IF p_kimlikinfo(i).veriKonum = 'kps' THEN
     koc_ws_count('KPS2',1);
    END IF;

      i:=i+1;
    END LOOP;
     v_errNum     := 15;
     */
    v_errnum := 15;

    INSERT INTO alz_tobb_user_error (
                  agent_int_id
                , identity_no
                , v_errnum
                , err_text
                , creation_date
                , request
                , response
                , process)
         VALUES (p_acente_kod
               , p_tckimlikno
               , v_errnum
               , v_msg
               , SYSDATE
               , v_request
               , v_response
               , 'BireySorguByTcKimlikNo');

    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      p_message := 'Sagmerden yanit alinamadi!';
      v_msg  := SUBSTR (SQLERRM, 1, 3000);

      INSERT INTO alz_tobb_user_error (
                    agent_int_id
                  , identity_no
                  , v_errnum
                  , err_text
                  , creation_date
                  , request
                  , response
                  , process)
           VALUES (p_acente_kod
                 , p_tckimlikno
                 , v_errnum
                 , v_msg
                 , SYSDATE
                 , v_request
                 , v_response
                 , 'BireySorguByTcKimlikNo');

      COMMIT;
      BEGIN
        UTL_HTTP.end_response (http_resp);
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
  --  Raise_Application_Error(-20110, sqlerrm);
  END;
  --
  PROCEDURE sendsms (p_gsm VARCHAR2, p_message_body VARCHAR2, p_company_code VARCHAR2)
  IS
    v_errnum  NUMBER (5);
    /*v_dbname  VARCHAR2 (30);
    soap_request VARCHAR2 (32767);
    soap_respond VARCHAR2 (32767);
    http_req  UTL_HTTP.req;
    http_resp UTL_HTTP.resp;
    HOST      VARCHAR2 (30000);
    v_resp_xml XMLTYPE;*/
  v_Response_Rec                 Customer.euromsg_mail_response_table := Customer.EuroMsg_Mail_Response_Table();
    v_Process_Results              Customer.process_result_table;
  v_Sms_Input                    Customer.EuroMsg_Sms_Input_Rec;
    v_Sms_Message_Type             NUMBER := 1;
    v_Parameter_Map                Customer.EuroMsg_Mail_Parameter_Table := Customer.EuroMsg_Mail_Parameter_Table();
    v_Sms_Result                   VARCHAR2(1000);
    v_Sms_Response                 VARCHAR2(1000);
    v_Payload                      CLOB;
    v_msg     VARCHAR2 (5000);
    v_request VARCHAR2 (4000);
    v_response VARCHAR2 (4000);
   -- v_em_campaign_code VARCHAR2 (20); --ademo
  --    yeni kurulan acente mesaj i�eri�i
  --    v_yeni_acente_msg VARCHAR2 (500) := 'abcdef12 �ifreniz ve XXxx kullan�c� ad�n�z ile DIGITALL sistemine giri� yapabilirsiniz.';
  --    yeni teknik user olusturuldugunda
  --    v_yeni_tuser_msg VARCHAR2 (500)
  --      := '5**3*5***1 nolu cep telefonunuza xxxx kullan�c�s�n�n DIGITALL �ifresi sms olarak iletilmi�tir.
  --                   XXxx kullan�c�s� ile DIGITALL sistemine giri� yapmak i�in t�klay�n�z? (t�klay�n�za bas�nca DigitALL sayfas�na y�nlendirme olacak.)';
  --    kapat�lan acente i�in
  --    v_kapat�lan_acente_msg VARCHAR2 (500) := 'xxxx TCKN?li personelinize ait XXxx kullan�c� hesab� kapat�lm��t�r.';
  --    kapat�lan teknik personel user�
  --    v_kapat�lan_tp_new VARCHAR2 (500) := 'xxxx TCKN?li teknik personelinize ait XXxx kullan�c� hesab� kapat�lm��t�r.';
  BEGIN
  --if p_company_code='045' Then--TPA2 Serdal 2017-12-05 --AliSakalli TPA-FAZ3 TPA_104 - 15.02.2018
    /*BEGIN
      SELECT em_campaign_code
        INTO v_em_campaign_code
        FROM alz_tpa_companies
       WHERE company_code = p_company_code;
    EXCEPTION
      WHEN OTHERS THEN
        v_em_campaign_code := NULL;
    END;
    soap_request :=
      '<S:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/" xmlns:S="http://schemas.xmlsoap.org/soap/envelope/">' || '<env:Header/>' ||
      '<S:Body>' || '<ns0:execute xmlns:ns0="gs.az.tr">' || '<arg0>' || '<command>' || '<commandName>SENDMESSAGE</commandName>' ||
      '<commandText>Mesaj G�nder</commandText>' || '</command>' || '<key>' || '</key>' || '<objectData>' || '<fields>' ||
      '<fieldName>obj.emAttachment1.attachmentBody</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment1.attachmentName</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment2.attachmentBody</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment2.attachmentName</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment3.attachmentBody</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment3.attachmentName</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment4.attachmentBody</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment4.attachmentName</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment5.attachmentBody</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment5.attachmentName</fieldName>' || '<value/>' || '</fields>' || '<fields>' || '<fieldName>obj.emBody</fieldName>' ||
      '<value>' || p_message_body || '</value>' || '</fields>' || '<fields>' || '<fieldName>obj.emMessageType</fieldName>' || '<value>0</value>' ||
      '</fields>' || '<fields>' || '<fieldName>obj.emSubject</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emTo</fieldName>' || '<value>' || p_gsm || '</value>' || --seda.g�ven canl�da de�i�ecek 905346675266
                                                                              '</fields>' || '<fields>' ||
      '<fieldName>obj.emCampaingCode</fieldName>' || '<value>' || v_em_campaign_code || '</value>' || --ENGINT campaign code added
                                                                                                     '</fields>' ||
      '<objcetName>ServiceEuroMessageObject</objcetName>' || '</objectData>' || '<processCode>AZS_EURO_MESSAGE</processCode>' ||
      '<processStepName>EUROMESSAGESENDER</processStepName>' || '</arg0>' || '</ns0:execute>' || '</S:Body>' || '</S:Envelope>';
    v_errnum := 1;
    BEGIN
      --SELECT name INTO v_dbname FROM v$database;
      SELECT get_db_name INTO v_dbname FROM dual; --AliSakalli TPA_104
    EXCEPTION
      WHEN OTHERS THEN
        v_dbname := NULL;
    END;

    IF v_dbname NOT IN ('OPUSDATA') THEN
      HOST   := 'http://test-services.allianz.com.tr/GenericService/GPE?wsdl'; --'http://irisapp1tnd1.yksigorta.com.tr:9090/GenericService/GPE?wsdl';
    ELSE
      -- HOST := 'https://services.allianz.com.tr/gws/GPE?wsdl'; sonradan testi yap�l�p d�zeltilecek
      HOST   := 'http://esb.allianz.com.tr:12000/external/gws/GPE?wsdl'; --'http://services.allianz.com.tr/gws/GPE?wsdl'; --'http://10.70.2.85:17101/gws/GPE?wsdl';
    END IF;

    v_request := SUBSTR (soap_request, 1, 3999);
    http_req := UTL_HTTP.begin_request (HOST, 'POST', 'HTTP/1.1');
    v_errnum := 2;
    UTL_HTTP.set_header (http_req, 'Keep-Alive', 'TE');
    v_errnum := 3;
    UTL_HTTP.set_header (http_req, 'Connection', 'keep-alive');
    v_errnum := 4;
    --UTL_HTTP.set_header (http_req, 'Content-Type', 'text/xml; charset=UTF-8');
    UTL_HTTP.SET_HEADER (http_req,
                        'Content-Type',
                        'text/xml; charset=ISO-8859-9');
    v_errnum := 5;
    UTL_HTTP.set_header (http_req, 'Content-Length', LENGTH (soap_request));
    v_errnum := 6;
    -- UTL_HTTP.set_header(http_req, 'SOAPAction', 'http://kpsbs.sbm.org.tr//kpsAileSorguByTcKimlikNo');
    v_errnum := 7;
    UTL_HTTP.write_text (http_req, soap_request);
    v_errnum := 8;
    http_resp := UTL_HTTP.get_response (http_req);
    v_errnum := 9;
    UTL_HTTP.read_text (http_resp, soap_respond, 32000);
    v_errnum := 10;
    UTL_HTTP.end_response (http_resp);
    v_errnum := 11;
    soap_respond := REPLACE (REPLACE (REPLACE (soap_respond, 'ns2:', ''), ' xsi:nil="1"', ''), 'S:', '');
    v_response := SUBSTR (soap_respond, 1, 3999);
    v_errnum := 12;
    v_resp_xml := xmltype (soap_respond);
    v_errnum := 13;
    v_errnum := 14; --ba�ar�l�
    */
  --[ademo
  v_errnum := 1;
  v_Parameter_Map.Extend;
    v_Parameter_Map(v_Parameter_Map.Count) := euromsg_mail_parameter_rec ('EM_SMS_OTHER', 'true'); --allclubdan g�nderim i�in
    v_errnum := 2;
    v_Sms_Input :=  Customer.EuroMsg_Sms_Input_Rec(p_gsm,
                                                   p_message_body,
                                                   p_company_code,
                                                   'ALZ_TOBB_USER_'||p_gsm,
                                                   v_Parameter_Map);
    v_errnum := 3;
    v_request := Alz_Euromsg_Utils.Convert_Sms_Input_To_Payload(v_Sms_Input);
    v_errnum := 4;
    Alz_Euromsg_Utils.Send_Sms(v_Sms_Input,
                               v_Sms_Message_Type,
                               USER,
                               v_Response_Rec,
                               v_Process_Results);
    v_errnum := 5;
    v_sms_result := '1';
    FOR rec IN (SELECT Hata_Code,Response_Name, Response_Value FROM TABLE(v_Response_Rec)) LOOP
        IF rec.Hata_Code = '200'
        AND rec.Response_Name = 'code' THEN
            v_sms_result := rec.Response_Value;
        END IF;
        IF rec.Response_Name = 'message' THEN
            v_sms_response := SUBSTR(rec.Response_Value,1,30);
        END IF;
    END LOOP;
  v_errNum := 6;
  v_response := v_sms_result || '-' || v_sms_response;
  --ademo]
    --basar�l� mesajlar tutuluyor
    INSERT INTO alz_tobb_user_hist (
                  gsm
                , email
                , v_errnum
                , err_text
                , creation_date
                , request
                , response)
         VALUES (p_gsm
               , NULL
               , v_errnum
               , 'sendsms/basarili'
               , SYSDATE
               , v_request
               , v_response);

    COMMIT;
  --end if;--TPA2 Serdal 2017-12-05 --AliSakalli TPA-FAZ3 TPA_104 - 15.02.2018
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_msg  := SUBSTR (SQLERRM, 1, 3000);

      INSERT INTO alz_tobb_user_error (
                    v_errnum
                  , err_text
                  , creation_date
                  , request
                  , response
                  , gsm
                  , process)
           VALUES (v_errnum
                 , v_msg
                 , SYSDATE
                 , v_request
                 , v_response
                 , p_gsm
                 , 'ALZ_TOBB_USER/sendsms');

      COMMIT;
      /*BEGIN
        UTL_HTTP.end_response (http_resp);
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;*/
  END;
  --
  PROCEDURE sendemail (p_mail_adress VARCHAR2, p_mail_body VARCHAR2, p_company_code VARCHAR2)
  IS
    v_errnum  NUMBER (5);
  --[ademo
  v_Mail_Input                   Customer.EuroMsg_Mail_Input_Rec;
    v_String_Rec_To                Customer.String_Table := Customer.String_Table();
    v_Response_Rec                 Customer.euromsg_mail_response_table := Customer.EuroMsg_Mail_Response_Table();
    v_Process_Results              Customer.process_result_table;
    v_Parameter_Map                Customer.EuroMsg_Mail_Parameter_Table := Customer.EuroMsg_Mail_Parameter_Table();
  --ademo]
    /*v_dbname  VARCHAR2 (30);
    soap_request VARCHAR2 (32767);
    soap_respond VARCHAR2 (32767);
    http_req  UTL_HTTP.req;
    http_resp UTL_HTTP.resp;
    HOST      VARCHAR2 (30000);
    v_resp_xml XMLTYPE; */
    v_msg     VARCHAR2 (5000);
    v_request VARCHAR2 (4000);
    v_response VARCHAR2 (4000);
    --v_em_campaign_code VARCHAR2 (20); --ademo
    v_subject    VARCHAR2(250); --AliSakalli TPA-FAZ3 TPA_104 - 15.02.2018
  --   Yeni kurulan acente oldu�unda:
  --    v_yeni_acente_mail VARCHAR2 (1000)
  --      := '5**3*5***1 no?lu cep telefonunuza xxxx kullan�c�s�n�n DIGITALL �ifresi sms olarak iletilmi�tir.
  --             XXxx kullan�c�s� ile DIGITALL sistemine giri� yapmak i�in t�klay�n�z? (t�klay�n�za bas�nca DigitALL sayfas�na y�nlendirme olacak.)';
  --    Yeni teknik personel user� olu�turuldu�unda:
  --    v_tp_mail VARCHAR2 (1000)
  --      := '5**3*5***1 no?lu cep telefonunuza xxxx kullan�c�s�n�n DIGITALL �ifresi sms olarak iletilmi�tir.
  --         XXxx kullan�c�s� ile DIGITALL sistemine giri� yapmak i�in t�klay�n�z? (t�klay�n�za bas�nca DigitALL sayfas�na y�nlendirme olacak.)';
  --    Kapat�lan acente i�in:
  --    v_kapatilan_acente_mail VARCHAR2 (1000) := 'xxxx TCKN?li personelinize ait XXxx kullan�c� hesab� kapat�lm��t�r.';
  --    Kapat�lan teknik personeli user� oldu�unda:
  --    v_kapatilan_tp_mail VARCHAR2 (1000) := 'xxxx TCKN?li teknik personelinize ait XXxx kullan�c� hesab� kapat�lm��t�r.';
  BEGIN
  --if p_company_code='045' Then--TPA2 Serdal 2017-12-05 --AliSakalli TPA-FAZ3 TPA_104 - 15.02.2018
    /*BEGIN
      SELECT em_campaign_code
        INTO v_em_campaign_code
        FROM alz_tpa_companies
       WHERE company_code = p_company_code;
    EXCEPTION
      WHEN OTHERS THEN
        v_em_campaign_code := NULL;
    END;*/

    --AliSakalli TPA-FAZ3 TPA_104 - 15.02.2018
    v_subject := NULL;
    IF p_company_code = '045' THEN
      v_subject := 'Allianz DigitALL Kullanici Bilgileri';
    ELSE
      v_subject := 'Allclub Kullanici Bilgileri';
    END IF;

    /*soap_request :=
      '<S:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/" xmlns:S="http://schemas.xmlsoap.org/soap/envelope/">' || '<env:Header/>' ||
      '<S:Body>' || '<ns0:execute xmlns:ns0="gs.az.tr">' || '<arg0>' || '<command>' || '<commandName>SENDMESSAGE</commandName>' ||
      '<commandText>Mesaj G�nder</commandText>' || '</command>' || '<key>' || '</key>' || '<objectData>' || '<fields>' ||
      '<fieldName>obj.emAttachment1.attachmentBody</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment1.attachmentName</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment2.attachmentBody</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment2.attachmentName</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment3.attachmentBody</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment3.attachmentName</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment4.attachmentBody</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment4.attachmentName</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment5.attachmentBody</fieldName>' || '<value/>' || '</fields>' || '<fields>' ||
      '<fieldName>obj.emAttachment5.attachmentName</fieldName>' || '<value/>' || '</fields>' || '<fields>' || '<fieldName>obj.emBody</fieldName>' ||
      '<value>' || p_mail_body || '</value>' || '</fields>' || '<fields>' || '<fieldName>obj.emMessageType</fieldName>' || '<value>1</value>' ||
      '</fields>' || '<fields>' || '<fieldName>obj.emCampaingCode</fieldName>' || '<value>' || v_em_campaign_code || '</value>' || '</fields>' ||
      '<fields>' || '<fieldName>obj.emSubject</fieldName>' || '<value>' || v_subject || '</value>' || '</fields>' || '<fields>'
      || '<fieldName>obj.emTo</fieldName>' || '<value>' || p_mail_adress || '</value>' || --Seda.Guven@allianz.com.tr
                                                                                         '</fields>' ||
      '<objcetName>ServiceEuroMessageObject</objcetName>' || '</objectData>' || '<processCode>AZS_EURO_MESSAGE</processCode>' ||
      '<processStepName>EUROMESSAGESENDER</processStepName>' || '</arg0>' || '</ns0:execute>' || '</S:Body>' || '</S:Envelope>'; --p_mail_adress mail eklenecek
    v_errnum := 1;
    BEGIN
      --SELECT name INTO v_dbname FROM v$database;
      SELECT get_db_name INTO v_dbname FROM dual; --AliSakalli TPA_104
    EXCEPTION
      WHEN OTHERS THEN
        v_dbname := NULL;
    END;

    IF v_dbname NOT IN ('OPUSDATA') THEN
      HOST   := 'http://test-services.allianz.com.tr/GenericService/GPE?wsdl'; --'http://irisapp1tnd1.yksigorta.com.tr:9090/GenericService/GPE?wsdl';
    ELSE
      --HOST := 'https://services.allianz.com.tr/gws/GPE?wsdl';
      HOST   := 'http://esb.allianz.com.tr:12000/external/gws/GPE?wsdl'; --'http://services.allianz.com.tr/gws/GPE?wsdl';  --'http://10.70.2.85:17101/gws/GPE?wsdl';
    END IF;

    v_request := SUBSTR (soap_request, 1, 3999);
    http_req := UTL_HTTP.begin_request (HOST, 'POST', 'HTTP/1.1');
    v_errnum := 2;
    UTL_HTTP.set_header (http_req, 'Keep-Alive', 'TE');
    v_errnum := 3;
    UTL_HTTP.set_header (http_req, 'Connection', 'keep-alive');
    v_errnum := 4;
--    UTL_HTTP.set_header (http_req, 'Content-Type', 'text/xml; charset=UTF-8');
     UTL_HTTP.SET_HEADER (http_req,
                        'Content-Type',
                        'text/xml; charset=ISO-8859-9');

    v_errnum := 5;
    UTL_HTTP.set_header (http_req, 'Content-Length', LENGTH (soap_request));
    v_errnum := 6;
    -- UTL_HTTP.set_header(http_req, 'SOAPAction', 'http://kpsbs.sbm.org.tr//kpsAileSorguByTcKimlikNo');
    v_errnum := 7;
    UTL_HTTP.write_text (http_req, soap_request);
    v_errnum := 8;
    http_resp := UTL_HTTP.get_response (http_req);
    v_errnum := 9;
    UTL_HTTP.read_text (http_resp, soap_respond, 32000);
    v_errnum := 10;
    UTL_HTTP.end_response (http_resp);
    v_errnum := 11;
    --soap_respond := Replace(Replace(Replace(soap_respond, 'ns2:', ''), ' xsi:nil="1"', ''), 'S:', '');
    v_response := SUBSTR (soap_respond, 1, 3999);
    v_errnum := 12;
    v_resp_xml := xmltype (soap_respond);
    v_errnum := 13;
    v_errnum := 14; --ba�ar�l�
    */
  v_errnum := 1;
  v_String_Rec_To.EXTEND;
    v_String_Rec_To(v_String_Rec_To.COUNT) := String_Rec(p_mail_adress);
    v_errnum := 2;
    v_Parameter_Map.Extend;
    v_Parameter_Map(v_Parameter_Map.Count) := euromsg_mail_parameter_rec ('EM_EMAIL_OTHER', 'true');
    v_errnum := 3;
    v_Mail_Input  := customer.EuroMsg_Mail_Input_Rec(NULL,
                                                      NULL,
                                                      NULL,
                                                      v_String_Rec_to,
                                                      NULL,
                                                      NULL,
                                                      v_subject,
                                                      p_mail_body,
                                                      NULL,
                                                      NULL,
                                                      p_company_code,
                                                      'ALZ_TOBB_USER',
                                                      v_Parameter_Map);
      v_errnum := 4;
      v_request := Alz_Euromsg_Utils.Convert_Mail_Input_To_Payload(v_Mail_Input);
      v_errnum := 5;
      Alz_Euromsg_Utils.Send_Mail(v_Mail_Input,
                                  USER,
                                  v_Response_Rec,
                                  v_Process_Results);
    v_errnum := 5;
       FOR rec IN (SELECT Hata_Code,Response_Name, Response_Value FROM TABLE(v_Response_Rec)) LOOP
           IF rec.Response_Name = 'message' THEN
               v_response := rec.Response_Value;
           END IF;
       END LOOP;
     v_errnum := 6;
       FOR rec IN (SELECT * FROM TABLE(v_Process_Results)) LOOP
             v_response := v_response
                     ||' - '||rec.REASON
                     ||' - '||rec.KEY_VALUE1
                     ||' - '||rec.ERROR_ORIGIN;
       END LOOP;
     v_errnum := 7;
    --basar�l� mailleri tutuluyor
    INSERT INTO alz_tobb_user_hist (
                  gsm
                , email
                , v_errnum
                , err_text
                , creation_date
                , request
                , response)
         VALUES (NULL
               , p_mail_adress
               , v_errnum
               , 'sendmail/basarili'
               , SYSDATE
               , v_request
               , v_response);

    COMMIT;
  --end if;--TPA2 Serdal 2017-12-05 --AliSakalli TPA-FAZ3 TPA_104 - 15.02.2018
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      v_msg  := SUBSTR (SQLERRM, 1, 3000);

      INSERT INTO alz_tobb_user_error (
                    v_errnum
                  , err_text
                  , creation_date
                  , request
                  , response
                  , email
                  , process)
           VALUES (v_errnum
                 , v_msg
                 , SYSDATE
                 , v_request
                 , v_response
                 , p_mail_adress
                 , 'ALZ_TOBB_USER/sendemail');

      COMMIT;
      /*BEGIN
        UTL_HTTP.end_response (http_resp);
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;*/
  END;
  --
  PROCEDURE regenerateuserpassword (p_user_name IN VARCHAR2)
  IS
    v_password RAW (16);
    v_user_name VARCHAR2 (50);
    v_name    VARCHAR2 (100);
    v_surname VARCHAR2 (100);
    --partaj kontrolu i�in
    vc_user_name VARCHAR2 (100);
    vc_agent_int_id VARCHAR2 (100);
    v_mail_adress VARCHAR2 (150);
    v_mail_body VARCHAR2 (1500);
    v_gsm_no  VARCHAR2 (150);
    v_gsm_body VARCHAR2 (1500);
    v_new_password VARCHAR2 (300);
    v_tckn    VARCHAR2 (11);
    v_reference_code VARCHAR2 (100);
    v_agent_int_id NUMBER;
    v_msg     VARCHAR2 (5000);
    v_errnum  NUMBER;
    v_err_text VARCHAR2 (1000);
    p_result  NUMBER;
    p_error_text VARCHAR2 (2000);
    v_company_code VARCHAR2 (10);
  v_ghlth_portal_count NUMBER;
  BEGIN
    v_errnum := 10;
    v_password :=
      alz_web_user_security.generatepasswordaes (4, 3, 2
                                               , 0);
    v_errnum := 20;

    UPDATE web_sec_system_users e
       SET e.user_password_aes = v_password, e.last_password_change = SYSDATE, e.password_expired = 1, e.retry_password_count = 0
         , e.update_date = SYSDATE
     WHERE e.user_name = p_user_name;

    COMMIT;
    --
    v_errnum := 30;
    v_new_password := alz_web_user_security.aesdecrypt (v_password);
    v_errnum := 40;
    BEGIN
      alz_web_user_security.change_aznetgios_password (p_user_name, v_new_password, p_result
                                                     , p_error_text);
    EXCEPTION
      WHEN OTHERS THEN
        p_result := NULL;
        p_error_text := NULL;
    END;
    --kullan�c�n�n partaj� kontrol ediliyor
    BEGIN
      SELECT DISTINCT c.agen_int_id
        INTO vc_agent_int_id
        FROM web_sec_system_users a
           , cp_partners b
           , koc_cp_partners_ext c
       WHERE a.customer_partner_id = b.part_id
         AND b.part_id = c.part_id
         AND a.user_name = p_user_name
         AND (a.end_date > TRUNC (SYSDATE) OR a.end_date IS NULL);

      v_errnum := 41;
    EXCEPTION
      WHEN OTHERS THEN
        --vc_user_name := null;
        vc_agent_int_id := NULL;

        INSERT INTO alz_tobb_user_error (
                      v_errnum
                    , err_text
                    , creation_date
                    , email
                    , process)
             VALUES (v_errnum
                   , p_user_name || '-' || 'Kullanicisinin unsur �zerinde acente bilgisi mevcut de�il ya da kullaniciya end date verilmis'
                   , SYSDATE
                   , v_mail_adress
                   , 'ALZ_TOBB_USER/regenerateUserpassword');
    END;

  SELECT COUNT(*) INTO v_ghlth_portal_count
    FROM   ALZ_GHLTH_PORTAL_USER
    WHERE  user_name = p_user_name
    AND    validity_end_date is null;

    --ayk dan user_name bos geliyorsa (update edilecek password ayk de�ilse) tp i�in
    IF (vc_agent_int_id <> '12354' AND vc_agent_int_id IS NOT NULL) THEN
      v_errnum := 42;
      BEGIN
        SELECT DISTINCT a.user_name
                      , (SELECT DISTINCT x.parent_agent_int_id
                           FROM koc_dmt_agents_ext x
                          WHERE x.int_id = d.int_id)
                      , --d.int_id,mail-sms Ana partaja g�nderiliyor
                       c.identity_no
                      , b.first_name
                      , b.surname
          INTO v_user_name
             , v_agent_int_id
             , v_tckn
             , v_name
             , v_surname
          FROM web_sec_system_users a
             , cp_partners b
             , koc_cp_partners_ext c
             , dmt_agents d
         WHERE a.customer_partner_id = b.part_id
           AND b.part_id = c.part_id
           AND c.agen_int_id = d.int_id
           AND a.user_name = p_user_name
           AND (a.end_date > TRUNC (SYSDATE) OR a.end_date IS NULL);
      EXCEPTION
        WHEN OTHERS THEN
          v_user_name := NULL;
          v_agent_int_id := NULL;
          v_tckn := NULL;
          v_gsm_no := NULL;
          v_mail_adress := NULL;
      END;
      v_errnum := 44;
      --
      BEGIN -- ENGINT company_code added
        SELECT DISTINCT e.mobile
                      , e.email
                      , NVL (company_code, '045') company_code
          INTO v_gsm_no
             , v_mail_adress
             , v_company_code
          FROM koc_dmt_agents_ext e
         WHERE e.int_id = v_agent_int_id;
      EXCEPTION
        WHEN OTHERS THEN
          v_gsm_no := NULL;
          v_mail_adress := NULL;
          v_company_code := NULL;
      END;

      IF (v_gsm_no IS NULL OR v_mail_adress IS NULL OR v_agent_int_id IS NULL) THEN
        IF v_gsm_no IS NULL THEN
          v_err_text := p_user_name || '-' || 'Kullanicisinin acyk �zerinde telefon numaras� tanimli degil';
        ELSIF v_mail_adress IS NULL THEN
          v_err_text := p_user_name || '-' || 'Kullanicisinin acyk �zerinde mail adresi tanimli degil';
        ELSIF v_agent_int_id IS NULL THEN
          v_err_text := p_user_name || '-' || 'Kullanicisinin acentesi tanimli degil';
        END IF;

        v_errnum := 45;

        INSERT INTO alz_tobb_user_error (
                      v_errnum
                    , err_text
                    , creation_date
                    , process)
             VALUES (v_errnum
                   , v_err_text
                   , SYSDATE
                   , 'ALZ_TOBB_USER/regenerateUserpassword');
      END IF;
    ELSIF (vc_agent_int_id = '12354') THEN
      --User� girilen kullan�c�(�ifremi unuttum yapan) teknik personel de�il ise unsur �zerinden bilgileri al�n�yor
      v_errnum := 46;
      BEGIN
        SELECT DISTINCT a.user_name
                      , d.int_id
                      , NVL ( (SELECT x.company_code
                                 FROM koc_dmt_agents_ext x
                                WHERE x.int_id = d.int_id)
                           , '045')
                          company_code
                      , c.identity_no
                      , b.first_name
                      , b.surname
                      , b.telephone
                      , b.email
          INTO v_user_name
             , v_agent_int_id
             , v_company_code
             , v_tckn
             , v_name
             , v_surname
             , v_gsm_no
             , v_mail_adress
          FROM web_sec_system_users a
             , cp_partners b
             , koc_cp_partners_ext c
             , dmt_agents d
         WHERE a.customer_partner_id = b.part_id
           AND b.part_id = c.part_id
           AND c.agen_int_id = d.int_id
           AND a.user_name = p_user_name
           AND (a.end_date > TRUNC (SYSDATE) OR a.end_date IS NULL);
      EXCEPTION
        WHEN OTHERS THEN
          v_user_name := NULL;
          v_reference_code := NULL;
          v_tckn := NULL;
          v_gsm_no := NULL;
          v_mail_adress := NULL;
          v_company_code := NULL;

          INSERT INTO alz_tobb_user_error (
                        v_errnum
                      , err_text
                      , creation_date
                      , process)
               VALUES (v_errnum
                     , p_user_name || '-' || 'Merkez kullan�c�s�nda eksik bilgiler mevcuttur.'
                     , SYSDATE
                     , 'ALZ_TOBB_USER/regenerateUserpassword');
      END;
  ELSIF (v_ghlth_portal_count > 0) THEN

        SELECT user_name,
               '045',
               name,
               surname,
               gsm,
               email
        INTO  v_user_name,
              v_company_code,
              v_name,
              v_surname,
              v_gsm_no,
              v_mail_adress
        FROM  ALZ_GHLTH_PORTAL_USER
        WHERE user_name = p_user_name
        AND   validity_end_date is null;

        IF (v_gsm_no IS NULL OR v_mail_adress IS NULL) THEN
            IF v_gsm_no IS NULL THEN
              v_err_text := p_user_name || '-' || 'Grup Sa�l�k Portal Kullanicisinin portal sisteminde telefon numaras� tanimli degil';
            ELSIF v_mail_adress IS NULL THEN
              v_err_text := p_user_name || '-' || 'Grup Sa�l�k Portal Kullanicisinin portal sisteminde mail adresi tanimli degil';
            END IF;

            v_errnum := 47;
            INSERT INTO alz_tobb_user_error (
                          v_errnum
                        , err_text
                        , creation_date
                        , process)
                 VALUES (v_errnum
                       , v_err_text
                       , SYSDATE
                       , 'ALZ_TOBB_USER/regenerateUserpassword');
        END IF;
    END IF;

    --
    v_errnum := 50;
    --AliSakalli TPA-FAZ3 TPA_104 - 15.02.2018
    IF v_company_code = '045' THEN
      v_mail_body := v_gsm_no || ' nolu cep telefonunuza ' || v_name || ' ' || v_surname || 'e ait yeni DigitALL sifresi sms olarak iletilmistir.';
      v_gsm_body := 'DigitALL sistemine ' || v_name || ' ' || v_surname || 'e ait ' || p_user_name || ' kullanici adi ve ' || v_new_password || ' sifre ile giris yapabilirsiniz.';
    ELSE
      v_mail_body := v_gsm_no || ' nolu cep telefonunuza ' || v_name || ' ' || v_surname || 'e ait yeni Allclub sifresi sms olarak iletilmistir.';
      v_gsm_body := 'Allclub sistemine ' || v_name || ' ' || v_surname || 'e ait ' || p_user_name || ' kullanici adi ve ' || v_new_password || ' sifre ile giris yapabilirsiniz.';
    END IF;

    --email
    IF v_mail_adress IS NOT NULL THEN
      alz_tobb_user.sendemail (v_mail_adress, v_mail_body, v_company_code);

      INSERT INTO alz_tobb_user_hist (
                    email
                  , v_errnum
                  , err_text
                  , creation_date)
           VALUES (v_mail_adress
                 , 14
                 , 'regenerateUserpassword/Basarili'
                 , SYSDATE);
    END IF;

    COMMIT;
    v_errnum := 60;

    ---sms
    IF v_gsm_no IS NOT NULL THEN
      alz_tobb_user.sendsms (v_gsm_no, v_gsm_body, v_company_code);

      INSERT INTO alz_tobb_user_hist (
                    gsm
                  , v_errnum
                  , err_text
                  , creation_date)
           VALUES (v_gsm_no
                 , 14
                 , 'regenerateUserpassword/Basarili'
                 , SYSDATE);
    END IF;

    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      v_msg  := SUBSTR (SQLERRM, 1, 3000);

      INSERT INTO alz_tobb_user_error (
                    v_errnum
                  , err_text
                  , creation_date
                  , request
                  , response
                  , email
                  , process)
           VALUES (v_errnum
                 , v_msg
                 , SYSDATE
                 , NULL
                 , NULL
                 , v_mail_adress
                 , 'ALZ_TOBB_USER/regenerateUserpassword');
  END;
  --
  PROCEDURE alz_tp_kontrol
  IS
    v_adim    VARCHAR2 (100);

    CURSOR c_list
    IS
        SELECT COUNT (*)
             , identity_no
             , agent_int_id
          FROM koc_dmt_agency_tech_emp a
         WHERE (a.validity_end_date IS NULL OR TRUNC (a.validity_end_date) > TRUNC (SYSDATE))
      GROUP BY identity_no, agent_int_id
        HAVING COUNT (identity_no) > 1;

    CURSOR c_ulist (
      p_identity_no VARCHAR2
    , p_agent_int_id VARCHAR2)
    IS
      SELECT *
        FROM koc_dmt_agency_tech_emp a
       WHERE identity_no = p_identity_no
         AND agent_int_id = p_agent_int_id
         AND (a.validity_end_date IS NULL OR TRUNC (a.validity_end_date) > TRUNC (SYSDATE))
         AND a.validity_start_date =
               (SELECT MIN (b.validity_start_date)
                  FROM koc_dmt_agency_tech_emp b
                 WHERE b.identity_no = p_identity_no
                   AND b.agent_int_id = p_agent_int_id
                   AND (b.validity_end_date IS NULL OR TRUNC (b.validity_end_date) > TRUNC (SYSDATE)))
         AND 1 <
               (SELECT COUNT (DISTINCT b.validity_start_date) --validity_start_date'i ayn� olan kay�tlar� alm�yoruz.
                  FROM koc_dmt_agency_tech_emp b
                 WHERE b.identity_no = p_identity_no
                   AND b.agent_int_id = p_agent_int_id
                   AND (b.validity_end_date IS NULL OR TRUNC (b.validity_end_date) > TRUNC (SYSDATE)));
  BEGIN
    v_adim := '10';

    FOR f_list IN c_list LOOP
      FOR f_ulist IN c_ulist (f_list.identity_no, f_list.agent_int_id) LOOP
        BEGIN
          v_adim := '20';

          UPDATE koc_dmt_agency_tech_emp x
             SET x.validity_end_date = TRUNC (SYSDATE) - 5
           WHERE x.identity_no = f_ulist.identity_no
             AND x.agent_int_id = f_ulist.agent_int_id
             AND x.validity_start_date = f_ulist.validity_start_date;

          COMMIT;
          v_adim := '30';

          INSERT INTO alz_tobb_end_tp (
                        agent_int_id
                      , emp_id_no
                      , identity_no
                      , employee_type
                      , employee_name
                      , employee_surname
                      , validity_start_date
                      , validity_end_date
                      , process_date)
               VALUES (f_ulist.agent_int_id
                     , f_ulist.emp_id_no
                     , f_ulist.identity_no
                     , f_ulist.employee_type
                     , f_ulist.employee_name
                     , f_ulist.employee_surname
                     , f_ulist.validity_start_date
                     , f_ulist.validity_end_date
                     , TRUNC (SYSDATE));

          COMMIT;
        EXCEPTION
          WHEN OTHERS THEN
            INSERT INTO alz_tobb_end_tp (
                          agent_int_id
                        , identity_no
                        , employee_name
                        , employee_surname
                        , process_date)
                 VALUES (f_ulist.agent_int_id
                       , f_ulist.identity_no
                       , v_adim
                       , v_adim
                       , TRUNC (SYSDATE));
        END;
      END LOOP;
    END LOOP;

    COMMIT;
  END;
  --
  PROCEDURE alz_bes_role_update (p_int_id NUMBER)
  IS
    --commit sonras� �al��mas� gerekiyor
    v_bes     NUMBER;
    v_user_ctrl VARCHAR2 (100);
    --Orhan Polat
    v_user_in_idm   BOOLEAN := false;
    v_carray_profile  customer.char_array;
    v_process_results customer.process_result_table;

    CURSOR c_user (pc_int_id NUMBER)
    IS
      SELECT DISTINCT ws.user_name
        FROM web_sec_system_users ws
           , koc_cp_partners_ext kcp
       WHERE ws.customer_partner_id = kcp.part_id AND (ws.end_date IS NULL OR TRUNC (end_date) > TRUNC (SYSDATE)) AND kcp.agen_int_id = pc_int_id;
  BEGIN
    BEGIN
      SELECT DISTINCT a.is_bes_authority
        INTO v_bes
        FROM koc_dmt_agents_ext a
       WHERE a.int_id = p_int_id;
    EXCEPTION
      WHEN OTHERS THEN
        v_bes  := NULL;
    END;

    IF v_bes = 1 THEN
      FOR c_u IN c_user (p_int_id) LOOP
        v_user_in_idm :=  CF_IDM_AUTHORIZATION.CHECK_IDM_SWITCH(c_u.user_name);
        BEGIN
          SELECT x.username
            INTO v_user_ctrl
            FROM koc_auth_user_role_rel x
           WHERE x.role_code = 'WPPPAGENT'
             AND x.username = c_u.user_name
             AND (x.validity_end_date IS NULL OR TRUNC (x.validity_end_date) > TRUNC (SYSDATE));
        EXCEPTION
          WHEN OTHERS THEN
            v_user_ctrl := NULL;
        END;

        IF v_user_ctrl IS NULL THEN
          BEGIN
            INSERT INTO koc_auth_user_role_rel (
                          username
                        , role_code
                        , validity_start_date)
                 VALUES (c_u.user_name
                       , 'WPPPAGENT'
                       , TRUNC (SYSDATE) - 3);
             ALZ_WEB_USER_UTILS.log_user_role_history(p_user_name       => c_u.user_name,
                              p_role_code       => 'WPPPAGENT',
                              p_action_type     => 'I',
                              p_update_user     => v_tobb_user_name,
                              p_process_results => v_process_results);
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
        END IF;
        IF v_user_in_idm THEN
           CF_IDM_UTILS.UPDATE_USER_PROFILE(c_u.user_name,v_AgencyBesProfile,'A',v_process_results);
        END IF;
        COMMIT;
      END LOOP;
    ELSE
      FOR c_u IN c_user (p_int_id) LOOP
        DELETE koc_auth_user_role_rel ka
         WHERE ka.role_code = 'WPPPAGENT' AND ka.username = c_u.user_name;
         ALZ_WEB_USER_UTILS.log_user_role_history(p_user_name       => c_u.user_name,
                              p_role_code       => 'WPPPAGENT',
                              p_action_type     => 'U',
                              p_update_user     => v_tobb_user_name,
                              p_process_results => v_process_results);
         IF v_user_in_idm THEN
            CF_IDM_UTILS.UPDATE_USER_PROFILE(c_u.user_name,v_AgencyBesProfile,'D',v_process_results);
         END IF;
      END LOOP;

      COMMIT;
    END IF;

    COMMIT;
  END;


   PROCEDURE alz_tp_user_control
  IS
    --Bu procedure ge�mi�e d�n�k en_date verilen teknik personellerin userlar�n� kapat�r

  v_record_count number;
  v_msg     VARCHAR2 (5000);

  cursor cr_user
  IS
         select q.* from web_sec_system_users q
            where q.user_name not in (
            select x.user_name from web_sec_system_users x
            where x.customer_partner_id in (
            SELECT  b.part_id
                    FROM  cp_partners b
                       , koc_cp_partners_ext c
                       , dmt_agents d
                       , koc_dmt_agents_ext e,
                       koc_dmt_agency_tech_emp f
                   WHERE  b.part_id = c.part_id
                     AND c.agen_int_id = d.int_id
                     AND d.int_id = e.int_id
                    and  f.AGENT_INT_ID = c.AGEN_INT_ID
                    and f.identity_no = c.identity_no
                    and (f.VALIDITY_END_DATE is null or trunc(f.VALIDITY_END_DATE) > trunc(sysdate))
                    AND e.signboard_no IS NOT NULL
                    AND e.int_id = f.agent_int_id
                    and e.mis_sub_group IN ('11', '12', '14', '61', '62', '63', '140'))
               and (x.end_date is null or trunc(x.end_date) > trunc(sysdate))
               )
            and
            q.user_name  in (
            select x.user_name from web_sec_system_users x
            where x.customer_partner_id in (
            SELECT  b.part_id
                    FROM  cp_partners b
                       , koc_cp_partners_ext c
                       , dmt_agents d
                       , koc_dmt_agents_ext e,
                       koc_dmt_agency_tech_emp f
                   WHERE  b.part_id = c.part_id
                     AND c.agen_int_id = d.int_id
                     AND d.int_id = e.int_id
                    and  f.AGENT_INT_ID = c.AGEN_INT_ID
                    and f.identity_no = c.identity_no
                    and (f.VALIDITY_END_DATE is not null and trunc(f.VALIDITY_END_DATE) < trunc(sysdate))
                    AND e.signboard_no IS NOT NULL
                    AND e.int_id = f.agent_int_id
                    and e.mis_sub_group IN ('11', '12', '14', '61', '62', '63', '140'))
               and (x.end_date is null or trunc(x.end_date) > trunc(sysdate))
                    )
            and (q.end_date is null or trunc(q.end_date) > trunc(sysdate));

  BEGIN

     v_record_count:=0;


      for cr in cr_user
      loop

         update web_sec_system_users x
         set x.end_date = sysdate
         where x.user_name = cr.user_name
           and (x.end_date is null or trunc(x.end_date) >= trunc(sysdate));

           v_record_count:=v_record_count+1;

      end loop;

      insert into ALZ_TOBB_HEADER(PROCESS_NAME,TOTAL_RECORD,PROCESS_DATE) values
                           ('Alz_tobb_user/alz_tp_user_control',v_record_count,sysdate);

  COMMIT;
  exception when others then

    v_msg  := SUBSTR (SQLERRM, 1, 3000);

      INSERT INTO alz_tobb_user_error (
                    v_errnum
                  , err_text
                  , creation_date
                  , request
                  , response
                  , email
                  , process)
           VALUES (0
                 , v_msg
                 , SYSDATE
                 , NULL
                 , NULL
                 , null
                 , 'ALZ_TOBB_USER/alz_tp_user_control');

  END;


   PROCEDURE alz_dap_role_update
   IS

    v_record_count number;
    --Orhan Polat
    v_user_in_idm   BOOLEAN := false;
    v_carray_profile  customer.char_array;
    v_process_results customer.process_result_table;

     --DAPMERKEZ rolu olmayan yetkili kullan�c�lar
     --Teknik Personel sonradan m�d�r,m�d�r yrd vs.oldu�unda batch ile DAPMERKEZ verilmesi talebi ile yaz�lm��t�r
      cursor cr_role_ins is
          select us.* from koc_dmt_agency_tech_emp t,
                           koc_cp_partners_ext cp,
                           web_sec_system_users us
            where t.identity_no = cp.identity_no
              and t.agent_int_id = cp.agen_int_id
              and cp.part_id = us.customer_partner_id
              and (us.end_date is null or trunc(us.end_date) > trunc(sysdate))
              and t.employee_type in ('1', '2', '4', '8', '9', '11')
              and ( t.VALIDITY_END_DATE is null or trunc(t.VALIDITY_END_DATE) > trunc(sysdate))
              and us.user_name not in (
                                SELECT rl.USERNAME
                                FROM koc_auth_user_role_rel rl
                                WHERE rl.role_code IN ('DAPMERKEZ')
                                AND (rl.validity_end_date IS NULL OR TRUNC (rl.validity_end_date) > TRUNC (SYSDATE)));


          cursor cr_role_del is
              select us.* from koc_dmt_agency_tech_emp t,
                           koc_cp_partners_ext cp,
                           web_sec_system_users us
            where t.identity_no = cp.identity_no
              and t.agent_int_id = cp.agen_int_id
              and cp.part_id = us.customer_partner_id
              and (us.end_date is null or trunc(us.end_date) > trunc(sysdate))
              and t.employee_type not in ('1', '2', '4', '8', '9', '11')
              and ( t.VALIDITY_END_DATE is null or trunc(t.VALIDITY_END_DATE) > trunc(sysdate))
              and us.user_name  in (
                                SELECT rl.USERNAME
                                FROM koc_auth_user_role_rel rl
                                WHERE rl.role_code IN ('DAPMERKEZ')
                                AND (rl.validity_end_date IS NULL OR TRUNC (rl.validity_end_date) > TRUNC (SYSDATE)));


   begin

       v_record_count:=0;

      for cr in cr_role_ins
      loop
        v_user_in_idm :=  CF_IDM_AUTHORIZATION.CHECK_IDM_SWITCH(cr.user_name);

        begin
          INSERT INTO koc_auth_user_role_rel (
                            username
                          , role_code
                          , validity_start_date)
                   VALUES (cr.user_name
                         , 'DAPMERKEZ'
                         , TRUNC(SYSDATE));
            ALZ_WEB_USER_UTILS.log_user_role_history(p_user_name       => cr.user_name,
                              p_role_code       => 'DAPMERKEZ',
                              p_action_type     => 'I',
                              p_update_user     => v_tobb_user_name,
                              p_process_results => v_process_results);
         exception when others then
           null;
         end;
         IF v_user_in_idm THEN
            CF_IDM_UTILS.UPDATE_USER_PROFILE(cr.user_name,v_DapMerkezProfile,'A',v_process_results);
         END IF;
        v_record_count:=v_record_count+1;

      end loop;

       insert into ALZ_TOBB_HEADER(PROCESS_NAME,TOTAL_RECORD,PROCESS_DATE) values
                           ('Alz_tobb_user/alz_dap_role_update/ins',v_record_count,sysdate);

        v_record_count:=0;

      for cr in cr_role_del
      loop

           update koc_auth_user_role_rel a
           set A.VALIDITY_END_DATE = trunc(sysdate)
           where A.USERNAME = cr.user_name
             and A.ROLE_CODE = 'DAPMERKEZ';
           ALZ_WEB_USER_UTILS.log_user_role_history(p_user_name       => cr.user_name,
                              p_role_code       => 'DAPMERKEZ',
                              p_action_type     => 'U',
                              p_update_user     => v_tobb_user_name,
                              p_process_results => v_process_results);
           IF v_user_in_idm THEN
              CF_IDM_UTILS.UPDATE_USER_PROFILE(cr.user_name,v_DapMerkezProfile,'D',v_process_results);
           END IF;
      end loop;

        insert into ALZ_TOBB_HEADER(PROCESS_NAME,TOTAL_RECORD,PROCESS_DATE) values
                           ('Alz_tobb_user/alz_dap_role_update/del',v_record_count,sysdate);


   commit;
   end;

   PROCEDURE alz_trafik_role_update (p_int_id NUMBER)
  IS
    --commit sonras� �al��mas� gerekiyor
    v_trafik     NUMBER;
    v_user_ctrl VARCHAR2 (100);
    --Orhan Polat
    v_user_in_idm   BOOLEAN := false;
    v_carray_profile  customer.char_array;
    v_process_results customer.process_result_table;

    CURSOR c_user (pc_int_id NUMBER)
    IS
      SELECT DISTINCT ws.user_name
        FROM web_sec_system_users ws
           , koc_cp_partners_ext kcp
       WHERE ws.customer_partner_id = kcp.part_id AND (ws.end_date IS NULL OR TRUNC (end_date) > TRUNC (SYSDATE)) AND kcp.agen_int_id = pc_int_id;
  BEGIN
    BEGIN
      SELECT DISTINCT a.AGENCY_MENU_TYPE
        INTO v_trafik
        FROM koc_dmt_agents_ext a
       WHERE a.int_id = p_int_id;
    EXCEPTION
      WHEN OTHERS THEN
        v_trafik  := NULL;
    END;

    IF v_trafik = 1 THEN
      FOR c_u IN c_user (p_int_id) LOOP
        BEGIN
          SELECT x.username
            INTO v_user_ctrl
            FROM koc_auth_user_role_rel x
           WHERE x.role_code = 'WPMTPLMADF'
             AND x.username = c_u.user_name
             AND (x.validity_end_date IS NULL OR TRUNC (x.validity_end_date) > TRUNC (SYSDATE));
        EXCEPTION
          WHEN OTHERS THEN
            v_user_ctrl := NULL;
        END;
        v_user_in_idm :=  CF_IDM_AUTHORIZATION.CHECK_IDM_SWITCH(c_u.user_name);
        IF v_user_ctrl IS NULL THEN
          BEGIN
            INSERT INTO koc_auth_user_role_rel (
                          username
                        , role_code
                        , validity_start_date)
                 VALUES (c_u.user_name
                       , 'WPMTPLMADF'
                       , TRUNC (SYSDATE) - 3);
             ALZ_WEB_USER_UTILS.log_user_role_history(p_user_name       => c_u.user_name,
                              p_role_code       => 'WPMTPLMADF',
                              p_action_type     => 'I',
                              p_update_user     => v_tobb_user_name,
                              p_process_results => v_process_results);
             INSERT INTO koc_auth_user_role_rel (
                          username
                        , role_code
                        , validity_start_date)
                VALUES (c_u.user_name
                       , 'WPTAGENTP'
                       , TRUNC (SYSDATE) - 3);
              ALZ_WEB_USER_UTILS.log_user_role_history(p_user_name       => c_u.user_name,
                              p_role_code       => 'WPTAGENTP',
                              p_action_type     => 'I',
                              p_update_user     => v_tobb_user_name,
                              p_process_results => v_process_results);
          EXCEPTION
            WHEN OTHERS THEN
              NULL;
          END;
          IF v_user_in_idm THEN
            CF_IDM_UTILS.UPDATE_USER_PROFILE(c_u.user_name,v_AgencyTrafficProfile,'A',v_process_results);
         END IF;
        END IF;

        COMMIT;
      END LOOP;
    ELSE
      FOR c_u IN c_user (p_int_id) LOOP
        DELETE koc_auth_user_role_rel ka
         WHERE ka.role_code = 'WPMTPLMADF' AND ka.username = c_u.user_name;

         ALZ_WEB_USER_UTILS.log_user_role_history(p_user_name       => c_u.user_name,
                              p_role_code       => 'WPMTPLMADF',
                              p_action_type     => 'U',
                              p_update_user     => v_tobb_user_name,
                              p_process_results => v_process_results);
         DELETE koc_auth_user_role_rel ka
         WHERE ka.role_code = 'WPTAGENTP' AND ka.username = c_u.user_name;

         ALZ_WEB_USER_UTILS.log_user_role_history(p_user_name       => c_u.user_name,
                              p_role_code       => 'WPTAGENTP',
                              p_action_type     => 'U',
                              p_update_user     => v_tobb_user_name,
                              p_process_results => v_process_results);
         IF v_user_in_idm THEN
            CF_IDM_UTILS.UPDATE_USER_PROFILE(c_u.user_name,v_AgencyTrafficProfile,'D',v_process_results);
         END IF;
      END LOOP;

      COMMIT;
    END IF;

    COMMIT;
  END;

END alz_tobb_user;

/
