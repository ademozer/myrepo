SELECT '�denen Hasar' Rapor,
       TIP,D_E,YIL,G_B, 
       Round(Sum(Borc),2) Borc,
       Round(Sum(Alacak),2) Alacak,
       Round(Sum(Fark),2) Fark 
FROM
(select  
  CASE WHEN REGEXP_COUNT(t.Explanation, 'KISM� FATURA �ADES�') > 0 THEN 'iade' 
       WHEN REGEXP_COUNT(t.Explanation, '�SKONTO') > 0 THEN 'iskonto'
       WHEN REGEXP_COUNT(t.Explanation, 'EXGRATIA') > 0 THEN 'exgratia'
       WHEN t.Account_Code IN ('7850211105', '7850211106') THEN 'Dosya Masraf�'
       WHEN t.Account_Code IN ('7850211201', '7850211203') THEN 'R�cu'
       ELSE '�deme' END TIP, 
       CASE WHEN t.Account_Code IN ('7850211101', '7850211103') THEN 'Direkt'
            WHEN t.Account_Code IN ('7850211102', '7850211104') THEN 'Endirekt'                                                  
            ELSE ''
       END D_E,
       CASE WHEN t.Account_Code IN ('7850211101', '7850211102') THEN 'Cari Y�l'
            WHEN t.Account_Code IN ('7850211103', '7850211104') THEN '�nceki Y�l'                                                 
            ELSE ''
       END YIL,
       CASE t.Product_Id
            WHEN 63 THEN 'Bireysel'
            WHEN 64 THEN 'Grup'
            ELSE TO_CHAR(t.Product_Id)
       END G_B,
       Nvl(t.Borc, 0) Borc,
       Nvl(t.Alacak, 0) Alacak,
       (Nvl(t.Borc,0)  - Nvl(t.Alacak,0)) Fark      
  From Koc_Acc_v_Posting_Details t, Koc_Dmt_Agents_Ext x
 Where t.Account_Code In ('7850211101',
                          '7850211103',
                          '7850211102',
                          '7850211104',
                          '7850211105',
                          '7850211106',
                          '7850211201',
                          '7850211203')
   And t.Agent_Int_Id = x.Int_Id
                   And x.Company_Code = '777'                     
   And t.Posting_Date Between to_date('01/02/2018', 'dd/mm/yyyy') and
       to_date('19/02/2018', 'dd/mm/yyyy'))
 GROUP BY TIP,D_E,YIL,G_B
  --where tip NOT IN ('�deme','iade')
