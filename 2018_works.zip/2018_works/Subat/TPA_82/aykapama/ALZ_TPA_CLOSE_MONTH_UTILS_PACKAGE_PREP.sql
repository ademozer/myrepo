
  CREATE OR REPLACE PACKAGE "CUSTOMER"."ALZ_TPA_CLOSE_MONTH_UTILS" As
  Type Refcur Is Ref Cursor;
  R_Pro_Res_Rec Alz_Mdlr_Hlth_Hpf_Utils.Process_Results_Rec;
  Ex_Business_Rule   Exception;
  v_TPA_Allianz      Varchar2(10) := '045';

  Function Get_Company_Premium(P_Company_Code In Varchar2) Return Number;
  Function Get_Company_Damage_Paid(P_Company_Code In Varchar2) Return Number;
  Function Get_Company_Suspense(P_Company_Code In Varchar2) Return Number;
  Function Get_Company_KPK(P_Company_Code In Varchar2) Return Number;
  Procedure Get_Close_Month_List (P_Company_Code           In Varchar2,
                                  P_Period                 In Varchar2,
                                  P_Rapor                  In Varchar2,--1.�denen,2.Muallak,3.�retim,4.KPK
                                  P_Close_Month_List_Cur   Out    Refcur,
                                  P_Process_Results        In Out Process_Result_Table
                                  );

End ALZ_TPA_CLOSE_MONTH_UTILS;

CREATE OR REPLACE PACKAGE BODY "CUSTOMER"."ALZ_TPA_CLOSE_MONTH_UTILS" As

  Function Get_Company_Premium(P_Company_Code In Varchar2) Return Number Is
    v_ToplamYazilanPrim Number := 0;
  Begin
    Select nvl(Sum(nvl(Net_Premium,0)-nvl(Karpaylasim,0)),0) ToplamYazilanPrim into v_ToplamYazilanPrim From (
    Select a.Company_Code,nvl(x.expense_ratio,0) expense_ratio,
           round(Sum(Nvl(a.t_Final_Premium, 0))*nvl(x.expense_ratio,0)/100,2) Karpaylasim,
           Sum(Nvl(a.t_Final_Premium, 0)) Premium_Amount,
           Sum(Nvl(a.t_Agent_Commission, 0)) Agent_Commission,
           Sum(Nvl(a.t_Final_Premium, 0) - Nvl(a.t_Agent_Commission, 0)) Net_Premium
      From Koc_Agency_Par_Final           a,
           Koc_Agency_Par_Order_Info      b,
           Alz_Tpa_Profit_Commissionratio x
     Where b.Year = a.Year
       And b.Month = a.Month
       And b.Order_No = a.Order_No
       And a.In_Out_Branch_Id = b.Branch_Id
       And a.Company_Code <> '045'
       And a.Company_Code = P_Company_Code
       And a.Company_Code = x.Company_Code(+)
       And a.term_start_date Between x.start_date And Nvl(x.end_date, Trunc(Sysdate)+ 1)
    Group By a.Company_Code,nvl(x.expense_ratio,0));

    Return v_ToplamYazilanPrim;

  Exception
    When No_Data_Found Then
      Return v_ToplamYazilanPrim;
  End;
  ---------------
  Function Get_Company_Damage_Paid(P_Company_Code In Varchar2) Return Number Is
    v_ToplamOdenenHasar Number := 0;
  Begin
    select nvl(Sum(Toplam),0) OdenenHasar into v_ToplamOdenenHasar from (
    Select x.Company_Code,t.Agent_Int_Id,t.Sap_Dist_Channel,
           Sum(Nvl(t.Borc,0)) Borc,
           Sum(Nvl(t.Alacak,0)) Alacak,
           Sum(Nvl(t.Borc,0)-Nvl(t.Alacak,0)) Toplam
      From Koc_Acc_v_Posting_Details t, Alz_Tpa_v_Koc_Dmt_Agents_Ext x
     Where t.Account_Code In ('7850211102', '7850211104')
       And t.Agent_Int_Id = x.Int_Id(+)
       And x.Company_Code <> '045'
       And x.Company_Code = P_Company_Code
     Group By x.Company_Code, t.Agent_Int_Id, t.Sap_Dist_Channel
     );

    Return v_ToplamOdenenHasar;

  Exception
    When No_Data_Found Then
      Return v_ToplamOdenenHasar;
  End;
  ---------------
  Function Get_Company_Suspense(P_Company_Code In Varchar2) Return Number Is
    v_SonDonemMuallak Number := 0;
  Begin
    Select nvl(Sum(SonDonemMuallak),0) SonDonemMuallak into v_SonDonemMuallak From (
    Select x.company_code,sum(nvl(t.trans_amt,0)) SonDonemMuallak
    From koc_clm_muallak_bordro_rep t, Alz_Tpa_v_Koc_Dmt_Agents_Ext x
    where trunc(t.ticket_date) between TRUNC(TO_DATE(TRUNC(TO_DATE(trunc(sysdate),'DD/MM/YYYY'),'MM')-1,'DD/MM/YYYY'),'MM') and TRUNC(TO_DATE(trunc(sysdate),'DD/MM/YYYY'),'MM')-1
     and t.Agent_Role = x.int_id(+)
     and x.Company_Code <> '045'
     And x.Company_Code = P_Company_Code
    group by x.company_code
    );

    Return v_SonDonemMuallak;

  Exception
    When No_Data_Found Then
      Return v_SonDonemMuallak;
  End;
  ---------------
  Function Get_Company_KPK(P_Company_Code In Varchar2) Return Number Is
    v_SonDonemKPK Number := 0;
  Begin
    Select nvl(Sum(SonDonemKPK),0) SonDonemKPK into v_SonDonemKPK From (
    Select x.company_code,nvl(sum(nvl(t.cmi_premium,0)-nvl(t.cmi_agency,0)-nvl(round((nvl(t.cmi_premium,0)*nvl(xx.expense_ratio,0)/100),2),0)),0) SonDonemKPK
    From KOC_CMI_PRO_RATA t, Koc_Cmi_Process_Close_Info b ,Alz_Tpa_v_Koc_Dmt_Agents_Ext x, Alz_Tpa_Profit_Commissionratio xx
     Where b.Roll_Month = To_Char(Trunc(To_Date(Trunc(Sysdate), 'DD/MM/YYYY'), 'MM') - 1,'MMYYYY')
       And b.Is_Industrial = 1
       And b.Branch_Ext_Ref = '20'
       And b.order_no = t.order_no
       and t.is_industrial = b.is_industrial
       And t.Agent_Role = x.int_id(+)
       And x.Company_Code <> '045'
       And x.Company_Code = P_Company_Code
       And x.Company_Code = xx.Company_Code(+)
       And t.term_start_date Between xx.start_date And Nvl(xx.end_date, Trunc(Sysdate)+ 1)
    group by x.company_code);

    Return v_SonDonemKPK;

  Exception
    When No_Data_Found Then
      Return v_SonDonemKPK;
  End;
  ---------------
  Procedure Get_Close_Month_List (P_Company_Code           In Varchar2,
                                  P_Period                 In Varchar2,
                                  P_Rapor                  In Varchar2,
                                  P_Close_Month_List_Cur   Out    Refcur,
                                  P_Process_Results        In Out Process_Result_Table
                                  ) Is
    V_Result        Refcur;
    v_AyKapalimi    Number;
    v_firstday      Date;
    v_lastday       Date;
    V_Proc          Constant Varchar2(100) := Initcap($$PLSQL_UNIT) || '.' || 'Get_Close_Month_List';
  Begin
    R_pro_res_rec                  := Null;
    R_pro_res_rec.Error_Origin     := V_Proc;

    if (P_Company_Code Is Null) Then
      R_Pro_Res_Rec.Reason  := 'D�nem Bilgisi Bo� Olamaz.';
      Raise Ex_Business_Rule;
    End if;

    if (P_Period Is Null) Then
      R_Pro_Res_Rec.Reason  := '�irket Bilgisi Bo� Olamaz.';
      Raise Ex_Business_Rule;
    End if;

    select To_Date('01'||P_Period,'DDMMYYYY'),last_day(To_Date('01'||P_Period,'DDMMYYYY')) into v_firstday,v_lastday from dual;

    select nvl(count(1),0) into v_AyKapalimi from KOC_PROCESS_CLOSE t
    where t.close_date = v_lastday
      and t.process_type = 'ACCH'
      and t.status_code = 2;

    if (v_AyKapalimi=0) Then
      R_Pro_Res_Rec.Reason  := 'D�nem Kapanmam��t�r.';
      Raise Ex_Business_Rule;
    End if;

    if (P_Rapor in (4,7)) And (P_Company_Code is Null or P_Company_Code = '045') Then
      R_Pro_Res_Rec.Reason  := 'Allianz i�in KPK Datas� �ekilememektedir.';
      Raise Ex_Business_Rule;
    End if;

    if P_Rapor = 1 Then--1.�denen Hasar
        if P_Company_Code = v_TPA_Allianz Then
          Open V_Result For
                Select '�denen Hasar' Rapor,
                   Decode(REGEXP_COUNT(t.Explanation, 'KISM� FATURA �ADES�', 1, 'i'),0,
                          Decode(REGEXP_COUNT(t.Explanation, '�SKONTO', 1, 'i'),0,
                                 Decode(t.Account_Code,'7850211105','Dosya Masraf�',
                                                       '7850211106','Dosya Masraf�',
                                                       '7850211201','Ruc�',
                                                       '7850211203','Ruc�',
                                 '�deme'),
                                 'iskonto'),
                          'iade') Tip,
                    CASE t.Account_Code
                           WHEN '7850211101' THEN 'Direkt'
                           WHEN '7850211103' THEN 'Direkt'
                           WHEN '7850211102' THEN 'Endirekt'
                           WHEN '7850211104' THEN 'Endirekt'
                           ELSE ''
                    END D_E,
                    CASE t.Account_Code
                           WHEN '7850211101' THEN 'Cari Y�l'
                           WHEN '7850211102' THEN 'Cari Y�l'
                           WHEN '7850211103' THEN '�nceki Y�l'
                           WHEN '7850211104' THEN '�nceki Y�l'
                           ELSE ''
                    END YIL,
                    Decode(t.Product_Id,63,'Bireysel',64,'Grup',t.Product_Id) G_B,
                       Round(Sum(Nvl(t.Borc,0)),2) Borc,
                       Round(Sum(Nvl(t.Alacak,0)),2) Alacak,
                       Round(Sum(Nvl(t.Borc,0)-Nvl(t.Alacak,0)),2) FARK
                  From Koc_Acc_v_Posting_Details t
                Where t.Account_Code In ('7850211101', '7850211103', '7850211102', '7850211104',
                                          '7850211105', '7850211106', '7850211201', '7850211203')
                   And t.Posting_Date Between to_date(v_firstday,'dd/mm/yyyy') and to_date(v_lastday,'dd/mm/yyyy')
                Group By
                    CASE t.Account_Code
                           WHEN '7850211101' THEN 'Direkt'
                           WHEN '7850211103' THEN 'Direkt'
                           WHEN '7850211102' THEN 'Endirekt'
                           WHEN '7850211104' THEN 'Endirekt'
                           ELSE ''
                    END,
                    CASE t.Account_Code
                           WHEN '7850211101' THEN 'Cari Y�l'
                           WHEN '7850211102' THEN 'Cari Y�l'
                           WHEN '7850211103' THEN '�nceki Y�l'
                           WHEN '7850211104' THEN '�nceki Y�l'
                           ELSE ''
                    END,
                    Decode(t.Product_Id,63,'Bireysel',64,'Grup',t.Product_Id)
                    ,Decode(REGEXP_COUNT(t.Explanation, 'KISM� FATURA �ADES�', 1, 'i'),0,
                          Decode(REGEXP_COUNT(t.Explanation, '�SKONTO', 1, 'i'),0,
                                 Decode(t.Account_Code,'7850211105','Dosya Masraf�',
                                                       '7850211106','Dosya Masraf�',
                                                       '7850211201','Ruc�',
                                                       '7850211203','Ruc�',
                                 '�deme'),
                                 'iskonto'),
                          'iade');
        else
          Open V_Result For
                Select '�denen Hasar' Rapor,
                   Decode(REGEXP_COUNT(t.Explanation, 'KISM� FATURA �ADES�', 1, 'i'),0,
                          Decode(REGEXP_COUNT(t.Explanation, '�SKONTO', 1, 'i'),0,
                                 '�deme',
                                 'iskonto'),
                          'iade') Tip,
                    CASE t.Account_Code
                           WHEN '7850211102' THEN 'Direkt'
                           WHEN '7850211104' THEN 'Direkt'
                           ELSE ''
                    END D_E,
                    CASE t.Account_Code
                           WHEN '7850211102' THEN 'Cari Y�l'
                           WHEN '7850211104' THEN '�nceki Y�l'
                           ELSE ''
                    END YIL,
                    Decode(t.Product_Id,63,'Bireysel',64,'Grup',t.Product_Id) G_B,
                       Round(Sum(Nvl(t.Borc,0)),2) Borc,
                       Round(Sum(Nvl(t.Alacak,0)),2) Alacak,
                       Round(Sum(Nvl(t.Borc,0)-Nvl(t.Alacak,0)),2) FARK
                  From Koc_Acc_v_Posting_Details t, Koc_Dmt_Agents_Ext x
                Where t.Account_Code In ('7850211102', '7850211104')
                   And t.Agent_Int_Id = x.Int_Id
                   And x.Company_Code = P_Company_Code
                   And t.Posting_Date Between to_date(v_firstday,'dd/mm/yyyy') and to_date(v_lastday,'dd/mm/yyyy')
                Group By
                    CASE t.Account_Code
                           WHEN '7850211102' THEN 'Direkt'
                           WHEN '7850211104' THEN 'Direkt'
                           ELSE ''
                    END,
                    CASE t.Account_Code
                           WHEN '7850211102' THEN 'Cari Y�l'
                           WHEN '7850211104' THEN '�nceki Y�l'
                           ELSE ''
                    END,
                    Decode(t.Product_Id,63,'Bireysel',64,'Grup',t.Product_Id)
                    ,Decode(REGEXP_COUNT(t.Explanation, 'KISM� FATURA �ADES�', 1, 'i'),0,
                          Decode(REGEXP_COUNT(t.Explanation, '�SKONTO', 1, 'i'),0,
                                 '�deme',
                                 'iskonto'),
                          'iade');
        end if;
    elsif P_Rapor = 2 Then--2.Muallak
       if P_Company_Code = v_TPA_Allianz Then
          Open V_Result For
            Select 'Muallak' Rapor,
                   'Muallak' Tip,
                    CASE t.Account_Code
                           WHEN '7850211101' THEN 'Direkt'
                           WHEN '7850221105' THEN 'Direkt'
                           WHEN '7850221102' THEN 'Endirekt'
                           WHEN '7850221119' THEN 'Endirekt'
                           ELSE ''
                    END D_E,
                    CASE t.Account_Code
                           WHEN '7850221101' THEN 'Cari Y�l'
                           WHEN '7850221102' THEN 'Cari Y�l'
                           WHEN '7850221119' THEN '�nceki Y�l'
                           WHEN '7850221105' THEN '�nceki Y�l'
                           ELSE ''
                    END YIL,
                    Decode(t.Product_Id,63,'Bireysel',64,'Grup',t.Product_Id) G_B,
                       Round(Sum(Nvl(t.Borc,0)),2) Borc,
                       Round(Sum(Nvl(t.Alacak,0)),2) Alacak,
                       Round(Sum(Nvl(t.Borc,0)-Nvl(t.Alacak,0)),2) FARK
                  From Koc_Acc_v_Posting_Details t
            Where t.Account_Code In ('7850211101', '7850211102', '7850211105', '7850221119')
              And t.Posting_Date Between to_date(v_firstday,'dd/mm/yyyy') and to_date(v_lastday,'dd/mm/yyyy')
            Group By
                    CASE t.Account_Code
                           WHEN '7850211101' THEN 'Direkt'
                           WHEN '7850221105' THEN 'Direkt'
                           WHEN '7850221102' THEN 'Endirekt'
                           WHEN '7850221119' THEN 'Endirekt'
                           ELSE ''
                    END,
                    CASE t.Account_Code
                           WHEN '7850221101' THEN 'Cari Y�l'
                           WHEN '7850221102' THEN 'Cari Y�l'
                           WHEN '7850221119' THEN '�nceki Y�l'
                           WHEN '7850221105' THEN '�nceki Y�l'
                           ELSE ''
                    END,
                    Decode(t.Product_Id,63,'Bireysel',64,'Grup',t.Product_Id)
                    ;
        else
          Open V_Result For
            Select 'Muallak' Rapor,
                   'Muallak' Tip,
                    CASE t.Account_Code
                           WHEN '7850221102' THEN 'Direkt'
                           WHEN '7850221119' THEN 'Direkt'
                           ELSE ''
                    END D_E,
                    CASE t.Account_Code
                           WHEN '7850221102' THEN 'Cari Y�l'
                           WHEN '7850221119' THEN '�nceki Y�l'
                           ELSE ''
                    END YIL,
                    Decode(t.Product_Id,63,'Bireysel',64,'Grup',t.Product_Id) G_B,
                       Round(Sum(Nvl(t.Borc,0)),2) Borc,
                       Round(Sum(Nvl(t.Alacak,0)),2) Alacak,
                       Round(Sum(Nvl(t.Borc,0)-Nvl(t.Alacak,0)),2) FARK
                  From Koc_Acc_v_Posting_Details t, Koc_Dmt_Agents_Ext x
            Where t.Account_Code In ('7850221102', '7850221119')
          And t.Agent_Int_Id = x.Int_Id
        And x.Company_Code = P_Company_Code
        And t.Posting_Date Between to_date(v_firstday,'dd/mm/yyyy') and to_date(v_lastday,'dd/mm/yyyy')
            Group By
                    CASE t.Account_Code
                           WHEN '7850221102' THEN 'Direkt'
                           WHEN '7850221119' THEN 'Direkt'
                           ELSE ''
                    END,
                    CASE t.Account_Code
                           WHEN '7850221102' THEN 'Cari Y�l'
                           WHEN '7850221119' THEN '�nceki Y�l'
                           ELSE ''
                    END,
                    Decode(t.Product_Id,63,'Bireysel',64,'Grup',t.Product_Id)
                    ;
        end if;
    elsif P_Rapor = 3 Then--3.�retim
       if P_Company_Code = v_TPA_Allianz Then
          Open V_Result For
                Select '�retim' Rapor,
                    CASE t.Account_Code
                           WHEN '7850211101' THEN 'Prim'
                           WHEN '7850111002' THEN 'Prim'
                           WHEN '7850257008' THEN 'Komisyon'
                           WHEN '7850221105' THEN 'Komisyon'
                           ELSE ''
                    END Tip,
                    CASE t.Account_Code
                           WHEN '7850211101' THEN 'Direkt'
                           WHEN '7850221105' THEN 'Direkt'
                           WHEN '7850111002' THEN 'Endirekt'
                           WHEN '7850257008' THEN 'Endirekt'
                           ELSE ''
                    END D_E,
                    ''YIL,
                    Decode(t.Product_Id,63,'Bireysel',64,'Grup',t.Product_Id) G_B,
                       Round(Sum(Nvl(t.Borc,0)),2) Borc,
                       Round(Sum(Nvl(t.Alacak,0)),2) Alacak,
                       Round(Sum(Nvl(t.Borc,0)-Nvl(t.Alacak,0)),2) FARK
                  From Koc_Acc_v_Posting_Details t
                Where t.Account_Code In ('7850211101','7850221105','7850111002','7850257008')
                  And t.Posting_Date Between to_date(v_firstday,'dd/mm/yyyy') and to_date(v_lastday,'dd/mm/yyyy')
                Group By
                    CASE t.Account_Code
                           WHEN '7850211101' THEN 'Direkt'
                           WHEN '7850221105' THEN 'Direkt'
                           WHEN '7850111002' THEN 'Endirekt'
                           WHEN '7850257008' THEN 'Endirekt'
                           ELSE ''
                    END,
                    CASE t.Account_Code
                           WHEN '7850211101' THEN 'Prim'
                           WHEN '7850111002' THEN 'Prim'
                           WHEN '7850257008' THEN 'Komisyon'
                           WHEN '7850221105' THEN 'Komisyon'
                           ELSE ''
                    END,
                    Decode(t.Product_Id,63,'Bireysel',64,'Grup',t.Product_Id)
                    ;
        else
          Open V_Result For
                Select '�retim' Rapor,
                    CASE t.Account_Code
                           WHEN '7850111002' THEN 'Prim'
                           WHEN '7850257008' THEN 'Komisyon'
                           ELSE ''
                    END Tip,
                    CASE t.Account_Code
                           WHEN '7850111002' THEN 'Direkt'
                           WHEN '7850257008' THEN 'Direkt'
                           ELSE ''
                    END D_E,
                    ''YIL,
                    Decode(t.Product_Id,63,'Bireysel',64,'Grup',t.Product_Id) G_B,
                       Round(Sum(Nvl(t.Borc,0)),2) Borc,
                       Round(Sum(Nvl(t.Alacak,0)),2) Alacak,
                       Round(Sum(Nvl(t.Borc,0)-Nvl(t.Alacak,0)),2) FARK
                  From Koc_Acc_v_Posting_Details t, Koc_Dmt_Agents_Ext x
                Where t.Account_Code In ('7850111002','7850257008')
                  And t.Agent_Int_Id = x.Int_Id
                  And x.Company_Code = P_Company_Code
                  And t.Posting_Date Between to_date(v_firstday,'dd/mm/yyyy') and to_date(v_lastday,'dd/mm/yyyy')
                Group By
                    CASE t.Account_Code
                           WHEN '7850111002' THEN 'Direkt'
                           WHEN '7850257008' THEN 'Direkt'
                           ELSE ''
                    END,
                    CASE t.Account_Code
                           WHEN '7850111002' THEN 'Prim'
                           WHEN '7850257008' THEN 'Komisyon'
                           ELSE ''
                    END,
                    Decode(t.Product_Id,63,'Bireysel',64,'Grup',t.Product_Id)
                    ;
        end if;
    elsif P_Rapor = 4 Then--4.KPK
        if P_Company_Code = v_TPA_Allianz Then
          Open V_Result For
            with subs as (
            Select /*+parallel(t,4)*/'KPK' Rapor,
                   'KPK Prim' Tip,
                   t.agent_role,
                   '' YIL,
                   Decode(t.Product_Id,63,'Bireysel',64,'Grup',t.Product_Id) G_B,
                   '' Borc,
                   '' Alacak,
                   Round(Sum(Nvl(t.cmi_premium,0)),2) Fark
                From KOC_CMI_PRO_RATA t,KOC_CMI_PROCESS_CLOSE_INFO c
               Where c.roll_month = To_char(to_date(v_firstday,'dd/mm/yyyy'),'mmyyyy')
               and t.order_no = c.order_no
               and t.branch_id =126
               and t.is_industrial =c.is_industrial
            Group by t.agent_role,Decode(t.Product_Id,63,'Bireysel',64,'Grup',t.Product_Id)
            ),
            subs2 as (
            Select /*+parallel(t,4)*/'KPK' Rapor,
                   'KPK Komisyon' Tip,
                   t.agent_role,
                   '' YIL,
                   Decode(t.Product_Id,63,'Bireysel',64,'Grup',t.Product_Id) G_B,
                   '' Borc,
                   '' Alacak,
                   Round(Sum(Nvl(t.cmi_agency,0)),2) Fark
                From KOC_CMI_PRO_RATA t,KOC_CMI_PROCESS_CLOSE_INFO c
               Where c.roll_month = To_char(to_date(v_firstday,'dd/mm/yyyy'),'mmyyyy')
               and t.order_no = c.order_no
               and t.branch_id =126
               and t.is_industrial =c.is_industrial
            Group by t.agent_role,Decode(t.Product_Id,63,'Bireysel',64,'Grup',t.Product_Id)
            )
            select s.Rapor,s.Tip,'Direkt' D_E, s.yil,s.G_B,s.Borc,s.Alacak,nvl(sum(nvl(s.Fark,0)),0) Fark
             from subs s
            group by s.Rapor,s.Tip,'Direkt',s.yil,s.G_B,s.Borc,s.Alacak
            union all
            select s.Rapor,s.Tip,'Direkt' D_E,s.yil,s.G_B,s.Borc,s.Alacak,nvl(sum(nvl(s.Fark,0)),0) Fark
             from subs2 s
            group by s. Rapor,s.Tip,'Direkt',s.yil,s.G_B,s.Borc,s.Alacak
            order by d_e,g_b,tip desc;
        Else
          Open V_Result For
            with subs as (
            Select 'KPK' Rapor,
                   'KPK Prim' Tip,
                   t.agent_role,
                   '' YIL,
                   Decode(t.Product_Id,63,'Bireysel',64,'Grup',t.Product_Id) G_B,
                   '' Borc,
                   '' Alacak,
                   Round(Sum(Nvl(t.cmi_premium,0)),2) Fark
                From KOC_CMI_PRO_RATA t,KOC_CMI_PROCESS_CLOSE_INFO c
               Where c.roll_month = To_char(to_date(v_firstday,'dd/mm/yyyy'),'mmyyyy')
               and t.order_no = c.order_no
               and t.branch_id =126
               and t.is_industrial =c.is_industrial
            Group by t.agent_role,Decode(t.Product_Id,63,'Bireysel',64,'Grup',t.Product_Id)
            ),
            subs2 as (
            Select 'KPK' Rapor,
                   'KPK Komisyon' Tip,
                   t.agent_role,
                   '' YIL,
                   Decode(t.Product_Id,63,'Bireysel',64,'Grup',t.Product_Id) G_B,
                   '' Borc,
                   '' Alacak,
                   Round(Sum(Nvl(t.cmi_agency,0)),2) Fark
                From KOC_CMI_PRO_RATA t,KOC_CMI_PROCESS_CLOSE_INFO c
               Where c.roll_month = To_char(to_date(v_firstday,'dd/mm/yyyy'),'mmyyyy')
               and t.order_no = c.order_no
               and t.branch_id =126
               and t.is_industrial =c.is_industrial
            Group by t.agent_role,Decode(t.Product_Id,63,'Bireysel',64,'Grup',t.Product_Id)
            )
            select s.Rapor,s.Tip,CASE x.company_code WHEN '045' THEN 'Direkt' ELSE 'Endirekt' END D_E,
                   s.yil,s.G_B,s.Borc,s.Alacak,nvl(sum(nvl(s.Fark,0)),0) Fark
             from subs s,Koc_Dmt_Agents_Ext x
            where s.Agent_Role = x.int_id
              and x.company_code = P_Company_Code
            group by s.Rapor,s.Tip,CASE x.company_code WHEN '045' THEN 'Direkt' ELSE 'Endirekt' END,
                   s.yil,s.G_B,s.Borc,s.Alacak
            union all
            select s.Rapor,s.Tip,CASE x.company_code WHEN '045' THEN 'Direkt' ELSE 'Endirekt' END D_E,
                   s.yil,s.G_B,s.Borc,s.Alacak,nvl(sum(nvl(s.Fark,0)),0) Fark
             from subs2 s,Koc_Dmt_Agents_Ext x
            where s.Agent_Role = x.int_id
              and x.company_code = P_Company_Code
            group by s. Rapor,s.Tip,CASE x.company_code WHEN '045' THEN 'Direkt' ELSE 'Endirekt' END,
                   s.yil,s.G_B,s.Borc,s.Alacak
            order by d_e,g_b,tip desc;
        End if;
    elsif P_Rapor = 5 Then--5.�denen Hasar Bordro Excel
        if P_Company_Code = v_TPA_Allianz Then
          Open V_Result For
            select t.ticket_date,t.ext_reference,t.trans_no,t.trans_amt,t.swift_code,t.currency_exchange_rate,t.date_of_loss,
                 t.cover_code,c.explanation Explanation,t.provision_date,t.Oar_No,t.Partner_name,t.Type_Of_Interest,
                 t.claim_inst_type,t.cover_cat_group,t.Supp_id,t.Comm_date,t.invoice_date,t.product_id,t.group_code,t.partition_type,
                 t.policy_ref,t.term_start_date,t.term_end_date,t.signature_date,t.reference_code,x.title title
             from koc_clm_bordro_rep t ,koc_v_cover c,Koc_Dmt_Agents_Ext x
             where t.agent_role = x.int_id(+)
             and t.cover_code  = c.cover_code(+)
             and t.ticket_date Between to_date(v_firstday,'dd/mm/yyyy') and to_date(v_lastday,'dd/mm/yyyy');
          Else
              Open V_Result For
            select t.ticket_date,t.ext_reference,t.trans_no,t.trans_amt,t.swift_code,t.currency_exchange_rate,t.date_of_loss,
                 t.cover_code,c.explanation Explanation,t.provision_date,t.Oar_No,t.Partner_name,t.Type_Of_Interest,
                 t.claim_inst_type,t.cover_cat_group,t.Supp_id,t.Comm_date,t.invoice_date,t.product_id,t.group_code,t.partition_type,
                 t.policy_ref,t.term_start_date,t.term_end_date,t.signature_date,t.reference_code,x.title title
             from koc_clm_bordro_rep t ,koc_v_cover c,Koc_Dmt_Agents_Ext x
             where t.agent_role = x.int_id(+)
             and t.cover_code  = c.cover_code(+)
             and t.ticket_date Between to_date(v_firstday,'dd/mm/yyyy') and to_date(v_lastday,'dd/mm/yyyy')
             and x.company_code = P_Company_Code;
          End if;
    elsif P_Rapor = 6 Then--6.Muallak Hasar Bordro Excel
        if P_Company_Code = v_TPA_Allianz Then
          Open V_Result For
            select t.ticket_date,t.ext_reference,t.trans_no,t.trans_amt,t.swift_code,t.currency_exchange_rate,t.date_of_loss,
               t.cover_code,c.explanation Explanation,t.provision_date,t.Oar_No,t.Partner_name,t.Type_Of_Interest,
               t.claim_inst_type,t.cover_cat_group,t.Supp_id,t.Comm_date,t.invoice_date,t.product_id,t.group_code,t.partition_type,
               t.policy_ref,t.term_start_date,t.term_end_date,t.signature_date,t.reference_code,x.title title
            from koc_clm_muallak_bordro_rep t ,koc_v_cover c,Koc_Dmt_Agents_Ext x
            where t.agent_role = x.int_id(+)
              and t.cover_code  = c.cover_code(+)
              and t.ticket_date = to_date(v_lastday,'dd/mm/yyyy');
        Else
                Open V_Result For
            select t.ticket_date,t.ext_reference,t.trans_no,t.trans_amt,t.swift_code,t.currency_exchange_rate,t.date_of_loss,
                 t.cover_code,c.explanation Explanation,t.provision_date,t.Oar_No,t.Partner_name,t.Type_Of_Interest,
                 t.claim_inst_type,t.cover_cat_group,t.Supp_id,t.Comm_date,t.invoice_date,t.product_id,t.group_code,t.partition_type,
                 t.policy_ref,t.term_start_date,t.term_end_date,t.signature_date,t.reference_code,x.title title
             from koc_clm_muallak_bordro_rep t ,koc_v_cover c,Koc_Dmt_Agents_Ext x
            where t.agent_role = x.int_id(+)
              and t.cover_code  = c.cover_code(+)
              and t.ticket_date = to_date(v_lastday,'dd/mm/yyyy')
              and x.company_code = P_Company_Code;
        End if;
    elsif P_Rapor = 7 Then--7.KPK Bordro Excel
        if P_Company_Code = v_TPA_Allianz Then
          Open V_Result For
            Select 'KPK' Rapor,
                   t.policy_ref,
                   t.version_no,
                   t.partition_no,
                   t.signature_date,
                   t.term_start_date,
                   t.term_end_date,
                   d.reference_code,
                   x.title,
                   t.total_premium,
                   t.earned_premium,
                   t.cmi_premium,
                   t.agency_comm_amt,
                   t.partition_type,
                   p.explanation,
                   t.branch_id,
                   b.branch_name,
                   t.cmi_agency
                From KOC_CMI_PRO_RATA t,KOC_CMI_PROCESS_CLOSE_INFO c, DMT_AGENTS d,Koc_Dmt_Agents_Ext x, KOC_OC_BRANCHES b,KOC_V_PARTITION p
            Where c.roll_month = To_char(to_date(v_lastday,'dd/mm/yyyy'),'mmyyyy')
              and t.order_no = c.order_no
              and t.branch_id =126
              and t.is_industrial =c.is_industrial
              and d.int_id = t.agent_role
              and t.Agent_Role = x.int_id
              and t.branch_id = b.branch_id
              and p.partition_type = t.partition_type;

        Else
          Open V_Result For
            Select 'KPK' Rapor,
                   t.policy_ref,
                   t.version_no,
                   t.partition_no,
                   t.signature_date,
                   t.term_start_date,
                   t.term_end_date,
                   d.reference_code,
                   x.title,
                   t.total_premium,
                   t.earned_premium,
                   t.cmi_premium,
                   t.agency_comm_amt,
                   t.partition_type,
                   p.explanation,
                   t.branch_id,
                   b.branch_name,
                   t.cmi_agency
                From KOC_CMI_PRO_RATA t,KOC_CMI_PROCESS_CLOSE_INFO c, DMT_AGENTS d,Koc_Dmt_Agents_Ext x, KOC_OC_BRANCHES b,KOC_V_PARTITION p
            Where c.roll_month = To_char(to_date(v_lastday,'dd/mm/yyyy'),'mmyyyy')
              and t.order_no = c.order_no
              and t.branch_id =126
              and t.is_industrial = c.is_industrial
              and d.int_id = t.agent_role
              and t.Agent_Role = x.int_id
              and t.branch_id = b.branch_id
              and p.partition_type = t.partition_type
              and x.company_code = P_Company_Code;
       End if;
    end if;
    P_Close_Month_List_Cur :=  V_Result;

  Exception
    When Ex_Business_Rule Then
        R_pro_res_rec.Type   := -1;
        R_pro_res_rec.Code   := 'BUSINESS_RULE_EXCEPTION';
        Customer.Alz_Mdlr_Hlth_Hpf_Utils.Org_Process_Results(R_pro_res_rec, User, P_Process_Results);
        Dbms_Output.Put_Line ('BUSINESS_RULE_EXCEPTION : ' ||R_pro_res_rec.Reason) ;
    When Others Then
        R_Pro_Res_Rec.Code  := 'ORACLE_EXCEPTION';--'DEVELOPER_INFO';
        R_pro_res_rec.Type   := -1;
        R_pro_res_rec.Reason := Sqlerrm;
        Alz_Mdlr_Hlth_Hpf_Utils.Org_Process_Results(R_Pro_Res_Rec, User, P_Process_Results);
        Dbms_Output.Put_Line ('ORACLE_EXCEPTION : ' ||R_pro_res_rec.Reason) ;
  End Get_Close_Month_List;
  ---------------
End ALZ_TPA_CLOSE_MONTH_UTILS;

/
