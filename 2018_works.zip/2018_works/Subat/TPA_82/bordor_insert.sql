DECLARE 
   v_seq              NUMBER :=  43576;
   p_tip              NUMBER := 2;               ---1 ise muallak 2 ise odenen
   p_date1            DATE := TO_DATE('01/03/2018','DD/MM/YYYY');--TRUNC ( (ADD_MONTHS (SYSDATE, -1)), 'MM'); -- Bir �nceki ay�n ilk g�n�
   p_date2            DATE := TO_DATE('31/03/2018','DD/MM/YYYY');--TRUNC (LAST_DAY (ADD_MONTHS (SYSDATE, -1))); -- Bir �nceki ay�n son g�n�
   p_provision_date   DATE;
   v_Err              VARCHAR2(1000);  
BEGIN
  
  INSERT /*+ APPEND */ INTO KOC_CLM_HLTH_BORDRO_MONTH  NOLOGGING
SELECT /*+ use_nl(a b c) */
             v_seq ORDER_NO 
             , TO_DATE('30/03/2018','DD/MM/YYYY') DATE_2
             , a.claim_id
             , a.sf_no
             , a.trans_no
             , c.ext_reference
             , a.add_order_no
             , a.hlth_cover_code
             , c.cover_no
             , (nvl(currency_exchange_rate,1)* nvl(c.trans_amt,0)) amount
             , a.region_code
             , c.trans_amt_swf
             , c.supp_id
             , nvl(currency_exchange_rate,1) currency_exchange_rate
             , 2 TIP
             , user
             , sysdate
             , A.REALIZATION_TICKET_DATE TICKET_DATE
             , TICKET_NO
             , DECODE(SF_TOTAL_TYPE,12,6,3) SF_TOTAL_TYPE
          FROM KOC_CLM_TRANS_EXT A
             , CLM_SUBFILES B
             , CLM_TRANS C
         WHERE A.CLAIM_ID = B.CLAIM_ID
           AND A.SF_NO    = B.Sf_NO
           AND A.REALIZATION_TICKET_DATE BETWEEN TO_DATE('01/03/2018','DD/MM/YYYY') AND TO_DATE('31/03/2018','DD/MM/YYYY') 
           AND B.SF_TYPE  = 'HLT'
           AND A.CLAIM_ID = C.CLAIM_ID
           AND A.SF_NO    = C.SF_NO
           AND A.TRANS_NO = C.TRANS_NO;
 
   -- �denen Bordro
   --SELECT  koc_clm_hlth_bordro_seq.NEXTVAL  FROM DUAL;
   
   --koc_clm_bordro.reset_syt0_trans;
 


  /* koc_clm_bordro.koc_clm_hlth_bordro_insert (p_tip,
                                              v_seq,
                                              p_date1,
                                              p_date2,
                                              p_provision_date);*/
                                              
   koc_clm_bordro.koc_clm_hlth_odenen_bordro (v_seq, p_date2);
   DBMS_OUTPUT.PUT_LINE('Bitti');
EXCEPTION WHEN OTHERS THEN
   v_Err := SUBSTR(SQLERRM,1,300);
   DBMS_OUTPUT.PUT_LINE(v_Err);
END;


  SELECT * FROM   koc_clm_bordro_rep
                WHERE    ticket_date >= TO_DATE('01/01/2018','DD/MM/YYYY')
                   AND ticket_date <= TO_DATE('01/04/2018','DD/MM/YYYY')
                    AND NVL (sf_type, 'HLT') = 'HLT'
                    FOR UPDATE
