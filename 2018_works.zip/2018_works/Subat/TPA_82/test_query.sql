select * from KOC_PROCESS_CLOSE t
    where t.close_date = '31.10.2017'
      and t.process_type = 'ACCH' for update
      and t.status_code = 2;
      
      
         select t.ticket_date,t.ext_reference,t.trans_no,t.trans_amt,t.swift_code,t.currency_exchange_rate,t.date_of_loss,
                 t.cover_code,c.explanation Explanation,t.provision_date,t.Oar_No,t.Partner_name,t.Type_Of_Interest,
                 t.claim_inst_type,t.cover_cat_group,t.Supp_id,t.Comm_date,t.invoice_date,t.product_id,t.group_code,t.partition_type,
                 t.policy_ref,t.term_start_date,t.term_end_date,t.signature_date,t.reference_code,x.title title,x.int_id,
                 CASE WHEN NVL(d.Is_Ex_Gratia,0) = 1 THEN 'EVET' ELSE 'HAYIR' END EX_GRATIA,
                 d.ex_gratia_fee EXGRATIA_FEE
             from koc_clm_bordro_rep t ,koc_v_cover c,Koc_Dmt_Agents_Ext x, koc_clm_hlth_detail d
             where t.agent_role = x.int_id(+)
             and t.cover_code  = c.cover_code(+)
             and t.ext_reference = d.ext_reference
             and t.add_order_no = 1
             and t.ticket_date Between to_date('01/09/2017','dd/mm/yyyy') and to_date('19/10/2018','dd/mm/yyyy')
             and x.company_code = '777'
             
             select * from koc_dmt_agents_ext where int_id =13406 for update
             
             
