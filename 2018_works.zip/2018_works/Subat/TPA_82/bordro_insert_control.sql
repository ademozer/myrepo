INSERT /*+ APPEND */ INTO KOC_CLM_HLTH_BORDRO_MONTH  NOLOGGING
SELECT /*+ use_nl(a b c) */
             43576 ORDER_NO 
             , TO_DATE('30/03/2018','DD/MM/YYYY') DATE_2
             , a.claim_id
             , a.sf_no
             , a.trans_no
             , c.ext_reference
             , a.add_order_no
             , a.hlth_cover_code
             , c.cover_no
             , (nvl(currency_exchange_rate,1)* nvl(c.trans_amt,0)) amount
             , a.region_code
             , c.trans_amt_swf
             , c.supp_id
             , nvl(currency_exchange_rate,1) currency_exchange_rate
             , 2 TIP
             , user
             , sysdate
             , A.REALIZATION_TICKET_DATE TICKET_DATE
             , TICKET_NO
             , DECODE(SF_TOTAL_TYPE,12,6,3) SF_TOTAL_TYPE
          FROM KOC_CLM_TRANS_EXT A
             , CLM_SUBFILES B
             , CLM_TRANS C
         WHERE A.CLAIM_ID = B.CLAIM_ID
           AND A.SF_NO    = B.Sf_NO
           AND A.REALIZATION_TICKET_DATE BETWEEN TO_DATE('01/03/2018','DD/MM/YYYY') AND TO_DATE('31/03/2018','DD/MM/YYYY') 
           AND B.SF_TYPE  = 'HLT'
           AND A.CLAIM_ID = C.CLAIM_ID
           AND A.SF_NO    = C.SF_NO
           AND A.TRANS_NO = C.TRANS_NO;
           
           
         select * from   KOC_CLM_TRANS_EXT where TRUNC(REALIZATION_TICKET_DATE) = TO_DATE('05/03/2018','DD/MM/YYYY')
         
         select * from koc_clm_hlth_detail@opusdata where claim_id = 33428029
         select * from clm_subfiles@opusdata where claim_id = 33428029
         select * from clm_trans where claim_id = 33428029
         
         select * from alz_tpa_companies;
         
         
         SELECT * FROM  KOC_CLM_HLTH_BORDRO_MONTH 
                WHERE process_date > TO_DATE('22/03/2018','DD/MM/YYYY')
                   AND ticket_date <= TO_DATE('24/03/2018','DD/MM/YYYY')
                    AND NVL (sf_type, 'HLT') = 'HLT';
                    
                    
                   -- SELECT koc_clm_hlth_bordro_seq.NEXTVAL FROM DUAL
