
  CREATE OR REPLACE PACKAGE "CUSTOMER"."KOC_CLM_HLTH_TRNX2" 
IS
   TYPE clmdetailtype IS TABLE OF koc_clm_hlth_detail%ROWTYPE
      INDEX BY BINARY_INTEGER;

   TYPE clmprovisiontype IS TABLE OF koc_clm_hlth_provisions%ROWTYPE
      INDEX BY BINARY_INTEGER;

   TYPE clmprocdetailtyp IS TABLE OF koc_clm_hlth_proc_detail%ROWTYPE
      INDEX BY BINARY_INTEGER;

   TYPE clmrejectiontype IS TABLE OF koc_clm_hlth_reject_loss%ROWTYPE
      INDEX BY BINARY_INTEGER;

   TYPE clmmedicineindemtype IS TABLE OF koc_clm_medicine_indem_det%ROWTYPE
      INDEX BY BINARY_INTEGER;

   TYPE clmvaccindemtype IS TABLE OF koc_clm_vacc_indem_totals%ROWTYPE
      INDEX BY BINARY_INTEGER;

   TYPE clmindemtottype IS TABLE OF koc_clm_hlth_indem_totals%ROWTYPE
      INDEX BY BINARY_INTEGER;

   TYPE relationshiptype IS TABLE OF alz_hltprv_relationship_detail%ROWTYPE
      INDEX BY BINARY_INTEGER;

   TYPE clmItemIndemType IS TABLE OF koc_clm_hlth_item_detail%ROWTYPE
      INDEX BY BINARY_INTEGER;

--  TYPE clmType IS TABLE OF  KOC_CLM_DETAIL%ROWTYPE INDEX BY BINARY_INTEGER;
   TYPE refcur IS REF CURSOR;

   --
   TYPE proc_doctor_info is Record (
     claim_id               koc_clm_hlth_proc_detail.claim_id%type,
     sf_no                  koc_clm_hlth_proc_detail.sf_no%type,
     add_order_no           koc_clm_hlth_proc_detail.add_order_no%type,
     process_code_main      koc_clm_hlth_proc_detail.process_code_main%type,
     process_code_sub1      koc_clm_hlth_proc_detail.process_code_sub1%type,
     process_code_sub2      koc_clm_hlth_proc_detail.process_code_sub2%type,
     doctor_code            koc_clm_hlth_proc_detail.doctor_code%type,
     doctor_status          koc_clm_hlth_proc_detail.doctor_status%type,
     doctor_name            varchar2(1000),
     doctor_title           koc_cc_web_inst_doctor.title%type,
     doctor_speciality      koc_cc_web_inst_doctor.specialty_subject%type,
     doctor_speciality_desc varchar2(1000),
     doctor_staff_status    koc_cc_web_inst_doctor.DOCTOR_STAFF%type,
     doctor_type            koc_cc_web_inst_doctor.DOCTOR_TYPE%type, --1 anla�mal� doktor , 2 anla�mas�z doktor , 3 d�� doktor
     doctor_type_desc       cur_translations.long_name%type
    );

   TYPE proc_doctor_info_type IS TABLE OF proc_doctor_info INDEX BY BINARY_INTEGER;
   --


   p_stoppage number;

   Function Is_Comm_Info_Exists_By_Stmntno(P_Statement_No Koc_Clm_Hlth_Comm.Statement_No%Type) Return Boolean;

   Function Get_Comm_No_By_Stmntno(P_Statement_No Koc_Clm_Hlth_Comm.Statement_No%Type) Return Koc_Clm_Hlth_Comm.Comm_No%Type;

   Function Is_Communication_Info_Exists(P_Claim_Id Koc_Clm_Hlth_Comm.Claim_Id%Type) Return Boolean;

   Function Get_Tax_No_By_Inst_No(P_Institute_Code Koc_Clm_Suppliers_Ext.Institute_Code%Type) Return Koc_Cp_Partners_Ext.Tax_Number%Type;

   Procedure Set_Clm_Invoice_Procs_To_Ki(P_Claim_Id Koc_Clm_Hlth_Prov_Statemnt.Claim_Id%Type
                                       , P_Sf_No    Koc_Clm_Hlth_Prov_Statemnt.Sf_No%Type
                                       , P_Statement_No Koc_Clm_Hlth_Prov_Statemnt.Statement_No%Type);

   Function SetInstEArchiveCommInfo (p_institute_code number, p_payment_group_code varchar2, p_ret_Invoice_Id Alz_Invoice_Master.Invoiceid%Type)
    return Varchar2;

   PROCEDURE doinstclmpayment (
      p_statement_no     NUMBER,
      p_institute_code   NUMBER,
      p_payment_date     DATE,
      p_user_id          VARCHAR2
   );

   PROCEDURE doinstclmpaymentByClaim ( -- ugurz:18012017
        p_statement_no     NUMBER,
        p_claim_id         NUMBER,
        p_institute_code   NUMBER,
        p_payment_date     DATE,
        p_user_id          VARCHAR2
    );-- ugurz:18012017

   PROCEDURE doinstclmpaymentAutoPayment (-- ugurz:18012017
        p_statement_no        NUMBER,
        p_institute_code      NUMBER,
        p_payment_date        DATE,
        p_user_id             VARCHAR2/*,
        p_is_e_invoice_payer  NUMBER*/
    );-- ugurz:18012017

   PROCEDURE doclmrealizationacc (
      p_claim_id                  NUMBER,
      p_sf_no                     NUMBER,
      p_add_order_no              NUMBER,
      p_dc                        NUMBER,
      p_product_id                NUMBER,
      p_partition_type            VARCHAR2,
      p_term_start_date           DATE,
      p_source_of_invoice         NUMBER,
      p_payment_date              DATE,
      p_batch_id            OUT   NUMBER
   );

   FUNCTION getstoppageamount (p_amount         IN NUMBER,
                               p_institute_code IN NUMBER,
                               pinvoice_date    IN DATE,
                               pdate_of_loss    IN DATE)
      RETURN NUMBER;

   PROCEDURE doclmpaymentacc (
      p_claim_id                  NUMBER,
      p_sf_no                     NUMBER,
      p_add_order_no              NUMBER,
      p_dc                        NUMBER,
      p_institute_code            NUMBER,
      p_product_id                NUMBER,
      p_partition_type            VARCHAR2,
      p_term_start_date           DATE,
      p_source_of_invoice         NUMBER,
      p_payment_date              DATE,
      p_batch_id            OUT   NUMBER
   );

   PROCEDURE indemnityrealization (
      p_claim_id                   NUMBER,
      p_sf_no                      NUMBER,
      p_add_order_no               NUMBER,
      p_dc                         NUMBER,
      p_source_of_invoice          NUMBER,
      p_supp_id                    NUMBER,
      p_ip_no                      NUMBER,
      p_contract_id                NUMBER,
      p_partition_no               NUMBER,
      p_product_id                 NUMBER,
      p_partition_type             VARCHAR2,
      p_term_start_date            DATE,
      p_payment_type               VARCHAR2,
      p_payment_date               DATE,
      p_realization_batch_id       NUMBER,
      p_realization_ticket_date    DATE,
      p_user_id                    VARCHAR2,
      p_creditor_bank              VARCHAR2,
      p_creditor_subsidiary        VARCHAR2,
      p_account_no                 VARCHAR2,
      p_account_owner              VARCHAR2,
      p_indem_acc_exp              VARCHAR2,
      p_correspondent_bank         VARCHAR2,
      p_correspondent_subsidiary   VARCHAR2,
      p_correspondent_account_no   NUMBER,
      p_money_order_address        VARCHAR2,
      p_is_account_approved        NUMBER,
      p_to_whom_clm_paid           VARCHAR2,
      p_iban_code                  VARCHAR2,
      p_correspondent_iban_code    VARCHAR2,
      p_tc_no                      varchar2,
      p_vkn_no                     varchar2
   );

   PROCEDURE indemnitypayment (
      p_claim_id       NUMBER,
      p_sf_no          NUMBER,
      p_add_order_no   NUMBER,
      p_payment_date   DATE,
      p_batch_id       NUMBER
   );

   FUNCTION getfeerate (
      p_institute_code    NUMBER,
      p_cover_cat_group   VARCHAR2,
      p_date              DATE
   )
      RETURN NUMBER;

   FUNCTION getfeeprice (p_cover_cat_group VARCHAR2, p_date DATE)
      RETURN NUMBER;

   FUNCTION isprovisionfee (p_institute_code NUMBER, p_trans_date DATE)
      RETURN NUMBER;

   FUNCTION getservicerate (
      p_institute_code   NUMBER,
      p_service_type     VARCHAR2,
      p_date             DATE
   )
      RETURN NUMBER;

   FUNCTION getreturnreceipt (pinst_code IN NUMBER,
                              pclaim_id  IN NUMBER,
                              psf_no     IN NUMBER,
                              pcurr_rate IN NUMBER,
                              ptrn_date1 IN DATE,
                              ptrn_date2 IN DATE) RETURN NUMBER;

   PROCEDURE geninstclmtrans (
      p_institute_code   NUMBER,
      p_payment_group    VARCHAR2,
      p_order_no         NUMBER,
      p_start_date       DATE,
      p_end_date         DATE,
      p_payment_term     DATE,
      p_user_id          VARCHAR2,
      p_payment_date     DATE DEFAULT NULL
   );

   PROCEDURE approveinstrans (
      p_payment_group_code   VARCHAR2,
      p_institute_code       NUMBER,
      p_payment_date         DATE,
      p_user_id              VARCHAR2
   );

--  PROCEDURE insertInstTrans(p_institute_code number,p_trans_date date,p_trans_amount number,p_trans_type number,p_claim_id number,p_sf_no number,p_add_order_no number,p_reverse VARCHAR2,p_trans_no number,p_exp varchar2 default null);
   PROCEDURE insertinsttrans (
      p_institute_code         NUMBER,
      p_trans_date             DATE,
      p_trans_amount           NUMBER,
      p_trans_type             NUMBER,
      p_claim_id               NUMBER,
      p_sf_no                  NUMBER,
      p_add_order_no           NUMBER,
      p_reverse                VARCHAR2,
      p_trans_no               NUMBER,
      p_exp                    VARCHAR2,
      p_account_no             VARCHAR2,
      p_acc_date               DATE,
      p_order_no               NUMBER,
      p_batch_id         OUT   NUMBER
   );

   PROCEDURE finddatesforinstclmtrans (
      p_institute_code                  NUMBER,
      p_payment_group                   VARCHAR2,
      p_max_ticket_date           OUT   DATE,
      p_min_ticket_date           OUT   DATE,
      p_technical_approved_date   OUT   DATE
   );

   FUNCTION getinsttransname (p_trans_type NUMBER)
      RETURN VARCHAR2;

   FUNCTION isinstclmpaid (p_statement_no NUMBER)
      RETURN NUMBER;

   PROCEDURE clmtechapproved (
      p_claim_id       NUMBER,
      p_sf_no          NUMBER,
      p_add_order_no   NUMBER
   );

   PROCEDURE clmpaymentapproved (
      p_claim_id       NUMBER,
      p_sf_no          NUMBER,
      p_add_order_no   NUMBER,
      p_onayiptal      NUMBER
   );

   PROCEDURE clmtechapprovedcancel (
      p_claim_id       NUMBER,
      p_sf_no          NUMBER,
      p_add_order_no   NUMBER
   );

   PROCEDURE clmpaymentapprovedcancel (
      p_claim_id       NUMBER,
      p_sf_no          NUMBER,
      p_add_order_no   NUMBER
   );

   FUNCTION isclmapproved (
      p_claim_id       NUMBER,
      p_sf_no          NUMBER,
      p_add_order_no   NUMBER
   )
      RETURN NUMBER;

   FUNCTION lastapproveddate (p_institute_code NUMBER)
      RETURN DATE;

   PROCEDURE cancelclmpayment (
      p_claim_id       NUMBER,
      p_sf_no          NUMBER,
      p_add_order_no   NUMBER,
      p_payment_date   DATE,
      p_user_id        VARCHAR2,
      p_exp            VARCHAR2
   );

   PROCEDURE cancelclmrealization (
      p_claim_id       NUMBER,
      p_sf_no          NUMBER,
      p_add_order_no   NUMBER,
      p_payment_date   DATE,
      p_user_id        VARCHAR2,
      p_exp            VARCHAR2
   );

--  procedure doInstTransAccByType(p_trans_date date,p_trans_date2 date,p_trans_type number ,p_trans_group varchar2, p_payment_group_code varchar2, p_institute_code number,p_dc number, p_pay_month number,p_pay_year number,p_acc_date DATE,p_batch_id OUT number, p_bank_code varchar2 default null) ;
   PROCEDURE doinsttransaccbytype (
      p_trans_date                 DATE,
      p_trans_date2                DATE,
      p_trans_type                 NUMBER,
      p_trans_group                VARCHAR2,
      p_payment_group_code         VARCHAR2,
      p_institute_code             NUMBER,
      p_dc                         NUMBER,
      p_pay_month                  NUMBER,
      p_pay_year                   NUMBER,
      p_acc_date                   DATE,
      p_batch_id             OUT   NUMBER
   );

   PROCEDURE updateinsuredbankinfo (
      p_contract_id             NUMBER,
      p_ip_no                   NUMBER,
      p_bank_code               NUMBER,
      p_subsdiary_code          NUMBER,
      p_account_no              VARCHAR2,
      p_account_owner           VARCHAR2,
      p_indemnity_account_exp   VARCHAR2,
      p_date                    DATE,
      p_iban_code               varchar2  ,
       p_ACC_OWNER_PARTID        number
   );


   PROCEDURE updatefinalclass (
      p_claim_id                NUMBER,
      p_sf_no                   NUMBER,
      p_add_order_no            NUMBER,
      p_final_class_disease_1   VARCHAR2,
      p_final_class_disease_2   VARCHAR2,
      p_final_class_disease_3   VARCHAR2
   );

   PROCEDURE updateclmtransbank (
      p_contract_id             NUMBER,
      p_partition_no            NUMBER,
      p_bank                    NUMBER,
      p_branch                  NUMBER,
      p_accno                   VARCHAR2,
      p_acc_owner               VARCHAR2,
      p_result         IN OUT   VARCHAR2
   );

   PROCEDURE updateclmtransbank (
      p_contract_id             NUMBER,
      p_partition_no            NUMBER,
      p_bank                    NUMBER,
      p_branch                  NUMBER,
      p_accno                   VARCHAR2,
      p_acc_owner               VARCHAR2,
      p_claim_id                NUMBER,
      p_result         IN OUT   VARCHAR2,
      p_iban_code                    VARCHAR2,
      p_tc_no                        VARCHAR2,
      p_vkn_no                       VARCHAR2
   );

--  PROCEDURE setClmDetail (clm KOC_CLM_DETAIL%ROWTYPE) ;
   PROCEDURE setclmdetail (
      p_claim_id              NUMBER,
      p_sf_no                 NUMBER,
      p_detail_no             NUMBER,
      p_can_be_recourse       NUMBER,
      p_recourse_amount       NUMBER,
      p_recourse_clm_amount   NUMBER,
      p_recourse_rate_100     NUMBER,
      p_recourse_rate_8       NUMBER,
      p_recourse_status       NUMBER
   );

   PROCEDURE setclmreinsurance (
      p_contract_id      NUMBER,
      p_partition_no     NUMBER,
      p_claim_id         NUMBER,
      p_product_id       NUMBER,
      p_partition_type   VARCHAR2,
      p_cover_code       VARCHAR2
   );

   PROCEDURE update_specialty_subject (
      p_claim_id            NUMBER,
      p_sf_no               NUMBER,
      p_add_order_no        NUMBER,
      p_specialty_subject   VARCHAR2
   );

   PROCEDURE p_get_clm_recorse_status (
    p_claim_id NUMBER,
    p_sf_no NUMBER,
    p_result OUT  VARCHAR2,
    p_code    OUT  VARCHAR2);



  FUNCTION get_clm_recorse_status (p_claim_id NUMBER, p_sf_no NUMBER)
  RETURN VARCHAR2;




   PROCEDURE geninstperiodamount (
      p_institute_code   NUMBER,
      p_start_date       DATE,
      p_end_date         DATE
   );

  --Task 12317 ile UW notelar� i�in eklendi. yg
   PROCEDURE insUpdUWNote (
      p_claim_id                       NUMBER,
      p_part_id                        NUMBER,
      p_status_code                    VARCHAR2,
      p_explanation                    VARCHAR2,
      p_contract_id                    NUMBER,
      p_partition_no                   NUMBER);

   --Task 12317 ile koc_clm_hlth_proc_detail tablosundaki bilgiler koc_clm_hlth_tmp_proc_detail(session bazl�)
   --tablosuna tas�n�yor. 16/06/2009 yg
   PROCEDURE transerProcDataToSession (
      p_claim_id               NUMBER,
      p_sf_no                  NUMBER,
      p_add_order_no           NUMBER );


    --Task 12317 - Session bazl�   koc_clm_hlth_tmp_proc_detail tablosundan kay�t silme. 16/06/2009 yg
    --11.11.2014 seq_no eklendi mustafaku@kora
    PROCEDURE deleteSessionProcReq (
       p_claim_id            NUMBER,
       p_sf_no               NUMBER,
       p_add_order_no        NUMBER,
       p_process_code_main   NUMBER,
       p_process_code_sub1   NUMBER,
       p_process_code_sub2   NUMBER,
       p_location_code       NUMBER,
       p_cover_code          VARCHAR2,
       p_seq_no              NUMBER
    );

    --Task 12317 -   koc_clm_hlth_tmp_proc_detail tablosundaki datay�  koc_clm_hlth_proc_detail tablsuna tasir. 16/06/2009 yg
    PROCEDURE transerSessionProcDataToDB (
      p_claim_id               NUMBER,
      p_sf_no                  NUMBER,
      p_add_order_no           NUMBER );

    --Task 12317 - �lgili teminata ait  koc_clm_hlth_tmp_proc_detail tablosundaki islem bilgilerini siler. 16/06/2009 yg
    PROCEDURE deleteCoverProcs (
       p_claim_id            NUMBER,
       p_sf_no               NUMBER,
       p_add_order_no        NUMBER,
       p_location_code       NUMBER,
       p_cover_code          VARCHAR2
    )  ;

    PROCEDURE insertSessionProcs (
       p_claim_id                NUMBER,
       p_sf_no                   NUMBER,
       p_location_code           NUMBER,
       p_add_order_no            NUMBER,
       p_cover_code              VARCHAR2,
       p_group_no                NUMBER,
       p_process_code_main       NUMBER,
       p_process_code_sub1       NUMBER,
       p_process_code_sub2       NUMBER,
       p_discount_group_code     VARCHAR2,
       p_indemnity_amount        NUMBER,
       p_process_group           VARCHAR2,
       p_userid                  VARCHAR2,
       p_process_count           NUMBER,
       p_status_code             VARCHAR2,
       p_swift_code              VARCHAR2,
       p_inst_indemnity_amount   NUMBER,
       p_seq_no                  NUMBER
    );
    PROCEDURE setHospitalizeDateToNull (
       p_claim_id            NUMBER,
       p_sf_no               NUMBER,
       p_add_order_no        NUMBER
    );

    PROCEDURE processtempacctoreal;

    PROCEDURE pcancelstoppagemail(pstatement_no IN NUMBER,
                                  pclaim_id     IN NUMBER,
                                  pinvoice_date IN DATE,
                                  pclaim_amount IN NUMBER,
                                  pstoppage     IN NUMBER);

    FUNCTION postingstoppage (ptype            IN VARCHAR2,
                              pposting_date    IN DATE,
                              pbatch_id        IN NUMBER,
                              pevent_type_code IN VARCHAR2,
                              pusername        IN VARCHAR2)RETURN NUMBER;

    PROCEDURE get_proc_doctor_info (p_claim_id          IN NUMBER,
                                    P_sf_no             IN NUMBER,
                                    p_add_order_no      IN NUMBER,
                                    p_provision_date    IN DATE,
                                    p_proc_doctor_info  OUT proc_doctor_info_type
                                    );

    PROCEDURE get_relationship_info (p_claim_id          IN NUMBER,
                                     P_sf_no             IN NUMBER,
                                     p_add_order_no      IN NUMBER ,
                                     p_relationshiptype  OUT relationshiptype
                                     );
  --ITEM WORKS
    type itemTyp is table of koc_clm_hlth_item_detail%rowtype index by binary_integer;

    itemRec itemTyp;
    PROCEDURE setItemRec( p_itemRec koc_clm_hlth_item_detail%rowtype );
    PROCEDURE getItemRec( p_itemRec OUT itemTyp ) ;
    PROCEDURE emptyItemRec;

    PROCEDURE get_item_detail_data  (p_claim_id          IN NUMBER,
                                     P_sf_no             IN NUMBER,
                                     p_add_order_no      IN NUMBER ,
                                     p_item_list         OUT KOC_CLM_HLTH_TRNX.clmItemIndemType
                                     );

    PROCEDURE transerItemDataToSession ( p_claim_id               NUMBER,
                                         p_sf_no                  NUMBER,
                                         p_add_order_no           NUMBER );

    PROCEDURE deleteSessionItemReq ( p_claim_id            NUMBER,
                                     p_sf_no               NUMBER,
                                     p_add_order_no        NUMBER,
                                     p_ubb_code            VARCHAR2,
                                     p_location_code       NUMBER,
                                     p_cover_code          VARCHAR2,
                                     p_seq_no              NUMBER
                                   );

    PROCEDURE transerSessionItemDataToDB ( p_claim_id               NUMBER,
                                           p_sf_no                  NUMBER,
                                           p_add_order_no           NUMBER );


    PROCEDURE deleteCoverItems ( p_claim_id            NUMBER,
                                 p_sf_no               NUMBER,
                                 p_add_order_no        NUMBER,
                                 p_location_code       NUMBER,
                                 p_cover_code          VARCHAR2
                                );

    PROCEDURE insertSessionItems (  p_clmItemIndemType        koc_clm_hlth_item_detail%rowtype );

    function getitemdesc(p_ubb_code varchar2, p_date date default sysdate) return varchar2   ;
END;
CREATE OR REPLACE PACKAGE BODY "CUSTOMER"."KOC_CLM_HLTH_TRNX2" 
AS
   FUNCTION Get_Payment_Group_By_Inst_Code (
      P_Institute_Code Koc_V_Clm_Suppliers_M1.Institute_Code%TYPE)
      RETURN Koc_V_Clm_Suppliers_M1.Payment_Group_Code%TYPE
   IS
      CURSOR Cr_Paym (
         Pc_Institute_Code Koc_V_Clm_Suppliers_M1.Institute_Code%TYPE)
      IS
         SELECT A.Payment_Group_Code
           FROM Koc_V_Clm_Suppliers_M1 A
          WHERE A.Supp_Type = 'SKRM' AND A.Institute_Code = Pc_Institute_Code;

      V_Payment_Group_Code   Koc_V_Clm_Suppliers_M1.Payment_Group_Code%TYPE;
   BEGIN
      OPEN Cr_Paym (P_Institute_Code);

      FETCH Cr_Paym INTO V_Payment_Group_Code;

      CLOSE Cr_Paym;

      RETURN V_Payment_Group_Code;
   END;


   FUNCTION Is_Comm_Info_Exists_By_Stmntno (
      P_Statement_No Koc_Clm_Hlth_Comm.Statement_No%TYPE)
      RETURN BOOLEAN
   IS
      CURSOR Cr_Comm (Pc_Statement_No Koc_Clm_Hlth_Comm.Statement_No%TYPE)
      IS
         SELECT A.Comm_No
           FROM Koc_Clm_Hlth_Comm A
          WHERE A.Statement_No = Pc_Statement_No;

      L_Comm_No   Koc_Clm_Hlth_Comm.Comm_No%TYPE;
   BEGIN
      OPEN Cr_Comm (P_Statement_No);

      FETCH Cr_Comm INTO L_Comm_No;

      CLOSE Cr_Comm;

      IF L_Comm_No IS NULL
      THEN
         RETURN FALSE;
      END IF;

      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN FALSE;
   END;

   PROCEDURE Set_Clm_Invoice_Procs_To_Ki (
      P_Claim_Id        Koc_Clm_Hlth_Prov_Statemnt.Claim_Id%TYPE,
      P_Sf_No           Koc_Clm_Hlth_Prov_Statemnt.Sf_No%TYPE,
      P_Statement_No    Koc_Clm_Hlth_Prov_Statemnt.Statement_No%TYPE)
   IS
   BEGIN
      UPDATE Koc_Clm_Hlth_Prov_Statemnt A
         SET A.Inv_Process = 1
       WHERE     A.Claim_Id = P_Claim_Id
             AND A.Sf_No = P_Sf_No
             AND A.Statement_No = P_Statement_No;
   END;

   FUNCTION Get_Comm_No_By_Stmntno (
      P_Statement_No Koc_Clm_Hlth_Comm.Statement_No%TYPE)
      RETURN Koc_Clm_Hlth_Comm.Comm_No%TYPE
   IS
      CURSOR Cr_Comm (Pc_Statement_No Koc_Clm_Hlth_Comm.Statement_No%TYPE)
      IS
         SELECT A.Comm_No
           FROM Koc_Clm_Hlth_Comm A
          WHERE A.Statement_No = Pc_Statement_No;

      L_Comm_No   Koc_Clm_Hlth_Comm.Comm_No%TYPE;
   BEGIN
      OPEN Cr_Comm (P_Statement_No);

      FETCH Cr_Comm INTO L_Comm_No;

      CLOSE Cr_Comm;

      RETURN L_Comm_No;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;

   FUNCTION Is_Communication_Info_Exists (
      P_Claim_Id Koc_Clm_Hlth_Comm.Claim_Id%TYPE)
      RETURN BOOLEAN
   IS
      CURSOR Cr_Comm (Pc_Claim_Id Koc_Clm_Hlth_Comm.Claim_Id%TYPE)
      IS
         SELECT A.Comm_No
           FROM Koc_Clm_Hlth_Comm A
          WHERE A.Claim_Id = Pc_Claim_Id;

      L_Comm_No   Koc_Clm_Hlth_Comm.Comm_No%TYPE;
   BEGIN
      OPEN Cr_Comm (P_Claim_Id);

      FETCH Cr_Comm INTO L_Comm_No;

      CLOSE Cr_Comm;

      IF L_Comm_No IS NULL
      THEN
         RETURN FALSE;
      END IF;

      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN FALSE;
   END;

   FUNCTION Get_Part_Id_By_Inst_No (
      P_Institute_Code Koc_Clm_Suppliers_Ext.Institute_Code%TYPE)
      RETURN Clm_Suppliers.Part_Id%TYPE
   IS
      CURSOR Cr_Partner (
         Pc_Institute_Code Koc_Clm_Suppliers_Ext.Institute_Code%TYPE)
      IS
         SELECT B.Part_Id
           FROM Koc_Clm_Suppliers_Ext A, Clm_Suppliers B
          WHERE     A.Institute_Code = Pc_Institute_Code
                AND B.Supp_Id = A.Supp_Id;

      V_Part_Id   Clm_Suppliers.Part_Id%TYPE;
   BEGIN
      OPEN Cr_Partner (P_Institute_Code);

      FETCH Cr_Partner INTO V_Part_Id;

      CLOSE Cr_Partner;

      RETURN V_Part_Id;
   END;

   FUNCTION Get_Tax_No_By_Inst_No (
      P_Institute_Code Koc_Clm_Suppliers_Ext.Institute_Code%TYPE)
      RETURN Koc_Cp_Partners_Ext.Tax_Number%TYPE
   IS
      CURSOR Cr_Partner (
         Pc_Institute_Code Koc_Clm_Suppliers_Ext.Institute_Code%TYPE)
      IS
         SELECT C.Tax_Number
           FROM Koc_Clm_Suppliers_Ext A,
                Clm_Suppliers B,
                Koc_Cp_Partners_Ext C
          WHERE     A.Institute_Code = Pc_Institute_Code
                AND B.Supp_Id = A.Supp_Id
                AND C.Part_Id = B.Part_Id;

      V_Tax_Number   Koc_Cp_Partners_Ext.Tax_Number%TYPE;
   BEGIN
      OPEN Cr_Partner (P_Institute_Code);

      FETCH Cr_Partner INTO V_Tax_Number;

      CLOSE Cr_Partner;

      RETURN V_Tax_Number;
   END;

   FUNCTION Get_Identity_By_Part_Id (
      P_Part_Id Koc_Cp_Partners_Ext.Part_Id%TYPE)
      RETURN Koc_Cp_Partners_Ext.Tax_Number%TYPE
   IS
      CURSOR Cr_Identity (Pc_Part_Id Koc_Cp_Partners_Ext.Part_Id%TYPE)
      IS
         SELECT NVL (A.Tax_Number, A.Identity_No) Ident
           FROM Koc_Cp_Partners_Ext A
          WHERE A.Part_Id = Pc_Part_Id;

      V_Ident   Koc_Cp_Partners_Ext.Tax_Number%TYPE;
   BEGIN
      OPEN Cr_Identity (P_Part_Id);

      FETCH Cr_Identity INTO V_Ident;

      CLOSE Cr_Identity;

      RETURN V_Ident;
   END;

   FUNCTION getmaxtransno (p_claim_id NUMBER, p_sf_no NUMBER)
      RETURN NUMBER
   IS
      v_trans_no   NUMBER;
   BEGIN
      SELECT NVL (MAX (trans_no), 0)
        INTO v_trans_no
        FROM clm_trans
       WHERE claim_id = p_claim_id AND sf_no = p_sf_no;

      RETURN (v_trans_no);
   END;

   FUNCTION SetInstEArchiveCommInfo (
      p_institute_code        NUMBER,
      p_payment_group_code    VARCHAR2,
      p_ret_Invoice_Id        Alz_Invoice_Master.Invoiceid%TYPE)
      RETURN VARCHAR2
   IS
      -- inst type = 1 hastaneler icin
      CURSOR c_1
      IS
         SELECT *
           FROM (  SELECT manager_title_id,
                          b.title_desc manager_title_desc,
                          CASE
                             WHEN ALZ_VALIDATION_PKG.is_valid_gsm (
                                     phone_number) = 1
                             THEN
                                phone_number
                             ELSE
                                NULL
                          END
                             phone_number,
                          CASE
                             WHEN ALZ_VALIDATION_PKG.is_valid_email (email) = 1
                             THEN
                                email
                             ELSE
                                NULL
                          END
                             email
                     FROM (SELECT institute_code,
                                  manager_code,
                                  manager_title_id,
                                  title,
                                  NAME,
                                  surname,
                                  phone_number,
                                  interphone,
                                  fax_number,
                                  email,
                                  validity_start_date,
                                  validity_end_date,
                                  has_authorization,
                                  'Onayli' status,
                                  is_delete,
                                  phone_area_code
                             FROM koc_cc_web_inst_manager
                            WHERE     institute_code = p_institute_code
                                  AND has_authorization = 1) a,
                          koc_cc_web_inst_dept b,
                          koc_cc_web_unit_ref r
                    WHERE     a.manager_title_id = b.title_id
                          AND r.institute_code = a.institute_code
                          AND r.unit_type = 'K'
                          AND r.validity_start_date <= TRUNC (SYSDATE)
                          AND (   r.validity_end_date >= TRUNC (SYSDATE)
                               OR r.validity_end_date IS NULL)
                          AND r.institute_code = p_institute_code
                          AND is_delete = 0
                          AND (   (    email IS NOT NULL
                                   AND ALZ_VALIDATION_PKG.is_valid_email (
                                          email) = 1)
                               OR (    phone_number IS NOT NULL
                                   AND ALZ_VALIDATION_PKG.is_valid_gsm (
                                          phone_number) = 1))
                          AND manager_title_id IN (11, 12, 6, 7)
                 ORDER BY CASE
                             WHEN manager_title_id = 11 THEN 1 -- muhasebe muduru
                             WHEN manager_title_id = 12 THEN 2 -- muhasebe yetkilisi
                             WHEN manager_title_id = 6 THEN 3 -- anl.kurum muduru
                             WHEN manager_title_id = 7 THEN 4 -- anl.kurum yetkilisi
                             ELSE 5
                          END)
          WHERE ROWNUM = 1;

      r_1                c_1%ROWTYPE;


      CURSOR c_2
      IS
         SELECT m.part_id,
                (SELECT NVL (e.TAX_NUMBER, e.IDENTITY_NO)
                   FROM koc_cp_partners_ext e
                  WHERE e.part_id = m.part_id)
                   identityno
           FROM KOC_V_CLM_SUPPLIERS_m1 m, koc_clm_suppliers_ext s -- is_earchieve_printed eklenecek mi?
          WHERE     m.supp_type = 'SKRM'
                AND m.supp_id = s.supp_id
                AND m.INSTITUTE_TYPE = s.INSTITUTE_TYPE
                AND m.institute_code = p_institute_code
                AND m.payment_group_code =
                       NVL (p_payment_group_code, m.payment_group_code);

      r_2                c_2%ROWTYPE;

      v_INSTITUTE_TYPE   VARCHAR2 (4);
      v_noinfo           NUMBER := 1;
      v_email            VARCHAR2 (500);
      v_phone            VARCHAR2 (30);
      v_print            VARCHAR2 (30) := 0;

      PROCEDURE findbysupplier
      IS
      BEGIN
         OPEN c_2;

         FETCH c_2 INTO r_2;

         IF c_2%FOUND
         THEN
            v_email := ALZ_INV_FORMS_UTILS.get_email (r_2.part_id);
            v_phone := ALZ_INV_FORMS_UTILS.get_gsm (r_2.part_id);
            v_print :=
               ALZ_INV_FORMS_UTILS.is_earchive_printed (r_2.identityno);
         END IF;

         CLOSE c_2;
      END;
   BEGIN
      SELECT DISTINCT m.INSTITUTE_TYPE
        INTO v_INSTITUTE_TYPE
        FROM KOC_V_CLM_SUPPLIERS_m1 m, koc_clm_suppliers_ext s -- is_earchieve_printed eklenecek mi?
       WHERE     m.supp_type = 'SKRM'
             AND m.supp_id = s.supp_id
             AND m.INSTITUTE_TYPE = s.INSTITUTE_TYPE
             AND m.institute_code = p_institute_code
             AND m.payment_group_code = p_payment_group_code;

      -- hastaneler icin portalldaki idari personel listesinden bak
      IF v_INSTITUTE_TYPE = 1
      THEN
         OPEN c_1;

         FETCH c_1 INTO r_1;

         IF c_1%NOTFOUND
         THEN
            --bulamazsan supplierden bak
            findbysupplier;
         ELSE
            v_email := r_1.email;
            v_phone := r_1.phone_number;
         END IF;

         CLOSE c_1;
      ELSE
         -- eczaneler , doktorlar vs  supplierdan bak
         findbysupplier;
      END IF;


      IF p_ret_Invoice_Id IS NOT NULL
      THEN
         UPDATE Alz_Invoice_Master_Ext
            SET INV_INFORM_GSM = v_phone,
                INV_INFORM_EMAIL = v_email,
                IS_EARCHIVE_PRINTED = v_print
          WHERE Idx =
                   ALZ_INV_PROCESS_UTILS.GET_IDX_BY_INVID_FROM_INVOICE (
                      p_ret_Invoice_Id);
      END IF;

      RETURN NULL;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN SQLERRM;
   END;


   PROCEDURE cancelclmpayment (p_claim_id        NUMBER,
                               p_sf_no           NUMBER,
                               p_add_order_no    NUMBER,
                               p_payment_date    DATE,
                               p_user_id         VARCHAR2,
                               p_exp             VARCHAR2)
   IS
      CURSOR curstat
      IS
         SELECT a.*
           FROM koc_clm_hlth_detail a
          WHERE     a.claim_id = p_claim_id
                AND a.sf_no = p_sf_no
                AND a.add_order_no = p_add_order_no
                AND a.status_code IN ('ODE');

      CURSOR curdetail
      IS
           SELECT b.claim_id,
                  b.sf_no,
                  b.add_order_no,
                  b.cover_code,
                  b.swift_code,
                  b.is_pool_cover,
                  b.is_special_cover,
                  SUM (b.exemption_amount) exemption_amount,
                  SUM (b.provision_total) provision_total,
                  SUM (b.refusal_amount) refusal_amount,
                  SUM (b.request_amount) request_amount,
                  a.ext_reference,
                  a.provision_date,
                  a.invoice_date,
                  a.claim_inst_type,
                  a.claim_inst_loc,
                  a.country_code country,
                  a.date_of_loss,
                  a.realization_date,
                  a.close_date
             FROM koc_clm_hlth_detail a, koc_clm_hlth_provisions b
            WHERE     a.claim_id = p_claim_id
                  AND a.sf_no = p_sf_no
                  AND a.add_order_no = p_add_order_no
                  AND a.status_code = 'ODE'
                  AND a.claim_id = b.claim_id
                  AND a.sf_no = b.sf_no
                  AND a.add_order_no = b.add_order_no
                  AND b.status_code = 'ODE'
         GROUP BY b.claim_id,
                  b.sf_no,
                  b.add_order_no,
                  b.cover_code,
                  b.swift_code,
                  b.is_pool_cover,
                  b.is_special_cover,
                  a.ext_reference,
                  a.provision_date,
                  a.invoice_date,
                  a.claim_inst_type,
                  a.claim_inst_loc,
                  a.country_code,
                  a.date_of_loss,
                  a.realization_date,
                  a.close_date;

      /*uzenk 10022017*/
      CURSOR c_before_cancel_status (
         p_ext_reference NUMBER)
      IS
           SELECT new_cpa_status
             FROM KOC_CLM_HLTH_DETAIL_CPA_LOG
            WHERE     new_status_code = 'P'
                  AND ext_reference = p_ext_reference
                  AND entry_Date =
                         (SELECT MAX (entry_Date)
                            FROM KOC_CLM_HLTH_DETAIL_CPA_LOG
                           WHERE     ext_reference = p_ext_reference
                                 AND new_status_code = 'P')
         ORDER BY ROWNUM DESC;

      v_before_cancel_status     VARCHAR2 (10);
      /*uzenk 10022017*/


      clmdetail                  curdetail%ROWTYPE;
      stat                       curstat%ROWTYPE;
      v_batch_id                 NUMBER;
      v_pay_batch_id             NUMBER;
      cur                        refcur;
      policyinfo                 koc_v_hlth_insured_info_indem%ROWTYPE;
      v_supp_id                  NUMBER;
      v_trans_no                 NUMBER;
      v_int_ref                  NUMBER;
      v_pay_curr_get_type        VARCHAR2 (4);
      v_pay_clearing_system_id   NUMBER;
      v_currency_exchange_rate   NUMBER := 1;
      v_status_id                NUMBER;
      v_cover_swf                VARCHAR2 (20);
      v_exch_date                VARCHAR2 (20);
      v_curr_date                DATE;
      v_prev_realization_date    DATE;
      v_trans_date               DATE;
      v_muallak_date             DATE;
      v_country_group            NUMBER;
      indeminfo                  koc_clm_hlth_indem_totals%ROWTYPE;
      icur                       koc_clm_hlth_trnx.refcur;
      v_indem_date               DATE;
      v_indem_exp                VARCHAR2 (200);
   BEGIN
      OPEN curstat;

      FETCH curstat INTO stat;

      CLOSE curstat;

      SELECT supp_id
        INTO v_supp_id
        FROM koc_clm_suppliers_ext
       WHERE institute_code = stat.institute_code;

      v_prev_realization_date :=
         NVL (clmdetail.realization_date, clmdetail.close_date);
      koc_clm_hlth_utils.getpolinfoforindembyclm (stat.claim_id,
                                                  stat.provision_date,
                                                  cur);

      FETCH cur INTO policyinfo;

      CLOSE cur;

      koc_clm_hlth_trnx2.doclmrealizationacc (stat.claim_id,
                                              stat.sf_no,
                                              stat.add_order_no,
                                              -1,
                                              policyinfo.product_id,
                                              policyinfo.partition_type,
                                              policyinfo.term_start_date,
                                              2,
                                              p_payment_date,
                                              v_batch_id);
      koc_clm_hlth_trnx2.doclmpaymentacc (stat.claim_id,
                                          stat.sf_no,
                                          stat.add_order_no,
                                          -1,
                                          stat.institute_code,
                                          policyinfo.product_id,
                                          policyinfo.partition_type,
                                          policyinfo.term_start_date,
                                          2,
                                          p_payment_date,
                                          v_pay_batch_id);


      koc_clm_hlth_trnx2.indemnityrealization (stat.claim_id,
                                               stat.sf_no,
                                               1                --add_order_no
                                                ,
                                               -1                       --sign
                                                 ,
                                               2                       --elden
                                                ,
                                               v_supp_id,
                                               policyinfo.ip_no,
                                               policyinfo.contract_id,
                                               policyinfo.partition_no,
                                               policyinfo.product_id,
                                               policyinfo.partition_type,
                                               policyinfo.term_start_date,
                                               '7',
                                               p_payment_date,
                                               v_batch_id,
                                               p_payment_date,
                                               p_user_id,
                                               NULL --p_creditor_bank VARCHAR2
                                                   ,
                                               NULL --p_creditor_subsidiary VARCHAR2
                                                   ,
                                               NULL    --p_account_no VARCHAR2
                                                   ,
                                               NULL --p_account_owner VARCHAR2
                                                   ,
                                               NULL --p_indem_acc_exp VARCHAR2
                                                   ,
                                               NULL --p_correspondent_bank VARCHAR2
                                                   ,
                                               NULL --p_correspondent_subsidiary VARCHAR2
                                                   ,
                                               NULL --p_correspondent_account_no NUMBER
                                                   ,
                                               NULL --p_money_order_address VARCHAR2
                                                   ,
                                               NULL,
                                               NULL,
                                               NULL,             --p_iban_code
                                               NULL, --p_correspondent_iban_code
                                               NULL,                 --p_tc_no
                                               NULL                 --p_vkn_no
                                                   );

      --cozbay task132695 kapsaminda buraya alindi 15.02.2012
      UPDATE koc_clm_hlth_detail
         SET invoice_date = NULL,
             invoice_no = NULL,
             invoice_total = NULL,
             close_date = NULL
       WHERE     claim_id = stat.claim_id
             AND sf_no = stat.sf_no
             AND add_order_no = stat.add_order_no;

      UPDATE koc_clm_trans_ext a
         SET ticket_date = p_payment_date, batch_id = v_pay_batch_id
       WHERE     a.claim_id = p_claim_id
             AND a.sf_no = p_sf_no
             AND a.add_order_no = p_add_order_no
             AND a.trans_no =
                    (SELECT MAX (xx.trans_no)
                       FROM koc_clm_trans_ext xx, clm_trans yy
                      WHERE     xx.claim_id = a.claim_id
                            AND xx.sf_no = a.sf_no
                            AND xx.add_order_no = a.add_order_no
                            AND xx.hlth_cover_code = a.hlth_cover_code
                            AND xx.claim_id = yy.claim_id
                            AND xx.sf_no = yy.sf_no
                            AND xx.trans_no = yy.trans_no
                            AND yy.sf_total_type IN ('11', '12', '10'));

      ---muallak kayd�
      OPEN curdetail;

      LOOP
         FETCH curdetail INTO clmdetail;

         EXIT WHEN curdetail%NOTFOUND;
         --- kur bilgisi bul --
         v_currency_exchange_rate := 1;

         IF NVL (clmdetail.swift_code, base_swift_code) != base_swift_code
         THEN
            v_country_group :=
               koc_clm_hlth_utils.getcountrygroup (clmdetail.country);
            v_indem_date :=
               NVL (clmdetail.provision_date,
                    NVL (clmdetail.date_of_loss, clmdetail.invoice_date));
            koc_clm_hlth_trnx.getindemtotals (policyinfo.contract_id,
                                              policyinfo.partition_no,
                                              clmdetail.claim_inst_type,
                                              clmdetail.claim_inst_loc,
                                              v_country_group,
                                              clmdetail.cover_code,
                                              v_indem_date,
                                              0,
                                              0,
                                              p_user_id,
                                              clmdetail.is_pool_cover,
                                              clmdetail.is_special_cover,
                                              icur);

            FETCH icur INTO indeminfo;

            CLOSE icur;

            v_cover_swf := indeminfo.swift_code;

            SELECT DECODE (v_cover_swf,
                           base_swift_code, pay_clearing_system_id,
                           pay_swf_clear_sys_id),
                   DECODE (v_cover_swf,
                           base_swift_code, pay_curr_get_type,
                           pay_swf_curr_get_type),
                   DECODE (v_cover_swf,
                           base_swift_code, pay_exch_dates,
                           pay_swf_exch_dates)
              INTO v_pay_clearing_system_id, v_pay_curr_get_type, v_exch_date
              FROM koc_oc_prod_partition_rel
             WHERE     product_id = policyinfo.product_id
                   AND partition_type = policyinfo.partition_type
                   AND validity_start_date <= policyinfo.term_start_date
                   AND NVL (validity_end_date, policyinfo.term_start_date) >=
                          policyinfo.term_start_date;

            IF v_exch_date = 'FAT'
            THEN
               v_curr_date :=
                  NVL (clmdetail.provision_date, clmdetail.invoice_date);
            ELSIF v_exch_date = 'OLAY'
            THEN
               v_curr_date :=
                  NVL (clmdetail.provision_date,
                       NVL (clmdetail.date_of_loss, clmdetail.invoice_date));
            ELSIF v_exch_date = 'TAH'
            THEN
               v_curr_date :=
                  NVL (clmdetail.provision_date, v_prev_realization_date);
            ELSE
               v_curr_date :=
                  NVL (clmdetail.provision_date,
                       NVL (clmdetail.date_of_loss, clmdetail.invoice_date));
            END IF;

            v_currency_exchange_rate :=
               koc_curr_utils.retrieve_currency_rate (
                  clmdetail.swift_code,
                  v_pay_curr_get_type,
                  TRUNC (v_curr_date),
                  v_pay_clearing_system_id,
                  TRUE);
         END IF;

         -------------------------------------
         v_trans_no := NVL (getmaxtransno (p_claim_id, p_sf_no), 0) + 1;

         SELECT clm_int_ref_seq.NEXTVAL INTO v_int_ref FROM DUAL;

         INSERT INTO clm_trans (claim_id,
                                sf_no,
                                trans_no,
                                movement_id,
                                assignee,
                                sf_total_type,
                                trans_type,
                                trans_date,
                                clm_status,
                                trans_amt,
                                trans_amt_swf,
                                trans_base_amt,
                                rsv_amt,
                                int_ref,
                                supp_id,
                                ip_no,
                                oar_no,
                                ext_reference)
              VALUES (clmdetail.claim_id,
                      clmdetail.sf_no,
                      v_trans_no,
                      1,
                      p_user_id,
                      10,
                      10,
                      p_payment_date,
                      'TRANS',
                      clmdetail.provision_total,
                      clmdetail.swift_code,
                      clmdetail.request_amount,
                      clmdetail.refusal_amount,
                      v_int_ref,
                      v_supp_id,
                      policyinfo.ip_no,
                      policyinfo.partition_no,
                      clmdetail.ext_reference);

         begin
         koc_clm_bordro.alz_hlth_bordro_trans_log(clmdetail.claim_id,v_trans_no,'KOC_CLM_HLTH_TRNX2-688',null,1);
         exception when others then
            begin
                koc_clm_bordro.alz_hlth_bordro_trans_log(clmdetail.claim_id,v_trans_no,'KOC_CLM_HLTH_TRNX2-688',null,1,substr(sqlerrm,1,950));
            exception when others then
                null;
            end;
         end;

         INSERT INTO koc_clm_trans_ext (claim_id,
                                        sf_no,
                                        add_order_no,
                                        trans_no,
                                        exemption_amount,
                                        hlth_cover_code,
                                        currency_exchange_rate) --,institute_code)
              VALUES (clmdetail.claim_id,
                      clmdetail.sf_no,
                      clmdetail.add_order_no,
                      v_trans_no,
                      clmdetail.exemption_amount,
                      clmdetail.cover_code,
                      NVL (v_currency_exchange_rate, 1)); --,stat.institute_code);

         SELECT clm_status_id_seq.NEXTVAL INTO v_status_id FROM DUAL;

         INSERT INTO clm_status_history (status_id,
                                         claim_id,
                                         clm_line_id,
                                         clm_level,
                                         clm_status,
                                         csh_date,
                                         csh_username,
                                         sf_no,
                                         trans_no)
              VALUES (v_status_id,
                      clmdetail.claim_id,
                      20,
                      'TRANS',
                      'OPEN',
                      TRUNC (SYSDATE),
                      p_user_id,
                      1,
                      v_trans_no);

         INSERT INTO koc_clm_status_history_ext (status_id,
                                                 claim_id,
                                                 sf_no,
                                                 clm_status,
                                                 process_date,
                                                 userid,
                                                 explanation)
              VALUES (v_status_id,
                      clmdetail.claim_id,
                      clmdetail.sf_no,
                      'OPEN',
                      SYSDATE,
                      p_user_id,
                      'CCP');
      END LOOP;

      v_indem_exp :=
            'TAHAKKUK �PTAL�. (�PT.TAR:'
         || TO_CHAR (p_payment_date, 'dd/mm/yyyy')
         || ') '
         || p_exp;

      INSERT INTO koc_clm_hlth_indem_dec (claim_id,
                                          sf_no,
                                          add_order_no,
                                          process_date,
                                          file_agreement_code,
                                          explanation,
                                          userid)
           VALUES (p_claim_id,
                   p_sf_no,
                   p_add_order_no,
                   SYSDATE,
                   'P',
                   SUBSTR (v_indem_exp, 1, 100),
                   p_user_id);

      UPDATE koc_clm_hlth_prov_statemnt a
         SET status_code = 'P'
       WHERE     a.claim_id = p_claim_id
             AND a.sf_no = p_sf_no
             AND a.status_code = 'ODE';



      /*uzenk 10022017*/
      v_before_cancel_status := NULL;

      OPEN c_before_cancel_status (stat.ext_reference);

      FETCH c_before_cancel_status INTO v_before_cancel_status;

      CLOSE c_before_cancel_status;

      UPDATE koc_clm_hlth_detail a
         SET status_code = 'P',
             cpa_status = v_before_cancel_status,           /*uzenk 10022017*/
             close_date = NULL,
             realization_date = NULL
       WHERE     a.claim_id = p_claim_id
             AND a.sf_no = p_sf_no
             AND a.add_order_no = p_add_order_no
             AND a.status_code = 'ODE';


      UPDATE koc_clm_hlth_provisions a
         SET status_code = 'P'
       WHERE     a.claim_id = p_claim_id
             AND a.sf_no = p_sf_no
             AND a.add_order_no = p_add_order_no
             AND a.status_code = 'ODE';

      UPDATE koc_clm_hlth_proc_detail a
         SET status_code = 'P'
       WHERE     a.claim_id = p_claim_id
             AND a.sf_no = p_sf_no
             AND a.add_order_no = p_add_order_no
             AND a.status_code = 'ODE';

      --15408 bc yetki limit
      UPDATE KOC_CLM_HLTH_PROV_LIMIT a
         SET claim_status = 'P'
       WHERE     a.claim_id = p_claim_id
             AND a.sf_no = p_sf_no
             AND a.add_order_no = p_add_order_no
             AND a.claim_status = 'ODE';
   END cancelclmpayment;

   PROCEDURE cancelclmrealization (p_claim_id        NUMBER,
                                   p_sf_no           NUMBER,
                                   p_add_order_no    NUMBER,
                                   p_payment_date    DATE,
                                   p_user_id         VARCHAR2,
                                   p_exp             VARCHAR2)
   IS
      CURSOR curstat
      IS
         SELECT a.*
           FROM koc_clm_hlth_detail a
          WHERE     a.claim_id = p_claim_id
                AND a.sf_no = p_sf_no
                AND a.add_order_no = p_add_order_no
                AND a.status_code IN ('TAH');

      CURSOR clmcur
      IS
         SELECT DISTINCT a.payment_type,
                         a.creditor_bank,
                         a.creditor_subsidiary,
                         a.account_no,
                         a.money_order_address,
                         a.correspondent_bank,
                         a.correspondent_subsidiary,
                         a.correspondent_account_code,
                         a.is_account_approved,
                         a.to_whom_clm_paid,
                         a.IBAN_CODE,
                         a.CORRESPONDENT_IBAN_CODE
           FROM koc_clm_trans_ext a
          WHERE     a.claim_id = p_claim_id
                AND a.sf_no = p_sf_no
                AND a.add_order_no = p_add_order_no
                AND a.trans_no =
                       (SELECT MAX (xx.trans_no)
                          FROM koc_clm_trans_ext xx, clm_trans yy
                         WHERE     xx.claim_id = a.claim_id
                               AND xx.sf_no = a.sf_no
                               AND xx.add_order_no = a.add_order_no
                               AND xx.hlth_cover_code = a.hlth_cover_code
                               AND xx.claim_id = yy.claim_id
                               AND xx.sf_no = yy.sf_no
                               AND xx.trans_no = yy.trans_no
                               AND yy.sf_total_type IN ('11', '12', '10'));

      CURSOR curprov
      IS
           SELECT b.claim_id,
                  b.sf_no,
                  b.add_order_no,
                  b.cover_code,
                  b.swift_code,
                  b.is_pool_cover,
                  b.is_special_cover,
                  SUM (b.exemption_amount) exemption_amount,
                  SUM (b.provision_total) provision_total,
                  SUM (b.refusal_amount) refusal_amount,
                  SUM (b.request_amount) request_amount
             FROM koc_clm_hlth_provisions b
            WHERE     b.claim_id = p_claim_id
                  AND b.sf_no = p_sf_no
                  AND b.add_order_no = p_add_order_no
                  AND b.status_code = 'TAH'
         GROUP BY b.claim_id,
                  b.sf_no,
                  b.add_order_no,
                  b.cover_code,
                  b.swift_code,
                  b.is_pool_cover,
                  b.is_special_cover;

      CURSOR curmainprov
      IS
         SELECT b.*
           FROM koc_clm_hlth_provisions b
          WHERE     b.claim_id = p_claim_id
                AND b.sf_no = p_sf_no
                AND b.add_order_no = p_add_order_no
                AND b.status_code = 'TAH';

      CURSOR curpartner (p_part_id NUMBER)
      IS
         SELECT pi.identity_no, pi.TAX_NUMBER
           FROM koc_cp_partners_ext pi
          WHERE pi.part_id = p_part_id;

      curpartnerrec              curpartner%ROWTYPE;


      clmmainprovision           curmainprov%ROWTYPE;
      clmprovision               curprov%ROWTYPE;
      clmdetail                  curstat%ROWTYPE;
      v_batch_id                 NUMBER;
      v_pay_batch_id             NUMBER;
      cur                        refcur;
      clmrec                     clmcur%ROWTYPE;
      policyinfo                 koc_v_hlth_insured_info_indem%ROWTYPE;
      v_supp_id                  NUMBER;
      v_trans_no                 NUMBER;
      v_int_ref                  NUMBER;
      v_pay_curr_get_type        VARCHAR2 (4);
      v_pay_clearing_system_id   NUMBER;
      v_currency_exchange_rate   NUMBER;
      v_status_id                NUMBER;
      v_inv_date                 DATE;
      v_cover_swf                VARCHAR2 (20);
      v_exch_date                VARCHAR2 (20);
      v_curr_date                DATE;
      v_prev_realization_date    DATE;
      v_country_group            NUMBER;
      indeminfo                  koc_clm_hlth_indem_totals%ROWTYPE;
      icur                       koc_clm_hlth_trnx.refcur;
      v_indem_date               DATE;
      v_indem_exp                VARCHAR (200);
   BEGIN
      OPEN curstat;

      FETCH curstat INTO clmdetail;

      CLOSE curstat;

      SELECT supp_id
        INTO v_supp_id
        FROM koc_clm_suppliers_ext
       WHERE institute_code = clmdetail.institute_code;

      v_inv_date :=
         TO_DATE (
               TO_CHAR (NVL (clmdetail.date_of_loss, clmdetail.invoice_date),
                        'DD/MM/YYYY')
            || ' 13:00:00',
            'DD/MM/YYYY HH24:MI:SS');
      koc_clm_hlth_utils.getpolinfoforindembyclm (clmdetail.claim_id,
                                                  v_inv_date,
                                                  cur);

      FETCH cur INTO policyinfo;

      CLOSE cur;

      IF policyinfo.contract_id IS NULL
      THEN
         v_inv_date :=
            TO_DATE (
                  TO_CHAR (
                     NVL (clmdetail.date_of_loss, clmdetail.invoice_date),
                     'DD/MM/YYYY')
               || ' 11:00:00',
               'DD/MM/YYYY HH24:MI:SS');
         koc_clm_hlth_utils.getpolinfoforindembyclm (clmdetail.claim_id,
                                                     v_inv_date,
                                                     cur);

         FETCH cur INTO policyinfo;

         CLOSE cur;
      END IF;

      v_prev_realization_date :=
         NVL (clmdetail.realization_date, clmdetail.close_date);
      v_prev_realization_date := NVL (v_prev_realization_date, p_payment_date);

      IF policyinfo.contract_id IS NULL
      THEN
         raise_application_error (
            -20200,
            clmdetail.claim_id || clmdetail.invoice_date);
      END IF;

      OPEN clmcur;

      FETCH clmcur INTO clmrec;

      CLOSE clmcur;

      koc_clm_hlth_trnx2.doclmrealizationacc (clmdetail.claim_id,
                                              clmdetail.sf_no,
                                              clmdetail.add_order_no,
                                              -1,
                                              policyinfo.product_id,
                                              policyinfo.partition_type,
                                              policyinfo.term_start_date,
                                              1,
                                              p_payment_date,
                                              v_batch_id);

      OPEN curpartner (clmdetail.part_id);

      FETCH curpartner INTO curpartnerrec;

      CLOSE curpartner;



      koc_clm_hlth_trnx2.indemnityrealization (
         clmdetail.claim_id,
         clmdetail.sf_no,
         clmdetail.add_order_no,
         -1                                                             --sign
           ,
         1                                                             --elden
          ,
         v_supp_id,
         policyinfo.ip_no,
         policyinfo.contract_id,
         policyinfo.partition_no,
         policyinfo.product_id,
         policyinfo.partition_type,
         policyinfo.term_start_date,
         clmrec.payment_type,
         p_payment_date,
         v_batch_id,
         p_payment_date,
         p_user_id,
         clmrec.creditor_bank,
         clmrec.creditor_subsidiary,
         clmrec.account_no,
         NULL,
         NULL,
         clmrec.correspondent_bank,
         clmrec.correspondent_subsidiary,
         clmrec.correspondent_account_code,
         clmrec.money_order_address,
         clmrec.is_account_approved,
         clmrec.to_whom_clm_paid,
         clmrec.iban_code,
         clmrec.correspondent_iban_code,
         curpartnerrec.identity_no,
         curpartnerrec.TAX_NUMBER);

      ---- reverse
      OPEN curmainprov;

      LOOP
         FETCH curmainprov INTO clmmainprovision;

         EXIT WHEN curmainprov%NOTFOUND;
         koc_clm_hlth_trnx.reverseremainig (policyinfo.contract_id,
                                            policyinfo.partition_no,
                                            v_prev_realization_date,
                                            p_user_id,
                                            clmdetail,
                                            clmmainprovision);
      END LOOP;

      CLOSE curmainprov;

      ---- reverse

      ---muallak kayd�
      OPEN curprov;

      LOOP
         FETCH curprov INTO clmprovision;

         EXIT WHEN curprov%NOTFOUND;
         --- kur bilgisi bul --
         v_currency_exchange_rate := 1;

         IF NVL (clmdetail.swift_code, base_swift_code) != base_swift_code
         THEN
            v_country_group :=
               koc_clm_hlth_utils.getcountrygroup (clmdetail.country_code);
            v_indem_date :=
               NVL (clmdetail.provision_date,
                    NVL (clmdetail.date_of_loss, clmdetail.invoice_date));
            koc_clm_hlth_trnx.getindemtotals (policyinfo.contract_id,
                                              policyinfo.partition_no,
                                              clmdetail.claim_inst_type,
                                              clmdetail.claim_inst_loc,
                                              v_country_group,
                                              clmprovision.cover_code,
                                              v_indem_date,
                                              0,
                                              0,
                                              p_user_id,
                                              clmprovision.is_pool_cover,
                                              clmprovision.is_special_cover,
                                              icur);

            FETCH icur INTO indeminfo;

            CLOSE icur;

            v_cover_swf := indeminfo.swift_code;

            SELECT DECODE (v_cover_swf,
                           base_swift_code, pay_clearing_system_id,
                           pay_swf_clear_sys_id),
                   DECODE (v_cover_swf,
                           base_swift_code, pay_curr_get_type,
                           pay_swf_curr_get_type),
                   DECODE (v_cover_swf,
                           base_swift_code, pay_exch_dates,
                           pay_swf_exch_dates)
              INTO v_pay_clearing_system_id, v_pay_curr_get_type, v_exch_date
              FROM koc_oc_prod_partition_rel
             WHERE     product_id = policyinfo.product_id
                   AND partition_type = policyinfo.partition_type
                   AND validity_start_date <= policyinfo.term_start_date
                   AND NVL (validity_end_date, policyinfo.term_start_date) >=
                          policyinfo.term_start_date;

            IF v_exch_date = 'FAT'
            THEN
               v_curr_date :=
                  NVL (clmdetail.provision_date, clmdetail.invoice_date);
            ELSIF v_exch_date = 'OLAY'
            THEN
               v_curr_date :=
                  NVL (clmdetail.provision_date,
                       NVL (clmdetail.date_of_loss, clmdetail.invoice_date));
            ELSIF v_exch_date = 'TAH'
            THEN
               v_curr_date :=
                  NVL (clmdetail.provision_date, v_prev_realization_date);
            ELSE
               v_curr_date :=
                  NVL (clmdetail.provision_date, clmdetail.invoice_date);
            END IF;

            v_currency_exchange_rate :=
               koc_curr_utils.retrieve_currency_rate (
                  clmdetail.swift_code,
                  v_pay_curr_get_type,
                  TRUNC (v_curr_date),
                  v_pay_clearing_system_id,
                  TRUE);
         END IF;

         v_trans_no := NVL (getmaxtransno (p_claim_id, p_sf_no), 0) + 1;

         SELECT clm_int_ref_seq.NEXTVAL INTO v_int_ref FROM DUAL;

         INSERT INTO clm_trans (claim_id,
                                sf_no,
                                trans_no,
                                movement_id,
                                assignee,
                                sf_total_type,
                                trans_type,
                                trans_date,
                                clm_status,
                                trans_amt,
                                trans_amt_swf,
                                trans_base_amt,
                                rsv_amt,
                                int_ref,
                                supp_id,
                                ip_no,
                                oar_no,
                                ext_reference)
              VALUES (clmdetail.claim_id,
                      clmdetail.sf_no,
                      v_trans_no,
                      1,
                      p_user_id,
                      10,
                      10,
                      p_payment_date,
                      'TRANS',
                      clmprovision.provision_total,
                      clmprovision.swift_code,
                      clmprovision.request_amount,
                      clmprovision.refusal_amount,
                      v_int_ref,
                      v_supp_id,
                      policyinfo.ip_no,
                      policyinfo.partition_no,
                      clmdetail.ext_reference);

         begin
         koc_clm_bordro.alz_hlth_bordro_trans_log(clmdetail.claim_id,v_trans_no,'KOC_CLM_HLTH_TRNX2-1186',null,1);
         exception when others then
            begin
                koc_clm_bordro.alz_hlth_bordro_trans_log(clmdetail.claim_id,v_trans_no,'KOC_CLM_HLTH_TRNX2-1186',null,1,substr(sqlerrm,1,950));
            exception when others then
                null;
            end;
         end;

         INSERT INTO koc_clm_trans_ext (claim_id,
                                        sf_no,
                                        add_order_no,
                                        trans_no,
                                        exemption_amount,
                                        hlth_cover_code,
                                        currency_exchange_rate) --,institute_code)
              VALUES (clmdetail.claim_id,
                      clmdetail.sf_no,
                      clmdetail.add_order_no,
                      v_trans_no,
                      clmprovision.exemption_amount,
                      clmprovision.cover_code,
                      NVL (v_currency_exchange_rate, 1)); --,clmDetail.institute_code);

         SELECT clm_status_id_seq.NEXTVAL INTO v_status_id FROM DUAL;

         INSERT INTO clm_status_history (status_id,
                                         claim_id,
                                         clm_line_id,
                                         clm_level,
                                         clm_status,
                                         csh_date,
                                         csh_username,
                                         sf_no,
                                         trans_no)
              VALUES (v_status_id,
                      clmdetail.claim_id,
                      20,
                      'TRANS',
                      'OPEN',
                      TRUNC (SYSDATE),
                      p_user_id,
                      1,
                      v_trans_no);

         INSERT INTO koc_clm_status_history_ext (status_id,
                                                 claim_id,
                                                 sf_no,
                                                 clm_status,
                                                 process_date,
                                                 userid,
                                                 explanation)
              VALUES (v_status_id,
                      clmdetail.claim_id,
                      clmdetail.sf_no,
                      'OPEN',
                      SYSDATE,
                      p_user_id,
                      'CCR');
      END LOOP;

      CLOSE curprov;

      v_indem_exp :=
            'TAHAKKUK �PTAL�. (�PT.TAR:'
         || TO_CHAR (p_payment_date, 'dd/mm/yyyy')
         || ') '
         || p_exp;

      INSERT INTO koc_clm_hlth_indem_dec (claim_id,
                                          sf_no,
                                          add_order_no,
                                          process_date,
                                          file_agreement_code,
                                          explanation,
                                          userid)
           VALUES (clmdetail.claim_id,
                   clmdetail.sf_no,
                   clmdetail.add_order_no,
                   SYSDATE,
                   'I',
                   v_indem_exp,
                   p_user_id);

      UPDATE koc_clm_hlth_detail a
         SET status_code = 'I', close_date = NULL, realization_date = NULL
       WHERE     a.claim_id = p_claim_id
             AND a.sf_no = p_sf_no
             AND a.add_order_no = p_add_order_no
             AND a.status_code = 'TAH';

      UPDATE koc_clm_hlth_provisions a
         SET status_code = NULL
       WHERE     a.claim_id = p_claim_id
             AND a.sf_no = p_sf_no
             AND a.add_order_no = p_add_order_no
             AND a.status_code = 'TAH';

      UPDATE koc_clm_hlth_proc_detail a
         SET status_code = NULL
       WHERE     a.claim_id = p_claim_id
             AND a.sf_no = p_sf_no
             AND a.add_order_no = p_add_order_no
             AND a.status_code = 'TAH';

      --150408 BC yetki limit
      DELETE KOC_CLM_HLTH_PROV_LIMIT
       WHERE     claim_id = p_claim_id
             AND sf_no = p_sf_no
             AND add_order_no = p_add_order_no
             AND claim_status = 'TAH';
   END cancelclmrealization;

   PROCEDURE doinstclmpayment (p_statement_no      NUMBER,
                               p_institute_code    NUMBER,
                               p_payment_date      DATE,
                               p_user_id           VARCHAR2)
   IS
      CURSOR curstat
      IS
         SELECT a.*, b.provision_date
           FROM koc_clm_hlth_prov_statemnt a, koc_clm_hlth_detail b
          WHERE     a.claim_id = b.claim_id
                AND a.sf_no = b.sf_no
                AND a.institute_code = b.institute_code
                AND a.statement_no = p_statement_no
                AND b.institute_code = p_institute_code
                AND b.add_order_no = 1
                AND a.status_code IN ('P')
                AND b.status_code IN ('P')
                AND a.invoice_date IS NOT NULL
                AND a.invoice_no IS NOT NULL;

      CURSOR curprov (
         p_claim_id        NUMBER,
         p_sf_no           NUMBER,
         p_add_order_no    NUMBER)
      IS
         SELECT SUM (NVL (request_amount, 0) - NVL (refusal_amount, 0)) total,
                SUM (NVL (provision_total, 0)) prov_total
           FROM koc_clm_hlth_provisions
          WHERE     claim_id = p_claim_id
                AND sf_no = p_sf_no
                AND add_order_no = p_add_order_no;

      stat             curstat%ROWTYPE;
      recprov          curprov%ROWTYPE;
      v_batch_id       NUMBER;
      v_pay_batch_id   NUMBER;
      cur              refcur;
      policyinfo       koc_v_hlth_insured_info_indem%ROWTYPE;
      v_supp_id        NUMBER;
   BEGIN
      OPEN curstat;

      LOOP
         FETCH curstat INTO stat;

         EXIT WHEN curstat%NOTFOUND;

         BEGIN
            OPEN curprov (stat.claim_id, stat.sf_no, 1);

            FETCH curprov INTO recprov;

            CLOSE curprov;

            IF recprov.prov_total > 0
            THEN
               SELECT supp_id
                 INTO v_supp_id
                 FROM koc_clm_suppliers_ext
                WHERE institute_code = p_institute_code;

               koc_clm_hlth_utils.getpolinfoforindembyclm (
                  stat.claim_id,
                  stat.provision_date,
                  cur);


               FETCH cur INTO policyinfo;

               CLOSE cur;

               UPDATE koc_clm_hlth_detail
                  SET invoice_date = stat.invoice_date,
                      invoice_no = stat.invoice_no,
                      invoice_total = stat.invoice_total,
                      close_date = p_payment_date
                WHERE     claim_id = stat.claim_id
                      AND sf_no = stat.sf_no
                      AND add_order_no = 1;

               koc_clm_hlth_trnx2.doclmrealizationacc (
                  stat.claim_id,
                  stat.sf_no,
                  1,
                  1,
                  policyinfo.product_id,
                  policyinfo.partition_type,
                  policyinfo.term_start_date,
                  2,
                  p_payment_date,
                  v_batch_id);


               IF v_batch_id IS NOT NULL
               THEN
                  koc_clm_hlth_trnx2.doclmpaymentacc (
                     stat.claim_id,
                     stat.sf_no,
                     1,
                     1,
                     p_institute_code,
                     policyinfo.product_id,
                     policyinfo.partition_type,
                     policyinfo.term_start_date,
                     2,
                     p_payment_date,
                     v_pay_batch_id);

                  IF v_pay_batch_id IS NOT NULL
                  THEN
                     koc_clm_hlth_trnx2.indemnityrealization (
                        stat.claim_id,
                        stat.sf_no,
                        1                                       --add_order_no
                         ,
                        1                                               --sign
                         ,
                        2                                              --kurum
                         ,
                        v_supp_id,
                        policyinfo.ip_no,
                        policyinfo.contract_id,
                        policyinfo.partition_no,
                        policyinfo.product_id,
                        policyinfo.partition_type,
                        policyinfo.term_start_date,
                        '7',
                        p_payment_date,
                        v_batch_id,
                        p_payment_date,
                        p_user_id,
                        NULL                        --p_creditor_bank VARCHAR2
                            ,
                        NULL                  --p_creditor_subsidiary VARCHAR2
                            ,
                        NULL                           --p_account_no VARCHAR2
                            ,
                        NULL                        --p_account_owner VARCHAR2
                            ,
                        NULL                        --p_indem_acc_exp VARCHAR2
                            ,
                        NULL                   --p_correspondent_bank VARCHAR2
                            ,
                        NULL             --p_correspondent_subsidiary VARCHAR2
                            ,
                        NULL               --p_correspondent_account_no NUMBER
                            ,
                        NULL                  --p_money_order_address VARCHAR2
                            ,
                        NULL,
                        NULL,
                        NULL,                                   -- p_iban_code
                        NULL,                     --p_correspondent_iban_code,
                        NULL,                                        --p_tc_no
                        NULL                                        --p_vkn_no
                            );

                     koc_clm_hlth_trnx2.indemnitypayment (stat.claim_id,
                                                          stat.sf_no,
                                                          1,
                                                          p_payment_date,
                                                          v_pay_batch_id);

                     UPDATE koc_clm_hlth_prov_statemnt
                        SET status_code = 'ODE'
                      WHERE     statement_no = p_statement_no
                            AND claim_id = stat.claim_id
                            AND sf_no = stat.sf_no
                            AND status_code IN ('P');

                     UPDATE koc_clm_hlth_incomp_papers
                        SET status_code = 'C'
                      WHERE     claim_id = stat.claim_id
                            AND sf_no = stat.sf_no
                            AND status_code IN ('A');

                     UPDATE koc_clm_hlth_detail            ---- ugurz:18012017
                        SET cpa_status = 'ODE'
                      WHERE     claim_id = stat.claim_id
                            AND sf_no = stat.sf_no
                            AND status_code IN ('ODE');      -- ugurz:18012017
                  ELSE
                     ROLLBACK;
                  END IF;                                    -- v_pay_batch_id
               ELSE
                  ROLLBACK;
               END IF;                                           -- v_batch_id
            END IF;
         EXCEPTION
            WHEN OTHERS
            THEN
               ROLLBACK;
               RAISE_APPLICATION_ERROR (-20100,
                                        'Fi� Olu�turulamad�! ' || SQLERRM);
         END;
      END LOOP;

      CLOSE curstat;
   END;



   PROCEDURE doinstclmpaymentByClaim (                       -- ugurz:18012017
                                      p_statement_no      NUMBER,
                                      p_claim_id          NUMBER,
                                      p_institute_code    NUMBER,
                                      p_payment_date      DATE,
                                      p_user_id           VARCHAR2)
   IS
      CURSOR curstat
      IS
         SELECT a.*, b.provision_date
           FROM koc_clm_hlth_prov_statemnt a, koc_clm_hlth_detail b
          WHERE     a.claim_id = b.claim_id
                AND a.sf_no = b.sf_no
                AND a.institute_code = b.institute_code
                AND a.statement_no = p_statement_no
                AND b.institute_code = p_institute_code
                AND a.claim_id = p_claim_id
                AND b.add_order_no = 1
                AND a.status_code IN ('P')
                AND b.status_code IN ('P')
                AND a.invoice_date IS NOT NULL
                AND a.invoice_no IS NOT NULL;

      CURSOR curprov (
         p_claim_id        NUMBER,
         p_sf_no           NUMBER,
         p_add_order_no    NUMBER)
      IS
         SELECT SUM (NVL (request_amount, 0) - NVL (refusal_amount, 0)) total,
                SUM (NVL (provision_total, 0)) prov_total
           FROM koc_clm_hlth_provisions
          WHERE     claim_id = p_claim_id
                AND sf_no = p_sf_no
                AND add_order_no = p_add_order_no;

      stat             curstat%ROWTYPE;
      recprov          curprov%ROWTYPE;
      v_batch_id       NUMBER;
      v_pay_batch_id   NUMBER;
      cur              refcur;
      policyinfo       koc_v_hlth_insured_info_indem%ROWTYPE;
      v_supp_id        NUMBER;
   BEGIN
      OPEN curstat;

      LOOP
         FETCH curstat INTO stat;

         EXIT WHEN curstat%NOTFOUND;

         BEGIN
            OPEN curprov (stat.claim_id, stat.sf_no, 1);

            FETCH curprov INTO recprov;

            CLOSE curprov;

            IF recprov.prov_total > 0
            THEN
               SELECT supp_id
                 INTO v_supp_id
                 FROM koc_clm_suppliers_ext
                WHERE institute_code = p_institute_code;

               koc_clm_hlth_utils.getpolinfoforindembyclm (
                  stat.claim_id,
                  stat.provision_date,
                  cur);


               FETCH cur INTO policyinfo;

               CLOSE cur;

               UPDATE koc_clm_hlth_detail
                  SET invoice_date = stat.invoice_date,
                      invoice_no = stat.invoice_no,
                      invoice_total = stat.invoice_total,
                      close_date = p_payment_date
                WHERE     claim_id = stat.claim_id
                      AND sf_no = stat.sf_no
                      AND add_order_no = 1;

               koc_clm_hlth_trnx2.doclmrealizationacc (
                  stat.claim_id,
                  stat.sf_no,
                  1,
                  1,
                  policyinfo.product_id,
                  policyinfo.partition_type,
                  policyinfo.term_start_date,
                  2,
                  p_payment_date,
                  v_batch_id);


               IF v_batch_id IS NOT NULL
               THEN
                  koc_clm_hlth_trnx2.doclmpaymentacc (
                     stat.claim_id,
                     stat.sf_no,
                     1,
                     1,
                     p_institute_code,
                     policyinfo.product_id,
                     policyinfo.partition_type,
                     policyinfo.term_start_date,
                     2,
                     p_payment_date,
                     v_pay_batch_id);

                  IF v_pay_batch_id IS NOT NULL
                  THEN
                     koc_clm_hlth_trnx2.indemnityrealization (
                        stat.claim_id,
                        stat.sf_no,
                        1                                       --add_order_no
                         ,
                        1                                               --sign
                         ,
                        2                                              --kurum
                         ,
                        v_supp_id,
                        policyinfo.ip_no,
                        policyinfo.contract_id,
                        policyinfo.partition_no,
                        policyinfo.product_id,
                        policyinfo.partition_type,
                        policyinfo.term_start_date,
                        '7',
                        p_payment_date,
                        v_batch_id,
                        p_payment_date,
                        p_user_id,
                        NULL                        --p_creditor_bank VARCHAR2
                            ,
                        NULL                  --p_creditor_subsidiary VARCHAR2
                            ,
                        NULL                           --p_account_no VARCHAR2
                            ,
                        NULL                        --p_account_owner VARCHAR2
                            ,
                        NULL                        --p_indem_acc_exp VARCHAR2
                            ,
                        NULL                   --p_correspondent_bank VARCHAR2
                            ,
                        NULL             --p_correspondent_subsidiary VARCHAR2
                            ,
                        NULL               --p_correspondent_account_no NUMBER
                            ,
                        NULL                  --p_money_order_address VARCHAR2
                            ,
                        NULL,
                        NULL,
                        NULL,                                   -- p_iban_code
                        NULL,                     --p_correspondent_iban_code,
                        NULL,                                        --p_tc_no
                        NULL                                        --p_vkn_no
                            );

                     koc_clm_hlth_trnx2.indemnitypayment (stat.claim_id,
                                                          stat.sf_no,
                                                          1,
                                                          p_payment_date,
                                                          v_pay_batch_id);

                     UPDATE koc_clm_hlth_prov_statemnt
                        SET status_code = 'ODE'
                      WHERE     statement_no = p_statement_no
                            AND claim_id = stat.claim_id
                            AND sf_no = stat.sf_no
                            AND status_code IN ('P');

                     UPDATE koc_clm_hlth_detail
                        SET cpa_status = 'ODE'
                      WHERE     claim_id = stat.claim_id
                            AND sf_no = stat.sf_no
                            AND status_code IN ('ODE');

                     UPDATE koc_clm_hlth_incomp_papers
                        SET status_code = 'C'
                      WHERE     claim_id = stat.claim_id
                            AND sf_no = stat.sf_no
                            AND status_code IN ('A');
                  ELSE
                     ROLLBACK;
                  END IF;                                    -- v_pay_batch_id
               ELSE
                  ROLLBACK;
               END IF;                                           -- v_batch_id
            END IF;
         EXCEPTION
            WHEN OTHERS
            THEN
               ROLLBACK;
               RAISE_APPLICATION_ERROR (-20100,
                                        'Fi� Olu�turulamad�! ' || SQLERRM);
         END;
      END LOOP;

      CLOSE curstat;
   END doinstclmpaymentByClaim;                              -- ugurz:18012017

   PROCEDURE doinstclmpaymentAutoPayment (                   -- ugurz:18012017
                                          p_statement_no      NUMBER,
                                          p_institute_code    NUMBER,
                                          p_payment_date      DATE,
                                          p_user_id           VARCHAR2 /*,
                                         p_is_e_invoice_payer  NUMBER*/
                                                                      )
   IS
      CURSOR c_claims
      IS
         SELECT c.claim_id
           FROM koc_clm_hlth_prov_statemnt s, koc_clm_hlth_detail c
          WHERE     s.claim_id = c.claim_id
                AND s.Sf_No = c.Sf_No
                AND s.statement_no = p_statement_no
                AND c.cpa_status = 'TO'
                AND assigned_user IS NULL;

      v_claim_id   NUMBER;
   BEGIN
      OPEN c_claims;

      LOOP
         FETCH c_claims INTO v_claim_id;

         EXIT WHEN c_claims%NOTFOUND;
         KOC_CLM_HLTH_TRNX2.doinstclmpaymentByClaim (p_statement_no,
                                                     v_claim_id,
                                                     p_institute_code,
                                                     p_payment_date,
                                                     p_user_id);
      /*IF p_is_e_invoice_payer = 1 THEN
        UPDATE koc_clm_hlth_prov_statemnt x
           SET inv_status = 'O'
         WHERE x.claim_id = v_claim_id
           AND x.statement_no = p_statement_no
           AND inv_status IS NULL;
      END IF; 22022017*/

      END LOOP;

      CLOSE c_claims;
   END doinstclmpaymentAutoPayment;                          -- ugurz:18012017

   PROCEDURE indemnitypayment (p_claim_id        NUMBER,
                               p_sf_no           NUMBER,
                               p_add_order_no    NUMBER,
                               p_payment_date    DATE,
                               p_batch_id        NUMBER)
   IS
   BEGIN
      UPDATE koc_clm_trans_ext a
         SET ticket_date = p_payment_date, batch_id = p_batch_id
       WHERE     claim_id = p_claim_id
             AND sf_no = p_sf_no
             AND add_order_no = p_add_order_no
             AND a.realization_batch_id IS NOT NULL
             AND trans_no =
                    (SELECT MAX (xx.trans_no)
                       FROM koc_clm_trans_ext xx, clm_trans yy
                      WHERE     xx.claim_id = a.claim_id
                            AND xx.sf_no = a.sf_no
                            AND xx.add_order_no = a.add_order_no
                            AND xx.hlth_cover_code = a.hlth_cover_code
                            AND xx.claim_id = yy.claim_id
                            AND xx.sf_no = yy.sf_no
                            AND xx.trans_no = yy.trans_no
                            AND yy.sf_total_type IN ('11', '12', '10'));

      UPDATE koc_clm_hlth_detail a
         SET status_code = 'ODE'
       WHERE     a.claim_id = p_claim_id
             AND a.sf_no = p_sf_no
             AND a.add_order_no = p_add_order_no
             AND a.status_code = 'TAH';

      UPDATE koc_clm_hlth_provisions a
         SET status_code = 'ODE'
       WHERE     a.claim_id = p_claim_id
             AND a.sf_no = p_sf_no
             AND a.add_order_no = p_add_order_no
             AND a.status_code = 'TAH';

      UPDATE koc_clm_hlth_proc_detail a
         SET status_code = 'ODE'
       WHERE     a.claim_id = p_claim_id
             AND a.sf_no = p_sf_no
             AND a.add_order_no = p_add_order_no
             AND a.status_code = 'TAH';

      --150428 BC yetki limit
      UPDATE KOC_CLM_HLTH_PROV_LIMIT a
         SET claim_status = 'ODE'
       WHERE     a.claim_id = p_claim_id
             AND a.sf_no = p_sf_no
             AND a.add_order_no = p_add_order_no
             AND a.claim_status = 'TAH';
   END;

   PROCEDURE doclmrealizationacc (p_claim_id                NUMBER,
                                  p_sf_no                   NUMBER,
                                  p_add_order_no            NUMBER,
                                  p_dc                      NUMBER,
                                  p_product_id              NUMBER,
                                  p_partition_type          VARCHAR2,
                                  p_term_start_date         DATE,
                                  p_source_of_invoice       NUMBER,
                                  p_payment_date            DATE,
                                  p_batch_id            OUT NUMBER)
   IS
      -- p_source_of_invoice=1 ELDEN
      -- p_source_of_invoice=2 KURUM
      CURSOR clm
      IS
           SELECT a.claim_id,
                  a.swift_code,
                  b.provision_date,
                  b.invoice_date,
                  b.date_of_loss,
                  b.realization_date,
                  b.close_date,
                  b.ext_reference,
                  koc_clm_hlth_utils.getpartnernamebypartid (b.part_id)
                     partnername,
                  b.claim_inst_type,
                  b.claim_inst_loc,
                  a.cover_code,
                  b.country_code,
                  a.is_pool_cover,
                  a.is_special_cover,
                  B.Invoice_No,
                  B.Institute_Code,
                  SUM (a.provision_total) provision_total
             FROM koc_clm_hlth_provisions a, koc_clm_hlth_detail b
            WHERE     a.claim_id = p_claim_id
                  AND a.sf_no = p_sf_no
                  AND a.add_order_no = p_add_order_no
                  AND a.claim_id = b.claim_id
                  AND a.sf_no = b.sf_no
                  AND a.add_order_no = b.add_order_no
                  AND (   (p_dc = 1 AND a.status_code = 'P')
                       OR (p_dc = -1 AND a.status_code IN ('ODE', 'TAH')))
         GROUP BY a.claim_id,
                  a.swift_code,
                  b.provision_date,
                  b.invoice_date,
                  b.date_of_loss,
                  b.realization_date,
                  b.close_date,
                  b.ext_reference,
                  b.part_id,
                  b.claim_inst_type,
                  b.claim_inst_loc,
                  a.cover_code,
                  b.country_code,
                  a.is_pool_cover,
                  a.is_special_cover,
                  B.Invoice_No,
                  B.Institute_Code;

      CURSOR curp
      IS
         SELECT a.policy_ref,
                b.oar_no,
                b.contract_id,
                a.product_id,
                a.agent_role
           FROM clm_pol_bases a, clm_pol_oar b
          WHERE a.claim_id = b.claim_id AND a.claim_id = p_claim_id;

      recclm                     curp%ROWTYPE;

      CURSOR curacc (
         pp_product_id        NUMBER,
         pp_partition_type    VARCHAR2,
         pp_cover_code        VARCHAR2,
         pp_date              DATE)
      IS
         SELECT x.acc_cover_code
           FROM koc_oc_prod_part_main_cov x
          WHERE     x.product_id = pp_product_id
                AND x.partition_type = pp_partition_type
                AND x.cover_code = pp_cover_code
                AND x.validity_start_date <= pp_date
                AND NVL (x.validity_end_date, pp_date) >= pp_date;

      v_acc_cover_code           koc_oc_prod_part_main_cov.acc_cover_code%TYPE;

      CURSOR curdet (
         pp_contract_id NUMBER)
      IS
         SELECT a.branch_ext_ref,
                NVL (b.is_industrial,
                     DECODE (x.PRODUCT_ID,  63, 0,  64, 1,  1))
                   is_industrial
           FROM ocp_policy_contracts x,
                koc_ocp_pol_contracts_ext a,
                koc_ocp_pol_versions_ext b
          WHERE     a.contract_id = pp_contract_id
                AND x.contract_id = a.contract_id
                AND b.contract_id = a.contract_id
                AND b.version_no = 1;

      recdet                     curdet%ROWTYPE;


      clmdetail                  clm%ROWTYPE;

      v_postings                 koc_acc_utils.account_postingtyp;
      v_sayac                    NUMBER := 1;
      v_pay_curr_get_type        VARCHAR2 (4);
      v_pay_clearing_system_id   NUMBER;
      v_amount                   NUMBER;
      v_sub2                     VARCHAR2 (10);
      v_sub1                     VARCHAR2 (10);
      v_currency_exchange_rate   NUMBER;
      v_cover_swf                VARCHAR2 (20);
      v_exch_date                VARCHAR2 (20);
      v_curr_date                DATE;
      indeminfo                  koc_clm_hlth_indem_totals%ROWTYPE;
      icur                       koc_clm_hlth_trnx.refcur;
      v_indem_date               DATE;
      v_exp                      VARCHAR (100);
      v_country_group            NUMBER;
      p_user_id                  VARCHAR2 (30);
      v_partnername              VARCHAR2 (500);
      v_ext_reference            VARCHAR2 (30);
      wdigit_prim                NUMBER
         := NVL (find_round_digit (base_swift_code, 'P'), 2);

      v_related_order            NUMBER := 1;
      v_amount_rec               NUMBER := 0;

      v_cost_center_code         VARCHAR2 (10);
      v_sap_lob                  VARCHAR2 (10);
      v_sap_dist_channel         koc_acx_postings.SAP_DIST_CHANNEL%TYPE;

      v_document_type            VARCHAR2 (100);
      v_document_type_Exp        VARCHAR2 (100);
      --ademo.TPA.start
      v_tpa_company_code         ALZ_TPA_COMPANIES.COMPANY_CODE%TYPE;
      v_tpa_rci_company_id       KOC_RCI_COMPANIES_EXT.RCI_COMPANY_ID%TYPE;
   --ademo.TPA.end
   BEGIN
      p_user_id := USER;

      OPEN curp;

      FETCH curp INTO recclm;

      CLOSE curp;

      v_amount := 0;

      OPEN clm;

      LOOP
         FETCH clm INTO clmdetail;

         EXIT WHEN clm%NOTFOUND;
         v_currency_exchange_rate := 1;
         v_acc_cover_code := NULL;

         IF NVL (clmdetail.swift_code, base_swift_code) != base_swift_code
         THEN
            v_indem_date :=
               NVL (clmdetail.provision_date,
                    NVL (clmdetail.date_of_loss, clmdetail.invoice_date));

            v_country_group :=
               koc_clm_hlth_utils.getcountrygroup (clmdetail.country_code);
            koc_clm_hlth_trnx.getindemtotals (recclm.contract_id,
                                              recclm.oar_no,
                                              clmdetail.claim_inst_type,
                                              clmdetail.claim_inst_loc,
                                              v_country_group,
                                              clmdetail.cover_code,
                                              v_indem_date,
                                              0,
                                              0,
                                              p_user_id,
                                              clmdetail.is_pool_cover,
                                              clmdetail.is_special_cover,
                                              icur);

            FETCH icur INTO indeminfo;

            CLOSE icur;

            v_cover_swf := indeminfo.swift_code;

            SELECT DECODE (v_cover_swf,
                           base_swift_code, pay_clearing_system_id,
                           pay_swf_clear_sys_id),
                   DECODE (v_cover_swf,
                           base_swift_code, pay_curr_get_type,
                           pay_swf_curr_get_type),
                   DECODE (v_cover_swf,
                           base_swift_code, pay_exch_dates,
                           pay_swf_exch_dates)
              INTO v_pay_clearing_system_id, v_pay_curr_get_type, v_exch_date
              FROM koc_oc_prod_partition_rel
             WHERE     product_id = p_product_id
                   AND partition_type = p_partition_type
                   AND validity_start_date <= p_term_start_date
                   AND NVL (validity_end_date, p_term_start_date) >=
                          p_term_start_date;

            IF v_exch_date = 'FAT'
            THEN
               v_curr_date :=
                  NVL (clmdetail.provision_date, clmdetail.invoice_date);
            ELSIF v_exch_date = 'OLAY'
            THEN
               v_curr_date :=
                  NVL (clmdetail.provision_date,
                       NVL (clmdetail.date_of_loss, clmdetail.invoice_date));
            ELSIF v_exch_date = 'TAH'
            THEN
               v_curr_date := NVL (clmdetail.provision_date, p_payment_date);
            ELSE
               v_curr_date :=
                  NVL (clmdetail.provision_date, clmdetail.invoice_date);
            END IF;

            v_currency_exchange_rate :=
               koc_curr_utils.retrieve_currency_rate (
                  clmdetail.swift_code,
                  v_pay_curr_get_type,
                  TRUNC (v_curr_date),
                  v_pay_clearing_system_id,
                  TRUE);
         END IF;

         v_amount :=
              NVL (v_amount, 0)
            + ROUND (
                   clmdetail.provision_total
                 * NVL (v_currency_exchange_rate, 1),
                 wdigit_prim);

         v_amount_rec :=
            ROUND (
               clmdetail.provision_total * NVL (v_currency_exchange_rate, 1),
               wdigit_prim);
         v_partnername := clmdetail.partnername;
         v_ext_reference := clmdetail.ext_reference;


         IF v_amount_rec > 0
         THEN
            v_exp :=
                  RPAD (v_ext_reference, 12, ' ')
               || RPAD (SUBSTR (v_partnername, 1, 30), 30, ' ')
               || recclm.policy_ref
               || ' '
               || RPAD (recclm.oar_no, 10, ' ')
               || ' HDNO:'
               || p_claim_id
               || ' SIRA:'
               || p_add_order_no;

            IF p_source_of_invoice = 1
            THEN
               v_sub1 := '4178';

               IF p_product_id = 63
               THEN
                  IF p_partition_type = 'YDES'
                  THEN
                     v_sub1 := '4438';
                  END IF;
               END IF;
            END IF;

            IF p_source_of_invoice = 2
            THEN
               v_sub1 := '4437';
            END IF;



            /*
            v_institutetype := koc_clm_hlth_utils.getinstitutetype(clmdetail.institute_code);

        --- E-Fatura
        IF V_Payment_Group_Code = '5' THEN
           v_document_type     := 'SMM';
           v_document_type_Exp := 'SMM';
        else
            If (V_Institutetype = '2' And V_Payment_Group_Code = '4') Or (V_Institutetype <> '2' And V_Payment_Group_Code Not In ('4', '5')) Then
               V_Document_Type     := 'FTR';
               V_Document_Type_Exp := 'FTR';
            End If;
        END IF;
        --/ E-Fatura

*/

            v_sayac := 1;
            v_postings (v_sayac).account_category_code := 'YGENEL';
            v_postings (v_sayac).event_type_code := 'TAZMINAT';
            v_postings (v_sayac).event_order_no := 1;
            v_postings (v_sayac).subfactor_1_val := v_sub1;
            v_postings (v_sayac).posting_amount :=
               ROUND (p_dc * v_amount_rec, wdigit_prim);
            v_postings (v_sayac).posting_date := p_payment_date;
            v_postings (v_sayac).posting_type := 'MAHSUP';
            v_postings (v_sayac).swift_code := base_swift_code;
            v_postings (v_sayac).curr_exchg_rate := 1;
            v_postings (v_sayac).explanation := v_exp;
            v_postings (v_sayac).invoice_no := clmdetail.invoice_no;
            v_postings (v_sayac).invoice_date := clmdetail.invoice_date;
            v_postings (v_sayac).Document_Type := v_document_type;
            v_postings (v_sayac).Document_Type_Exp := v_document_type_Exp;
            --SAP 29/11/2011 YG --
            v_postings (v_sayac).related_order := v_related_order;
            --------------
            --ademo TPA.start
            v_postings (v_sayac).claim_id := p_claim_id;
            v_tpa_company_code := '045';

            IF p_claim_id IS NOT NULL
            THEN
               v_tpa_company_code :=
                  Alz_Tpa_Core_Utils.Get_Company_Code_By_Claim (p_claim_id);
            END IF;

            IF NVL (v_tpa_company_code, '999') NOT IN ('045', '999')
            THEN
               v_tpa_rci_company_id :=
                  Alz_Tpa_Claim_Utils.Get_Tpa_Rci_Company_Id (p_claim_id);
               v_sayac := v_sayac + 1;
               v_sub1 := TO_CHAR (v_tpa_rci_company_id);
               v_postings (v_sayac).account_category_code := 'YALINAN05';
               v_postings (v_sayac).event_type_code := 'TAZMINAT';
               v_postings (v_sayac).event_order_no := 1;
               v_postings (v_sayac).subfactor_1_val := v_sub1;
               v_postings (v_sayac).subfactor_2_val := '1';
               v_postings (v_sayac).subfactor_3_val := '4';
               v_postings (v_sayac).posting_amount :=
                  ROUND (p_dc * v_amount_rec, wdigit_prim);
               v_postings (v_sayac).posting_date := p_payment_date;
               v_postings (v_sayac).posting_type := 'MAHSUP';
               v_postings (v_sayac).swift_code := base_swift_code;
               v_postings (v_sayac).curr_exchg_rate := 1;
               v_postings (v_sayac).explanation := v_exp;
               v_postings (v_sayac).invoice_no := clmdetail.invoice_no;
               v_postings (v_sayac).invoice_date := clmdetail.invoice_date;
               v_postings (v_sayac).Document_Type := v_document_type;
               v_postings (v_sayac).Document_Type_Exp := v_document_type_Exp;
               --SAP 29/11/2011 YG --
               v_postings (v_sayac).related_order := v_related_order;
               v_postings (v_sayac).claim_id := p_claim_id;

               v_sayac := v_sayac + 1;

               v_postings (v_sayac).account_category_code := 'YALINAN05';
               v_postings (v_sayac).event_type_code := 'TAZMINAT';
               v_postings (v_sayac).event_order_no := 1;
               v_postings (v_sayac).subfactor_1_val := v_sub1;
               v_postings (v_sayac).subfactor_2_val := '1';
               v_postings (v_sayac).subfactor_3_val := '4';
               v_postings (v_sayac).posting_amount :=
                  ROUND (-1 * p_dc * v_amount_rec, wdigit_prim);
               v_postings (v_sayac).posting_date := p_payment_date;
               v_postings (v_sayac).posting_type := 'MAHSUP';
               v_postings (v_sayac).swift_code := base_swift_code;
               v_postings (v_sayac).curr_exchg_rate := 1;
               v_postings (v_sayac).explanation := v_exp;
               v_postings (v_sayac).invoice_no := clmdetail.invoice_no;
               v_postings (v_sayac).invoice_date := clmdetail.invoice_date;
               v_postings (v_sayac).Document_Type := v_document_type;
               v_postings (v_sayac).Document_Type_Exp := v_document_type_Exp;
               --SAP 29/11/2011 YG --
               v_postings (v_sayac).related_order := v_related_order;
               v_postings (v_sayac).claim_id := p_claim_id;
            END IF;

            --------------

            v_sub2 := '01';

            IF NVL (v_tpa_company_code, '999') NOT IN ('045', '999')
            THEN
               v_sub2 := '02';
            END IF;

            --ademo TPA.end

            ----
            v_sayac := v_sayac + 1;
            v_postings (v_sayac).account_category_code := 'YTEK02111';
            v_postings (v_sayac).event_type_code := 'TAZMINAT';
            v_postings (v_sayac).event_order_no := 1;

            IF p_payment_date < TO_DATE ('01.01.2008', 'dd.mm.yyyy')
            THEN
               v_postings (v_sayac).subfactor_1_val := '86';
            ELSE
               v_postings (v_sayac).subfactor_1_val := '85';
            END IF;

            v_postings (v_sayac).subfactor_2_val := v_sub2;

            IF TO_NUMBER (TO_CHAR (clmdetail.date_of_loss, 'YYYY')) =
                  TO_NUMBER (TO_CHAR (p_payment_date, 'YYYY'))
            THEN
               v_postings (v_sayac).subfactor_3_val := '01';
            ELSE
               v_postings (v_sayac).subfactor_3_val := '02';
            END IF;

            v_postings (v_sayac).subfactor_4_val := '01';

            v_postings (v_sayac).posting_amount :=
               ROUND (-1 * p_dc * v_amount_rec, wdigit_prim);
            v_postings (v_sayac).posting_date := p_payment_date;
            v_postings (v_sayac).posting_type := 'MAHSUP';
            v_postings (v_sayac).swift_code := base_swift_code;
            v_postings (v_sayac).curr_exchg_rate := 1;
            v_postings (v_sayac).explanation := v_exp;
            v_postings (v_sayac).invoice_no := clmdetail.invoice_no;
            v_postings (v_sayac).invoice_date := clmdetail.invoice_date;
            v_postings (v_sayac).Document_Type := v_document_type;
            v_postings (v_sayac).Document_Type_Exp := v_document_type_Exp;
            --SAP 29/11/2011 YG --
            recdet := NULL;

            OPEN curdet (recclm.contract_id);

            FETCH curdet INTO recdet;

            CLOSE curdet;

            OPEN curacc (p_product_id,
                         p_partition_type,
                         clmdetail.cover_code,
                         p_payment_date);

            FETCH curacc INTO v_acc_cover_code;

            CLOSE curacc;

            v_sap_lob := '785';

            IF recclm.agent_role IS NULL
            THEN
               v_sap_dist_channel := '73';
            END IF;

            IF recdet.is_industrial IS NULL
            THEN
               recdet.is_industrial := 0;
            END IF;

            v_postings (v_sayac).agent_int_id := recclm.agent_role;
            v_postings (v_sayac).product_id := p_product_id;
            v_postings (v_sayac).partition_type := p_partition_type;
            v_postings (v_sayac).branch_ext_ref := recdet.branch_ext_ref;
            v_postings (v_sayac).acc_cover_group := v_acc_cover_code;
            v_postings (v_sayac).is_industrial := recdet.is_industrial;
            v_postings (v_sayac).sap_lob := v_sap_lob;
            v_postings (v_sayac).sap_dist_channel := v_sap_dist_channel;
            v_postings (v_sayac).related_order := v_related_order;
            --ademo TPA.start
            v_postings (v_sayac).claim_id := p_claim_id;

            IF NVL (v_tpa_company_code, '999') NOT IN ('045', '999')
            THEN
               v_postings (v_sayac).trading_code := v_tpa_rci_company_id;
            END IF;

            -- ademo TPA.end
            ----------------------
            v_related_order := v_related_order + 1;
            v_sayac := v_sayac + 1;

            koc_acc_utils.posting_accounts (v_postings,
                                            'ACC',
                                            '10',
                                            NULL,
                                            'Allianz Sigorta',
                                            p_batch_id);
         END IF;
      END LOOP;

      CLOSE clm;

      IF v_amount > 0
      THEN
         IF p_dc = 1
         THEN
            UPDATE koc_clm_hlth_detail
               SET payment_total = v_amount,
                   realization_date = p_payment_date
             WHERE     claim_id = p_claim_id
                   AND sf_no = p_sf_no
                   AND add_order_no = p_add_order_no;
         ELSE
            UPDATE koc_clm_hlth_detail
               SET payment_total = NULL, realization_date = NULL
             WHERE     claim_id = p_claim_id
                   AND sf_no = p_sf_no
                   AND add_order_no = p_add_order_no;
         END IF;
      END IF;
   END;

   FUNCTION getstoppageamount (p_amount           IN NUMBER,
                               p_institute_code   IN NUMBER,
                               pinvoice_date      IN DATE,
                               pdate_of_loss      IN DATE)
      RETURN NUMBER
   IS
      --cozbay task132695 07.02.2012 stopaj amount hesaplama. tek bir yerde hesaplayalimki heryerde kullanalim
      vstoppage_amount      NUMBER;
      vpayment_group_code   koc_clm_suppliers_ext.payment_group_code%TYPE;
      vstoppage_date        DATE;
      wdigit_prim           NUMBER
         := NVL (find_round_digit (base_swift_code, 'P'), 2);

      CURSOR cur_pymt_grp_code
      IS
         SELECT a.payment_group_code
           FROM koc_clm_suppliers_ext a
          WHERE a.institute_code = p_institute_code;
   BEGIN
      OPEN cur_pymt_grp_code;

      FETCH cur_pymt_grp_code INTO vpayment_group_code;

      CLOSE cur_pymt_grp_code;

      --sadece �deme tipi 5 olanlarda
      IF NVL (vpayment_group_code, '0') = '5'
      THEN
         vstoppage_date :=
            TO_DATE (KOC_SYSTEM_PARAMETER.GET_PARAMETER ('STOPPAGE_DATE'),
                     'DD.MM.YYYY');

         --stopaj ge�i� tarihinden b�y�k olanlarda
         IF    (    pinvoice_date >= vstoppage_date
                AND pdate_of_loss >= vstoppage_date)
            OR (    pinvoice_date >= vstoppage_date
                AND pdate_of_loss < vstoppage_date)
         THEN
            vstoppage_amount := (NVL (p_amount, 0) / 1.08) * 0.2;
         ELSE
            vstoppage_amount := 0;
         END IF;
      ELSE
         vstoppage_amount := 0;
      END IF;

      RETURN ROUND (NVL (vstoppage_amount, 0), wdigit_prim);
   END;

   PROCEDURE doclmpaymentacc (p_claim_id                NUMBER,
                              p_sf_no                   NUMBER,
                              p_add_order_no            NUMBER,
                              p_dc                      NUMBER,
                              p_institute_code          NUMBER,
                              p_product_id              NUMBER,
                              p_partition_type          VARCHAR2,
                              p_term_start_date         DATE,
                              p_source_of_invoice       NUMBER,
                              p_payment_date            DATE,
                              p_batch_id            OUT NUMBER)
   IS
      -- p_source_of_invoice=1 ELDEN
      -- p_source_of_invoice=2 KURUM
      -- bu procedure yaln�zca provizyon i�in kullan�lyor (KURUM)
      CURSOR clm
      IS
           SELECT a.claim_id,
                  a.swift_code,
                  SUM (a.provision_total) provision_total,
                  b.provision_date,
                  b.invoice_date,
                  b.date_of_loss,
                  b.realization_date,
                  b.close_date,                             /*, a.cover_code*/
                  --cozbay burada yanlislik vardi
                  B.Invoice_No,
                  B.Institute_Code
             FROM koc_clm_hlth_provisions a, koc_clm_hlth_detail b
            WHERE     a.claim_id = p_claim_id
                  AND a.sf_no = p_sf_no
                  AND a.add_order_no = p_add_order_no
                  AND a.claim_id = b.claim_id
                  AND a.sf_no = b.sf_no
                  AND a.add_order_no = b.add_order_no
                  AND (   (p_dc = 1 AND a.status_code = 'P')
                       OR (p_dc = -1 AND a.status_code IN ('ODE')))
         GROUP BY a.claim_id,
                  a.swift_code,
                  b.provision_date,
                  b.invoice_date,
                  b.date_of_loss,
                  b.realization_date,
                  b.close_date,
                  B.Invoice_No,
                  B.Institute_Code
           HAVING SUM (a.provision_total) > 0;

      clmdetail                  clm%ROWTYPE;
      v_postings                 koc_acc_utils.account_postingtyp;
      v_sayac                    NUMBER;
      v_pay_curr_get_type        VARCHAR2 (4);
      v_pay_clearing_system_id   NUMBER;
      v_amount                   NUMBER;
      v_sub2                     VARCHAR2 (10);
      v_sub1                     VARCHAR2 (10);
      v_currency_exchange_rate   NUMBER;
      v_cover_swf                VARCHAR2 (20);
      v_exch_date                VARCHAR2 (20);
      v_curr_date                DATE;
      wdigit_prim                NUMBER
         := NVL (find_round_digit (base_swift_code, 'P'), 2);
      vstoppage_amount           NUMBER;
      veksi_stp_amount           NUMBER;
      v_account_category_code    ac_account_categories.account_category_code%TYPE;
      v_stoppage_y_n             BOOLEAN := FALSE;
      v_part_id                  koc_mv_skrm_suppliers.part_id%TYPE;
      v_doctor_name              koc_mv_skrm_suppliers.name%TYPE;
      v_last_date                DATE;
      v_statement_no             koc_clm_hlth_prov_statemnt.statement_no%TYPE;

      V_Payment_Group_Code       Koc_V_Clm_Suppliers_M1.Payment_Group_Code%TYPE;
      v_institutetype            NUMBER;
      v_document_type            VARCHAR2 (100);
      v_document_type_Exp        VARCHAR2 (100);

      CURSOR cur_doctor_name (pinst_code IN NUMBER)
      IS
         SELECT s.part_id, s.name
           FROM koc_mv_skrm_suppliers s
          WHERE s.institute_code = pinst_code;

      CURSOR cur_statement_no (
         pclaim_id   IN NUMBER,
         psf_no      IN NUMBER)
      IS
         SELECT statement_no
           FROM KOC_CLM_HLTH_PROV_STATEMNT
          WHERE     claim_id = pclaim_id
                AND sf_no = psf_no
                AND status_code = 'ODE';
   BEGIN
      --p_stoppage:=null;

      OPEN clm;

      FETCH clm INTO clmdetail;

      CLOSE clm;

      IF clmdetail.claim_id IS NOT NULL
      THEN
         v_currency_exchange_rate := 1;

         IF NVL (clmdetail.swift_code, base_swift_code) != base_swift_code
         THEN
            v_cover_swf := clmdetail.swift_code;

            SELECT DECODE (v_cover_swf,
                           base_swift_code, pay_clearing_system_id,
                           pay_swf_clear_sys_id),
                   DECODE (v_cover_swf,
                           base_swift_code, pay_curr_get_type,
                           pay_swf_curr_get_type),
                   DECODE (v_cover_swf,
                           base_swift_code, pay_exch_dates,
                           pay_swf_exch_dates)
              INTO v_pay_clearing_system_id, v_pay_curr_get_type, v_exch_date
              FROM koc_oc_prod_partition_rel
             WHERE     product_id = p_product_id
                   AND partition_type = p_partition_type
                   AND validity_start_date <= p_term_start_date
                   AND NVL (validity_end_date, p_term_start_date) >=
                          p_term_start_date;

            IF v_exch_date = 'FAT'
            THEN
               v_curr_date :=
                  NVL (clmdetail.provision_date, clmdetail.invoice_date);
            ELSIF v_exch_date = 'OLAY'
            THEN
               v_curr_date :=
                  NVL (clmdetail.provision_date,
                       NVL (clmdetail.date_of_loss, clmdetail.invoice_date));
            ELSIF v_exch_date = 'TAH'
            THEN
               v_curr_date := NVL (clmdetail.provision_date, p_payment_date);
            ELSE
               v_curr_date :=
                  NVL (clmdetail.provision_date, clmdetail.invoice_date);
            END IF;

            v_currency_exchange_rate :=
               koc_curr_utils.retrieve_currency_rate (
                  clmdetail.swift_code,
                  v_pay_curr_get_type,
                  TRUNC (v_curr_date),
                  v_pay_clearing_system_id,
                  TRUE);
         END IF;

         v_amount :=
            clmdetail.provision_total * NVL (v_currency_exchange_rate, 1);

         v_institutetype :=
            koc_clm_hlth_utils.getinstitutetype (clmdetail.institute_code);
         V_Payment_Group_Code :=
            Get_Payment_Group_By_Inst_Code (clmdetail.Institute_Code);

         --- E-Fatura
         v_document_type := 'DGR';
         v_document_type_Exp := 'DGR';

         IF V_Payment_Group_Code = '5'
         THEN
            v_document_type := 'SMM';
            v_document_type_Exp := 'SMM';
         ELSE
            IF (V_Institutetype = '2' AND V_Payment_Group_Code = '4')
            THEN -- eczane ise buradaki fi�ler i�in belge t�r� DGR ��ks�n isteniyor M�jde G�m��o�lu
               V_Document_Type := 'DGR';
               V_Document_Type_Exp := 'DGR';
            ELSIF (    V_Institutetype <> '2'
                   AND V_Payment_Group_Code NOT IN ('4', '5'))
            THEN
               V_Document_Type := 'FTR';
               V_Document_Type_Exp := 'FTR';
            END IF;
         END IF;

         --/ E-Fatura

         v_sub1 := '4437';
         ----
         v_sayac := 1;
         v_postings (v_sayac).account_category_code := 'YGENEL';
         v_postings (v_sayac).event_type_code := 'TAZMINAT';
         v_postings (v_sayac).subfactor_1_val := v_sub1;
         v_postings (v_sayac).posting_amount :=
            ROUND (p_dc * -1 * v_amount, wdigit_prim);
         v_postings (v_sayac).posting_date := p_payment_date;
         v_postings (v_sayac).posting_type := 'MAHSUP';
         v_postings (v_sayac).swift_code := base_swift_code;
         v_postings (v_sayac).curr_exchg_rate := 1;
         v_postings (v_sayac).explanation :=
            'HASAR DOSYA NO:' || p_claim_id || ' SIRA:' || p_add_order_no;
         v_postings (v_sayac).invoice_no := clmdetail.invoice_no;
         v_postings (v_sayac).invoice_date := clmdetail.invoice_date;
         v_postings (v_sayac).Document_Type := v_document_type;
         v_postings (v_sayac).Document_Type_Exp := v_document_type_Exp;
         --SAP 29/11/2011 YG --
         v_postings (v_sayac).related_order := 1;
         ----------------------

         -- cozbay task132695 02.02.2012 artik stopaji ayiriyoruz start

         vstoppage_amount :=
            koc_clm_hlth_trnx2.getstoppageamount (v_amount,
                                                  p_institute_code,
                                                  clmdetail.invoice_date,
                                                  clmdetail.date_of_loss);

         IF vstoppage_amount <> 0
         THEN                                   --artik stopaj tutari ayrilcak
            veksi_stp_amount := v_amount - vstoppage_amount;
            v_last_date := LAST_DAY (ADD_MONTHS (p_payment_date, -1));

            IF TO_CHAR (clmdetail.invoice_date, 'MM') =
                  TO_CHAR (p_payment_date, 'MM')
            THEN
               v_stoppage_y_n := TRUE;
               v_amount := veksi_stp_amount;
               v_account_category_code := 'YSTOPAJ';
               v_sub1 := '3003';
            ELSIF clmdetail.invoice_date <= v_last_date
            THEN
               v_stoppage_y_n := TRUE;
               v_amount := veksi_stp_amount;
               v_account_category_code := 'YKURUM';
               v_sub1 := 'S99';
            ELSE
               v_stoppage_y_n := FALSE;
            END IF;
         ELSE
            v_stoppage_y_n := FALSE;
         END IF;

         IF v_stoppage_y_n
         THEN
            OPEN cur_doctor_name (p_institute_code);

            FETCH cur_doctor_name
            INTO v_part_id, v_doctor_name;

            CLOSE cur_doctor_name;

            v_sayac := v_sayac + 1;
            v_postings (v_sayac).account_category_code :=
               v_account_category_code;
            v_postings (v_sayac).event_type_code := 'TAZMINAT';
            v_postings (v_sayac).subfactor_1_val := v_sub1;
            v_postings (v_sayac).posting_amount :=
               ROUND (p_dc * vstoppage_amount, wdigit_prim);
            v_postings (v_sayac).posting_date := p_payment_date;
            v_postings (v_sayac).posting_type := 'MAHSUP';
            v_postings (v_sayac).swift_code := base_swift_code;
            v_postings (v_sayac).curr_exchg_rate := 1;
            v_postings (v_sayac).explanation :=
               SUBSTR (
                     'HASAR DOSYA NO:'
                  || p_claim_id
                  || ' SIRA:'
                  || p_add_order_no
                  || ' DOKTOR UNSUR NO: '
                  || v_part_id
                  || ' DOKTOR ADI: '
                  || v_doctor_name,
                  1,
                  100);
            v_postings (v_sayac).invoice_no := clmdetail.invoice_no;
            v_postings (v_sayac).invoice_date := clmdetail.invoice_date;
            v_postings (v_sayac).Document_Type := v_document_type;
            v_postings (v_sayac).Document_Type_Exp := v_document_type_Exp;
            v_postings (v_sayac).related_order := 1;

            -- iptallerde mail atiyoruz
            IF     p_dc = -1
               AND TO_NUMBER (TO_CHAR (p_payment_date, 'DD')) >= 15
               AND clmdetail.invoice_date <= v_last_date
            THEN
               --once icmal numarasini buluyoruz
               OPEN cur_statement_no (p_claim_id, p_sf_no);

               FETCH cur_statement_no INTO v_statement_no;

               CLOSE cur_statement_no;

               ---mail at

               koc_clm_hlth_trnx2.pcancelstoppagemail (
                  v_statement_no,
                  p_claim_id,
                  clmdetail.invoice_date,
                  v_amount + vstoppage_amount,
                  vstoppage_amount);
            END IF;
         END IF;

         -- cozbay task132695 02.02.2012 artik stopaji ayiriyoruz end

         v_sub1 := p_institute_code;
         v_sayac := v_sayac + 1;
         v_postings (v_sayac).account_category_code := 'YKURUM';
         v_postings (v_sayac).event_type_code := 'TAZMINAT';
         v_postings (v_sayac).subfactor_1_val := v_sub1;
         v_postings (v_sayac).posting_amount :=
            ROUND (p_dc * v_amount, wdigit_prim);
         v_postings (v_sayac).posting_date := p_payment_date;
         v_postings (v_sayac).posting_type := 'MAHSUP';
         v_postings (v_sayac).swift_code := base_swift_code;
         v_postings (v_sayac).curr_exchg_rate := 1;
         v_postings (v_sayac).explanation :=
            'HASAR DOSYA NO:' || p_claim_id || ' SIRA:' || p_add_order_no;
         v_postings (v_sayac).invoice_no := clmdetail.invoice_no;
         v_postings (v_sayac).invoice_date := clmdetail.invoice_date;
         v_postings (v_sayac).Document_Type := v_document_type;
         v_postings (v_sayac).Document_Type_Exp := v_document_type_Exp;
         --SAP 29/11/2011 YG --
         v_postings (v_sayac).related_order := 1;
         ----------------------
         koc_acc_utils.posting_accounts (v_postings,
                                         'ACC',
                                         '10',
                                         NULL,
                                         'Allianz Sigorta',
                                         p_batch_id);
      END IF;
   END;

   PROCEDURE doinsttransaccbytype (p_trans_date               DATE,
                                   p_trans_date2              DATE,
                                   p_trans_type               NUMBER,
                                   p_trans_group              VARCHAR2,
                                   p_payment_group_code       VARCHAR2,
                                   p_institute_code           NUMBER,
                                   p_dc                       NUMBER,
                                   p_pay_month                NUMBER,
                                   p_pay_year                 NUMBER,
                                   p_acc_date                 DATE,
                                   p_batch_id             OUT NUMBER)
   IS
      TYPE daterec IS RECORD
      (
         pay_month            NUMBER,
         pay_year             NUMBER,
         institute_code       NUMBER,
         payment_group_code   VARCHAR2 (10)
      );

      TYPE datetbl IS TABLE OF daterec
                         INDEX BY BINARY_INTEGER;

      v_base_swift_code              VARCHAR2 (5) := base_swift_code;

      CURSOR trnx
      IS
           SELECT --/*+ index(a KOC_CLM_HLTH_INST_TRANS_PK, KOC_CLM_HLTH_INST_TRANS_IDX3)*/
                 'not_sap' d_type,
                  a.institute_code,
                  a.trans_type,
                  b.SIGN,
                  A.Claim_Id claim_id,
                  A.Sf_No sf_no,
                  a.add_order_no,
                  SUM (a.trans_amount) trans_amt,
                  v_base_swift_code swift_code,
                  a.explanation,
                  a.payment_group_code,
                  a.trans_date,
                  a.account_no,
                  C.Invoice_No,
                  C.Invoice_Date,
                  C.Ext_Reference,
                  A.Trans_No,
                  A.Order_No
             FROM koc_clm_hlth_inst_trans a,
                  koc_cc_inst_trans_ref b,
                  koc_clm_hlth_detail c
            WHERE     a.trans_type =
                         DECODE (p_trans_type,
                                 NULL, a.trans_type,
                                 p_trans_type)
                  AND a.trans_type IN (2, 11, 33, 34)
                  AND a.trans_amount > 0                    --08.04.2009 AYSEL
                  AND b.trans_group = p_trans_group
                  AND a.trans_type = b.trans_type
                  AND a.pay_year =
                         DECODE (p_pay_year, NULL, a.pay_year, p_pay_year)
                  AND a.pay_month =
                         DECODE (p_pay_month, NULL, a.pay_month, p_pay_month)
                  AND a.trans_date BETWEEN DECODE (p_trans_date,
                                                   NULL, a.trans_date,
                                                   p_trans_date)
                                       AND DECODE (p_trans_date2,
                                                   NULL, a.trans_date,
                                                   p_trans_date2)
                  AND a.institute_code =
                         DECODE (p_institute_code,
                                 NULL, a.institute_code,
                                 p_institute_code)
                  AND a.payment_group_code =
                         DECODE (p_payment_group_code,
                                 NULL, a.payment_group_code,
                                 p_payment_group_code)
                  AND a.batch_id IS NULL
                  AND C.Claim_Id(+) = A.Claim_Id
                  AND C.Sf_No(+) = A.Sf_No
                  AND C.Add_Order_No(+) = A.Add_Order_No
         GROUP BY a.institute_code,
                  a.trans_type,
                  b.SIGN,
                  a.add_order_no,
                  a.explanation,
                  a.payment_group_code,
                  a.trans_date,
                  a.account_no,
                  A.Claim_Id,
                  A.Sf_No,
                  C.Ext_Reference,
                  C.Invoice_No,
                  C.Invoice_Date,
                  A.Trans_No,
                  A.Order_No
           HAVING SUM (a.trans_amount) > 0
         UNION ALL
           SELECT --/*+ index(a KOC_CLM_HLTH_INST_TRANS_PK, KOC_CLM_HLTH_INST_TRANS_IDX3)*/
                 'sap' d_type,
                  a.institute_code,
                  a.trans_type,
                  b.SIGN,
                  a.claim_id,
                  a.sf_no,
                  a.add_order_no,
                  SUM (a.trans_amount) trans_amt,
                  v_base_swift_code swift_code,
                  a.explanation,
                  a.payment_group_code,
                  a.trans_date,
                  a.account_no,
                  C.Invoice_No,
                  C.Invoice_Date,
                  C.Ext_Reference,
                  A.Trans_No,
                  A.Order_No
             FROM koc_clm_hlth_inst_trans a,
                  koc_cc_inst_trans_ref b,
                  koc_clm_hlth_detail c
            WHERE     a.trans_type =
                         DECODE (p_trans_type,
                                 NULL, a.trans_type,
                                 p_trans_type)
                  AND a.trans_type NOT IN (1, 21, 18, 2, 11, 33, 34)    --,28)
                  AND a.trans_amount > 0                    --08.04.2009 AYSEL
                  AND b.trans_group = p_trans_group
                  AND a.trans_type = b.trans_type
                  AND a.pay_year =
                         DECODE (p_pay_year, NULL, a.pay_year, p_pay_year)
                  AND a.pay_month =
                         DECODE (p_pay_month, NULL, a.pay_month, p_pay_month)
                  AND a.trans_date BETWEEN DECODE (p_trans_date,
                                                   NULL, a.trans_date,
                                                   p_trans_date)
                                       AND DECODE (p_trans_date2,
                                                   NULL, a.trans_date,
                                                   p_trans_date2)
                  AND a.institute_code =
                         DECODE (p_institute_code,
                                 NULL, a.institute_code,
                                 p_institute_code)
                  AND a.payment_group_code =
                         DECODE (p_payment_group_code,
                                 NULL, a.payment_group_code,
                                 p_payment_group_code)
                  AND a.batch_id IS NULL
                  AND C.Claim_Id(+) = A.Claim_Id
                  AND C.Sf_No(+) = A.Sf_No
                  AND C.Add_Order_No(+) = A.Add_Order_No
         GROUP BY a.institute_code,
                  a.trans_type,
                  b.SIGN,
                  a.claim_id,
                  a.sf_no,
                  a.add_order_no,
                  a.explanation,
                  a.payment_group_code,
                  a.trans_date,
                  a.account_no,
                  C.Invoice_No,
                  C.Invoice_Date,
                  C.Ext_Reference,
                  A.Trans_No,
                  A.Order_No
           HAVING SUM (a.trans_amount) > 0
         ORDER BY 2; -- KES�NL�KLE �LK OLARAK INSTITUTE_CODE A G�RE SIRALI OLMALI

      CURSOR cur_sap_det (
         p_claim_id    NUMBER,
         p_sf_no       NUMBER)
      IS
         --         SELECT c.cover_code,
         --                e.sap_dist_channel,
         --                pb.product_id,
         --                se.partition_type,
         --                NVL (se.is_industrial, 0) is_industrial,
         --                DECODE (TO_NUMBER (TO_CHAR (se.date_of_loss, 'yyyy')),
         --                        TO_NUMBER (TO_CHAR (p_acc_date, 'yyyy')), '01',
         --                        '02')
         --                   dyear
         --           FROM koc_clm_hlth_provisions c,
         --                clm_pol_bases pb,
         --                koc_clm_subfiles_ext se,
         --                koc_dmt_agents_ext e
         --          WHERE     c.claim_id = p_claim_id
         --                AND c.sf_no = p_sf_no
         --                AND pb.claim_id = c.claim_id
         --                AND se.claim_id = c.claim_id
         --                AND se.sf_no = c.sf_no
         --                AND e.int_id = NVL (pb.agent_role, se.agent_role);
         SELECT c.cover_code,
                e.sap_dist_channel,
                pb.product_id,
                se.partition_type,
                NVL (Pve.is_industrial, 0) is_industrial,
                DECODE (TO_NUMBER (TO_CHAR (se.date_of_loss, 'yyyy')),
                        TO_NUMBER (TO_CHAR (p_acc_date, 'yyyy')), '01',
                        '02')
                   dyear
           FROM koc_clm_hlth_provisions c,
                clm_pol_bases pb,
                koc_clm_subfiles_ext se,
                ocp_policy_bases opb,
                koc_ocp_pol_versions_ext pve,
                koc_dmt_agents_ext e
          WHERE     c.claim_id = p_claim_id
                AND c.sf_no = p_sf_no
                AND pb.claim_id = c.claim_id
                AND se.claim_id = c.claim_id
                AND se.sf_no = c.sf_no
                AND Opb.Contract_Id = pb.contract_id
                AND Opb.Top_Indicator = 'Y'
                AND Pve.Contract_Id = pb.Contract_Id
                AND Pve.Version_No = 1
                AND e.Int_Id = Opb.Agent_Role;

      rec_sap_det                    cur_sap_det%ROWTYPE;
      v_cost_center_code             VARCHAR2 (10);

      CURSOR cur_branch (
         p_product_id NUMBER)
      IS
         SELECT c.ext_reference branch_ext_ref
           FROM oc_products a, koc_oc_branch_prod_groups b, koc_oc_branches c
          WHERE     a.product_id = p_product_id
                AND b.product_group_id = a.product_group_id
                AND c.branch_id = b.branch_id;

      v_branch                       koc_oc_branches.ext_reference%TYPE;

      CURSOR trnxiade (
         p_start_date            DATE,
         p_end_date              DATE,
         p_institute_code        NUMBER,
         --p_payment_group_code   NUMBER, mustafaku kpamuk TSS
         p_payment_group_code    VARCHAR2,
         p_pay_year              NUMBER,
         p_pay_month             NUMBER,
         p_trans_type            NUMBER,
         p_trans_group           VARCHAR2,
         p_trans_date            DATE,
         p_trans_date2           DATE)
      IS
         -- kurum kodu s�ras� kesinlikle bozulmamamal�
         SELECT qiade.trans_type,
                qclm.institute_code,
                qclm.claim_id,
                qclm.ext_reference,
                qclm.ip_no,
                qclm.partition_no,
                qclm.sf_no,
                qclm.supp_id,
                qclm.invoice_date,
                qclm.date_of_loss,
                    /*cozbay task132695 09.02.2012 invoice_date ve date_of_loss eklendi*/
                    DECODE (qiade.trans_type,  2, 1,  4, 1,  5, 1,  0)
                  * ROUND (
                         qiade.trans_amt
                       * qclm.trn_amount_11
                       / DECODE (qtop.trn_amount_11,
                                 0, 1,
                                 qtop.trn_amount_11),
                       2)
                +   DECODE (qiade.trans_type, 11, 1, 0)
                  * ROUND (
                         qiade.trans_amt
                       * qclm.trn_amount_12
                       / DECODE (qtop.trn_amount_12,
                                 0, 1,
                                 qtop.trn_amount_12),
                       2)
                +   DECODE (qiade.trans_type, 33, 1, 0)
                  * ROUND (
                         qiade.trans_amt
                       * qclm.trn_amount_2_11
                       / DECODE (qtop.trn_amount_2_11,
                                 0, 1,
                                 qtop.trn_amount_2_11),
                       2)
                +   DECODE (qiade.trans_type, 34, 1, 0)
                  * ROUND (
                         qiade.trans_amt
                       * qclm.trn_amount_2_12
                       / DECODE (qtop.trn_amount_2_12,
                                 0, 1,
                                 qtop.trn_amount_2_12),
                       2)
                   trans_amount,
                    DECODE (qiade.trans_type,  2, 1,  4, 1,  5, 1,  0)
                  * qiade.trans_amt
                  * qclm.trn_amount_11
                  / DECODE (qtop.trn_amount_11, 0, 1, qtop.trn_amount_11)
                +   DECODE (qiade.trans_type, 11, 1, 0)
                  * qiade.trans_amt
                  * qclm.trn_amount_12
                  / DECODE (qtop.trn_amount_12, 0, 1, qtop.trn_amount_12)
                +   DECODE (qiade.trans_type, 33, 1, 0)
                  * qiade.trans_amt
                  * qclm.trn_amount_2_11
                  / DECODE (qtop.trn_amount_2_11, 0, 1, qtop.trn_amount_2_11)
                +   DECODE (qiade.trans_type, 34, 1, 0)
                  * qiade.trans_amt
                  * qclm.trn_amount_2_12
                  / DECODE (qtop.trn_amount_2_12, 0, 1, qtop.trn_amount_2_12)
                   nr_trans_amount
           FROM (  SELECT /*+ index(a KOC_CLM_HLTH_INST_TRANS_PK, KOC_CLM_HLTH_INST_TRANS_IDX3)*/
                         a.trans_type,
                          a.institute_code,
                          SUM (b.SIGN * a.trans_amount) trans_amt,
                          a.payment_group_code
                     FROM koc_clm_hlth_inst_trans a, koc_cc_inst_trans_ref b
                    WHERE     a.trans_type =
                                 DECODE (p_trans_type,
                                         NULL, a.trans_type,
                                         p_trans_type)
                          AND a.trans_type IN (4, 5, 2, 11, 33, 34)
                          AND b.trans_group = p_trans_group
                          AND a.trans_type = b.trans_type
                          AND a.pay_year =
                                 DECODE (p_pay_year,
                                         NULL, a.pay_year,
                                         p_pay_year)
                          AND a.pay_month =
                                 DECODE (p_pay_month,
                                         NULL, a.pay_month,
                                         p_pay_month)
                          AND a.trans_date BETWEEN DECODE (p_trans_date,
                                                           NULL, a.trans_date,
                                                           p_trans_date)
                                               AND DECODE (p_trans_date2,
                                                           NULL, a.trans_date,
                                                           p_trans_date2)
                          AND a.institute_code =
                                 DECODE (p_institute_code,
                                         NULL, a.institute_code,
                                         p_institute_code)
                          AND a.payment_group_code =
                                 DECODE (p_payment_group_code,
                                         NULL, a.payment_group_code,
                                         p_payment_group_code)
                          AND a.claim_id IS NULL
                          AND a.batch_id IS NULL
                 GROUP BY a.institute_code,
                          a.payment_group_code,
                          a.trans_type
                   HAVING SUM (b.SIGN * a.trans_amount) != 0) qiade,
                (  SELECT /*+ ordered index (c koc_clm_suppliers_ext_pk) */
                         ABS (
                             SUM (
                                  DECODE (a.sf_total_type,  11, 1,  12, 0,  0)
                                * a.trans_amt
                                * NVL (b.currency_exchange_rate, 1)))
                             trn_amount_11,
                          ABS (
                             SUM (
                                  DECODE (d.specialty_subject, 1730, 1, 0)
                                * DECODE (a.sf_total_type,  11, 1,  12, 0,  0)
                                * a.trans_amt
                                * NVL (b.currency_exchange_rate, 1)))
                             trn_amount_2_11,
                          ABS (
                             SUM (
                                  DECODE (a.sf_total_type,  11, 0,  12, 1,  0)
                                * a.trans_amt
                                * NVL (b.currency_exchange_rate, 1)))
                             trn_amount_12,
                          ABS (
                             SUM (
                                  DECODE (d.specialty_subject, 1730, 1, 0)
                                * DECODE (a.sf_total_type,  11, 0,  12, 1,  0)
                                * a.trans_amt
                                * NVL (b.currency_exchange_rate, 1)))
                             trn_amount_2_12,
                          c.institute_code,
                          a.claim_id,
                          a.ext_reference,
                          a.ip_no,
                          a.oar_no partition_no,
                          a.sf_no,
                          a.supp_id,
                          d.invoice_date,
                          d.date_of_loss
                     /*cozbay task132695 09.02.2012 invoice_date ve date_of_loss eklendi*/
                     FROM koc_clm_trans_ext b,
                          clm_trans a,
                          koc_clm_suppliers_ext c,
                          koc_clm_hlth_detail d
                    WHERE     a.claim_id = b.claim_id
                          AND a.sf_no = b.sf_no
                          AND a.trans_no = b.trans_no
                          AND a.supp_id = c.supp_id
                          AND b.payment_type = '7'
                          AND c.payment_group_code = p_payment_group_code
                          AND c.institute_code =
                                 DECODE (p_institute_code,
                                         NULL, c.institute_code,
                                         p_institute_code)
                          AND b.ticket_date > p_start_date
                          AND b.ticket_date <= p_end_date
                          AND a.sf_total_type IN ('11', '12')
                          AND b.claim_id = d.claim_id
                          AND b.sf_no = d.sf_no
                          AND b.add_order_no = d.add_order_no
                 GROUP BY c.institute_code,
                          a.claim_id,
                          a.ext_reference,
                          a.ip_no,
                          a.oar_no,
                          a.sf_no,
                          a.supp_id,
                          d.invoice_date,
                          d.date_of_loss
                   HAVING SUM (
                               DECODE (a.sf_total_type,  11, 1,  12, 1,  0)
                             * a.trans_amt
                             * NVL (b.currency_exchange_rate, 1)) != 0) qclm,
                (  SELECT /*+ ordered index (c KOC_CLM_SUPPLIERS_EXT_PK) */
                         ABS (
                             SUM (
                                  DECODE (a.sf_total_type,  11, 1,  12, 0,  0)
                                * a.trans_amt
                                * NVL (b.currency_exchange_rate, 1)))
                             trn_amount_11,
                            ABS (
                               SUM (
                                    DECODE (d.specialty_subject, 1730, 1, 0)
                                  * DECODE (a.sf_total_type,
                                            11, 1,
                                            12, 0,
                                            0)
                                  * a.trans_amt
                                  * NVL (b.currency_exchange_rate, 1)))
                          + 0.000000001
                             trn_amount_2_11,
                          ABS (
                             SUM (
                                  DECODE (a.sf_total_type,  11, 0,  12, 1,  0)
                                * a.trans_amt
                                * NVL (b.currency_exchange_rate, 1)))
                             trn_amount_12,
                            ABS (
                               SUM (
                                    DECODE (d.specialty_subject, 1730, 1, 0)
                                  * DECODE (a.sf_total_type,
                                            11, 0,
                                            12, 1,
                                            0)
                                  * a.trans_amt
                                  * NVL (b.currency_exchange_rate, 1)))
                          + 0.000000001
                             trn_amount_2_12,
                          c.institute_code
                     FROM koc_clm_trans_ext b,
                          clm_trans a,
                          koc_clm_suppliers_ext c,
                          koc_clm_hlth_detail d
                    WHERE     a.claim_id = b.claim_id
                          AND a.sf_no = b.sf_no
                          AND a.trans_no = b.trans_no
                          AND a.supp_id = c.supp_id
                          AND b.payment_type = '7'
                          AND c.payment_group_code = p_payment_group_code
                          AND c.institute_code =
                                 DECODE (p_institute_code,
                                         NULL, c.institute_code,
                                         p_institute_code)
                          AND b.ticket_date > p_start_date
                          AND b.ticket_date <= p_end_date
                          AND a.sf_total_type IN ('11', '12')
                          AND b.claim_id = d.claim_id
                          AND b.sf_no = d.sf_no
                          AND b.add_order_no = d.add_order_no
                 GROUP BY c.institute_code
                   HAVING SUM (
                               DECODE (a.sf_total_type,  11, 1,  12, 1,  0)
                             * a.trans_amt
                             * NVL (b.currency_exchange_rate, 1)) != 0) qtop
          WHERE     qclm.institute_code = qiade.institute_code
                AND qclm.institute_code = qtop.institute_code
         UNION ALL
           SELECT /*+ index(a KOC_CLM_HLTH_INST_TRANS_PK, KOC_CLM_HLTH_INST_TRANS_IDX3)*/
                 a.trans_type,
                  a.institute_code,
                  a.claim_id,
                  d.ext_reference,
                  f.ip_no,
                  c.oar_no partition_no,
                  a.sf_no,
                  g.supp_id,
                  h.invoice_date,
                  h.date_of_loss,
                  SUM (b.SIGN * a.trans_amount) trans_amount,
                  SUM (b.SIGN * a.trans_amount) nr_trans_amount
             FROM koc_clm_hlth_inst_trans a,
                  koc_cc_inst_trans_ref b,
                  clm_pol_oar c,
                  clm_subfiles d,
                  clm_interested_parties f,
                  koc_clm_suppliers_ext g,
                  koc_clm_hlth_detail h
            /*cozbay task132695 09.02.2012 invoice_date ve date_of_loss icin koc_clm_hlth_detail */
            WHERE     a.trans_type =
                         DECODE (p_trans_type,
                                 NULL, a.trans_type,
                                 p_trans_type)
                  AND a.trans_type IN (4, 5, 2, 11, 33, 34)
                  AND b.trans_group = p_trans_group
                  AND a.trans_type = b.trans_type
                  AND a.pay_year =
                         DECODE (p_pay_year, NULL, a.pay_year, p_pay_year)
                  AND a.pay_month =
                         DECODE (p_pay_month, NULL, a.pay_month, p_pay_month)
                  AND a.trans_date BETWEEN DECODE (p_trans_date,
                                                   NULL, a.trans_date,
                                                   p_trans_date)
                                       AND DECODE (p_trans_date2,
                                                   NULL, a.trans_date,
                                                   p_trans_date2)
                  AND a.institute_code =
                         DECODE (p_institute_code,
                                 NULL, a.institute_code,
                                 p_institute_code)
                  AND a.payment_group_code =
                         DECODE (p_payment_group_code,
                                 NULL, a.payment_group_code,
                                 p_payment_group_code)
                  AND a.claim_id = c.claim_id
                  AND a.claim_id = d.claim_id
                  AND a.claim_id = f.claim_id
                  AND a.institute_code = g.institute_code
                  AND a.batch_id IS NULL
                  AND a.claim_id = h.claim_id
                  AND a.sf_no = h.sf_no
                  AND a.add_order_no = h.add_order_no
         GROUP BY a.trans_type,
                  a.institute_code,
                  a.claim_id,
                  d.ext_reference,
                  f.ip_no,
                  c.oar_no,
                  a.sf_no,
                  g.supp_id,
                  h.invoice_date,
                  h.date_of_loss
           HAVING SUM (b.SIGN * a.trans_amount) != 0
         ORDER BY 2;             -- kurum kodu s�ras� kesinlikle bozulmamamal�

      CURSOR currnd (
         p_date              DATE,
         p_amount            NUMBER,
         p_sf_total_type     VARCHAR2,
         p_institute_code    NUMBER)
      IS
           SELECT a.ROWID rw, a.trans_amt
             FROM koc_clm_trans_ext b, clm_trans a, koc_clm_suppliers_ext c
            WHERE     a.claim_id = b.claim_id
                  AND a.sf_no = b.sf_no
                  AND a.trans_no = b.trans_no
                  AND a.supp_id = c.supp_id
                  AND c.payment_group_code = p_payment_group_code
                  AND c.institute_code = p_institute_code
                  AND a.trans_date = p_date
                  AND a.sf_total_type = p_sf_total_type
         --AND a.trans_amt >= p_amount
         ORDER BY a.trans_amt DESC;

      --[ademo 19.09.2017
      CURSOR cur_agent (p_claim_id IN clm_pol_bases.CLAIM_ID%TYPE)
      IS
         SELECT agent_role
           FROM clm_pol_bases
          WHERE claim_id = p_claim_id;

      --ademo]

      trnrndrec                      currnd%ROWTYPE;
      trniaderec                     trnxiade%ROWTYPE;
      trnrec                         trnx%ROWTYPE;
      --recIsk curIsk%rowtype;
      v_postings                     koc_acc_utils.account_postingtyp;
      v_postings2                    koc_acc_utils.account_postingtyp;
      v_sayac                        NUMBER := 1;
      v_sub2                         VARCHAR2 (10);
      v_sub1                         VARCHAR2 (10);
      v_currency_exchange_rate       NUMBER := 1;
      v_exp                          VARCHAR2 (500);
      v_ext_reference                NUMBER;
      v_amount                       NUMBER;
      v_pay_year                     NUMBER;
      v_pay_month                    NUMBER;
      v_payment_date                 DATE;
      v_is_approved                  NUMBER;
      v_confirm_date                 DATE;
      v_err                          VARCHAR2 (2000);
      wdigit_prim                    NUMBER
         := NVL (find_round_digit (base_swift_code, 'P'), 2);
      v_account_category_code        VARCHAR2 (50) := 'YGENEL';
      v_prv_conf_date                DATE;
      v_trans_no                     NUMBER;
      v_int_ref                      NUMBER;
      v_sf_total_type                VARCHAR2 (4);
      v_f_cover_code                 VARCHAR2 (5);
      v_total_amount                 NUMBER;
      v_exit                         BOOLEAN := FALSE;
      xx_institute_code              NUMBER;
      v_cnt                          NUMBER;
      l_exp                          VARCHAR2 (255);
      v_RetSetInstEArchiveCommInfo   VARCHAR2 (1000);


      CURSOR curacc (
         pp_product_id        NUMBER,
         pp_partition_type    VARCHAR2,
         pp_cover_code        VARCHAR2,
         pp_date              DATE)
      IS
         SELECT x.acc_cover_code
           FROM koc_oc_prod_part_main_cov x
          WHERE     x.product_id = pp_product_id
                AND x.partition_type = pp_partition_type
                AND x.cover_code = pp_cover_code
                AND x.validity_start_date <= pp_date
                AND NVL (x.validity_end_date, pp_date) >= pp_date;

      v_acc_cover_code               koc_oc_prod_part_main_cov.acc_cover_code%TYPE;
      cur                            refcur;
      policyinfo                     koc_v_hlth_insured_info_indem%ROWTYPE;
      v_related_order                NUMBER;
      v_sub3                         VARCHAR2 (10);
      v_sub4                         VARCHAR2 (10);
      v_sap_lob                      VARCHAR2 (10);
      v_stoppage_amount              NUMBER;

      payid                          NUMBER := 0;
      v_pay_date                     datetbl;
      V_Institute_Code               Koc_Clm_Suppliers_Ext.Institute_Code%TYPE;
      V_Institutetype                NUMBER;
      V_Payment_Group_Code           Koc_V_Clm_Suppliers_M1.Payment_Group_Code%TYPE;
      V_Document_Type                VARCHAR2 (100);
      V_Document_Type_Exp            VARCHAR2 (100);
      v_inst_total                   NUMBER;
      v_is_e_inv_payer               BOOLEAN;
      V_Idx                          Alz_Invoice_Master.Idx%TYPE;
      V_Ret_Invoice_Id               Alz_Invoice_Master.Invoiceid%TYPE;

      V_Issue_Date                   DATE;

      v_Invoice_Info                 Alz_Inv_Process_Utils.Manuel_Invoice_Info_Type;
      v_claim_files                  Alz_Inv_Process_Utils.Inv_Claim_Files_Tbl;
      v_claim_files2                 Alz_Inv_Process_Utils.Inv_Claim_Files_Tbl;

      v_Inv_Lines                    Alz_Inv_Process_Utils.Inv_Lines_Tbl;
      v_Inv_Lines2                   Alz_Inv_Process_Utils.Inv_Lines_Tbl;
      l_part_id                      NUMBER;



      V_Invoice_Type_Code            Alz_Invoice_Master.Invoicetypecode%TYPE;
      --ademo TPA.start
      v_Tpa_Company_Code             Alz_Tpa_Companies.Company_Code%TYPE;
      v_Tpa_Rci_Company_Id           Koc_Rci_Companies_Ext.Rci_Company_Id%TYPE;
      v_Agent_Role                   Clm_Pol_Bases.Agent_Role%TYPE;

      --ademo TPA.end

      PROCEDURE set_Batch_Process (
         p_idx              alz_invoice_batch_process.idx%TYPE,
         P_Process_Type     alz_invoice_batch_process.Process_Type%TYPE,
         p_process_param    alz_invoice_batch_process.process_param%TYPE)
      IS
         v_batch   Alz_Inv_Forms_Utils.Alz_Inv_Batch_Process_Ty;
      BEGIN
         v_batch.Process_Type := P_Process_Type;
         v_batch.Idx := p_idx;
         v_batch.Process_Date := NULL;
         v_batch.Process_Count := 0;
         v_batch.Insert_User := USER;
         v_batch.Insert_Date := SYSDATE;
         v_batch.Process_Param := p_process_param;

         Alz_Inv_Forms_Utils.Set_Inv_Batch_Process (v_batch);
      END;
   BEGIN
      v_total_amount := 0;

      IF     p_acc_date >= TO_DATE ('01/01/2007', 'dd/mm/yyyy')
         AND (   p_trans_type IN (4, 5, 2, 11, 33, 34)
              OR p_trans_group IN ('IADEMAK', 'PROVISKON'))
      THEN
         IF p_payment_group_code != '99'
         THEN
            koc_clm_hlth_utils.getnextpaymentdate (p_acc_date,
                                                   p_payment_group_code,
                                                   v_confirm_date,
                                                   v_payment_date);
            koc_clm_hlth_utils.getprvconfirmdate (p_payment_group_code,
                                                  v_confirm_date,
                                                  v_prv_conf_date);
         ELSE
            v_prv_conf_date :=
               TO_DATE ('01/' || TO_CHAR (p_acc_date, 'mm/yyyy'),
                        'dd/mm/yyyy');
            v_confirm_date := LAST_DAY (v_prv_conf_date);
         END IF;

         OPEN trnxiade (v_prv_conf_date,
                        v_confirm_date,
                        p_institute_code,
                        p_payment_group_code,
                        p_pay_year,
                        p_pay_month,
                        p_trans_type,
                        p_trans_group,
                        p_trans_date,
                        p_trans_date2);

         xx_institute_code := NULL;

         LOOP
            FETCH trnxiade INTO trniaderec;

            v_exit := FALSE;

            IF trnxiade%NOTFOUND
            THEN
               v_exit := TRUE;
               trniaderec.institute_code := 0;
            END IF;

            IF NVL (xx_institute_code, trniaderec.institute_code) !=
                  trniaderec.institute_code
            THEN
               v_total_amount := ROUND (v_total_amount, 2);

               IF v_total_amount != 0
               THEN
                  IF p_trans_group = 'IADEMAK'
                  THEN
                     v_sf_total_type := '61';
                  END IF;

                  IF p_trans_group = 'PROVISKON'
                  THEN
                     v_sf_total_type := '63';
                  END IF;

                  OPEN currnd (p_acc_date,
                               ABS (v_total_amount),
                               v_sf_total_type,
                               xx_institute_code);

                  FETCH currnd INTO trnrndrec;

                  IF currnd%FOUND
                  THEN
                     UPDATE clm_trans
                        SET trans_amt = trans_amt - NVL (v_total_amount, 0)
                      WHERE ROWID = trnrndrec.rw;

                      begin
                      koc_clm_bordro.alz_hlth_bordro_trans_log(trniaderec.claim_id,null,null,'KOC_CLM_HLTH_TRNX2-3475',2);
                      exception when others then
                        begin
                            koc_clm_bordro.alz_hlth_bordro_trans_log(trniaderec.claim_id,null,null,'KOC_CLM_HLTH_TRNX2-3475',2,substr(sqlerrm,1,950));
                        exception when others then
                            null;
                        end;
                      end;

                     CLOSE currnd;
                  ELSE
                     CLOSE currnd;

                     IF p_trans_group = 'IADEMAK'
                     THEN
                        v_sf_total_type := '60';
                     END IF;

                     IF p_trans_group = 'PROVISKON'
                     THEN
                        v_sf_total_type := '62';
                     END IF;

                     OPEN currnd (p_acc_date,
                                  ABS (v_total_amount),
                                  v_sf_total_type,
                                  xx_institute_code);

                     FETCH currnd INTO trnrndrec;

                     IF currnd%FOUND
                     THEN
                        UPDATE clm_trans
                           SET trans_amt = trans_amt + NVL (v_total_amount, 0)
                         WHERE ROWID = trnrndrec.rw;

                         begin
                         koc_clm_bordro.alz_hlth_bordro_trans_log(trniaderec.claim_id,null,null,'KOC_CLM_HLTH_TRNX2-3504',2);
                         exception when others then
                            begin
                             koc_clm_bordro.alz_hlth_bordro_trans_log(trniaderec.claim_id,null,null,'KOC_CLM_HLTH_TRNX2-3504',2,substr(sqlerrm,1,950));
                            exception when others then
                             null;
                            end;
                         end;
                     END IF;

                     CLOSE currnd;
                  END IF;
               END IF;

               v_total_amount := 0;
            END IF;

            EXIT WHEN v_exit;
            xx_institute_code := trniaderec.institute_code;
            v_trans_no :=
                 NVL (getmaxtransno (trniaderec.claim_id, trniaderec.sf_no),
                      0)
               + 1;

            SELECT clm_int_ref_seq.NEXTVAL INTO v_int_ref FROM DUAL;

            v_amount := trniaderec.trans_amount;
            v_total_amount :=
                 v_total_amount
               +   SIGN (trniaderec.nr_trans_amount)
                 * (  ABS (trniaderec.nr_trans_amount)
                    - ABS (trniaderec.trans_amount));

            IF trniaderec.trans_type IN (4, 5)
            THEN
               IF v_amount > 0
               THEN
                  v_sf_total_type := '60';
               ELSE
                  v_sf_total_type := '61';
               END IF;
            END IF;

            IF trniaderec.trans_type IN (2, 11, 33, 34)
            THEN
               IF v_amount > 0
               THEN
                  v_sf_total_type := '62';
               ELSE
                  v_sf_total_type := '63';
               END IF;
            END IF;

            v_amount := ABS (v_amount);

            BEGIN
               SELECT cover_code
                 INTO v_f_cover_code
                 FROM (  SELECT cover_code
                           FROM koc_clm_hlth_provisions a
                          WHERE     a.claim_id = trniaderec.claim_id
                                AND sf_no = trniaderec.sf_no
                                AND add_order_no = 1
                                AND status_code IN ('TAH', 'ODE', 'P')
                       ORDER BY provision_total DESC)
                WHERE ROWNUM < 2;
            EXCEPTION
               WHEN OTHERS
               THEN
                  v_f_cover_code := 'S511';
            END;

            INSERT INTO clm_trans (claim_id,
                                   sf_no,
                                   trans_no,
                                   movement_id,
                                   assignee,
                                   sf_total_type,
                                   trans_type,
                                   trans_date,
                                   clm_status,
                                   trans_amt,
                                   trans_amt_swf,
                                   trans_base_amt,
                                   int_ref,
                                   supp_id,
                                   ip_no,
                                   oar_no,
                                   ext_reference)
                 VALUES (trniaderec.claim_id,
                         trniaderec.sf_no,
                         v_trans_no,
                         1,
                         USER,
                         v_sf_total_type,
                         20,
                         p_acc_date,
                         'TRANS',
                         v_amount,
                         v_base_swift_code,
                         v_amount,
                         v_int_ref,
                         trniaderec.supp_id,
                         trniaderec.ip_no,
                         trniaderec.partition_no,
                         trniaderec.ext_reference);

            begin
            koc_clm_bordro.alz_hlth_bordro_trans_log(trniaderec.claim_id,v_trans_no,'KOC_CLM_HLTH_TRNX2-3569',null,1);
            exception when others then
                begin
                 koc_clm_bordro.alz_hlth_bordro_trans_log(trniaderec.claim_id,v_trans_no,'KOC_CLM_HLTH_TRNX2-3569',null,1,substr(sqlerrm,1,950));
                exception when others then
                 null;
                end;
            end;

            IF p_trans_type = 1
            THEN ----cozbay task132695 08.02.2012 stopaj amount eklendi sadece tahakkuk i�in
               v_stoppage_amount :=
                  koc_clm_hlth_trnx2.getstoppageamount (
                     v_amount,
                     trniaderec.institute_code,
                     trniaderec.invoice_date,
                     trniaderec.date_of_loss);
            END IF;

            INSERT INTO koc_clm_trans_ext (claim_id,
                                           sf_no,
                                           add_order_no,
                                           trans_no,
                                           form_type,
                                           form_year,
                                           hlth_cover_code,
                                           currency_exchange_rate,
                                           institute_code,
                                           stoppage_amount)
                 VALUES (trniaderec.claim_id,
                         trniaderec.sf_no,
                         1,
                         v_trans_no,
                         'MKBZ',
                         TO_CHAR (p_acc_date, 'YYYY'),
                         v_f_cover_code,
                         1,
                         trniaderec.institute_code,
                         v_stoppage_amount);
         END LOOP;

         CLOSE trnxiade;
      END IF;

      ------ inst trans tablosuna ait cursor
      v_related_order := 1;
      v_sayac := 1;

      OPEN Trnx;

      FETCH Trnx INTO Trnrec;

      WHILE Trnx%FOUND
      LOOP
         V_Institute_Code := Trnrec.Institute_Code;
         V_Is_E_Inv_Payer :=
            Alz_Inv_Utils.Is_Einvoice_Payer (
               Get_Part_Id_By_Inst_No (Trnrec.Institute_Code));
         V_Institutetype :=
            Koc_Clm_Hlth_Utils.Getinstitutetype (Trnrec.Institute_Code);
         V_Payment_Group_Code :=
            Get_Payment_Group_By_Inst_Code (Trnrec.Institute_Code);
         V_Inst_Total := 0;

         V_Postings.Delete;
         V_Claim_Files.Delete;
         V_Claim_Files2.Delete;
         v_Inv_Lines2.Delete;
         v_postings2.Delete;

         v_Inv_Lines.Delete;


         WHILE Trnx%FOUND AND Trnrec.Institute_Code = V_Institute_Code
         LOOP
            Rec_Sap_Det.Cover_Code := NULL;
            Rec_Sap_Det.Sap_Dist_Channel := NULL;
            Rec_Sap_Det.Product_Id := NULL;
            Rec_Sap_Det.Partition_Type := NULL;
            Rec_Sap_Det.Is_Industrial := NULL;
            Rec_Sap_Det.Dyear := NULL;

            IF                                         --Trnrec.D_Type = 'sap'
              Trnrec.Claim_Id IS NOT NULL AND Trnrec.Sf_No IS NOT NULL
            THEN
               OPEN Cur_Sap_Det (Trnrec.Claim_Id, Trnrec.Sf_No);

               FETCH Cur_Sap_Det INTO Rec_Sap_Det;

               CLOSE Cur_Sap_Det;
            END IF;

            V_Amount := Trnrec.Trans_Amt;
            V_Sub1 := NULL;
            V_Sub2 := NULL;
            V_Sub3 := NULL;
            V_Sub4 := NULL;

            V_Cost_Center_Code := NULL;

            --[ademo
            IF Trnrec.Claim_Id IS NOT NULL
            THEN
               OPEN cur_agent (Trnrec.Claim_Id);

               FETCH cur_agent INTO v_Agent_Role;

               CLOSE cur_agent;
            END IF;

            --ademo]

            IF Trnrec.Trans_Type IN (4, 5)
            THEN                                                -- Iade Fatura
               IF P_Acc_Date >= TO_DATE ('01/01/2007', 'dd/mm/yyyy')
               THEN
                  IF P_Acc_Date < TO_DATE ('01.01.2008', 'dd.mm.yyyy')
                  THEN
                     V_Sub1 := '86';
                  ELSE
                     V_Sub1 := '85';
                  END IF;

                  -- ademo tpa.start
                  V_Sub2 := '01';

                  IF Trnrec.claim_id IS NOT NULL
                  THEN
                     v_Tpa_Company_Code :=
                        Alz_Tpa_Core_Utils.Get_Company_Code_By_Claim (
                           Trnrec.claim_id);

                     IF NVL (v_Tpa_Company_Code, '999') NOT IN ('045', '999')
                     THEN
                        v_Sub2 := '02';
                     END IF;
                  END IF;

                  -- adem tpa.end
                  V_Account_Category_Code := 'YTEK02111';       --'Ytek02110';
                  V_Sub3 := NVL (Rec_Sap_Det.Dyear, '01');
                  V_Sub4 := '01';
                  V_Sap_Lob := '785';

                  IF Rec_Sap_Det.Sap_Dist_Channel IS NULL
                  THEN
                     Rec_Sap_Det.Sap_Dist_Channel := '73';
                  END IF;

                  IF Rec_Sap_Det.Is_Industrial IS NULL
                  THEN
                     Rec_Sap_Det.Is_Industrial := 0;
                  END IF;
               ELSE
                  V_Sub1 := '4388';                               --6860210005
                  V_Account_Category_Code := 'YGENEL';
               END IF;

               V_Exp := 'KISM� FATURA �ADES�';

               IF Trnrec.D_Type = 'sap' AND Trnrec.Claim_Id IS NOT NULL
               THEN
                  V_Ext_Reference :=
                     Koc_Clm_Hlth_Utils.Getextrefbyclmid (Trnrec.Claim_Id);
                  V_Exp :=
                        V_Exp
                     || ' - HASAR DOSYA NO : '
                     || V_Ext_Reference
                     || '-'
                     || Trnrec.Add_Order_No;
               END IF;
            ELSIF Trnrec.Trans_Type IN (3, 10)
            THEN
               --Provizyon Giderleri
               V_Exp := Trnrec.Explanation;

               IF P_Acc_Date >= TO_DATE ('01/12/2009', 'dd/mm/yyyy')
               THEN
                  V_Sub1 := '85';
                  V_Sub2 := '03';
                  V_Account_Category_Code := 'YTEK01511';         --7850151103

                  IF Rec_Sap_Det.Sap_Dist_Channel IS NULL
                  THEN
                     Rec_Sap_Det.Sap_Dist_Channel := '73';
                  END IF;

                  IF Rec_Sap_Det.Is_Industrial IS NULL
                  THEN
                     Rec_Sap_Det.Is_Industrial := 0;
                  END IF;

                  --V_Cost_Center_Code := '9999929992'; Task 161285
                  V_Sap_Lob := '785';
               ELSE
                  V_Sub1 := '4439';                               --6860210003
                  V_Account_Category_Code := 'YGENEL';
               END IF;
            ELSIF Trnrec.Trans_Type IN (2, 11, 33, 34)
            THEN                                       --Provizyon �skontolar�
               IF P_Acc_Date >= TO_DATE ('01/01/2007', 'dd/mm/yyyy')
               THEN
                  IF P_Acc_Date < TO_DATE ('01.01.2008', 'dd.mm.yyyy')
                  THEN
                     V_Sub1 := '86';
                  ELSE
                     V_Sub1 := '85';
                  END IF;

                  --Task 176861 Eczane Provizyon Iskontolar�na Bsmv Vergisi P_Payment_Group_Code = 4 Eklendi
                  IF P_Payment_Group_Code IN ('2', '4')
                  THEN
                     V_Sub1 := '85';
                     V_Sub2 := '03';
                     V_Account_Category_Code := 'YTEK01511';      --7850151103
                  --V_Cost_Center_Code := '9999929992';  Task 161285
                  ELSE
                     V_Sub2 := '01';
                     V_Account_Category_Code := 'YTEK02111';    --'Ytek02110';
                     V_Sub3 := NVL (Rec_Sap_Det.Dyear, '01');
                     V_Sub4 := '01';
                  END IF;

                  V_Sap_Lob := '785';

                  IF Rec_Sap_Det.Sap_Dist_Channel IS NULL
                  THEN
                     Rec_Sap_Det.Sap_Dist_Channel := '73';
                  END IF;

                  IF Rec_Sap_Det.Is_Industrial IS NULL
                  THEN
                     Rec_Sap_Det.Is_Industrial := 0;
                  END IF;
               ELSE
                  V_Sub1 := '4440';
                  V_Account_Category_Code := 'YGENEL';
               END IF;

               V_Exp :=
                     '�SKONTO '
                  --- Provizyon:'|| Koc_Clm_Hlth_Utils.Getextrefbyclmid (Trnrec.Claim_Id)
                  --|| ' - '
                  || Koc_Clm_Hlth_Utils.Getinstitutnamebycode (
                        Trnrec.Institute_Code,
                        P_Acc_Date);
            ELSIF Trnrec.Trans_Type IN (8, 9)
            THEN                                           --Personel Maa�lar�
               V_Sub1 := '2397';
               V_Exp := Trnrec.Explanation;
               V_Account_Category_Code := 'YGENEL';
            ELSIF Trnrec.Trans_Type IN (14, 15)
            THEN                                         --Ssk ��veren Hissesi
               V_Sub1 := '2403';
               V_Exp := Trnrec.Explanation;
               V_Account_Category_Code := 'YGENEL';
            ELSIF Trnrec.Trans_Type IN (16, 17)
            THEN                                          --��sizlik Sigortas�
               V_Sub1 := '2404';
               V_Exp := Trnrec.Explanation;
               V_Account_Category_Code := 'YGENEL';
            ELSIF Trnrec.Trans_Type IN (6, 7)
            THEN                                           --Ko� Net Giderleri
               V_Sub1 := '5091';                           --Taskit No : 13973
               V_Exp := Trnrec.Explanation;
               V_Account_Category_Code := 'YGENEL';
            ELSIF Trnrec.Trans_Type IN (12, 13)
            THEN                                             --Di�er Giderleri
               V_Sub1 := '';
               V_Account_Category_Code := 'YGENEL';
            --          Elsif Trnrec.Trans_Type In (29, 30)
            ELSIF Trnrec.Trans_Type IN (29, 30, 35, 36) --onura 191344 hacizli kurum �demelerinin sisteme i�lenebilmesi
            THEN                                           --Di�er Bor� Alacak
               V_Exp := Trnrec.Explanation;

               SELECT A.Subfactor_1_Val,
                      A.Subfactor_2_Val,
                      A.Account_Category_Code
                 INTO V_Sub1, V_Sub2, V_Account_Category_Code
                 FROM Koc_Acc_V_Internal_Accounts A
                WHERE A.Gl_Acct_Ref_Code = Trnrec.Account_No;

               ----Bkundak Ekleme
               IF V_Account_Category_Code = 'YTEK02111'
               THEN                                      --T171054 ,Eozel@Kora
                  V_Sub3 := NVL (Rec_Sap_Det.Dyear, '01');
                  V_Sub4 := '01';

                  -- ademo tpa.start TPA_49_5_2
                  IF Trnrec.Trans_Type IN (29, 30)
                  THEN
                     v_Tpa_Company_Code := '045';

                     IF Trnrec.claim_id IS NOT NULL
                     THEN
                        v_Tpa_Company_Code :=
                           Alz_Tpa_Core_Utils.Get_Company_Code_By_Claim (
                              Trnrec.claim_id);
                     END IF;

                     IF     NVL (v_Tpa_Company_Code, '999') NOT IN
                               ('045', '999')
                        AND v_Sub2 <> '02'
                     THEN
                        V_Sub2 := '02';
                     END IF;
                  END IF;
               -- adem tpa.end
               END IF;

               --
               IF Rec_Sap_Det.Sap_Dist_Channel IS NULL
               THEN
                  Rec_Sap_Det.Sap_Dist_Channel := '73';
               END IF;


               IF Rec_Sap_Det.Is_Industrial IS NULL
               THEN
                  Rec_Sap_Det.Is_Industrial := 0;
               END IF;

               V_Sap_Lob := '785';
            --Bkundak Ekleme Sonu
            ELSIF Trnrec.Trans_Type IN (28)
            THEN                                           --Di�er Bor� Alacak
               V_Exp := 'HAVALE �PTAL�' || Trnrec.Institute_Code;
               V_Account_Category_Code := 'YBANKA';

               SELECT A.Subfactor_1_Val
                 INTO V_Sub1
                 FROM Koc_Acc_V_Internal_Accounts A
                WHERE A.Gl_Acct_Ref_Code = Trnrec.Account_No;
            END IF;

            -- E-Fatura
            -- Default De�erler
            V_Document_Type := 'DGR';
            V_Document_Type_Exp := 'DGR';

            --
            IF     V_Payment_Group_Code = '5'
               AND V_Account_Category_Code <> 'YBANKA'
            THEN
               V_Document_Type := 'SMM';
               V_Document_Type_Exp := 'SMM';
            END IF;

            IF Trnrec.Trans_Type IN (2, 3, 4)
            THEN
               IF    (V_Institutetype = '2' AND V_Payment_Group_Code = '4')
                  OR (    V_Institutetype <> '2'
                      AND V_Payment_Group_Code NOT IN ('4', '5'))
               THEN
                  V_Document_Type := 'FTR';
                  V_Document_Type_Exp := 'FTR';
               END IF;

               BEGIN                                                  --aykutt
                  SELECT DISTINCT a.part_id
                    INTO l_part_id
                    FROM koc_v_clm_suppliers_m1 a
                   WHERE a.institute_code = trnrec.institute_code;
               EXCEPTION
                  WHEN OTHERS
                  THEN
                     NULL;
               END;

               V_Inst_Total :=
                    NVL (V_Inst_Total, 0)
                  + ROUND (-1 * Trnrec.SIGN * P_Dc * V_Amount, Wdigit_Prim);


               IF     Trnrec.trans_type = 4
                  AND Trnrec.payment_group_code != '4'
                  AND Alz_Inv_Utils.Is_Einvoice_Payer (l_part_id, SYSDATE)
                  AND trnrec.claim_id IS NOT NULL                     --aykutt
               THEN
                  V_Claim_Files2 (V_Claim_Files2.COUNT + 1).Ext_Reference :=
                     Trnrec.Ext_Reference;
                  v_Inv_Lines2.Delete;

                  v_Inv_Lines2 (v_Inv_Lines2.COUNT + 1).Priceamount :=
                     ROUND (-1 * Trnrec.SIGN * P_Dc * V_Amount, Wdigit_Prim);
                  v_Inv_Lines2 (v_Inv_Lines2.COUNT).Taxamount := 0;
                  v_Inv_Lines2 (v_Inv_Lines2.COUNT).Pricingcurrencycode :=
                     'TRL';

                  BEGIN
                     l_exp := NULL;

                     SELECT SUBSTR (explanation, 1, 255)
                       INTO l_exp
                       FROM koc_clm_hlth_inst_trans
                      WHERE     batch_id = p_batch_id
                            AND explanation IS NOT NULL
                            AND trans_date = Trnrec.trans_date
                            AND institute_code = Trnrec.institute_code;
                  EXCEPTION
                     WHEN OTHERS
                     THEN
                        l_exp := NULL;
                  END;

                  IF NVL (l_exp, 'X') != 'X'
                  THEN
                     v_Inv_Lines2 (v_Inv_Lines2.COUNT).Name := l_exp;
                  ELSE
                     v_Inv_Lines2 (v_Inv_Lines2.COUNT).Name :=
                           '('
                        || Trnrec.Institute_Code
                        || ')'
                        || Trnrec.Invoice_Date
                        || ' Tarihli '
                        || Trnrec.Invoice_No
                        || ' nolu faturan�n k�smi iadesi';
                  END IF;

                  V_Invoice_Type_Code := 'IADE';

                  IF NVL (V_Inst_Total, 0) <> 0
                  THEN
                     V_Is_E_Inv_Payer :=
                        Alz_Inv_Utils.Is_Einvoice_Payer (
                           Get_Part_Id_By_Inst_No (Trnrec.Institute_Code));

                     IF V_Is_E_Inv_Payer
                     THEN
                        V_Invoice_Info.Inv_Master_Ext.Delivery_Type := 'E';
                     ELSE
                        V_Invoice_Info.Inv_Master_Ext.Delivery_Type := 'M';
                     END IF;

                     IF V_Invoice_Info.Inv_Master_Ext.Delivery_Type
                           IS NOT NULL
                     THEN
                        V_Invoice_Info.Documentcurrencycode := 'TRL';
                        V_Invoice_Info.Calculationrate := 1;
                        V_Invoice_Info.Approval_Hierarchy_Code :=
                           'GIDEN_SAGLIK_AZS';
                        V_Invoice_Info.issue_Date := TRUNC (P_Acc_Date);
                        V_Invoice_Info.Invoice_Type_Code :=
                           V_Invoice_Type_Code;
                        V_Invoice_Info.Institute_Code := V_Institute_Code;
                        V_Invoice_Info.Inv_Master_Ext.Source_Type := 'GIDEN';
                        V_Invoice_Info.Is_Create_Batch := 'FALSE';

                        V_Ret_Invoice_Id := NULL;
                        V_Issue_Date := NULL;
                        Alz_Inv_Process_Utils.Crt_Invoice_By_Identity_No (
                           Get_Identity_By_Part_Id (
                              Get_Part_Id_By_Inst_No (V_Institute_Code)),
                           V_Invoice_Info,
                           v_Inv_Lines2,
                           v_claim_files2,
                           0,
                           V_Ret_Invoice_Id);

                        IF V_Ret_Invoice_Id IS NULL
                        THEN
                           ROLLBACK;
                           Raise_Application_Error (
                              -20200,
                              '�skonto Faturas� Olu�turulamad�!');
                        END IF;

                        V_Issue_Date :=
                           Alz_Inv_Utils.Get_Issue_Date_By_Invoiceid (
                              V_Ret_Invoice_Id);

                        IF V_Issue_Date IS NULL
                        THEN
                           ROLLBACK;
                           Raise_Application_Error (
                              -20200,
                                 '�skonto Fatura ('
                              || V_Ret_Invoice_Id
                              || ') Tarihi Bulunamad�!');
                        END IF;

                        IF V_Invoice_Info.Inv_Master_Ext.Delivery_Type = 'E'
                        THEN
                           set_Batch_Process (
                              Alz_Inv_Process_Utils.Get_Idx_By_Invid_From_Invoice (
                                 V_Ret_Invoice_Id),
                              'INVOICE',
                              'ISTISNA');                          --'SATIS');
                        ELSIF V_Invoice_Info.Inv_Master_Ext.Delivery_Type =
                                 'M'
                        THEN
                           set_Batch_Process (
                              Alz_Inv_Process_Utils.Get_Idx_By_Invid_From_Invoice (
                                 V_Ret_Invoice_Id),
                              'EARCHIVE',
                              'ISTISNA');

                           v_RetSetInstEArchiveCommInfo :=
                              SetInstEArchiveCommInfo (
                                 V_Institute_Code,
                                 Trnrec.Payment_Group_Code,
                                 V_Ret_Invoice_Id);
                        END IF;
                     END IF;
                  END IF;

                  V_Postings2 (V_Sayac).Account_Category_Code :=
                     V_Account_Category_Code;
                  V_Postings2 (V_Sayac).Event_Type_Code := 'TAZMINAT';
                  V_Postings2 (V_Sayac).Event_Order_No := 1;
                  V_Postings2 (V_Sayac).Subfactor_1_Val := V_Sub1;
                  V_Postings2 (V_Sayac).Subfactor_2_Val := V_Sub2;
                  V_Postings2 (V_Sayac).Subfactor_3_Val := V_Sub3;
                  V_Postings2 (V_Sayac).Subfactor_4_Val := V_Sub4;
                  V_Postings2 (V_Sayac).Posting_Amount :=
                     ROUND (-1 * Trnrec.SIGN * P_Dc * V_Amount, Wdigit_Prim);
                  V_Postings2 (V_Sayac).Posting_Date := P_Acc_Date;
                  V_Postings2 (V_Sayac).Posting_Type := 'MAHSUP';
                  V_Postings2 (V_Sayac).Swift_Code := Trnrec.Swift_Code;
                  V_Postings2 (V_Sayac).Curr_Exchg_Rate :=
                     V_Currency_Exchange_Rate;
                  V_Postings2 (V_Sayac).Explanation := V_Exp;

                  V_Postings2 (V_Sayac).Invoice_No := Trnrec.Invoice_No;
                  V_Postings2 (V_Sayac).Invoice_Date := Trnrec.Invoice_Date;
                  V_Postings2 (V_Sayac).Document_Type := V_Document_Type;
                  V_Postings2 (V_Sayac).Document_Type_Exp :=
                     V_Document_Type_Exp;

                  OPEN Curacc (Rec_Sap_Det.Product_Id,
                               Rec_Sap_Det.Partition_Type,
                               Rec_Sap_Det.Cover_Code,
                               P_Acc_Date);

                  FETCH Curacc INTO V_Acc_Cover_Code;

                  CLOSE Curacc;

                  OPEN Cur_Branch (Rec_Sap_Det.Product_Id);

                  FETCH Cur_Branch INTO V_Branch;

                  CLOSE Cur_Branch;

                  V_Postings2 (V_Sayac).Sap_Dist_Channel :=
                     Rec_Sap_Det.Sap_Dist_Channel;
                  V_Postings2 (V_Sayac).Product_Id := Policyinfo.Product_Id;
                  V_Postings2 (V_Sayac).Partition_Type :=
                     Policyinfo.Partition_Type;
                  V_Postings2 (V_Sayac).Branch_Ext_Ref := V_Branch;
                  V_Postings2 (V_Sayac).Acc_Cover_Group := V_Acc_Cover_Code;
                  V_Postings2 (V_Sayac).Is_Industrial :=
                     Rec_Sap_Det.Is_Industrial;
                  V_Postings2 (V_Sayac).Sap_Lob := V_Sap_Lob;
                  V_Postings2 (V_Sayac).Cost_Center_Code := V_Cost_Center_Code;
                  V_Postings2 (V_Sayac).Related_Order := V_Related_Order;
                  ----------------------
                  --ademo TPA.start TPA_49_5_2
                  V_Postings2 (V_Sayac).Claim_Id := Trnrec.Claim_Id;
                  V_Postings2 (V_Sayac).Agent_Int_Id := v_Agent_Role;  --ademo

                  IF     Trnrec.Trans_Type IN (29, 30)
                     AND Trnrec.Claim_Id IS NOT NULL
                     AND NVL (v_Tpa_Company_Code, '999') NOT IN
                            ('045', '999')
                  THEN
                     V_Sayac := V_Sayac + 1;
                     v_Tpa_Rci_Company_Id :=
                        Alz_Tpa_Claim_Utils.Get_Tpa_Rci_Company_Id (
                           Trnrec.claim_id);
                     V_Postings2 (V_Sayac).Account_Category_Code :=
                        'YALINAN05';
                     V_Postings2 (V_Sayac).Event_Type_Code := 'TAZMINAT';
                     V_Postings2 (V_Sayac).Event_Order_No := 1;
                     V_Postings2 (V_Sayac).Subfactor_1_Val :=
                        TO_CHAR (v_Tpa_Rci_Company_id);
                     V_Postings2 (V_Sayac).Subfactor_2_Val := '1';
                     V_Postings2 (V_Sayac).Subfactor_3_Val := '4';
                     V_Postings2 (V_Sayac).Posting_Amount :=
                        ROUND (-1 * Trnrec.SIGN * P_Dc * V_Amount,
                               Wdigit_Prim);
                     V_Postings2 (V_Sayac).Posting_Date := P_Acc_Date;
                     V_Postings2 (V_Sayac).Posting_Type := 'MAHSUP';
                     V_Postings2 (V_Sayac).Swift_Code := Trnrec.Swift_Code;
                     V_Postings2 (V_Sayac).Curr_Exchg_Rate :=
                        V_Currency_Exchange_Rate;
                     V_Postings2 (V_Sayac).Explanation := V_Exp;
                     V_Postings2 (V_Sayac).Invoice_No := Trnrec.Invoice_No;
                     V_Postings2 (V_Sayac).Invoice_Date := Trnrec.Invoice_Date;
                     V_Postings2 (V_Sayac).Document_Type := V_Document_Type;
                     V_Postings2 (V_Sayac).Document_Type_Exp :=
                        V_Document_Type_Exp;
                     V_Postings2 (V_Sayac).Claim_Id := Trnrec.Claim_Id;
                     V_Postings2 (V_Sayac).Agent_Int_Id := v_Agent_Role; --ademo

                     V_Sayac := V_Sayac + 1;
                     V_Postings2 (V_Sayac).Account_Category_Code :=
                        'YALINAN05';
                     V_Postings2 (V_Sayac).Event_Type_Code := 'TAZMINAT';
                     V_Postings2 (V_Sayac).Event_Order_No := 1;
                     V_Postings2 (V_Sayac).Subfactor_1_Val :=
                        TO_CHAR (v_Tpa_Rci_Company_id);
                     V_Postings2 (V_Sayac).Subfactor_2_Val := '1';
                     V_Postings2 (V_Sayac).Subfactor_3_Val := '4';
                     V_Postings2 (V_Sayac).Posting_Amount :=
                        ROUND (Trnrec.SIGN * P_Dc * V_Amount, Wdigit_Prim);
                     V_Postings2 (V_Sayac).Posting_Date := P_Acc_Date;
                     V_Postings2 (V_Sayac).Posting_Type := 'MAHSUP';
                     V_Postings2 (V_Sayac).Swift_Code := Trnrec.Swift_Code;
                     V_Postings2 (V_Sayac).Curr_Exchg_Rate :=
                        V_Currency_Exchange_Rate;
                     V_Postings2 (V_Sayac).Explanation := V_Exp;
                     V_Postings2 (V_Sayac).Invoice_No := Trnrec.Invoice_No;
                     V_Postings2 (V_Sayac).Invoice_Date := Trnrec.Invoice_Date;
                     V_Postings2 (V_Sayac).Document_Type := V_Document_Type;
                     V_Postings2 (V_Sayac).Document_Type_Exp :=
                        V_Document_Type_Exp;
                     V_Postings2 (V_Sayac).Claim_Id := Trnrec.Claim_Id;
                     V_Postings2 (V_Sayac).Agent_Int_Id := v_Agent_Role; --ademo
                  ELSE
                     IF     NVL (v_Tpa_Company_Code, '999') NOT IN
                               ('045', '999')
                        AND Trnrec.claim_id IS NOT NULL
                     THEN
                        v_Tpa_Rci_Company_Id :=
                           Alz_Tpa_Claim_Utils.Get_Tpa_Rci_Company_Id (
                              Trnrec.claim_id);
                        V_Postings2 (v_sayac).Trading_Code :=
                           v_Tpa_Rci_Company_Id;
                     END IF;
                  END IF;

                  --ademo TPA.end
                  V_Sayac := V_Sayac + 1;
                  V_Postings2 (V_Sayac).Account_Category_Code := 'YKURUM';
                  V_Postings2 (V_Sayac).Event_Type_Code := 'TAZMINAT';
                  V_Postings2 (V_Sayac).Event_Order_No := 1;
                  V_Postings2 (V_Sayac).Subfactor_1_Val :=
                     Trnrec.Institute_Code;
                  V_Postings2 (V_Sayac).Posting_Amount :=
                     ROUND (Trnrec.SIGN * P_Dc * V_Amount, Wdigit_Prim);
                  V_Postings2 (V_Sayac).Posting_Date := P_Acc_Date;
                  V_Postings2 (V_Sayac).Posting_Type := 'MAHSUP';
                  V_Postings2 (V_Sayac).Swift_Code := Trnrec.Swift_Code;
                  V_Postings2 (V_Sayac).Curr_Exchg_Rate :=
                     V_Currency_Exchange_Rate;
                  V_Postings2 (V_Sayac).Explanation := V_Exp;

                  V_Postings2 (V_Sayac).Invoice_No := Trnrec.Invoice_No;
                  V_Postings2 (V_Sayac).Invoice_Date := Trnrec.Invoice_Date;
                  V_Postings2 (V_Sayac).Document_Type := V_Document_Type;
                  V_Postings2 (V_Sayac).Document_Type_Exp :=
                     V_Document_Type_Exp;

                  --Sap 29/11/2011 Yg --
                  V_Postings2 (V_Sayac).Related_Order := V_Related_Order;
                  --ademo TPA.start
                  V_Postings2 (V_Sayac).Claim_Id := Trnrec.Claim_Id;
                  V_Postings2 (V_Sayac).Agent_Int_Id := v_Agent_Role;  --ademo
                  --ademo TPA.end
                  ----------------------
                  V_Sayac := V_Sayac + 1;
                  V_Related_Order := V_Related_Order + 1;

                  IF V_Postings2.COUNT > 0
                  THEN
                     Koc_Acc_Utils.Posting_Accounts (V_Postings2,
                                                     'ACC',
                                                     '10',
                                                     NULL,
                                                     'Allianz Sigorta',
                                                     P_Batch_Id);


                     V_Pay_Year :=
                        TO_NUMBER (TO_CHAR (V_Payment_Date, 'YYYY'));
                     V_Pay_Month := TO_NUMBER (TO_CHAR (V_Payment_Date, 'MM'));

                     IF Trnrec.Payment_Group_Code != '99'
                     THEN
                        Koc_Clm_Hlth_Utils.Getnextpaymentdate (
                           P_Acc_Date,
                           Trnrec.Payment_Group_Code,
                           V_Confirm_Date,
                           V_Payment_Date);
                        V_Is_Approved := 0;

                        IF Trnrec.Trans_Type NOT IN (2, 3, 10, 11, 33, 34)
                        THEN
                           SELECT DECODE (COUNT (*), 0, 0, 1)
                             INTO V_Is_Approved
                             FROM Koc_Clm_Month_Confirm_Rem
                            WHERE     Year =
                                         TO_NUMBER (
                                            TO_CHAR (V_Payment_Date, 'YYYY'))
                                  AND Month =
                                         TO_NUMBER (
                                            TO_CHAR (V_Payment_Date, 'MM'))
                                  AND Payment_Group_Code =
                                         Trnrec.Payment_Group_Code
                                  AND Firm = '0'
                                  AND Institute_Code = Trnrec.Institute_Code;

                           IF V_Is_Approved > 0
                           THEN
                              SELECT DECODE (COUNT (*), 0, 0, 1)
                                INTO V_Cnt
                                FROM Koc_Clm_Hlth_Inst_Trans
                               WHERE     Pay_Year =
                                            TO_NUMBER (
                                               TO_CHAR (V_Payment_Date,
                                                        'YYYY'))
                                     AND Pay_Month =
                                            TO_NUMBER (
                                               TO_CHAR (V_Payment_Date, 'MM'))
                                     AND Payment_Group_Code =
                                            Trnrec.Payment_Group_Code
                                     AND Firm = '0'
                                     AND Institute_Code =
                                            Trnrec.Institute_Code
                                     AND Trans_Type IN (1, 21)
                                     AND Approve_Date IS NULL;

                              IF V_Cnt > 0
                              THEN
                                 V_Is_Approved := 0;
                              END IF;
                           END IF;
                        END IF;

                        IF V_Is_Approved > 0
                        THEN
                           SELECT MIN (Payment_Date)
                             INTO V_Payment_Date
                             FROM Koc_Cc_Month_Confirm_Dates A
                            WHERE     Payment_Group_Code =
                                         Trnrec.Payment_Group_Code
                                  AND Payment_Date > V_Payment_Date
                                  AND NOT EXISTS
                                             (SELECT 'X'
                                                FROM Koc_Clm_Month_Confirm_Rem
                                               WHERE     Year =
                                                            TO_NUMBER (
                                                               TO_CHAR (
                                                                  A.Payment_Date,
                                                                  'YYYY'))
                                                     AND Month =
                                                            TO_NUMBER (
                                                               TO_CHAR (
                                                                  A.Payment_Date,
                                                                  'MM'))
                                                     AND Institute_Code =
                                                            Trnrec.Institute_Code
                                                     AND Order_No = 1);
                        END IF;
                     ELSE
                        V_Payment_Date := P_Acc_Date;
                     END IF;

                     UPDATE Koc_Clm_Hlth_Inst_Trans A
                        SET Batch_Id = P_Batch_Id, Batch_Date = P_Acc_Date
                      WHERE     A.Institute_Code = Trnrec.Institute_Code
                            AND A.Trans_Date BETWEEN DECODE (
                                                        P_Trans_Date,
                                                        NULL, A.Trans_Date,
                                                        P_Trans_Date)
                                                 AND DECODE (
                                                        P_Trans_Date2,
                                                        NULL, A.Trans_Date,
                                                        P_Trans_Date2)
                            AND A.Trans_Type = Trnrec.Trans_Type
                            AND A.Pay_Year = V_Pay_Year
                            AND A.Pay_Month = V_Pay_Month
                            AND A.Payment_Group_Code =
                                   Trnrec.Payment_Group_Code
                            AND a.claim_id = Trnrec.claim_id
                            AND A.Batch_Id IS NULL;

                     IF V_Ret_Invoice_Id IS NOT NULL
                     THEN
                        UPDATE Alz_Invoice_Master_Ext A
                           SET A.Acc_Batch_Id = P_Batch_Id,
                               A.Accounting_Date = P_Acc_Date,
                               A.Accounting_User = USER
                         WHERE A.Idx =
                                  ALZ_INV_PROCESS_UTILS.GET_IDX_BY_INVID_FROM_INVOICE (
                                     V_Ret_Invoice_Id);
                     END IF;

                     BEGIN                                --aykutt iade fatura
                        l_exp := NULL;

                        SELECT explanation
                          INTO l_exp
                          FROM koc_clm_hlth_inst_trans
                         WHERE     batch_id = p_batch_id
                               AND EXPLANATION IS NOT NULL
                               AND trans_date = TRUNC (SYSDATE)
                               AND claim_id IS NULL;


                        UPDATE alz_invoice_lines
                           SET name = l_exp
                         WHERE idx =
                                  ALZ_INV_PROCESS_UTILS.GET_IDX_BY_INVID_FROM_INVOICE (
                                     V_Ret_Invoice_Id);
                     EXCEPTION
                        WHEN OTHERS
                        THEN
                           NULL;
                     END;

                     V_Postings2.Delete;
                     V_Sayac := 1;
                     V_Related_Order := 1;
                     DBMS_OUTPUT.put_line (V_Ret_Invoice_Id);
                     DBMS_OUTPUT.put_line (p_batch_id);
                  END IF;
               ELSE
                  V_Claim_Files (V_Claim_Files.COUNT + 1).Ext_Reference :=
                     Trnrec.Ext_Reference;

                  IF Trnrec.Trans_Type IN (2, 3)
                  THEN
                     V_Invoice_Type_Code := 'ISTISNA';              --'SATIS';

                     IF V_Inv_Lines.FIRST IS NOT NULL
                     THEN
                        V_Inv_Lines (1).Priceamount :=
                             NVL (V_Inv_Lines (1).Priceamount, 0)
                           + ROUND (-1 * Trnrec.SIGN * P_Dc * V_Amount,
                                    Wdigit_Prim);
                     ELSE
                        V_Inv_Lines (1).Priceamount :=
                           ROUND (-1 * Trnrec.SIGN * P_Dc * V_Amount,
                                  Wdigit_Prim);
                     END IF;

                     v_Inv_Lines (1).Taxamount := 0;
                     v_Inv_Lines (1).Pricingcurrencycode := 'TRL';
                     v_Inv_Lines (1).Name :=
                           '('
                        || V_Institute_Code
                        || ') Anla�mal� Kurum Teknoloji Destek Bedeli';
                  ELSIF Trnrec.Trans_Type IN (4)
                  THEN
                     V_Invoice_Type_Code := 'IADE';


                     v_Inv_Lines (v_Inv_Lines.COUNT + 1).Priceamount :=
                        ROUND (-1 * Trnrec.SIGN * P_Dc * V_Amount,
                               Wdigit_Prim);
                     v_Inv_Lines (v_Inv_Lines.COUNT).Taxamount := 0;
                     v_Inv_Lines (v_Inv_Lines.COUNT).Pricingcurrencycode :=
                        'TRL';



                     v_Inv_Lines (v_Inv_Lines.COUNT).Name :=
                           '('
                        || V_Institute_Code
                        || ')'
                        || Trnrec.Invoice_Date
                        || ' Tarihli '
                        || Trnrec.Invoice_No
                        || ' nolu faturan�n k�smi iadesi';
                  END IF;

                  IF Trnrec.claim_id IS NULL AND p_trans_group = 'IADEMAK' --MYALINKILIC: TYH61004 TASK I ICIN YAPILDI
                  THEN
                     FOR r1
                        IN (SELECT is_industrial,
                                   DECODE (
                                      ROWNUM,
                                      1,   dist_value
                                         + (  Trnrec.trans_amt
                                            - SUM (dist_value) OVER ()),
                                      dist_value)
                                      dist_value1,
                                   ROWNUM row_num,
                                   dist_value,
                                   (  Trnrec.trans_amt
                                    - SUM (dist_value) OVER ())
                                      diff_val,
                                   agent_role,
                                   sap_dist_channel                    --ademo
                              FROM (  SELECT a.*,
                                             ROUND (SUM (prov_total) OVER (),
                                                    2)
                                                total_cnt,
                                             ROUND (
                                                  100
                                                * (  prov_total
                                                   / SUM (prov_total) OVER ()),
                                                2)
                                                perc,
                                             ROUND (
                                                  (  prov_total
                                                   / SUM (prov_total) OVER ())
                                                * Trnrec.trans_amt,
                                                2)
                                                dist_value
                                        FROM (  SELECT agent_role,
                                                       is_industrial,
                                                       ROUND (SUM (prov_total),
                                                              2)
                                                          prov_total,
                                                       sap_dist_channel --,sum(prov_total) over() total_cnt,
                                                  FROM (  SELECT cpb.agent_role,
                                                                 NVL (
                                                                    kve.is_industrial,
                                                                    DECODE (
                                                                       opc.product_id,
                                                                       63, 0,
                                                                       64, 1,
                                                                       1))
                                                                    is_industrial,
                                                                 SUM (
                                                                    provision_total)
                                                                    prov_total,
                                                                    cpb.agent_role
                                                                 || '_'
                                                                 || is_industrial
                                                                    cont_uniq,
                                                                 e.sap_dist_channel
                                                            FROM koc_clm_hlth_detail dtl,
                                                                 clm_pol_bases cpb,
                                                                 ocp_policy_contracts opc,
                                                                 koc_ocp_pol_versions_ext kve,
                                                                 koc_clm_hlth_provisions khp,
                                                                 koc_dmt_agents_ext e
                                                           WHERE     institute_code =
                                                                        p_institute_code
                                                                 AND cpb.claim_id =
                                                                        dtl.claim_id
                                                                 AND dtl.claim_id =
                                                                        khp.claim_id
                                                                 AND dtl.sf_no =
                                                                        khp.sf_no
                                                                 AND dtl.add_order_no =
                                                                        khp.add_order_no
                                                                 AND cpb.contract_id =
                                                                        opc.contract_id
                                                                 AND cpb.contract_id =
                                                                        kve.contract_id
                                                                 AND kve.version_no =
                                                                        1
                                                                 AND provision_date BETWEEN ADD_MONTHS (
                                                                                               p_acc_date,
                                                                                               -12)
                                                                                        AND p_acc_date
                                                                 AND dtl.status_code =
                                                                        'ODE'
                                                                 AND khp.status_code =
                                                                        'ODE'
                                                                 AND NOT EXISTS
                                                                            (SELECT 1
                                                                               FROM Koc_Dmt_Agents_Ext
                                                                              WHERE     int_id =
                                                                                           cpb.agent_role
                                                                                    AND NVL (
                                                                                           company_code,
                                                                                           '045') !=
                                                                                           '045') --ademo.TPA 01.12.2017
                                                                 AND e.Int_Id =
                                                                        cpb.Agent_Role
                                                        GROUP BY cpb.agent_role,
                                                                 kve.is_industrial,
                                                                 opc.product_id,
                                                                 e.sap_dist_channel)
                                              GROUP BY agent_role,
                                                       is_industrial,
                                                       sap_dist_channel) a
                                    GROUP BY agent_role,
                                             is_industrial,
                                             a.prov_total,
                                             sap_dist_channel
                                    ORDER BY dist_value DESC)
                             WHERE dist_value > 0)
                     LOOP
                        v_Agent_Role := r1.agent_role;                 --ademo

                        V_Postings (V_Sayac).Account_Category_Code :=
                           V_Account_Category_Code;
                        V_Postings (V_Sayac).Event_Type_Code := 'TAZMINAT';
                        V_Postings (V_Sayac).Event_Order_No := 1;
                        V_Postings (V_Sayac).Subfactor_1_Val := V_Sub1;
                        V_Postings (V_Sayac).Subfactor_2_Val := V_Sub2;
                        V_Postings (V_Sayac).Subfactor_3_Val := V_Sub3;
                        V_Postings (V_Sayac).Subfactor_4_Val := V_Sub4;
                        V_Postings (V_Sayac).Posting_Amount :=
                           ROUND (-1 * Trnrec.SIGN * P_Dc * r1.dist_value1,
                                  Wdigit_Prim);
                        V_Postings (V_Sayac).Posting_Date := P_Acc_Date;
                        V_Postings (V_Sayac).Posting_Type := 'MAHSUP';
                        V_Postings (V_Sayac).Swift_Code := Trnrec.Swift_Code;
                        V_Postings (V_Sayac).Curr_Exchg_Rate :=
                           V_Currency_Exchange_Rate;
                        V_Postings (V_Sayac).Explanation := V_Exp;
                        V_Postings (V_Sayac).Invoice_No := Trnrec.Invoice_No;
                        V_Postings (V_Sayac).Invoice_Date :=
                           Trnrec.Invoice_Date;
                        V_Postings (V_Sayac).Document_Type := V_Document_Type;
                        V_Postings (V_Sayac).Document_Type_Exp :=
                           V_Document_Type_Exp;

                        --Sap 29/11/2011 Yg --

                        OPEN Curacc (Rec_Sap_Det.Product_Id,
                                     Rec_Sap_Det.Partition_Type,
                                     Rec_Sap_Det.Cover_Code,
                                     P_Acc_Date);

                        FETCH Curacc INTO V_Acc_Cover_Code;

                        CLOSE Curacc;

                        OPEN Cur_Branch (Rec_Sap_Det.Product_Id);

                        FETCH Cur_Branch INTO V_Branch;

                        CLOSE Cur_Branch;

                        V_Postings (V_Sayac).Sap_Dist_Channel :=
                           --Rec_Sap_Det.Sap_Dist_Channel;
                           r1.sap_dist_channel;
                        V_Postings (V_Sayac).Product_Id :=
                           Policyinfo.Product_Id;
                        V_Postings (V_Sayac).Partition_Type :=
                           Policyinfo.Partition_Type;
                        V_Postings (V_Sayac).Branch_Ext_Ref := V_Branch;
                        V_Postings (V_Sayac).Acc_Cover_Group :=
                           V_Acc_Cover_Code;
                        V_Postings (V_Sayac).Is_Industrial := r1.Is_Industrial;
                        V_Postings (V_Sayac).Sap_Lob := V_Sap_Lob;
                        V_Postings (V_Sayac).Cost_Center_Code :=
                           V_Cost_Center_Code;
                        V_Postings (V_Sayac).Related_Order := V_Related_Order;
                        V_Postings (V_Sayac).Agent_Int_Id := v_Agent_Role; -- ademo
                        ----------------------
                        V_Sayac := V_Sayac + 1;
                        V_Postings (V_Sayac).Account_Category_Code := 'YKURUM';
                        V_Postings (V_Sayac).Event_Type_Code := 'TAZMINAT';
                        V_Postings (V_Sayac).Event_Order_No := 1;
                        V_Postings (V_Sayac).Subfactor_1_Val :=
                           Trnrec.Institute_Code;
                        V_Postings (V_Sayac).Posting_Amount :=
                           ROUND (Trnrec.SIGN * P_Dc * r1.dist_value1,
                                  Wdigit_Prim);
                        V_Postings (V_Sayac).Posting_Date := P_Acc_Date;
                        V_Postings (V_Sayac).Posting_Type := 'MAHSUP';
                        V_Postings (V_Sayac).Swift_Code := Trnrec.Swift_Code;
                        V_Postings (V_Sayac).Curr_Exchg_Rate :=
                           V_Currency_Exchange_Rate;
                        V_Postings (V_Sayac).Explanation := V_Exp;
                        V_Postings (V_Sayac).Invoice_No := Trnrec.Invoice_No;
                        V_Postings (V_Sayac).Invoice_Date :=
                           Trnrec.Invoice_Date;
                        V_Postings (V_Sayac).Document_Type := V_Document_Type;
                        V_Postings (V_Sayac).Document_Type_Exp :=
                           V_Document_Type_Exp;

                        --Sap 29/11/2011 Yg --
                        V_Postings (V_Sayac).Related_Order := V_Related_Order;
                        V_Postings (V_Sayac).Agent_Int_Id := v_Agent_Role; -- ademo
                        ----------------------
                        V_Sayac := V_Sayac + 1;
                        V_Related_Order := V_Related_Order + 1;
                     END LOOP;
                  ELSE
                     V_Postings (V_Sayac).Account_Category_Code :=
                        V_Account_Category_Code;
                     V_Postings (V_Sayac).Event_Type_Code := 'TAZMINAT';
                     V_Postings (V_Sayac).Event_Order_No := 1;
                     V_Postings (V_Sayac).Subfactor_1_Val := V_Sub1;
                     V_Postings (V_Sayac).Subfactor_2_Val := V_Sub2;
                     V_Postings (V_Sayac).Subfactor_3_Val := V_Sub3;
                     V_Postings (V_Sayac).Subfactor_4_Val := V_Sub4;
                     V_Postings (V_Sayac).Posting_Amount :=
                        ROUND (-1 * Trnrec.SIGN * P_Dc * V_Amount,
                               Wdigit_Prim);
                     V_Postings (V_Sayac).Posting_Date := P_Acc_Date;
                     V_Postings (V_Sayac).Posting_Type := 'MAHSUP';
                     V_Postings (V_Sayac).Swift_Code := Trnrec.Swift_Code;
                     V_Postings (V_Sayac).Curr_Exchg_Rate :=
                        V_Currency_Exchange_Rate;
                     V_Postings (V_Sayac).Explanation := V_Exp;
                     V_Postings (V_Sayac).Invoice_No := Trnrec.Invoice_No;
                     V_Postings (V_Sayac).Invoice_Date := Trnrec.Invoice_Date;
                     V_Postings (V_Sayac).Document_Type := V_Document_Type;
                     V_Postings (V_Sayac).Document_Type_Exp :=
                        V_Document_Type_Exp;

                     --Sap 29/11/2011 Yg --

                     OPEN Curacc (Rec_Sap_Det.Product_Id,
                                  Rec_Sap_Det.Partition_Type,
                                  Rec_Sap_Det.Cover_Code,
                                  P_Acc_Date);

                     FETCH Curacc INTO V_Acc_Cover_Code;

                     CLOSE Curacc;

                     OPEN Cur_Branch (Rec_Sap_Det.Product_Id);

                     FETCH Cur_Branch INTO V_Branch;

                     CLOSE Cur_Branch;

                     V_Postings (V_Sayac).Sap_Dist_Channel :=
                        Rec_Sap_Det.Sap_Dist_Channel;
                     V_Postings (V_Sayac).Product_Id := Policyinfo.Product_Id;
                     V_Postings (V_Sayac).Partition_Type :=
                        Policyinfo.Partition_Type;
                     V_Postings (V_Sayac).Branch_Ext_Ref := V_Branch;
                     V_Postings (V_Sayac).Acc_Cover_Group := V_Acc_Cover_Code;
                     V_Postings (V_Sayac).Is_Industrial :=
                        Rec_Sap_Det.Is_Industrial;
                     V_Postings (V_Sayac).Sap_Lob := V_Sap_Lob;
                     V_Postings (V_Sayac).Cost_Center_Code :=
                        V_Cost_Center_Code;
                     V_Postings (V_Sayac).Related_Order := V_Related_Order;
                     V_Postings (V_Sayac).Agent_Int_Id := v_Agent_Role; -- ademo
                     ----------------------
                     V_Sayac := V_Sayac + 1;
                     V_Postings (V_Sayac).Account_Category_Code := 'YKURUM';
                     V_Postings (V_Sayac).Event_Type_Code := 'TAZMINAT';
                     V_Postings (V_Sayac).Event_Order_No := 1;
                     V_Postings (V_Sayac).Subfactor_1_Val :=
                        Trnrec.Institute_Code;
                     V_Postings (V_Sayac).Posting_Amount :=
                        ROUND (Trnrec.SIGN * P_Dc * V_Amount, Wdigit_Prim);
                     V_Postings (V_Sayac).Posting_Date := P_Acc_Date;
                     V_Postings (V_Sayac).Posting_Type := 'MAHSUP';
                     V_Postings (V_Sayac).Swift_Code := Trnrec.Swift_Code;
                     V_Postings (V_Sayac).Curr_Exchg_Rate :=
                        V_Currency_Exchange_Rate;
                     V_Postings (V_Sayac).Explanation := V_Exp;
                     V_Postings (V_Sayac).Invoice_No := Trnrec.Invoice_No;
                     V_Postings (V_Sayac).Invoice_Date := Trnrec.Invoice_Date;
                     V_Postings (V_Sayac).Document_Type := V_Document_Type;
                     V_Postings (V_Sayac).Document_Type_Exp :=
                        V_Document_Type_Exp;

                     --Sap 29/11/2011 Yg --
                     V_Postings (V_Sayac).Related_Order := V_Related_Order;
                     V_Postings (V_Sayac).Agent_Int_Id := v_Agent_Role;
                     ----------------------
                     V_Sayac := V_Sayac + 1;
                     V_Related_Order := V_Related_Order + 1;
                  END IF;          --MYALINKILIC: TYH61004 TASK I ICIN YAPILDI
               END IF;                                         --aykutt ana if
            ELSE
               V_Postings (V_Sayac).Account_Category_Code :=
                  V_Account_Category_Code;
               V_Postings (V_Sayac).Event_Type_Code := 'TAZMINAT';
               V_Postings (V_Sayac).Event_Order_No := 1;
               V_Postings (V_Sayac).Subfactor_1_Val := V_Sub1;
               V_Postings (V_Sayac).Subfactor_2_Val := V_Sub2;
               V_Postings (V_Sayac).Subfactor_3_Val := V_Sub3;
               V_Postings (V_Sayac).Subfactor_4_Val := V_Sub4;
               V_Postings (V_Sayac).Posting_Amount :=
                  ROUND (-1 * Trnrec.SIGN * P_Dc * V_Amount, Wdigit_Prim);
               V_Postings (V_Sayac).Posting_Date := P_Acc_Date;
               V_Postings (V_Sayac).Posting_Type := 'MAHSUP';
               V_Postings (V_Sayac).Swift_Code := Trnrec.Swift_Code;
               V_Postings (V_Sayac).Curr_Exchg_Rate :=
                  V_Currency_Exchange_Rate;
               V_Postings (V_Sayac).Explanation := V_Exp;
               V_Postings (V_Sayac).Invoice_No := Trnrec.Invoice_No;
               V_Postings (V_Sayac).Invoice_Date := Trnrec.Invoice_Date;
               V_Postings (V_Sayac).Document_Type := V_Document_Type;
               V_Postings (V_Sayac).Document_Type_Exp := V_Document_Type_Exp;

               --Sap 29/11/2011 Yg --

               OPEN Curacc (Rec_Sap_Det.Product_Id,
                            Rec_Sap_Det.Partition_Type,
                            Rec_Sap_Det.Cover_Code,
                            P_Acc_Date);

               FETCH Curacc INTO V_Acc_Cover_Code;

               CLOSE Curacc;

               OPEN Cur_Branch (Rec_Sap_Det.Product_Id);

               FETCH Cur_Branch INTO V_Branch;

               CLOSE Cur_Branch;

               V_Postings (V_Sayac).Sap_Dist_Channel :=
                  Rec_Sap_Det.Sap_Dist_Channel;
               V_Postings (V_Sayac).Product_Id := Policyinfo.Product_Id;
               V_Postings (V_Sayac).Partition_Type :=
                  Policyinfo.Partition_Type;
               V_Postings (V_Sayac).Branch_Ext_Ref := V_Branch;
               V_Postings (V_Sayac).Acc_Cover_Group := V_Acc_Cover_Code;
               V_Postings (V_Sayac).Is_Industrial := Rec_Sap_Det.Is_Industrial;
               V_Postings (V_Sayac).Sap_Lob := V_Sap_Lob;
               V_Postings (V_Sayac).Cost_Center_Code := V_Cost_Center_Code;
               V_Postings (V_Sayac).Related_Order := V_Related_Order;
               V_Postings (V_Sayac).Agent_Int_Id := v_Agent_Role;     -- ademo
               ----------------------
               V_Sayac := V_Sayac + 1;
               V_Postings (V_Sayac).Account_Category_Code := 'YKURUM';
               V_Postings (V_Sayac).Event_Type_Code := 'TAZMINAT';
               V_Postings (V_Sayac).Event_Order_No := 1;
               V_Postings (V_Sayac).Subfactor_1_Val := Trnrec.Institute_Code;
               V_Postings (V_Sayac).Posting_Amount :=
                  ROUND (Trnrec.SIGN * P_Dc * V_Amount, Wdigit_Prim);
               V_Postings (V_Sayac).Posting_Date := P_Acc_Date;
               V_Postings (V_Sayac).Posting_Type := 'MAHSUP';
               V_Postings (V_Sayac).Swift_Code := Trnrec.Swift_Code;
               V_Postings (V_Sayac).Curr_Exchg_Rate :=
                  V_Currency_Exchange_Rate;
               V_Postings (V_Sayac).Explanation := V_Exp;
               V_Postings (V_Sayac).Invoice_No := Trnrec.Invoice_No;
               V_Postings (V_Sayac).Invoice_Date := Trnrec.Invoice_Date;
               V_Postings (V_Sayac).Document_Type := V_Document_Type;
               V_Postings (V_Sayac).Document_Type_Exp := V_Document_Type_Exp;

               --Sap 29/11/2011 Yg --
               V_Postings (V_Sayac).Related_Order := V_Related_Order;
               V_Postings (V_Sayac).Agent_Int_Id := v_Agent_Role;     -- ademo
               ----------------------
               V_Sayac := V_Sayac + 1;
               V_Related_Order := V_Related_Order + 1;
            END IF;

            -- E-Fatura

            IF Trnrec.Payment_Group_Code != '99'
            THEN
               Koc_Clm_Hlth_Utils.Getnextpaymentdate (
                  P_Acc_Date,
                  Trnrec.Payment_Group_Code,
                  V_Confirm_Date,
                  V_Payment_Date);
               V_Is_Approved := 0;

               IF Trnrec.Trans_Type NOT IN (2, 3, 10, 11, 33, 34)
               THEN
                  SELECT DECODE (COUNT (*), 0, 0, 1)
                    INTO V_Is_Approved
                    FROM Koc_Clm_Month_Confirm_Rem
                   WHERE     Year =
                                TO_NUMBER (TO_CHAR (V_Payment_Date, 'YYYY'))
                         AND Month =
                                TO_NUMBER (TO_CHAR (V_Payment_Date, 'MM'))
                         AND Payment_Group_Code = Trnrec.Payment_Group_Code
                         --And Order_No = 1
                         AND Firm = '0'
                         AND Institute_Code = Trnrec.Institute_Code;

                  IF V_Is_Approved > 0
                  THEN
                     SELECT DECODE (COUNT (*), 0, 0, 1)
                       INTO V_Cnt
                       FROM Koc_Clm_Hlth_Inst_Trans
                      WHERE     Pay_Year =
                                   TO_NUMBER (
                                      TO_CHAR (V_Payment_Date, 'YYYY'))
                            AND Pay_Month =
                                   TO_NUMBER (TO_CHAR (V_Payment_Date, 'MM'))
                            AND Payment_Group_Code =
                                   Trnrec.Payment_Group_Code
                            AND Firm = '0'
                            AND Institute_Code = Trnrec.Institute_Code
                            AND Trans_Type IN (1, 21)
                            AND Approve_Date IS NULL;

                     IF V_Cnt > 0
                     THEN
                        V_Is_Approved := 0;
                     END IF;
                  END IF;
               END IF;

               IF V_Is_Approved > 0
               THEN
                  SELECT MIN (Payment_Date)
                    INTO V_Payment_Date
                    FROM Koc_Cc_Month_Confirm_Dates A
                   WHERE     Payment_Group_Code = Trnrec.Payment_Group_Code
                         AND Payment_Date > V_Payment_Date
                         AND NOT EXISTS
                                    (SELECT 'X'
                                       FROM Koc_Clm_Month_Confirm_Rem
                                      WHERE     Year =
                                                   TO_NUMBER (
                                                      TO_CHAR (
                                                         A.Payment_Date,
                                                         'YYYY'))
                                            AND Month =
                                                   TO_NUMBER (
                                                      TO_CHAR (
                                                         A.Payment_Date,
                                                         'MM'))
                                            AND Institute_Code =
                                                   Trnrec.Institute_Code
                                            AND Order_No = 1);
               END IF;
            ELSE
               V_Payment_Date := P_Acc_Date;
            END IF;

            V_Pay_Year := TO_NUMBER (TO_CHAR (V_Payment_Date, 'YYYY'));
            V_Pay_Month := TO_NUMBER (TO_CHAR (V_Payment_Date, 'MM'));
            --
            Payid := V_Pay_Date.COUNT + 1;
            V_Pay_Date (Payid).Pay_Year := V_Pay_Year;
            V_Pay_Date (Payid).Pay_Month := V_Pay_Month;
            V_Pay_Date (Payid).Institute_Code := Trnrec.Institute_Code;
            V_Pay_Date (Payid).Payment_Group_Code := Trnrec.Payment_Group_Code;

            --
            IF Trnrec.Trans_Type IN (35, 36)
            THEN --onura 191344 hacizli kurum �demelerinin sisteme i�lenebilmesi
               UPDATE Koc_Clm_Month_Confirm_Rem s
                  SET payment_date = V_Payment_Date
                WHERE     s.institute_code = Trnrec.Institute_Code
                      AND s.payment_group_code = Trnrec.Payment_Group_Code
                      AND s.firm = '0'
                      AND s.year = V_Pay_Year
                      AND s.month = V_Pay_Month;
            END IF;

            UPDATE Koc_Clm_Hlth_Inst_Trans A
               SET Pay_Year = V_Pay_Year, Pay_Month = V_Pay_Month
             WHERE     A.Institute_Code = Trnrec.Institute_Code
                   AND A.Trans_Date = Trnrec.Trans_Date
                   AND A.Trans_Type = Trnrec.Trans_Type
                   AND Firm = '0'
                   AND A.Payment_Group_Code = Trnrec.Payment_Group_Code
                   AND A.Batch_Id IS NULL;

            FETCH Trnx INTO Trnrec;
         END LOOP;

         IF V_Postings.COUNT > 0
         THEN
            -- E�er fatura kesilmesi gerekiyorsa �nce bu fatura kesilecek, daha sonra bu kesilen fatura bilgisi ilgili fi�in �zerine yaz�lacak
            --- E-Fatura
            IF NVL (V_Inst_Total, 0) <> 0
            THEN
               V_Invoice_Info := NULL;

               IF V_Is_E_Inv_Payer
               THEN
                  V_Invoice_Info.Inv_Master_Ext.Delivery_Type := 'E';
               ELSE
                  V_Invoice_Info.Inv_Master_Ext.Delivery_Type := 'M';
               END IF;

               IF V_Invoice_Info.Inv_Master_Ext.Delivery_Type IS NOT NULL
               THEN
                  V_Invoice_Info.Documentcurrencycode := 'TRL';
                  V_Invoice_Info.Calculationrate := 1;
                  V_Invoice_Info.Approval_Hierarchy_Code := 'GIDEN_SAGLIK_AZS';
                  V_Invoice_Info.issue_Date := TRUNC (P_Acc_Date);
                  V_Invoice_Info.Invoice_Type_Code := V_Invoice_Type_Code;
                  V_Invoice_Info.Institute_Code := V_Institute_Code;
                  V_Invoice_Info.Inv_Master_Ext.Source_Type := 'GIDEN';
                  V_Invoice_Info.Is_Create_Batch := 'FALSE'; -- �skonto faturas� i�in tahakkuk fi�i kesme(zaten kesilen fatura i�in gerekli fi� a�a��da olu�turuluyor


                  IF NVL (v_Inv_Lines.COUNT, 0) > 0
                  THEN
                     V_Ret_Invoice_Id := NULL;
                     V_Issue_Date := NULL;
                     Alz_Inv_Process_Utils.Crt_Invoice_By_Identity_No (
                        Get_Identity_By_Part_Id (
                           Get_Part_Id_By_Inst_No (V_Institute_Code)),
                        V_Invoice_Info,
                        v_Inv_Lines,
                        v_claim_files,
                        0,
                        V_Ret_Invoice_Id);
                  END IF;

                  V_Invoice_Type_Code := NULL;

                  IF V_Ret_Invoice_Id IS NULL
                  THEN
                     ROLLBACK;
                     Raise_Application_Error (
                        -20200,
                        '�skonto Faturas� Olu�turulamad�!');
                  END IF;

                  V_Issue_Date :=
                     Alz_Inv_Utils.Get_Issue_Date_By_Invoiceid (
                        V_Ret_Invoice_Id);

                  IF V_Issue_Date IS NULL
                  THEN
                     ROLLBACK;
                     Raise_Application_Error (
                        -20200,
                           '�skonto Fatura ('
                        || V_Ret_Invoice_Id
                        || ') Tarihi Bulunamad�!');
                  END IF;

                  IF V_Invoice_Info.Inv_Master_Ext.Delivery_Type = 'E'
                  THEN
                     set_Batch_Process (
                        Alz_Inv_Process_Utils.Get_Idx_By_Invid_From_Invoice (
                           V_Ret_Invoice_Id),
                        'INVOICE',
                        'ISTISNA');
                  --'SATIS');
                  ELSIF V_Invoice_Info.Inv_Master_Ext.Delivery_Type = 'M'
                  THEN
                     set_Batch_Process (
                        Alz_Inv_Process_Utils.Get_Idx_By_Invid_From_Invoice (
                           V_Ret_Invoice_Id),
                        'EARCHIVE',
                        'ISTISNA');
                     v_RetSetInstEArchiveCommInfo :=
                        SetInstEArchiveCommInfo (V_Institute_Code,
                                                 Trnrec.Payment_Group_Code,
                                                 V_Ret_Invoice_Id);
                  END IF;

                  --   Olu�an Fi� �zerine, Bu Fi� I�in Kesilen Fatura No / Fatura Tarihi Bilgileri Yaz�lacak
                  FOR I IN 1 .. V_Postings.COUNT          ---aykutt kontrol et
                  LOOP
                     V_Postings (I).Invoice_No := V_Ret_Invoice_Id;
                     V_Postings (I).Invoice_Date := V_Issue_Date;
                  END LOOP;
               END IF;
            END IF;

            --/ E-Fatura

            Koc_Acc_Utils.Posting_Accounts (V_Postings,
                                            'ACC',
                                            '10',
                                            NULL,
                                            'Allianz Sigorta',
                                            P_Batch_Id);

            Payid := V_Pay_Date.FIRST;

            WHILE (Payid IS NOT NULL)
            LOOP
               UPDATE Koc_Clm_Hlth_Inst_Trans A
                  SET Batch_Id = P_Batch_Id, Batch_Date = P_Acc_Date
                WHERE     A.Institute_Code = V_Institute_Code
                      AND A.Trans_Date BETWEEN DECODE (P_Trans_Date,
                                                       NULL, A.Trans_Date,
                                                       P_Trans_Date)
                                           AND DECODE (P_Trans_Date2,
                                                       NULL, A.Trans_Date,
                                                       P_Trans_Date2)
                      AND A.Trans_Type =
                             DECODE (P_Trans_Type,
                                     NULL, A.Trans_Type,
                                     P_Trans_Type)
                      AND A.Trans_Type IN
                             (SELECT Trans_Type
                                FROM Koc_Cc_Inst_Trans_Ref
                               WHERE Trans_Group = P_Trans_Group)
                      AND A.Pay_Year =
                             DECODE (P_Pay_Year,
                                     NULL, A.Pay_Year,
                                     P_Pay_Year)
                      AND A.Pay_Month =
                             DECODE (P_Pay_Month,
                                     NULL, A.Pay_Month,
                                     P_Pay_Month)
                      AND A.Payment_Group_Code =
                             DECODE (V_Pay_Date (Payid).Payment_Group_Code,
                                     NULL, A.Payment_Group_Code,
                                     V_Pay_Date (Payid).Payment_Group_Code)
                      AND A.Batch_Id IS NULL;

               IF Trnrec.Trans_Type IN (35, 36)
               THEN --onura 191344 hacizli kurum �demelerinin sisteme i�lenebilmesi
                  UPDATE Koc_Clm_Month_Confirm_Rem s
                     SET payment_date = NVL (V_Payment_Date, SYSDATE)
                   WHERE     s.institute_code = V_Institute_Code
                         AND s.payment_group_code =
                                DECODE (
                                   V_Pay_Date (Payid).Payment_Group_Code,
                                   NULL, s.Payment_Group_Code,
                                   V_Pay_Date (Payid).Payment_Group_Code)
                         --and s.firm = '0'
                         AND s.year =
                                DECODE (P_Pay_Year, NULL, s.Year, P_Pay_Year)
                         AND s.month =
                                DECODE (P_Pay_Month,
                                        NULL, s.Month,
                                        P_Pay_Month);
               END IF;

               payid := v_pay_date.NEXT (payid);
            END LOOP;

            IF V_Ret_Invoice_Id IS NOT NULL
            THEN
               UPDATE Alz_Invoice_Master_Ext A
                  SET A.Acc_Batch_Id = P_Batch_Id,
                      A.Accounting_Date = P_Acc_Date,
                      A.Accounting_User = USER
                WHERE A.Idx =
                         ALZ_INV_PROCESS_UTILS.GET_IDX_BY_INVID_FROM_INVOICE (
                            V_Ret_Invoice_Id);
            END IF;

            V_Pay_Date.Delete;
            V_Postings.Delete;
            V_Sayac := 1;
            V_Related_Order := 1;
         END IF;
      END LOOP;

      CLOSE Trnx;
   EXCEPTION
      WHEN OTHERS
      THEN
         v_err := SQLCODE || ':' || SQLERRM;
         --v_err := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE();
         ROLLBACK;
         raise_application_error (-20200, v_err);
   END;

   PROCEDURE indemnityrealization (p_claim_id                    NUMBER,
                                   p_sf_no                       NUMBER,
                                   p_add_order_no                NUMBER,
                                   p_dc                          NUMBER,
                                   p_source_of_invoice           NUMBER,
                                   p_supp_id                     NUMBER,
                                   p_ip_no                       NUMBER,
                                   p_contract_id                 NUMBER,
                                   p_partition_no                NUMBER,
                                   p_product_id                  NUMBER,
                                   p_partition_type              VARCHAR2,
                                   p_term_start_date             DATE,
                                   p_payment_type                VARCHAR2,
                                   p_payment_date                DATE,
                                   p_realization_batch_id        NUMBER,
                                   p_realization_ticket_date     DATE,
                                   p_user_id                     VARCHAR2,
                                   p_creditor_bank               VARCHAR2,
                                   p_creditor_subsidiary         VARCHAR2,
                                   p_account_no                  VARCHAR2,
                                   p_account_owner               VARCHAR2,
                                   p_indem_acc_exp               VARCHAR2,
                                   p_correspondent_bank          VARCHAR2,
                                   p_correspondent_subsidiary    VARCHAR2,
                                   p_correspondent_account_no    NUMBER,
                                   p_money_order_address         VARCHAR2,
                                   p_is_account_approved         NUMBER,
                                   p_to_whom_clm_paid            VARCHAR2,
                                   p_iban_code                   VARCHAR2,
                                   p_correspondent_iban_code     VARCHAR2,
                                   p_tc_no                       VARCHAR2,
                                   p_vkn_no                      VARCHAR2)
   IS
      --p_source_of_invoice=1 ELDEN
      --p_source_of_invoice=2 KURUM
      CURSOR curdetail
      IS
           SELECT b.claim_id,
                  b.sf_no,
                  b.add_order_no,
                  b.cover_code,
                  b.swift_code,
                  b.is_pool_cover,
                  b.is_special_cover,
                  SUM (b.exemption_amount) exemption_amount,
                  SUM (b.provision_total) provision_total,
                  SUM (b.refusal_amount) refusal_amount,
                  SUM (b.request_amount) request_amount,
                  a.ext_reference,
                  a.provision_date,
                  a.invoice_date,
                  a.claim_inst_type,
                  a.claim_inst_loc,
                  a.date_of_loss,
                  a.close_date,
                  a.realization_date,
                  a.institute_code,
                  a.country_code,
                  a.package_id,
                  a.package_date
             FROM koc_clm_hlth_detail a, koc_clm_hlth_provisions b
            WHERE     a.claim_id = p_claim_id
                  AND a.sf_no = p_sf_no
                  AND a.add_order_no = p_add_order_no
                  AND (   (    p_source_of_invoice = 2
                           AND a.status_code = DECODE (p_dc, 1, 'P', 'ODE'))
                       OR (    p_source_of_invoice = 1
                           AND a.status_code = DECODE (p_dc, 1, 'P', 'TAH')))
                  AND a.claim_id = b.claim_id
                  AND a.sf_no = b.sf_no
                  AND a.add_order_no = b.add_order_no
                  AND (   (    p_source_of_invoice = 2
                           AND b.status_code = DECODE (p_dc, 1, 'P', 'ODE'))
                       OR (    p_source_of_invoice = 1
                           AND b.status_code = DECODE (p_dc, 1, 'P', 'TAH')))
         GROUP BY b.claim_id,
                  b.sf_no,
                  b.add_order_no,
                  b.cover_code,
                  b.swift_code,
                  b.is_pool_cover,
                  b.is_special_cover,
                  a.ext_reference,
                  a.provision_date,
                  a.invoice_date,
                  a.claim_inst_type,
                  a.claim_inst_loc,
                  a.date_of_loss,
                  a.close_date,
                  a.realization_date,
                  a.institute_code,
                  a.country_code,
                  a.package_id,
                  a.package_date;

      clmdetail                  curdetail%ROWTYPE;
      p_provision_date           DATE;
      v_max_form_no              NUMBER;
      v_int_ref                  NUMBER;
      v_status_id                NUMBER;
      v_trans_no                 NUMBER := 1;
      v_currency_exchange_rate   NUMBER;
      v_err                      VARCHAR2 (2000);
      v_country_group            NUMBER;
      v_pay_curr_get_type        VARCHAR2 (4);
      v_pay_clearing_system_id   NUMBER;
      v_sf_total_type            NUMBER;
      v_cover_swf                VARCHAR2 (20);
      v_exch_date                VARCHAR2 (20);
      v_curr_date                DATE;
      v_realization_date         DATE;
      v_rec_found                BOOLEAN := FALSE;
      indeminfo                  koc_clm_hlth_indem_totals%ROWTYPE;
      icur                       koc_clm_hlth_trnx.refcur;
      v_indem_date               DATE;
      elementer_form_no          NUMBER;
      v_stoppage_amount          NUMBER;
   BEGIN
      --p_dc = 1 tahakkuk
      --p_dc = -1 tahakkuk iptal
      IF NVL (p_dc, 0) NOT IN (1, -1)
      THEN
         raise_application_error (-20200, '��lem i�areti hatas�');
      END IF;

      OPEN curdetail;

      LOOP
         FETCH curdetail INTO clmdetail;

         EXIT WHEN curdetail%NOTFOUND;
         v_country_group :=
            koc_clm_hlth_utils.getcountrygroup (clmdetail.country_code);

         IF clmdetail.provision_date IS NULL
         THEN
            p_provision_date :=
               NVL (clmdetail.date_of_loss, clmdetail.invoice_date);
         ELSE
            p_provision_date := clmdetail.provision_date;
         END IF;

         v_realization_date := p_payment_date;

         IF p_dc = -1
         THEN
            v_realization_date :=
               NVL (clmdetail.realization_date, clmdetail.close_date);
         END IF;

         v_currency_exchange_rate := 1;

         IF NVL (clmdetail.swift_code, base_swift_code) != base_swift_code
         THEN
            v_indem_date :=
               NVL (clmdetail.provision_date,
                    NVL (clmdetail.date_of_loss, clmdetail.invoice_date));
            koc_clm_hlth_trnx.getindemtotals (p_contract_id,
                                              p_partition_no,
                                              clmdetail.claim_inst_type,
                                              clmdetail.claim_inst_loc,
                                              v_country_group,
                                              clmdetail.cover_code,
                                              v_indem_date,
                                              0,
                                              0,
                                              p_user_id,
                                              clmdetail.is_pool_cover,
                                              clmdetail.is_special_cover,
                                              icur);

            FETCH icur INTO indeminfo;

            CLOSE icur;

            v_cover_swf := indeminfo.swift_code;

            SELECT DECODE (v_cover_swf,
                           base_swift_code, pay_clearing_system_id,
                           pay_swf_clear_sys_id),
                   DECODE (v_cover_swf,
                           base_swift_code, pay_curr_get_type,
                           pay_swf_curr_get_type),
                   DECODE (v_cover_swf,
                           base_swift_code, pay_exch_dates,
                           pay_swf_exch_dates)
              INTO v_pay_clearing_system_id, v_pay_curr_get_type, v_exch_date
              FROM koc_oc_prod_partition_rel
             WHERE     product_id = p_product_id
                   AND partition_type = p_partition_type
                   AND validity_start_date <= p_term_start_date
                   AND NVL (validity_end_date, p_term_start_date) >=
                          p_term_start_date;

            IF v_exch_date = 'FAT'
            THEN
               v_curr_date :=
                  NVL (clmdetail.provision_date, clmdetail.invoice_date);
            ELSIF v_exch_date = 'OLAY'
            THEN
               v_curr_date :=
                  NVL (clmdetail.provision_date,
                       NVL (clmdetail.date_of_loss, clmdetail.invoice_date));
            ELSIF v_exch_date = 'TAH'
            THEN
               v_curr_date :=
                  NVL (clmdetail.provision_date, v_realization_date);
            ELSE
               v_curr_date :=
                  NVL (clmdetail.provision_date, clmdetail.invoice_date);
            END IF;

            v_currency_exchange_rate :=
               koc_curr_utils.retrieve_currency_rate (
                  clmdetail.swift_code,
                  v_pay_curr_get_type,
                  TRUNC (v_curr_date),
                  v_pay_clearing_system_id,
                  TRUE);
         END IF;

         BEGIN
            SELECT NVL (counter, 0) + 1
              INTO v_max_form_no
              FROM koc_clm_counter
             WHERE     count_type = 'SMKBZ'
                   AND YEAR = TO_CHAR (p_payment_date, 'YYYY')
            FOR UPDATE;
         EXCEPTION
            WHEN OTHERS
            THEN
               v_max_form_no := 1;
         END;

         UPDATE koc_clm_counter
            SET counter = v_max_form_no
          WHERE     count_type = 'SMKBZ'
                AND YEAR = TO_CHAR (p_payment_date, 'YYYY');


         IF p_dc = 1
         THEN
            v_sf_total_type := 11;
         END IF;

         IF p_dc = -1
         THEN
            v_sf_total_type := 12;
         END IF;

         v_trans_no := NVL (getmaxtransno (p_claim_id, p_sf_no), 0) + 1;

         SELECT clm_int_ref_seq.NEXTVAL INTO v_int_ref FROM DUAL;

         INSERT INTO clm_trans (claim_id,
                                sf_no,
                                trans_no,
                                movement_id,
                                assignee,
                                sf_total_type,
                                trans_type,
                                trans_date,
                                clm_status,
                                trans_amt,
                                trans_amt_swf,
                                rsv_amt,
                                trans_base_amt,
                                int_ref,
                                supp_id,
                                ip_no,
                                oar_no,
                                ext_reference)
              VALUES (clmdetail.claim_id,
                      clmdetail.sf_no,
                      v_trans_no,
                      1,
                      p_user_id,
                      v_sf_total_type,
                      20,
                      p_payment_date,
                      'TRANS',
                      clmdetail.provision_total,
                      clmdetail.swift_code,
                      clmdetail.refusal_amount,
                      clmdetail.request_amount,
                      v_int_ref,
                      p_supp_id,
                      p_ip_no,
                      p_partition_no,
                      clmdetail.ext_reference);

         begin
         koc_clm_bordro.alz_hlth_bordro_trans_log(clmdetail.claim_id,v_trans_no,'KOC_CLM_HLTH_TRNX2-5381',null,1);
         exception when others then
            begin
             koc_clm_bordro.alz_hlth_bordro_trans_log(clmdetail.claim_id,v_trans_no,'KOC_CLM_HLTH_TRNX2-5381',null,1,substr(sqlerrm,1,950));
            exception when others then
             null;
            end;
         end;

         v_stoppage_amount :=
            koc_clm_hlth_trnx2.getstoppageamount (clmdetail.provision_total,
                                                  clmdetail.institute_code,
                                                  clmdetail.invoice_date,
                                                  clmdetail.date_of_loss); --cozbay task132695 08.02.2012 stopaj amount eklendi

         INSERT INTO koc_clm_trans_ext (claim_id,
                                        sf_no,
                                        add_order_no,
                                        trans_no,
                                        form_no,
                                        form_type,
                                        form_year,
                                        exemption_amount,
                                        hlth_cover_code,
                                        currency_exchange_rate,
                                        payment_type,
                                        realization_batch_id,
                                        realization_ticket_date,
                                        realization_user,
                                        payment_user,
                                        creditor_bank,
                                        creditor_subsidiary,
                                        account_no,
                                        correspondent_bank,
                                        correspondent_subsidiary,
                                        money_order_address,
                                        correspondent_account_code,
                                        creditor_name,
                                        to_whom_clm_paid,
                                        institute_code,
                                        is_account_approved,
                                        iban_code,
                                        correspondent_iban_code,
                                        bank_acc_IDENTITY_NO,
                                        bank_acc_tax_number,
                                        stoppage_amount)
              VALUES (
                        clmdetail.claim_id,
                        clmdetail.sf_no,
                        clmdetail.add_order_no,
                        v_trans_no,
                        v_max_form_no,
                        'MKBZ',
                        TO_CHAR (p_payment_date, 'YYYY'),
                        clmdetail.exemption_amount,
                        clmdetail.cover_code,
                        NVL (v_currency_exchange_rate, 1),
                        p_payment_type,
                        p_realization_batch_id,
                        p_realization_ticket_date,
                        p_user_id,
                        p_user_id,
                        p_creditor_bank,
                        p_creditor_subsidiary,
                        p_account_no,
                        p_correspondent_bank,
                        p_correspondent_subsidiary,
                        p_money_order_address,
                        p_correspondent_account_no,
                        p_account_owner,
                        p_to_whom_clm_paid,
                        DECODE (p_payment_type,
                                '7', clmdetail.institute_code,
                                NULL),
                        p_is_account_approved,
                        p_iban_code,
                        p_correspondent_iban_code,
                        p_tc_no,
                        p_vkn_no,
                        v_stoppage_amount);

         SELECT clm_status_id_seq.NEXTVAL INTO v_status_id FROM DUAL;

         INSERT INTO clm_status_history (status_id,
                                         claim_id,
                                         clm_line_id,
                                         clm_level,
                                         clm_status,
                                         csh_date,
                                         csh_username,
                                         sf_no,
                                         trans_no)
              VALUES (v_status_id,
                      clmdetail.claim_id,
                      20,
                      'TRANS',
                      'CLOSE',
                      TRUNC (SYSDATE),
                      p_user_id,
                      1,
                      v_trans_no);

         INSERT INTO koc_clm_status_history_ext (status_id,
                                                 claim_id,
                                                 sf_no,
                                                 clm_status,
                                                 process_date,
                                                 userid,
                                                 explanation)
              VALUES (v_status_id,
                      clmdetail.claim_id,
                      clmdetail.sf_no,
                      'CLOSE',
                      SYSDATE,
                      p_user_id,
                      'IR');

         UPDATE koc_clm_hlth_indem_totals a
            SET a.s_indemnity_amount =
                     NVL (a.s_indemnity_amount, 0)
                   + NVL (p_dc * clmdetail.provision_total, 0),
                a.s_provision_amount =
                     NVL (a.s_provision_amount, 0)
                   - NVL (p_dc * clmdetail.provision_total, 0)
          WHERE     a.claim_inst_type = clmdetail.claim_inst_type
                AND a.claim_inst_loc = clmdetail.claim_inst_loc
                AND a.contract_id = p_contract_id
                AND a.partition_no = p_partition_no
                AND a.country_group = v_country_group
                AND a.is_pool_cover = clmdetail.is_pool_cover
                AND a.is_special_cover = clmdetail.is_special_cover
                AND a.cover_code = clmdetail.cover_code
                AND a.is_valid = 1
                AND a.package_id = clmdetail.package_id
                AND a.package_date = clmdetail.package_date
                AND a.validity_start_date =
                       (SELECT MAX (aa.validity_start_date)
                          FROM koc_clm_hlth_indem_totals aa
                         WHERE     aa.contract_id = a.contract_id
                               AND aa.partition_no = a.partition_no
                               AND aa.claim_inst_type = a.claim_inst_type
                               AND aa.claim_inst_loc = a.claim_inst_loc
                               AND aa.country_group = a.country_group
                               AND aa.cover_code = a.cover_code
                               AND aa.is_special_cover = a.is_special_cover
                               AND aa.is_pool_cover = a.is_pool_cover
                               AND aa.package_date = a.package_date
                               AND aa.package_id = a.package_id
                               AND NVL (aa.is_valid, 0) = 1
                               AND aa.validity_start_date <= p_provision_date);

         v_trans_no := NVL (v_trans_no, 0) + 1;
         v_rec_found := TRUE;
      END LOOP;

      CLOSE curdetail;

      IF p_dc = 1 AND v_rec_found
      THEN
         UPDATE koc_clm_hlth_detail a
            SET status_code = 'TAH',
                close_date = p_payment_date,
                realization_date = p_payment_date
          WHERE     a.claim_id = p_claim_id
                AND a.sf_no = p_sf_no
                AND a.add_order_no = p_add_order_no
                AND a.status_code = 'P';

         UPDATE koc_clm_hlth_provisions a
            SET status_code = 'TAH'
          WHERE     a.claim_id = p_claim_id
                AND a.sf_no = p_sf_no
                AND a.add_order_no = p_add_order_no
                AND a.status_code = 'P';

         UPDATE koc_clm_hlth_proc_detail a
            SET status_code = 'TAH'
          WHERE     a.claim_id = p_claim_id
                AND a.sf_no = p_sf_no
                AND a.add_order_no = p_add_order_no
                AND a.status_code = 'P';

         --150408 BC yetki limit
         UPDATE KOC_CLM_HLTH_PROV_LIMIT a
            SET claim_status = 'TAH'
          WHERE     a.claim_id = p_claim_id
                AND a.sf_no = p_sf_no
                AND a.add_order_no = p_add_order_no
                AND a.claim_status = 'P';
      END IF;
   END;

   PROCEDURE finddatesforinstclmtrans (p_institute_code                NUMBER,
                                       p_payment_group                 VARCHAR2,
                                       p_max_ticket_date           OUT DATE,
                                       p_min_ticket_date           OUT DATE,
                                       p_technical_approved_date   OUT DATE)
   IS
   BEGIN
      SELECT MAX (b.ticket_date),
             MIN (b.ticket_date),
             MAX (technical_approved_date)
        INTO p_max_ticket_date, p_min_ticket_date, p_technical_approved_date
        FROM clm_trans a, koc_clm_trans_ext b, koc_clm_suppliers_ext c
       WHERE     a.claim_id = b.claim_id
             AND a.sf_no = b.sf_no
             AND a.trans_no = b.trans_no
             AND a.supp_id = c.supp_id
             AND b.payment_type = '7'
             AND c.payment_group_code = payment_group_code
             AND c.institute_code = p_institute_code
             AND a.sf_total_type IN ('11', '12')
             AND b.payment_approved_date IS NULL
             AND b.technical_approved_date IS NOT NULL;
   END;

   FUNCTION getfeerate (p_institute_code     NUMBER,
                        p_cover_cat_group    VARCHAR2,
                        p_date               DATE)
      RETURN NUMBER
   IS
      v_result   NUMBER;
   BEGIN
      SELECT a.rate
        INTO v_result
        FROM koc_cc_hlth_prov_ded_prc a
       WHERE     institute_code = p_institute_code
             AND cover_cat_group = p_cover_cat_group
             AND inf_type = 'PRVEXPRATE'
             AND validity_start_date <= p_date
             AND NVL (validity_end_date, p_date) >= p_date;

      RETURN (v_result);
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN (0);
   END;

   FUNCTION getfeeprice (p_cover_cat_group VARCHAR2, p_date DATE)
      RETURN NUMBER
   IS
      v_result   NUMBER;
   BEGIN
      SELECT a.price
        INTO v_result
        FROM koc_cc_hlth_prov_ded_prc a
       WHERE     institute_code = 0
             AND cover_cat_group = p_cover_cat_group
             AND inf_type = 'PRVEXPPRC'
             AND validity_start_date <= p_date
             AND NVL (validity_end_date, p_date) >= p_date;

      RETURN (v_result);
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN (0);
   END;

   FUNCTION isprovisionfee (p_institute_code NUMBER, p_trans_date DATE)
      RETURN NUMBER
   IS
      v_result   NUMBER;
   BEGIN
      SELECT NVL (c.is_provision_fee_charge, 0)
        INTO v_result
        FROM koc_v_clm_suppliers c
       WHERE     c.eff_date <= p_trans_date
             AND NVL (c.exp_date, p_trans_date) >= p_trans_date
             AND c.institute_code = p_institute_code
             AND ROWNUM < 2;

      RETURN (v_result);
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN (0);
   END;

   FUNCTION getservicerate (p_institute_code    NUMBER,
                            p_service_type      VARCHAR2,
                            p_date              DATE)
      RETURN NUMBER
   IS
      v_result   NUMBER;
   BEGIN
      SELECT a.rate
        INTO v_result
        FROM koc_cc_hlth_prov_ded_prc a
       WHERE     institute_code = p_institute_code
             AND inf_type = p_service_type
             AND validity_start_date <= p_date
             AND NVL (validity_end_date, p_date) >= p_date;

      RETURN (v_result);
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN (0);
   END;

   FUNCTION getreturnreceipt (pinst_code   IN NUMBER,
                              pclaim_id    IN NUMBER,
                              psf_no       IN NUMBER,
                              pcurr_rate   IN NUMBER,
                              ptrn_date1   IN DATE,
                              ptrn_date2   IN DATE)
      RETURN NUMBER
   IS
      /*cozbay task145365  06.08.2012 Sa�l�k Kurumlar�na kesilen provizyon iskontolar�n�n hesaplama revizyonu hk. */
      /*iade fatura toplami bulunur*/
      v_result   NUMBER;

      CURSOR cur
      IS
         SELECT NVL (
                   SUM (
                        DECODE (trans_type,  4, 1,  5, -1)
                      * NVL (trans_amount, 0)
                      * NVL (pcurr_rate, 1)),
                   0)
           FROM koc_clm_hlth_inst_trans
          WHERE     institute_code = pinst_code
                AND claim_id = pclaim_id
                AND sf_no = psf_no
                AND trans_date BETWEEN ptrn_date1 AND ptrn_date2
                AND trans_type IN ('4', '5');
   BEGIN
      OPEN cur;

      FETCH cur INTO v_result;

      CLOSE cur;

      RETURN NVL (v_result, 0);
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN 0;
   END;


   --Fonksiyon 03/06/2009 tarihinde de�i�tirildi. AKILINC
   PROCEDURE geninstclmtrans (p_institute_code    NUMBER,
                              p_payment_group     VARCHAR2,
                              p_order_no          NUMBER,
                              p_start_date        DATE,
                              p_end_date          DATE,
                              p_payment_term      DATE,
                              p_user_id           VARCHAR2,
                              p_payment_date      DATE DEFAULT NULL --mustafaku kenanp TSS 05032015
                                                                   )
   IS
      p_max_ticket_date           DATE;
      p_min_ticket_date           DATE;
      p_technical_approved_date   DATE;

      --/*+ ordered index (c KOC_CLM_SUPPLIERS_EXT_PK) */
      CURSOR cur
      IS
           SELECT /*+ no_expand */
                 a.sf_total_type,
                  SUM (
                       (NVL (a.trans_amt, 0) - NVL (b.stoppage_amount, 0))
                     * NVL (b.currency_exchange_rate, 1))
                     trn_amount, /*cozbay task132695 08/0/2012 stopaj eklendi */
                  SUM (
                       DECODE (d.specialty_subject, 1730, 1, 0)
                     * a.trans_amt
                     * NVL (b.currency_exchange_rate, 1))
                     trn_amount_dis,
                  c.institute_code,
                  DECODE (
                     SIGN (
                          TO_NUMBER (TO_CHAR (b.ticket_date, 'YYYY'))
                        - TO_NUMBER (TO_CHAR (p_end_date, 'YYYY'))),
                     -1, TO_DATE ('31/12/' || TO_CHAR (p_start_date, 'YYYY'),
                                  'DD/MM/YYYY'),
                     p_payment_term)
                     trans_date,
                  SUM (
                       NVL (b.stoppage_amount, 0)
                     * NVL (b.currency_exchange_rate, 1))
                     stoppage   /*cozbay task132695 08/0/2012 stopaj eklendi*/
             FROM koc_clm_trans_ext b,
                  clm_trans a,
                  koc_clm_suppliers_ext c,
                  koc_clm_hlth_detail d
            WHERE     a.claim_id = b.claim_id
                  AND a.sf_no = b.sf_no
                  AND a.trans_no = b.trans_no
                  --AND a.supp_id = c.supp_id
                  AND b.INSTITUTE_CODE = c.INSTITUTE_CODE
                  AND b.payment_type = '7'
                  --AND c.payment_group_code = p_payment_group
                  AND c.institute_code =
                         DECODE (p_institute_code,
                                 NULL, c.institute_code,
                                 p_institute_code)
                  AND b.ticket_date >= p_start_date
                  AND b.ticket_date <= p_end_date
                  AND (ticket_no >= 0 OR ticket_no IS NULL)
                  AND a.sf_total_type IN ('11', '12')
                  AND b.claim_id = d.claim_id
                  AND b.sf_no = d.sf_no
                  AND b.add_order_no = d.add_order_no
                  AND (   (    c.tss_payment_group_code = p_payment_group
                           AND NVL (is_complementary, 0) = 1)
                       OR (    c.payment_group_code = p_payment_group
                           AND NVL (is_complementary, 0) = 0)) -- mustafaku kenanp TSS 05032015
                  AND b.payment_approved_date IS NULL
         GROUP BY c.institute_code,
                  a.sf_total_type,
                  DECODE (
                     SIGN (
                          TO_NUMBER (TO_CHAR (b.ticket_date, 'YYYY'))
                        - TO_NUMBER (TO_CHAR (p_end_date, 'YYYY'))),
                     -1, TO_DATE ('31/12/' || TO_CHAR (p_start_date, 'YYYY'),
                                  'DD/MM/YYYY'),
                     p_payment_term);

      --- PROV�ZYON ADED�
      CURSOR curcntclm
      IS
           SELECT SUM (QSUM.ADET) ADET,
                  QSUM.SF_TOTAL_TYPE,
                  QSUM.INSTITUTE_CODE,
                  QSUM.COVER_CAT_GROUP,
                  SUM (QSUM.PRICE * QSUM.RATE * QSUM.ADET) PROVISION_FEE,
                  QSUM.PRICE,
                  QSUM.RATE,
                  QSUM.CLAIM_ID,
                  QSUM.SF_NO,
                  QSUM.ADD_ORDER_NO
             FROM (SELECT Q1.CNT ADET,
                          Q1.CLAIM_ID,
                          Q1.SF_NO,
                          Q1.ADD_ORDER_NO,
                          Q1.INSTITUTE_CODE,
                          Q1.COVER_CAT_GROUP,
                          Q1.DATE_OF_LOSS,
                          Q1.SF_TOTAL_TYPE,
                          KOC_CLM_HLTH_TRNX2.GETFEERATE (Q1.INSTITUTE_CODE,
                                                         Q1.COVER_CAT_GROUP,
                                                         Q1.DATE_OF_LOSS)
                             RATE,
                          KOC_CLM_HLTH_TRNX2.GETFEEPRICE (Q1.COVER_CAT_GROUP,
                                                          Q1.DATE_OF_LOSS)
                             PRICE
                     FROM (  SELECT COUNT (*) CNT,
                                    QTRN.SF_TOTAL_TYPE,
                                    QTRN.INSTITUTE_CODE,
                                    QTRN.COVER_CAT_GROUP,
                                    QTRN.DATE_OF_LOSS,
                                    QTRN.IS_PROVISION_FEE_CHARGE,
                                    QTRN.CLAIM_ID,
                                    QTRN.SF_NO,
                                    QTRN.ADD_ORDER_NO
                               FROM (SELECT /*+ ordered index (c KOC_CLM_SUPPLIERS_EXT_PK) */
                                           DISTINCT
                                            C.INSTITUTE_CODE,
                                            A.CLAIM_ID,
                                            A.SF_NO,
                                            B.ADD_ORDER_NO,
                                            D.COVER_CAT_GROUP,
                                            E.DATE_OF_LOSS,
                                            A.SF_TOTAL_TYPE,
                                            KOC_CLM_HLTH_TRNX2.ISPROVISIONFEE (
                                               C.INSTITUTE_CODE,
                                               E.DATE_OF_LOSS)
                                               IS_PROVISION_FEE_CHARGE
                                       FROM KOC_CLM_TRANS_EXT B,
                                            CLM_TRANS A,
                                            KOC_CLM_SUPPLIERS_EXT C,
                                            KOC_OC_COVER_DEFINITIONS D,
                                            CLM_POL_BASES E,
                                            (  SELECT /*+ ordered index (c KOC_CLM_SUPPLIERS_EXT_PK) */
                                                     SUM (
                                                           DECODE (A.SF_TOTAL_TYPE,
                                                                   11, 1,
                                                                   12, -1,
                                                                   0)
                                                         * A.TRANS_AMT
                                                         * NVL (
                                                              B.CURRENCY_EXCHANGE_RATE,
                                                              1))
                                                         TRN_AMOUNT,
                                                      C.INSTITUTE_CODE,
                                                      B.CLAIM_ID,
                                                      B.SF_NO,
                                                      B.ADD_ORDER_NO
                                                 FROM KOC_CLM_TRANS_EXT B,
                                                      CLM_TRANS A,
                                                      KOC_CLM_SUPPLIERS_EXT C
                                                WHERE     A.CLAIM_ID = B.CLAIM_ID
                                                      AND A.SF_NO = B.SF_NO
                                                      AND A.TRANS_NO = B.TRANS_NO
                                                      AND A.SUPP_ID = C.SUPP_ID
                                                      AND B.PAYMENT_TYPE = '7'
                                                      AND C.PAYMENT_GROUP_CODE =
                                                             P_PAYMENT_GROUP
                                                      AND C.INSTITUTE_CODE =
                                                             DECODE (
                                                                P_INSTITUTE_CODE,
                                                                NULL, C.INSTITUTE_CODE,
                                                                P_INSTITUTE_CODE)
                                                      AND B.TICKET_DATE >=
                                                             P_START_DATE
                                                      AND B.TICKET_DATE <=
                                                             P_END_DATE
                                                      AND A.SF_TOTAL_TYPE IN
                                                             ('11', '12')
                                                      AND B.PAYMENT_APPROVED_DATE
                                                             IS NULL
                                                      AND NOT EXISTS
                                                                 (SELECT NULL --mustafaku kenanp TSS 05032015
                                                                    FROM koc_clm_hlth_detail d
                                                                   WHERE     d.claim_id =
                                                                                b.claim_id
                                                                         AND d.add_order_no =
                                                                                b.add_order_no
                                                                         AND d.sf_no =
                                                                                b.sf_no
                                                                         AND NVL (
                                                                                d.is_complementary,
                                                                                0) =
                                                                                1)
                                             GROUP BY C.INSTITUTE_CODE,
                                                      B.CLAIM_ID,
                                                      B.SF_NO,
                                                      B.ADD_ORDER_NO
                                               HAVING ABS (
                                                         SUM (
                                                              DECODE (
                                                                 A.SF_TOTAL_TYPE,
                                                                 11, 1,
                                                                 12, -1,
                                                                 0)
                                                            * A.TRANS_AMT
                                                            * NVL (
                                                                 B.CURRENCY_EXCHANGE_RATE,
                                                                 1))) > 10) QTOP
                                      WHERE     A.CLAIM_ID = B.CLAIM_ID
                                            AND A.SF_NO = B.SF_NO
                                            AND A.TRANS_NO = B.TRANS_NO
                                            AND A.SUPP_ID = C.SUPP_ID
                                            AND B.PAYMENT_TYPE = '7'
                                            AND C.PAYMENT_GROUP_CODE =
                                                   P_PAYMENT_GROUP
                                            AND B.CLAIM_ID = E.CLAIM_ID
                                            AND C.INSTITUTE_CODE =
                                                   DECODE (
                                                      P_INSTITUTE_CODE,
                                                      NULL, C.INSTITUTE_CODE,
                                                      P_INSTITUTE_CODE)
                                            AND B.TICKET_DATE >= P_START_DATE
                                            AND B.TICKET_DATE <= P_END_DATE
                                            AND A.SF_TOTAL_TYPE IN ('11', '12')
                                            AND B.PAYMENT_APPROVED_DATE IS NULL
                                            AND B.HLTH_COVER_CODE = D.COVER_CODE
                                            AND D.VALIDITY_START_DATE <=
                                                   A.TRANS_DATE
                                            AND NVL (D.VALIDITY_END_DATE,
                                                     A.TRANS_DATE) >=
                                                   A.TRANS_DATE
                                            AND (   (    D.COVER_CAT_GROUP = 'AT'
                                                     AND NOT EXISTS
                                                                (SELECT 1
                                                                   FROM KOC_CLM_TRANS_EXT XX,
                                                                        KOC_OC_COVER_DEFINITIONS YY
                                                                  WHERE     XX.HLTH_COVER_CODE =
                                                                               YY.COVER_CODE
                                                                        AND YY.VALIDITY_START_DATE <=
                                                                               XX.TICKET_DATE
                                                                        AND NVL (
                                                                               YY.VALIDITY_END_DATE,
                                                                               XX.TICKET_DATE) >=
                                                                               XX.TICKET_DATE
                                                                        AND XX.CLAIM_ID =
                                                                               B.CLAIM_ID
                                                                        AND XX.SF_NO =
                                                                               B.SF_NO
                                                                        AND XX.ADD_ORDER_NO =
                                                                               B.ADD_ORDER_NO
                                                                        AND YY.COVER_CAT_GROUP =
                                                                               'YT'
                                                                        AND XX.REALIZATION_BATCH_ID
                                                                               IS NOT NULL
                                                                        AND XX.TICKET_DATE >=
                                                                               P_START_DATE
                                                                        AND XX.TICKET_DATE <=
                                                                               P_END_DATE))
                                                 OR D.COVER_CAT_GROUP = 'YT')
                                            AND C.INSTITUTE_CODE =
                                                   QTOP.INSTITUTE_CODE
                                            AND B.CLAIM_ID = QTOP.CLAIM_ID
                                            AND B.SF_NO = QTOP.SF_NO
                                            AND B.ADD_ORDER_NO =
                                                   QTOP.ADD_ORDER_NO) QTRN
                              WHERE QTRN.IS_PROVISION_FEE_CHARGE = 1
                           GROUP BY QTRN.INSTITUTE_CODE,
                                    QTRN.COVER_CAT_GROUP,
                                    QTRN.DATE_OF_LOSS,
                                    QTRN.IS_PROVISION_FEE_CHARGE,
                                    QTRN.CLAIM_ID,
                                    QTRN.SF_NO,
                                    QTRN.ADD_ORDER_NO,
                                    QTRN.SF_TOTAL_TYPE) Q1) QSUM
            WHERE NVL (QSUM.PRICE, 0) != 0 AND NVL (QSUM.RATE, 0) != 0
         GROUP BY QSUM.INSTITUTE_CODE,
                  QSUM.COVER_CAT_GROUP,
                  QSUM.PRICE,
                  RATE,
                  QSUM.CLAIM_ID,
                  QSUM.SF_NO,
                  QSUM.ADD_ORDER_NO,
                  QSUM.SF_TOTAL_TYPE
         ORDER BY QSUM.INSTITUTE_CODE;



      CURSOR cursumclm
      IS
           SELECT QTOP.INSTITUTE_CODE,
                  SUM (
                       (  KOC_CLM_HLTH_TRNX2.GETSERVICERATE (
                             QTOP.INSTITUTE_CODE,
                             'DISCRATE',
                             QTOP.DATE_OF_LOSS)
                        + KOC_CLM_HLTH_TRNX2.GETSERVICERATE (
                             QTOP.INSTITUTE_CODE,
                             'SERVRATE',
                             QTOP.DATE_OF_LOSS))
                     * (  QTOP.TRN_AMOUNT
                        - KOC_CLM_HLTH_TRNX2.GETRETURNRECEIPT (
                             QTOP.INSTITUTE_CODE,
                             QTOP.CLAIM_ID,
                             QTOP.SF_NO,
                             QTOP.CURRENCY_EXCHANGE_RATE,
                             P_START_DATE,
                             P_END_DATE)))
                     ISK,
                  SUM (
                       KOC_CLM_HLTH_TRNX2.GETSERVICERATE (QTOP.INSTITUTE_CODE,
                                                          'SERV2RATE',
                                                          QTOP.DATE_OF_LOSS)
                     * QTOP.TRN_AMOUNT_SERV2)
                     ISK_2,
                  QTOP.CLAIM_ID,
                  QTOP.SF_NO,
                  QTOP.ADD_ORDER_NO
             FROM (  SELECT /*+ no_expand */
                           C.INSTITUTE_CODE,
                            D.DATE_OF_LOSS,
                            SUM (
                                 DECODE (A.SF_TOTAL_TYPE,  11, 1,  12, -1,  0)
                               * A.TRANS_AMT
                               * NVL (B.CURRENCY_EXCHANGE_RATE, 1))
                               TRN_AMOUNT,
                            SUM (
                                 DECODE (D.SPECIALTY_SUBJECT, 1730, 1, 0)
                               * DECODE (A.SF_TOTAL_TYPE,  11, 1,  12, -1,  0)
                               * A.TRANS_AMT
                               * NVL (B.CURRENCY_EXCHANGE_RATE, 1))
                               TRN_AMOUNT_SERV2,
                            B.CLAIM_ID,
                            B.SF_NO,
                            B.ADD_ORDER_NO,
                            B.CURRENCY_EXCHANGE_RATE
                       FROM KOC_CLM_TRANS_EXT B,
                            CLM_TRANS A,
                            KOC_CLM_SUPPLIERS_EXT C,
                            KOC_CLM_HLTH_DETAIL D
                      WHERE     A.CLAIM_ID = B.CLAIM_ID
                            AND A.SF_NO = B.SF_NO
                            AND A.TRANS_NO = B.TRANS_NO
                            --AND a.supp_id = c.supp_id
                            AND B.INSTITUTE_CODE = C.INSTITUTE_CODE
                            AND B.PAYMENT_TYPE = '7'
                            --AND C.PAYMENT_GROUP_CODE = P_PAYMENT_GROUP  mustafaku kenanp TSS 05032015
                            AND C.INSTITUTE_CODE =
                                   DECODE (P_INSTITUTE_CODE,
                                           NULL, C.INSTITUTE_CODE,
                                           P_INSTITUTE_CODE)
                            AND B.TICKET_DATE >= P_START_DATE
                            AND B.TICKET_DATE <= P_END_DATE
                            AND A.SF_TOTAL_TYPE IN ('11', '12')
                            AND B.PAYMENT_APPROVED_DATE IS NULL
                            AND B.CLAIM_ID = D.CLAIM_ID
                            AND B.SF_NO = D.SF_NO
                            AND B.ADD_ORDER_NO = D.ADD_ORDER_NO
                            AND (   (    C.TSS_PAYMENT_GROUP_CODE =
                                            P_PAYMENT_GROUP
                                     AND NVL (d.is_complementary, 0) = 1)
                                 OR            --mustafaku kenanp TSS 05032015
                                    (    C.PAYMENT_GROUP_CODE = P_PAYMENT_GROUP
                                     AND NVL (d.is_complementary, 0) = 0))
                   GROUP BY C.INSTITUTE_CODE,
                            D.DATE_OF_LOSS,
                            B.CLAIM_ID,
                            B.SF_NO,
                            B.ADD_ORDER_NO,
                            B.CURRENCY_EXCHANGE_RATE) QTOP
         GROUP BY QTOP.INSTITUTE_CODE,
                  QTOP.CLAIM_ID,
                  QTOP.SF_NO,
                  QTOP.ADD_ORDER_NO;


      --Curdor kullan�lmad���ndan TSS i�in de�i�iklik yap�lmad�
      CURSOR curinst (
         p_institute_code    NUMBER,
         p_date1             DATE,
         p_date2             DATE)
      IS
         SELECT a.eff_date,
                NVL (b.is_provision_fee_charge, 0) is_provision_fee_charge,
                b.discount_rate,
                b.service_value_rate,
                b.service_value_rate_2
           FROM clm_suppliers a, koc_clm_suppliers_ext b
          WHERE     a.supp_id = b.supp_id
                AND b.institute_code = p_institute_code
                AND a.eff_date <= p_date2
                AND NVL (a.exp_date, p_date1) >= p_date1
         -- and nvl(b.is_provision_fee_charge,0) = 1
         UNION
         SELECT a.eff_date,
                NVL (b.is_provision_fee_charge, 0) is_provision_fee_charge,
                b.discount_rate,
                b.service_value_rate,
                b.service_value_rate_2
           FROM clm_suppliers a, koc_clm_supp_ext_his b
          WHERE     a.supp_id = b.supp_id
                AND b.institute_code = p_institute_code
                AND a.eff_date <= p_date2
                AND NVL (a.exp_date, p_date1) >= p_date1
         ORDER BY 1 DESC;

      --and nvl(b.is_provision_fee_charge,0) = 1;
      rec                         cur%ROWTYPE;
      reccnt                      curcntclm%ROWTYPE;
      recinst                     curinst%ROWTYPE;
      recsumclm                   cursumclm%ROWTYPE;
      v_provision_discount        NUMBER;

      v_provision_fee             NUMBER;
      v_trans_no                  NUMBER := 0;
      v_cover_cat_group           VARCHAR2 (20) := 'X';
      v_fee_cnt                   NUMBER := 0;
      v_price                     NUMBER := 0;
      v_exp                       VARCHAR2 (100);
      v_inst_ext_id               NUMBER;               --,mukerrer task� i�in
   BEGIN
      IF p_payment_group != '99'
      THEN
         DELETE FROM koc_clm_hlth_inst_trans a
               WHERE     a.institute_code =
                            DECODE (p_institute_code,
                                    NULL, a.institute_code,
                                    p_institute_code)
                     AND payment_group_code = p_payment_group
                     AND a.trans_date = p_payment_term
                     AND a.firm = '0'
                     AND a.trans_type IN (1, 2, 3, 21, 11, 33, 34)
                     AND approve_date IS NULL
                     AND (   p_payment_date IS NULL
                          OR (    p_payment_date IS NOT NULL
                              AND a.payment_date = p_payment_date)); -- mustafaku kenanp TSS 05032015



         DELETE FROM koc_clm_hlth_inst_trans a
               WHERE     a.institute_code =
                            DECODE (p_institute_code,
                                    NULL, a.institute_code,
                                    p_institute_code)
                     AND payment_group_code = p_payment_group
                     --                 AND a.trans_date = p_payment_term
                     AND pay_year = TO_CHAR (p_payment_term, 'yyyy')
                     AND pay_month = TO_CHAR (p_payment_term, 'mm')
                     AND a.firm = '0'
                     AND a.trans_type IN (1, 21)
                     AND approve_date IS NULL
                     AND (   p_payment_date IS NULL
                          OR (    p_payment_date IS NOT NULL
                              AND a.payment_date = p_payment_date)); -- mustafaku kenanp TSS 05032015

         --    and a.order_no = p_order_no;
         UPDATE koc_clm_trans_ext
            SET technical_approved_date = NULL, pay_order_no = NULL
          WHERE ROWID IN
                   (SELECT b.ROWID
                      FROM koc_clm_trans_ext b,
                           clm_trans a,
                           koc_clm_suppliers_ext c
                     WHERE     a.claim_id = b.claim_id
                           AND a.sf_no = b.sf_no
                           AND a.trans_no = b.trans_no
                           AND a.supp_id = c.supp_id
                           AND b.payment_type = 7
                           --AND c.payment_group_code = p_payment_group mustafaku kenanp TSS 05032015
                           AND (   (    c.payment_group_code =
                                           p_payment_group
                                    AND p_payment_group NOT LIKE 'T%')
                                OR (    c.tss_payment_group_code =
                                           p_payment_group
                                    AND p_payment_group LIKE 'T%')) -- mustafaku kenanp TSS 05032015
                           AND c.institute_code =
                                  DECODE (p_institute_code,
                                          NULL, c.institute_code,
                                          p_institute_code)
                           AND b.ticket_date >= p_start_date
                           AND b.ticket_date <= p_end_date
                           AND (ticket_no >= 0 OR ticket_no IS NULL)
                           AND a.sf_total_type IN ('11', '12')
                           AND b.payment_approved_date IS NULL
                           AND technical_approved_date = p_payment_term);
      ELSE
         koc_clm_hlth_trnx2.finddatesforinstclmtrans (
            p_institute_code,
            p_payment_group,
            p_max_ticket_date,
            p_min_ticket_date,
            p_technical_approved_date);

         IF p_max_ticket_date IS NOT NULL
         THEN
            DELETE FROM koc_clm_hlth_inst_trans a
                  WHERE     a.institute_code =
                               DECODE (p_institute_code,
                                       NULL, a.institute_code,
                                       p_institute_code)
                        AND payment_group_code = p_payment_group
                        AND a.trans_date = p_technical_approved_date
                        AND a.firm = '0'
                        AND a.trans_type IN (1, 2, 3, 21, 11, 33, 34)
                        AND approve_date IS NULL;

            --    and a.order_no = p_order_no;
            UPDATE koc_clm_trans_ext
               SET technical_approved_date = NULL, pay_order_no = NULL
             WHERE ROWID IN
                      (SELECT b.ROWID
                         FROM clm_trans a,
                              koc_clm_trans_ext b,
                              koc_clm_suppliers_ext c
                        WHERE     a.claim_id = b.claim_id
                              AND a.sf_no = b.sf_no
                              AND a.trans_no = b.trans_no
                              AND a.supp_id = c.supp_id
                              AND b.payment_type = '7'
                              AND c.payment_group_code = p_payment_group
                              AND c.institute_code =
                                     DECODE (p_institute_code,
                                             NULL, c.institute_code,
                                             p_institute_code)
                              AND b.ticket_date >= p_min_ticket_date
                              AND b.ticket_date <= p_max_ticket_date
                              AND (ticket_no >= 0 OR ticket_no IS NULL)
                              AND a.sf_total_type IN ('11', '12')
                              AND b.payment_approved_date IS NULL
                              AND technical_approved_date =
                                     p_technical_approved_date);
         END IF;
      END IF;



      OPEN cur;

      LOOP
         FETCH cur INTO rec;

         EXIT WHEN cur%NOTFOUND;

         SELECT NVL (MAX (trans_no), 0) + 1
           INTO v_trans_no
           FROM koc_clm_hlth_inst_trans
          WHERE     institute_code = rec.institute_code --            AND trans_date = p_payment_term
                AND trans_date = rec.trans_date
                AND trans_type IN (1, 21);

         --AND order_no = p_order_no;--kora06 pk ya d��me sorunu oldu�undan kald�r�ld�. 30/01/2012

         IF NVL (rec.trn_amount, 0) != 0
         THEN
            BEGIN
               v_inst_ext_id := NULL;                    --mukerrer task� i�in

               SELECT KOC_CLM_TRANS_INST_EXT_SEQ.NEXTVAL --mukerrer task� i�in
                 INTO v_inst_ext_id
                 FROM DUAL;

               UPDATE koc_clm_trans_ext                  --mukerrer task� i�in
                  SET inst_ext_id = v_inst_ext_id
                WHERE ROWID IN
                         (SELECT b.ROWID
                            FROM koc_clm_trans_ext b,
                                 clm_trans a,
                                 koc_clm_suppliers_ext c,
                                 koc_clm_hlth_detail d
                           WHERE     a.claim_id = b.claim_id
                                 AND a.sf_no = b.sf_no
                                 AND a.trans_no = b.trans_no
                                 AND b.INSTITUTE_CODE = c.INSTITUTE_CODE
                                 AND b.payment_type = '7'
                                 AND c.institute_code = rec.institute_code
                                 AND b.ticket_date >= p_start_date
                                 AND b.ticket_date <= p_end_date
                                 AND (ticket_no >= 0 OR ticket_no IS NULL)
                                 AND a.sf_total_type IN ('11', '12')
                                 AND b.claim_id = d.claim_id
                                 AND b.sf_no = d.sf_no
                                 AND b.add_order_no = d.add_order_no
                                 AND inst_ext_id IS NULL
                                 AND d.status_code = 'ODE'
                                 AND (   (    c.tss_payment_group_code =
                                                 p_payment_group
                                          AND NVL (is_complementary, 0) = 1)
                                      OR (    c.payment_group_code =
                                                 p_payment_group
                                          AND NVL (is_complementary, 0) = 0)) -- mustafaku kenanp TSS 05032015
                                 AND b.payment_approved_date IS NULL);
            EXCEPTION
               WHEN OTHERS
               THEN
                  NULL;
            END;

            INSERT INTO koc_clm_hlth_inst_trans (institute_code,
                                                 trans_date,
                                                 trans_type,
                                                 firm,
                                                 trans_no,
                                                 order_no,
                                                 trans_amount,
                                                 pay_year,
                                                 pay_month,
                                                 userid,
                                                 entry_date,
                                                 batch_id,
                                                 payment_group_code,
                                                 stoppage_amount /*cozbay task132695 08/0/2012 stopaj eklendi*/
                                                                ,
                                                 CONFIRMATION_DATE,
                                                 PAYMENT_DATE,
                                                 inst_ext_id --Mukerrer task� i�in
                                                            )
                 VALUES (rec.institute_code,
                         rec.trans_date,
                         DECODE (rec.sf_total_type,  11, 1,  12, 21,  0),
                         '0',
                         v_trans_no,
                         p_order_no,
                         NVL (rec.trn_amount, 0),
                         TO_CHAR (p_payment_term, 'YYYY'),
                         TO_CHAR (p_payment_term, 'MM'),
                         p_user_id,
                         SYSDATE,
                         0,
                         p_payment_group,
                         rec.stoppage /*cozbay task132695 08/0/2012 stopaj eklendi*/
                                     ,
                         p_end_date,
                         p_payment_date,
                         v_inst_ext_id                   --Mukerrer task� i�in
                                      );
         END IF;
      END LOOP;

      CLOSE cur;

      -------------- tarihe g�re iskonto
      IF p_payment_group NOT LIKE 'T%'
      THEN
         OPEN cursumclm;


         LOOP
            FETCH cursumclm INTO recsumclm;

            EXIT WHEN cursumclm%NOTFOUND;

            SELECT NVL (MAX (trans_no), 0) + 1
              INTO v_trans_no
              FROM koc_clm_hlth_inst_trans
             WHERE     institute_code = recsumclm.institute_code
                   AND trans_date = p_payment_term
                   AND trans_type IN (2, 11, 33, 34);

            --AND order_no = p_order_no;

            v_provision_discount := recsumclm.isk;
            v_exp := 'Anla�mal� Kurum Teknoloji Destek Bedeli';      --ONURA

            /*
                        IF p_payment_group = 4 --MYALINKILIC-TYH-56664:Ezcanelere �zel �la� iskontosu hesaplayan sorgu
                        THEN
                           BEGIN
                              --                  SELECT SUM (discounted_amount)
                              --                    INTO v_provision_discount
                              --                    FROM (SELECT CASE
                              --                                    WHEN g.is_discounted = 1
                              --                                    THEN
                              --                                         (  (  e.price
                              --                                             - e.price * h.exemption_rate)
                              --                                          * g.discounted_rate)
                              --                                       / 100 --c.price-trunc(( 1-exemption_rate)*(c.price-( (c.price * discounted_rate)/100)))--c.price-( (c.price * discounted_rate)/100)
                              --                                    ELSE
                              --                                       TRUNC (
                              --                                            (1 - h.exemption_rate)
                              --                                          * (  (  koc_clm_hlth_trnx2.getservicerate (
                              --                                                     d.institute_code,
                              --                                                     'DISCRATE',
                              --                                                     d.date_of_loss)
                              --                                                + koc_clm_hlth_trnx2.getservicerate (
                              --                                                     d.institute_code,
                              --                                                     'SERVRATE',
                              --                                                     d.date_of_loss))
                              --                                             * (  e.price
                              --                                                - koc_clm_hlth_trnx2.getreturnreceipt (
                              --                                                     d.institute_code,
                              --                                                     d.claim_id,
                              --                                                     d.sf_no,
                              --                                                     1,
                              --                                                     --                           e.currency_exchange_rate,
                              --                                                     p_start_date,
                              --                                                     p_end_date))),
                              --                                          2)
                              --                                 END
                              --                                    discounted_amount
                              --                            FROM koc_clm_trans_ext b,
                              --                                 clm_trans a,
                              --                                 koc_clm_suppliers_ext c,
                              --                                 koc_clm_hlth_detail d,
                              --                                 koc_clm_medicine_indem_det e,
                              --                                 koc_cc_medicines g,
                              --                                 koc_clm_hlth_provisions h
                              --                           WHERE     a.claim_id = b.claim_id
                              --                                 AND a.sf_no = b.sf_no
                              --                                 AND a.trans_no = b.trans_no
                              --                                 --AND a.supp_id = c.supp_id
                              --                                 AND b.institute_code = c.institute_code
                              --                                 AND a.claim_id = e.claim_id
                              --                                 AND b.payment_type = '7'
                              --                                 AND a.claim_id = recsumclm.claim_id --33216417                  --recsumclm.claim_id
                              --                                 AND b.hlth_cover_code = e.cover_code
                              --                                 AND e.barcode = g.barcode
                              --                                 AND h.claim_id = d.claim_id
                              --                                 AND h.sf_no = d.sf_no
                              --                                 AND h.add_order_no = d.add_order_no
                              --                                 AND h.cover_code = e.cover_code
                              --                                 AND a.sf_total_type IN ('11', '12')
                              --                                 AND b.payment_approved_date IS NULL
                              --                                 AND b.claim_id = d.claim_id
                              --                                 AND b.sf_no = d.sf_no
                              --                                 AND b.add_order_no = d.add_order_no
                              --                                 AND g.validity_date =
                              --                                        (SELECT MAX (g1.validity_date)
                              --                                           FROM koc_cc_medicines g1
                              --                                          WHERE     g.barcode = g1.barcode
                              --                                                AND TRUNC (d.provision_Date) >
                              --                                                       g1.validity_date));

                              SELECT SUM (discounted_amount) discounted_amount
                                INTO v_provision_discount
                                FROM (SELECT CASE
                                                WHEN mcbprv.is_discounted = 1
                                                THEN
                                                     (  (  mcbprv.cmprice
                                                         -   mcbprv.cmprice      --e.price
                                                           * mcbprv.exemption_rate)
                                                      * mcbprv.discounted_rate)
                                                   / 100 --c.price-trunc(( 1-exemption_rate)*(c.price-( (c.price * discounted_rate)/100)))--c.price-( (c.price * discounted_rate)/100)
                                                ELSE
                                                   TRUNC (
                                                        (1 - mcbprv.exemption_rate)
                                                      * (  (  koc_clm_hlth_trnx2.getservicerate (
                                                                 mcbprv.institute_code,
                                                                 'DISCRATE',
                                                                 mcbprv.date_of_loss)
                                                            + koc_clm_hlth_trnx2.getservicerate (
                                                                 mcbprv.institute_code,
                                                                 'SERVRATE',
                                                                 mcbprv.date_of_loss))
                                                         * (  mcbprv.provision_total --e.price
                                                            - koc_clm_hlth_trnx2.getreturnreceipt (
                                                                 mcbprv.institute_code,
                                                                 mcbprv.claim_id,
                                                                 mcbprv.sf_no,
                                                                 1,
                                                                 --                           e.currency_exchange_rate,
                                                                 p_start_date,
                                                                 p_end_date))),
                                                      2)
                                             END
                                                discounted_amount
                                        FROM (SELECT cbprv.claim_id,
                                                     cbprv.sf_no,
                                                     cbprv.date_of_loss,
                                                     cbprv.provision_date,
                                                     cbprv.exemption_rate,
                                                     cbprv.barcode,
                                                     cbprv.provision_total,
                                                     cbprv.institute_code,
                                                     cbprv.cmprice,
                                                     NVL (
                                                        med.validity_date,
                                                        TO_DATE ('01.01.1900',
                                                                 'dd.mm.yyyy'))
                                                        validity_date,
                                                     NVL (med.is_discounted, 0)
                                                        is_discounted,
                                                     NVL (med.discounted_rate, 0)
                                                        discounted_rate
                                                FROM (SELECT prv.claim_id,
                                                             prv.sf_no,
                                                             prv.date_of_loss,
                                                             prv.institute_code,
                                                             prv.provision_date,
                                                             prv.exemption_rate,
                                                             NVL (cmed.barcode, -1)
                                                                barcode,
                                                             cmed.price cmprice,
                                                             prv.provision_total
                                                        FROM (  SELECT d.claim_id,
                                                                       d.provision_date,
                                                                       d.sf_no,
                                                                       d.add_order_no,
                                                                       d.date_of_loss,
                                                                       h.cover_code,
                                                                       h.location_code,
                                                                       h.exemption_rate,
                                                                       d.institute_code,
                                                                       SUM (
                                                                          h.provision_total)
                                                                          provision_total,
                                                                       SUM (
                                                                          h.request_amount)
                                                                          request_amount -- barkodsuz manuel olarak provizyon al�nabilir
                                                                  FROM koc_clm_trans_ext b,
                                                                       clm_trans a,
                                                                       koc_clm_suppliers_ext c,
                                                                       koc_clm_hlth_detail d,
                                                                       koc_clm_hlth_provisions h
                                                                 WHERE     a.claim_id =
                                                                              b.claim_id
                                                                       AND a.sf_no =
                                                                              b.sf_no
                                                                       AND a.trans_no =
                                                                              b.trans_no
                                                                       AND a.supp_id =
                                                                              c.supp_id
                                                                       AND b.institute_code =
                                                                              c.institute_code
                                                                       AND b.payment_type =
                                                                              '7'
                                                                       AND a.claim_id =
                                                                              recsumclm.claim_id --33216417                  --recsumclm.claim_id
                                                                       AND h.claim_id =
                                                                              d.claim_id
                                                                       AND h.sf_no =
                                                                              d.sf_no
                                                                       --                                                           AND d.institute_code =
                                                                       --                                                                  1757
                                                                       AND h.add_order_no =
                                                                              d.add_order_no
                                                                       AND a.sf_total_type IN
                                                                              ('11', '12')
                                                                       AND b.claim_id =
                                                                              d.claim_id
                                                                       AND b.sf_no =
                                                                              d.sf_no
                                                                       AND b.add_order_no =
                                                                              d.add_order_no
                                                                       AND b.payment_approved_date
                                                                              IS NULL
                                                              GROUP BY d.claim_id,
                                                                       provision_date,
                                                                       d.sf_no,
                                                                       d.add_order_no,
                                                                       d.date_of_loss,
                                                                       h.cover_code,
                                                                       h.location_code,
                                                                       h.exemption_rate,
                                                                       d.institute_code) prv,
                                                             koc_clm_medicine_indem_det cmed
                                                       WHERE     prv.claim_id =
                                                                    cmed.claim_id(+)
                                                             AND prv.sf_no =
                                                                    cmed.sf_no(+)
                                                             AND prv.add_order_no =
                                                                    cmed.add_order_no(+)
                                                             AND prv.location_code =
                                                                    cmed.location_code(+)
                                                             AND prv.cover_code =
                                                                    cmed.cover_code(+)
                                                             AND cmed.status_code(+) =
                                                                    'P') cbprv,
                                                     koc_cc_medicines med
                                               WHERE cbprv.barcode = med.barcode(+)) mcbprv
                                       WHERE mcbprv.validity_date =
                                                NVL (
                                                   (SELECT MAX (g1.validity_date)
                                                      FROM koc_cc_medicines g1
                                                     WHERE     mcbprv.barcode =
                                                                  g1.barcode(+)
                                                           AND TRUNC (
                                                                  mcbprv.provision_Date) >
                                                                  g1.validity_date(+)),
                                                   TO_DATE ('01.01.1900', 'dd.mm.yyyy')));
                                EXCEPTION
                              WHEN OTHERS
                              THEN
                                 raise_application_error (
                                    -20200,
                                    'Kalem e �zel iskonto bulurken hata: ' || SQLERRM);
                           END; --MYALINKILIC-TYH-56664:Ezcanelere �zel �la� iskontosu hesaplayan sorgu
                        END IF;
            */

            --'�skonto hizmet katk� pay�'

            IF NVL (v_provision_discount, 0) > 0
            THEN
               INSERT INTO koc_clm_hlth_inst_trans (institute_code,
                                                    trans_date,
                                                    trans_type,
                                                    firm,
                                                    trans_no,
                                                    order_no,
                                                    trans_amount,
                                                    pay_year,
                                                    pay_month,
                                                    userid,
                                                    entry_date,
                                                    payment_group_code,
                                                    explanation,
                                                    claim_id,
                                                    sf_no,
                                                    add_order_no,
                                                    CONFIRMATION_DATE,
                                                    PAYMENT_DATE -- mustafaku kenanp TSS 05032015
                                                                )
                    VALUES (recsumclm.institute_code,
                            p_payment_term,
                            2,
                            0,
                            v_trans_no,
                            p_order_no,
                            v_provision_discount,
                            TO_CHAR (p_payment_term, 'YYYY'),
                            TO_CHAR (p_payment_term, 'MM'),
                            p_user_id,
                            SYSDATE,
                            p_payment_group,
                            v_exp,
                            recsumclm.claim_id,
                            recsumclm.sf_no,
                            recsumclm.add_order_no,
                            p_end_date,
                            p_payment_date    -- mustafaku kenanp TSS 05032015
                                          );
            END IF;

            v_exp := '�skonto hizmet katk� pay�';

            IF NVL (v_provision_discount, 0) < 0
            THEN
               INSERT INTO koc_clm_hlth_inst_trans (institute_code,
                                                    trans_date,
                                                    trans_type,
                                                    firm,
                                                    trans_no,
                                                    order_no,
                                                    trans_amount,
                                                    pay_year,
                                                    pay_month,
                                                    userid,
                                                    entry_date,
                                                    payment_group_code,
                                                    explanation,
                                                    claim_id,
                                                    sf_no,
                                                    add_order_no,
                                                    CONFIRMATION_DATE,
                                                    PAYMENT_DATE -- mustafaku kenanp TSS 05032015
                                                                )
                    VALUES (recsumclm.institute_code,
                            p_payment_term,
                            11,
                            0,
                            v_trans_no,
                            p_order_no,
                            ABS (v_provision_discount),
                            TO_CHAR (p_payment_term, 'YYYY'),
                            TO_CHAR (p_payment_term, 'MM'),
                            p_user_id,
                            SYSDATE,
                            p_payment_group,
                            v_exp,
                            recsumclm.claim_id,
                            recsumclm.sf_no,
                            recsumclm.add_order_no,
                            p_end_date,
                            p_payment_date    -- mustafaku kenanp TSS 05032015
                                          );
            END IF;

            ------ 2. SERVICE VALUE_RATE-----
            v_provision_discount := recsumclm.isk_2;
            v_exp := '�skonto hizmet katk� pay�(2)';

            IF NVL (v_provision_discount, 0) > 0
            THEN
               INSERT INTO koc_clm_hlth_inst_trans (institute_code,
                                                    trans_date,
                                                    trans_type,
                                                    firm,
                                                    trans_no,
                                                    order_no,
                                                    trans_amount,
                                                    pay_year,
                                                    pay_month,
                                                    userid,
                                                    entry_date,
                                                    payment_group_code,
                                                    explanation,
                                                    claim_id,
                                                    sf_no,
                                                    add_order_no,
                                                    CONFIRMATION_DATE,
                                                    PAYMENT_DATE -- mustafaku kenanp TSS 05032015
                                                                )
                    VALUES (recsumclm.institute_code,
                            p_payment_term,
                            33,
                            0,
                            v_trans_no,
                            p_order_no,
                            v_provision_discount,
                            TO_CHAR (p_payment_term, 'YYYY'),
                            TO_CHAR (p_payment_term, 'MM'),
                            p_user_id,
                            SYSDATE,
                            p_payment_group,
                            v_exp,
                            recsumclm.claim_id,
                            recsumclm.sf_no,
                            recsumclm.add_order_no,
                            p_end_date,
                            p_payment_date    -- mustafaku kenanp TSS 05032015
                                          );
            END IF;

            IF NVL (v_provision_discount, 0) < 0
            THEN
               INSERT INTO koc_clm_hlth_inst_trans (institute_code,
                                                    trans_date,
                                                    trans_type,
                                                    firm,
                                                    trans_no,
                                                    order_no,
                                                    trans_amount,
                                                    pay_year,
                                                    pay_month,
                                                    userid,
                                                    entry_date,
                                                    payment_group_code,
                                                    explanation,
                                                    claim_id,
                                                    sf_no,
                                                    add_order_no,
                                                    CONFIRMATION_DATE,
                                                    PAYMENT_DATE -- mustafaku kenanp TSS 05032015
                                                                )
                    VALUES (recsumclm.institute_code,
                            p_payment_term,
                            34,
                            0,
                            v_trans_no,
                            p_order_no,
                            ABS (v_provision_discount),
                            TO_CHAR (p_payment_term, 'YYYY'),
                            TO_CHAR (p_payment_term, 'MM'),
                            p_user_id,
                            SYSDATE,
                            p_payment_group,
                            v_exp,
                            recsumclm.claim_id,
                            recsumclm.sf_no,
                            recsumclm.add_order_no,
                            p_end_date,
                            p_payment_date    -- mustafaku kenanp TSS 05032015
                                          );
            END IF;
         END LOOP;

         CLOSE cursumclm;

         --------------



         OPEN curcntclm;

         LOOP
            FETCH curcntclm INTO reccnt;

            EXIT WHEN curcntclm%NOTFOUND;
            v_exp :=
               SUBSTR (
                     reccnt.adet
                  || ' * '
                  || reccnt.price * reccnt.rate
                  || ' '
                  || reccnt.cover_cat_group,
                  1,
                  100);

            SELECT NVL (MAX (trans_no), 0) + 1
              INTO v_trans_no
              FROM koc_clm_hlth_inst_trans
             WHERE     institute_code = reccnt.institute_code
                   AND trans_date = p_payment_term
                   AND trans_type IN (3, 10);

            --AND order_no = p_order_no;

            v_exp :=
               SUBSTR (
                     '('
                  || reccnt.institute_code
                  || ') '
                  || v_exp
                  || ' ('
                  || TO_CHAR (p_start_date, 'dd/mm/yyyy')
                  || ' '
                  || TO_CHAR (p_end_date, 'dd/mm/yyyy')
                  || ')',
                  1,
                  100);

            IF reccnt.sf_total_type = '11'
            THEN
               v_exp := 'Anla�mal� Kurum Teknoloji Destek Bedeli'; -- 169903 nolu task

               INSERT INTO koc_clm_hlth_inst_trans (institute_code,
                                                    trans_date,
                                                    trans_type,
                                                    firm,
                                                    trans_no,
                                                    order_no,
                                                    trans_amount,
                                                    pay_year,
                                                    claim_id,
                                                    sf_no,
                                                    add_order_no,
                                                    pay_month,
                                                    userid,
                                                    entry_date,
                                                    payment_group_code,
                                                    explanation)
                    VALUES (reccnt.institute_code,
                            p_payment_term,
                            3,
                            '0',
                            v_trans_no,
                            p_order_no,
                            reccnt.provision_fee,
                            TO_CHAR (p_payment_term, 'YYYY'),
                            reccnt.claim_id,
                            reccnt.sf_no,
                            reccnt.add_order_no,
                            TO_CHAR (p_payment_term, 'MM'),
                            p_user_id,
                            SYSDATE,
                            p_payment_group,
                            v_exp);
            ELSIF reccnt.sf_total_type = '12'
            THEN
               INSERT INTO koc_clm_hlth_inst_trans (institute_code,
                                                    trans_date,
                                                    trans_type,
                                                    firm,
                                                    trans_no,
                                                    order_no,
                                                    trans_amount,
                                                    pay_year,
                                                    pay_month,
                                                    claim_id,
                                                    sf_no,
                                                    add_order_no,
                                                    userid,
                                                    entry_date,
                                                    payment_group_code,
                                                    explanation)
                    VALUES (reccnt.institute_code,
                            p_payment_term,
                            10,
                            '0',
                            v_trans_no,
                            p_order_no,
                            ABS (reccnt.provision_fee),
                            TO_CHAR (p_payment_term, 'YYYY'),
                            TO_CHAR (p_payment_term, 'MM'),
                            reccnt.claim_id,
                            reccnt.sf_no,
                            reccnt.add_order_no,
                            p_user_id,
                            SYSDATE,
                            p_payment_group,
                            v_exp);
            END IF;
         END LOOP;

         CLOSE curcntclm;
      END IF;

      --
      UPDATE koc_clm_hlth_inst_trans
         SET order_no = p_order_no
       WHERE     approve_date IS NULL
             AND trans_type NOT IN (1, 2, 3, 21, 11, 33, 34)
             AND pay_year = TO_NUMBER (TO_CHAR (p_payment_term, 'YYYY'))
             AND pay_month = TO_NUMBER (TO_CHAR (p_payment_term, 'MM'))
             AND payment_group_code = p_payment_group
             AND institute_code =
                    DECODE (p_institute_code,
                            NULL, institute_code,
                            p_institute_code)
             AND (   (    p_payment_date IS NOT NULL
                      AND payment_date = p_payment_date)
                  OR p_payment_date IS NULL);  --mustafaku kenanp TSS 05032015

      UPDATE koc_clm_trans_ext
         SET technical_approved_date = p_payment_term,
             pay_order_no = p_order_no
       WHERE ROWID IN
                (SELECT b.ROWID
                   FROM clm_trans a,
                        koc_clm_trans_ext b,
                        koc_clm_suppliers_ext c
                  WHERE     a.claim_id = b.claim_id
                        AND a.sf_no = b.sf_no
                        AND a.trans_no = b.trans_no
                        AND a.supp_id = c.supp_id
                        AND b.payment_type = '7'
                        --AND c.payment_group_code = p_payment_group  mustafaku kenanp TSS 05032015
                        AND (   (    c.payment_group_code = p_payment_group
                                 AND p_payment_group NOT LIKE 'T%')
                             OR (    c.tss_payment_group_code =
                                        p_payment_group
                                 AND p_payment_group LIKE 'T%')) --mustafaku kenanp TSS 05032015
                        AND c.institute_code =
                               DECODE (p_institute_code,
                                       NULL, c.institute_code,
                                       p_institute_code)
                        AND b.ticket_date >= p_start_date
                        AND b.ticket_date <= p_end_date
                        AND (ticket_no >= 0 OR ticket_no IS NULL)
                        AND a.sf_total_type IN ('11', '12')
                        AND b.payment_approved_date IS NULL);
   END;

   ---------
   PROCEDURE approveinstrans (p_payment_group_code    VARCHAR2,
                              p_institute_code        NUMBER,
                              p_payment_date          DATE,
                              p_user_id               VARCHAR2)
   IS
      CURSOR cur
      IS
           SELECT institute_code,
                  pay_year,
                  pay_month,
                  payment_group_code,
                  approve_date,
                  order_no,
                  SUM (DECODE (b.SIGN, 1, trans_amount, 0)) credit,
                  SUM (DECODE (b.SIGN, -1, trans_amount, 0)) debit,
                  SUM (b.SIGN * trans_amount) remaning
             FROM koc_clm_hlth_inst_trans a, koc_cc_inst_trans_ref b
            WHERE     a.trans_type = b.trans_type
                  AND batch_id IS NOT NULL
                  AND a.payment_group_code = p_payment_group_code
                  AND TO_DATE (LPAD (a.pay_month, 2, '0') || a.pay_year,
                               'mmyyyy') <= p_payment_date
                  AND a.institute_code = p_institute_code
                  AND a.approve_date IS NULL
                  AND a.firm = '0'
                  AND a.trans_type NOT IN (18, 28, 31, 32)
         -- and order_no = p_order_no
         GROUP BY institute_code,
                  pay_year,
                  pay_month,
                  payment_group_code,
                  approve_date,
                  order_no;

      rec                  cur%ROWTYPE;
      v_confirm_date       DATE;
      v_min_payment_date   DATE;
      v_min_confirm_date   DATE;
      v_min_date           DATE;
      v_approve_date       DATE;
      v_inst_ext_id        NUMBER;                       --Mukerrer task� i�in
   BEGIN
      v_approve_date := TRUNC (SYSDATE);

      --      IF v_approve_date < p_payment_date
      --      THEN
      --         v_approve_date := p_payment_date;
      --      END IF;--Mukerrer task� i�in comment'e al�nacak

      OPEN cur;

      LOOP
         FETCH cur INTO rec;

         EXIT WHEN cur%NOTFOUND;

         INSERT INTO koc_clm_month_confirm_rem (institute_code,
                                                YEAR,
                                                MONTH,
                                                firm,
                                                order_no,
                                                approve_date,
                                                userid,
                                                entry_date,
                                                payment_group_code,
                                                payment_amount)
              VALUES (p_institute_code,
                      rec.pay_year,
                      rec.pay_month,
                      0,
                      rec.order_no,
                      v_approve_date,
                      p_user_id,
                      SYSDATE,
                      p_payment_group_code,
                      rec.remaning);
      END LOOP;

      CLOSE cur;

      UPDATE koc_clm_hlth_inst_trans
         SET approve_date = v_approve_date, approve_user = USER
       WHERE     payment_group_code = p_payment_group_code
             AND TO_DATE (LPAD (pay_month, 2, '0') || pay_year, 'mmyyyy') <=
                    p_payment_date
             AND institute_code = p_institute_code
             AND trans_type NOT IN (31, 32)
             AND approve_date IS NULL;

      IF p_payment_group_code != '99'
      THEN
         SELECT MIN (TO_DATE (LPAD (MONTH, 2, '0') || YEAR, 'mmyyyy'))
           INTO v_min_payment_date
           FROM koc_clm_month_confirm_rem
          WHERE     payment_group_code = p_payment_group_code
                AND TO_DATE (LPAD (MONTH, 2, '0') || YEAR, 'mmyyyy') <=
                       p_payment_date
                AND institute_code = p_institute_code
                AND approve_date = v_approve_date;          --TRUNC (SYSDATE);

         SELECT MAX (confirmation_date)
           INTO v_confirm_date
           FROM koc_cc_month_confirm_dates
          WHERE     payment_group_code = p_payment_group_code
                AND payment_date = p_payment_date;

         SELECT MAX (confirmation_date)
           INTO v_min_confirm_date
           FROM koc_cc_month_confirm_dates
          WHERE     payment_group_code = p_payment_group_code
                AND TO_CHAR (payment_date, 'YYYY') =
                       TO_CHAR (v_min_payment_date, 'YYYY')
                AND TO_CHAR (payment_date, 'mm') =
                       TO_CHAR (v_min_payment_date, 'mm');

         koc_clm_hlth_utils.getprvconfirmdate (p_payment_group_code,
                                               v_min_confirm_date,
                                               v_min_date);
         v_min_date := v_min_date + 1;
      ELSE
         SELECT MIN (ticket_date), MAX (ticket_date)
           INTO v_min_date, v_confirm_date
           FROM clm_trans a, koc_clm_trans_ext b
          WHERE     b.institute_code = p_institute_code
                AND a.claim_id = b.claim_id
                AND a.sf_no = b.sf_no
                AND a.trans_no = b.trans_no
                AND a.sf_total_type IN ('11', '12')
                AND b.payment_type = '7'
                AND b.technical_approved_date IS NOT NULL
                AND b.payment_approved_date IS NULL;
      END IF;

      BEGIN
         v_inst_ext_id := NULL;

         SELECT MIN (inst_ext_id)
           INTO v_inst_ext_id
           FROM koc_clm_hlth_inst_trans
          WHERE     payment_group_code = p_payment_group_code
                AND TO_DATE (LPAD (pay_month, 2, '0') || pay_year, 'mmyyyy') <=
                       p_payment_date
                AND institute_code = p_institute_code
                AND trans_type NOT IN (31, 32)
                AND approve_date = v_approve_date
                AND inst_ext_id IS NOT NULL;

         UPDATE koc_clm_trans_ext
            SET payment_approved_date = v_approve_date
          WHERE inst_ext_id = v_inst_ext_id;
      EXCEPTION
         WHEN OTHERS
         THEN
            NULL;
      END;                                               --Mukerrer task� i�in

      BEGIN
         UPDATE koc_clm_trans_ext b
            SET payment_approved_date = v_approve_date
          WHERE ROWID IN
                   (SELECT b.ROWID
                      FROM koc_clm_trans_ext b, clm_trans a
                     WHERE     a.claim_id = b.claim_id
                           AND a.sf_no = b.sf_no
                           AND a.trans_no = b.trans_no
                           AND a.sf_total_type IN ('11', '12')
                           AND b.institute_code =
                                  DECODE (p_institute_code,
                                          NULL, b.institute_code,
                                          p_institute_code)
                           AND b.ticket_date >= v_min_date
                           AND b.ticket_date <= v_confirm_date
                           AND b.payment_type = '7'
                           AND b.technical_approved_date IS NOT NULL
                           AND b.payment_approved_date IS NULL
                           AND inst_ext_id IS NULL       --Mukerrer task� i�in
                                                  );
      EXCEPTION
         WHEN OTHERS
         THEN
            NULL;
      END;
   END;

   PROCEDURE insertinsttrans (p_institute_code       NUMBER,
                              p_trans_date           DATE,
                              p_trans_amount         NUMBER,
                              p_trans_type           NUMBER,
                              p_claim_id             NUMBER,
                              p_sf_no                NUMBER,
                              p_add_order_no         NUMBER,
                              p_reverse              VARCHAR2,
                              p_trans_no             NUMBER,
                              p_exp                  VARCHAR2,
                              p_account_no           VARCHAR2,
                              p_acc_date             DATE,
                              p_order_no             NUMBER,
                              p_batch_id         OUT NUMBER)
   IS
      vv_trans_no            NUMBER;
      vv_trans_type          NUMBER;
      v_pay_year             NUMBER;
      v_pay_month            NUMBER;
      v_payment_date         DATE;
      v_payment_group_code   VARCHAR2 (4);
      v_is_approved          NUMBER;
      v_confirm_date         DATE;
      v_insert               NUMBER;
      v_batch_id             NUMBER;
      v_sign                 NUMBER;
      v_trans_group          VARCHAR2 (50);
      v_reverse_batch_id     NUMBER;
      v_old_batch_id         NUMBER;
      v_del_batch_id         NUMBER;
      v_max_order_no         NUMBER;
      v_stoppage_amount      NUMBER;            --cozbay task132695 08.02.2012
      v_stp_eksi_amnt        NUMBER;            --cozbay task132695 08.02.2012
      v_invoice_date         DATE;              --cozbay task132695 08.02.2012
      v_date_of_loss         DATE;              --cozbay task132695 08.02.2012
      v_is_complementary     NUMBER;           --mustafaku kpamuk TSS 12032015


      --cozbay task132695 08.02.2012
      CURSOR cur_detail (
         pclaim_id       IN NUMBER,
         psf_no          IN NUMBER,
         padd_order_no   IN NUMBER)
      IS
         SELECT invoice_date,
                date_of_loss,
                NVL (is_complementary, 0) is_complementary --mustafaku kpamuk TSS 12032015 is_comp.
           FROM koc_clm_hlth_detail
          WHERE     claim_id = pclaim_id
                AND sf_no = psf_no
                AND add_order_no = padd_order_no;
   BEGIN
      v_insert := 1;

      ----cozbay task132695 08.02.2012  invoice_date ve date_of_loss bul
      OPEN cur_detail (p_claim_id, p_sf_no, p_add_order_no);

      FETCH cur_detail
      INTO v_invoice_date, v_date_of_loss, v_is_complementary; --mustafaku kpamuk TSS 12032015 is_comp.

      CLOSE cur_detail;

      SELECT DECODE (v_is_complementary,
                     1, tss_payment_group_code,
                     payment_group_code) --mustafaku kpamuk TSS 12032015 tss_payment_group
        INTO v_payment_group_code
        FROM koc_clm_suppliers_ext
       WHERE institute_code = p_institute_code;

      IF NVL (v_payment_group_code, '99') != '99'
      THEN
         --
         IF v_payment_group_code NOT LIKE 'T%' --mustafaku kpamuk TSS 12032015  if blo�u
         THEN
            koc_clm_hlth_utils.getnextpaymentdate (p_trans_date,
                                                   v_payment_group_code,
                                                   v_confirm_date,
                                                   v_payment_date);
         ELSE
            BEGIN                              --mustafaku kpamuk TSS 12032015
               SELECT MIN (confirmation_date) confirmation_date,
                      MIN (payment_date) payment_date
                 INTO v_confirm_date, v_payment_date
                 FROM koc_cc_month_confirm_dates
                WHERE     confirmation_date >= p_trans_date --p_acc_date  mustafaku otuzunturk tss
                      AND payment_group_code = v_payment_group_code;
            EXCEPTION
               WHEN OTHERS
               THEN
                  v_confirm_date := NULL;
                  v_payment_date := NULL;
            END;                               --mustafaku kpamuk TSS 12032015
         END IF;

         --
         v_is_approved := 0;

         SELECT DECODE (COUNT (*), 0, 0, 1)
           INTO v_is_approved
           FROM koc_clm_month_confirm_rem
          WHERE     YEAR = TO_NUMBER (TO_CHAR (v_payment_date, 'YYYY'))
                AND MONTH = TO_NUMBER (TO_CHAR (v_payment_date, 'MM'))
                AND firm = '0'
                AND institute_code = p_institute_code
                AND payment_group_code = v_payment_group_code; --mustafaku kpamuk TSS 12032015

         IF v_is_approved > 0
         THEN
            SELECT MIN (payment_date)
              INTO v_payment_date
              FROM koc_cc_month_confirm_dates a
             WHERE     payment_group_code = v_payment_group_code
                   AND payment_date > v_payment_date
                   AND payment_group_code = v_payment_group_code --mustafaku kpamuk TSS 12032015
                   AND NOT EXISTS
                              (SELECT 'X'
                                 FROM koc_clm_month_confirm_rem
                                WHERE     YEAR =
                                             TO_NUMBER (
                                                TO_CHAR (a.payment_date,
                                                         'YYYY'))
                                      AND MONTH =
                                             TO_NUMBER (
                                                TO_CHAR (a.payment_date,
                                                         'MM'))
                                      AND institute_code = p_institute_code
                                      AND order_no = 1
                                      AND payment_group_code =
                                             v_payment_group_code --mustafaku kpamuk TSS 12032015
                                                                 );
         END IF;
      ELSE                                          -- payment_group_code = 99
         v_payment_date := p_trans_date;
      END IF;

      v_pay_year := TO_NUMBER (TO_CHAR (v_payment_date, 'YYYY'));
      v_pay_month := TO_NUMBER (TO_CHAR (v_payment_date, 'MM'));
      vv_trans_type := p_trans_type;

      IF p_reverse = 'R'
      THEN
         SELECT reverse_trans_type
           INTO vv_trans_type
           FROM koc_cc_inst_trans_ref
          WHERE trans_type = p_trans_type;



         DELETE FROM koc_clm_hlth_inst_trans
               WHERE     institute_code = p_institute_code
                     AND trans_date = p_trans_date
                     AND trans_type = p_trans_type
                     AND trans_no = p_trans_no
                     AND batch_id IS NULL
                     AND order_no = p_order_no;

         IF SQL%ROWCOUNT = 0
         THEN --INSTITUTE_CODE, TRANS_DATE, TRANS_TYPE, FIRM, TRANS_NO, ORDER_NO
            UPDATE koc_clm_hlth_inst_trans
               SET reverse_flag = 'R'
             WHERE     institute_code = p_institute_code
                   AND trans_date = p_trans_date
                   AND trans_type = p_trans_type
                   AND trans_no = p_trans_no
                   AND order_no = p_order_no;
         ELSE
            v_insert := 0;
         END IF;
      END IF;

      IF v_insert = 1
      THEN
         SELECT (NVL (MAX (order_no), 0) + 1) v_max
           INTO v_max_order_no
           FROM koc_clm_hlth_inst_trans
          WHERE     pay_year = v_pay_year
                AND pay_month = v_pay_month
                AND approve_date IS NOT NULL
                AND payment_group_code = v_payment_group_code
                AND institute_code = p_institute_code;


         SELECT NVL (MAX (trans_no), 0) + 1
           INTO vv_trans_no
           FROM koc_clm_hlth_inst_trans
          WHERE     institute_code = p_institute_code
                AND trans_date = p_trans_date
                AND trans_type = vv_trans_type;

         --AND order_no = v_max_order_no;--kora06 pk ya d��me sorunu oldu�undan kald�r�ld�. 30/01/2012



         --cozbay task132695 08.02.2012  stopaj eklendi sadece tahakkukta calissin
         IF p_trans_type = 1
         THEN
            v_stoppage_amount :=
               koc_clm_hlth_trnx2.getstoppageamount (p_trans_amount,
                                                     p_institute_code,
                                                     v_invoice_date,
                                                     v_date_of_loss);
            v_stp_eksi_amnt := p_trans_amount - v_stoppage_amount;
         ELSE
            v_stoppage_amount := NULL;
            v_stp_eksi_amnt := p_trans_amount;
         END IF;

         --



         INSERT INTO koc_clm_hlth_inst_trans (institute_code,
                                              trans_type,
                                              trans_date,
                                              trans_amount,
                                              trans_no,
                                              order_no,
                                              firm,
                                              pay_year,
                                              pay_month,
                                              payment_group_code,
                                              entry_date,
                                              userid,
                                              claim_id,
                                              sf_no,
                                              add_order_no,
                                              reverse_flag,
                                              explanation,
                                              account_no,
                                              stoppage_amount,
                                              CONFIRMATION_DATE,
                                              PAYMENT_DATE --mustafaku kpamuk TSS 12032015
                                                          )
              VALUES (p_institute_code,
                      vv_trans_type,
                      p_trans_date,
                      v_stp_eksi_amnt                       /*p_trans_amount*/
                                     ,
                      vv_trans_no,
                      v_max_order_no,
                      0,
                      v_pay_year,
                      v_pay_month,
                      v_payment_group_code,
                      SYSDATE,
                      USER,
                      p_claim_id,
                      p_sf_no,
                      p_add_order_no,
                      p_reverse,
                      p_exp,
                      p_account_no,
                      v_stoppage_amount,
                      v_confirm_date,
                      v_payment_date           --mustafaku kpamuk TSS 12032015
                                    );


         IF vv_trans_type = 28
         THEN
            SELECT batch_id
              INTO v_del_batch_id
              FROM koc_clm_hlth_inst_trans
             WHERE     institute_code = p_institute_code
                   AND trans_date = p_trans_date
                   AND trans_type = p_trans_type
                   AND trans_no = p_trans_no
                   AND order_no = p_order_no
                   AND reverse_flag = 'R';

            FOR rec
               IN (SELECT a.approve_date,
                          a.order_no,
                          a.institute_code,
                          a.payment_date
                     FROM koc_clm_month_confirm_rem a
                    WHERE     a.institute_code = p_institute_code
                          AND a.pay_batch_id = v_del_batch_id)
            LOOP
               UPDATE koc_clm_hlth_inst_trans
                  SET approve_date = NULL, approve_user = NULL
                WHERE     institute_code = rec.institute_code
                      AND trans_type NOT IN (31, 32)
                      AND approve_date = rec.approve_date
                      AND order_no = rec.order_no
                      AND TO_DATE (LPAD (pay_month, 2, '0') || pay_year,
                                   'mmyyyy') <= rec.payment_date;

               UPDATE koc_clm_trans_ext b
                  SET payment_approved_date = NULL
                WHERE ROWID IN
                         (SELECT b.ROWID
                            FROM koc_clm_trans_ext b, clm_trans a
                           WHERE     a.claim_id = b.claim_id
                                 AND a.sf_no = b.sf_no
                                 AND a.trans_no = b.trans_no
                                 AND a.sf_total_type IN ('11', '12')
                                 AND b.institute_code = rec.institute_code
                                 --                   AND b.ticket_date >= v_min_date
                                 --                 AND b.ticket_date <= v_confirm_date
                                 AND b.payment_type = '7'
                                 AND b.technical_approved_date IS NOT NULL
                                 AND b.payment_approved_date =
                                        rec.payment_date
                                 AND pay_order_no = rec.order_no);
            END LOOP;

            DELETE FROM koc_clm_month_confirm_rem a
                  WHERE     a.institute_code = p_institute_code
                        AND a.pay_batch_id = v_del_batch_id;
         END IF;
      END IF;

      IF p_acc_date IS NOT NULL
      THEN
         SELECT a.SIGN, a.trans_group
           INTO v_sign, v_trans_group
           FROM koc_cc_inst_trans_ref a
          WHERE trans_type = vv_trans_type;

         doinsttransaccbytype (p_trans_date,
                               p_trans_date,
                               vv_trans_type,
                               v_trans_group,
                               v_payment_group_code,
                               p_institute_code,
                               1,
                               v_pay_month,
                               v_pay_year,
                               p_acc_date,
                               v_batch_id);
         p_batch_id := v_batch_id;
      END IF;
   END;

   PROCEDURE clmtechapproved (p_claim_id        NUMBER,
                              p_sf_no           NUMBER,
                              p_add_order_no    NUMBER)
   IS
   BEGIN
      UPDATE koc_clm_trans_ext a
         SET technical_approved_date = TRUNC (SYSDATE)
       WHERE     claim_id = p_claim_id
             AND sf_no = p_sf_no
             AND add_order_no = p_add_order_no
             AND technical_approved_date IS NULL
             AND payment_type NOT IN ('7')
             AND trans_no IN
                    (SELECT x.trans_no
                       FROM koc_clm_trans_ext x, clm_trans y
                      WHERE     x.claim_id = y.claim_id
                            AND x.sf_no = y.sf_no
                            AND y.trans_no = y.trans_no
                            AND x.claim_id = a.claim_id
                            AND x.sf_no = a.sf_no
                            AND x.add_order_no = a.add_order_no
                            AND y.sf_total_type IN ('11'))
             AND trans_no IN
                    (  SELECT MAX (x.trans_no)
                         FROM koc_clm_trans_ext x, clm_trans y
                        WHERE     x.claim_id = y.claim_id
                              AND x.sf_no = y.sf_no
                              AND y.trans_no = y.trans_no
                              AND x.claim_id = a.claim_id
                              AND x.sf_no = a.sf_no
                              AND x.add_order_no = a.add_order_no
                              AND y.sf_total_type IN ('11', '12')
                     GROUP BY x.hlth_cover_code);
   END;

   PROCEDURE clmpaymentapproved (p_claim_id        NUMBER,
                                 p_sf_no           NUMBER,
                                 p_add_order_no    NUMBER,
                                 p_onayiptal       NUMBER)
   IS
      v_sysdate   DATE := TRUNC (SYSDATE);
   BEGIN
      UPDATE koc_clm_trans_ext a
         SET payment_approved_date = v_sysdate
       WHERE     claim_id = p_claim_id
             AND sf_no = p_sf_no
             AND add_order_no = p_add_order_no
             AND technical_approved_date IS NOT NULL
             AND payment_approved_date IS NULL
             AND payment_type NOT IN ('7')
             AND (   (project_code IS NULL AND p_onayiptal = 1)
                  OR NVL (p_onayiptal, 0) = 0)
             AND trans_no IN
                    (SELECT x.trans_no
                       FROM koc_clm_trans_ext x, clm_trans y
                      WHERE     x.claim_id = y.claim_id
                            AND x.sf_no = y.sf_no
                            AND y.trans_no = y.trans_no
                            AND x.claim_id = a.claim_id
                            AND x.sf_no = a.sf_no
                            AND x.add_order_no = a.add_order_no
                            AND y.sf_total_type IN ('11'))
             AND trans_no IN
                    (  SELECT MAX (x.trans_no)
                         FROM koc_clm_trans_ext x, clm_trans y
                        WHERE     x.claim_id = y.claim_id
                              AND x.sf_no = y.sf_no
                              AND y.trans_no = y.trans_no
                              AND x.claim_id = a.claim_id
                              AND x.sf_no = a.sf_no
                              AND x.add_order_no = a.add_order_no
                              AND y.sf_total_type IN ('11', '12')
                     GROUP BY x.hlth_cover_code);
   END;

   PROCEDURE clmtechapprovedcancel (p_claim_id        NUMBER,
                                    p_sf_no           NUMBER,
                                    p_add_order_no    NUMBER)
   IS
   BEGIN
      UPDATE koc_clm_trans_ext a
         SET technical_approved_date = NULL
       WHERE     claim_id = p_claim_id
             AND sf_no = p_sf_no
             AND add_order_no = p_add_order_no
             AND technical_approved_date IS NOT NULL
             AND payment_approved_date IS NULL
             AND payment_type NOT IN ('7')
             AND trans_no IN
                    (SELECT x.trans_no
                       FROM koc_clm_trans_ext x, clm_trans y
                      WHERE     x.claim_id = y.claim_id
                            AND x.sf_no = y.sf_no
                            AND y.trans_no = y.trans_no
                            AND x.claim_id = a.claim_id
                            AND x.sf_no = a.sf_no
                            AND x.add_order_no = a.add_order_no
                            AND y.sf_total_type IN ('11'))
             AND trans_no IN
                    (  SELECT MAX (x.trans_no)
                         FROM koc_clm_trans_ext x, clm_trans y
                        WHERE     x.claim_id = y.claim_id
                              AND x.sf_no = y.sf_no
                              AND y.trans_no = y.trans_no
                              AND x.claim_id = a.claim_id
                              AND x.sf_no = a.sf_no
                              AND x.add_order_no = a.add_order_no
                              AND y.sf_total_type IN ('11', '12')
                     GROUP BY x.hlth_cover_code);
   END;

   PROCEDURE clmpaymentapprovedcancel (p_claim_id        NUMBER,
                                       p_sf_no           NUMBER,
                                       p_add_order_no    NUMBER)
   IS
   BEGIN
      UPDATE koc_clm_trans_ext a
         SET payment_approved_date = NULL, technical_approved_date = NULL
       WHERE     claim_id = p_claim_id
             AND sf_no = p_sf_no
             AND add_order_no = p_add_order_no
             AND payment_approved_date IS NOT NULL
             AND payment_type NOT IN (7)
             AND transfer_bank_date IS NULL
             AND trans_no IN
                    (SELECT x.trans_no
                       FROM koc_clm_trans_ext x, clm_trans y
                      WHERE     x.claim_id = y.claim_id
                            AND x.sf_no = y.sf_no
                            AND y.trans_no = y.trans_no
                            AND x.claim_id = a.claim_id
                            AND x.sf_no = a.sf_no
                            AND x.add_order_no = a.add_order_no
                            AND y.sf_total_type IN (11))
             AND trans_no IN
                    (  SELECT MAX (x.trans_no)
                         FROM koc_clm_trans_ext x, clm_trans y
                        WHERE     x.claim_id = y.claim_id
                              AND x.sf_no = y.sf_no
                              AND y.trans_no = y.trans_no
                              AND x.claim_id = a.claim_id
                              AND x.sf_no = a.sf_no
                              AND x.add_order_no = a.add_order_no
                              AND y.sf_total_type IN (11, 12)
                     GROUP BY x.hlth_cover_code);

      Customer.Alz_Hlth_Cpa.Insertinvoicehistory (
         p_Claim_Id,
         p_Sf_No,
         p_Add_Order_No,
         '-',
         'KES�N ONAY IPTAL�-�DEME');
   END;

   FUNCTION lastapproveddate (p_institute_code NUMBER)
      RETURN DATE
   IS
      v_max_confirm_date     DATE;
      v_max_payment_date     DATE;
      v_payment_group_code   VARCHAR2 (10);
   BEGIN
      SELECT MAX (TO_DATE (LPAD (MONTH, 2, '0') || YEAR, 'mmyyyy'))
        INTO v_max_payment_date
        FROM koc_clm_month_confirm_rem
       WHERE institute_code = p_institute_code;

      SELECT payment_group_code
        INTO v_payment_group_code
        FROM (SELECT DISTINCT payment_group_code
                FROM koc_clm_month_confirm_rem
               WHERE     institute_code = p_institute_code
                     AND MONTH = TO_CHAR (v_max_payment_date, 'mm')
                     AND YEAR = TO_CHAR (v_max_payment_date, 'yyyy'));

      SELECT MAX (confirmation_date)
        INTO v_max_confirm_date
        FROM koc_cc_month_confirm_dates
       WHERE     payment_group_code = v_payment_group_code
             AND TO_CHAR (payment_date, 'YYYY') =
                    TO_CHAR (v_max_payment_date, 'YYYY')
             AND TO_CHAR (payment_date, 'mm') =
                    TO_CHAR (v_max_payment_date, 'mm');

      RETURN (v_max_confirm_date);
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN (TO_DATE ('01/01/1980', 'dd/mm/yyyy'));
   END;

   FUNCTION isclmapproved (p_claim_id        NUMBER,
                           p_sf_no           NUMBER,
                           p_add_order_no    NUMBER)
      RETURN NUMBER
   IS
      v_result   NUMBER;
   BEGIN
      SELECT DECODE (COUNT (*), 0, 0, 1)
        INTO v_result
        FROM koc_clm_trans_ext a
       WHERE     claim_id = p_claim_id
             AND sf_no = p_sf_no
             AND add_order_no = p_add_order_no
             AND technical_approved_date IS NOT NULL
             AND payment_type != '7';

      RETURN (v_result);
   END;

   FUNCTION getinsttransname (p_trans_type NUMBER)
      RETURN VARCHAR2
   IS
      v_result   VARCHAR2 (200);
   BEGIN
      SELECT description
        INTO v_result
        FROM koc_cc_inst_trans_ref
       WHERE trans_type = p_trans_type;

      RETURN (v_result);
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN (NULL);
   END;

   PROCEDURE updateinsuredbankinfo (p_contract_id              NUMBER,
                                    p_ip_no                    NUMBER,
                                    p_bank_code                NUMBER,
                                    p_subsdiary_code           NUMBER,
                                    p_account_no               VARCHAR2,
                                    p_account_owner            VARCHAR2,
                                    p_indemnity_account_exp    VARCHAR2,
                                    p_date                     DATE,
                                    p_iban_code                VARCHAR2,
                                    p_ACC_OWNER_PARTID         NUMBER)
   IS
      v_start_date      DATE;
      v_end_date        DATE;
      v_identity_no     VARCHAR2 (50);
      v_IBAN_CODE_sgk   VARCHAR2 (34);
   BEGIN
      SELECT IBAN_CODE
        INTO v_IBAN_CODE_sgk
        FROM koc_acc_bank_history
       WHERE contract_id = 1 AND VALIDITY_END_DATE IS NULL;     -- task 191293

      IF v_IBAN_CODE_sgk = p_IBAN_CODE
      THEN
         RETURN;    -- task 191293 sa�l�k servisine �denecekler g�ncellenmesin
      END IF;

      v_end_date := SYSDATE - 1 / 86400;
      v_start_date := SYSDATE;

      UPDATE koc_acc_bank_history
         SET validity_end_date = v_end_date
       WHERE     contract_id = p_contract_id
             AND ip_no = p_ip_no
             AND validity_end_date IS NULL;

      IF (p_ACC_OWNER_PARTID IS NOT NULL)
      THEN
         BEGIN
            SELECT a.IDENTITY_NO
              INTO v_identity_no
              FROM koc_cp_partners_ext a
             WHERE a.PART_ID = p_ACC_OWNER_PARTID;
         EXCEPTION
            WHEN OTHERS
            THEN
               v_identity_no := NULL;
         END;
      END IF;

      IF SQL%NOTFOUND
      THEN
         INSERT INTO koc_acc_bank_history (contract_id,
                                           ip_no,
                                           convert_bank_info_exp,
                                           is_indemn_acc_approved,
                                           validity_start_date,
                                           bank_code,
                                           subsidiary_code,
                                           account_no,
                                           account_owner,
                                           indemnity_account_explanation,
                                           userid,
                                           process_date,
                                           iban_code,
                                           ACC_OWNER_PARTID,
                                           identity_no)
              VALUES (p_contract_id,
                      p_ip_no,
                      NULL,
                      0,
                      v_start_date,
                      p_bank_code,
                      p_subsdiary_code,
                      p_account_no,
                      p_account_owner,
                      p_indemnity_account_exp,
                      USER,
                      SYSDATE,
                      p_iban_code,
                      p_ACC_OWNER_PARTID,
                      v_identity_no);
      ELSE
         INSERT INTO koc_acc_bank_history (contract_id,
                                           ip_no,
                                           convert_bank_info_exp,
                                           is_indemn_acc_approved,
                                           validity_start_date,
                                           bank_code,
                                           subsidiary_code,
                                           account_no,
                                           account_owner,
                                           indemnity_account_explanation,
                                           userid,
                                           process_date,
                                           iban_code,
                                           ACC_OWNER_PARTID,
                                           identity_no)
            SELECT a.contract_id,
                   a.ip_no,
                   a.convert_bank_info_exp,
                   0,
                   v_start_date,
                   p_bank_code,
                   p_subsdiary_code,
                   p_account_no,
                   p_account_owner,
                   p_indemnity_account_exp,
                   USER,
                   SYSDATE,
                   p_iban_code,
                   p_ACC_OWNER_PARTID,
                   v_identity_no
              FROM koc_acc_bank_history a
             WHERE     contract_id = p_contract_id
                   AND ip_no = p_ip_no
                   AND validity_end_date = v_end_date
                   AND ROWNUM < 2;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         NULL;
   END;

   FUNCTION isinstclmpaid (p_statement_no NUMBER)
      RETURN NUMBER
   IS
      v_result   NUMBER;
   BEGIN
      SELECT DECODE (COUNT (*), 0, 0, 1)
        INTO v_result
        FROM koc_clm_hlth_prov_statemnt
       WHERE statement_no = p_statement_no AND status_code = 'ODE';

      RETURN (v_result);
   END;

   PROCEDURE updatefinalclass (p_claim_id                 NUMBER,
                               p_sf_no                    NUMBER,
                               p_add_order_no             NUMBER,
                               p_final_class_disease_1    VARCHAR2,
                               p_final_class_disease_2    VARCHAR2,
                               p_final_class_disease_3    VARCHAR2)
   IS
   BEGIN
      UPDATE koc_clm_hlth_detail
         SET final_class_disease_1 = p_final_class_disease_1,
             final_class_disease_2 = p_final_class_disease_2,
             final_class_disease_3 = p_final_class_disease_3
       WHERE     claim_id = p_claim_id
             AND sf_no = p_sf_no
             AND add_order_no = p_add_order_no;
   END;

   PROCEDURE updateclmtransbank (p_contract_id           NUMBER,
                                 p_partition_no          NUMBER,
                                 p_bank                  NUMBER,
                                 p_branch                NUMBER,
                                 p_accno                 VARCHAR2,
                                 p_acc_owner             VARCHAR2,
                                 p_claim_id              NUMBER,
                                 p_result         IN OUT VARCHAR2,
                                 p_iban_code             VARCHAR2,
                                 p_tc_no                 VARCHAR2,
                                 p_vkn_no                VARCHAR2)
   IS
      CURSOR cur
      IS
         SELECT a.ROWID, a.*, d.ext_reference
           FROM koc_clm_trans_ext a,
                clm_pol_bases b,
                clm_pol_oar c,
                clm_subfiles d,
                clm_trans e
          WHERE     a.claim_id = b.claim_id
                AND a.claim_id = c.claim_id
                AND c.contract_id = p_contract_id
                AND c.oar_no = p_partition_no
                AND a.realization_ticket_date IS NOT NULL
                AND a.payment_approved_date IS NULL
                AND a.ticket_date IS NULL
                AND a.payment_type = '5'
                AND a.claim_id =
                       DECODE (p_claim_id, NULL, a.claim_id, p_claim_id)
                AND a.claim_id = d.claim_id
                AND a.claim_id = e.claim_id
                AND a.trans_no = e.trans_no
                AND a.sf_no = e.sf_no
                AND e.sf_total_type = '11'
                AND a.trans_no =
                       (SELECT MAX (x.trans_no)
                          FROM koc_clm_trans_ext x, clm_trans y
                         WHERE     x.claim_id = y.claim_id
                               AND x.sf_no = y.sf_no
                               AND x.trans_no = y.trans_no
                               AND x.claim_id = a.claim_id
                               AND x.sf_no = a.sf_no
                               AND x.hlth_cover_code = a.hlth_cover_code
                               AND x.add_order_no = a.add_order_no
                               AND y.sf_total_type IN ('11', '12', '10'));

      rec                         cur%ROWTYPE;
      p_bankacc                   KOC_CLM_HLTH_UTILS2.bankacctype;
      v_technical_approved_date   DATE;
      v_cnt                       NUMBER;
      v_IBAN_CODE_sgk             VARCHAR2 (34);
      v_IBAN_CODE                 VARCHAR2 (34);
   BEGIN
      p_result := '';

      SELECT IBAN_CODE
        INTO v_IBAN_CODE_sgk
        FROM koc_acc_bank_history
       WHERE contract_id = 1 AND VALIDITY_END_DATE IS NULL;     -- task 191293

      OPEN cur;

      LOOP
         FETCH cur INTO rec;

         EXIT WHEN cur%NOTFOUND;
         KOC_CLM_HLTH_UTILS2.getcoresspondentbankinfo (p_bank,
                                                       base_swift_code,
                                                       TRUNC (SYSDATE),
                                                       p_bankacc);

         IF rec.technical_approved_date IS NULL
         THEN
            v_technical_approved_date := NULL;
         ELSE
            SELECT COUNT (*)
              INTO v_cnt
              FROM koc_clm_ind_app_canc_reas x
             WHERE     x.claim_id = rec.claim_id
                   AND x.sf_no = rec.sf_no
                   AND x.add_order_no = rec.add_order_no
                   AND x.approve_date <= rec.technical_approved_date;

            IF v_cnt > 0
            THEN
               v_technical_approved_date := TRUNC (SYSDATE);
            ELSE
               v_technical_approved_date := rec.technical_approved_date;
            END IF;
         END IF;

         SELECT IBAN_CODE
           INTO v_IBAN_CODE
           FROM koc_clm_trans_ext
          WHERE ROWID = rec.ROWID;

         IF v_IBAN_CODE_sgk = v_IBAN_CODE
         THEN
            NULL;   -- task 191293 sa�l�k servisine �denecekler g�ncellenmesin
         ELSE
            UPDATE koc_clm_trans_ext
               SET creditor_bank = p_bank,
                   creditor_subsidiary = p_branch,
                   account_no = p_accno,
                   creditor_name = p_acc_owner,
                   correspondent_bank = p_bankacc.bank_code,
                   correspondent_subsidiary = p_bankacc.subsdiary_code,
                   correspondent_account_code = p_bankacc.account_code,
                   is_account_approved = 0,
                   to_whom_clm_paid = 'INSURED',
                   technical_approved_date = v_technical_approved_date,
                   project_code = NULL,
                   IBAN_CODE = p_iban_code,
                   correspondent_iban_code = p_bankacc.iban_code,
                   bank_acc_IDENTITY_NO = p_tc_no,
                   bank_acc_tax_number = p_vkn_no
             WHERE ROWID = rec.ROWID;

            p_result := p_result || rec.ext_reference || ',';
         END IF;
      END LOOP;
   END;

   PROCEDURE updateclmtransbank (p_contract_id           NUMBER,
                                 p_partition_no          NUMBER,
                                 p_bank                  NUMBER,
                                 p_branch                NUMBER,
                                 p_accno                 VARCHAR2,
                                 p_acc_owner             VARCHAR2,
                                 p_result         IN OUT VARCHAR2)
   IS
   BEGIN
      updateclmtransbank (p_contract_id,
                          p_partition_no,
                          p_bank,
                          p_branch,
                          p_accno,
                          p_acc_owner,
                          NULL,
                          p_result,
                          NULL,                                  --p_iban_code
                          NULL,                                   --   p_tc_no
                          NULL                                      --p_vkn_no
                              );
   END;

   /*   PROCEDURE setclmdetail (clm koc_clm_detail%ROWTYPE)
      IS
      BEGIN
         UPDATE koc_clm_detail
            SET can_be_recourse = clm.can_be_recourse,
                recourse_amount = clm.recourse_amount,
                recourse_clm_amount = clm.recourse_clm_amount,
                recourse_rate_100 = clm.recourse_rate_100,
                recourse_rate_8 = clm.recourse_rate_8,
                recourse_status = clm.recourse_status
          WHERE claim_id = clm.claim_id
            AND sf_no = clm.sf_no
            AND detail_no = clm.detail_no;

         IF SQL%ROWCOUNT = 0 AND NVL (clm.can_be_recourse, 0) = 1
         THEN
            INSERT INTO koc_clm_detail
                        (claim_id, sf_no, detail_no,
                         can_be_recourse, recourse_amount,
                         recourse_clm_amount, recourse_rate_100,
                         recourse_rate_8, recourse_status
                        )
                 VALUES (clm.claim_id, clm.sf_no, clm.detail_no,
                         clm.can_be_recourse, clm.recourse_amount,
                         clm.recourse_clm_amount, clm.recourse_rate_100,
                         clm.recourse_rate_8, clm.recourse_status
                        );
         END IF;
            --update koc_clm_hlth_detail where rel_claim_id= p_rel_claim_id
   --       where where claim_id= clm.claim_id;
      END;
   */



   PROCEDURE setclmdetail (p_claim_id               NUMBER,
                           p_sf_no                  NUMBER,
                           p_detail_no              NUMBER,
                           p_can_be_recourse        NUMBER,
                           p_recourse_amount        NUMBER,
                           p_recourse_clm_amount    NUMBER,
                           p_recourse_rate_100      NUMBER,
                           p_recourse_rate_8        NUMBER,
                           p_recourse_status        NUMBER)
   IS
      CURSOR cagent
      IS
         SELECT koc_clm_utils.region_code_bul (clm.PROVISION_USER_ID) rcode
           FROM koc_clm_hlth_detail clm
          WHERE     clm.claim_id = p_claim_id
                AND clm.sf_no = p_sf_no
                AND ROWNUM < 2;

      /*      SELECT distinct users.oracle_username,
                   koc_clm_utils.region_code_bul (users.oracle_username) rcode
              FROM koc_cp_partners_ext cp,
                   koc_v_sec_system_users users,
                   koc_dmt_agents_ext ext,
                   clm_pol_bases clm
             WHERE cp.part_id = users.customer_partner_id
               AND ext.int_id = cp.agen_int_id
               AND clm.agent_role = ext.int_id
               AND clm.claim_id = p_claim_id;*/


      ragent   cagent%ROWTYPE;
   BEGIN
      OPEN cagent;

      FETCH cagent INTO ragent;

      CLOSE cagent;

      -- rucu oran tarih�e , Task 184519
      Koc_Clm_Recourse2.p_recourse_history (p_claim_id,
                                            p_sf_no,
                                            p_recourse_rate_8,
                                            p_recourse_rate_100,
                                            USER,
                                            'koc_clm_hlth_trnx2');

      UPDATE koc_clm_detail
         SET can_be_recourse = p_can_be_recourse,
             recourse_amount = p_recourse_amount,
             recourse_clm_amount = p_recourse_clm_amount,
             recourse_rate_100 = p_recourse_rate_100,
             recourse_rate_8 = p_recourse_rate_8,
             recourse_status = p_recourse_status,
             user_region_code = ragent.rcode
       WHERE     claim_id = p_claim_id
             AND sf_no = p_sf_no
             AND detail_no = p_detail_no;

      IF SQL%ROWCOUNT = 0 AND NVL (p_can_be_recourse, 0) = 1
      THEN
         INSERT INTO koc_clm_detail (claim_id,
                                     sf_no,
                                     detail_no,
                                     can_be_recourse,
                                     recourse_amount,
                                     recourse_clm_amount,
                                     recourse_rate_100,
                                     recourse_rate_8,
                                     recourse_status,
                                     user_region_code)
              VALUES (p_claim_id,
                      p_sf_no,
                      p_detail_no,
                      p_can_be_recourse,
                      p_recourse_amount,
                      p_recourse_clm_amount,
                      p_recourse_rate_100,
                      p_recourse_rate_8,
                      p_recourse_status,
                      ragent.rcode);
      END IF;
   --update koc_clm_hlth_detail where rel_claim_id= p_rel_claim_id
   --       where where claim_id= clm.claim_id;
   END;

   PROCEDURE setclmreinsurance (p_contract_id       NUMBER,
                                p_partition_no      NUMBER,
                                p_claim_id          NUMBER,
                                p_product_id        NUMBER,
                                p_partition_type    VARCHAR2,
                                p_cover_code        VARCHAR2)
   IS
      v_business_start_date   DATE;
      v_reins_cover_code      VARCHAR2 (4);
   BEGIN
      v_business_start_date :=
         koc_clm_hlth_trnx.get_business_start_date (p_contract_id, 1);

      SELECT DECODE (x.reins_cover_code, 0, NULL, x.reins_cover_code)
        INTO v_reins_cover_code
        FROM koc_oc_prod_part_main_cov x
       WHERE     x.product_id = p_product_id
             AND x.partition_type = p_partition_type
             AND x.cover_code = p_cover_code
             AND x.validity_start_date <= v_business_start_date
             AND (   x.validity_end_date >= v_business_start_date
                  OR x.validity_end_date IS NULL);

      koc_rci_clm_match_api.set_claim_match_par (p_claim_id,
                                                 1,
                                                 v_business_start_date,
                                                 p_contract_id,
                                                 NULL,
                                                 v_reins_cover_code,
                                                 20,
                                                 p_partition_no);
      koc_rci_clm_match_api.match_claim_section;
   EXCEPTION
      WHEN OTHERS
      THEN
         NULL;
   END;

   PROCEDURE update_specialty_subject (p_claim_id             NUMBER,
                                       p_sf_no                NUMBER,
                                       p_add_order_no         NUMBER,
                                       p_specialty_subject    VARCHAR2)
   IS
   BEGIN
      UPDATE koc_clm_hlth_detail
         SET specialty_subject = p_specialty_subject
       WHERE     claim_id = p_claim_id
             AND sf_no = p_sf_no
             AND add_order_no = p_add_order_no;
   END;

   PROCEDURE p_get_clm_recorse_status (p_claim_id       NUMBER,
                                       p_sf_no          NUMBER,
                                       p_result     OUT VARCHAR2,
                                       p_code       OUT VARCHAR2)
   IS
      --   v_result   VARCHAR2 (500) := NULL;
      CURSOR c1
      IS
           SELECT b.close_code, b.explanation          --INTO p_result, p_code
             FROM koc_clm_subfile_closed_rel a,
                  koc_clm_closed_ref b,
                  koc_clm_recourse_detail c,
                  clm_subfiles d
            WHERE     a.cancel_date IS NULL
                  AND a.claim_id = c.claim_id
                  AND a.sf_no = c.sf_no
                  AND c.clm_ext_reference = d.ext_reference
                  AND d.claim_id = p_claim_id
                  --         AND c.sf_no = p_sf_no
                  AND a.close_code = b.close_code
         ORDER BY order_no DESC;

      v1   c1%ROWTYPE;

      CURSOR c2
      IS
           SELECT a.*
             FROM clm_status_history a,
                  koc_clm_recourse_detail c,
                  clm_subfiles d
            WHERE     a.claim_id = c.claim_id
                  AND a.sf_no = c.sf_no
                  AND a.clm_status = 'RUCU'
                  AND c.clm_ext_reference = d.ext_reference
                  AND d.claim_id = p_claim_id
         ORDER BY a.status_id DESC;

      -- AND c.sf_no = p_sf_no;

      v2   c2%ROWTYPE;

      CURSOR c3
      IS
         SELECT b.parameter_name, b.parameter
           FROM koc_clm_detail a,
                (SELECT *
                   FROM koc_v_cp_health_look_up x
                  WHERE x.look_up_code = 'CLMRECSTAT') b
          WHERE     claim_id = p_claim_id
                AND sf_no = p_sf_no
                AND a.recourse_status = b.parameter;

      v3   c3%ROWTYPE;
   BEGIN
      OPEN c1;

      FETCH c1 INTO v1;

      IF c1%FOUND
      THEN
         p_result := v1.explanation;
         p_code := '6';
      ELSE
         OPEN c2;

         FETCH c2 INTO v2;

         IF c2%FOUND
         THEN
            p_result := 'R�cu Dosyasy A�yldy';
            p_code := 5;
         ELSE
            OPEN c3;

            FETCH c3 INTO v3;

            IF c3%FOUND
            THEN
               p_result := v3.parameter_name;
               p_code := v3.parameter;
            END IF;

            CLOSE c3;
         END IF;

         CLOSE c2;
      END IF;

      CLOSE c1;

      p_result := SUBSTR (p_result, 1, 20);
   END;


   FUNCTION get_clm_recorse_status (p_claim_id NUMBER, p_sf_no NUMBER)
      RETURN VARCHAR2
   IS
      v_result   VARCHAR2 (500) := NULL;

      CURSOR c1
      IS
         SELECT b.explanation
           FROM koc_clm_subfile_closed_rel a,
                koc_clm_closed_ref b,
                koc_clm_recourse_detail c,
                clm_subfiles d
          WHERE     a.cancel_date IS NULL
                AND a.claim_id = c.claim_id
                AND a.sf_no = c.sf_no
                AND c.clm_ext_reference = d.ext_reference
                AND d.claim_id = p_claim_id
                --         AND c.sf_no = p_sf_no
                AND a.close_code = b.close_code;

      v1         c1%ROWTYPE;

      CURSOR c2
      IS
         SELECT a.*
           FROM clm_status_history a,
                koc_clm_recourse_detail c,
                clm_subfiles d
          WHERE     a.claim_id = c.claim_id
                AND a.sf_no = c.sf_no
                AND a.clm_status = 'RUCU'
                AND c.clm_ext_reference = d.ext_reference
                AND d.claim_id = p_claim_id;

      -- AND c.sf_no = p_sf_no;

      v2         c2%ROWTYPE;

      CURSOR c3
      IS
         SELECT b.parameter_name
           FROM koc_clm_detail a,
                (SELECT *
                   FROM koc_v_cp_health_look_up x
                  WHERE x.look_up_code = 'CLMRECSTAT') b
          WHERE     claim_id = p_claim_id
                AND sf_no = p_sf_no
                AND a.recourse_status = b.parameter;

      v3         c3%ROWTYPE;
   BEGIN
      OPEN c1;

      FETCH c1 INTO v1;

      IF c1%FOUND
      THEN
         v_result := v1.explanation;
      ELSE
         OPEN c2;

         FETCH c2 INTO v2;

         IF c2%FOUND
         THEN
            v_result := 'R�cu Dosyasy A�yldy';
         ELSE
            OPEN c3;

            FETCH c3 INTO v3;

            IF c3%FOUND
            THEN
               v_result := v3.parameter_name;
            END IF;

            CLOSE c3;
         END IF;

         CLOSE c2;
      END IF;

      CLOSE c1;

      v_result := SUBSTR (v_result, 1, 20);


      RETURN (v_result);
   END;                                                              /*begin*/



   PROCEDURE geninstperiodamount (p_institute_code    NUMBER,
                                  p_start_date        DATE,
                                  p_end_date          DATE)
   IS
      v_trans_type           NUMBER;
      v_payment_group_code   VARCHAR2 (10);
      p_trans_year           NUMBER;
      p_trans_month          NUMBER;
      p_trans_date           DATE;
      p_year                 NUMBER;


      CURSOR cur
      IS
           SELECT institute_code,
                  SUM (devir_borc) devir_borc,
                  SUM (devir_alacak) devir_alacak,
                  SUM (devir) devir,
                  SUM (borc) borc,
                  SUM (alacak) alacak,
                  SUM (tut) tut,
                  SUM (devir_borc) + SUM (borc) devir_borc_2006,
                  SUM (devir_alacak) + SUM (alacak) devir_alacak_2006,
                  SUM (tut) + SUM (devir) bakiye
             FROM (  SELECT 0 devir_borc,
                            0 devir_alacak,
                            0 devir,
                            SUM (DECODE (b.SIGN, -1, 1, 0) * a.trans_amount) borc,
                            SUM (DECODE (b.SIGN, 1, 1, 0) * a.trans_amount)
                               alacak,
                            SUM (b.SIGN * a.trans_amount) tut,
                            a.institute_code
                       FROM koc_clm_hlth_inst_trans a, koc_cc_inst_trans_ref b
                      WHERE     a.trans_type = b.trans_type
                            AND a.firm IN ('0', 'M2')
                            AND a.institute_code = p_institute_code
                            AND a.batch_date BETWEEN p_start_date AND p_end_date
                            AND a.trans_type NOT IN (1, 21, 31, 32)
                   GROUP BY a.institute_code
                   UNION ALL
                     SELECT SUM (DECODE (b.SIGN, -1, 1, 0) * a.trans_amount)
                               devir_borc,
                            SUM (DECODE (b.SIGN, 1, 1, 0) * a.trans_amount)
                               devir_alacak,
                            SUM (b.SIGN * a.trans_amount) devir,
                            0,
                            0,
                            0 tut,
                            a.institute_code
                       FROM koc_clm_hlth_inst_trans a, koc_cc_inst_trans_ref b
                      WHERE     a.trans_type = b.trans_type
                            AND a.firm IN ('0', 'M2', 'M1')
                            AND a.pay_year = p_year
                            AND a.pay_month = 1
                            AND a.institute_code = p_institute_code
                            AND a.trans_type IN (31, 32)
                   GROUP BY a.institute_code
                   UNION ALL
                     SELECT 0 devir_borc,
                            0 devir_alacak,
                            0 devir,
                            SUM (borc) borc,
                            SUM (alacak) alacak,
                            SUM (a.alacak - a.borc) tut,
                            TO_NUMBER (SUBSTR (a.account_code, 7, 4))
                               institute_code
                       FROM koc_acc_v_posting_details a
                      WHERE     a.account_code LIKE '347020%'
                            AND a.account_code =
                                   '347020' || LPAD (p_institute_code, 4, '0')
                            AND a.posting_date >= p_start_date
                            AND a.posting_date <= p_end_date
                            AND a.event_type_code != 'DEVIRHESAP'
                            AND NVL (a.username, '0') != 'SERBESTFIS'
                            AND EXISTS
                                   (SELECT 1
                                      FROM koc_acc_v_posting_details x
                                     WHERE     x.account_code = '3470640002'
                                           AND x.batch_id = a.batch_id)
                   GROUP BY SUBSTR (a.account_code, 7, 4))
         GROUP BY institute_code;

      rec                    cur%ROWTYPE;
   BEGIN
      p_trans_date := LAST_DAY (p_end_date) + 1;
      p_trans_year := TO_CHAR (p_trans_date, 'YYYY');
      p_trans_month := TO_CHAR (p_trans_date, 'MM');
      p_year := TO_CHAR (p_start_date, 'YYYY');



      OPEN cur;

      LOOP
         BEGIN
            FETCH cur INTO rec;

            EXIT WHEN cur%NOTFOUND;

            IF rec.bakiye < 0
            THEN
               v_trans_type := 31;
            ELSE
               v_trans_type := 32;
            END IF;

            BEGIN
               SELECT a.payment_group_code
                 INTO v_payment_group_code
                 FROM koc_clm_suppliers_ext a
                WHERE a.institute_code = rec.institute_code;
            EXCEPTION
               WHEN OTHERS
               THEN
                  v_payment_group_code := NULL;
            END;



            DELETE FROM koc_clm_hlth_inst_trans
                  WHERE     institute_code = rec.institute_code
                        AND trans_date = p_trans_date
                        AND trans_type IN (31, 32);

            INSERT INTO koc_clm_hlth_inst_trans (institute_code,
                                                 trans_date,
                                                 trans_type,
                                                 firm,
                                                 trans_no,
                                                 trans_amount,
                                                 pay_year,
                                                 pay_month,
                                                 claim_id,
                                                 sf_no,
                                                 add_order_no,
                                                 batch_id,
                                                 batch_date,
                                                 approve_date,
                                                 userid,
                                                 entry_date,
                                                 reverse_flag,
                                                 payment_group_code,
                                                 order_no,
                                                 explanation,
                                                 account_no,
                                                 approve_user)
                 VALUES (rec.institute_code,
                         p_trans_date,
                         v_trans_type,
                         '0',
                         1,
                         ABS (rec.bakiye),
                         p_trans_year,
                         p_trans_month,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         p_trans_date,
                         SYSDATE,
                         NULL,
                         NULL,
                         NULL,
                         v_payment_group_code,
                         1,
                         'DEV�R',
                         NULL,
                         NULL);

            COMMIT;
         EXCEPTION
            WHEN OTHERS
            THEN
               ROLLBACK;
         END;
      END LOOP;

      CLOSE cur;
   END;


   --Task 12317 - e-provizyon ile eklendi. yg 24/04/2009
   PROCEDURE insupduwnote (p_claim_id        NUMBER,
                           p_part_id         NUMBER,
                           p_status_code     VARCHAR2,
                           p_explanation     VARCHAR2,
                           p_contract_id     NUMBER,
                           p_partition_no    NUMBER)
   IS
      CURSOR c_has_uw
      IS
         SELECT 1
           FROM koc_clm_uw_notification n
          WHERE n.claim_id = p_claim_id;

      row_has_uw   c_has_uw%ROWTYPE;
   BEGIN
      OPEN c_has_uw;

      FETCH c_has_uw INTO row_has_uw;

      IF c_has_uw%FOUND
      THEN
         UPDATE koc_clm_uw_notification
            SET status_code = p_status_code,
                explanation = p_explanation,
                part_id = p_part_id,
                contract_id = p_contract_id,
                partition_no = p_partition_no
          WHERE claim_id = p_claim_id;
      ELSE
         INSERT INTO koc_clm_uw_notification (claim_id,
                                              part_id,
                                              status_code,
                                              explanation,
                                              contract_id,
                                              partition_no,
                                              create_user_id,
                                              create_date)
              VALUES (p_claim_id,
                      p_part_id,
                      p_status_code,
                      p_explanation,
                      p_contract_id,
                      p_partition_no,
                      USER,
                      SYSDATE);
      END IF;

      CLOSE c_has_uw;
   END;

   PROCEDURE transerProcDataToSession (p_claim_id        NUMBER,
                                       p_sf_no           NUMBER,
                                       p_add_order_no    NUMBER)
   IS
   BEGIN
      --session da deger kaldiysa once o bilgiler silinir.
      DELETE koc_clm_hlth_tmp_proc_detail
       WHERE     claim_id = p_claim_id
             AND sf_no = p_sf_no
             AND add_order_no = p_add_order_no;


      -- proc_detail deki kay�tlar session bazl� tabloya aktar�l�r
      /*mkucuk@kora
       INSERT INTO koc_clm_hlth_tmp_proc_detail
                   (claim_id, sf_no, location_code, add_order_no, cover_code,
                    group_no, process_code_main, process_code_sub1,
                    process_code_sub2, discount_group_code, indemnity_amount,
                    process_group, userid, entrance_date, process_count, status_code,
                    swift_code, inst_indemnity_amount, explanation )
          SELECT claim_id, sf_no, location_code, add_order_no, cover_code, group_no,
                 process_code_main, process_code_sub1, process_code_sub2,
                 discount_group_code, indemnity_amount, process_group, userid,
                 entrance_date, process_count, status_code, swift_code,
                 inst_indemnity_amount, explanation
            FROM koc_clm_hlth_proc_detail
           WHERE claim_id = p_claim_id
             AND sf_no = p_sf_no
             AND add_order_no = p_add_order_no;*/
      INSERT INTO koc_clm_hlth_tmp_proc_detail (claim_id,
                                                sf_no,
                                                location_code,
                                                add_order_no,
                                                cover_code,
                                                group_no,
                                                process_code_main,
                                                process_code_sub1,
                                                process_code_sub2,
                                                discount_group_code,
                                                indemnity_amount,
                                                process_group,
                                                userid,
                                                entrance_date,
                                                process_count,
                                                status_code,
                                                swift_code,
                                                inst_indemnity_amount,
                                                explanation,
                                                time_stamp,
                                                drg_code,
                                                doctor_code,
                                                doctor_status,
                                                sgk_amount,
                                                order_no,
                                                vat_rate,
                                                right_left,
                                                proc_type,
                                                physiotherapy_session,
                                                diagnosis_id,
                                                surgery_id,
                                                seq_no,
                                                bre_result_code,
                                                REQ_PROCESS_NAME,
                                                REQ_PROCESS_CODE,
                                                REQ_PROCESS_LIST_TYPE,
                                                RELATED_PROCESS,
                                                RELATED_PROCESS_LIST_TYPE)
         SELECT claim_id,
                sf_no,
                location_code,
                add_order_no,
                cover_code,
                group_no,
                process_code_main,
                process_code_sub1,
                process_code_sub2,
                discount_group_code,
                indemnity_amount,
                process_group,
                userid,
                entrance_date,
                process_count,
                status_code,
                swift_code,
                inst_indemnity_amount,
                explanation,
                time_stamp,
                drg_code,
                doctor_code,
                doctor_status,
                sgk_amount,
                order_no,
                vat_rate,
                right_left,
                proc_type,
                physiotherapy_session,
                diagnosis_id,
                surgery_id,
                seq_no,
                bre_result_code,
                REQ_PROCESS_NAME,
                REQ_PROCESS_CODE,
                REQ_PROCESS_LIST_TYPE,
                RELATED_PROCESS,
                RELATED_PROCESS_LIST_TYPE
           FROM koc_clm_hlth_proc_detail
          WHERE     claim_id = p_claim_id
                AND sf_no = p_sf_no
                AND add_order_no = p_add_order_no;
   END;

   --seq_no eklendi mkucuk@kora
   PROCEDURE deleteSessionProcReq (p_claim_id             NUMBER,
                                   p_sf_no                NUMBER,
                                   p_add_order_no         NUMBER,
                                   p_process_code_main    NUMBER,
                                   p_process_code_sub1    NUMBER,
                                   p_process_code_sub2    NUMBER,
                                   p_location_code        NUMBER,
                                   p_cover_code           VARCHAR2,
                                   p_seq_no               NUMBER)
   IS
   BEGIN
      DELETE koc_clm_hlth_tmp_proc_detail
       WHERE     claim_id = p_claim_id
             AND sf_no = p_sf_no
             AND add_order_no = p_add_order_no
             AND process_code_main = p_process_code_main
             AND process_code_sub1 = p_process_code_sub1
             AND process_code_sub2 = p_process_code_sub2
             AND location_code = p_location_code
             AND cover_code = p_cover_code
             AND seq_no = p_seq_no;
   END;

   PROCEDURE transerSessionProcDataToDB (p_claim_id        NUMBER,
                                         p_sf_no           NUMBER,
                                         p_add_order_no    NUMBER)
   IS
   BEGIN
      DELETE koc_clm_hlth_proc_detail
       WHERE     claim_id = p_claim_id
             AND sf_no = p_sf_no
             AND add_order_no = p_add_order_no;


      /*mkucuk@kora
      INSERT INTO koc_clm_hlth_proc_detail
                  (claim_id, sf_no, location_code, add_order_no, cover_code,
                   group_no, process_code_main, process_code_sub1,
                   process_code_sub2, discount_group_code, indemnity_amount,
                   process_group, userid, entrance_date, process_count, status_code,
                   swift_code, inst_indemnity_amount, explanation)
         SELECT claim_id, sf_no, location_code, add_order_no, cover_code, group_no,
                process_code_main, process_code_sub1, process_code_sub2,
                discount_group_code, indemnity_amount, process_group, userid,
                entrance_date, process_count, status_code, swift_code,
                inst_indemnity_amount, explanation
           FROM koc_clm_hlth_tmp_proc_detail
          WHERE claim_id = p_claim_id
            AND sf_no = p_sf_no
            AND add_order_no = p_add_order_no;*/
      INSERT INTO koc_clm_hlth_proc_detail (claim_id,
                                            sf_no,
                                            location_code,
                                            add_order_no,
                                            cover_code,
                                            group_no,
                                            process_code_main,
                                            process_code_sub1,
                                            process_code_sub2,
                                            discount_group_code,
                                            indemnity_amount,
                                            process_group,
                                            userid,
                                            entrance_date,
                                            process_count,
                                            status_code,
                                            swift_code,
                                            inst_indemnity_amount,
                                            explanation,
                                            time_stamp,
                                            drg_code,
                                            doctor_code,
                                            doctor_status,
                                            sgk_amount,
                                            order_no,
                                            vat_rate,
                                            right_left,
                                            proc_type,
                                            physiotherapy_session,
                                            diagnosis_id,
                                            surgery_id,
                                            seq_no,
                                            bre_result_code,
                                            REQ_PROCESS_NAME,
                                            REQ_PROCESS_CODE,
                                            REQ_PROCESS_LIST_TYPE,
                                            RELATED_PROCESS,
                                            RELATED_PROCESS_LIST_TYPE)
         SELECT claim_id,
                sf_no,
                location_code,
                add_order_no,
                cover_code,
                group_no,
                process_code_main,
                process_code_sub1,
                process_code_sub2,
                discount_group_code,
                indemnity_amount,
                process_group,
                userid,
                entrance_date,
                process_count,
                status_code,
                swift_code,
                inst_indemnity_amount,
                explanation,
                time_stamp,
                drg_code,
                doctor_code,
                doctor_status,
                sgk_amount,
                order_no,
                vat_rate,
                right_left,
                proc_type,
                physiotherapy_session,
                diagnosis_id,
                surgery_id,
                seq_no,
                bre_result_code,
                REQ_PROCESS_NAME,
                REQ_PROCESS_CODE,
                REQ_PROCESS_LIST_TYPE,
                RELATED_PROCESS,
                RELATED_PROCESS_LIST_TYPE
           FROM koc_clm_hlth_tmp_proc_detail
          WHERE     claim_id = p_claim_id
                AND sf_no = p_sf_no
                AND add_order_no = p_add_order_no;
   END;

   PROCEDURE deleteCoverProcs (p_claim_id         NUMBER,
                               p_sf_no            NUMBER,
                               p_add_order_no     NUMBER,
                               p_location_code    NUMBER,
                               p_cover_code       VARCHAR2)
   IS
   BEGIN
      DELETE koc_clm_hlth_tmp_proc_detail
       WHERE     claim_id = p_claim_id
             AND sf_no = p_sf_no
             AND add_order_no = p_add_order_no
             AND cover_code = p_cover_code
             AND location_code = p_location_code;
   END;

   PROCEDURE insertSessionProcs (p_claim_id                 NUMBER,
                                 p_sf_no                    NUMBER,
                                 p_location_code            NUMBER,
                                 p_add_order_no             NUMBER,
                                 p_cover_code               VARCHAR2,
                                 p_group_no                 NUMBER,
                                 p_process_code_main        NUMBER,
                                 p_process_code_sub1        NUMBER,
                                 p_process_code_sub2        NUMBER,
                                 p_discount_group_code      VARCHAR2,
                                 p_indemnity_amount         NUMBER,
                                 p_process_group            VARCHAR2,
                                 p_userid                   VARCHAR2,
                                 p_process_count            NUMBER,
                                 p_status_code              VARCHAR2,
                                 p_swift_code               VARCHAR2,
                                 p_inst_indemnity_amount    NUMBER,
                                 p_seq_no                   NUMBER)
   IS
      CURSOR c_has
      IS
         SELECT 1
           FROM koc_clm_hlth_tmp_proc_detail
          WHERE     claim_id = p_claim_id
                AND sf_no = p_sf_no
                AND location_code = p_location_code
                AND add_order_no = p_add_order_no
                AND cover_code = p_cover_code
                AND process_code_main = p_process_code_main
                AND process_code_sub1 = p_process_code_sub1
                AND process_code_sub2 = p_process_code_sub2
                AND seq_no = p_seq_no;

      row_has   c_has%ROWTYPE;
   BEGIN
      OPEN c_has;

      FETCH c_has INTO row_has;

      IF c_has%NOTFOUND
      THEN
         INSERT INTO koc_clm_hlth_tmp_proc_detail (claim_id,
                                                   sf_no,
                                                   location_code,
                                                   add_order_no,
                                                   cover_code,
                                                   group_no,
                                                   process_code_main,
                                                   process_code_sub1,
                                                   process_code_sub2,
                                                   discount_group_code,
                                                   indemnity_amount,
                                                   process_group,
                                                   userid,
                                                   process_count,
                                                   status_code,
                                                   swift_code,
                                                   inst_indemnity_amount,
                                                   seq_no)
              VALUES (p_claim_id,
                      p_sf_no,
                      p_location_code,
                      p_add_order_no,
                      p_cover_code,
                      p_group_no,
                      p_process_code_main,
                      p_process_code_sub1,
                      p_process_code_sub2,
                      p_discount_group_code,
                      p_indemnity_amount,
                      p_process_group,
                      p_userid,
                      p_process_count,
                      p_status_code,
                      p_swift_code,
                      p_inst_indemnity_amount,
                      1);
      ELSE
         UPDATE koc_clm_hlth_tmp_proc_detail
            SET process_count = p_process_count,
                indemnity_amount = p_indemnity_amount,
                inst_indemnity_amount = p_inst_indemnity_amount
          WHERE     claim_id = p_claim_id
                AND sf_no = p_sf_no
                AND location_code = p_location_code
                AND add_order_no = p_add_order_no
                AND cover_code = p_cover_code
                AND process_code_main = p_process_code_main
                AND process_code_sub1 = p_process_code_sub1
                AND process_code_sub2 = p_process_code_sub2;
      END IF;
   END;

   PROCEDURE setHospitalizeDateToNull (p_claim_id        NUMBER,
                                       p_sf_no           NUMBER,
                                       p_add_order_no    NUMBER)
   IS
   BEGIN
      UPDATE koc_clm_hlth_detail
         SET hospitalize_date = NULL, DISCHARGE_DATE = NULL
       WHERE     claim_id = p_claim_id
             AND sf_no = p_sf_no
             AND add_order_no = p_add_order_no;
   END;


   PROCEDURE processtempacctoreal
   IS
      -- cozbay task132695 09/02/2012
      -- stopaj ge�ici hesaptan ger�ek hesaba fisleri aktarma
      v_last_month         DATE;
      v_first_date_last    DATE;
      v_last_date_last     DATE;
      v_status_code_aca    NUMBER;
      v_status_code_acch   NUMBER;
      v_postings           koc_acc_utils.account_postingtyp;
      v_sayac              NUMBER;
      v_batch_id           NUMBER;
      v_borc               NUMBER;
      v_alacak             NUMBER;
      v_first_date         DATE;
      v_last_date          DATE;


      CURSOR c_status (
         p_process_date   IN DATE,
         p_close_date     IN DATE,
         p_process_type   IN VARCHAR2)
      IS
         SELECT c.status_code
           FROM koc_process_close c
          WHERE     process_date = p_process_date
                AND close_date = p_close_date
                AND c.process_type = p_process_type
                AND c.branch_id = 1;

      CURSOR cur_tmp (
         pfirst_date   IN DATE,
         plast_date    IN DATE)
      IS
         SELECT SUM (borc) borc, SUM (alacak) alacak
           FROM koc_acc_v_posting_details
          WHERE     account_code = '3470299999'
                AND posting_date BETWEEN pfirst_date AND plast_date;
   BEGIN
      v_first_date := TRUNC (TRUNC (SYSDATE), 'MM');           --ayin ilk gunu
      v_last_date := LAST_DAY (v_first_date);                 -- ayin son gunu

      OPEN cur_tmp (v_first_date, v_last_date);

      FETCH cur_tmp
      INTO v_borc, v_alacak;

      CLOSE cur_tmp;

      IF NVL (v_borc, 0) <> 0 OR NVL (v_alacak, 0) <> 0
      THEN
         v_last_month := ADD_MONTHS (TRUNC (SYSDATE), -1);

         v_first_date_last := TRUNC (v_last_month, 'MM'); --Onceki ayin ilk gunu
         v_last_date_last := LAST_DAY (v_first_date_last); -- Onceki ayin son gunu

         --ACA i�in onceki ayin statusunu aliyoruz
         OPEN c_status (v_first_date_last, v_last_date_last, 'ACA');

         FETCH c_status INTO v_status_code_aca;

         CLOSE c_status;

         --ACCH i�in onceki ayin statusunu aliyoruz
         OPEN c_status (v_first_date_last, v_last_date_last, 'ACCH');

         FETCH c_status INTO v_status_code_acch;

         CLOSE c_status;

         -- ayi aciyoruz

         UPDATE koc_process_close
            SET status_code = 1
          WHERE     process_date = v_first_date_last
                AND close_date = v_last_date_last
                AND process_type IN ('ACA', 'ACCH')
                AND branch_id = 1;

         v_sayac := 0;

         --borc varsa borc icin
         IF v_borc <> 0
         THEN
            -- gercek hesaba borc kesiyorum
            v_sayac := v_sayac + 1;
            v_postings (v_sayac).account_category_code := 'YSTOPAJ';
            v_postings (v_sayac).event_type_code := 'TAZMINAT';
            v_postings (v_sayac).subfactor_1_val := '3003';
            v_postings (v_sayac).posting_amount := -1 * v_borc;
            v_postings (v_sayac).posting_date := v_last_date_last; --bir onceki ayin son gunune atiyoruz
            v_postings (v_sayac).posting_type := 'MAHSUP';
            v_postings (v_sayac).swift_code := base_swift_code;
            v_postings (v_sayac).curr_exchg_rate := 1;
            v_postings (v_sayac).explanation :=
               TO_CHAR (v_last_date_last, 'MM/YYYY') || ' STOPAJ VIRMANI';
            v_postings (v_sayac).related_order := 1;

            -- geciciye tersini yani alacak  kesiyorum

            v_sayac := v_sayac + 1;
            v_postings (v_sayac).account_category_code := 'YKURUM';
            v_postings (v_sayac).event_type_code := 'TAZMINAT';
            v_postings (v_sayac).subfactor_1_val := 'S99';
            v_postings (v_sayac).posting_amount := v_borc;
            v_postings (v_sayac).posting_date := v_last_date_last; --bir onceki ayin son gunune atiyoruz
            v_postings (v_sayac).posting_type := 'MAHSUP';
            v_postings (v_sayac).swift_code := base_swift_code;
            v_postings (v_sayac).curr_exchg_rate := 1;
            v_postings (v_sayac).explanation :=
                  TO_CHAR (v_last_date_last, 'MM/YYYY')
               || ' STOPAJ VIRMANI TERS FISI';
            v_postings (v_sayac).related_order := 1;
         END IF;

         --alacak varsa borc icin
         IF v_alacak <> 0
         THEN
            -- gercek hesaba alacak kesiyorum
            v_sayac := v_sayac + 1;
            v_postings (v_sayac).account_category_code := 'YSTOPAJ';
            v_postings (v_sayac).event_type_code := 'TAZMINAT';
            v_postings (v_sayac).subfactor_1_val := '3003';
            v_postings (v_sayac).posting_amount := v_alacak;
            v_postings (v_sayac).posting_date := v_last_date_last; --bir onceki ayin son gunune atiyoruz
            v_postings (v_sayac).posting_type := 'MAHSUP';
            v_postings (v_sayac).swift_code := base_swift_code;
            v_postings (v_sayac).curr_exchg_rate := 1;
            v_postings (v_sayac).explanation :=
               TO_CHAR (v_last_date_last, 'MM/YYYY') || ' STOPAJ VIRMANI';
            v_postings (v_sayac).related_order := 1;

            -- geciciye tersini yani borc  kesiyorum
            v_sayac := v_sayac + 1;
            v_postings (v_sayac).account_category_code := 'YKURUM';
            v_postings (v_sayac).event_type_code := 'TAZMINAT';
            v_postings (v_sayac).subfactor_1_val := 'S99';
            v_postings (v_sayac).posting_amount := -1 * v_alacak;
            v_postings (v_sayac).posting_date := v_last_date_last; --bir onceki ayin son gunune atiyoruz
            v_postings (v_sayac).posting_type := 'MAHSUP';
            v_postings (v_sayac).swift_code := base_swift_code;
            v_postings (v_sayac).curr_exchg_rate := 1;
            v_postings (v_sayac).explanation :=
                  TO_CHAR (v_last_date_last, 'MM/YYYY')
               || ' STOPAJ VIRMANI TERS FISI';
            v_postings (v_sayac).related_order := 1;
         END IF;


         koc_acc_utils.posting_accounts (v_postings,
                                         'ACC',
                                         '10',
                                         NULL,
                                         'Allianz Sigorta',
                                         v_batch_id);

         --ayi kapatiyoruz

         UPDATE koc_process_close
            SET status_code =
                   DECODE (process_type,
                           'ACA', NVL (v_status_code_aca, 2),
                           'ACCH', NVL (v_status_code_acch, 2))
          WHERE     process_date = v_first_date_last
                AND close_date = v_last_date_last
                AND process_type IN ('ACA', 'ACCH')
                AND branch_id = 1;

         COMMIT;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         IF v_first_date_last IS NOT NULL AND v_last_date_last IS NOT NULL
         THEN
            UPDATE koc_process_close
               SET status_code =
                      DECODE (process_type,
                              'ACA', NVL (v_status_code_aca, 2),
                              'ACCH', NVL (v_status_code_acch, 2))
             WHERE     process_date = v_first_date_last
                   AND close_date = v_last_date_last
                   AND process_type IN ('ACA', 'ACCH')
                   AND branch_id = 1;

            COMMIT;
         END IF;
   END;


   PROCEDURE pcancelstoppagemail (pstatement_no   IN NUMBER,
                                  pclaim_id       IN NUMBER,
                                  pinvoice_date   IN DATE,
                                  pclaim_amount   IN NUMBER,
                                  pstoppage       IN NUMBER)
   IS
      --cozbay task132695 13/02/2012 stopaj iptallerinde mail atiyor
      v_par_list   koc_smtp_util.par_list;
      v_dbname     system_parameters.VALUE%TYPE;

      CURSOR cur_dbname
      IS
         SELECT VALUE dbname
           FROM system_parameters
          WHERE code = 'SYSTEM_STATUS';
   BEGIN
      OPEN cur_dbname;

      FETCH cur_dbname INTO v_dbname;

      CLOSE cur_dbname;

      v_par_list.v_from := 'Allianz.opus@allianz.com.tr';

      IF v_dbname = 'LIVE'
      THEN
         v_par_list.v_to (1) := 'mine.kaptan@allianz.com.tr';
         v_par_list.v_to (2) := 'vergilendirme.servisi@allianz.com.tr';
      ELSE
         v_par_list.v_to (1) := 'canan.ozbay@allianz.com.tr';
      END IF;

      v_par_list.v_subject := 'Ge�mi� Tarihli Stopaj Tahakkuk �ptali';
      v_par_list.v_message_body (1) :=
            CHR (10)
         || CHR (10)
         || ' Ge�mi� Tarihli Stopaj Tahakkuk �ptali Yap�lm��t�r ; ';
      v_par_list.v_message_body (2) :=
         CHR (10) || ' �cmal Numaras� : ' || pstatement_no;
      v_par_list.v_message_body (3) :=
         CHR (10) || ' Hasar Dosya No : ' || pclaim_id;
      v_par_list.v_message_body (4) :=
         CHR (10) || ' Fatura Tarihi : ' || pinvoice_date;
      v_par_list.v_message_body (5) :=
         CHR (10) || ' Hasar Tutar� : ' || pclaim_amount;
      v_par_list.v_message_body (6) :=
         CHR (10) || ' Stopaj Tutar� : ' || pstoppage;
      KOC_SMTP_UTIL.SEND (v_par_list);
   END;

   FUNCTION postingstoppage (ptype              IN VARCHAR2,
                             pposting_date      IN DATE,
                             pbatch_id          IN NUMBER,
                             pevent_type_code   IN VARCHAR2,
                             pusername          IN VARCHAR2)
      RETURN NUMBER
   IS
      --cozbay task132695 13/02/2012 muhasebelesmis stopaj tutarini bulma
      vstoppage   NUMBER;

      CURSOR cur_stoppage
      IS
         SELECT DECODE (ptype,  'B', borc,  'A', alacak)
           FROM koc_acc_v_posting_details s
          WHERE     s.posting_date = pposting_date
                AND s.account_code IN ('3470299999', '3600103003')
                AND s.batch_id = pbatch_id
                AND s.event_type_code = pevent_type_code
                AND s.username = pusername;
   BEGIN
      OPEN cur_stoppage;

      FETCH cur_stoppage INTO vstoppage;

      CLOSE cur_stoppage;

      RETURN NVL (vstoppage, 0);
   END;

   --
   PROCEDURE get_proc_doctor_info (
      p_claim_id           IN     NUMBER,
      P_sf_no              IN     NUMBER,
      p_add_order_no       IN     NUMBER,
      p_provision_date     IN     DATE,
      p_proc_doctor_info      OUT proc_doctor_info_type)
   IS
      CURSOR proc_doctor (
         cp_claim_id        NUMBER,
         cp_sf_no           NUMBER,
         cp_add_order_no    NUMBER)
      IS
         SELECT process_code_main,
                process_code_sub1,
                process_code_sub2,
                doctor_code,
                doctor_status
           FROM koc_clm_hlth_proc_detail p
          WHERE     p.claim_id = cp_claim_id
                AND p.sf_no = cp_sf_no
                AND p.add_order_no = cp_add_order_no
                AND doctor_code IS NOT NULL;

      CURSOR doctor_type (
         cp_doctor_type_code cur_translations.short_code%TYPE)
      IS
         SELECT long_name
           FROM cur_translations b, koc_cp_health_look_up a
          WHERE     a.look_up_code = 'DOCTYPE'
                AND a.desc_int_id = b.desc_int_id
                AND b.sula_ora_nls_code = 'TR'
                AND short_code = cp_doctor_type_code;

      v_doctor_code              koc_clm_hlth_proc_detail.doctor_code%TYPE;
      v_doctor_status            koc_clm_hlth_proc_detail.doctor_status%TYPE;
      v_doctor_name              VARCHAR2 (1000);
      v_doctor_title             koc_cc_web_inst_doctor.title%TYPE;
      v_doctor_speciality_code   koc_cc_web_inst_doctor.specialty_subject%TYPE;
      v_doctor_speciality_desc   VARCHAR2 (1000);
      v_doctor_staff_status      koc_cc_web_inst_doctor.DOCTOR_STAFF%TYPE;
      v_doctor_type              koc_cc_web_inst_doctor.DOCTOR_TYPE%TYPE;
      v_doctor_type_desc         cur_translations.long_name%TYPE;

      rec_num                    NUMBER := 1;
   BEGIN
      IF p_proc_doctor_info.COUNT > 0
      THEN
         p_proc_doctor_info.delete;
      END IF;

      FOR v_proc_doctor IN proc_doctor (p_claim_id, P_sf_no, p_add_order_no)
      LOOP
         IF v_proc_doctor.doctor_code IS NOT NULL
         THEN
            BEGIN
               SELECT INITCAP (title),
                      INITCAP (doctor_name) || ' ' || UPPER (doctor_surname),
                      specialty_subject,
                      INITCAP (doctor_staff),
                      doctor_type
                 INTO v_doctor_title,
                      v_doctor_name,
                      v_doctor_speciality_code,
                      v_doctor_staff_status,
                      v_doctor_type
                 FROM hst_cc_web_inst_doctor d
                WHERE     d.doctor_code = v_proc_doctor.doctor_code
                      AND TRUNC (validity_start_date) <= p_provision_date
                      AND TRUNC (NVL (validity_end_date, SYSDATE)) >=
                             p_provision_date;
            EXCEPTION
               WHEN NO_DATA_FOUND
               THEN
                  v_doctor_name := NULL;
                  v_doctor_title := NULL;
                  v_doctor_speciality_code := NULL;
               WHEN TOO_MANY_ROWS
               THEN
                  --
                  SELECT INITCAP (title),
                            INITCAP (doctor_name)
                         || ' '
                         || UPPER (doctor_surname),
                         specialty_subject,
                         INITCAP (doctor_staff),
                         doctor_type
                    INTO v_doctor_title,
                         v_doctor_name,
                         v_doctor_speciality_code,
                         v_doctor_staff_status,
                         v_doctor_type
                    FROM koc_cc_web_inst_doctor d
                   WHERE     d.doctor_code = v_proc_doctor.doctor_code
                         AND TRUNC (validity_start_date) <= p_provision_date
                         AND TRUNC (NVL (validity_end_date, SYSDATE)) >=
                                p_provision_date
                         AND TRUNC (validity_start_date) =
                                (SELECT MAX (TRUNC (validity_start_date))
                                   FROM koc_cc_web_inst_doctor d
                                  WHERE     d.doctor_code =
                                               v_proc_doctor.doctor_code
                                        AND TRUNC (validity_start_date) <=
                                               p_provision_date
                                        AND TRUNC (
                                               NVL (validity_end_date,
                                                    SYSDATE)) >=
                                               p_provision_date)
                         AND ROWNUM = 1;
               WHEN OTHERS
               THEN
                  v_doctor_name := NULL;
                  v_doctor_title := NULL;
                  v_doctor_speciality_code := NULL;
            END;

            IF v_doctor_speciality_code IS NOT NULL
            THEN
               BEGIN
                  --
                  SELECT parent_explanation || ' - ' || explanation
                    INTO v_doctor_speciality_desc
                    FROM koc_oc_specialty_subj_ref a
                   WHERE     NVL (business_line_type, 0) IN (0, 1)
                         AND TRUNC (validity_start_date) <= p_provision_date
                         AND TRUNC (NVL (validity_end_date, SYSDATE)) >=
                                p_provision_date
                         AND specialty_subject = v_doctor_speciality_code;
               EXCEPTION
                  WHEN NO_DATA_FOUND
                  THEN
                     v_doctor_speciality_desc := NULL;
                  WHEN TOO_MANY_ROWS
                  THEN
                     SELECT parent_explanation || ' - ' || explanation
                       INTO v_doctor_speciality_desc
                       FROM koc_oc_specialty_subj_ref a
                      WHERE     NVL (business_line_type, 0) IN (0, 1)
                            AND TRUNC (validity_start_date) <=
                                   p_provision_date
                            AND TRUNC (NVL (validity_end_date, SYSDATE)) >=
                                   p_provision_date
                            AND specialty_subject = v_doctor_speciality_code
                            AND TRUNC (validity_start_date) =
                                   (SELECT MAX (TRUNC (validity_start_date))
                                      FROM koc_oc_specialty_subj_ref a
                                     WHERE     NVL (business_line_type, 0) IN
                                                  (0, 1)
                                           AND TRUNC (validity_start_date) <=
                                                  p_provision_date
                                           AND TRUNC (
                                                  NVL (validity_end_date,
                                                       SYSDATE)) >=
                                                  p_provision_date
                                           AND specialty_subject =
                                                  v_doctor_speciality_code)
                            AND ROWNUM = 1;
                  WHEN OTHERS
                  THEN
                     v_doctor_speciality_desc := NULL;
               END;
            END IF;

            IF v_doctor_type IS NOT NULL
            THEN
               OPEN doctor_type (v_doctor_type);

               FETCH doctor_type INTO v_doctor_type_desc;

               CLOSE doctor_type;
            END IF;
         END IF;

         p_proc_doctor_info (rec_num).claim_id := p_claim_id;
         p_proc_doctor_info (rec_num).sf_no := p_sf_no;
         p_proc_doctor_info (rec_num).add_order_no := p_add_order_no;
         p_proc_doctor_info (rec_num).process_code_main :=
            v_proc_doctor.process_code_main;
         p_proc_doctor_info (rec_num).process_code_sub1 :=
            v_proc_doctor.process_code_sub1;
         p_proc_doctor_info (rec_num).process_code_sub2 :=
            v_proc_doctor.process_code_sub2;
         p_proc_doctor_info (rec_num).doctor_code := v_doctor_code;
         p_proc_doctor_info (rec_num).doctor_status := v_doctor_status;
         p_proc_doctor_info (rec_num).doctor_name := v_doctor_name;
         p_proc_doctor_info (rec_num).doctor_title := v_doctor_title;
         p_proc_doctor_info (rec_num).doctor_speciality :=
            v_doctor_speciality_code;
         p_proc_doctor_info (rec_num).doctor_speciality_desc :=
            v_doctor_speciality_desc;
         p_proc_doctor_info (rec_num).doctor_staff_status :=
            v_doctor_staff_status;
         p_proc_doctor_info (rec_num).doctor_type := v_doctor_type;
         p_proc_doctor_info (rec_num).doctor_type_desc := v_doctor_type_desc;

         rec_num := rec_num + 1;
      END LOOP;
   END;

   ---
   PROCEDURE get_relationship_info (
      p_claim_id           IN     NUMBER,
      P_sf_no              IN     NUMBER,
      p_add_order_no       IN     NUMBER,
      p_relationshiptype      OUT relationshiptype)
   IS
      CURSOR c_relationship (
         cp_claim_id       IN NUMBER,
         cP_sf_no          IN NUMBER,
         cp_add_order_no   IN NUMBER)
      IS
         SELECT claim_id,
                sf_no,
                add_order_no,
                insurednotype,
                insuredno,
                firstname,
                surname,
                gender,
                dateofbirth,
                relationship,
                mobilephone,
                email
           FROM alz_hltprv_relationship_detail
          WHERE     claim_id = cp_claim_id
                AND sf_no = cp_sf_no
                AND add_order_no = cp_add_order_no;

      rec_num   NUMBER := 1;
   BEGIN
      FOR v_relationship
         IN c_relationship (p_claim_id, P_sf_no, p_add_order_no)
      LOOP
         p_relationshiptype (rec_num).claim_id := v_relationship.claim_id;
         p_relationshiptype (rec_num).sf_no := v_relationship.sf_no;
         p_relationshiptype (rec_num).add_order_no :=
            v_relationship.add_order_no;
         p_relationshiptype (rec_num).insurednotype :=
            v_relationship.insurednotype;
         p_relationshiptype (rec_num).insuredno := v_relationship.insuredno;
         p_relationshiptype (rec_num).firstname := v_relationship.firstname;
         p_relationshiptype (rec_num).surname := v_relationship.surname;
         p_relationshiptype (rec_num).gender := v_relationship.gender;
         p_relationshiptype (rec_num).dateofbirth :=
            v_relationship.dateofbirth;
         p_relationshiptype (rec_num).relationship :=
            v_relationship.relationship;
         p_relationshiptype (rec_num).mobilephone :=
            v_relationship.mobilephone;
         p_relationshiptype (rec_num).email := v_relationship.email;

         rec_num := rec_num + 1;
      END LOOP;
   END;

   PROCEDURE setItemRec (p_itemRec koc_clm_hlth_item_detail%ROWTYPE)
   IS
      i   NUMBER;
   BEGIN
      IF p_itemRec.ubb_code IS NOT NULL
      THEN
         i := itemRec.COUNT + 1;

         itemRec (i).claim_id := p_itemRec.claim_id;
         itemRec (i).sf_no := p_itemRec.sf_no;
         itemRec (i).location_code := p_itemRec.location_code;
         itemRec (i).add_order_no := p_itemRec.add_order_no;
         itemRec (i).cover_code := p_itemRec.cover_code;
         itemRec (i).ubb_code := p_itemRec.ubb_code;
         itemRec (i).quantity := p_itemRec.quantity;
         itemRec (i).price := p_itemRec.price;
         itemRec (i).item_type := p_itemRec.item_type;
         itemRec (i).drg_code := p_itemRec.drg_code;
         itemRec (i).order_no := p_itemRec.order_no;
         itemRec (i).surgery_id := p_itemRec.surgery_id;
         itemRec (i).vat_rate := p_itemRec.vat_rate;
         itemRec (i).explanation := p_itemRec.explanation;
         itemRec (i).status_code := p_itemRec.status_code;
         itemRec (i).time_stamp := p_itemRec.time_stamp;
         itemRec (i).seq_no := p_itemRec.seq_no;
         itemRec (i).bre_result_code := p_itemRec.bre_result_code;
         itemRec (i).process_code := p_itemRec.process_code;
         itemRec (i).process_code_list := p_itemRec.process_code_list;
         itemRec (i).REQ_ITEM_NAME := p_itemRec.REQ_ITEM_NAME;
         itemRec (i).REQ_ITEM_UBBCODE := p_itemRec.REQ_ITEM_UBBCODE;
      END IF;
   END;


   PROCEDURE getItemRec (p_itemRec OUT itemTyp)
   IS
   BEGIN
      p_itemRec := itemRec;
   END;

   PROCEDURE emptyItemRec
   IS
   BEGIN
      itemRec.DELETE;
   END;

   PROCEDURE get_item_detail_data (
      p_claim_id       IN     NUMBER,
      P_sf_no          IN     NUMBER,
      p_add_order_no   IN     NUMBER,
      p_item_list         OUT KOC_CLM_HLTH_TRNX.clmItemIndemType)
   IS
      CURSOR c_item (
         cp_claim_id        koc_clm_hlth_item_detail.claim_id%TYPE,
         cp_sf_no           koc_clm_hlth_item_detail.sf_no%TYPE,
         cp_add_order_no    koc_clm_hlth_item_detail.add_order_no%TYPE)
      IS
         SELECT *
           FROM koc_clm_hlth_item_detail
          WHERE     claim_id = cp_claim_id
                AND sf_no = cp_sf_no
                AND add_order_no = cp_add_order_no;

      rec_num   NUMBER := 0;
   BEGIN
      FOR c_item_rec IN c_item (p_claim_id, P_sf_no, p_add_order_no)
      LOOP
         rec_num := rec_num + 1;

         p_item_list (rec_num).claim_id := c_item_rec.claim_id;
         p_item_list (rec_num).sf_no := c_item_rec.sf_no;
         p_item_list (rec_num).location_code := c_item_rec.location_code;
         p_item_list (rec_num).add_order_no := c_item_rec.add_order_no;
         p_item_list (rec_num).cover_code := c_item_rec.cover_code;
         p_item_list (rec_num).ubb_code := c_item_rec.ubb_code;
         p_item_list (rec_num).quantity := c_item_rec.quantity;
         p_item_list (rec_num).price := c_item_rec.price;
         p_item_list (rec_num).item_type := c_item_rec.item_type;
         p_item_list (rec_num).drg_code := c_item_rec.drg_code;
         p_item_list (rec_num).order_no := c_item_rec.order_no;
         p_item_list (rec_num).surgery_id := c_item_rec.surgery_id;
         p_item_list (rec_num).vat_rate := c_item_rec.vat_rate;
         p_item_list (rec_num).explanation := c_item_rec.explanation;
         p_item_list (rec_num).status_code := c_item_rec.status_code;
         p_item_list (rec_num).time_stamp := c_item_rec.time_stamp;
         p_item_list (rec_num).seq_no := c_item_rec.seq_no;
         p_item_list (rec_num).bre_result_code := c_item_rec.bre_result_code;
         p_item_list (rec_num).process_code := c_item_rec.process_code;
         p_item_list (rec_num).process_code_list :=
            c_item_rec.process_code_list;
      END LOOP;
   END;

   --========
   PROCEDURE transerItemDataToSession (p_claim_id        NUMBER,
                                       p_sf_no           NUMBER,
                                       p_add_order_no    NUMBER)
   IS
   BEGIN
      --session da deger kaldiysa once o bilgiler silinir.
      DELETE koc_clm_hlth_tmp_item_detail
       WHERE     claim_id = p_claim_id
             AND sf_no = p_sf_no
             AND add_order_no = p_add_order_no;

      INSERT INTO koc_clm_hlth_tmp_item_detail (claim_id,
                                                sf_no,
                                                location_code,
                                                add_order_no,
                                                cover_code,
                                                ubb_code,
                                                quantity,
                                                price,
                                                item_type,
                                                drg_code,
                                                order_no,
                                                surgery_id,
                                                vat_rate,
                                                explanation,
                                                status_code,
                                                time_stamp,
                                                seq_no,
                                                bre_result_code,
                                                process_code,
                                                process_code_list,
                                                REQ_ITEM_NAME,
                                                REQ_ITEM_UBBCODE)
         SELECT claim_id,
                sf_no,
                location_code,
                add_order_no,
                cover_code,
                ubb_code,
                quantity,
                price,
                item_type,
                drg_code,
                order_no,
                surgery_id,
                vat_rate,
                explanation,
                status_code,
                time_stamp,
                seq_no,
                bre_result_code,
                process_code,
                process_code_list,
                REQ_ITEM_NAME,
                REQ_ITEM_UBBCODE
           FROM koc_clm_hlth_item_detail
          WHERE     claim_id = p_claim_id
                AND sf_no = p_sf_no
                AND add_order_no = p_add_order_no;
   END;


   PROCEDURE deleteSessionItemReq (p_claim_id         NUMBER,
                                   p_sf_no            NUMBER,
                                   p_add_order_no     NUMBER,
                                   p_ubb_code         VARCHAR2,
                                   p_location_code    NUMBER,
                                   p_cover_code       VARCHAR2,
                                   p_seq_no           NUMBER)
   IS
   BEGIN
      DELETE koc_clm_hlth_tmp_item_detail
       WHERE     claim_id = p_claim_id
             AND sf_no = p_sf_no
             AND add_order_no = p_add_order_no
             AND ubb_code = p_ubb_code
             AND location_code = p_location_code
             AND cover_code = p_cover_code
             AND seq_no = p_seq_no;
   END;

   PROCEDURE transerSessionItemDataToDB (p_claim_id        NUMBER,
                                         p_sf_no           NUMBER,
                                         p_add_order_no    NUMBER)
   IS
   BEGIN
      DELETE koc_clm_hlth_item_detail
       WHERE     claim_id = p_claim_id
             AND sf_no = p_sf_no
             AND add_order_no = p_add_order_no;

      INSERT INTO koc_clm_hlth_item_detail (claim_id,
                                            sf_no,
                                            location_code,
                                            add_order_no,
                                            cover_code,
                                            ubb_code,
                                            quantity,
                                            price,
                                            item_type,
                                            drg_code,
                                            order_no,
                                            surgery_id,
                                            vat_rate,
                                            explanation,
                                            status_code,
                                            time_stamp,
                                            seq_no,
                                            bre_result_code,
                                            process_code,
                                            process_code_list,
                                            REQ_ITEM_NAME,
                                            REQ_ITEM_UBBCODE)
         SELECT claim_id,
                sf_no,
                location_code,
                add_order_no,
                cover_code,
                ubb_code,
                quantity,
                price,
                item_type,
                drg_code,
                order_no,
                surgery_id,
                vat_rate,
                explanation,
                status_code,
                time_stamp,
                seq_no,
                bre_result_code,
                process_code,
                process_code_list,
                REQ_ITEM_NAME,
                REQ_ITEM_UBBCODE
           FROM koc_clm_hlth_tmp_item_detail
          WHERE     claim_id = p_claim_id
                AND sf_no = p_sf_no
                AND add_order_no = p_add_order_no;
   END;

   PROCEDURE deleteCoverItems (p_claim_id         NUMBER,
                               p_sf_no            NUMBER,
                               p_add_order_no     NUMBER,
                               p_location_code    NUMBER,
                               p_cover_code       VARCHAR2)
   IS
   BEGIN
      DELETE koc_clm_hlth_tmp_item_detail
       WHERE     claim_id = p_claim_id
             AND sf_no = p_sf_no
             AND add_order_no = p_add_order_no
             AND cover_code = p_cover_code
             AND location_code = p_location_code;
   END;

   PROCEDURE insertSessionItems (
      p_clmItemIndemType koc_clm_hlth_item_detail%ROWTYPE)
   IS
      CURSOR c_has
      IS
         SELECT 1
           FROM koc_clm_hlth_tmp_item_detail
          WHERE     claim_id = p_clmItemIndemType.claim_id
                AND sf_no = p_clmItemIndemType.sf_no
                AND location_code = p_clmItemIndemType.location_code
                AND add_order_no = p_clmItemIndemType.add_order_no
                AND cover_code = p_clmItemIndemType.cover_code
                AND ubb_code = p_clmItemIndemType.ubb_code
                AND seq_no = p_clmItemIndemType.seq_no;

      row_has   c_has%ROWTYPE;
   BEGIN
      OPEN c_has;

      FETCH c_has INTO row_has;

      IF c_has%NOTFOUND
      THEN
         INSERT INTO koc_clm_hlth_tmp_item_detail (claim_id,
                                                   sf_no,
                                                   location_code,
                                                   add_order_no,
                                                   cover_code,
                                                   ubb_code,
                                                   quantity,
                                                   price,
                                                   item_type,
                                                   drg_code,
                                                   order_no,
                                                   surgery_id,
                                                   vat_rate,
                                                   explanation,
                                                   status_code,
                                                   time_stamp,
                                                   seq_no,
                                                   bre_result_code,
                                                   process_code,
                                                   process_code_list,
                                                   REQ_ITEM_NAME,
                                                   REQ_ITEM_UBBCODE)
              VALUES (p_clmItemIndemType.claim_id,
                      p_clmItemIndemType.sf_no,
                      p_clmItemIndemType.location_code,
                      p_clmItemIndemType.add_order_no,
                      p_clmItemIndemType.cover_code,
                      p_clmItemIndemType.ubb_code,
                      p_clmItemIndemType.quantity,
                      p_clmItemIndemType.price,
                      p_clmItemIndemType.item_type,
                      p_clmItemIndemType.drg_code,
                      p_clmItemIndemType.order_no,
                      p_clmItemIndemType.surgery_id,
                      p_clmItemIndemType.vat_rate,
                      p_clmItemIndemType.explanation,
                      p_clmItemIndemType.status_code,
                      p_clmItemIndemType.time_stamp,
                      p_clmItemIndemType.seq_no,
                      p_clmItemIndemType.bre_result_code,
                      p_clmItemIndemType.process_code,
                      p_clmItemIndemType.process_code_list,
                      p_clmItemIndemType.REQ_ITEM_NAME,
                      p_clmItemIndemType.REQ_ITEM_UBBCODE);
      ELSE
         UPDATE koc_clm_hlth_tmp_item_detail
            SET quantity = p_clmItemIndemType.quantity,
                price = p_clmItemIndemType.price,
                item_type = p_clmItemIndemType.item_type,
                drg_code = p_clmItemIndemType.drg_code,
                order_no = p_clmItemIndemType.order_no,
                surgery_id = p_clmItemIndemType.surgery_id,
                vat_rate = p_clmItemIndemType.vat_rate,
                explanation = p_clmItemIndemType.explanation,
                status_code = p_clmItemIndemType.status_code,
                time_stamp = p_clmItemIndemType.time_stamp,
                seq_no = p_clmItemIndemType.seq_no,
                bre_result_code = p_clmItemIndemType.bre_result_code,
                process_code = p_clmItemIndemType.process_code,
                process_code_list = p_clmItemIndemType.process_code_list
          WHERE     claim_id = p_clmItemIndemType.claim_id
                AND sf_no = p_clmItemIndemType.sf_no
                AND location_code = p_clmItemIndemType.location_code
                AND add_order_no = p_clmItemIndemType.add_order_no
                AND cover_code = p_clmItemIndemType.cover_code
                AND ubb_code = p_clmItemIndemType.ubb_code
                AND seq_no = p_clmItemIndemType.seq_no;
      END IF;
   END;

   --ubb koduna g�re malzeme ad� bilgisi d�ner
   FUNCTION getitemdesc (p_ubb_code VARCHAR2, p_date DATE DEFAULT SYSDATE)
      RETURN VARCHAR2
   IS
      v_item_name   VARCHAR2 (500);
   BEGIN
      BEGIN
         SELECT material_name
           INTO v_item_name
           FROM koc_hlth_gmdn_ubb_list u
          WHERE u.ubb_code = p_ubb_code    --and validity_start_date <= p_date
                                       --and nvl(validity_end_date, p_date) >= p_date
         ;

         RETURN v_item_name;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            RETURN 'Malzeme Ad� Bilgisi bulunamad�.';
         WHEN TOO_MANY_ROWS
         THEN
            SELECT material_name
              INTO v_item_name
              FROM koc_hlth_gmdn_ubb_list u
             WHERE u.ubb_code = p_ubb_code --and validity_start_date <= p_date
                                           --and nvl(validity_end_date, p_date) >= p_date
                   AND ROWNUM = 1;

            RETURN v_item_name;
         WHEN OTHERS
         THEN
            RETURN 'Malzeme Ad� Bilgisi bulunurken hata.';
      END;
   EXCEPTION
      WHEN OTHERS
      THEN
         NULL;
   END;
END;
/
