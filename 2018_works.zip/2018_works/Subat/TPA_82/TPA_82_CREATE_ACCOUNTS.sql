DECLARE
 v_internal_account_id NUMBER;
 v_desc_int_id         NUMBER;
 v_err VARCHAR2(4000);
 
 PROCEDURE define_account(p_internal_account_id IN NUMBER, 
                          p_desc_int_id IN NUMBER, 
                          p_account_category_code VARCHAR2,
                          p_sf_1 IN VARCHAR2,
                          p_sf_2 IN VARCHAR2,
                          p_sf_3 IN VARCHAR2,
                          p_sf_4 IN VARCHAR2,
                          p_acc_ref_code IN VARCHAR2,
                          p_desc IN VARCHAR2)     
 IS
    v_acc_ref_code VARCHAR2(100) := p_acc_ref_code;
 BEGIN
    insert into ac_internal_accounts 
    (INTERNAL_ACCOUNT_ID, COMPANY_ID, SWIFT_CODE, ACCOUNT_CATEGORY_CODE, SUBFACTOR_1_VAL, SUBFACTOR_2_VAL, SUBFACTOR_3_VAL, SUBFACTOR_4_VAL, 
     EXPL_GL_MPNG_ONLY_IND, AUTO_ASSIGN_ACCT_IND, GL_MPNG_ACCT_IND, CREATION_DATE, SUBFACTOR_1_EXTN_VAL, SUBFACTOR_2_EXTN_VAL, SUBFACTOR_3_EXTN_VAL, SUBFACTOR_4_EXTN_VAL)
    values (p_internal_account_id,4, 'TL', p_account_category_code, p_sf_1, p_sf_2, p_sf_3, p_sf_4, 'N', 'N', 'N', to_date('01-01-2017', 'dd-mm-yyyy'), p_sf_1, p_sf_2, p_sf_3, p_sf_4);
    
    insert into OPUS_CORE.AC_GL_SYSTEM_REFS (DESC_INT_ID,GL_ACCT_REF_CODE, GL_SYS_CODE, DETAIL_EXTRACT_IND) values (p_desc_int_id, p_acc_ref_code, 'ORAF','N');
    
    insert into ac_gl_mappings (INTERNAL_ACCOUNT_ID, GL_ACCT_REF_CODE, GL_SYS_CODE, VERSION_NO, START_DATE, CONTROL_ACCOUNT_ID, DERIVED_ACCOUNT, END_DATE)
    values (p_internal_account_id, p_acc_ref_code, 'ORAF', 1, to_date('01-01-2017', 'dd-mm-yyyy'), null, null, null);-- -999- kullan�c� verecek

    UPDATE OPUS_CORE.DESCRIPTIONS
    SET INT_ID = p_desc_int_id,
        JOIN_TABLE = 'AC_GL_SYSTEM_REFS'
    WHERE INT_ID = p_desc_int_id
    AND JOIN_TABLE = 'AC_GL_SYSTEM_REFS';
    
    IF SQL%NOTFOUND THEN
        insert into OPUS_CORE.DESCRIPTIONS (INT_ID, JOIN_TABLE) values (p_desc_int_id, 'AC_GL_SYSTEM_REFS');
    END IF;
    
    insert into Cur_Translations (DESC_INT_ID,SULA_ORA_NLS_CODE,  SHORT_CODE, LONG_NAME, COMMENTS)
    values (p_desc_int_id,'TR', v_acc_ref_code, p_desc, null);
    
    insert into alz_account_sap_attribute(account_code, 
                                          posting_key_debit, 
                                          posting_key_credit,
                                          sap_account,
                                          account_category_code,
                                          has_trading_partner,
                                          has_sub_item,
                                          has_dist_channel,
                                          has_date_of_loss,
                                          has_region,
                                          has_cost_center,
                                          has_invoice_no,
                                          has_invoice_date,
                                          has_vendor_name,
                                          has_lob,
                                          has_customer_segment,
                                          check_mandatory_fields,
                                          account_sap_type,
                                          internal_account_id,
                                          sub_account_category,
                                          sap_oper_account,
                                          process_date,
                                          account_swf_code)
    values(p_acc_ref_code, 40, 50, p_acc_ref_code,  p_account_category_code,
           0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 'GL', 
           p_internal_account_id,
           p_account_category_code,
           '6111101090',
           to_date('15-01-2012', 'dd-mm-yyyy'),
           'TL');

    COMMIT;

 END;

BEGIN
   select max(INTERNAL_ACCOUNT_ID)+1 maxINTERNAL_ACCOUNT_ID 
     into v_internal_account_id
     from ac_internal_accounts t;

   select max(DESC_INT_ID)+1 maxDESC_INT_ID 
     into v_desc_int_id
     from Cur_Translations t;
     
      define_account(v_internal_account_id, 
                    v_desc_int_id,
                    'YIBNR02211',
                    '85',
                    '05',
                    '',
                    '',
                    '7850221136',
                    'IBNR');
                    
EXCEPTION
WHEN OTHERS THEN
  v_err := dbms_utility.format_error_stack|| 
           dbms_utility.format_error_backtrace||'desc_int_id='||v_desc_int_id||' account_id = '||v_internal_account_id;
  
  DBMS_OUTPUT.PUT_LINE(v_err);
  
END;
/


