    select t.ticket_date,t.ext_reference,t.trans_no,t.trans_amt,t.swift_code,t.currency_exchange_rate,t.date_of_loss,
                 t.cover_code,c.explanation Explanation,t.provision_date,t.Oar_No,t.Partner_name,t.Type_Of_Interest,
                 t.claim_inst_type,t.cover_cat_group,t.Supp_id,t.Comm_date,t.invoice_date,t.product_id,t.group_code,t.partition_type,
                 t.policy_ref,t.term_start_date,t.term_end_date,t.signature_date,t.reference_code,x.title title,(CASE WHEN NVL(d.is_ex_gratia,0) = 1 THEN 'EVET' ELSE '' END) EXGRATIA, NVL(d.ex_gratia_fee,0) EXGRATIA_FEE
             from koc_clm_bordro_rep t ,koc_v_cover c,Koc_Dmt_Agents_Ext x,koc_clm_hlth_detail d
             where t.agent_role = x.int_id(+)
             and t.cover_code  = c.cover_code(+)
             and t.claim_id = d.claim_id
             and t.sf_no = d.sf_no
             and t.add_order_no = d.add_order_no
             and t.ticket_date Between to_date('01/02/2018','dd/mm/yyyy') and to_date('28/02/2018','dd/mm/yyyy')
            -- and x.company_code = '777'
            
             select * from koc_clm_bordro_rep where ticket_date = to_date('01/02/2018','DD/MM/YYYY')
             
             select * from koc_clm_hlth_detail where claim_id = 33428653
             
             select * from all_source where lower(text) like '%into%koc_clm_bordro_rep%'
             
             
             
        SELECT *--max(bordro_date)
        FROM   KOC_CLM_HLTH_BORDRO_MONTH
        WHERE  1=1-- order_no= p_order_no
        and    bordro_date = last_day(SYSDATE-30);
