DECLARE  
    v_Companies_Def             ALZ_TPA_DEFINITION_UTILS.T_Companies_Def;
    v_Img_Parameters_Def        ALZ_TPA_DEFINITION_UTILS.T_Img_Parameters_Def;
    v_Tpa_Parameters_Def        ALZ_TPA_DEFINITION_UTILS.T_Tpa_Parameters_Def;
    v_Tpa_Prod_Payment_Rel_Def  ALZ_TPA_DEFINITION_UTILS.T_Tpa_Prod_Payment_Rel_Def;
    v_Template_Seq number;
    v_AT_Package_Id number;
    v_YT_Package_Id number;
    v_HD_Package_Id number;

    v_AT_Template_Seq number;
    v_YT_Template_Seq number;
    v_HD_Template_Seq number;

    v_Dummy_Package_Id number;
    v_ref_company_code         VARCHAR2(10) := '777'; -- Fiba
  Begin
    delete from CUSTOMER.ALZ_TPA_DEFINITION_ERROR t;
    commit;
    
    ALZ_TPA_DEFINITION_UTILS.vp_Company_Code     := '018';
    ALZ_TPA_DEFINITION_UTILS.vp_Merkez_Reference_Code   := '80000';
    ALZ_TPA_DEFINITION_UTILS.vp_Partition_Type   := 'TSSZ';
    ALZ_TPA_DEFINITION_UTILS.vp_Product_Id       := 63;
    ALZ_TPA_DEFINITION_UTILS.vp_Start_Date       := To_Date('01.02.2018', 'DD.MM.YYYY');

    v_Companies_Def.Validity_Start_Date          := ALZ_TPA_DEFINITION_UTILS.vp_Start_Date;
    v_Companies_Def.Company_Title                := 'ZURICH S�GORTA A.�.';
    v_Companies_Def.Company_Short_Name           := 'Zurich Sigorta';
    v_Companies_Def.Partition_Type               :=  ALZ_TPA_DEFINITION_UTILS.vp_Partition_Type;
    v_Companies_Def.Partition_Description        := 'ZurichTamSa�l�k';
    v_Companies_Def.Partition_Description_Us     := 'ZurichTamSa�l�k';
    v_Companies_Def.Main_Partition_Type          := 'TSS';
    v_Companies_Def.Company_Code                 := '045';
    v_Companies_Def.Tpa_Company_Code             :=  ALZ_TPA_DEFINITION_UTILS.vp_Company_Code;
    v_Companies_Def.Region_Code                  := '100';
    v_Companies_Def.Sap_Dist_Channel             := '76';
    v_Companies_Def.User_Prefix                  := 'ZRCH';
    v_Companies_Def.Tobb_Ws_User                 := Null;
    v_Companies_Def.SagmerTarifeKodu_Exp         := '8882'; 
    -----------------------
    -- yeni �irkette kontrol et
    -----------------------
    v_Companies_Def.Policy_Counter_Location_Code := '0003';
    v_Companies_Def.Policy_Counter_Seperator1    := '07';
    v_Companies_Def.Policy_Counter_Seperator2_1  := '0';
    v_Companies_Def.Policy_Counter_Seperator2_2  := '1';
    v_Companies_Def.Policy_Counter_Counter       :=  1;
    ------------------------------------------------------
    ALZ_TPA_DEFINITION_UTILS.Crt_Tpa_Sirket(v_Companies_Def);
    ------------------------------------------------------
    v_Img_Parameters_Def.Company_Code        := ALZ_TPA_DEFINITION_UTILS.vp_Company_Code;
    v_Img_Parameters_Def.Product_Id          := ALZ_TPA_DEFINITION_UTILS.vp_Product_Id;
    v_Img_Parameters_Def.Partition_Type      := ALZ_TPA_DEFINITION_UTILS.vp_Partition_Type;
    v_Img_Parameters_Def.Validity_Start_Date := ALZ_TPA_DEFINITION_UTILS.vp_Start_Date;
    v_Img_Parameters_Def.Validity_End_Date   := Null;
    ------------------------------------------------------
    --ALZ_TPA_DEFINITION_UTILS.Crt_Tpa_Img_Parameters(v_Img_Parameters_Def);
    ------------------------------------------------------
    INSERT INTO ALZ_TPA_IMG_PARAMETERS(COMPANY_CODE,
                                        PRODUCT_ID,
                                        PARTITION_TYPE,
                                        PARAMETER_TYPE,
                                        IMAGE,
                                        VALIDITY_START_DATE,
                                        VALIDITY_END_DATE,                  
                                        GROUP_CODE
    )
    SELECT ALZ_TPA_DEFINITION_UTILS.vp_Company_Code COMPANY_CODE,
           PRODUCT_ID,
           PARTITION_TYPE,       
           PARAMETER_TYPE,
           IMAGE,   
           TO_DATE('01/02/2018','DD/MM/YYYY') VALIDITY_START_DATE,
           VALIDITY_END_DATE,                  
           GROUP_CODE
      FROM ALZ_TPA_IMG_PARAMETERS
     WHERE company_code = v_ref_company_code;
    ------------------------------------------------------
    --ALZ_TPA_DEFINITION_UTILS.Crt_Tpa_Parameters(v_Tpa_Parameters_Def); Fibadan kopyalan�p de�i�enler update edilecek.
    v_Tpa_Parameters_Def.Address_1             := 'Orjin Plaza Maslak Mahallesi Eski B�y�kdere Cad. No: 27 Kat: 12-13 Sar�yer 34398 �STANBUL';
    v_Tpa_Parameters_Def.Tax_Number            := '9999999999';
    v_Tpa_Parameters_Def.Trade_Name            := 'Zurich Sigorta A.�.';
    v_Tpa_Parameters_Def.Trade_Registry        := '372142';
    v_Tpa_Parameters_Def.Website_Url           := 'www.zurichsigorta.com.tr';
    
    INSERT INTO ALZ_TPA_PARAMETERS  
    SELECT ALZ_TPA_DEFINITION_UTILS.vp_Company_Code COMPANY_CODE,
           PRODUCT_ID,
           PARTITION_TYPE,
           PARAMETER_TYPE,
           TO_DATE('01/02/2018','DD/MM/YYYY') VALIDITY_START_DATE,
           VALIDITY_END_DATE,
           DESC_INT_ID,        
           CASE PARAMETER_TYPE
                WHEN 'WEBSITE_URL' THEN v_Tpa_Parameters_Def.Website_Url
                WHEN 'TRADE_NAME'  THEN v_Tpa_Parameters_Def.Trade_Name
                WHEN 'TRADE_REGISTRY' THEN  v_Tpa_Parameters_Def.Trade_Registry
                WHEN 'TAX_NUMBER' THEN  v_Tpa_Parameters_Def.Tax_Number
                WHEN 'ADDRESS_1' THEN  v_Tpa_Parameters_Def.Address_1          
                ELSE PARAMETER_VALUE          
           END PARAMETER_VALUE,
           GROUP_CODE
      FROM ALZ_TPA_PARAMETERS
     WHERE company_code = v_ref_company_code
       AND PARAMETER_TYPE NOT IN('PROVISION_CARE_PHONE','PROVISION_YKS_PHONE');
    ------------------------------------------------------
    v_Tpa_Prod_Payment_Rel_Def.Validity_Start_Date := ALZ_TPA_DEFINITION_UTILS.vp_Start_Date;
    v_Tpa_Prod_Payment_Rel_Def.Partition_Type      := ALZ_TPA_DEFINITION_UTILS.vp_Partition_Type;
    v_Tpa_Prod_Payment_Rel_Def.Product_Id          := ALZ_TPA_DEFINITION_UTILS.vp_Product_Id;
    v_Tpa_Prod_Payment_Rel_Def.Username            := User;
    ------------------------------------------------------
    ALZ_TPA_DEFINITION_UTILS.Crt_Tpa_Prod_Payment_Rel(v_Tpa_Prod_Payment_Rel_Def);
    ------------------------------------------------------
    ALZ_TPA_DEFINITION_UTILS.Crt_Indirim_Tanimlari;
    ------------------------------------------------------
    --ALZ_TPA_DEFINITION_UTILS.Gnl_Estp_Indirim_Tanimlari; --gerek yok
    ------------------------------------------------------
    --ALZ_TPA_DEFINITION_UTILS.Gnl_Tpak_Insert_Tanimlari; -- gerek yok
    ------------------------------------------------------
    ALZ_TPA_DEFINITION_UTILS.Crt_Tpa_Indirim_Tanimlari;
    ------------------------------------------------------
    ALZ_TPA_DEFINITION_UTILS.Crt_ESTP_Update;
    ------------------------------------------------------
    --Select Koc_Oc_Hlth_Templates_Seq.Nextval Into v_YT_Template_Seq From Dual;
    Select Koc_Oc_Hlth_Templates_Seq.Nextval Into v_AT_Template_Seq From Dual;
    --Select Koc_Oc_Hlth_Templates_Seq.Nextval Into v_HD_Template_Seq From Dual;

    ------------------------------------------------------
    ALZ_TPA_DEFINITION_UTILS.Crt_Tpa_Yt_Plan_Olusturulmasi(v_AT_Template_Seq, v_YT_Package_Id);
    ------------------------------------------------------
    ALZ_TPA_DEFINITION_UTILS.Crt_Tpa_At_Plan_Olusturulmasi(v_AT_Template_Seq, v_AT_Package_Id);
    ------------------------------------------------------
    ALZ_TPA_DEFINITION_UTILS.Crt_Tpa_Hd_Plan_Olusturulmasi(v_HD_Package_Id);
    ------------------------------------------------------
    ALZ_TPA_DEFINITION_UTILS.Crt_Dummy_Plan_Olusturulmasi(v_Dummy_Package_Id);
    ------------------------------------------------------
    ALZ_TPA_DEFINITION_UTILS.Crt_Hazal_Indirimler(v_AT_Package_Id,v_YT_Package_Id,v_HD_Package_Id,v_Dummy_Package_Id);
    ------------------------------------------------------
    ALZ_TPA_DEFINITION_UTILS.Crt_Beyan_Duzenle;
    ------------------------------------------------------
    ALZ_TPA_DEFINITION_UTILS.Crt_Basvuru_Ve_Bilgilendirme;
    ------------------------------------------------------
    --ALZ_TPA_DEFINITION_UTILS.Crt_Koc_Ac_Bank_Member_Ref_Ins;--insert select 100
    Insert Into Customer.Koc_Ac_Bank_Member_Ref
      (Bank_Code,
       Bank_Account_Code,
       Bank_Member_Id,
       Explanation,
       Validity_Start_Date,
       Validity_End_Date,
       Parameter1,
       Parameter2,
       Parameter3,
       Parameter4,
       Using_System,
       Company_Code,
       Pos_Type)
      Select Bank_Code,
             Bank_Account_Code,
             Bank_Member_Id,
             Explanation,
             Validity_Start_Date,
             Validity_End_Date,
             Parameter1,
             Parameter2,
             Parameter3,
             Parameter4,
             Using_System,
             ALZ_TPA_DEFINITION_UTILS.vp_Company_Code COMPANY_CODE,
             Pos_Type
        From Customer.Koc_Ac_Bank_Member_Ref
       Where Company_Code = v_ref_company_code;
    ------------------------------------------------------
    ALZ_TPA_DEFINITION_UTILS.Crt_Alz_Acc_Bank_Method_Defins;
    ------------------------------------------------------
    --ALZ_TPA_DEFINITION_UTILS.Crt_Koc_Mis_Agent_Group_Refins; --gerek yok
    ------------------------------------------------------
    ALZ_TPA_DEFINITION_UTILS.Crt_Alz_Tpa_Company_Misrel_Ins;
    ------------------------------------------------------
    --ALZ_TPA_DEFINITION_UTILS.Crt_Koc_Dmt_Region_Coderef_Ins; --insert select 100 Z�R�CH
    INSERT INTO Alz_Sap_Dist_Channel_Ref
    select v_Companies_Def.Sap_Dist_Channel SAP_DIST_CHANNEL,
           'TPA ZURICH' EXPANATION,
           VALIDITY_END_DATE,
           COMM_GRP_REF,
           COMM_GRP_EXP  
      from Alz_Sap_Dist_Channel_Ref
     where sap_dist_channel=75;
    ------------------------------------------------------
    ALZ_TPA_DEFINITION_UTILS.Crt_Alz_Web_Action_Def_Insert;
    ------------------------------------------------------
    ALZ_TPA_DEFINITION_UTILS.Crt_Koc_Oc_Hlth_Spec_Cond_Docs;
    ------------------------------------------------------
    --ALZ_TPA_DEFINITION_UTILS.Crt_Dashboard_Yetki_Hiyerarsi; --gerek yok 
    ------------------------------------------------------
    --ALZ_TPA_DEFINITION_UTILS.Crt_Koc_Oc_Clauses_All; -- gerek yok
    ------------------------------------------------------
   /* ALZ_TPA_DEFINITION_UTILS.Crt_Tpa_Clauses_1;
    ALZ_TPA_DEFINITION_UTILS. Crt_Tpa_Clauses_2(v_Dummy_Package_Id);
    ALZ_TPA_DEFINITION_UTILS.Crt_Tpa_Clauses_3;*/ --gerek yok
    ------------------------------------------------------
    --ALZ_TPA_DEFINITION_UTILS.Crt_Tpa_Koc_Cp_Health_Look_Up; Z�rih �zel �art�
    INSERT INTO Customer.Koc_Cp_Health_Look_Up
    select LOOK_UP_CODE,'TSSZ' PARAMETER,DESC_INT_ID,
           TO_DATE('01/02/2018','DD/MM/YYYY') VALIDITY_START,VALIDITY_END,'ADEMO' USERID,
           TO_DATE('01/02/2018','DD/MM/YYYY') ENTRY_DATE,'Z�rich Sigorta �zel �art�' 
      from Customer.Koc_Cp_Health_Look_Up
      where look_up_code='SPCLCOND'
       and parameter='TSS'; 
    ------------------------------------------------------
    --ALZ_TPA_DEFINITION_UTILS.Crt_Alz_Tpa_Message_Def; insert select
    Insert Into Alz_Tpa_Message_Definitions(Message_Id,
                                            Company_Code,
                                            Message_Name,
                                            --Message_Template,
                                            Validity_Start_Date,
                                            Validity_End_Date,
                                            Create_User_Id,
                                            Update_User_Id)
    Select Message_Id, ALZ_TPA_DEFINITION_UTILS.vp_Company_Code Company_Code, Message_Name, 
           --Message_Template, 
           ALZ_TPA_DEFINITION_UTILS.vp_Start_Date  Validity_Start_Date, Validity_End_Date,
           Create_User_Id, Update_User_Id
      From Alz_Tpa_Message_Definitions
     Where Company_Code = v_ref_company_code;
  End;
