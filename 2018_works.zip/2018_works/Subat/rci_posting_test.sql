  SELECT CASE
            WHEN TO_CHAR (a.date_of_loss, 'YYYY') < '2018'--TO_CHAR ('2018', 'YYYY')
            THEN
               'PRIOR'
            ELSE
               'CURRENT'
         END year_type,
         nvl(mis.sap_dist_channel,'11') sap_dist_channel, -- MYALINKILIC: SAP dist Channel i tan�ms�z olan partajlar i�in 11 no lu partaj� at�yoruZ, Cigdem Cicek e tekrar sorulacak
         NVL (ext.is_industrial, DECODE (a.product_id, 64, 1, 0)) is_industrial,
         /*d_account_code,
         c_account_code,
         g.account_category_code d_account_category_code,
         g1.account_category_code c_account_category_code,
         g.subfactor_1_val,
         g.subfactor_2_val,
         g.subfactor_3_val,
         g.subfactor_4_val,
         g1.subfactor_1_val rel_subfactor_1_val,
         g1.subfactor_2_val rel_subfactor_2_val,
         g1.subfactor_3_val rel_subfactor_3_val,
         g1.subfactor_4_val rel_subfactor_4_val,*/ --ademo.tpa
         TO_CHAR (a.date_of_loss, 'YYYY') date_of_loss_year,
         'TL' swift_code,
         a.product_id,
         NULL partition_type,
         85 acc_cover_code,
         0 collection_company_id,
         0 company_id,
         0 arrangement_id,
         400 trans_sub_type,
         --'TAHAKKUK EDEN S�GORTALI DIREKT REASURANS MUALLAK' description,
         CASE WHEN NVL(mis.company_code,'045') = '045' THEN 'OSCG' ELSE 'IOSCG' END OC_TYPE, --ademo.tpa
         SUM (trans_amt) amount_tl
    FROM koc_clm_muallak_bordro_rep a,
         koc_ocp_pol_versions_ext ext,
         /*alz_rci_oc_account_def F,
         koc_acc_v_internal_accounts G,
         koc_acc_v_internal_accounts G1,*/ --ademo.tpa
         (SELECT ax.region_code,
                 bx.mis_main_group,
                 bx.mis_sub_group,
                 ax.validity_end_date,
                 ax.int_id,
                 bx.sap_dist_channel,
                 bx.company_code --ademo.tpa
            FROM koc_dmt_agents_region_ext ax,
                 koc_dmt_agents_ext bx,
                 koc_mis_agent_group_ref cx
           WHERE     ax.validity_start_date =
                        (SELECT MAX (x.validity_start_date)
                           FROM koc_dmt_agents_region_ext x
                          WHERE x.int_id = ax.int_id)
                 AND bx.int_id = ax.int_id
                 AND cx.mis_main_group = bx.mis_main_group
                 AND cx.mis_sub_group = bx.mis_sub_group) mis
   WHERE     sf_type = 'HLT'
         AND ticket_date = TO_DATE('31.01.2018','DD.MM.YYYY')
         AND a.contract_id = ext.contract_id
         AND ext.version_no = 1
--         AND a.Claim_Id = extr.Claim_Id
--         AND a.Sf_No = extr.Sf_No
--         AND a.Trans_No = extr.Trans_No
         AND CASE
                WHEN TO_CHAR (a.date_of_loss, 'YYYY') < '2018'--TO_CHAR ('2018', 'YYYY')
                THEN 'PRIOR'
                ELSE 'CURRENT'
             END IN('CURRENT','PRIOR') --= f.year_type --ademo.tpa
         /*AND f.OC_TYPE = 'M'                                         --MUALLAK
         AND g.gl_acct_ref_code = f.d_account_code
         AND g1.gl_acct_ref_code = f.c_account_code*/
         AND a.agent_role = mis.int_id(+)
         AND a.term_end_date < mis.validity_end_date(+)
GROUP BY CASE
            WHEN TO_CHAR (a.date_of_loss, 'YYYY') < '2018'--TO_CHAR ('2018', 'YYYY')
            THEN 'PRIOR'
            ELSE 'CURRENT'
         END,
         NVL (ext.is_industrial, DECODE (a.product_id, 64, 1, 0)),
         mis.sap_dist_channel,
         /*d_account_code,
         c_account_code,
         g.ACCOUNT_CATEGORY_CODE,
         g1.account_category_code,
         g.subfactor_1_val,
         g.subfactor_2_val,
         g.subfactor_3_val,
         g.subfactor_4_val,
         g1.subfactor_1_val,
         g1.subfactor_2_val,
         g1.subfactor_3_val,
         g1.subfactor_4_val,*/ --ademo.tpa
         TO_CHAR (a.date_of_loss, 'YYYY'),
         a.product_id,
         CASE WHEN NVL(mis.company_code,'045') = '045' THEN 'OSCG' ELSE 'IOSCG' END --ademo.tpa
        UNION ALL
SELECT CASE
                    WHEN TO_CHAR (a.FILE_OPEN_DATE, 'YYYY') < '2018'
                    -- TO_CHAR ( &pc_date, 'YYYY')
                    THEN
                       'PRIOR'
                    ELSE
                       'CURRENT'
                 END
                    YEAR_TYPE,
                 NVL (c.sap_dist_channel, 11) sap_dist_channel,
                 NVL (c.is_industrial, 0) is_industrial,
                 /*d_account_code,
                 c_account_code,
                 g.account_category_code d_account_category_code,
                 g1.account_category_code c_account_category_code,
                 g.subfactor_1_val,
                 g.subfactor_2_val,
                 g.subfactor_3_val,
                 g.subfactor_4_val,
                 g1.subfactor_1_val rel_subfactor_1_val,
                 g1.subfactor_2_val rel_subfactor_2_val,
                 g1.subfactor_3_val rel_subfactor_3_val,
                 g1.subfactor_4_val rel_subfactor_4_val,*/
                 TO_CHAR (A.FILE_OPEN_DATE, 'YYYY') date_of_loss_year,
                 NVL (d.swift_code, 'TL') swift_code,
                 c.product_id,
                 NULL partititon_type,
                 85 acc_cover_code,
                 0 collection_company_id,
                 0 company_id,
                 0 arrangement_id,
                 400 trans_sub_type,
                 /*CASE
                    WHEN TO_CHAR (A.FILE_OPEN_DATE, 'YYYY') <
                            TO_CHAR (ADD_MONTHS (&pc_date, -1), 'YYYY')
                    THEN
                          'DAV.MUALLAK GROSS ONCEKI YIL BIR. '
                       || TO_CHAR (&pc_date, 'MMYYYY')
                    ELSE
                          'DAV.MUALLAK GROSS CARI YIL END. '
                       || TO_CHAR (&pc_date, 'MMYYYY')
                 END
                    description,*/
                 CASE WHEN NVL(c.company_code,'045') = '045' THEN 'OSCGL' ELSE 'IOSCGL' END OC_TYPE, --ademo.tpa
                 ROUND (SUM (case when sign(amount-paid-returned)>0 then amount-paid-returned else 0 end), 2)*-1 amount_tl
FROM koc_law_bases a,
                 koc_law_bases_detail b,
                 (SELECT a.policy_ref,
                         a.contract_id,
                         NVL (d.product_id, 63) product_id,
                         NVL (is_industrial, DECODE (d.product_id,  64, 1,  63, 0))
                            is_industrial,
                         b.sap_dist_channel,
                         b.company_code --ademo.tpa
                    FROM ocp_policy_bases a,
                         koc_dmt_agents_ext b,
                         koc_ocp_pol_versions_ext c,
                         ocp_policy_contracts d
                   WHERE     a.agent_role = b.int_id
                         AND a.contract_id = c.contract_id
                         AND a.contract_id = d.contract_id
                         AND c.version_no = 1
                         AND a.version_no = 1) c,
                 alz_law_reserve_history d/*,
                 alz_rci_oc_account_def F,
                 koc_acc_v_internal_accounts G,
                 koc_acc_v_internal_accounts G1*/
           WHERE     a.law_file_no = b.law_file_no
                 AND a.law_file_no = d.law_file_no
                 AND b.detail_no=d.detail_no
                 AND a.law_sf_type = 'S'
                 AND b.policy_ref = c.policy_ref(+)
                 AND d.detail_no>0
                 AND a.file_close_date IS NULL
                 AND d.amount > 0
                 AND TRUNC (d.bordro_date) = TO_DATE('31.01.2018','DD/MM/YYYY')--LAST_DAY (TRUNC ('31.01.20))
                 AND d.is_bordro = 1
                 AND CASE
                        WHEN TO_CHAR (A.FILE_OPEN_DATE, 'YYYY') <
                                TO_CHAR (ADD_MONTHS (TO_DATE('01.01.2018','DD.MM.YYYY'), -1), 'YYYY')
                        THEN
                           'PRIOR'
                        ELSE
                           'CURRENT'
                     END IN('PRIOR','CURRENT')--= f.year_type
                 /*AND f.OC_TYPE = 'OSCGL'                                         --MUALLAK
                 AND g.gl_acct_ref_code = f.d_account_code
                 AND g1.gl_acct_ref_code = f.c_account_code*/
GROUP BY d.swift_code,
                 C.Sap_Dist_Channel,
                 NVL (c.is_industrial, 0),
                 /*d_account_code,
                 c_account_code,
                 g.account_category_code,
                 g1.account_category_code,
                 g.subfactor_1_val,
                 g.subfactor_2_val,
                 g.subfactor_3_val,
                 g.subfactor_4_val,
                 g1.subfactor_1_val,
                 g1.subfactor_2_val,
                 g1.subfactor_3_val,
                 g1.subfactor_4_val,*/
                 TO_CHAR (A.FILE_OPEN_DATE, 'YYYY'),
                 CASE
                    WHEN TO_CHAR (a.FILE_OPEN_DATE, 'YYYY') < '2018'
                     --TO_CHAR (', 'YYYY')
                    THEN
                       'PRIOR'
                    ELSE
                       'CURRENT'
                 END,
                 NVL (c.sap_dist_channel, 11),
                 c.product_id,
                 CASE WHEN NVL(c.company_code,'045') = '045' THEN 'OSCGL' ELSE 'IOSCGL' END;
