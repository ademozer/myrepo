


 Select count(1)
        from Ocp_interested_parties intpart join ocp_policy_bases bases
                                              on bases.contract_id = intpart.contract_id
                                             And bases.Top_Indicator = 'Y'
                                             And Nvl(pc_Origin_Date, Trunc(Sysdate)) between Bases.Term_start_date and Bases.Term_end_date
                                            join koc_ocp_pol_versions_ext verext
                                              on verext.contract_id = bases.contract_id
                                             And verext.top_indicator = 'Y'
       where intpart.partner_id = pc_part_id
         And nvl(verext.endorsement_no, 0) not in(2,14);
      --
      cursor crs_Existsnewendedhlthpol(pc_Identity_No   koc_cp_partners_ext.Identity_No%type
                                          , pc_Origin_Date  date
       ) is
        select /*+rule*/ a.Part_Id
          from koc_cp_partners_ext a join koc_v_health_insured_info b
                                       on b.Partner_Id = a.Part_Id
       where a.Identity_No = pc_Identity_No
         And Nvl(pc_Origin_Date, Trunc(Sysdate)) between b.Term_start_date and b.Term_end_date
         And Rownum < 2
      ;




  cursor crs_Existsnewendedhlthpol(pc_Identity_No   koc_cp_partners_ext.Identity_No%type
                                          , pc_Origin_Date  date
       ) is
        select /*+rule*/ a.Part_Id
          from koc_cp_partners_ext a join koc_v_health_insured_info b
                                       on b.Partner_Id = a.Part_Id
       where a.Identity_No = pc_Identity_No
         And Nvl(pc_Origin_Date, Trunc(Sysdate)) between b.Term_start_date and b.Term_end_date
         And Rownum < 2

Sorgulanan TC Kimlik No / Kart No sahibinin Allianz Sigorta A.�.'de poli�esi bulunmaktad�r. L�tfen sigortal�m�za Allianz anla�mal� fiyatlar�n� uygulamay� unutmay�n�z!


'Sorgulanan TC Kimlik No / Kart No sahibinin Allianz Sigorta A.�.''de sa�l�k bran�� d���nda bir poli�esi bulunmaktad�r. L�tfen sigortal�m�za Allianz anla�mal� fiyatlar�n� uygulamay� unutmay�n�z!';


GetPartnerIdbyActiveCardno



  -- if  search_type = 'sigortalikartno', it will be open..
      cursor crs_GetIdentity ( pc_searchid      varchar2
                             , pc_origindate    date
      ) is
        select Case when Nvl(b.Identity_No, '0') <> '0' Then 1 else 2 end IsIdentityNoExists
             , Nvl(a.Validity_End_Date, to_date('01.01.2099', 'dd.mm.yyyy')) Validity_End_Date
             , a.part_id
             , b.Identity_No
          from koc_hlth_customer_id_cards a join koc_cp_partners_ext b
                                              on b.Part_id = a.Part_Id
         where a.card_no = to_number(pc_searchid)
/*           and a.validity_start_date <= trunc(pc_origindate)
           and (a.validity_end_date is null or a.validity_end_date >= trunc(pc_origindate))*/
         order by 1, 2 desc, 3 desc
       ;
       crs_GetIdentityRec   crs_GetIdentity%Rowtype;
       --
      -- if p_hltprv_insuredreq.searchtype in 'tckimlikno','kibriskimlikno', 'yabancikimlikno', it will be open..
      cursor crs_insuredidentityno( pc_searchid varchar2
      ) is
        select distinct hpi.part_id
          from koc_v_health_partner_info hpi
         where hpi.identity_no = pc_searchid
         order by hpi.part_id; --(en son max part id)
         
---         
   if v_searchtype = 'SigortaliKartNo'
         then
           Open crs_GetIdentity(v_searchid, trunc(Self.origindate));
           Fetch crs_GetIdentity Into crs_GetIdentityRec;
           If crs_GetIdentity%Found then
              Close crs_GetIdentity;
              If crs_GetIdentityRec.IsIdentityNoExists = 1 Then
                 v_searchid   := crs_GetIdentityRec.Identity_No;
                 v_searchtype := 'TcKimlikNo';
              End if;
           Else
              Close crs_GetIdentity;
              Return;
              --Raise_Application_Error(-20110, 'Bu kart numaras�na sahip unusur i�in "TC Kimlik No" bilgisi okunamad�!');
           End if;
         End if;

         -- Poli�e listesinin okunmas�.  Her zaman TcKimlik �zerinden poli�eler okunmas�na �al���l�yor, Yabanc�larda TC Kimlik yoksa tekrar kart no ile okuyor
         If v_searchtype = 'TcKimlikNo' Then
            v_PartId := 0;  v_PolicyCount := 0;
            Self.IdentityNo := v_searchid;
            for c in crs_insuredidentityno(v_searchid)
            loop
               --
               self.partid := to_number(c.part_id);
