select 355577538 from dual 

<CONTRACT_ID:355577538>
<PARTITION_NO:288>
<IS_REFFERAL:0>
<DOCTOR_CODE:46804317272>

SELECT Alz_General_List_Utils.Getparamnumbervalue('GL-QWR', 'DOCTOR_IDENTITY_NO=15365408002;PROCESS_TYPE=10.10.101;INSTITUTE_CODE=1750;') FROM DUAL;

select * from alz_hltprv_log where processinfo='GETHLTHPROCESSPRICE' and rownum<100


  select * from alz_general_lists_col_val where col_value IN('15365408002','10.10.101','1750')
  
   SELECT * FROM alz_general_lists_column WHERE COL_GROUP='GENERAL_LISTS_KEY_INFO'

Customer.General_Lists_Query_Val_Typ;
 Customer.General_Lists_Query_Typ;
 
 SELECT col_val.*
  FROM (SELECT a.process_code_main || '.' || a.process_code_sub1 || '.' || a.process_code_sub2 col_code, a.discount_group_code col_ext_ref
             , a.process_name col_name
          FROM koc_cc_hlth_tda_proc_list a
         WHERE a.validity_start_date <= TRUNC (SYSDATE) AND NVL (a.validity_end_date, TRUNC (SYSDATE)) >= TRUNC (SYSDATE)) col_val
         
         
         SELECT c.par_name, c.par_value, a.key_no list_id, a.key_seq list_seq
           FROM    (   (SELECT 1 KEY_NO,1 KEY_SEQ FROM DUAL) a
                    JOIN
                       alz_general_lists_details b
                    ON b.list_id = a.key_no AND b.list_seq = a.key_seq)
                 JOIN
                   alz_general_lists_par c
                ON c.list_id = b.list_id AND c.list_seq = b.list_seq;
                
                
              select p.par_value 
                from alz_general_lists_par p                    
               where p.par_name='TUTAR'        
                 and exists (SELECT 1 FROM alz_general_lists_column c,
                                            alz_general_lists_col_val v
                              WHERE c.col_id = v.col_id
                                AND v.list_id = p.list_id
                                AND v.list_seq = p.list_seq
                                AND c.col_name = 'DOCTOR_IDENTITY_NO'                             
                                AND v.col_value='15365408002') --:doctorIdentityNo                                
                 and exists (SELECT 1 FROM alz_general_lists_column c,
                                            alz_general_lists_col_val v
                              WHERE c.col_id = v.col_id
                                AND v.list_id = p.list_id
                                AND v.list_seq = p.list_seq
                                AND c.col_name = 'PROCESS_TYPE'                             
                                AND v.col_value='10.10.101')     --:processCodeMain :processCodeSub1 :processCodeSub2
                 and exists (SELECT 1 FROM alz_general_lists_column c,
                                           alz_general_lists_col_val v
                              WHERE c.col_id = v.col_id
                                AND v.list_id = p.list_id
                                AND v.list_seq = p.list_seq
                                AND c.col_name = 'INSTITUTE_CODE'                             
                                AND v.col_value='1750')  --:instituteCode               
                                             
                                            
              
              select * from alz_look_up where code='HLTAPPCODE'
              
            select * from  alz_general_lists_column
            
            select * from alz_general_lists_details
