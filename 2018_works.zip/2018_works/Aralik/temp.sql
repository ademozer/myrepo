Koc_Clm_Hlth_Utils.Whichdbprocworking

select * from all_source where lower(text) like '%business_line%'

getpolinfoforindemnity

;Koc_Clm_Hlth_Utils.Getpolinfoforindemnity

SELECT * FROM Koc_V_Cp_Health_Look_Up WHERE  look_up_code='CLMSTCODE'
