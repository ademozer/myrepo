DECLARE
   TYPE Refcur IS REF CURSOR;
  procedure computeRemaining(
                             p_User_Id               IN VARCHAR2,
                             p_Institute_Code        IN NUMBER,                             
                             p_Query_Date            IN DATE,
                             p_Contract_Id           IN NUMBER,
                             p_Partition_No          IN NUMBER
                            ) IS

        CURSOR crs_user IS
          SELECT d.user_type, g.user_group
            FROM CUSTOMER.Koc_Cp_User_Detail d, CUSTOMER.Koc_Oc_Hlth_User_Grp_Rel g
           WHERE d.Userid = p_User_Id
             AND d.user_type = g.user_type
             AND d.Validity_Start_Date <= p_Query_Date
             AND (d.Validity_End_Date IS NULL OR d.Validity_End_Date >= p_Query_Date)
             AND g.Validity_Start_Date <= p_Query_Date
             AND (g.Validity_End_Date IS NULL OR g.Validity_End_Date >= p_Query_Date);

        rec_user crs_user%ROWTYPE;

        CURSOR crs_policy IS
           SELECT Partner_Id, Policy_Start_Date, Group_Code
             FROM CUSTOMER.Koc_v_Hlth_Insured_Info_Indem
            where contract_id = p_Contract_Id
              and partition_no = p_Partition_No;

         rec_policy crs_policy%ROWTYPE;

         crs_institute RefCur;
         rec_institute CUSTOMER.KOC_V_CLM_SUPPLIERS_MAIN%ROWTYPE;

        -- v_converter_row       alz_hcl_converter_row := alz_hcl_converter_row();
        -- v_converter_row_cover alz_hcl_converter_row := alz_hcl_converter_row();
         v_request CLOB;
         v_response CLOB;
         v_url VARCHAR2(200) := 'http://10.70.47.25:19101/hclm-health-claim-service/api/v1/computeremaining/get'; -- esb adresi ile de�i�ecek
         v_status NUMBER;
         v_message VARCHAR2(1000);
         v_cover_info VARCHAR2(32000);

     BEGIN

        /*addParameterToTable('coverCode', p_Cover_Code, v_converter_row_cover);
        addParameterToTable('daySeance', TO_CHAR(NVL(p_Day_Seance,0)), v_converter_row_cover);
        addParameterToTable('provisionAmount', TO_CHAR(NVL(p_Provision_Amount,0)), v_converter_row_cover);
        addParameterToTable('exemptionOverAmount', TO_CHAR(NVL(p_Exemption_Ovr_Amount,0)), v_converter_row_cover);
        addParameterToTable('poolCover', CASE NVL(p_Is_Pool_Cover,0) WHEN 1 THEN 'true' ELSE 'false' END, v_converter_row_cover);
        addParameterToTable('specialCover', CASE NVL(p_Is_Special_Cover,0) WHEN 1 THEN 'true' ELSE 'false' END, v_converter_row_cover);
        v_cover_info := '[' || convertTableToPayload(v_converter_row_cover) || ']';
        addParameterToTable('coverInfoParamList', v_cover_info, v_converter_row);*/

        OPEN crs_user;
        FETCH crs_user INTO rec_user;
        CLOSE crs_user;

        OPEN crs_policy;
        FETCH crs_policy INTO rec_policy;
        CLOSE crs_policy;
        
          DBMS_OUTPUT.PUT_LINE('Partner Id  :'||rec_policy.Partner_Id);

        KOC_CLM_HLTH_UTILS.Getinstitutinfobycode(p_Institute_Code, p_Query_Date, crs_institute);
        FETCH crs_institute INTO rec_institute;
        CLOSE crs_institute;

       DBMS_OUTPUT.PUT_LINE('Kurum Anla�ma Tipi :'||rec_institute.Claim_Inst_Type);
       /* addParameterToTable('instituteCode', TO_CHAR(p_Institute_Code), v_converter_row);
        addParameterToTable('contractId', TO_CHAR(p_Contract_Id), v_converter_row);
        addParameterToTable('partitionNo', TO_CHAR(p_Partition_No), v_converter_row);
        addParameterToTable('partnerId', TO_CHAR(rec_policy.Partner_Id), v_converter_row);
        addParameterToTable('policyGroupCode', TO_CHAR(rec_policy.Group_Code), v_converter_row);
        addParameterToTable('policyStartDate', TO_CHAR(rec_policy.Policy_Start_Date,'YYYY-MM-DD'), v_converter_row);
        addParameterToTable('invoiceDate',  TO_CHAR(p_Query_Date,'YYYY-MM-DD'), v_converter_row);
        addParameterToTable('queryDate',  TO_CHAR(p_Query_Date,'YYYY-MM-DD'), v_converter_row);
        addParameterToTable('realizationDate',  TO_CHAR(p_Query_Date,'YYYY-MM-DD'), v_converter_row);
        addParameterToTable('referral', CASE NVL(p_Is_Referral,0) WHEN 1 THEN 'true' ELSE 'false' END, v_converter_row);
        addParameterToTable('swiftCode', p_Swift_Code, v_converter_row);
        addParameterToTable('userGroup', TO_CHAR(rec_user.User_Group), v_converter_row);

        v_request := convertTableToPayload(v_converter_row);

        DBMS_OUTPUT.PUT_LINE('Limit Sorgulama Request: '||v_request);
        callRestService(v_url, 'POST', v_request, v_response, v_status, v_message);
        DBMS_OUTPUT.PUT_LINE('Limit Sorgulama Response: '||v_response||' status='||v_status);
        IF v_status = 1 THEN
               DBMS_OUTPUT.PUT_LINE('Fiyat Hesaplama Hata: '||v_message);
               v_response := '[{"daySeance": "0"},
                               {"exemptionRate": "0"},
                               {"exemptionSumAmount": "0"},
                               {"instituteExemptionSumAmount": "0"},
                               {"overPriceAmount": "0"},
                               {"provisionAmount": "0"},
                               {"remainedCoverPriceAmount": "0"},
                               "remainedDaySeance": "0" ]';
         END IF;

         v_converter_row := processPayload(v_response);

         FOR rec IN (SELECT FIELD_NAME,FIELD_VALUE FROM TABLE(v_converter_row)) LOOP
              IF rec.FIELD_NAME = 'daySeance' THEN
                  BEGIN
                      p_Out_Day_Seance := TO_NUMBER(TRIM(rec.FIELD_VALUE),'999999.9999');
                  EXCEPTION
                  WHEN OTHERS THEN
                      v_message := SQLERRM;
                      DBMS_OUTPUT.PUT_LINE('Limit Sorgulama Hata.ResponseParsing1: '||v_message);
                  END;
              END IF;
              IF rec.FIELD_NAME = 'exemptionRate' THEN
                  BEGIN
                      p_Out_Exemption_Rate := TO_NUMBER(TRIM(rec.FIELD_VALUE),'999999.9999');
                  EXCEPTION
                  WHEN OTHERS THEN
                      v_message := SQLERRM;
                      DBMS_OUTPUT.PUT_LINE('Limit Sorgulama Hata.ResponseParsing2: '||v_message);
                  END;
              END IF;
              IF rec.FIELD_NAME = 'exemptionSumAmount' THEN
                  BEGIN
                      p_Out_Exemption_Sum := TO_NUMBER(TRIM(rec.FIELD_VALUE),'999999.9999');
                  EXCEPTION
                  WHEN OTHERS THEN
                      v_message := SQLERRM;
                      DBMS_OUTPUT.PUT_LINE('Limit Sorgulama Hata.ResponseParsing3: '||v_message);
                  END;
              END IF;
              IF rec.FIELD_NAME = 'instituteExemptionSumAmount' THEN
                  BEGIN
                      p_Out_Inst_Exemp_Sum := TO_NUMBER(TRIM(rec.FIELD_VALUE),'999999.9999');
                  EXCEPTION
                  WHEN OTHERS THEN
                      v_message := SQLERRM;
                      DBMS_OUTPUT.PUT_LINE('Limit Sorgulama Hata.ResponseParsing4: '||v_message);
                  END;
              END IF;
              IF rec.FIELD_NAME = 'overPriceAmount' THEN
                  p_Out_Over_Price := rec.FIELD_VALUE;
              END IF;
              IF rec.FIELD_NAME = 'provisionAmount' THEN
                  BEGIN
                      p_Out_Provision_Amount := TO_NUMBER(TRIM(rec.FIELD_VALUE),'999999.9999');
                  EXCEPTION
                  WHEN OTHERS THEN
                      v_message := SQLERRM;
                      DBMS_OUTPUT.PUT_LINE('Limit Sorgulama Hata.ResponseParsing5: '||v_message);
                  END;
              END IF;
              IF rec.FIELD_NAME = 'remainedCoverPriceAmount' THEN
                  BEGIN
                      p_r_Cover_Price := TO_NUMBER(TRIM(rec.FIELD_VALUE),'999999.9999');
                  EXCEPTION
                  WHEN OTHERS THEN
                      v_message := SQLERRM;
                      DBMS_OUTPUT.PUT_LINE('Limit Sorgulama Hata.ResponseParsing6: '||v_message);
                  END;
              END IF;
              IF rec.FIELD_NAME = 'remainedDaySeance' THEN
                  BEGIN
                      p_r_Day_Seance := TO_NUMBER(TRIM(rec.FIELD_VALUE),'999999.9999');
                  EXCEPTION
                  WHEN OTHERS THEN
                      v_message := SQLERRM;
                      DBMS_OUTPUT.PUT_LINE('Limit Sorgulama Hata.ResponseParsing7: '||v_message);
                  END;
              END IF;
        END LOOP;*/
        
        

     END computeRemaining;
     
 BEGIN
   
    computeRemaining('MEDISER28',13,SYSDATE,353869514,4);
   
 END;
