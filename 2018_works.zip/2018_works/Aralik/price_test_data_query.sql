SELECT /*+ORDERED*/ a.*
  FROM Koc_v_Hlth_Insured_Info_Indem a
  WHERE 1 = 1           
    AND a.Contract_Id = 355577538
    AND a.Partition_No = 288
    AND a.partner_id=31762360 
    AND a.package_id=255194
             
    
    select * from clm_pol_oar where contract_id=355577538 and oar_no=288
             
    --130-20-116 S-AT-�OH - S11183
     select * from koc_clm_hlth_proc_detail where claim_id=38466674
     select * from koc_clm_hlth_detail  where claim_id=38466674
     1289
     86696-196128
     select * from koc_clm_hlth_indem_totals where Contract_Id = 290946949 and partition_no=4 and Exemption_Group is not null
     
     select * from koc_clm_hlth_indem_totals where exemption_group is not null and rownum < 2
     
     
     select * from koc_oc_hlth_expack_cov_rel where is_pool_cover=1;--Contract_Id = 290946949
     
     Koc_Clm_Hlth_Utils.Getpolinfoforindemnity
