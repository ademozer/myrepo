PROCEDURE Computeremaning(p_Contract_Id              NUMBER,
/*
  Getindemtotalsmdftmp(p_Contract_Id,
  Getindemtotalsmdf(p_Contract_Id,
  Transferindeminfotorep(p_Contract_Id, p_Partition_No);
  Getindemtotalsfromrep(p_Contract_Id,
  SELECT {Network_Id} FROM Koc_v_Hlth_Insured_Info_Indem a WHERE a.Contract_Id = p_Contract_Id
  
*/
                            p_Partition_No             NUMBER,
                            p_Part_Id                  NUMBER,
                            p_Claim_Id                 NUMBER,
                            p_Sf_No                    NUMBER,
                            p_Institute_Code           NUMBER,
                            p_Claim_Inst_Type          VARCHAR2,
                            p_Claim_Inst_Loc           VARCHAR2,
                            p_Country_Group            NUMBER,
                            p_Location_Code            NUMBER,
                            p_Cover_Code               VARCHAR2,
                            p_Swift_Code               VARCHAR2,
                            p_Date                     DATE,
                            p_Invoice_Date             DATE,
                            p_Realization_Date         DATE,
                            p_Prov_Date_Time           DATE,
                            p_Provision_Amount         NUMBER,
                            p_Day_Seance               NUMBER,
                            p_Policyinfo               Koc_v_Hlth_Insured_Info_Indem%ROWTYPE,
                            p_Institutinfo             Koc_v_Clm_Suppliers%ROWTYPE,
                            p_User_Id                  VARCHAR2,
                            p_Is_Pool_Cover            NUMBER,
                            p_Is_Special_Cover         NUMBER,
                            p_Process_Type             NUMBER DEFAULT 0,
                            p_Out_Provision_Amount     OUT NUMBER,
                            p_Out_Day_Seance           OUT NUMBER,
                            p_Out_Exemption_Rate       OUT NUMBER,
                            p_Out_Exemption_Sum        OUT NUMBER,
                            p_Out_Inst_Exemp_Sum       OUT NUMBER,
                            p_r_Day_Seance             OUT NUMBER,
                            p_r_Cover_Price            OUT NUMBER,
                            p_Inst_Provision_Aval_Code OUT VARCHAR2,
                            p_Inst_Is_Cover_Val        OUT NUMBER,
                            p_Out_Over_Price           OUT VARCHAR2,
                            p_Exemption_Ovr_Amount     IN NUMBER DEFAULT NULL, -- Muafiyet tutarini düzenleme
                            p_Is_Referral              IN NUMBER DEFAULT NULL) IS
    v_Network_Prov_Aval_Code NUMBER := 0;
    j                        NUMBER;
    v_Trans_Insured          Transinsuredtyp;
    Cur                      Refcur;
    Indeminfo                Koc_Clm_Hlth_Indem_Totals%ROWTYPE;
    Indeminfoparent          Koc_Clm_Hlth_Indem_Totals%ROWTYPE;
    Indeminforep             Rep_Clm_Hlth_Indem_Totals%ROWTYPE;
    Indeminfopool            Koc_Clm_Hlth_Indem_Totals%ROWTYPE;
    Oldindeminfo             Koc_Clm_Hlth_Indem_Totals%ROWTYPE;
    Policyinfo               Koc_v_Hlth_Insured_Info_Indem%ROWTYPE;
    Institutinfo             Koc_v_Clm_Suppliers%ROWTYPE;
    v_Clmprovision           Koc_Clm_Hlth_Provisions%ROWTYPE;
    u_r_Cover_Price          NUMBER;
    u_r_Day_Seance           NUMBER;
    u_r_Exemption_Sum        NUMBER;
    u_s_Provision_Amount     NUMBER;
    u_s_Spend_Total          NUMBER;
    u_s_Spend_Day_Seance     NUMBER;
    u_s_Exemption_Sum        NUMBER;

    v_Policy_Start_Date          DATE;
    v_Old_Contract_Id            NUMBER;
    v_Old_Partition_No           NUMBER;
    v_Term_End_Date              DATE;
    v_Max_Inc_Clearing_System_Id NUMBER;
    v_Max_Inc_Curr_Get_Type      VARCHAR2(10);
    v_Max_Inc_Swift_Code         VARCHAR2(4);

    Expackrsltbl         Expackrsltbltyp;
    c_Inst_Is_Cover_Val2 NUMBER := NULL;

    c_Max_Increase      NUMBER;
    c_Provision_Amount  NUMBER;
    c_Exemption_Rate    NUMBER;
    c_Day_Seance        NUMBER;
    c_Exemption_Sum     NUMBER;
    c_Day_Seance_Amount NUMBER;
    c_Is_Unlimited      NUMBER;

    c_r_Cover_Price NUMBER;
    c_r_Day_Seance  NUMBER;

    c_f_Cover_Price NUMBER;
    c_f_Day_Seance  NUMBER;

    c_Inst_Cover_Price         NUMBER := NULL;
    c_Inst_r_Day_Seance        NUMBER := NULL;
    c_Inst_Exemption_Sum       NUMBER := NULL;
    c_Inst_Exemption_Rate      NUMBER := NULL;
    c_Inst_Is_Unlimited        NUMBER := NULL;
    c_Inst_Provision_Aval_Code VARCHAR2(4) := NULL;
    c_Inst_Is_Cover_Val        NUMBER := NULL;
    c_Inst_Is_Not_Valid_Exemp  NUMBER := NULL;

    c_Parent_Indemnity_Type   VARCHAR2(20);
    c_Parent_Provision_Amount NUMBER;
    c_Parent_r_Cover_Price    NUMBER;
    c_Parent_Is_Unlimited     NUMBER;

    p_Rsl_Number             NUMBER;
    p_Rsl_Date               DATE;
    p_Rsl_Char               VARCHAR2(2000);
    Expackrow                Koc_Oc_Hlth_Expack_Cov_Rel%ROWTYPE;
    v_Pay_Clearing_System_Id NUMBER;
    v_Pay_Curr_Get_Type      VARCHAR2(4);

    v_Parite         NUMBER := 1;
    v_Cover_Swf      VARCHAR2(20);
    v_Exch_Date      VARCHAR2(20);
    v_Curr_Date      DATE;
    v_Exit           BOOLEAN;
    Vv_Date          DATE;
    Vv_Partittion_No NUMBER;
    i                NUMBER;
    v_Networkid      Koc_v_Hlth_Insured_Info_Indem.Network_Id%TYPE;

    Hltprv_Log                  Hltprv_Log_Typ;
    Vprodpartmdlr               VARCHAR2(10);
    Vcoverpackageid             NUMBER;
    Vcoverpackagedate           DATE;
    v_Network_21_Prov_Aval_Code NUMBER;

    --PRAGMA AUTONOMOUS_TRANSACTION;
    v_City_Code    VARCHAR2(3);
    v_Country_Code VARCHAR2(3) := 'TR';
    v_Is_Refferal  NUMBER;

    -- engine 18052017 TPA
    v_Company_Code   Alz_Tpa_Companies.Company_Code%TYPE;
    v_Message        Customer.Alz_Tpa_Message_Definitions.Message_Template%TYPE;
    v_Message_Fields VARCHAR2(1000);
    -- engine 18052017 TPA
  BEGIN
    --p_process_type :0 deger al
    --p_process_type :1 limit günceller
    --p_process_type :2 islem iptal
    --p_process_type :3 Limit bloklayarak deger alir
    -- 44.a ------------------------------------------------------
    IF p_Process_Type = 3 THEN
      Getindemtotalsmdftmp(p_Contract_Id,
                           p_Partition_No,
                           p_Claim_Inst_Type,
                           p_Claim_Inst_Loc,
                           p_Country_Group,
                           p_Cover_Code,
                           p_Policyinfo.Package_Id,
                           p_Policyinfo.Package_Date,
                           Trunc(p_Date),
                           p_User_Id,
                           p_Is_Pool_Cover,
                           p_Is_Special_Cover,
                           Cur);
      FETCH Cur
        INTO Indeminfo;
      CLOSE Cur;
	-- 44.b -------------------------------------------------------
    ELSE
      Getindemtotalsmdf(p_Contract_Id,
                        p_Partition_No,
                        p_Claim_Inst_Type,
                        p_Claim_Inst_Loc,
                        p_Country_Group,
                        p_Cover_Code,
                        p_Policyinfo.Package_Id,
                        p_Policyinfo.Package_Date,
                        Trunc(p_Date),
                        p_User_Id,
                        p_Is_Pool_Cover,
                        p_Is_Special_Cover,
                        Cur);
      FETCH Cur
        INTO Indeminfo;
      CLOSE Cur;

    END IF;
    -- 44.c -------------------------------------------------------
    IF Indeminfo.Contract_Id IS NULL AND p_Process_Type = 1 THEN
      Raise_Application_Error(-20222, 'Teminat, Planda Bulunamadı.'); --20222 errcode u başka yerde kullanma !
    END IF;
    -- 44.d -------------------------------------------------------
    --aaktas
    --02052014
    --1KEZ teminat ödeme tipi NORM gibi davranacak
    IF Indeminfo.Indemnity_Payment_Type NOT IN
       ('DEFA', 'GUN', 'NORM', '2YIL', '1KEZ') THEN
      Raise_Application_Error(-20200,
                              'Ödeme Tipi Hatasi.' ||
                              Indeminfo.Indemnity_Payment_Type);
    END IF;
    -- 44.e ---------------------------------------------------------
    ------ replication
    --replikasyon artik kullanilmiyor
    IF Koc_Clm_Hlth_Utils.Whichdbprocworking = 3 THEN
      Transferindeminfotorep(p_Contract_Id, p_Partition_No);

      Getindemtotalsfromrep(p_Contract_Id,
                            p_Partition_No,
                            p_Claim_Inst_Type,
                            p_Claim_Inst_Loc,
                            p_Country_Group,
                            p_Cover_Code,
                            Trunc(p_Date),
                            0,
                            0,
                            p_User_Id,
                            p_Is_Pool_Cover,
                            p_Is_Special_Cover,
                            Cur);

      FETCH Cur
        INTO Indeminforep;

      CLOSE Cur;

      Indeminfo.r_Exemption_Sum := Nvl(Indeminfo.r_Exemption_Sum, 0) +
                                   Nvl(Indeminforep.r_Exemption_Sum, 0);

      IF Indeminfo.Indemnity_Payment_Type IN ('NORM', '1KEZ') AND
         Nvl(Indeminfo.Is_Unlimited, 0) != 1 THEN
        --yasemin
        Indeminfo.r_Cover_Price := Nvl(Indeminfo.r_Cover_Price, 0) +
                                   Nvl(Indeminforep.r_Cover_Price, 0);
      END IF;

      IF Indeminfo.Indemnity_Payment_Type IN
         ('DEFA', 'GUN', 'NORM', '1KEZ') THEN
        Indeminfo.r_Day_Seance := Nvl(Indeminfo.r_Day_Seance, 0) +
                                  Nvl(Indeminforep.r_Day_Seance, 0);
      END IF;
    END IF;
   
    c_Provision_Amount := Nvl(p_Provision_Amount, 0);
    -- 44.f --------------------------------------------------------------
    -- talep tutarinin döviz cinsi teminatin döviz cinsinden farkli ise
    -- talep tutarinin teminat döviz cinsi karsiligini bulunur
    -- ve limitler bu tutar ile güncellenir.
    IF p_Swift_Code != Indeminfo.Swift_Code THEN
      v_Cover_Swf := Indeminfo.Swift_Code;

      SELECT Decode(v_Cover_Swf,
                    Base_Swift_Code,
                    Pay_Clearing_System_Id,
                    Pay_Swf_Clear_Sys_Id),
             Decode(v_Cover_Swf,
                    Base_Swift_Code,
                    Pay_Curr_Get_Type,
                    Pay_Swf_Curr_Get_Type),
             Decode(v_Cover_Swf,
                    Base_Swift_Code,
                    Pay_Exch_Dates,
                    Pay_Swf_Exch_Dates)
        INTO v_Pay_Clearing_System_Id, v_Pay_Curr_Get_Type, v_Exch_Date
        FROM Koc_Oc_Prod_Partition_Rel
       WHERE Product_Id = p_Policyinfo.Product_Id
         AND Partition_Type = p_Policyinfo.Partition_Type
         AND Validity_Start_Date <= p_Policyinfo.Term_Start_Date
         AND Nvl(Validity_End_Date, p_Policyinfo.Term_Start_Date) >=
             p_Policyinfo.Term_Start_Date;

      IF v_Exch_Date = 'FAT' THEN
        v_Curr_Date := p_Invoice_Date;
      ELSIF v_Exch_Date = 'OLAY' THEN
        v_Curr_Date := p_Date;
      ELSIF v_Exch_Date = 'TAH' THEN
        v_Curr_Date := p_Realization_Date;
      ELSE
        v_Curr_Date := p_Date;
      END IF;

      v_Parite           := Koc_Curr_Utils.Retrieve_Currency_Rate(p_Swift_Code,
                                                                  v_Pay_Curr_Get_Type,
                                                                  Trunc(v_Curr_Date),
                                                                  v_Pay_Clearing_System_Id,
                                                                  TRUE) /
                            Koc_Curr_Utils.Retrieve_Currency_Rate(Indeminfo.Swift_Code,
                                                                  v_Pay_Curr_Get_Type,
                                                                  Trunc(v_Curr_Date),
                                                                  v_Pay_Clearing_System_Id,
                                                                  TRUE);
      c_Provision_Amount := v_Parite * c_Provision_Amount;
    END IF;
    -- 44.g ------------------------------------------------------------
    -- provizyon almis hasar dosya--------------------------------------------
    -- provizyon almis lokasyon üzerinde degisiklik yapildiginda dogru provizyon tutarini göstere bilmesi için
    -- önce provizyon almis lokasyon reverse ediliyor.
    --IF p_Process_Type = 0
    IF p_Process_Type IN (0, 3) THEN
      BEGIN
        SELECT *
          INTO v_Clmprovision
          FROM Koc_Clm_Hlth_Provisions
         WHERE Claim_Id = p_Claim_Id
           AND Sf_No = p_Sf_No
           AND Location_Code = p_Location_Code
           AND Cover_Code = p_Cover_Code
           AND Status_Code = 'P';

        IF p_Policyinfo.Partition_Type = 'KEKS' THEN
          v_Clmprovision.Exemption_Amount := 0;
        END IF;

        Indeminfo.s_Provision_Amount := Indeminfo.s_Provision_Amount -
                                        v_Parite * Nvl(v_Clmprovision.Provision_Total,
                                                       0);
        Indeminfo.s_Spend_Total      := Indeminfo.s_Spend_Total -
                                        v_Parite *
                                        (Nvl(v_Clmprovision.Request_Amount,
                                             0) - Nvl(v_Clmprovision.Refusal_Amount,
                                                       0));
        Indeminfo.s_Spend_Day_Seance := Indeminfo.s_Spend_Day_Seance -
                                        Nvl(v_Clmprovision.Req_Cure_Day_Count,
                                            0);
        Indeminfo.s_Exemption_Sum    := Indeminfo.s_Exemption_Sum -
                                        v_Parite * Nvl(v_Clmprovision.Exemption_Amount,
                                                       0);
        Indeminfo.r_Exemption_Sum    := Indeminfo.r_Exemption_Sum +
                                        v_Parite * Nvl(v_Clmprovision.Exemption_Amount,
                                                       0);

        IF Indeminfo.Indemnity_Payment_Type IN ('NORM', '1KEZ') AND
           Nvl(Indeminfo.Is_Unlimited, 0) != 1 THEN
          IF v_Clmprovision.Exemption_Rate != 1 THEN
            --yasemin
            Indeminfo.r_Cover_Price := Indeminfo.r_Cover_Price +
                                       v_Parite *
                                       ((v_Clmprovision.Provision_Total /
                                       (1 - v_Clmprovision.Exemption_Rate)) +
                                       v_Clmprovision.Exemption_Amount);
          ELSE
            --yasemin
            Indeminfo.r_Cover_Price := Indeminfo.r_Cover_Price +
                                       v_Parite *
                                       v_Clmprovision.Exemption_Amount;
          END IF;
        END IF;

        IF Indeminfo.Indemnity_Payment_Type IN
           ('DEFA', 'GUN', 'NORM', '1KEZ') THEN
          Indeminfo.r_Day_Seance := Indeminfo.r_Day_Seance +
                                    v_Clmprovision.Day_Seance;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
    END IF;

    -----------------------------------------------------------
    Policyinfo   := p_Policyinfo;
    Institutinfo := p_Institutinfo;
    -- 44.h --------------------------------------------------------------------------
    --aaktas
    --21012015
    --Poliçe modüler saglik ürünü mü?
    Vprodpartmdlr := Koc_Health_Policy_Utils5.Get_Prod_Part_Mdlr(Policyinfo.Product_Id,
                                                                 Policyinfo.Partition_Type,
                                                                 Trunc(p_Date));
    -- 44.i ---------------------------------------------------
    --abdullah aktas
    --21012015
    --mdlr tipinde ise partition_type teminatin sub_package_id sini al
    --mdlr poliçesindeki teminatlarin planlari farkli olabilir.
    IF Nvl(Vprodpartmdlr, 'X') = 'MDLR' THEN
      Vcoverpackageid   := Indeminfo.Sub_Package_Id;
      Vcoverpackagedate := Indeminfo.Sub_Package_Date;
    ELSE
      Vcoverpackageid   := Policyinfo.Package_Id;
      Vcoverpackagedate := Policyinfo.Package_Date;
    END IF;
    -- 44.k---------------------------------------------------------
    --ibrahimk
    --expack cov rel de yeni kural için kullanılacak alanlar
    IF p_Institute_Code IS NOT NULL THEN
      Alz_Hlth_Karma_Utils.Get_Inst_City_Code(Institutinfo.Institute_Code,
                                              v_City_Code,
                                              v_Country_Code);
    ELSE
      v_City_Code    := NULL;
      v_Country_Code := NULL;
    END IF;

    --ibrahimk + kenanp 25012017 karma projesi
    BEGIN
      SELECT Network_Id
        INTO v_Networkid
        FROM (SELECT a.Package_Id,
                     a.Contract_Id,
                     a.Partition_No,
                     a.Network_Id,
                     Decode(a.Package_Status, 'D', 0, 1) Sira
                FROM Koc_v_Hlth_Insured_Info_Indem a
               WHERE a.Contract_Id = p_Contract_Id
                 AND a.Partition_No = p_Partition_No
                 AND p_Date BETWEEN a.Term_Start_Date AND
                     (a.Term_End_Date + 0.5) /*Öğlen 12:00 den sonra provizyon alamasın*/
               ORDER BY 5 DESC)
       WHERE Rownum < 2;
    EXCEPTION
      WHEN OTHERS THEN
        v_Networkid := NULL;
    END;
    --44.l---------------------------------------------------------------------------------
    --sonrasında parametre olarak eklendi.
    IF p_Claim_Id IS NOT NULL AND p_Is_Referral IS NULL THEN
      v_Is_Refferal := Alz_Hlth_Karma_Utils.Get_Clm_Is_Referral(p_Claim_Id     => v_Clmprovision.Claim_Id,
                                                                p_Sf_No        => v_Clmprovision.Sf_No,
                                                                p_Add_Order_No => v_Clmprovision.Add_Order_No);
    ELSE
      v_Is_Refferal := p_Is_Referral;
    END IF;
    ---44.m------------------------------------------------------------------------------
    --IF p_Process_Type IN (0, 1)
    IF p_Process_Type IN (0, 1, 3) THEN
      --kurum için tanimlanmis limit, muafiyet tutari yada hasta payi var mi?----
      Expackrow.Product_Id           := Policyinfo.Product_Id;
      Expackrow.Partition_Type       := Policyinfo.Partition_Type;
      Expackrow.Contract_Id          := Policyinfo.Contract_Id;
      Expackrow.Partition_No         := Policyinfo.Partition_No;
      Expackrow.Validity_Start_Date  := Nvl(Indeminfo.Validity_Start_Date,
                                            To_Date('01/01/1000',
                                                    'DD/MM/YYYY'));
      Expackrow.Part_Id              := Policyinfo.Partner_Id;
      Expackrow.Package_Id           := Vcoverpackageid;
      Expackrow.Package_Date         := Vcoverpackagedate;
      Expackrow.Claim_Inst_Type      := Nvl(p_Claim_Inst_Type,
                                            Institutinfo.Claim_Inst_Type);
      Expackrow.Claim_Inst_Loc       := Nvl(p_Claim_Inst_Loc,
                                            Institutinfo.Claim_Inst_Loc);
      Expackrow.Institute_Code       := Institutinfo.Institute_Code;
      Expackrow.Inst_Cov_Type        := Institutinfo.Inst_Cov_Type;
      Expackrow.Inst_Validity_Type   := Institutinfo.Inst_Validity_Type;
      Expackrow.Institute_Type       := Institutinfo.Institute_Type;
      Expackrow.Country_Group        := p_Country_Group;
      Expackrow.Child_Cover_Code     := Indeminfo.Cover_Code;
      Expackrow.Is_Pool_Cover        := Indeminfo.Is_Pool_Cover;
      Expackrow.Is_Special_Cover     := Indeminfo.Is_Special_Cover;
      Expackrow.Cover_Cat_Group      := Indeminfo.Cover_Cat_Group;
      Expackrow.Institude_Group_Code := Institutinfo.Institute_Group_Code_Type_2; -- selcenk TSS 03/03/2015
      Expackrow.Spec_Group_Code      := Institutinfo.Institute_Group_Code_Type_s; -- selcenk TSS 03/03/2015
      Expackrow.City_Code            := v_City_Code; --ibrahimk karma 21/09/2016
      Expackrow.Network_Id           := v_Networkid; --ibrahimk + kenanp 25012017 karma projesi

      Getinstexpackresult(Expackrow,
                          'IS_UNLIMITED',
                          p_Rsl_Number,
                          p_Rsl_Date,
                          p_Rsl_Char);
      Expackrsltbl(1).Is_Unlimited := p_Rsl_Number;

      Getinstexpackresult(Expackrow,
                          'COVER_PRICE',
                          p_Rsl_Number,
                          p_Rsl_Date,
                          p_Rsl_Char);
      Expackrsltbl(1).Cover_Price := p_Rsl_Number;

      Getinstexpackresult(Expackrow,
                          'EXEMPTION_RATE',
                          p_Rsl_Number,
                          p_Rsl_Date,
                          p_Rsl_Char);
      Expackrsltbl(1).Exemption_Rate := p_Rsl_Number;

      --ibrahimk karma 21/09/2106
      Getinstexpackresult(Expackrow,
                          'EXEMPTION_RATE2',
                          p_Rsl_Number,
                          p_Rsl_Date,
                          p_Rsl_Char);
      Expackrsltbl(1).Exemption_Rate2 := p_Rsl_Number;

      IF Nvl(v_Is_Refferal, 0) = 1 AND Expackrsltbl(1)
        .Exemption_Rate2 IS NOT NULL THEN
        Expackrsltbl(1).Exemption_Rate := Expackrsltbl(1).Exemption_Rate2;
      END IF;
      ------------------------------------------------
      Getinstexpackresult(Expackrow,
                          'EXEMPTION_SUM',
                          p_Rsl_Number,
                          p_Rsl_Date,
                          p_Rsl_Char);
      Expackrsltbl(1).Exemption_Sum := p_Rsl_Number;

      Getinstexpackresult(Expackrow,
                          'SPECIAL_COVER_CODE',
                          p_Rsl_Char,
                          p_Rsl_Date,
                          p_Rsl_Char);
      Expackrsltbl(1).Special_Cover_Code := p_Rsl_Char;

      Getinstexpackresult(Expackrow,
                          'MAX_DAY_SEANCE',
                          p_Rsl_Number,
                          p_Rsl_Date,
                          p_Rsl_Char);
      Expackrsltbl(1).Max_Day_Seance := p_Rsl_Number;

      --27032014
      --aaktas
      Getinstexpackresult(Expackrow,
                          'IS_NOT_VALID_EXEMP',
                          p_Rsl_Number,
                          p_Rsl_Date,
                          p_Rsl_Char);
      Expackrsltbl(1).Is_Not_Valid_Exemp := p_Rsl_Number;
      --

      p_Rsl_Char   := NULL;
      p_Rsl_Number := NULL;

      IF Institutinfo.Institute_Code IN (8, 693) THEN
        IF Policyinfo.Policy_Start_Date >=
           To_Date('01/10/2007', 'dd/mm/yyyy') THEN
          Getinstexpackresult(Expackrow,
                              'PROVISION_AVAL_CODE',
                              p_Rsl_Char,
                              p_Rsl_Date,
                              p_Rsl_Char);
          Expackrsltbl(1).Provision_Aval_Code := p_Rsl_Char;

          Getinstexpackresult(Expackrow,
                              'IS_COVER_VAL',
                              p_Rsl_Number,
                              p_Rsl_Date,
                              p_Rsl_Char);
          Expackrsltbl(1).Is_Cover_Val := p_Rsl_Number;

          Getinstexpackresult(Expackrow,
                              'IS_COVER_VAL2',
                              p_Rsl_Number,
                              p_Rsl_Date,
                              p_Rsl_Char);
          Expackrsltbl(1).Is_Cover_Val2 := p_Rsl_Number;

        END IF;
      ELSE
        Getinstexpackresult(Expackrow,
                            'PROVISION_AVAL_CODE',
                            p_Rsl_Char,
                            p_Rsl_Date,
                            p_Rsl_Char);
        Expackrsltbl(1).Provision_Aval_Code := p_Rsl_Char;

        Getinstexpackresult(Expackrow,
                            'IS_COVER_VAL',
                            p_Rsl_Number,
                            p_Rsl_Date,
                            p_Rsl_Char);
        Expackrsltbl(1).Is_Cover_Val := p_Rsl_Number;

        Getinstexpackresult(Expackrow,
                            'IS_COVER_VAL2',
                            p_Rsl_Number,
                            p_Rsl_Date,
                            p_Rsl_Char);
        Expackrsltbl(1).Is_Cover_Val2 := p_Rsl_Number;

      END IF;
      -- 44.n ------------------------------------------------------- 
      v_Network_Prov_Aval_Code := 0;
      v_Network_Prov_Aval_Code := Isnetworkavailableforinst(Policyinfo.Contract_Id,
                                                            Policyinfo.Partition_No,
                                                            Institutinfo.Institute_Code,
                                                            Trunc(p_Date),
                                                            p_User_Id);

      --selcenk 26/03/2015
      IF Nvl(v_Network_Prov_Aval_Code, 0) = 0 AND
         Nvl(p_Cover_Code, 'X') <> 'X' THEN
        v_Network_21_Prov_Aval_Code := Isnetworkavailableforinst(Policyinfo.Contract_Id,
                                                                 Policyinfo.Partition_No,
                                                                 Institutinfo.Institute_Code,
                                                                 Trunc(p_Date),
                                                                 p_User_Id,
                                                                 p_Cover_Code
                                                                 -- ,indeminfo.cover_code -- selcenk 26/03/2015
                                                                 );

        IF v_Network_21_Prov_Aval_Code = 1 THEN
          --expackrsltbl (1).is_cover_val := 1;
          Expackrsltbl(1).Provision_Aval_Code := 1;
        END IF;
      END IF;

      --selcenk 26/03/2015

      IF v_Network_Prov_Aval_Code = 1 THEN
        Expackrsltbl(1).Provision_Aval_Code := v_Network_Prov_Aval_Code;
      END IF;
      -- 44.o ---------------------------------------------------------------- 
      i := 0;

      LOOP
        i := i + 1;
        EXIT WHEN i > Expackrsltbl.Count;

        IF Expackrsltbl(i).Is_Unlimited IS NOT NULL THEN
          c_Inst_Is_Unlimited := Expackrsltbl(i).Is_Unlimited;
        END IF;

        IF Expackrsltbl(i).Cover_Price IS NOT NULL THEN
          c_Inst_Cover_Price := Nvl(Expackrsltbl(i).Cover_Price, 0);
        END IF;

        IF Expackrsltbl(i).Max_Day_Seance IS NOT NULL THEN
          c_Inst_r_Day_Seance := Nvl(Expackrsltbl(i).Max_Day_Seance, 0);
        END IF;

        IF Expackrsltbl(i).Exemption_Sum IS NOT NULL THEN
          c_Inst_Exemption_Sum := Nvl(Expackrsltbl(i).Exemption_Sum, 0);
        END IF;

        IF Expackrsltbl(i).Exemption_Rate IS NOT NULL THEN
          c_Inst_Exemption_Rate := Nvl(Expackrsltbl(i).Exemption_Rate, 0);
        END IF;

        IF Expackrsltbl(i).Provision_Aval_Code IS NOT NULL THEN
          c_Inst_Provision_Aval_Code := Expackrsltbl(i).Provision_Aval_Code;
        END IF;

        IF Expackrsltbl(i).Is_Cover_Val IS NOT NULL THEN
          c_Inst_Is_Cover_Val := Expackrsltbl(i).Is_Cover_Val;
        END IF;

        --ibrahim kapa aç
        IF Nvl(Indeminfo.Is_Valid_By_Rule, 0) = 1 AND
           Nvl(Expackrsltbl(i).Is_Cover_Val2, 0) <> 1 THEN
          c_Inst_Is_Cover_Val2 := 1;
          c_Provision_Amount   := 0;

          --tutar sıfırlandığında logluyoruz. kontrol için sonradan kapatılacak
          Hltprv_Log        := Hltprv_Log_Typ();
          Hltprv_Log.Log_Id := NULL;

          Hltprv_Log.Servicename := 'KOC_CLM_HLTH_TRNX';
          Hltprv_Log.Processinfo := 'COMPUTEREMANING';
          Hltprv_Log.Note        := 'Teminat geçerli kuralı çalıştı';
          Hltprv_Log.Content     := 'sqlerrm              : ' || SQLERRM ||
                                    Chr(10) || 'p_contract_id        : ' ||
                                    p_Contract_Id || Chr(10) ||
                                    'p_partition_no       : ' ||
                                    p_Partition_No || Chr(10) ||
                                    'p_claim_inst_type    : ' ||
                                    p_Claim_Inst_Type || Chr(10) ||
                                    'p_claim_inst_loc     : ' ||
                                    p_Claim_Inst_Loc || Chr(10) ||
                                    'p_country_group      : ' ||
                                    p_Country_Group || Chr(10) ||
                                    'p_cover_code         : ' ||
                                    p_Cover_Code || Chr(10) ||
                                    'package_id           : ' ||
                                    p_Policyinfo.Package_Id || Chr(10) ||
                                    'package_date         : ' ||
                                    p_Policyinfo.Package_Date || Chr(10) ||
                                    'p_date               : ' || p_Date ||
                                    Chr(10) || 'p_user_id            : ' ||
                                    p_User_Id || Chr(10) ||
                                    'p_is_pool_cover      : ' ||
                                    p_Is_Pool_Cover || Chr(10) ||
                                    'p_is_special_cover   : ' ||
                                    p_Is_Special_Cover || Chr(10) ||
                                    'modüler saglik mi    : ' ||
                                    Vprodpartmdlr || Chr(10) ||
                                    'sub_package_id       : ' ||
                                    Indeminfo.Sub_Package_Id || Chr(10) ||
                                    'sub_package_date     : ' ||
                                    Indeminfo.Sub_Package_Date || Chr(10) ||
                                    'nvl(indeminfo.is_valid_by_rule, 0) : ' ||
                                    Nvl(Indeminfo.Is_Valid_By_Rule, 0) ||
                                    Chr(10) ||
                                    'nvl(Expackrsltbl(i).Is_Cover_Val2, 0) : ' ||
                                    Nvl(Expackrsltbl(i).Is_Cover_Val2, 0);

          Hltprv_Log.Savelogwithpragma;

        END IF;
        --ibrahim kapa aç

        IF Expackrsltbl(i).Is_Not_Valid_Exemp IS NOT NULL THEN
          c_Inst_Is_Not_Valid_Exemp := Expackrsltbl(i).Is_Not_Valid_Exemp;
        END IF;
      END LOOP;

      ----kuruma bagli degisenler--------------------
      IF c_Inst_Is_Unlimited IS NOT NULL AND c_Inst_Is_Unlimited = 0 THEN
        c_Is_Unlimited := c_Inst_Is_Unlimited;
      ELSE
        c_Is_Unlimited := Indeminfo.Is_Unlimited;
      END IF;

      IF c_Inst_Exemption_Sum IS NOT NULL THEN
        IF Nvl(c_Provision_Amount, 0) < c_Inst_Exemption_Sum THEN
          c_Inst_Exemption_Sum := Nvl(c_Provision_Amount, 0);
        END IF;
      ELSE
        c_Inst_Exemption_Sum := 0;
      END IF;

      -- en küçük limit alinmali
      IF c_Inst_Cover_Price IS NOT NULL AND
         Indeminfo.r_Cover_Price > Nvl(c_Inst_Cover_Price, 0) THEN
        c_r_Cover_Price := Nvl(c_Inst_Cover_Price, 0);
      ELSE
        c_r_Cover_Price := Indeminfo.r_Cover_Price;
      END IF;

      IF c_Inst_r_Day_Seance IS NOT NULL AND
         Nvl(Indeminfo.r_Day_Seance, 0) > Nvl(c_Inst_r_Day_Seance, 0) THEN
        c_r_Day_Seance := Nvl(c_Inst_r_Day_Seance, 0);
      ELSE
        c_r_Day_Seance := Nvl(Indeminfo.r_Day_Seance, 0);
      END IF;

      IF c_Inst_Cover_Price IS NOT NULL THEN
        c_f_Cover_Price := Nvl(c_Inst_Cover_Price, 0);
      ELSE
        c_f_Cover_Price := Indeminfo.f_Cover_Price;
      END IF;

      IF c_Inst_Exemption_Rate IS NOT NULL THEN
        c_Exemption_Rate := c_Inst_Exemption_Rate;
      ELSE
        c_Exemption_Rate := Indeminfo.Exemption_Rate;
      END IF;

      --enf. katsayisini bul.
	  -- 44.m ----------------------------------------------
      c_Max_Increase := 1;

      IF Nvl(Indeminfo.Max_Increase, 1) != 1 THEN
        BEGIN
          SELECT a.Max_Inc_Clearing_System_Id,
                 a.Max_Inc_Curr_Get_Type,
                 a.Max_Inc_Swift_Code
            INTO v_Max_Inc_Clearing_System_Id,
                 v_Max_Inc_Curr_Get_Type,
                 v_Max_Inc_Swift_Code
            FROM Koc_Oc_Prod_Package_Rel a
           WHERE a.Product_Id = Policyinfo.Product_Id
             AND a.Partition_Type = Policyinfo.Partition_Type
             AND a.Package_Id = Policyinfo.Package_Id
             AND a.Dim_Value = Policyinfo.Group_Code
             AND a.Validity_Start_Date <= Trunc(p_Date)
             AND Nvl(a.Validity_End_Date, Trunc(p_Date)) >= Trunc(p_Date);
        EXCEPTION
          WHEN OTHERS THEN
            SELECT a.Max_Inc_Clearing_System_Id,
                   a.Max_Inc_Curr_Get_Type,
                   a.Max_Inc_Swift_Code
              INTO v_Max_Inc_Clearing_System_Id,
                   v_Max_Inc_Curr_Get_Type,
                   v_Max_Inc_Swift_Code
              FROM Koc_Oc_Prod_Package_Rel a
             WHERE a.Product_Id = Policyinfo.Product_Id
               AND a.Partition_Type = Policyinfo.Partition_Type
               AND a.Package_Id = Policyinfo.Package_Id
               AND a.Dim_Value = '0'
               AND a.Validity_Start_Date <= Trunc(p_Date)
               AND Nvl(a.Validity_End_Date, Trunc(p_Date)) >= Trunc(p_Date);
        END;

        c_Max_Increase := Koc_Curr_Utils.Retrieve_Currency_Rate(v_Max_Inc_Swift_Code,
                                                                v_Max_Inc_Curr_Get_Type,
                                                                Trunc(p_Date),
                                                                v_Max_Inc_Clearing_System_Id,
                                                                TRUE) /
                          Koc_Curr_Utils.Retrieve_Currency_Rate(v_Max_Inc_Swift_Code,
                                                                v_Max_Inc_Curr_Get_Type,
                                                                Trunc(Policyinfo.Policy_Start_Date),
                                                                v_Max_Inc_Clearing_System_Id,
                                                                TRUE);

        IF c_Max_Increase > Nvl(Indeminfo.Max_Increase, 1) THEN
          c_Max_Increase := Nvl(Indeminfo.Max_Increase, 1);
        END IF;

        IF c_Max_Increase < 1 THEN
          c_Max_Increase := 1;
        END IF;
      END IF;
      -- 44.r ---------------------------------------------------------------------
      -- c_r_cover_price  kurum tanimi da dikkate alinarak bulunanan kalan limit
      -- c_r_day_seance kurum tanimi da dikkate alinarak bulunanan kalan limit
      -- c_f_cover_price kurum tanimi da dikkate alinarak bulunanan  limit
      -- c_f_day_seance kurum tanimi da dikkate alinarak bulunanan  limit

      IF Nvl(c_Inst_Exemption_Sum, 0) > 0 THEN
        IF Nvl(c_Inst_Exemption_Sum, 0) >= c_Provision_Amount THEN
          c_Inst_Exemption_Sum := c_Provision_Amount;
          c_Provision_Amount   := 0;
        ELSE
          c_Provision_Amount := c_Provision_Amount -
                                Nvl(c_Inst_Exemption_Sum, 0);
        END IF;
      END IF;

      --27032014
      --aaktas
      --kurum için muafiyet çalismasin
      --
      -- Muafiyet tutarini düzenleme
      --
      /* c_Exemption_Sum := 0;
      IF Nvl(c_Inst_Is_Not_Valid_Exemp, 0) = 0
      THEN
          IF Nvl(Indeminfo.r_Exemption_Sum, 0) > 0 AND
               Indeminfo.Exemption_Group IS NOT NULL
          THEN
              IF Nvl(Indeminfo.r_Exemption_Sum, 0) >= c_Provision_Amount
              THEN
                  c_Exemption_Sum    := c_Provision_Amount;
                  c_Provision_Amount := 0;
              ELSE
                  c_Exemption_Sum    := Nvl(Indeminfo.r_Exemption_Sum, 0);
                  c_Provision_Amount := c_Provision_Amount - c_Exemption_Sum;
              END IF;
          END IF;
      END IF; */
      --
      c_Exemption_Sum := 0;

      IF Nvl(c_Inst_Is_Not_Valid_Exemp, 0) = 0 THEN
        IF (Nvl(Indeminfo.r_Exemption_Sum, 0) > 0 OR
           p_Exemption_Ovr_Amount IS NOT NULL) AND
           Indeminfo.Exemption_Group IS NOT NULL THEN
          -- Muafiyet tutarini düzenleme
          IF p_Exemption_Ovr_Amount IS NOT NULL THEN
            c_Exemption_Sum := p_Exemption_Ovr_Amount;
          ELSE
            IF Nvl(Indeminfo.r_Exemption_Sum, 0) >= c_Provision_Amount THEN
              c_Exemption_Sum := c_Provision_Amount;
            ELSE
              c_Exemption_Sum := Nvl(Indeminfo.r_Exemption_Sum, 0);
            END IF;
          END IF;

          c_Provision_Amount := c_Provision_Amount - c_Exemption_Sum;
        END IF;
      END IF;
      
      -- 44. s checkDaySeance -----------------------------------------------------------	  
      c_Day_Seance := Nvl(p_Day_Seance, 0);

      --
      IF Indeminfo.Indemnity_Payment_Type IN ('NORM', '1KEZ') THEN
        --
        IF c_Is_Unlimited = 1 THEN
          IF Nvl(c_r_Day_Seance, 0) < c_Day_Seance THEN
            IF c_r_Day_Seance = 0 THEN
              c_Day_Seance_Amount := 0;
            ELSE
              c_Day_Seance_Amount := Nvl(c_r_Day_Seance, 0) *
                                     (c_Provision_Amount / c_Day_Seance);
            END IF;

            -- kalan seans sayisinin miktari kadar ödeme yapilir.
            IF c_Day_Seance_Amount < c_Provision_Amount THEN
              c_Provision_Amount := c_Day_Seance_Amount;
            END IF;

            c_Day_Seance := Nvl(c_r_Day_Seance, 0);
          END IF;

          u_r_Cover_Price      := NULL;
          u_r_Exemption_Sum    := c_Exemption_Sum;
          u_s_Provision_Amount := c_Provision_Amount *
                                  (1 - c_Exemption_Rate);
          u_s_Spend_Total      := p_Provision_Amount;

          --- güne göre c_prov amount degisiyor spend ilk deger olmali
          u_s_Spend_Day_Seance := p_Day_Seance;

          --- güne göre c_day_seance amount degisiyor spend ilk deger olmali
          u_s_Exemption_Sum := c_Exemption_Sum;
          u_r_Day_Seance    := c_Day_Seance;
        ELSE
          --Mustafa Ku Limit asim ve muafiyet ayni anda geldiginde hataya neden oluyor
          --Hibrit testleri esnasinda ortaya çikti 20.03.2016
          /*                   IF Nvl(c_r_Cover_Price, 0) * c_Max_Increase <  c_Provision_Amount   - c_Exemption_Sum
          THEN

                  c_Provision_Amount := Nvl(c_r_Cover_Price, 0) * c_Max_Increase ;

          END IF;*/

          IF Nvl(c_r_Cover_Price, 0) * c_Max_Increase < c_Provision_Amount THEN
            c_Provision_Amount := Nvl(c_r_Cover_Price, 0) * c_Max_Increase;
          END IF;

          /* --yasemin
          IF Nvl(c_r_Cover_Price, 0) * c_Max_Increase < (c_Provision_Amount + c_Exemption_Sum)
          THEN
              -- kalan limitin exemption sumdan küçük olmasi durumuda kontrol edildi. bu tip bir durum olur mu ? bilmiyorum!
              IF Nvl(c_r_Cover_Price, 0) * c_Max_Increase > c_Exemption_Sum
              THEN
                  c_Provision_Amount := Nvl(c_r_Cover_Price, 0) * c_Max_Increase - c_Exemption_Sum;
              ELSE
                  c_Provision_Amount := 0;
                  c_Exemption_Sum    := Nvl(c_r_Cover_Price, 0) * c_Max_Increase;
              END IF;
          END IF;*/

          --
          IF Nvl(c_r_Day_Seance, 0) < c_Day_Seance THEN
            IF c_r_Day_Seance = 0 THEN
              c_Day_Seance_Amount := 0;
            ELSE
              --abdullah
              --08122014
              --talep edilen seansin birim fiyati alinmali

              --c_day_seance_amount := nvl (c_r_day_seance, 0) * (c_provision_amount / c_day_seance);
              c_Day_Seance_Amount := Nvl(c_r_Day_Seance, 0) *
                                     (p_Provision_Amount / c_Day_Seance);

              IF c_Day_Seance_Amount > c_Provision_Amount THEN
                c_Day_Seance_Amount := c_Provision_Amount;

                IF c_r_Day_Seance >
                   Round(c_Provision_Amount /
                         (p_Provision_Amount / c_Day_Seance)) THEN
                  c_r_Day_Seance := Round(c_Provision_Amount /
                                          (p_Provision_Amount /
                                          c_Day_Seance));
                END IF;
              END IF;
            END IF;

            -- kalan seans sayisinin miktari kadar ödeme yapilir.
            IF c_Day_Seance_Amount < c_Provision_Amount THEN
              c_Provision_Amount := c_Day_Seance_Amount;
            END IF;

            c_Day_Seance := Nvl(c_r_Day_Seance, 0);
          END IF;

          u_r_Cover_Price      := c_Provision_Amount; -- + c_exemption_sum; 17/01/2011 muafiyetin kalan limitten düsmemesi için yg
          u_r_Day_Seance       := c_Day_Seance;
          u_r_Exemption_Sum    := c_Exemption_Sum;
          u_s_Provision_Amount := c_Provision_Amount *
                                  (1 - c_Exemption_Rate);
          u_s_Spend_Total      := p_Provision_Amount;

          --- güne göre c_prov amount degisiyor spend ilk deger olmali
          u_s_Spend_Day_Seance := p_Day_Seance;

          --- güne göre c_day_seance amount degisiyor spend ilk deger olmali
          u_s_Exemption_Sum := c_Exemption_Sum;
        END IF;
	  -- 44.t ---------------------------------------------	
      ELSIF Indeminfo.Indemnity_Payment_Type = 'GUN' THEN
        --
        IF c_Day_Seance > c_r_Day_Seance THEN
          c_Day_Seance := c_r_Day_Seance;
        END IF;

        --
        IF Nvl(c_Day_Seance, 0) = 0 THEN
          --
          IF c_Provision_Amount > c_f_Cover_Price THEN
            c_Provision_Amount := c_f_Cover_Price;
          END IF;
        ELSE
          --
          IF c_Provision_Amount > c_f_Cover_Price * c_Day_Seance THEN
            c_Provision_Amount := c_f_Cover_Price * c_Day_Seance;
          END IF;
        END IF;

        u_r_Day_Seance       := c_Day_Seance;
        u_r_Cover_Price      := NULL;
        u_r_Exemption_Sum    := c_Exemption_Sum;
        u_s_Provision_Amount := c_Provision_Amount * (1 - c_Exemption_Rate);
        u_s_Spend_Total      := p_Provision_Amount;
        u_s_Spend_Day_Seance := p_Day_Seance;
        u_s_Exemption_Sum    := c_Exemption_Sum;
		
	  -- 44.u --------------------------------------------------- 	
      ELSIF Indeminfo.Indemnity_Payment_Type = 'DEFA' THEN

        IF p_Process_Type = 3 THEN
          Getindemtotalsmdftmp(p_Contract_Id,
                               p_Partition_No,
                               p_Claim_Inst_Type,
                               p_Claim_Inst_Loc,
                               p_Country_Group,
                               Indeminfo.Parent_Cover_Code,
                               p_Policyinfo.Package_Id,
                               p_Policyinfo.Package_Date,
                               Trunc(p_Date),
                               p_User_Id,
                               p_Is_Pool_Cover,
                               p_Is_Special_Cover,
                               Cur);
          FETCH Cur
            INTO Indeminfoparent;
          CLOSE Cur;
        ELSE
          Getindemtotalsmdf(p_Contract_Id,
                            p_Partition_No,
                            p_Claim_Inst_Type,
                            p_Claim_Inst_Loc,
                            p_Country_Group,
                            Indeminfo.Parent_Cover_Code,
                            p_Policyinfo.Package_Id,
                            p_Policyinfo.Package_Date,
                            Trunc(p_Date),
                            p_User_Id,
                            p_Is_Pool_Cover,
                            p_Is_Special_Cover,
                            Cur);
          FETCH Cur
            INTO Indeminfoparent;
          CLOSE Cur;

        END IF;

        c_Parent_Is_Unlimited   := Nvl(Indeminfoparent.Is_Unlimited, 0);
        c_Parent_Indemnity_Type := Nvl(Indeminfoparent.Indemnity_Payment_Type,
                                       'X');
        c_Parent_r_Cover_Price  := Indeminfoparent.r_Cover_Price;

        IF c_Parent_Is_Unlimited = 0 AND
           c_Parent_Indemnity_Type IN ('NORM', '1KEZ') THEN
          c_Parent_Provision_Amount := c_Provision_Amount;

          IF Nvl(c_Parent_r_Cover_Price, 0) * c_Max_Increase <
             (c_Provision_Amount + c_Exemption_Sum) THEN
            -- kalan limitin exemption sumdan küçük olmasi durumuda kontrol edildi. bu tip bir durum olur mu ? bilmiyorum!
            IF Nvl(c_Parent_r_Cover_Price, 0) * c_Max_Increase >
               c_Exemption_Sum THEN
              c_Parent_Provision_Amount := Nvl(c_Parent_r_Cover_Price, 0) *
                                           c_Max_Increase - c_Exemption_Sum;
            ELSE
              c_Parent_Provision_Amount := 0;
              c_Exemption_Sum           := Nvl(c_Parent_r_Cover_Price, 0) *
                                           c_Max_Increase;
            END IF;
          END IF;
        END IF;

        IF c_Provision_Amount > c_f_Cover_Price THEN
          c_Provision_Amount := c_f_Cover_Price;
        END IF;

        IF c_Parent_Is_Unlimited = 0 AND
           c_Parent_Indemnity_Type IN ('NORM', '1KEZ') THEN
          IF c_Provision_Amount > c_Parent_Provision_Amount THEN
            c_Provision_Amount := c_Parent_Provision_Amount;
          END IF;
        END IF;

        IF c_Day_Seance > c_r_Day_Seance THEN
          c_Day_Seance := c_r_Day_Seance;
        END IF;

        u_r_Day_Seance  := c_Day_Seance;
        u_r_Cover_Price := NULL;

        IF c_Parent_Is_Unlimited = 0 AND
           c_Parent_Indemnity_Type IN ('NORM', '1KEZ') THEN
          u_r_Cover_Price := c_Provision_Amount;
        END IF;

        u_r_Exemption_Sum    := c_Exemption_Sum;
        u_s_Provision_Amount := c_Provision_Amount * (1 - c_Exemption_Rate);
        u_s_Spend_Total      := p_Provision_Amount;
        u_s_Spend_Day_Seance := p_Day_Seance;
        u_s_Exemption_Sum    := c_Exemption_Sum;
      ELSIF Indeminfo.Indemnity_Payment_Type = '2YIL' THEN
        IF Nvl(Indeminfo.s_Spend_Total, 0) > 0 THEN
          c_Provision_Amount := 0;
          c_Day_Seance       := 0;
        ELSE
          Getoldpolicy(p_Contract_Id,
                       p_Partition_No,
                       p_Part_Id,
                       v_Old_Contract_Id,
                       v_Old_Partition_No,
                       v_Term_End_Date);

          IF p_Process_Type = 3 THEN
            Getindemtotalstmp(v_Old_Contract_Id,
                              v_Old_Partition_No,
                              p_Claim_Inst_Type,
                              p_Claim_Inst_Loc,
                              p_Country_Group,
                              p_Cover_Code,
                              v_Term_End_Date,
                              0,
                              0,
                              p_User_Id,
                              p_Is_Pool_Cover,
                              p_Is_Special_Cover,
                              Cur);

          ELSE
            Getindemtotals(v_Old_Contract_Id,
                           v_Old_Partition_No,
                           p_Claim_Inst_Type,
                           p_Claim_Inst_Loc,
                           p_Country_Group,
                           p_Cover_Code,
                           v_Term_End_Date,
                           0,
                           0,
                           p_User_Id,
                           p_Is_Pool_Cover,
                           p_Is_Special_Cover,
                           Cur);

          END IF;
          FETCH Cur
            INTO Oldindeminfo;

          CLOSE Cur;

          IF Nvl(Oldindeminfo.s_Spend_Total, 0) > 0 THEN
            c_Provision_Amount := 0;
            c_Day_Seance       := 0;
          ELSE
            IF c_Provision_Amount > c_f_Cover_Price THEN
              c_Provision_Amount := c_f_Cover_Price;
            END IF;

            IF c_Day_Seance > c_f_Day_Seance THEN
              c_Day_Seance := c_f_Day_Seance;
            END IF;
          END IF;
        END IF;

        u_r_Day_Seance       := c_Day_Seance;
        u_r_Cover_Price      := 0;
        u_r_Exemption_Sum    := 0;
        u_s_Provision_Amount := c_Provision_Amount * (1 - c_Exemption_Rate);
        u_s_Spend_Total      := p_Provision_Amount;
        u_s_Spend_Day_Seance := p_Day_Seance;
        u_s_Exemption_Sum    := c_Exemption_Sum;
      END IF;
      -- 44.y --------------------------------------------------------------
      p_Out_Provision_Amount := Round(c_Provision_Amount * (1 / v_Parite),
                                      Find_Round_Digit(p_Swift_Code, 'P'));
      p_Out_Day_Seance       := c_Day_Seance;
      p_Out_Exemption_Rate   := c_Exemption_Rate;
      p_Out_Exemption_Sum    := Round(c_Exemption_Sum * (1 / v_Parite),
                                      Find_Round_Digit(p_Swift_Code, 'P'));
      p_Out_Inst_Exemp_Sum   := Round(c_Inst_Exemption_Sum * (1 / v_Parite),
                                      Find_Round_Digit(p_Swift_Code, 'P'));

      --kalan limiti bulmak için geldiginde anlamli.
      p_r_Day_Seance  := c_r_Day_Seance;
      p_r_Cover_Price := Round(c_r_Cover_Price,
                               Find_Round_Digit(p_Swift_Code, 'P'));

      --mustafaku
      -- Limit asim ve muafiyet beraber oldugunda probleme neden oluyor Hibrit testleri esnasinda ortaya çikti
      /*            IF p_r_Cover_Price < p_Provision_Amount - c_Exemption_Sum
      THEN
          p_Out_Over_Price := To_Char(p_Provision_Amount - p_r_Cover_Price - c_Exemption_Sum) * (1 / v_Parite);
      ELSE
          p_Out_Over_Price := 0;
      END IF; */
      IF p_r_Cover_Price < p_Provision_Amount THEN
        p_Out_Over_Price := To_Char(p_Provision_Amount - p_r_Cover_Price) *
                            (1 / v_Parite);
      ELSE
        p_Out_Over_Price := 0;
      END IF;

      p_Inst_Provision_Aval_Code := c_Inst_Provision_Aval_Code;
      p_Inst_Is_Cover_Val        := c_Inst_Is_Cover_Val;
    END IF;
    -- 46.madde (44.z) --  
    IF p_Process_Type IN (1) THEN
      -- REPLICA
      -- 46.a------------------------------------------------------	  
      IF Koc_Clm_Hlth_Utils.Whichdbprocworking = 3 THEN
        u_r_Exemption_Sum := Round(Nvl(u_r_Exemption_Sum, 0),
                                   Find_Round_Digit(p_Swift_Code, 'P'));
        u_r_Cover_Price   := Round(u_r_Cover_Price,
                                   Find_Round_Digit(p_Swift_Code, 'P'));

        UPDATE Rep_Clm_Hlth_Indem_Totals a
           SET a.r_Exemption_Sum = Nvl(a.r_Exemption_Sum, 0) -
                                   Nvl(u_r_Exemption_Sum, 0)
         WHERE a.Record_Status IS NULL
           AND a.Contract_Id = p_Contract_Id
           AND a.Partition_No = p_Partition_No
           AND a.Validity_Start_Date <= p_Date
           AND Nvl(a.Validity_End_Date, p_Date) >= p_Date
           AND a.Exemption_Group = Indeminfo.Exemption_Group;

        Updaterelatedcoveronrep(p_Contract_Id,
                                p_Partition_No,
                                p_Cover_Code,
                                Indeminfo.Package_Id,
                                Indeminfo.Package_Date,
                                p_Country_Group,
                                p_Claim_Inst_Type,
                                p_Claim_Inst_Loc,
                                Indeminfo.Is_Pool_Cover,
                                Indeminfo.Is_Special_Cover,
                                p_Date,
                                u_r_Cover_Price,
                                u_r_Day_Seance,
                                NULL,
                                NULL,
                                NULL,
                                NULL,
                                NULL,
                                NULL,
                                NULL,
                                NULL,
                                p_Prov_Date_Time,
                                1);
    -- 46.b ---------------------------------------------------------------
      ELSE
	  
        u_s_Provision_Amount := Round(Nvl(u_s_Provision_Amount, 0),
                                      Find_Round_Digit(p_Swift_Code, 'P'));
        u_s_Spend_Total      := Round(Nvl(u_s_Spend_Total, 0),
                                      Find_Round_Digit(p_Swift_Code, 'P'));
        u_s_Exemption_Sum    := Round(Nvl(u_s_Exemption_Sum, 0),
                                      Find_Round_Digit(p_Swift_Code, 'P'));
        u_r_Exemption_Sum    := Round(Nvl(u_r_Exemption_Sum, 0),
                                      Find_Round_Digit(p_Swift_Code, 'P'));
        u_r_Cover_Price      := Round(u_r_Cover_Price,
                                      Find_Round_Digit(p_Swift_Code, 'P'));

        UPDATE Koc_Clm_Hlth_Indem_Totals a
           SET a.s_Provision_Amount = Nvl(a.s_Provision_Amount, 0) +
                                      Nvl(u_s_Provision_Amount, 0),
               a.s_Spend_Total      = Nvl(a.s_Spend_Total, 0) +
                                      Nvl(u_s_Spend_Total, 0),
               a.s_Spend_Day_Seance = Nvl(a.s_Spend_Day_Seance, 0) +
                                      Nvl(u_s_Spend_Day_Seance, 0),
               a.s_Exemption_Sum    = Nvl(a.s_Exemption_Sum, 0) +
                                      Nvl(u_s_Exemption_Sum, 0)
         WHERE a.Contract_Id = p_Contract_Id
           AND (a.Partition_No = p_Partition_No OR
               a.Partition_No =
               Decode(Indeminfo.Is_Pool_Cover, 0, p_Partition_No, 0))
           AND a.Claim_Inst_Type = Indeminfo.Claim_Inst_Type
           AND a.Claim_Inst_Loc = Indeminfo.Claim_Inst_Loc
           AND a.Country_Group = Indeminfo.Country_Group
           AND a.Cover_Code = p_Cover_Code
           AND a.Main_Or_Sub_Cov = 'ALT'
           AND Nvl(a.Is_Valid, 0) = 1
           AND a.Is_Pool_Cover = Indeminfo.Is_Pool_Cover
           AND a.Is_Special_Cover = Indeminfo.Is_Special_Cover
           AND a.Package_Id = Indeminfo.Package_Id
           AND a.Package_Date = Indeminfo.Package_Date
           AND a.Validity_Start_Date =
               (SELECT MAX(Aa.Validity_Start_Date)
                  FROM Koc_Clm_Hlth_Indem_Totals Aa
                 WHERE Aa.Contract_Id = a.Contract_Id
                   AND Aa.Partition_No = a.Partition_No
                   AND Aa.Claim_Inst_Type = a.Claim_Inst_Type
                   AND Aa.Claim_Inst_Loc = a.Claim_Inst_Loc
                   AND Aa.Country_Group = a.Country_Group
                   AND Aa.Cover_Code = a.Cover_Code
                   AND Aa.Is_Special_Cover = a.Is_Special_Cover
                   AND Aa.Is_Pool_Cover = a.Is_Pool_Cover
                   AND Aa.Package_Date = a.Package_Date
                   AND Aa.Package_Id = a.Package_Id
                   AND Nvl(Aa.Is_Valid, 0) = 1
                   AND Aa.Validity_Start_Date <= p_Date);

        UPDATE Koc_Clm_Hlth_Indem_Totals a
           SET a.r_Exemption_Sum = Nvl(a.r_Exemption_Sum, 0) -
                                   Nvl(u_r_Exemption_Sum, 0)
         WHERE a.Contract_Id = p_Contract_Id
           AND a.Partition_No = p_Partition_No
           AND a.Validity_Start_Date <= Trunc(p_Date)
           AND Nvl(a.Validity_End_Date, Trunc(p_Date)) >= Trunc(p_Date)
           AND Nvl(a.Is_Valid, 0) = 1
           AND a.Exemption_Group = Indeminfo.Exemption_Group;
     -- 46.c -----------------------------------------------------------------
        j := 1;<
        v_Trans_Insured.Delete;
        Vv_Date          := Trunc(p_Date);
        Vv_Partittion_No := p_Partition_No;

        LOOP
          BEGIN
            IF Nvl(Vprodpartmdlr, 'X') <> 'MDLR' THEN
              Updaterelatedcover(Indeminfo.Contract_Id,
                                 Vv_Partittion_No,
                                 Indeminfo.Cover_Code,
                                 Indeminfo.Package_Id,
                                 Indeminfo.Package_Date,
                                 Indeminfo.Country_Group,
                                 Indeminfo.Claim_Inst_Type,
                                 Indeminfo.Claim_Inst_Loc,
                                 Indeminfo.Is_Pool_Cover,
                                 Indeminfo.Is_Special_Cover,
                                 Vv_Date,
                                 u_r_Cover_Price,
                                 u_r_Day_Seance,
                                 NULL,
                                 NULL,
                                 NULL,
                                 NULL,
                                 NULL,
                                 NULL,
                                 NULL,
                                 NULL,
                                 p_Prov_Date_Time,
                                 1);
            ELSE
              Updaterelatedcovermdlr(Indeminfo.Contract_Id,
                                     Vv_Partittion_No,
                                     Indeminfo.Cover_Code,
                                     Indeminfo.Package_Id,
                                     Indeminfo.Package_Date,
                                     Indeminfo.Sub_Package_Id,
                                     Indeminfo.Sub_Package_Date,
                                     Indeminfo.Country_Group,
                                     Indeminfo.Claim_Inst_Type,
                                     Indeminfo.Claim_Inst_Loc,
                                     Indeminfo.Is_Pool_Cover,
                                     Indeminfo.Is_Special_Cover,
                                     Vv_Date,
                                     u_r_Cover_Price,
                                     u_r_Day_Seance,
                                     NULL,
                                     NULL,
                                     NULL,
                                     NULL,
                                     NULL,
                                     NULL,
                                     NULL,
                                     NULL,
                                     p_Prov_Date_Time,
                                     1);
            END IF;
          EXCEPTION
            WHEN OTHERS THEN
              --
              --abdullah aktas/emre elçik
              --anlamli hata yakalama
              --08012014

              Hltprv_Log        := Hltprv_Log_Typ();
              Hltprv_Log.Log_Id := NULL;

              Hltprv_Log.Servicename := 'KOC_CLM_HLTH_TRNX';
              Hltprv_Log.Processinfo := 'COMPUTEREMANING';
              Hltprv_Log.Note        := 'Teminat seçim esnasinda teknik bir hata olustu';
              Hltprv_Log.Content     := 'sqlerrm              : ' ||
                                        SQLERRM || Chr(10) ||
                                        'p_contract_id        : ' ||
                                        p_Contract_Id || Chr(10) ||
                                        'p_partition_no       : ' ||
                                        p_Partition_No || Chr(10) ||
                                        'p_claim_inst_type    : ' ||
                                        p_Claim_Inst_Type || Chr(10) ||
                                        'p_claim_inst_loc     : ' ||
                                        p_Claim_Inst_Loc || Chr(10) ||
                                        'p_country_group      : ' ||
                                        p_Country_Group || Chr(10) ||
                                        'p_cover_code         : ' ||
                                        p_Cover_Code || Chr(10) ||
                                        'package_id           : ' ||
                                        p_Policyinfo.Package_Id || Chr(10) ||
                                        'package_date         : ' ||
                                        p_Policyinfo.Package_Date ||
                                        Chr(10) ||
                                        'p_date               : ' || p_Date ||
                                        Chr(10) ||
                                        'p_user_id            : ' ||
                                        p_User_Id || Chr(10) ||
                                        'p_is_pool_cover      : ' ||
                                        p_Is_Pool_Cover || Chr(10) ||
                                        'p_is_special_cover   : ' ||
                                        p_Is_Special_Cover || Chr(10) ||
                                        'modüler saglik mi    : ' ||
                                        Vprodpartmdlr || Chr(10) ||
                                        'sub_package_id       : ' ||
                                        Indeminfo.Sub_Package_Id || Chr(10) ||
                                        'sub_package_date     : ' ||
                                        Indeminfo.Sub_Package_Date;

              Hltprv_Log.Savelogwithpragma;

              -- engine 18/05/2017 TPA
              /*Raise_Application_Error(-20200,
              'Teknik bir hata olustu! Hata takip numarasi: ' || Hltprv_Log.Log_Id ||
                                                     ' ile Allianz provizyon merkezine basvurunuz.');*/

              v_Company_Code := Alz_Tpa_Core_Utils.Get_Company_Code(p_Contract_Id => p_Contract_Id);

              v_Message_Fields := '<LOG_ID:' || Hltprv_Log.Log_Id || '>';

              v_Message := Alz_Tpa_Claim_Utils.Get_Alz_Message(p_Message_Name   => 'APPLY_WITH_REFERENCE_PROVISION_CENTER_FOR_ERROR',
                                                               p_Message_Fields => v_Message_Fields,
                                                               p_Company_Code   => v_Company_Code);
              Raise_Application_Error(-20200, v_Message);
              -- engine 18/05/2017 TPA
          END;

          IF Indeminfo.Is_Pool_Cover = 1 THEN
            --yasemin
            Updaterelatedpoolcover(Indeminfo.Contract_Id,
                                   0,
                                   Indeminfo.Cover_Code,
                                   Indeminfo.Package_Id,
                                   Indeminfo.Package_Date,
                                   Vv_Date,
                                   u_r_Cover_Price,
                                   u_r_Day_Seance,
                                   p_Prov_Date_Time,
                                   1);
          END IF;

          v_Exit := FALSE;
          i      := 1;

          WHILE v_Trans_Insured.Count >= i LOOP
            IF v_Trans_Insured(i)
             .Contract_Id = Indeminfo.Trans_Contract_Id AND v_Trans_Insured(i)
               .Partition_No = Indeminfo.Trans_Partition_No THEN
              v_Exit := TRUE;
            END IF;

            i := i + 1;
          END LOOP;

          v_Trans_Insured(j).Contract_Id := Indeminfo.Trans_Contract_Id;
          v_Trans_Insured(j).Partition_No := Indeminfo.Trans_Partition_No;
          j := j + 1;

          EXIT WHEN(Indeminfo.Trans_Contract_Id IS NULL OR v_Exit);
          -- 46.c ---------------------------------------------------
          Koc_Clm_Hlth_Utils.Getpolinfoforindemnity(Indeminfo.Trans_Contract_Id,
                                                    Indeminfo.Trans_Partition_No,
                                                    NULL,
                                                    Cur);

          FETCH Cur
            INTO Policyinfo;

          IF Cur%NOTFOUND THEN
            Dbms_Output.Put_Line('policyInfo  bulunamadi.');

            CLOSE Cur;

            EXIT;
          END IF;

          CLOSE Cur;

          Vv_Date          := Policyinfo.Term_End_Date;
          Vv_Partittion_No := Indeminfo.Trans_Partition_No;

          Getindemtotalsmdf(Indeminfo.Trans_Contract_Id,
                            Indeminfo.Trans_Partition_No,
                            Indeminfo.Claim_Inst_Type,
                            Indeminfo.Claim_Inst_Loc,
                            Indeminfo.Country_Group,
                            Indeminfo.Cover_Code,
                            Policyinfo.Package_Id,
                            Policyinfo.Package_Date,
                            Policyinfo.Term_End_Date,
                            p_User_Id,
                            Indeminfo.Is_Pool_Cover,
                            Indeminfo.Is_Special_Cover,
                            Cur);

          FETCH Cur
            INTO Indeminfo;

          IF Cur%NOTFOUND THEN
            Dbms_Output.Put_Line('trans indem info bulunamadi.');

            CLOSE Cur;

            EXIT;
          ELSE
            NULL;
          END IF;

          CLOSE Cur;
        END LOOP;
      END IF;
	-- 47.madde (44.z1) --------------------------------------------------------------------  
    ELSIF p_Process_Type = 3 THEN
      -- 47.a ------------------------------------------------------------------------
      u_s_Provision_Amount := Round(Nvl(u_s_Provision_Amount, 0),
                                    Find_Round_Digit(p_Swift_Code, 'P'));
      u_s_Spend_Total      := Round(Nvl(u_s_Spend_Total, 0),
                                    Find_Round_Digit(p_Swift_Code, 'P'));
      u_s_Exemption_Sum    := Round(Nvl(u_s_Exemption_Sum, 0),
                                    Find_Round_Digit(p_Swift_Code, 'P'));
      u_r_Exemption_Sum    := Round(Nvl(u_r_Exemption_Sum, 0),
                                    Find_Round_Digit(p_Swift_Code, 'P'));
      u_r_Cover_Price      := Round(u_r_Cover_Price,
                                    Find_Round_Digit(p_Swift_Code, 'P'));

      UPDATE Koc_Clm_Hlth_Tmp_Indem_Totals a
         SET a.s_Provision_Amount = Nvl(a.s_Provision_Amount, 0) +
                                    Nvl(u_s_Provision_Amount, 0),
             a.s_Spend_Total      = Nvl(a.s_Spend_Total, 0) +
                                    Nvl(u_s_Spend_Total, 0),
             a.s_Spend_Day_Seance = Nvl(a.s_Spend_Day_Seance, 0) +
                                    Nvl(u_s_Spend_Day_Seance, 0),
             a.s_Exemption_Sum    = Nvl(a.s_Exemption_Sum, 0) +
                                    Nvl(u_s_Exemption_Sum, 0)
       WHERE a.Contract_Id = p_Contract_Id
         AND (a.Partition_No = p_Partition_No OR
             a.Partition_No =
             Decode(Indeminfo.Is_Pool_Cover, 0, p_Partition_No, 0))
         AND a.Claim_Inst_Type = Indeminfo.Claim_Inst_Type
         AND a.Claim_Inst_Loc = Indeminfo.Claim_Inst_Loc
         AND a.Country_Group = Indeminfo.Country_Group
         AND a.Cover_Code = p_Cover_Code
         AND a.Main_Or_Sub_Cov = 'ALT'
         AND Nvl(a.Is_Valid, 0) = 1
         AND a.Is_Pool_Cover = Indeminfo.Is_Pool_Cover
         AND a.Is_Special_Cover = Indeminfo.Is_Special_Cover
         AND a.Package_Id = Indeminfo.Package_Id
         AND a.Package_Date = Indeminfo.Package_Date
         AND a.Validity_Start_Date =
             (SELECT MAX(Aa.Validity_Start_Date)
                FROM Koc_Clm_Hlth_Tmp_Indem_Totals Aa
               WHERE Aa.Contract_Id = a.Contract_Id
                 AND Aa.Partition_No = a.Partition_No
                 AND Aa.Claim_Inst_Type = a.Claim_Inst_Type
                 AND Aa.Claim_Inst_Loc = a.Claim_Inst_Loc
                 AND Aa.Country_Group = a.Country_Group
                 AND Aa.Cover_Code = a.Cover_Code
                 AND Aa.Is_Special_Cover = a.Is_Special_Cover
                 AND Aa.Is_Pool_Cover = a.Is_Pool_Cover
                 AND Aa.Package_Date = a.Package_Date
                 AND Aa.Package_Id = a.Package_Id
                 AND Nvl(Aa.Is_Valid, 0) = 1
                 AND Aa.Validity_Start_Date <= p_Date);

      UPDATE Koc_Clm_Hlth_Tmp_Indem_Totals a
         SET a.r_Exemption_Sum = Nvl(a.r_Exemption_Sum, 0) -
                                 Nvl(u_r_Exemption_Sum, 0)
       WHERE a.Contract_Id = p_Contract_Id
         AND a.Partition_No = p_Partition_No
         AND a.Validity_Start_Date <= Trunc(p_Date)
         AND Nvl(a.Validity_End_Date, Trunc(p_Date)) >= Trunc(p_Date)
         AND Nvl(a.Is_Valid, 0) = 1
         AND a.Exemption_Group = Indeminfo.Exemption_Group;
      -- 47.b------------------------------------------------------------
      j := 1;
      v_Trans_Insured.Delete;
      Vv_Date          := Trunc(p_Date);
      Vv_Partittion_No := p_Partition_No;

      LOOP
        BEGIN
          IF Nvl(Vprodpartmdlr, 'X') <> 'MDLR' THEN
            Updaterelatedcovertmp(Indeminfo.Contract_Id,
                                  Vv_Partittion_No,
                                  Indeminfo.Cover_Code,
                                  Indeminfo.Package_Id,
                                  Indeminfo.Package_Date,
                                  Indeminfo.Country_Group,
                                  Indeminfo.Claim_Inst_Type,
                                  Indeminfo.Claim_Inst_Loc,
                                  Indeminfo.Is_Pool_Cover,
                                  Indeminfo.Is_Special_Cover,
                                  Vv_Date,
                                  u_r_Cover_Price,
                                  u_r_Day_Seance,
                                  NULL,
                                  NULL,
                                  NULL,
                                  NULL,
                                  NULL,
                                  NULL,
                                  NULL,
                                  NULL,
                                  p_Prov_Date_Time,
                                  1);
          ELSE
            Updaterelatedcovermdlrtmp(Indeminfo.Contract_Id,
                                      Vv_Partittion_No,
                                      Indeminfo.Cover_Code,
                                      Indeminfo.Package_Id,
                                      Indeminfo.Package_Date,
                                      Indeminfo.Sub_Package_Id,
                                      Indeminfo.Sub_Package_Date,
                                      Indeminfo.Country_Group,
                                      Indeminfo.Claim_Inst_Type,
                                      Indeminfo.Claim_Inst_Loc,
                                      Indeminfo.Is_Pool_Cover,
                                      Indeminfo.Is_Special_Cover,
                                      Vv_Date,
                                      u_r_Cover_Price,
                                      u_r_Day_Seance,
                                      NULL,
                                      NULL,
                                      NULL,
                                      NULL,
                                      NULL,
                                      NULL,
                                      NULL,
                                      NULL,
                                      p_Prov_Date_Time,
                                      1);
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            --
            --abdullah aktas/emre elçik
            --anlamli hata yakalama
            --08012014

            Hltprv_Log        := Hltprv_Log_Typ();
            Hltprv_Log.Log_Id := NULL;

            Hltprv_Log.Servicename := 'KOC_CLM_HLTH_TRNX';
            Hltprv_Log.Processinfo := 'COMPUTEREMANING';
            Hltprv_Log.Note        := 'Teminat seçim esnasinda teknik bir hata olustu';
            Hltprv_Log.Content     := 'sqlerrm              : ' || SQLERRM ||
                                      Chr(10) || 'p_contract_id        : ' ||
                                      p_Contract_Id || Chr(10) ||
                                      'p_partition_no       : ' ||
                                      p_Partition_No || Chr(10) ||
                                      'p_claim_inst_type    : ' ||
                                      p_Claim_Inst_Type || Chr(10) ||
                                      'p_claim_inst_loc     : ' ||
                                      p_Claim_Inst_Loc || Chr(10) ||
                                      'p_country_group      : ' ||
                                      p_Country_Group || Chr(10) ||
                                      'p_cover_code         : ' ||
                                      p_Cover_Code || Chr(10) ||
                                      'package_id           : ' ||
                                      p_Policyinfo.Package_Id || Chr(10) ||
                                      'package_date         : ' ||
                                      p_Policyinfo.Package_Date || Chr(10) ||
                                      'p_date               : ' || p_Date ||
                                      Chr(10) || 'p_user_id            : ' ||
                                      p_User_Id || Chr(10) ||
                                      'p_is_pool_cover      : ' ||
                                      p_Is_Pool_Cover || Chr(10) ||
                                      'p_is_special_cover   : ' ||
                                      p_Is_Special_Cover || Chr(10) ||
                                      'modüler saglik mi    : ' ||
                                      Vprodpartmdlr || Chr(10) ||
                                      'sub_package_id       : ' ||
                                      Indeminfo.Sub_Package_Id || Chr(10) ||
                                      'sub_package_date     : ' ||
                                      Indeminfo.Sub_Package_Date;

            Hltprv_Log.Savelogwithpragma;

            -- engine 18/05/2017 TPA
            /*Raise_Application_Error(-20200,
            'Teknik bir hata olustu! Hata takip numarasi: ' || Hltprv_Log.Log_Id ||
                                                 ' ile Allianz provizyon merkezine basvurunuz.');*/

            v_Company_Code := Alz_Tpa_Core_Utils.Get_Company_Code(p_Contract_Id => p_Contract_Id);

            v_Message_Fields := '<LOG_ID:' || Hltprv_Log.Log_Id || '>';

            v_Message := Alz_Tpa_Claim_Utils.Get_Alz_Message(p_Message_Name   => 'APPLY_WITH_REFERENCE_PROVISION_CENTER_FOR_ERROR',
                                                             p_Message_Fields => v_Message_Fields,
                                                             p_Company_Code   => v_Company_Code);
            Raise_Application_Error(-20200, v_Message);
            -- engine 18/05/2017 TPA
        END;

        /*    IF Indeminfo.Is_Pool_Cover = 1
        THEN
          --yasemin
          Updaterelatedpoolcover(Indeminfo.Contract_Id, 0, Indeminfo.Cover_Code, Indeminfo.Package_Id, Indeminfo.Package_Date, Vv_Date,
                                 u_r_Cover_Price, u_r_Day_Seance, p_Prov_Date_Time, 1);
        END IF;*/

        v_Exit := FALSE;
        i      := 1;

        WHILE v_Trans_Insured.Count >= i LOOP
          IF v_Trans_Insured(i)
           .Contract_Id = Indeminfo.Trans_Contract_Id AND v_Trans_Insured(i)
             .Partition_No = Indeminfo.Trans_Partition_No THEN
            v_Exit := TRUE;
          END IF;

          i := i + 1;
        END LOOP;

        v_Trans_Insured(j).Contract_Id := Indeminfo.Trans_Contract_Id;
        v_Trans_Insured(j).Partition_No := Indeminfo.Trans_Partition_No;
        j := j + 1;

        EXIT WHEN(Indeminfo.Trans_Contract_Id IS NULL OR v_Exit);
        -- 47.c -------------------------------------------------------------------------------------
        Koc_Clm_Hlth_Utils.Getpolinfoforindemnity(Indeminfo.Trans_Contract_Id,
                                                  Indeminfo.Trans_Partition_No,
                                                  NULL,
                                                  Cur);

        FETCH Cur
          INTO Policyinfo;

        IF Cur%NOTFOUND THEN
          Dbms_Output.Put_Line('policyInfo  bulunamadi.');

          CLOSE Cur;

          EXIT;
        END IF;

        CLOSE Cur;

        Vv_Date          := Policyinfo.Term_End_Date;
        Vv_Partittion_No := Indeminfo.Trans_Partition_No;
        -- 47. d-------------------------------------------------------------
        Getindemtotalsmdftmp(Indeminfo.Trans_Contract_Id,
                             Indeminfo.Trans_Partition_No,
                             Indeminfo.Claim_Inst_Type,
                             Indeminfo.Claim_Inst_Loc,
                             Indeminfo.Country_Group,
                             Indeminfo.Cover_Code,
                             Policyinfo.Package_Id,
                             Policyinfo.Package_Date,
                             Policyinfo.Term_End_Date,
                             p_User_Id,
                             Indeminfo.Is_Pool_Cover,
                             Indeminfo.Is_Special_Cover,
                             Cur);

        FETCH Cur
          INTO Indeminfo;

        IF Cur%NOTFOUND THEN
          Dbms_Output.Put_Line('trans indem info bulunamadi.');

          CLOSE Cur;

          EXIT;
        ELSE
          NULL;
        END IF;

        CLOSE Cur;
      END LOOP;
    END IF;
  END;