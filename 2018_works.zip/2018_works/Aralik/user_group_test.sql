DECLARE

 CURSOR crs_user IS
          SELECT d.user_type, g.user_group       
            FROM CUSTOMER.Koc_Cp_User_Detail d, CUSTOMER.Koc_Oc_Hlth_User_Grp_Rel g
           WHERE d.Userid = 'BGEBECE'
             AND d.user_type = g.user_type
             AND d.user_type='1'
             AND d.Validity_Start_Date <= SYSDATE
             AND (d.Validity_End_Date IS NULL OR d.Validity_End_Date >= SYSDATE)
             AND g.Validity_Start_Date <= SYSDATE
             AND (g.Validity_End_Date IS NULL OR g.Validity_End_Date >= SYSDATE);
              

        
       
           
         

         v_user_group VARCHAR2(32000);   
         v_ndx NUMBER:=0;                    
     BEGIN
       
        v_user_group := '';
        
        FOR rec_user IN crs_user LOOP
          
            IF v_ndx>0 THEN
              
                v_user_group :=  v_user_group || ',';
                
            END IF;   
              
            v_user_group := v_user_group||'"'||rec_user.user_group||'"';
            
            v_ndx := v_ndx+1;  
                   
        END LOOP;
         
        v_user_group := '['||v_user_group||']';
        
        DBMS_OUTPUT.PUT_LINE(v_user_group);
        
    END;
        
        
