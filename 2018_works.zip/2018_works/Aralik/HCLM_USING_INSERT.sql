DECLARE 
   v_desc_int_id NUMBER;
BEGIN
  
select max(int_id) + 1
INTO v_desc_int_id
from  DESCRIPTIONS;

insert into DESCRIPTIONS (INT_ID, JOIN_TABLE)
values (v_desc_int_id, 'KOC_CP_HEALTH_LOOK_UP');

insert into cur_translations (SULA_ORA_NLS_CODE, DESC_INT_ID, SHORT_CODE, LONG_NAME, COMMENTS)
values ('TR', v_desc_int_id, 'HCLM_USAGE', '0-Eski Sistem,1-Sadece Portal Yeni,2-Sadece Opus Yeni,3-Yeni Sistem', null);

insert into cur_translations (SULA_ORA_NLS_CODE, DESC_INT_ID, SHORT_CODE, LONG_NAME, COMMENTS)
values ('US', v_desc_int_id, 'HCLM_USAGE', '0-Old System,1-Only Portal New,2- Only Opus New,3-New System', null);

insert into koc_cp_health_look_up (LOOK_UP_CODE, PARAMETER, DESC_INT_ID, VALIDITY_START, VALIDITY_END, USERID, ENTRY_DATE, DETAIL_EXPLANATION)
values ('HCLM_USAGE', '0', v_desc_int_id, sysdate, null, 'ADEMO', null, 'HCLM Yeni Sistem Kullan�m�');

END;
/

/*
DECLARE
n_desc_int_id NUMBER;
BEGIN
n_desc_int_id:=inf_lang_api.ins_trans('KOC_CP_HEALTH_LOOK_UP','HCLM_USAGE','0-Eski Sistem,1-Sadece Portal Yeni,2-Sadece Opus Yeni,3-Yeni Sistem','TR',null);
DBMS_OUTPUT.PUT_LINE('new desc_int_id='||n_desc_int_id);
END;
*/
select * from cur_translations where desc_int_id=584595; 

--select * from DESCRIPTIONS where JOIN_TABLE ='KOC_CP_HEALTH_LOOK_UP' and int_id=586588 for update


select * from koc_cp_health_look_up  WHERE Look_Up_Code = 'HCLM_USAGE' for update;

  SELECT *--Parameter
      --INTO v_Complex_Enable
      FROM Koc_v_Cp_Health_Look_Up
     WHERE Look_Up_Code = 'HCLM_USAGE';
     
     SELECT KOC_CLM_HLTH_UTILS.Getlookupparamvalue('HCLM_USAGE',SYSDATE) FROM DUAL

 
insert into DESCRIPTIONS (INT_ID, JOIN_TABLE)
values (586588, 'KOC_CP_HEALTH_LOOK_UP');

insert into cur_translations (SULA_ORA_NLS_CODE, DESC_INT_ID, SHORT_CODE, LONG_NAME, COMMENTS)
values ('TR', 586588, 'HCLM_USAGE', '0-Eski Sistem,1-Sadece Portal Yeni,2-Sadece Opus Yeni,3-Yeni Sistem', null);

insert into cur_translations (SULA_ORA_NLS_CODE, DESC_INT_ID, SHORT_CODE, LONG_NAME, COMMENTS)
values ('US', 586588, 'HCLM_USAGE', '0-Old System,1-Only Portal New,2- Only Opus New,3-New System', null);

insert into koc_cp_health_look_up (LOOK_UP_CODE, PARAMETER, DESC_INT_ID, VALIDITY_START, VALIDITY_END, USERID, ENTRY_DATE, DETAIL_EXPLANATION)
values ('HCLM_USAGE', '0', 584595, sysdate, null, 'ADEMO', null, 'HCLM Yeni Sistem Kullan�m�');







