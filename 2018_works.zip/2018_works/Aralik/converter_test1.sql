
DECLARE
v_ndx NUMBER:=0;
v_field_name VARCHAR2(200);
v_field_value VARCHAR2(200);
BEGIN
  
FOR rec_1 IN (SELECT COLUMN_VALUE FROM TABLE(CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.convertPayloadToTable('{
    "provisionAmount" : 0.00,
    "exemptionRate" : 0,
    "exemptionSumAmount" : 0.00,
    "instituteExemptionSumAmount" : 0.00,
    "remainedCoverPriceAmount" : 0.00,
    "overPriceAmount" : 0,
    "daySeance" : 0,
    "remainedDaySeance" : 1
  }'))) LOOP

            v_ndx := 0;
            FOR rec_2 IN (SELECT FIELD_NAME, FIELD_VALUE FROM TABLE(rec_1.COLUMN_VALUE)) LOOP
                 DBMS_OUTPUT.PUT_LINE('field_name='||rec_2.FIELD_NAME||' field_value='||rec_2.FIELD_VALUE);
                 IF v_ndx = 0 THEN
                     v_field_name := rec_2.FIELD_NAME;
                 END IF;

                 IF v_ndx = 1 THEN
                     v_field_value := rec_2.FIELD_VALUE;
                 END IF;
                 v_ndx := v_ndx + 1;
                 
            END LOOP;
            
            DBMS_OUTPUT.PUT_LINE('field_name='||v_field_name||' field_value='||v_field_value);
 END LOOP;
            
END;            
     
