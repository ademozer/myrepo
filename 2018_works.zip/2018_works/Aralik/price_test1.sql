DECLARE 
 v_process_price NUMBER;
BEGIN

 v_process_price                            := koc_clm_hlth_trnx.gettdaprocesspriceimpl(13,
'34',
83,
10,
101,
SYSDATE,
1,
null,
0.001,
null,
361942577,
1,
0,
233304
);

DBMS_OUTPUT.PUT_LINE(v_process_price);
EXCEPTION 
WHEN OTHERS THEN
   v_process_price := -1;
END;
