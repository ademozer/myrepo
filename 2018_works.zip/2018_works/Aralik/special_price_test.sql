DECLARE
v_price NUMBER;

BEGIN 
  
  v_price := Alz_General_List_Utils.Getparamnumbervalue('GL-QWR', 'DOCTOR_IDENTITY_NO=15365408002;PROCESS_TYPE=10.10.101;INSTITUTE_CODE=1750;');
  
  DBMS_OUTPUT.PUT_LINE(v_price);
  
END;
