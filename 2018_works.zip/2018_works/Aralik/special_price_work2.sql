 SELECT bb.list_id, bb.list_seq
                        FROM         (SELECT 3 COL_ID,'46804317272' VALUE, 'GENERAL_LISTS_KEY_INFO' COL_GROUP FROM DUAL) aa
                                   JOIN
                                      alz_general_lists_col_val bb
                                   ON bb.col_id = aa.col_id AND bb.col_value = aa.VALUE
                                JOIN
                                   alz_general_lists_master cc
                                ON cc.list_id = bb.list_id AND cc.reference_key = 'GL-QWR' AND cc.validity_end_date IS NULL
                             JOIN
                                alz_general_lists_details dd
                             ON dd.list_id = cc.list_id AND dd.status = 'A' AND dd.validity_end_date IS NULL
                       WHERE aa.col_group = 'GENERAL_LISTS_KEY_INFO' AND aa.VALUE IS NOT NULL
                    GROUP BY bb.list_id, bb.list_seq
