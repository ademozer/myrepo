DECLARE

         v_converter_row alz_hcl_converter_row := alz_hcl_converter_row();
         v_request CLOB;
         v_response CLOB;
         v_url VARCHAR2(200) := 'http://10.70.47.25:19101/hclm-health-claim-service/api/v1/process/price'; -- esb adresi ile de�i�ecek
         v_status NUMBER;
         v_message VARCHAR2(1000);
         v_complementary_type VARCHAR2(10);
         v_ulak_price NUMBER;
         v_price NUMBER := 0;
     BEGIN
          /*ALZ_HCLM_CONVERTER_UTILS.addParameterToTable('instituteCode', TO_CHAR(p_Institute_Code), v_converter_row);
          ALZ_HCLM_CONVERTER_UTILS.addParameterToTable('defaultCityCode', p_City_Code, v_converter_row);
          ALZ_HCLM_CONVERTER_UTILS.addParameterToTable('processCodeMain', TO_CHAR(p_Proc_Code_Main), v_converter_row);
          ALZ_HCLM_CONVERTER_UTILS.addParameterToTable('processCodeSub1', TO_CHAR(p_Proc_Code_Sub1), v_converter_row);
          ALZ_HCLM_CONVERTER_UTILS.addParameterToTable('processCodeSub2', TO_CHAR(p_Proc_Code_Sub2), v_converter_row);
          ALZ_HCLM_CONVERTER_UTILS.addParameterToTable('validityDate', TO_CHAR(p_Date,'YYYY-MM-DD'), v_converter_row);
          ALZ_HCLM_CONVERTER_UTILS.addParameterToTable('groupCode', p_Group_Code, v_converter_row);
          IF p_Is_Tss_Oss = 0 THEN
              v_complementary_type := 'OSS';
              v_ulak_price         := 1;
          ELSE
              v_complementary_type := 'TSS';
              v_ulak_price         := p_Is_Tss_Oss;
          END IF;
          ALZ_HCLM_CONVERTER_UTILS.addParameterToTable('complementaryType', v_complementary_type, v_converter_row);
          ALZ_HCLM_CONVERTER_UTILS.addParameterToTable('ulakPrice', REPLACE(TO_CHAR(v_ulak_price),',','.'), v_converter_row);
          ALZ_HCLM_CONVERTER_UTILS.addParameterToTable('ahekProvider', CASE p_Is_Ahek WHEN 1 THEN 'true' ELSE 'false' END, v_converter_row);
          ALZ_HCLM_CONVERTER_UTILS.addParameterToTable('contractId', TO_CHAR(p_Contract_Id), v_converter_row);
          ALZ_HCLM_CONVERTER_UTILS.addParameterToTable('partitionNo', TO_CHAR(p_Partition_No), v_converter_row);
          ALZ_HCLM_CONVERTER_UTILS.addParameterToTable('isReferral', CASE p_Is_Refferal WHEN 1 THEN 'true' ELSE 'false' END, v_converter_row);
          ALZ_HCLM_CONVERTER_UTILS.addParameterToTable('doctorCode', TO_CHAR(p_Doctor_Code), v_converter_row);
          ALZ_HCLM_CONVERTER_UTILS.addParameterToTable('isRoboticSurgery', CASE p_Is_Robotic_Surgery WHEN 1 THEN 'true' ELSE 'false' END, v_converter_row);
          ALZ_HCLM_CONVERTER_UTILS.addParameterToTable('isLaparoscopicSurgery', CASE p_Is_Laparoscopic_Surgery WHEN 1 THEN 'true' ELSE 'false' END, v_converter_row);

          v_request := ALZ_HCLM_CONVERTER_UTILS.convertTableToPayload(v_converter_row);*/
          v_request := '{"instituteCode" : "1289","defaultCityCode" : "34","processCodeMain" : "130","processCodeSub1" : "20","processCodeSub2" : "116","validityDate" : "2018-12-04","groupCode" : "S11183","complementaryType" : "TSS","ulakPrice" : "1","ahekProvider" : "false","contractId" : "355577538","partitionNo" : "288","isReferral" : "false","doctorCode" : "0","isRoboticSurgery" : "false","isLaparoscopicSurgery" : "false"}';
          DBMS_OUTPUT.PUT_LINE('Fiyat Hesaplama Request: '||v_request);
          ALZ_HCLM_CONVERTER_UTILS.callRestService(v_url, 'POST', v_request, v_response, v_status, v_message);
          DBMS_OUTPUT.PUT_LINE('Fiyat Hesaplama Response: '||v_response);
          IF v_status = 1 THEN
               DBMS_OUTPUT.PUT_LINE('Fiyat Hesaplama Hata: '||v_message);
               --v_response := '[{"price" : "0"}]';
               v_price := 0;
          ELSE
               BEGIN
                  v_price := TO_NUMBER(TRIM(v_response),'999999.9999');
               EXCEPTION
               WHEN OTHERS THEN
                   v_price := 0;
                   v_message := SQLERRM;
                   DBMS_OUTPUT.PUT_LINE('Fiyat Hesaplama Hata2: '||v_message);
               END;
          END IF;

          /*v_converter_row := processPayload(v_response);

          FOR rec IN (SELECT FIELD_NAME,FIELD_VALUE FROM TABLE(v_converter_row)) LOOP
              IF rec.FIELD_NAME = 'price' THEN
                  v_price := rec.FIELD_VALUE;
              END IF;
          END LOOP;*/

           DBMS_OUTPUT.PUT_LINE('Fiyat : '||v_price);

     END; 

--SELECT TO_NUMBER('4,79','') FROM DUAL
