     WITH generallists
                AS (  SELECT bb.list_id, bb.list_seq
                        FROM         (SELECT 3 COL_ID,'46804317272' VALUE, 'GENERAL_LISTS_KEY_INFO' COL_GROUP FROM DUAL) aa
                                   JOIN
                                      alz_general_lists_col_val bb
                                   ON bb.col_id = aa.col_id AND bb.col_value = aa.VALUE
                                JOIN
                                   alz_general_lists_master cc
                                ON cc.list_id = bb.list_id AND cc.reference_key = 'GL-QWR' AND cc.validity_end_date IS NULL
                             JOIN
                                alz_general_lists_details dd
                             ON dd.list_id = cc.list_id AND dd.status = 'A' AND dd.validity_end_date IS NULL
                       WHERE aa.col_group = 'GENERAL_LISTS_KEY_INFO' AND aa.VALUE IS NOT NULL
                    GROUP BY bb.list_id, bb.list_seq)
           SELECT a.list_id, a.list_seq
             FROM       generallists a
                     JOIN
                        alz_general_lists_col_val b
                     ON b.list_id = a.list_id AND b.list_seq = a.list_seq
                  JOIN
                    (SELECT 3 COL_ID,'46804317272' VALUE, 'GENERAL_LISTS_KEY_INFO' COL_GROUP FROM DUAL) c
                  ON c.col_id = b.col_id
            WHERE b.col_value IN ('*T�m�', c.VALUE)
         GROUP BY a.list_id, a.list_seq
           HAVING COUNT ( * ) = (SELECT COUNT ( * )
                                   FROM alz_general_lists_col dd
                                  WHERE dd.list_id = a.list_id AND dd.list_seq = a.list_seq)
                                  
                                  
                                   select * from alz_general_lists_master where reference_key='GL-QWR'
                                   select * from alz_general_lists_col_val where col_id=3 and col_value='46804317272'
                                   select * from alz_general_lists_col
                                   select * from alz_general_lists_details
