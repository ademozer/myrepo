select * from 
(
-- 34 Bireysel �deme Oran�
select LPAD(rule_code,2,'0') rule_code,rule_name,rule_type, rule_explanation
from koc_oc_hlth_ex_pack_rul_gr
where 1=1 -- rule_type in( '1','3')
order by 1
 -- and 63 = 63
 -- and rule_code in('11','30','31','32','33','34')
  
union all
select rule_code, rule_name, rule_explanation
from koc_oc_hlth_ex_pack_rul_gr
where rule_type in( '1','3')
  and 63 in (64,0)
  and rule_code in('11','30','31','32','33'))
order by to_number(rule_code

select * from koc_cp_user_detail where userid IN(
select user_id from ademo.kascv_users_prep@opusdev
) and userid='MEDISER28'

select * from  kascv_users
where user_id not in (
select userid from koc_cp_user_detail
)

create table kascv_users_prep(user_id VARCHAR2(100));

SELECT * from kascv_users_prep for update

GRANT SELECT ON kascv_users_prep TO PUBLIC


select count(*) from koc_clm_hlth_detail where provision_user_id IN(select USER_ID from  kascv_users
where user_id not in (
select userid from koc_cp_user_detail
))

select * from koc_cp_user_detail where userid='VCEYHAN'
select * from sec_system_users where oracle_username='VCEYHAN'
select * from web_sec_system_users where reference_opus_user='VCEYHAN'

SELECT INITCAP('eprovision_users') FROM DUAL
