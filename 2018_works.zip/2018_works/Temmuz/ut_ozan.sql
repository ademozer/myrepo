declare
  -- Non-scalar parameters require additional processing 
  ndx number:=0;
  p_quote_ref VARCHAR2(200);
  p_version_no NUMBER;
  p_product_id  NUMBER;
  p_partition_type VARCHAR2(400);
  v_default_partition_type varchar2(10) := 'TSSF';
  p_mdlr_hlth_policy customer.mdlr_hlth_policy_rec;
  p_action customer.action_rec;
  p_security_info customer.security_info_rec;
  p_simple_questions customer.simple_question_table;
  p_process_results customer.process_result_table;
  p_contract_id NUMBER;
  p_mdlr_hlth_scale_part_moduls Customer.Mdlr_Hlth_Scale_Part_Mdl_Table;
  --ndx NUMBER;
  PROCEDURE dbms_lob_append(v_clob in out clob, p_Message Varchar2) Is
      --
      v_time varchar2(100);
  Begin
      dbms_output.put_line(p_Message);
     /*IF (DBMS_LOB.ISTEMPORARY (v_clob) = 0) THEN
        DBMS_LOB.createtemporary (v_clob, TRUE);
     END IF;
     --
     v_time := to_char(systimestamp,'dd-mm-yyyy hh24:mi:ss.FF');
     IF v_clob IS NULL THEN
      v_clob := v_time||' '||p_message||chr(10);
     ELSE
      dbms_lob.APPEND(v_clob, v_time||' '||p_Message||chr(10));
     END IF;*/
     --
  End;
  procedure action_log (p_contract_id number,
                      p_action customer.action_rec) is

v_log clob;

cursor c_write_log is
select value
  from system_parameters
 where code = 'ACTION_LOG';

v_write_log system_parameters.value%type;

begin

    v_log := null;
    dbms_lob_append(v_log, 'endorsement_code : '||p_action.endorsement_code);
    dbms_lob_append(v_log, 'endors_reason_code : '||p_action.endors_reason_code);
    dbms_lob_append(v_log, 'action_name : '||p_action.action_name);
    dbms_lob_append(v_log, 'target_page : '||p_action.target_page);
    dbms_lob_append(v_log, 'current_page : '||p_action.current_page);
    dbms_lob_append(v_log, 'direction : '||p_action.direction);
    dbms_lob_append(v_log, 'button_name : '||p_action.button_name);
    dbms_lob_append(v_log, 'project_name : '||p_action.project_name);
    dbms_lob_append(v_log, 'flow_name : '||p_action.flow_name);
    dbms_lob_append(v_log, 'product_id : '||p_action.product_id);
    dbms_lob_append(v_log, 'partition_type : '||p_action.partition_type);
    dbms_lob_append(v_log, 'action_code : '||p_action.action_code);
    dbms_lob_append(v_log, 'endorsement_code_exp : '||p_action.endorsement_code_exp);
    dbms_lob_append(v_log, 'endors_reason_code_exp : '||p_action.endors_reason_code_exp);

    open c_write_log;
    fetch c_write_log into v_write_log;
    close c_write_log;

    if nvl(v_write_log, '0') = '1' then
       alz_mdlr_hlth_policy_utils7.p_insert_mdlr_log(p_contract_id, null, v_log, 'ACTION_LOG', null, null, null, 1);
       IF (DBMS_LOB.ISTEMPORARY (v_log) = 1) THEN
           DBMS_LOB.FREETEMPORARY (v_log);
       end if;
    end if;

exception when others then

    null;

end;
procedure security_info_log (p_contract_id number,
                             p_security_info customer.security_info_rec) is

v_log clob;

cursor c_write_log is
select value
  from system_parameters
 where code = 'SECURITY_INFO_LOG';

v_write_log system_parameters.value%type;

begin

    v_log := null;
    dbms_lob_append(v_log, 'ip : '||p_security_info.ip);
    dbms_lob_append(v_log, 'userid : '||p_security_info.userid);
    dbms_lob_append(v_log, 'agency_code : '||p_security_info.agency_code);
    dbms_lob_append(v_log, 'sub_agency_code : '||p_security_info.sub_agency_code);
    dbms_lob_append(v_log, 'login_date : '||p_security_info.login_date);
    dbms_lob_append(v_log, 'identity_no : '||p_security_info.identity_no);

    open c_write_log;
    fetch c_write_log into v_write_log;
    close c_write_log;

    if nvl(v_write_log, '0') = '1' then
       alz_mdlr_hlth_policy_utils7.p_insert_mdlr_log(p_contract_id, null, v_log, 'SECURITY_INFO_LOG', null, null, null, 1);
       IF (DBMS_LOB.ISTEMPORARY (v_log) = 1) THEN
           DBMS_LOB.FREETEMPORARY (v_log);
       end if;
    end if;

exception when others then

    null;

end;

procedure add_log_process_result (p_log in out clob, p_process_results in out customer.process_result_table) is

v_process_result_ind number;

begin

    if p_process_results is null then
        p_process_results := customer.process_result_table();
    end if;

    v_process_result_ind := p_process_results.first;

    while v_process_result_ind is not null loop

        dbms_lob_append(p_log, 'process_result - type : '||p_process_results(v_process_result_ind).type||' reason : '||p_process_results(v_process_result_ind).reason);

        v_process_result_ind := p_process_results.next(v_process_result_ind);
    end loop;

end;
procedure agency_transfer(p_contract_id  in number,
                          p_agent_int_id in out number,
                          p_agency_code  in out varchar2,
                          p_agency_name  in out varchar2,
                          p_region_code  in out varchar2,
                          p_region_name  in out varchar2) is

   p_agent_transfer koc_health_policy_utils2.agent_transfer;

begin

   p_agent_transfer.int_id := p_agent_int_id;
   p_agent_transfer.reference_code := p_agency_code;
   p_agent_transfer.agency_name := p_agency_name;
   p_agent_transfer.region_code := p_region_code;
   p_agent_transfer.region_name := p_region_name;

   koc_health_policy_utils2.agency_transfer(p_contract_id, p_agent_transfer);

   p_agent_int_id := p_agent_transfer.int_id;
   p_agency_code := p_agent_transfer.reference_code;
   p_agency_name := p_agent_transfer.agency_name;
   p_region_code := p_agent_transfer.region_code;
   p_region_name := p_agent_transfer.region_name;

end;
procedure sub_agency_transfer(p_contract_id  in number,
                              p_agent_int_id in out number,
                              p_agency_code  in out varchar2,
                              p_agency_name  in out varchar2,
                              p_region_code  in out varchar2,
                              p_region_name  in out varchar2,
                              p_subagent_int_id in out number,
                              p_subagent_code in out varchar2,
                              p_subagent_name in out varchar2) is

p_agent_transfer koc_health_policy_utils2.agent_transfer;
p_sagent_transfer koc_health_policy_utils2.agent_transfer;

BEGIN

   p_agent_transfer.int_id := p_agent_int_id;
   p_agent_transfer.reference_code := p_agency_code;
   p_agent_transfer.agency_name := p_agency_name;
   p_agent_transfer.region_code := p_region_code;
   p_agent_transfer.region_name := p_region_name;

   p_sagent_transfer.int_id:= p_subagent_int_id ;
   p_sagent_transfer.reference_code:= p_subagent_code;
   p_sagent_transfer.agency_name:= p_subagent_name;

   koc_health_policy_utils2.sub_agency_transfer (p_contract_id, p_agent_transfer, p_sagent_transfer);

   p_agent_int_id := p_agent_transfer.int_id;
   p_agency_code := p_agent_transfer.reference_code;
   p_agency_name := p_agent_transfer.agency_name;
   p_region_code := p_agent_transfer.region_code;
   p_region_name := p_agent_transfer.region_name;

   p_subagent_int_id := p_sagent_transfer.int_id;
   p_subagent_code   := p_sagent_transfer.reference_code;
   p_subagent_name   := p_sagent_transfer.agency_name;

end;
PROCEDURE delete_quote ( p_contract_id       IN     NUMBER,
                          p_version_no        IN     NUMBER,
                          p_user              IN     VARCHAR2,
                          p_quote_reference   IN     VARCHAR2,
                          p_simple_questions  IN OUT customer.simple_question_table,
                          p_process_results   IN OUT customer.process_result_table ) IS

 v_policy_count          NUMBER;
 v_auto_count            NUMBER;
 v_start_quote_reference ocq_quotes.quote_reference%TYPE;
 v_value                 NUMBER;

   CURSOR c1 (p_contract_id IN NUMBER) IS
   SELECT quote_reference
     FROM ocq_quotes oq,
          ocq_koc_ocp_pol_contracts_ext oqe
    WHERE oq.quote_id=(SELECT min(oqq.quote_id)
                         FROM ocq_quotes oqq
                        WHERE oqq.contract_id = p_contract_id)
      AND oq.quote_id = oqe.quote_id
      AND nvl(oqe.is_renewal,0) = 1;

 BEGIN

   --�lgili contract_id i�in poli�ele�mi� bir kay�t var m� ?
   SELECT count(*)
     INTO v_policy_count
     FROM ocp_policy_bases
    WHERE contract_id = p_contract_id;

   IF  v_policy_count > 0 THEN
      --Poli�ele�mi� kay�t var ise hata mesaj� veriliyor.
      alz_web_process_utils.process_result (0,
                                            9,
                                            -1,
                                            'POLICY_REF ERR',
                                            '�lgili teklif �zerinden poli�e �retimi ger�ekle�ti�i i�in silinememektedir.',
                                            NULL,
                                            NULL,
                                            NULL,
                                            'alz_mdlr_hlth_policy_utils.delete_quote',
                                            p_user,
                                            p_process_results);
   ELSE
      --Kay�t yok ise, ilgili contract_id ve version_no i�in otorizasyona d��m�� bir kay�t var m� ?
     SELECT count(*)
       INTO v_auto_count
       FROM koc_hpf_trans r
      WHERE r.contract_id = p_contract_id
        AND version_no = koc_hpf_utils3.get_top_version (p_contract_id);

     IF v_auto_count > 0 THEN
         -- Otorizasyona d��m�� kay�t var ise hata mesaj� veriliyor.
         alz_web_process_utils.process_result (0,
                                               9,
                                               -1,
                                               'AUTHORIZATION ERR',
                                               '�lgili teklifin otorizasyon kayd� oldu�u i�in silinememektedir.',
                                               NULL,
                                               NULL,
                                               NULL,
                                               'alz_mdlr_hlth_policy_utils.delete_quote',
                                               p_user,
                                               p_process_results);
     ELSE
       --Otorizasyona d��m�� kay�t yok ise,Silinmek istenilen teklif yenileme ask�lar�n orjinal ilk teklifi mi ?

       OPEN c1(p_contract_id);
      FETCH c1 INTO v_start_quote_reference;

       IF c1%NOTFOUND THEN
          --Sorgudan kay�t d�nm�yor ise ilk teklif de�il.
          v_value := 0;
       END IF;

      CLOSE c1;

       IF nvl(v_start_quote_reference, 'X') = p_quote_reference THEN
          --Sorgudan d�nen kay�t silinmek istenilen teklife ait
          v_value := 1;
       ELSE
          --Sorgudan d�nen kay�t silinmek istenilen teklife ait de�il
          v_value := 0;
       END IF;

       IF  v_value =  1 THEN
         -- Silinmek istenilen teklif orjinal Teklif ise hata mesaj� veriliyor.
         alz_web_process_utils.process_result (0,
                                               9,
                                               -1,
                                               'POLICY_REF ERR',
                                               'Yenileme ask�n�n orjinal teklifi oldu�u i�in silinememektedir.',
                                               NULL,
                                               NULL,
                                               NULL,
                                               'alz_mdlr_hlth_policy_utils.delete_quote',
                                               p_user,
                                               p_process_results);
       ELSE
        --B�t�n kontrollerden ge�erse kullan�c�ya soru soruluyor.
          IF nvl(p_simple_questions.count, 0) = 0  then
               p_simple_questions.extend;
               p_simple_questions(p_simple_questions.count) :=
               customer.simple_question_rec (
                   110,
                   'Teklifin silinmesi ile ayn� teklife ula�man�z m�mk�n olamayacakt�r. Teklif silinsin mi?',
                   1,
                   NULL,
                   NULL);

          ELSE
            --Cevap Evet ise
           IF nvl(alz_base_function_utils.question_answer(p_simple_questions,110),0) = 1 THEN

            BEGIN

              UPDATE ocq_quotes
                 SET move_code ='TEKLIFSIL'
               WHERE quote_reference =p_quote_reference;

             alz_web_process_utils.process_result(0,
                                                  9,
                                                  100,
                                                 'quoteDeleteSuccess',
                                                 'Teklif Silme i�lemi ger�ekle�tirilmi�tir.',
                                                 NULL,
                                                 NULL,
                                                 NULL,
                                                 'alz_mdlr_hlth_policy_utils.delete_quote',
                                                 p_user,
                                                 p_process_results);

            EXCEPTION WHEN OTHERS THEN

                 alz_web_process_utils.process_result(0,
                                                      9,
                                                     -1,
                                                     'ORACLE_EXCEPTION',
                                                     substr(sqlerrm || '--' || dbms_utility.format_error_backtrace , 1, 1000),
                                                     NULL,
                                                     NULL,
                                                     NULL,
                                                     'alz_mdlr_hlth_policy_utils.delete_quote',
                                                     p_user,
                                                     p_process_results);
            END;

           END IF;
            --Cevap hay�r ise
           IF NVL(alz_base_function_utils.question_answer(p_simple_questions,110),0) = 0 THEN

              alz_web_process_utils.process_result ( 0,
                                                     9,
                                                     100,
                                                     'QUOTE_DEL ERROR',
                                                     'Teklif Silme i�lemi iptal edilmi�tir.',
                                                     NULL,
                                                     NULL,
                                                     NULL,
                                                     'alz_mdlr_hlth_policy_utils.delete_quote',
                                                     p_user,
                                                     p_process_results);
           END IF;

          END IF;

       END IF;

     END IF;

   END IF;

 EXCEPTION WHEN OTHERS THEN

    alz_web_process_utils.process_result(0,
                                         9,
                                         -1,
                                         'ORACLE_EXCEPTION',
                                         substr(sqlerrm || '--' || dbms_utility.format_error_backtrace , 1, 1000),
                                         NULL,
                                         NULL,
                                         NULL,
                                         'alz_mdlr_hlth_policy_utils.delete_quote',
                                         p_user,
                                         p_process_results);
 END;

procedure get_partner_bank_info (p_contract_id                number,
                                 p_ip_no                      number,
                                 p_Bank_Info                  in out Customer.Mdlr_Hlth_Bank_Info_Rec,
                                 p_user                       varchar2,
                                 p_process_results            in out customer.process_result_table) is

cursor c_bank_info (p_contract_id number, p_ip_no number) is
select *
  from koc_acc_bank_history r
 where contract_id = p_contract_id
   and ip_no = p_ip_no
   and /*trunc(r.validity_start_date) <= trunc(sysdate)
   and (r.validity_end_date >= trunc(sysdate) or */ r.validity_end_date is null;

begin

   for r_bank_info in c_bank_info (p_contract_id, p_ip_no) loop

       p_Bank_Info := Customer.Mdlr_Hlth_Bank_Info_Rec (r_bank_info.Iban_Code,
                                                        r_bank_info.Bank_Code,
                                                        null, --to do Bank_Exp,
                                                        r_bank_info.Subsidiary_Code,
                                                        null, --to do Subsidiary_Exp,
                                                        r_bank_info.Account_No,
                                                        r_bank_info.Account_Owner,
                                                        r_bank_info.Acc_Owner_Partid,
                                                        r_bank_info.identity_no);

   end loop;

exception when others then
    alz_web_process_utils.process_result(0,
                                         9,
                                         -1,
                                         'ORACLE_EXCEPTION',
                                         substr(sqlerrm || '--' || dbms_utility.format_error_backtrace, 1, 1000),
                                         null,
                                         null,
                                         p_contract_id,
                                         'alz_mdlr_hlth_policy_utils.get_partner_bank_info',
                                         p_user,
                                         p_process_results);
end;
PROCEDURE getprepartnercommlist   ( p_partner               IN     NUMBER,
                                     p_user                  IN     VARCHAR2,
                                     p_communication_table   OUT Mdlr_Hlth_Comm_Info_Table,
                                     p_process_results       in OUT customer.process_result_table
                                     )
   IS
      CURSOR cur
      IS
           SELECT
                    kv.comm_dev_type,
                    REPLACE (kv.explanation, ' ', '') comm_dev_exp,
                    kv.validity_end_date,
                    NVL (kv.validity_start_date,
                         TO_DATE ('01011980', 'ddmmyyyy'))
                    validity_start_date
             FROM   koc_cp_pre_comm_devices kv
            WHERE       kv.pre_part_id = p_partner
                    AND REPLACE (kv.explanation, ' ', '') IS NOT NULL
                    AND (kv.comm_dev_type in ('0090', '0091', '0200')
                         OR (kv.comm_dev_type <> '0090'
                             AND REPLACE (
                                   REPLACE (
                                      REPLACE (
                                         REPLACE (
                                            REPLACE (
                                               REPLACE (
                                                  REPLACE (
                                                     REPLACE (
                                                        REPLACE (
                                                           REPLACE (
                                                              REPLACE (
                                                                 kv.explanation,
                                                                 ' ',
                                                                 ''
                                                              ),
                                                              1,
                                                              ''
                                                           ),
                                                           2,
                                                           ''
                                                        ),
                                                        3,
                                                        ''
                                                     ),
                                                     4,
                                                     ''
                                                  ),
                                                  5,
                                                  ''
                                               ),
                                               6,
                                               ''
                                            ),
                                            7,
                                            ''
                                         ),
                                         8,
                                         ''
                                      ),
                                      9,
                                      ''
                                   ),
                                   0,
                                   ''
                                ) IS NULL))
                    AND kv.validity_end_date IS NULL
         ORDER BY   NVL (kv.validity_start_date,
                         TO_DATE ('01011980', 'ddmmyyyy')) DESC;

      rec   cur%ROWTYPE;
   BEGIN
      alz_base_function_utils.set_client (param => p_user);

      p_communication_table := NEW customer.Mdlr_Hlth_Comm_Info_Table ();

      OPEN cur;

      LOOP
         FETCH cur INTO rec;

         EXIT WHEN cur%NOTFOUND;
         p_communication_table.EXTEND;
         p_communication_table (p_communication_table.COUNT) :=
            NEW customer.Mdlr_Hlth_Comm_Info_Rec (rec.comm_dev_type,
                                                  rec.comm_dev_exp,
                                                  rec.validity_start_date,
                                                  rec.Validity_End_Date,
                                                  0);



      END LOOP;

      CLOSE cur;

      alz_base_function_utils.unset_client (param => p_user);
   EXCEPTION
      WHEN OTHERS
      THEN
         alz_web_process_utils.process_result (
            0,
            9,
            -1,
            'ORACLE_EXCEPTION',
            SUBSTR (SQLERRM || '--' || DBMS_UTILITY.format_error_backtrace,
                    1,
                    1000),
            NULL,
            NULL,
            NULL,
            'alz_mdlr_hlth_policy_utils.getprepartnercommlist',
            NULL,
            p_process_results
         );

         alz_base_function_utils.unset_client (param => p_user);
   END ;

 PROCEDURE getpartnercommlist( p_partner               IN     NUMBER,
                                  p_user                  IN     VARCHAR2,
                                  p_communication_table   OUT Mdlr_Hlth_Comm_Info_Table,
                                  p_process_results       in OUT customer.process_result_table
                                     )
   IS
      CURSOR cur
      IS
           SELECT
                    kv.comm_dev_type,
                    REPLACE (kv.explanation, ' ', '') comm_dev_exp,
                    kv.validity_end_date,
                    NVL (kv.validity_start_date,
                         TO_DATE ('01011980', 'ddmmyyyy'))
                    validity_start_date
             FROM   koc_cp_comm_devices kv
            WHERE       kv.part_id = p_partner
                    AND REPLACE (kv.explanation, ' ', '') IS NOT NULL
                    AND (kv.comm_dev_type in ('0090', '0091', '0200')
                         OR (kv.comm_dev_type <> '0090'
                             AND REPLACE (
                                   REPLACE (
                                      REPLACE (
                                         REPLACE (
                                            REPLACE (
                                               REPLACE (
                                                  REPLACE (
                                                     REPLACE (
                                                        REPLACE (
                                                           REPLACE (
                                                              REPLACE (
                                                                 kv.explanation,
                                                                 ' ',
                                                                 ''
                                                              ),
                                                              1,
                                                              ''
                                                           ),
                                                           2,
                                                           ''
                                                        ),
                                                        3,
                                                        ''
                                                     ),
                                                     4,
                                                     ''
                                                  ),
                                                  5,
                                                  ''
                                               ),
                                               6,
                                               ''
                                            ),
                                            7,
                                            ''
                                         ),
                                         8,
                                         ''
                                      ),
                                      9,
                                      ''
                                   ),
                                   0,
                                   ''
                                ) IS NULL))
                    AND kv.validity_end_date IS NULL
         ORDER BY   NVL (kv.validity_start_date,
                         TO_DATE ('01011980', 'ddmmyyyy')) DESC;

      rec   cur%ROWTYPE;
   BEGIN
      alz_base_function_utils.set_client (param => p_user);

      p_communication_table := NEW customer.Mdlr_Hlth_Comm_Info_Table ();

      OPEN cur;

      LOOP
         FETCH cur INTO rec;

         EXIT WHEN cur%NOTFOUND;
         p_communication_table.EXTEND;
         p_communication_table (p_communication_table.COUNT) :=
            NEW customer.Mdlr_Hlth_Comm_Info_Rec (rec.comm_dev_type,
                                                  rec.comm_dev_exp,
                                                  rec.validity_start_date,
                                                  rec.Validity_End_Date,
                                                  0);



      END LOOP;

      CLOSE cur;

      alz_base_function_utils.unset_client (param => p_user);
   EXCEPTION
      WHEN OTHERS
      THEN
         alz_web_process_utils.process_result (
            0,
            9,
            -1,
            'ORACLE_EXCEPTION',
            SUBSTR (SQLERRM || '--' || DBMS_UTILITY.format_error_backtrace,
                    1,
                    1000),
            NULL,
            NULL,
            NULL,
            'alz_mdlr_hlth_policy_utils.getpartnercommlist',
            NULL,
            p_process_results
         );

         alz_base_function_utils.unset_client (param => p_user);
   END ;

PROCEDURE get_hlth_policy_partner_type (p_contract_id           in number,
                                        p_partner_id            in number,
                                        p_mailing_address_id    in number,
                                        p_ip_no                 in number,
                                        p_partner_validity_date in date default sysdate,
                                        p_policy_partner_type   OUT customer.mdlr_hlth_partner_rec,
                                        p_user                  in varchar2,
                                        p_process_results       in out customer.process_result_table) IS

v_name2                    koc_cp_partners_ext.name2%TYPE;
v_identity_no              VARCHAR2 (30);
v_foreign_identity_no      VARCHAR2 (30);
v_partner_type             VARCHAR2 (1);
v_status                   NUMBER;
v_black_list_msg           VARCHAR2 (200);
v_segment                  VARCHAR2 (200);

cursor c_partner_info(p_part_id number, p_partner_validity_date date) is
select *
  from koc_cp_v_hlth_partners r
 where part_id = p_part_id
   and from_date <= nvl (p_partner_validity_date, sysdate)
   and end_date >= nvl (p_partner_validity_date, sysdate);
   /*and from_date <= sysdate
   AND end_date = (SELECT max(end_date)
                     FROM koc_cp_v_hlth_partners
                    WHERE part_id = r.part_id
                      AND from_date <= sysdate
                      AND end_date >= sysdate);
   */

cursor c_pre_special_check(p_part_id number) is
select special_check, is_short_term_settl
  from koc_cp_pre_partners
 where pre_part_id = p_part_id;

cursor c_special_check(p_part_id number) is
select special_check, is_short_term_settl
  from koc_cp_partners_ext
 where part_id = p_part_id;

cursor c_oss_technical(p_part_id in number) is
select a.oss_technical
  from koc_cp_oss_technic_date a
 where a.part_id = p_part_id
   and a.product_id = 63
   and a.group_code = '0'
   and trunc(sysdate) >= trunc(a.validity_start_date) and trunc(sysdate) <= trunc(nvl(a.validity_end_date, sysdate))
   and status is null
 order by a.VALIDITY_START_DATE desc;

v_oss_technical date;

cursor c_role_type(p_contract_id number, p_ip_no number) is
select role_type
  from wip_ip_links
 where contract_id = p_contract_id
   and ip_no = p_ip_no;

v_role_type wip_ip_links.role_type%type;

cursor c_ins_partner_validity_date (p_contract_id number, p_ip_no number) is
select partner_validity_date
  from wip_koc_ocp_partitions_ext r, wip_ip_links t
 where t.contract_id = p_contract_id
   and t.ip_no = p_ip_no
   and t.role_type = 'INS'
   and r.contract_id = t.contract_id
   and t.partition_no = r.partition_no;

cursor c_ph_partner_validity_date (p_contract_id number) is
select partner_validity_date
  from wip_koc_ocp_pol_versions_ext r
 where r.contract_id = p_contract_id;

v_partner_validity_date date;

cursor c_marital_status(p_marital_status varchar2) is
select screen_value
  from inf_dnm_poplists
 where poplist_code   = 'MARITAL_STATUS'
   and language       = 'TR'
   and internal_value = p_marital_status;

v_marital_status_exp varchar2(60);

cursor c_occp_exp(p_occupation varchar2) is
select tr.long_name occup
 from koc_cp_occupation_ref o, cur_translations tr
where tr.desc_int_id = o.desc_int_id
  and o.is_health_partner = 1
  and tr.sula_ora_nls_code = 'TR'
  and o.occupation = p_occupation;

v_occupation_exp varchar2(200);

v_partner_info             c_partner_info%rowTYPE;
v_age                      NUMBER;
v_address_exp              VARCHAR2 (500);
v_industrial_reason_code   koc_cp_partners_ext.industrial_reason_code1%TYPE;
v_is_foreign_company       NUMBER;
v_is_short_term_settl      NUMBER;

v_Bank_Info                        Customer.Mdlr_Hlth_Bank_Info_Rec;
v_Communication_Infos              Customer.Mdlr_Hlth_Comm_Info_Table;
v_Addresses                        Customer.Mdlr_Hlth_Address_Table;
v_Address_orj                      Customer.Address_Rec;
v_Address                          Customer.Mdlr_Hlth_Address_Rec;

v_address_count number;

v_is_pre_partner number;

v_date_of_death date;

cursor c_action_code(p_contract_id number, p_part_id number, p_ip_no number) is
select action_code
  from wip_interested_parties
 where contract_id = p_contract_id
   and partner_id = p_part_id
   and ip_no = p_ip_no;

v_action_code wip_interested_parties.action_code%type;

v_special_check koc_cp_partners_ext.special_check%type;

v_name varchar2(50);

cursor c_as400_info_ins(p_contract_id  number, p_ip_no number) is
select a.as400_partner_id, a.as400_address
  from as400_cnv_partner a, as400_cnv_policy_partner b, wip_koc_ocp_health h , wip_ip_links bb
 where h.contract_id = p_contract_id
   and b.as400_policy_no = h.as400_policy_no
   and b.as400_trans_id = h.trans_id_no
   and b.as400_partition_no = h.old_partition_no
   and a.as400_trans_id = b.as400_trans_id
   and h.contract_id = bb.contract_id
   and bb.ip_no = p_ip_no
   and bb.role_type ='INS'
   and h.partition_no = bb.partition_no
   and b.as400_partition_no = h.old_partition_no
   and a.as400_partner_id = b.as400_partner_id;


cursor c_as400_info_ph(p_contract_id  number, p_ip_no number) is
select distinct a.as400_partner_id, a.as400_address
  from as400_cnv_partner a, as400_cnv_policy b, wip_koc_ocp_health h , wip_ip_links bb
 where h.contract_id = p_contract_id
   and b.as400_policy_no = h.as400_policy_no
   and b.as400_trans_id = h.trans_id_no
   and a.as400_trans_id = b.as400_trans_id
   and h.contract_id = bb.contract_id
   and bb.ip_no = p_ip_no
   and bb.role_type ='PH'
   and a.as400_partner_id = b.as400_ph_part_id;

v_as400_partner_id as400_cnv_partner.as400_address%type;
v_as400_address as400_cnv_partner.as400_address%type;

v_partner_id number;

--hakan.anit ekledi 17.01.2017
cursor c_has_diabetes (p_part_id number) is
select has_diabetes, kvk_permission --basakk : gorky kvk_permission eklendi
  from koc_cp_partners_ext
where part_id = p_part_id
union all
select has_diabetes, kvk_permission --basakk : gorky pre_part li tablo eklendi
  from koc_cp_pre_partners
where pre_part_id = p_part_id;

v_has_diabetes       number;
v_kvk_permission     number; --basakk : gorky

  CURSOR c_Company( pp_contract_id NUMBER ) IS
  SELECT Company_Code
    FROM Wip_Koc_Ocp_Pol_Contracts_Ext
   WHERE Contract_Id = pp_contract_id
   UNION
 SELECT Company_Code
   FROM Ocq_Koc_Ocp_Pol_Contracts_Ext
  WHERE Contract_Id = pp_contract_id
 UNION
 SELECT Company_Code
   FROM Koc_Ocp_Pol_Contracts_Ext
  WHERE Contract_Id = pp_contract_id;

  v_Company VARCHAR2 (30);

  cursor c_Role_Type_By_Partner( pp_contract_id number, pp_partner_id NUMBER ) is
  SELECT il.role_type
    FROM wip_interested_parties t, wip_ip_links il
   WHERE t.contract_id = il.contract_id
     AND t.ip_no       = il.ip_no
     AND t.contract_id = pp_contract_id
     AND t.partner_id  = pp_partner_id
     ORDER BY role_type DESC;

 --gulumserg
 Cursor c_has_obyg (p_contract_id number) is
 SELECT 1
 FROM WIP_KOC_OCP_HEALTH
 WHERE contract_id = p_contract_id
 and nvl(transfer_obyg,0) = 1
 and nvl(transfer_type,0) = 8;

  v_has_obyg number;
  v_role_type_by_partner wip_ip_links.role_type%TYPE;
BEGIN

   v_partner_validity_date := null;

   OPEN c_partner_info(p_partner_id, p_partner_validity_date);
   FETCH c_partner_info INTO v_partner_info;
   CLOSE c_partner_info;

   IF v_partner_info.nationality != 'TR' AND v_partner_info.partner_type = 'P' THEN
      v_partner_type := 'O';
      v_foreign_identity_no := v_partner_info.identity_no;
      v_identity_no := NULL;
   else
      v_partner_type := v_partner_info.partner_type;
   END IF;

   IF v_partner_type = 'I' THEN
      v_name2 := v_partner_info.name || v_partner_info.name2;
      v_name := substr(v_partner_info.name, 1, 50);
   ELSE
      v_name2 := NULL;
      v_name := substr(v_partner_info.first_name, 1, 50);
   END IF;

   v_status := NULL;
   v_black_list_msg := NULL;
   v_segment := NULL;

   IF NVL (p_partner_id, 0) <> 0 THEN
      koc_partner_utils.vip_blist_control_for_partner (p_partner_id,
                                                       v_status,
                                                       v_black_list_msg);

      IF NVL (v_status, 0) <> 0 THEN
         v_segment := v_black_list_msg;
      END IF;
   END IF;

   open c_pre_special_check(p_partner_id);
   fetch c_pre_special_check into v_special_check, v_is_short_term_settl;
   if c_pre_special_check%notfound then
      v_is_pre_partner := 0;
   else
      open c_special_check(p_partner_id);
      fetch c_special_check into v_special_check, v_is_short_term_settl;
      close c_special_check;
      v_is_pre_partner := 1;
   end if;
   close c_pre_special_check;

   open c_oss_technical(p_partner_id);
   fetch c_oss_technical into v_oss_technical;
   close c_oss_technical;

   open c_has_obyg(p_contract_id);
   fetch c_has_obyg into v_has_obyg;
   close c_has_obyg;

   --gulumserg TSS DSIG teknik tarih d�zenleme
   if(alz_mdlr_hlth_policy_utils13.get_partition_type(p_contract_id) = 'TSS' AND v_has_obyg = 1) then
        v_oss_technical := null;
   end if;

   open c_marital_status(v_partner_info.Marital_Status);
   fetch c_marital_status into v_marital_status_exp;
   close c_marital_status;

   open c_occp_exp(v_partner_info.Occupation);
   fetch c_occp_exp into v_occupation_exp;
   close c_occp_exp;

   --adres bilgilerini aliyoruz------------------------------
   if nvl(v_is_pre_partner, 0) = 1 then
      alz_web_partner_utils.get_pre_address_rec(p_mailing_address_id,
                                                v_address_orj);
   else
      alz_web_partner_utils.get_address_rec(p_mailing_address_id,
                                            v_address_orj);
   end if;

   v_Address := Mdlr_Hlth_Address_Rec(v_address_orj);

   v_Addresses := Customer.Mdlr_Hlth_Address_Table();
   v_Addresses.extend;
   v_address_count := v_Addresses.count;
   v_Addresses(v_address_count) := v_Address;

   v_address_exp:= v_address_orj.explanation;
   --adres bilgilerini aliyoruz------------------------------

   --iletisim bilgilerini aliyoruz-------
   if nvl(v_is_pre_partner, 0) = 1 then
      getprepartnercommlist(p_partner_id,
                            p_user,
                            v_Communication_Infos,
                            p_process_results);
   else
      getpartnercommlist(p_partner_id,
                         p_user,
                         v_Communication_Infos,
                         p_process_results);
   end if;
   --iletisim bilgilerini aliyoruz-------

   if v_partner_info.date_of_death > trunc(sysdate) then
      v_date_of_death := null;
   else
      v_date_of_death := v_partner_info.date_of_death;
   end if;

   get_partner_bank_info(p_contract_id,
                         p_ip_no,
                         v_Bank_Info,
                         p_user,
                         p_process_results);

   open c_action_code(p_contract_id, p_partner_id, p_ip_no);
   fetch c_action_code into v_action_code;
   close c_action_code;

   open c_role_type(p_contract_id, p_ip_no);
   fetch c_role_type into v_role_type;
   close c_role_type;
/*
   open c_as400_info(p_contract_id, p_ip_no);
   fetch c_as400_info into v_as400_partner_id, v_as400_address;
   close c_as400_info;*/

   if nvl(v_role_type, 'INS') = 'INS' then
      open c_as400_info_ins(p_contract_id, p_ip_no);
     fetch c_as400_info_ins into v_as400_partner_id, v_as400_address;
     close c_as400_info_ins;
   elsif nvl(v_role_type, 'INS') = 'PH' then
      open c_as400_info_ph(p_contract_id, p_ip_no);
     fetch c_as400_info_ph into v_as400_partner_id, v_as400_address;
     close c_as400_info_ph;
   end if;

   if nvl(v_role_type, 'INS') = 'INS' then
      open c_ins_partner_validity_date(p_contract_id, p_ip_no);
      fetch c_ins_partner_validity_date into v_partner_validity_date;
      close c_ins_partner_validity_date;
   elsif nvl(v_role_type, 'INS') = 'PH' then
      open c_ph_partner_validity_date(p_contract_id);
      fetch c_ph_partner_validity_date into v_partner_validity_date;
      close c_ph_partner_validity_date;
   end if;

   --hakan.anit ekledi 17.01.2017
   OPEN c_has_diabetes(p_partner_id);
   FETCH c_has_diabetes INTO v_has_diabetes, v_kvk_permission; --basakk : gorky kvk_permission eklendi
   CLOSE c_has_diabetes;

   --omerku:13,07,2017
   BEGIN
     OPEN  c_Company( p_contract_id );
     FETCH c_Company INTO v_Company;
     CLOSE c_Company;

     OPEN  c_Role_Type_By_Partner( p_contract_id, p_partner_id );
     FETCH c_Role_Type_By_Partner INTO v_role_type_by_partner;
     CLOSE c_Role_Type_By_Partner;

     IF Nvl( v_Company, '045') = '045' THEN
       v_kvk_permission := alz_pdp_utils.get_partneridbypdpstatus( p_partner_id, p_contract_id, nvl(v_role_type_by_partner, 'INS') );
       IF v_partner_info.date_of_birth IS NOT NULL AND
          SYSDATE-v_partner_info.date_of_birth < 6575
       THEN
         v_kvk_permission := 0;
       END IF;
     END IF;
   EXCEPTION
     WHEN OTHERS THEN
       NULL;
   END;

   p_policy_partner_type := customer.mdlr_hlth_partner_rec (v_partner_info.identity_no,
                                                            v_partner_info.tax_number,
                                                            v_foreign_identity_no,
                                                            v_partner_info.passport_number,
                                                            p_partner_id,
                                                            v_name, --v_partner_info.first_name,
                                                            v_partner_info.name,
                                                            v_partner_info.father_name,
                                                            v_partner_info.sex,
                                                            v_partner_info.date_of_birth,
                                                            v_partner_info.birth_place,
                                                            v_action_code, --NULL, --action_code,
                                                            NULL, --p_role_type,
                                                            NULL, --role_type_exp,
                                                            v_partner_type,
                                                            NULL, --partner_type_exp,
                                                            v_name2,
                                                            p_mailing_address_id, --p_mailing_address_id,
                                                            v_address_exp,
                                                            null, --v_type_of_interest, ???
                                                            p_ip_no, --p_ip_no,
                                                            NULL, --action varchar2(1),
                                                            NULL, --is_editable number(1),
                                                            null, --p_partition_no, ???
                                                            NULL, --v_corporate_type,
                                                            v_partner_info.nationality,
                                                            v_segment,
                                                            v_industrial_reason_code,
                                                            v_is_foreign_company,
                                                            v_is_short_term_settl,
                                                            null, --iertekin - accenture ogulcany ekledi 19/12/2016
                                                            null, --iertekin - accenture ogulcany ekledi 19/12/2016
                                                            v_is_pre_partner,
                                                            v_partner_info.real_part_id,
                                                            v_date_of_death,
                                                            v_partner_info.Mother_Name,
                                                            v_partner_info.Marital_Status,
                                                            v_marital_status_exp,
                                                            v_partner_info.Tax_Office,
                                                            NULL, --v_partner_info.Card_No,
                                                            v_partner_info.Education,
                                                            v_partner_info.Employment_Status,
                                                            v_partner_info.Occupation,
                                                            v_occupation_exp,
                                                            v_partner_info.Job_Activity_Subject,
                                                            v_partner_info.Job_Title,
                                                            v_partner_info.Cigarette_No_Per_Day,
                                                            v_partner_info.Alcohol_Glass_Per_Week,
                                                            v_partner_info.Height,
                                                            v_partner_info.Weight,
                                                            v_partner_info.Ch_Cigarette_No_Per_Day,
                                                            v_partner_info.Ch_Alcohol_Glass_Per_Week,
                                                            v_partner_info.Ch_Height,
                                                            v_partner_info.Ch_Weight,
                                                            NULL, --v_partner_info.Last_Menstruation_Date,
                                                            v_partner_info.Web_Address,
                                                            NULL, --v_partner_info.Company_Name,
                                                            v_partner_info.Company_Type,
                                                            NULL, --v_partner_info.Agent_Int_Id,
                                                            v_partner_info.Name2,
                                                            v_partner_info.Before_Title,
                                                            v_partner_info.Military_Status_Exp,
                                                            v_partner_info.Pregnant_Status_Exp,
                                                            v_partner_info.From_Date,
                                                            v_partner_info.Valid_Identity_No,
                                                            v_special_check,
                                                            v_partner_info.Information_Approve,
                                                            v_oss_technical, --to do iertekin ???
                                                            null, --v_partner_info.Interest_Reference
                                                            v_partner_validity_date,
                                                            v_as400_partner_id,
                                                            v_as400_address,
                                                            v_partner_info.hlth_auth_occupation,
                                                            v_has_diabetes, --hakan.anit ekledi 17.01.2017
                                                            v_kvk_permission, --basakk : gorky
                                                            v_Bank_Info,
                                                            v_Communication_Infos,
                                                            v_Addresses
                                                            );

exception when others then
    alz_web_process_utils.process_result(0,
                                         9,
                                         -1,
                                         'ORACLE_EXCEPTION',
                                         substr(sqlerrm || '--' || dbms_utility.format_error_backtrace, 1, 1000),
                                         null,
                                         p_partner_id,
                                         p_contract_id,
                                         'alz_mdlr_hlth_policy_utils.get_hlth_policy_partner_type',
                                         p_user,
                                         p_process_results);
END;

PROCEDURE getHpfDetails(p_contract_id       in          number,
                        p_version_no        in          number,
                        p_user              in          varchar2,
                        p_mdlr_hlth_policy     out      customer.mdlr_hlth_policy_rec,
                        p_process_results   in out      customer.process_result_table) IS

    cursor c_part_ph is
    Select *
      from (Select x.*,
                   Rank() Over(Partition By x.Contract_Id Order By x.oncelik) ph_order
              from (select a.Contract_Id,
                           a.partner_id,
                           b.partition_no,
                           a.mailing_address_id,
                           b.role_type,
                           b.type_of_interest,
                           a.ip_no,
                           a.customer_name_text,
                           1 oncelik
                      from ocp_interested_parties a, ocp_ip_links b
                     where a.contract_id = b.contract_id
                       and a.ip_no = b.ip_no
                       and a.contract_id = p_contract_id
                       and a.action_code != 'D'
                       and b.role_type = 'PH'
                    union
                    select a.Contract_Id,
                           a.partner_id,
                           b.partition_no,
                           a.mailing_address_id,
                           b.role_type,
                           b.type_of_interest,
                           a.ip_no,
                           a.customer_name_text,
                           2 oncelik
                      from wip_interested_parties a, wip_ip_links b
                     where a.contract_id = b.contract_id
                       and a.ip_no = b.ip_no
                       and a.contract_id = p_contract_id
                       and a.action_code != 'D'
                       and b.role_type = 'PH') x)
    where ph_order = 1;

    v_ph_part_id                  cp_v_partners.part_id%TYPE;

    cursor c_policy_ref(p_contract_id number) is
    select policy_ref, agent_role, term_start_date, term_end_date
      from ocp_policy_bases r
     where r.contract_id = p_contract_id
    union
    select policy_ref, agent_role, term_start_date, term_end_date
      from wip_policy_bases r
     where r.contract_id = p_contract_id;

    v_policy_ref varchar2(30);
    v_agent_role number;
    v_term_start_date date;
    v_term_end_date date;

    cursor c_auth_document_group_id(p_contract_id number) is
    select auth_document_group_id
      from koc_ocp_pol_versions_ext r
     where r.contract_id = p_contract_id
    union
    select auth_document_group_id
      from wip_koc_ocp_pol_versions_ext r
     where r.contract_id = p_contract_id;

    v_auth_document_group_id koc_ocp_pol_versions_ext.auth_document_group_id%type;

    v_mdlr_hlth_policy            customer.mdlr_hlth_policy_rec;
    v_policy_base                 customer.mdlr_hlth_policy_base_rec;
    v_policy_holder               customer.mdlr_hlth_partner_rec;
    v_policy_holders              customer.mdlr_hlth_partner_table := customer.mdlr_hlth_partner_table();
    v_koc_hpf_rec                 customer.mdlr_hlth_hpf_rec;
    v_policy_base_orj_rec         customer.policy_base_rec;

    v_part_count                  number := 0;

  begin

    open c_policy_ref(p_contract_id);
    fetch c_policy_ref into v_policy_ref, v_agent_role, v_term_start_date, v_term_end_date;
    close c_policy_ref;

    open c_auth_document_group_id(p_contract_id);
    fetch c_auth_document_group_id into v_auth_document_group_id;
    close c_auth_document_group_id;

    v_policy_base_orj_rec := customer.policy_base_rec (p_contract_id, p_version_no, 63, null, null, v_agent_role, null, null, null, null, p_user, null, v_term_start_date, v_term_end_date, null,
                                                       null, null, null, null, null, v_policy_ref, null, null, 0, null, null, null, null, null, null, null, null, null,
                                                       null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
                                                       null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
                                                       null, null, null, null, null, null); -- TYH-76997 - LEVENT OZSOY Tarih sabitleme

    v_policy_base := customer.mdlr_hlth_policy_base_rec(v_policy_base_orj_rec);
    v_policy_base.auth_document_group_id := v_auth_document_group_id;

    v_part_count := 0;
    for part_rec in c_part_ph loop
        v_part_count := v_part_count + 1;

        -------Sigorta etiren bilgilerini atiyoruz----------
        get_hlth_policy_partner_type (p_contract_id,
                                      part_rec.partner_id,
                                      part_rec.mailing_address_id,
                                      part_rec.ip_no,
                                      sysdate,
                                      v_policy_holder,
                                      p_user,
                                      p_process_results);

        v_policy_holder.type_of_interest := part_rec.type_of_interest;
        v_policy_holder.ip_no := part_rec.ip_no;
        v_policy_holder.partner_explanation := part_rec.customer_name_text;

        v_policy_holders.extend;
        v_policy_holders (v_part_count) := v_policy_holder;

        -------Sigorta etiren bilgilerini atiyoruz----------

    end loop;

    /*
    alz_mdlr_hlth_hpf_utils.get_hpf(p_contract_id,
                                    p_version_no-1,
                                    v_koc_hpf_rec,
                                    p_user,
                                    p_process_results);
    */

    v_mdlr_hlth_policy := customer.mdlr_hlth_policy_rec(v_policy_base,
                                                        null,
                                                        v_policy_holders,
                                                        null,
                                                        null,
                                                        null,
                                                        null,
                                                        null,
                                                        null,--v_koc_hpf_rec);
                                                        null);  -- PinarDS - Manuel Aile Indirimi

    alz_mdlr_hlth_hpf_utils.get_hpf_main(v_mdlr_hlth_policy,
                                         p_version_no-1,
                                         p_user,
                                         p_process_results);

    p_mdlr_hlth_policy := v_mdlr_hlth_policy;

  EXCEPTION WHEN OTHERS THEN
      alz_web_process_utils.process_result (0,
                                            9,
                                            -1,
                                            'INVOKE ERR',
                                            substr (sqlcode||' - '|| sqlerrm||' - '||dbms_utility.format_error_backtrace, 1, 1000),
                                            null,
                                            p_contract_id,
                                            p_version_no,
                                            'alz_mdlr_hlth_policy_utils.getHpfDetails',
                                            p_user,
                                            p_process_results);
  END;
  
  procedure main_validations(p_mdlr_hlth_policy      in out      customer.mdlr_hlth_policy_rec,
                           p_user_type             in          varchar2,
                           p_user_agent_id         in          number,
                           p_action                in out      Customer.Action_Rec,
                           p_security_info         in          Customer.Security_Info_Rec,
                           p_simple_questions      in out      Customer.Simple_Question_Table,
                           p_process_results       in out      customer.process_result_table) is

cursor control_product_partition(p_product_id in number, p_partition_type in varchar2, p_signature_date in date) is
select 1
  from koc_oc_prod_partition_rel l
 where product_id = p_product_id
   and partition_type = p_partition_type
   and validity_start_date <= p_signature_date
   and (validity_end_date is null or validity_end_date >= p_signature_date);

cursor c_wip_agent(p_contract_id number) is
select a.agent_role, b.sub_agent
  from wip_policy_bases a, wip_koc_ocp_pol_versions_ext b
 where a.contract_id = p_contract_id and a.contract_id = b.contract_id;

cursor c_agent_info(p_agent_code in varchar2) is
select a.int_id, b.parent_agent_int_id, a.start_date, a.end_date, b.type
  from dmt_agents a, koc_dmt_agents_ext b
 where a.int_id = b.int_id
   and a.reference_code = p_agent_code;

cursor c_policy_exists_contract(p_contract_id number) is
select policy_ref
  from ocp_policy_bases
 where contract_id = p_contract_id
   and rownum < 2;

cursor c_wip_exists(p_contract_id in number) is
select 1
  from wip_policy_bases
 where contract_id = p_contract_id
   and rownum < 2;

cursor c_policy_start_date(p_contract_id number) is
select min(term_start_date)
  from (select term_start_date
          from ocp_policy_bases
         where contract_id = p_contract_id
        union
        select term_start_date
          from wip_policy_bases
         where contract_id = p_contract_id);

cursor c_is_ren(p_contract_id number) is
select 1
  from wip_koc_ocp_health
 where contract_id = p_contract_id
   and nvl(version_no, 0) = 0
   and (old_policy_contract_id is not null or as400_policy_no is not null)
   and rownum < 2;

v_is_ren number;
v_tolerance_day number;
v_first_cc_coll_date date;
v_payment_plans      Customer.Mdlr_Hlth_Payment_Plan_Table := Customer.Mdlr_Hlth_Payment_Plan_Table();
v_Payment_Ind number;
v_curr_dist_counter  number := 0;

p_global_opusdate     date := pme_public.opus_date;

agent_info            c_agent_info%rowtype;
v_pol_term_start_date date;
v_pol_signature_date  date;
v_prod_part_cont      number;
v_wip_agent_id        number;
v_wip_exists          number;
v_exists_policy_ref   varchar2(30);
v_wip_sub_agent_id    number;
v_life_agency_code    number;
v_msg                 number;
v_contract_id         number;

v_sp_emp_id varchar2(20);
v_is_auth number;

v_date date;

v_user_role varchar2(10);

cursor c_look_pdz(p_contract_id number) is
select b.agent_role, a.region_code, a.sub_agent
  from koc_ocp_pol_versions_ext a, ocp_policy_bases b
 where a.contract_id = p_contract_id
   and a.contract_id = b.contract_id
   and a.version_no = b.version_no
   and nvl(a.endorsement_no, 0) = 54
   and a.reversing_version is null
   and a.version_no = (select max(version_no)
                         from koc_ocp_pol_versions_ext aa
                        where aa.contract_id = a.contract_id
                          and nvl(aa.endorsement_no, 0) = 54
                          and aa.reversing_version is null);

v_pdz_int_id      number(10);
v_pdz_region_code varchar2(10);
v_pdz_sub_agent   number(10);

cursor c_look_transfer(p_int_id number, p_date date) is
select transferred_int_id, transfer_date
  from koc_dmt_agent_transfers
 where transfer_date = (select max(transfer_date)
                          from koc_dmt_agent_transfers
                         where transfer_date <= p_date
                         start with int_id = p_int_id
                        connect by prior transferred_int_id = int_id)
 start with int_id = p_int_id
 connect by prior transferred_int_id = int_id;

v_transferred_int_id wip_policy_bases.agent_role%type;
v_transfer_date      date;

v_log clob;

cursor c_write_log is
select value
  from system_parameters
 where code = 'CREATE_PROPOSAL_LOG';

v_write_log system_parameters.value%type;
n_performance number(38,9);


v_day_control        number; --hmp-32 batuhan g�ng�r
v_new_baby_index     number; --hmp-32 batuhan g�ng�r
v_max_day_diff       number; --hmp-32 batuhan g�ng�r
v_new_date           date;   --hmp-32 batuhan g�ng�r
v_baby_birth_date    date;   --hmp-32 batuhan g�ng�r
v_baby_partition_no  number; --hmp-32 batuhan g�ng�r
v_has_az_baby        number; --hmp-32 batuhan g�ng�r
v_pol_res_index      number; --hmp-32 batuhan g�ng�r


v_Is_Tpa_Centered  Number(1);--TPA2 Serdal
begin

    n_performance := DBMS_UTILITY.GET_TIME;
   dbms_lob_append(v_log, 'main_validations ba�l�yor...');

    dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.contract_id : '||p_mdlr_hlth_policy.policy_base.contract_id);
    dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.product_id : '||p_mdlr_hlth_policy.policy_base.product_id);
    dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.agent_int_id : '||p_mdlr_hlth_policy.policy_base.agent_int_id);
    dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.sub_agent_int_id : '||p_mdlr_hlth_policy.policy_base.sub_agent_int_id);
    dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.signature_date : '||p_mdlr_hlth_policy.policy_base.signature_date);
    dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.term_start_date : '||p_mdlr_hlth_policy.policy_base.term_start_date);
    dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.term_end_date : '||p_mdlr_hlth_policy.policy_base.term_end_date);
    dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.region_code : '||p_mdlr_hlth_policy.policy_base.region_code);
    dbms_lob_append(v_log, 'p_global_opusdate : '||p_global_opusdate);

    alz_policy_core_utils.get_user_auth_check(p_security_info.userid, p_process_results);

    dbms_lob_append(v_log, 'get_user_auth_check bitti');

    v_user_role := koc_hpf_utils.get_user_role(p_security_info.userid);
    v_Is_Tpa_Centered := Alz_Mdlr_Hlth_Search_Utils.Get_Is_Tpa_Centered(p_security_info.userid);--TPA2 Serdal

    dbms_lob_append(v_log, 'v_user_role : '||v_user_role);

    --aski bos geldiyse yeni aski olusturuyoruz..
    if NVL(p_mdlr_hlth_policy.policy_base.contract_id, 0) = 0 and p_action.action_code = 'DEMO' then
       ALZ_MDLR_HLTH_POLICY_UTILS.navigate_request(v_contract_id,
                        null,
                        null,
                        null,
                        p_mdlr_hlth_policy.policy_base.product_id,
                        v_default_partition_type,
                        p_mdlr_hlth_policy.policy_base.signature_date,
                        p_mdlr_hlth_policy.policy_base.agent_int_id,
                        p_mdlr_hlth_policy.policy_base.sub_agent_int_id,
                        p_mdlr_hlth_policy,
                        p_action,
                        p_security_info,
                        p_simple_questions,
                        p_process_results);

       if NVL(v_contract_id, 0) <> 0 then
          p_mdlr_hlth_policy.policy_base.contract_id := v_contract_id;
       else
          alz_web_process_utils.process_result(0,
                                               9,
                                               -1,
                                               'CONTRACT ERR',
                                               'Teklif askisi olusturulamadi.',
                                               null,
                                               null,
                                               null,
                                               'alz_mdlr_hlth_policy_utils.main_validations',
                                               p_security_info.userid,
                                               p_process_results);
       end if;
    end if;

    if p_mdlr_hlth_policy.policy_base.term_start_date is null then
       p_mdlr_hlth_policy.policy_base.term_start_date := p_global_opusdate;
       p_mdlr_hlth_policy.policy_base.term_end_date := trunc(add_months (p_mdlr_hlth_policy.policy_base.term_start_date, 12));
    else
       p_mdlr_hlth_policy.policy_base.term_start_date := trunc (p_mdlr_hlth_policy.policy_base.term_start_date);
       p_mdlr_hlth_policy.policy_base.term_end_date := trunc(add_months (p_mdlr_hlth_policy.policy_base.term_start_date, 12));
    end if;

    if p_mdlr_hlth_policy.policy_base.term_start_date > p_global_opusdate then
       p_mdlr_hlth_policy.policy_base.signature_date := p_mdlr_hlth_policy.policy_base.term_start_date;
    else
       p_mdlr_hlth_policy.policy_base.signature_date := p_global_opusdate;
    end if;

    if nvl(p_mdlr_hlth_policy.policy_base.version_no, 0) > 0 then
       v_date := p_mdlr_hlth_policy.policy_base.business_start_date;
    else
       v_date := p_mdlr_hlth_policy.policy_base.term_start_date;
    end if;

    if alz_mdlr_hlth_policy_utils13.get_partition_class(p_mdlr_hlth_policy.policy_base.contract_id) <> 'MNOR' then
       dbms_lob_append(v_log, 'MNOR de�il ifine girdik');
       dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.life_agency_code : '||p_mdlr_hlth_policy.policy_base.life_agency_code);
      if nvl(p_mdlr_hlth_policy.policy_base.life_agency_code, 0) = 0 then
         begin

            select koc_allianz_life_agent_code
              into v_life_agency_code
              from koc_dmt_agents_ext
             where int_id = p_mdlr_hlth_policy.policy_base.agent_int_id;

            dbms_lob_append(v_log, 'v_life_agency_code : '||v_life_agency_code);

            koc_health_policy_utils5.get_life_agency_code (v_life_agency_code, v_msg);

            dbms_lob_append(v_log, 'get_life_agency_code bitti v_life_agency_code : '||v_life_agency_code);

         exception when no_data_found then
            v_life_agency_code := null;
         end;

         p_mdlr_hlth_policy.policy_base.life_agency_code := v_life_agency_code;
      end if;
    end if;

    if p_mdlr_hlth_policy.policy_base.branch_ext_ref is null then
       p_mdlr_hlth_policy.policy_base.branch_ext_ref := '20';

       alz_web_process_utils.process_result(0,
                                            9,
                                            100,
                                            'POLICY ERR',
                                            'Brans bilgis bos olmamali',
                                            null,
                                            p_mdlr_hlth_policy.policy_base.contract_id,
                                            null,
                                            'alz_mdlr_hlth_policy_utils.main_validations',
                                            p_security_info.userid,
                                            p_process_results);
    end if;

    if (p_mdlr_hlth_policy.policy_base.term_start_date is null
       or p_mdlr_hlth_policy.policy_base.product_id is null
       or p_mdlr_hlth_policy.risk_subjects(1).risk_subject_base.partition_type is null
       or p_mdlr_hlth_policy.policy_base.agency_code is null
       or p_mdlr_hlth_policy.policy_base.region_code is null) then

       alz_web_process_utils.process_result (0,
                                             9,
                                             -1,
                                             'PROPOSAL MUST FIELDS ERR',
                                             'Teklif i�in zorunlu alanlarda eksiklik var. �r�n : '||p_mdlr_hlth_policy.policy_base.product_id||'
                                             , risk konusu : '||p_mdlr_hlth_policy.risk_subjects(1).risk_subject_base.partition_type||'
                                             , acente no : '||p_mdlr_hlth_policy.policy_base.agency_code||'
                                             , poli�e vadesi : '||p_mdlr_hlth_policy.policy_base.term_start_date||'
                                             , b�lge kodu : '||p_mdlr_hlth_policy.policy_base.region_code,
                                             null,
                                             null,
                                             null,
                                             'alz_mdlr_hlth_policy_utils.main_validations',
                                             p_security_info.userid,
                                             p_process_results);

    end if;

    if nvl(p_mdlr_hlth_policy.policy_base.version_no, 0) > 0 then
       if v_date < p_mdlr_hlth_policy.policy_base.term_start_date or v_date > p_mdlr_hlth_policy.policy_base.term_end_date then

          alz_web_process_utils.process_result (0,
                                                9,
                                                -1,
                                                'POLICY DATE ERR',
                                                'Zeyil ba�lang�� tarihi poli�e vadesi i�inde olmal�d�r.',
                                                null,
                                                null,
                                                null,
                                                'alz_mdlr_hlth_policy_utils.main_validations',
                                                p_security_info.userid,
                                                p_process_results);

          p_mdlr_hlth_policy.policy_base.business_start_date := p_mdlr_hlth_policy.policy_base.term_start_date;

       end if;

       /* iertekin sevgi kald�r�lmas�n� istedi. ileri tarihli poli�e iptali testi..
       if v_date > p_global_opusdate then

          alz_web_process_utils.process_result (0,
                                                9,
                                                100,
                                                'POLICY DATE ERR',
                                                'Zeyil ba�lang�� tarihi g�n�n tarihinden b�y�k olamaz.',
                                                null,
                                                null,
                                                null,
                                                'alz_mdlr_hlth_policy_utils.main_validations',
                                                p_security_info.userid,
                                                p_process_results);

          p_mdlr_hlth_policy.policy_base.business_start_date := p_global_opusdate;

       end if;
       */
    end if;

    open c_is_ren(p_mdlr_hlth_policy.policy_base.contract_id);
    fetch c_is_ren into v_is_ren;
    if c_is_ren%notfound then
       v_is_ren := 0;
    end if;
    close c_is_ren;

    dbms_lob_append(v_log, 'v_is_ren : '||v_is_ren);
    dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.endorsement_no : '||p_mdlr_hlth_policy.policy_base.endorsement_no);

  --yfe yenileme policesi zeyil kontrolu
    if nvl(v_is_ren, 0) > 0 then
        alz_mdlr_hlth_policy_utils14.check_old_policy_endors(p_mdlr_hlth_policy.policy_base.contract_id,
                                                             p_security_info.userid,
                                                             p_process_results);
    end if;

    if nvl(p_mdlr_hlth_policy.policy_base.endorsement_no, 0) not in (11, 14) and nvl(v_is_ren, 0) = 0 then
       v_sp_emp_id := web_mdlr_hlth_search_utils.is_salesperson(p_security_info.userid);
       dbms_lob_append(v_log, 'v_sp_emp_id : '||v_sp_emp_id);
       dbms_lob_append(v_log, 'p_user_type : '||p_user_type);
       dbms_lob_append(v_log, 'v_date : '||v_date);
       if p_user_type not in ('0', '2') or (p_user_type = '2' and v_sp_emp_id is not null) or (p_user_type in ('0', '2') and nvl(v_user_role, 'X') in ('SFMT', 'SYM')) then -- hazala_08022018_mdts-87_SYM_eklendi
          if nvl(v_user_role, 'X') not in ('SEL') then
              if v_date < p_global_opusdate and get_working_day(v_date, p_global_opusdate) > 5 then


                   v_new_date := p_mdlr_hlth_policy.policy_base.business_start_date;
                   FOR i IN 1..p_process_results.count
                   LOOP
                       IF  p_process_results(i).CODE = 'POLICY DATE ERR 5 DAY'
                       THEN
                          v_pol_res_index := i;
                          EXIT;
                       END IF;
                   END LOOP;

                   v_new_baby_index := alz_mdlr_hlth_policy_utils14.new_baby_indexer(p_mdlr_hlth_policy,15,0,sysdate);

                   if nvl(v_new_baby_index,0) <> 0 then

                        v_baby_birth_date    := p_mdlr_hlth_policy.Risk_Subjects(v_new_baby_index).Policy_Insured.birth_date;
                        v_baby_partition_no  := p_mdlr_hlth_policy.Risk_Subjects(v_new_baby_index).Risk_Subject_Base.partition_no;

                        if alz_mdlr_hlth_policy_utils14.is_alz_baby(p_mdlr_hlth_policy.policy_base.contract_id,v_baby_birth_date,v_baby_partition_no) = 1
                        then

                             v_has_az_baby := 1;

                        end if;

                   end if;


                    if nvl(v_has_az_baby,0) <> 1 then

                        v_new_date := get_before_working_day(p_global_opusdate, 5);
                        p_process_results.delete(v_pol_res_index);

                        alz_web_process_utils.process_result (0,
                                                           9,
                                                           100,
                                                           'POLICY DATE ERR',
                                                           '5 is g�nl�k s�re asildigi i�in teklifin g�ncellenmesi gerekiyor. G�ncelleyerek devam edilecektir.',
                                                           null,
                                                           null,
                                                           null,
                                                           'alz_mdlr_hlth_policy_utils.main_validations',
                                                           p_security_info.userid,
                                                           p_process_results);


                    elsif nvl(p_action.button_name,'x') <> 'deletePlan' then

                        v_max_day_diff := p_global_opusdate - p_mdlr_hlth_policy.risk_subjects(v_new_baby_index).policy_insured.birth_date;

                        if (p_global_opusdate - v_date) > v_max_day_diff then

                            v_day_control := v_max_day_diff;
                            v_new_date := p_mdlr_hlth_policy.risk_subjects(v_new_baby_index).policy_insured.birth_date;
                            p_process_results.delete(v_pol_res_index);
                            alz_web_process_utils.process_result (0,
                                                                  9,
                                                                  100,
                                                                  'POLICY DATE ERR',
                                                                  v_day_control || ' g�nl�k yeni dogan bebek dogum tarihi opsiyon kurali asildigi i�in teklifin g�ncellenmesi gerekiyor. G�ncelleyerek devam edilecektir.',
                                                                  null,
                                                                  null,
                                                                  'NewBaby',
                                                                  'alz_mdlr_hlth_policy_utils.main_validations',
                                                                  p_security_info.userid,
                                                                  p_process_results);

                        else

                            v_new_date := v_date;
                            p_process_results.delete(v_pol_res_index);

                        end if;

                    end if;


                    if nvl(p_mdlr_hlth_policy.policy_base.version_no, 0) > 0 then
                        p_mdlr_hlth_policy.policy_base.business_start_date := v_new_date;
                    else
                        p_mdlr_hlth_policy.policy_base.term_start_date := v_new_date;
                        p_mdlr_hlth_policy.policy_base.term_end_date := trunc(add_months (p_mdlr_hlth_policy.policy_base.term_start_date, 12));
                    end if;

             end if;

          else

             if v_date < p_global_opusdate and get_working_day(v_date, p_global_opusdate) > 15 then
                if alz_mdlr_hlth_policy_utils13.get_partition_type(p_mdlr_hlth_policy.policy_base.contract_id) = 'GRUP' then  --basakk : kvem d�zenlemeleri
                    alz_web_process_utils.process_result (0,
                                                          9,
                                                          100,
                                                          'POLICY DATE ERR',
                                                          '15 i� g�nl�k s�re a��ld��� i�in teklifin g�ncellenmesi gerekiyor. G�ncelleyerek devam edilecektir.',
                                                          null,
                                                          null,
                                                          null,
                                                          'alz_mdlr_hlth_policy_utils.main_validations',
                                                          p_security_info.userid,
                                                          p_process_results);

                    if nvl(p_mdlr_hlth_policy.policy_base.version_no, 0) > 0 then
                       p_mdlr_hlth_policy.policy_base.business_start_date := get_before_working_day(p_global_opusdate, 15);
                    else
                       p_mdlr_hlth_policy.policy_base.term_start_date := get_before_working_day(p_global_opusdate, 15);
                       p_mdlr_hlth_policy.policy_base.term_end_date := trunc(add_months (p_mdlr_hlth_policy.policy_base.term_start_date, 12));
                    end if;
                end if;

             elsif v_date < p_global_opusdate and get_working_day(v_date, p_global_opusdate) > 10  then

                if alz_mdlr_hlth_policy_utils13.get_partition_class(p_mdlr_hlth_policy.policy_base.contract_id) <> 'MNOR' then --basakk
                    alz_web_process_utils.process_result (0,
                                                          9,
                                                          100,
                                                          'POLICY DATE ERR',
                                                          '10 i� g�nl�k s�re a��ld��� i�in teklifin g�ncellenmesi gerekiyor. G�ncelleyerek devam edilecektir.',
                                                          null,
                                                          null,
                                                          null,
                                                          'alz_mdlr_hlth_policy_utils.main_validations',
                                                          p_security_info.userid,
                                                          p_process_results);

                    if nvl(p_mdlr_hlth_policy.policy_base.version_no, 0) > 0 then
                       p_mdlr_hlth_policy.policy_base.business_start_date := get_before_working_day(p_global_opusdate, 10);
                    else
                       p_mdlr_hlth_policy.policy_base.term_start_date := get_before_working_day(p_global_opusdate, 10);
                       p_mdlr_hlth_policy.policy_base.term_end_date := trunc(add_months (p_mdlr_hlth_policy.policy_base.term_start_date, 12));
                    end if;
                end if; --basakk
             end if;
          end if;
       end if;
    end if;

    if p_user_type not in ('0', '2') And (v_Is_Tpa_Centered = 0) then--TPA2 Serdal
       if (p_user_type = '1' and p_mdlr_hlth_policy.policy_base.agent_int_id <> p_user_agent_id) or (p_user_type = '3' and nvl(p_mdlr_hlth_policy.policy_base.sub_agent_int_id, 0) <> p_user_agent_id) then
          open c_look_transfer(p_mdlr_hlth_policy.policy_base.agent_int_id, p_mdlr_hlth_policy.policy_base.signature_date);
          fetch c_look_transfer into v_transferred_int_id, v_transfer_date;
          close c_look_transfer;
          dbms_lob_append(v_log, 'v_transferred_int_id : '||v_transferred_int_id);
          dbms_lob_append(v_log, 'v_transfer_date : '||v_transfer_date);
          dbms_lob_append(v_log, 'p_user_agent_id : '||p_user_agent_id);
          if p_user_type = '1' and nvl(v_transferred_int_id, 0) <> p_user_agent_id then
             open c_look_pdz(p_mdlr_hlth_policy.policy_base.contract_id);
             fetch c_look_pdz into v_pdz_int_id, v_pdz_region_code, v_pdz_sub_agent;
             close c_look_pdz;
             dbms_lob_append(v_log, 'v_pdz_int_id : '||v_pdz_int_id);
             dbms_lob_append(v_log, 'v_pdz_region_code : '||v_pdz_region_code);
             dbms_lob_append(v_log, 'v_pdz_sub_agent : '||v_pdz_sub_agent);
             if (p_user_type = '1' and nvl(v_pdz_int_id, 0) <> p_user_agent_id) or (p_user_type = '3' and nvl(v_pdz_sub_agent, 0) <> p_user_agent_id) then
                alz_web_process_utils.process_result(0,
                                                     9,
                                                     -1,
                                                     'INVALID_AGENCY',
                                                     'Kendi partajiniza ait teklif olusturabilirsiniz.',
                                                     null,
                                                     null,
                                                     p_mdlr_hlth_policy.policy_base.contract_id,
                                                     'alz_mdlr_hlth_policy_utils.main_validations',
                                                     p_security_info.userid,
                                                     p_process_results);
             end if;
          end if;
       end if;
    end if;

    if nvl(p_mdlr_hlth_policy.policy_base.version_no, 0) = 0 then
       if p_mdlr_hlth_policy.policy_base.sub_agent_code is not null then
          open c_agent_info(p_mdlr_hlth_policy.policy_base.sub_agent_code);
          fetch c_agent_info into agent_info;
          close c_agent_info;

          open c_policy_start_date(p_mdlr_hlth_policy.policy_base.contract_id);
          fetch c_policy_start_date into v_pol_term_start_date;
          close c_policy_start_date;

          if (nvl(v_pol_term_start_date, nvl(p_mdlr_hlth_policy.policy_base.first_quote_date, p_mdlr_hlth_policy.policy_base.signature_date)) not between agent_info.start_date and  agent_info.end_date) or agent_info.int_id is null then
             if nvl(p_mdlr_hlth_policy.policy_base.version_no, 0) > 0 then
                alz_web_process_utils.process_result(0,
                                                     9,
                                                     -1,
                                                     'INVALID_SUB_AGENCY',
                                                     'G�nderilen sube bilgisi ge�ersiz.',
                                                     null,
                                                     null,
                                                     p_mdlr_hlth_policy.policy_base.contract_id,
                                                     'alz_mdlr_hlth_policy_utils.main_validations',
                                                     p_security_info.userid,
                                                     p_process_results);
             else
                alz_web_process_utils.process_result(0,
                                                     9,
                                                     100,
                                                     'INVALID_SUB_AGENCY',
                                                     'G�nderilen sube bilgisi ge�ersiz. Ask�n�n �zerindeki �ube bilgisi silinecektir.',
                                                     null,
                                                     null,
                                                     p_mdlr_hlth_policy.policy_base.contract_id,
                                                     'alz_mdlr_hlth_policy_utils.main_validations',
                                                     p_security_info.userid,
                                                     p_process_results);
                p_mdlr_hlth_policy.policy_base.sub_agent_int_id := null;
             end if;
          end if;

          if agent_info.type <> '3' then
             alz_web_process_utils.process_result(0,
                                                  9,
                                                  -1,
                                                  'INVALID_SUB_AGENCY',
                                                  'G�nderilen sube bilgisi ge�ersiz.',
                                                  null,
                                                  null,
                                                  p_mdlr_hlth_policy.policy_base.contract_id,
                                                  'alz_mdlr_hlth_policy_utils.main_validations',
                                                  p_security_info.userid,
                                                  p_process_results);
          end if;

          if p_mdlr_hlth_policy.policy_base.sub_agent_int_id is not null then --iertekin yukar�daki uyar�dan sonra null'lad�ysam tekrar burada doldurmamas� i�in ekledim...
             if nvl(agent_info.int_id, 0) = 0 then
                p_mdlr_hlth_policy.policy_base.sub_agent_int_id := null;
             else
                p_mdlr_hlth_policy.policy_base.sub_agent_int_id := agent_info.int_id;
             end if;
          end if;
          p_mdlr_hlth_policy.policy_base.agent_int_id := agent_info.parent_agent_int_id;

       else
       dbms_output.put_line('serdal agency_code : '||p_mdlr_hlth_policy.policy_base.agency_code);

          open c_agent_info(p_mdlr_hlth_policy.policy_base.agency_code);
          fetch c_agent_info into agent_info;
          close c_agent_info;

          open c_policy_start_date(p_mdlr_hlth_policy.policy_base.contract_id);
          fetch c_policy_start_date into v_pol_term_start_date;
          close c_policy_start_date;

          if (nvl(v_pol_term_start_date, nvl(p_mdlr_hlth_policy.policy_base.first_quote_date, p_mdlr_hlth_policy.policy_base.signature_date)) not between agent_info.start_date and  agent_info.end_date) or agent_info.int_id is null then
             alz_web_process_utils.process_result(0,
                                                  9,
                                                  -1,
                                                  'INVALID_AGENCY',
                                                  'G�nderilen acente bilgisi ge�ersiz.',
                                                  null,
                                                  null,
                                                  p_mdlr_hlth_policy.policy_base.contract_id,
                                                  'alz_mdlr_hlth_policy_utils.main_validations',
                                                  p_security_info.userid,
                                                  p_process_results);
          end if;

          p_mdlr_hlth_policy.policy_base.sub_agent_int_id := null;
          p_mdlr_hlth_policy.policy_base.agent_int_id := agent_info.parent_agent_int_id;
       dbms_output.put_line('serdal agent_int_id : '||agent_info.parent_agent_int_id);

       end if;
    end if;

    if nvl(p_mdlr_hlth_policy.policy_base.contract_id, 0) <> 0 then
       open c_wip_agent(p_mdlr_hlth_policy.policy_base.contract_id);
       fetch c_wip_agent into v_wip_agent_id, v_wip_sub_agent_id;
       close c_wip_agent;
       dbms_lob_append(v_log, 'v_wip_agent_id : '||v_wip_agent_id);
       dbms_lob_append(v_log, 'v_wip_sub_agent_id : '||v_wip_sub_agent_id);

       if p_user_type not in ('0', '2') and alz_policy_core_utils2.is_authorized_agent(p_security_info.userid, v_wip_agent_id, v_wip_sub_agent_id) = 0
         And (v_Is_Tpa_Centered = 0)--TPA2 Serdal
         then
          dbms_lob_append(v_log, 'is_authorized_agent bitti');
          alz_web_process_utils.process_result(0,
                                               9,
                                               -1,
                                               'USER ERR',
                                               'Kendi partajiniza ait teklif askilari �zerinde islem yapabilirsiniz.',
                                               null,
                                               p_mdlr_hlth_policy.policy_base.contract_id,
                                               null,
                                               'alz_mdlr_hlth_policy_utils.main_validations',
                                               p_security_info.userid,
                                               p_process_results);
       /*elsif p_user_type = '2' and v_sp_emp_id is not null then
          v_is_auth := alz_salesperson.sp_is_auth_for_pwq (v_sp_emp_id, p_mdlr_hlth_policy.policy_base.contract_id, null, null);
          if nvl(v_is_auth, 0) = 0 then
             alz_web_process_utils.process_result(0,
                                                  9,
                                                  -1,
                                                  'INVALID_AGENCY',
                                                  'Kendi partajiniza ait teklif askilari �zerinde islem yapabilirsiniz.',
                                                  null,
                                                  null,
                                                  p_mdlr_hlth_policy.policy_base.contract_id,
                                                  'alz_mdlr_hlth_policy_utils.main_page_validation',
                                                  p_security_info.userid,
                                                  p_process_results);
          end if;*/
       end if;

       open c_policy_exists_contract(p_mdlr_hlth_policy.policy_base.contract_id);
       fetch c_policy_exists_contract into v_exists_policy_ref;
       close c_policy_exists_contract;
       dbms_lob_append(v_log, 'v_exists_policy_ref : '||v_exists_policy_ref);

       if v_exists_policy_ref is not null and nvl(p_mdlr_hlth_policy.policy_base.version_no, 0) = 0 then
          alz_web_process_utils.process_result(0,
                                               9,
                                               -1,
                                               'POLICY INFO',
                                               p_mdlr_hlth_policy.policy_base.contract_id || ' nolu teklif poli�elesmis. (' || v_exists_policy_ref || ')',
                                               null,
                                               p_mdlr_hlth_policy.policy_base.contract_id,
                                               null,
                                               'alz_mdlr_hlth_policy_utils.main_validations',
                                               p_security_info.userid,
                                               p_process_results);
       else
          open c_wip_exists(p_mdlr_hlth_policy.policy_base.contract_id);
          fetch c_wip_exists into v_wip_exists;
          close c_wip_exists;
          dbms_lob_append(v_log, 'v_wip_exists : '||v_wip_exists);

          if nvl(v_wip_exists, 0) = 0 then
             alz_web_process_utils.process_result(0,
                                                  9,
                                                  -1,
                                                  'INVALID CONTRACT ID',
                                                  'Teklif bulunamadi.',
                                                  null,
                                                  p_mdlr_hlth_policy.policy_base.contract_id,
                                                  null,
                                                  'alz_mdlr_hlth_policy_utils.main_validations',
                                                  p_security_info.userid,
                                                  p_process_results);
          end if;
       end if;
    end if;

    v_prod_part_cont := null;

    open control_product_partition(p_mdlr_hlth_policy.policy_base.product_id,
                                   p_mdlr_hlth_policy.risk_subjects(1).risk_subject_base.partition_type,
                                   nvl(p_mdlr_hlth_policy.policy_base.first_quote_date, p_mdlr_hlth_policy.policy_base.signature_date));
    fetch control_product_partition into v_prod_part_cont;
    close control_product_partition;
    dbms_lob_append(v_log, 'v_prod_part_cont : '||v_prod_part_cont);

    if nvl(v_prod_part_cont, 0) = 0 then
       alz_web_process_utils.process_result(0,
                                            9,
                                            -1,
                                            'INVALID PRODUCT',
                                            '�r�n - �r�n Nevi hatali.',
                                            null,
                                            null,
                                            null,
                                            'alz_mdlr_hlth_policy_utils.main_validations',
                                            p_security_info.userid,
                                            p_process_results);
    end if;

    if nvl(p_mdlr_hlth_policy.policy_base.version_no, 0) = 0 and to_char(p_mdlr_hlth_policy.policy_base.term_start_date, 'DDMM') = '2902' then
       p_mdlr_hlth_policy.policy_base.term_start_date := to_date('28/02/'||to_char(p_global_opusdate, 'yyyy'), 'dd/mm/yyyy');
       p_mdlr_hlth_policy.policy_base.term_end_date := trunc(add_months (p_mdlr_hlth_policy.policy_base.term_start_date, 12));
    end if;

    dbms_lob_append(v_log, 'main_updates bitti');

    open c_write_log;
    fetch c_write_log into v_write_log;
    close c_write_log;

    if nvl(v_write_log, '0') = '1' then
       n_performance := DBMS_UTILITY.GET_TIME - n_performance;
       alz_mdlr_hlth_policy_utils7.p_insert_mdlr_log(p_mdlr_hlth_policy.policy_base.contract_id, null, v_log, 'MAIN_VALIDATIONS', null, null, to_char(n_performance, 'FM9999999999,00'), 1);
       IF (DBMS_LOB.ISTEMPORARY (v_log) = 1) THEN
           DBMS_LOB.FREETEMPORARY (v_log);
       end if;
    end if;

exception when others then
    dbms_lob_append(v_log, substr(sqlerrm || '--' || dbms_utility.format_error_backtrace, 1, 1000));
    n_performance := DBMS_UTILITY.GET_TIME - n_performance;
    alz_mdlr_hlth_policy_utils7.p_insert_mdlr_log(p_mdlr_hlth_policy.policy_base.contract_id, null, v_log, 'MAIN_VALIDATIONS', null, null, to_char(n_performance, 'FM9999999999,00'), -1);
    IF (DBMS_LOB.ISTEMPORARY (v_log) = 1) THEN
        DBMS_LOB.FREETEMPORARY (v_log);
    end if;
    alz_web_process_utils.process_result(0,
                                         9,
                                         -1,
                                         'ORACLE_EXCEPTION',
                                         substr(sqlerrm || '--' || dbms_utility.format_error_backtrace, 1, 1000),
                                         null,
                                         null,
                                         p_mdlr_hlth_policy.policy_base.contract_id,
                                         'alz_mdlr_hlth_policy_utils.main_validations',
                                         p_security_info.userid,
                                         p_process_results);

end;

procedure main_updates(p_mdlr_hlth_policy      in out      customer.mdlr_hlth_policy_rec,
                       --p_from_navigate         in          number,
                       p_user_type             in          varchar2,
                       p_user_agent_id         in          number,
                       p_action                in out      Customer.Action_Rec,
                       p_security_info         in          Customer.Security_Info_Rec,
                       p_simple_questions      in out      Customer.Simple_Question_Table,
                       p_process_results       in out      customer.process_result_table) is

cursor has_life(p_contract_id number) is
select 1
  from wip_koc_ocp_health a, wip_partitions b
 where a.contract_id = p_contract_id
   and a.partition_no = b.partition_no
   and b.action_code = 'D'
   and nvl(a.has_life,0) = 1;

v_has_life number;
v_return_amount      number;
v_return_amount_life number;
v_life_tah           number;
v_alinan_tahsilat    number;

v_partition_class     varchar2(10);
v_is_harmony_mnor     number := 0;
v_has_advance_payment number;

v_is_harmony_tss      number := 0;

v_log clob;

cursor c_write_log is
select value
  from system_parameters
 where code = 'CREATE_PROPOSAL_LOG';

v_write_log system_parameters.value%type;
n_performance number(38,9);

begin

   n_performance := DBMS_UTILITY.GET_TIME;
   dbms_lob_append(v_log, 'main_updates ba�l�yor...');

   dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.contract_id : '||p_mdlr_hlth_policy.policy_base.contract_id);
   dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.version_no : '||p_mdlr_hlth_policy.policy_base.version_no);
   dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.product_id : '||p_mdlr_hlth_policy.policy_base.product_id);
   dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.agent_int_id : '||p_mdlr_hlth_policy.policy_base.agent_int_id);
   dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.sub_agent_int_id : '||p_mdlr_hlth_policy.policy_base.sub_agent_int_id);
   dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.signature_date : '||p_mdlr_hlth_policy.policy_base.signature_date);
   dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.term_start_date : '||p_mdlr_hlth_policy.policy_base.term_start_date);
   dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.term_end_date : '||p_mdlr_hlth_policy.policy_base.term_end_date);

   --teknik personel bilgisini eger o acenteye ait sadece bir tane varsa update ediyoruz
    /*update_emp_id_no(p_mdlr_hlth_policy,
                     p_from_navigate,
                     p_action,
                     p_security_info,
                     p_simple_questions,
                     p_process_results);*/
        dbms_output.put_line('update_emp_id_no');                  

    v_partition_class := nvl(koc_health_policy_utils5.get_prod_part_mdlr(p_mdlr_hlth_policy.policy_base.product_id,
                                                                         alz_mdlr_hlth_policy_utils13.get_partition_type(p_mdlr_hlth_policy.policy_base.contract_id),
                                                                         p_mdlr_hlth_policy.policy_base.term_start_date), 'X');


    if p_mdlr_hlth_policy.Policy_Base.agent_int_id = 56269 and p_mdlr_hlth_policy.Policy_Base.bank_sales_channel = 'GWS_YKB' then -- hazala_26072016_banka i�in webden geliyor demek
      if v_partition_class = 'MNOR' then
        v_is_harmony_mnor := 1;
      end if;
    end if;

    -- hazala_24032017_tss_webservice
    if gws_utils.get_source_type(p_mdlr_hlth_policy.Policy_Base.contract_id) then
      --if alz_mdlr_hlth_policy_utils13.get_partition_type(p_mdlr_hlth_policy.policy_base.contract_id) = 'TSS' then --closed by egezer for TPA project 12.01.2018
      if alz_tpa_hlth_policy_utils.get_main_partition_type(p_mdlr_hlth_policy.policy_base.contract_id) = 'TSS' then --added by egezer for TPA project 12.01.2018
        v_is_harmony_tss := 1;
      end if;
    end if;
    --

    if nvl(p_mdlr_hlth_policy.policy_base.version_no, 0) = 0 then

       --hayat alip alamayacagi kararini verip update ediyoruz
       /*update_life_option(p_mdlr_hlth_policy,
                          p_security_info.userid,
                          p_process_results);

       update_md_option(p_mdlr_hlth_policy,
                        p_security_info.userid,
                        p_process_results,
                        1);*/
       dbms_output.put_line('update_life_option');                        

       if p_mdlr_hlth_policy.policy_base.term_start_date < trunc(sysdate) then
          p_mdlr_hlth_policy.policy_base.signature_date := trunc(sysdate);
       else
          p_mdlr_hlth_policy.policy_base.signature_date := p_mdlr_hlth_policy.policy_base.term_start_date;
       end if;

       update wip_koc_ocp_pol_versions_ext
          set life_agency_code = p_mdlr_hlth_policy.policy_base.life_agency_code,
              auth_document_group_id = p_mdlr_hlth_policy.policy_base.auth_document_group_id,
              signature_date = p_mdlr_hlth_policy.policy_base.signature_date,
              business_start_time = TO_DATE ('12:00', 'hh24:mi'),
              signature_time = TO_DATE ('12:00', 'hh24:mi'),
              is_calculated = 1,
              sub_agent = p_mdlr_hlth_policy.policy_base.sub_agent_int_id,
              bank_sales_channel = p_mdlr_hlth_policy.Policy_Base.bank_sales_channel,
              bank_user_code = p_mdlr_hlth_policy.Policy_Base.Bank_User_Code
        where contract_id = p_mdlr_hlth_policy.policy_base.contract_id;

       dbms_lob_append(v_log, 'v_is_harmony_mnor : ' || v_is_harmony_mnor);
       dbms_lob_append(v_log, 'v_is_harmony_tss : ' || v_is_harmony_tss);


       dbms_lob_append(v_log, 'p_mdlr_hlth_policy.Policy_Base.paymenttype : '||p_mdlr_hlth_policy.Policy_Base.paymenttype);
       dbms_lob_append(v_log, 'p_mdlr_hlth_policy.Policy_Base.no_of_installments : '||p_mdlr_hlth_policy.Policy_Base.no_of_installments);
       dbms_lob_append(v_log, 'p_mdlr_hlth_policy.Policy_Base.Installment_Card_Count : '||p_mdlr_hlth_policy.Policy_Base.Installment_Card_Count);
       dbms_lob_append(v_log, 'p_mdlr_hlth_policy.Policy_Base.has_advance_payment  : '||p_mdlr_hlth_policy.Policy_Base.has_advance_payment );
       dbms_lob_append(v_log, 'v_has_advance_payment : '||v_has_advance_payment);

      --if nvl(v_is_harmony_mnor, 0) = 1 or nvl(v_is_harmony_tss, 0) = 1 then -- hazala_24032017_tss_webservice -- hazala_26072016
      --hsenel 13032018 sprint 5
      --MD �r�n�nde KK blokaj �al��mas�
       if nvl(v_is_harmony_mnor, 0) = 1 or nvl(v_is_harmony_tss, 0) = 1
         or alz_tpa_hlth_policy_utils.get_main_partition_type(p_mdlr_hlth_policy.policy_base.contract_id) = 'MD' then -- hazala_24032017_tss_webservice -- hazala_26072016

       /*if  nvl(v_is_harmony_tss, 0) = 1  then  --added by egezer for TPA project 12.01.2018 start closed by egezer 19.01.2018 Halenur'un maili �zerine kapat�d�.

          if p_mdlr_hlth_policy.Policy_Base.paymenttype = 3 and p_mdlr_hlth_policy.policy_base.installment_card_count is null  then

             dbms_lob_append(v_log, 'v_is_harmony_tss i�inde tipi set edecek ' );

             dbms_lob_append(v_log, 'set edilmeden �nce p_mdlr_hlth_policy.Policy_Base.paymenttype : '||p_mdlr_hlth_policy.Policy_Base.paymenttype);
             dbms_lob_append(v_log, 'set edilmeden �nce p_mdlr_hlth_policy.Policy_Base.no_of_installments : '||p_mdlr_hlth_policy.Policy_Base.no_of_installments);
             dbms_lob_append(v_log, 'set edilmeden �nce p_mdlr_hlth_policy.Policy_Base.Installment_Card_Count : '||p_mdlr_hlth_policy.Policy_Base.Installment_Card_Count);
             dbms_lob_append(v_log, 'set edilmeden �nce p_mdlr_hlth_policy.Policy_Base.has_advance_payment  : '||p_mdlr_hlth_policy.Policy_Base.has_advance_payment );
             dbms_lob_append(v_log, 'set edilmeden �nce v_has_advance_payment : '||v_has_advance_payment);

             p_mdlr_hlth_policy.Policy_Base.paymenttype:= 2;
             p_mdlr_hlth_policy.policy_base.installment_card_count := NULL;
             v_has_advance_payment := 1;
             p_mdlr_hlth_policy.Policy_Base.no_of_installments := 1;

             dbms_lob_append(v_log, 'set edildikten sonra p_mdlr_hlth_policy.Policy_Base.paymenttype : '||p_mdlr_hlth_policy.Policy_Base.paymenttype);
             dbms_lob_append(v_log, 'set edildikten sonra p_mdlr_hlth_policy.Policy_Base.no_of_installments : '||p_mdlr_hlth_policy.Policy_Base.no_of_installments);
             dbms_lob_append(v_log, 'set edildikten sonra p_mdlr_hlth_policy.Policy_Base.Installment_Card_Count : '||p_mdlr_hlth_policy.Policy_Base.Installment_Card_Count);
             dbms_lob_append(v_log, 'set edildikten sonra p_mdlr_hlth_policy.Policy_Base.has_advance_payment  : '||p_mdlr_hlth_policy.Policy_Base.has_advance_payment );
             dbms_lob_append(v_log, 'set edildikten sonra v_has_advance_payment : '||v_has_advance_payment);

          else
              v_has_advance_payment:=  p_mdlr_hlth_policy.policy_base.has_advance_payment;
          end if;

        else*/ --added by egezer for TPA project 12.01.2018 finish

          dbms_lob_append(v_log, 'mnor poli�e geldi');

         if p_mdlr_hlth_policy.Policy_Base.paymenttype in ('2', '3') then
            v_has_advance_payment := 1;
          elsif p_mdlr_hlth_policy.Policy_Base.paymenttype = '1' and p_mdlr_hlth_policy.Policy_Base.no_of_installments != 1 then
            v_has_advance_payment := 0;
          elsif p_mdlr_hlth_policy.Policy_Base.paymenttype = '1' and p_mdlr_hlth_policy.Policy_Base.no_of_installments = 1 then
            v_has_advance_payment := 1;
         end if;

           dbms_lob_append(v_log, 'mnor poli�e sonras� v_has_advance_payment = '||v_has_advance_payment);

        --end if;  --added by egezer for TPA project 12.01.2018

          dbms_lob_append(v_log, 'p_mdlr_hlth_policy.Policy_Base.paymenttype : '||p_mdlr_hlth_policy.Policy_Base.paymenttype);
          dbms_lob_append(v_log, 'p_mdlr_hlth_policy.Policy_Base.no_of_installments : '||p_mdlr_hlth_policy.Policy_Base.no_of_installments);
          dbms_lob_append(v_log, 'p_mdlr_hlth_policy.Policy_Base.Installment_Card_Count : '||p_mdlr_hlth_policy.Policy_Base.Installment_Card_Count);
          dbms_lob_append(v_log, 'p_mdlr_hlth_policy.Policy_Base.campaign_code : '||p_mdlr_hlth_policy.Policy_Base.campaign_code);
          dbms_lob_append(v_log, 'v_has_advance_payment : '||v_has_advance_payment);

          update wip_koc_ocp_pol_versions_ext
             set payment_type           = p_mdlr_hlth_policy.Policy_Base.paymenttype,
                 no_of_installments     = p_mdlr_hlth_policy.Policy_Base.no_of_installments,
                 installment_card_count = decode(p_mdlr_hlth_policy.policy_base.paymenttype, 3, p_mdlr_hlth_policy.policy_base.installment_card_count, null),
                 has_advance_payment    = v_has_advance_payment
           where contract_id = p_mdlr_hlth_policy.policy_base.contract_id;

       elsif v_partition_class = 'MNOR' or nvl(v_is_harmony_tss, 0) = 1 then -- hazala_24032017_tss_webservice

           if p_mdlr_hlth_policy.hpf.payment_type = 'HAVL' then
              p_mdlr_hlth_policy.Policy_Base.paymenttype := '1';
           elsif p_mdlr_hlth_policy.hpf.payment_type = 'KK' then
              p_mdlr_hlth_policy.Policy_Base.paymenttype := '2';
           else
              p_mdlr_hlth_policy.Policy_Base.paymenttype := null;
           end if;

           dbms_lob_append(v_log, 'p_mdlr_hlth_policy.Policy_Base.paymenttype : '||p_mdlr_hlth_policy.Policy_Base.paymenttype);
           dbms_lob_append(v_log, 'p_mdlr_hlth_policy.Policy_Base.no_of_installments : '||p_mdlr_hlth_policy.Policy_Base.no_of_installments);
           dbms_lob_append(v_log, 'p_mdlr_hlth_policy.Policy_Base.Installment_Card_Count : '||p_mdlr_hlth_policy.Policy_Base.Installment_Card_Count);
           dbms_lob_append(v_log, 'p_mdlr_hlth_policy.Policy_Base.campaign_code : '||p_mdlr_hlth_policy.Policy_Base.campaign_code);
           dbms_lob_append(v_log, 'v_has_advance_payment : '||v_has_advance_payment);

           update wip_koc_ocp_pol_versions_ext
              set payment_type = p_mdlr_hlth_policy.Policy_Base.paymenttype,
                  installment_card_count = null
            where contract_id = p_mdlr_hlth_policy.policy_base.contract_id;
       /* elsif p_mdlr_hlth_policy.policy_base.company_code != '045' then --basakk : gorky => blokajli

           dbms_lob_append(v_log, 'p_mdlr_hlth_policy.Policy_Base.paymenttype : '||p_mdlr_hlth_policy.Policy_Base.paymenttype);
           dbms_lob_append(v_log, 'p_mdlr_hlth_policy.Policy_Base.Installment_Card_Count : '||p_mdlr_hlth_policy.Policy_Base.Installment_Card_Count);
           dbms_lob_append(v_log, 'p_mdlr_hlth_policy.Policy_Base.no_of_installments : '||p_mdlr_hlth_policy.Policy_Base.no_of_installments);
           dbms_lob_append(v_log, 'v_has_advance_payment : '||v_has_advance_payment);

           if p_mdlr_hlth_policy.Policy_Base.paymenttype = '3' then
             p_mdlr_hlth_policy.Policy_Base.no_of_installments := 1;
           end if;

           dbms_lob_append(v_log, 'p_mdlr_hlth_policy.Policy_Base.no_of_installments : '||p_mdlr_hlth_policy.Policy_Base.no_of_installments);

           update wip_koc_ocp_pol_versions_ext
              set payment_type = p_mdlr_hlth_policy.Policy_Base.paymenttype,
                  installment_card_count = decode(p_mdlr_hlth_policy.Policy_Base.paymenttype,2,null,p_mdlr_hlth_policy.Policy_Base.Installment_Card_Count),
                  no_of_installments = p_mdlr_hlth_policy.Policy_Base.no_of_installments,
                  has_advance_payment = 1
            where contract_id = p_mdlr_hlth_policy.policy_base.contract_id;

       elsif p_mdlr_hlth_policy.Policy_Base.paymenttype = '3' and alz_tpa_hlth_policy_utils.get_main_partition_type(p_mdlr_hlth_policy.policy_base.contract_id) = 'TSS' then --added by egezer for TPA project 24.08.2017

           dbms_lob_append(v_log, 'p_mdlr_hlth_policy.Policy_Base.paymenttype : '||p_mdlr_hlth_policy.Policy_Base.paymenttype);
           dbms_lob_append(v_log, 'p_mdlr_hlth_policy.Policy_Base.Installment_Card_Count : '||p_mdlr_hlth_policy.Policy_Base.Installment_Card_Count);
           dbms_lob_append(v_log, 'p_mdlr_hlth_policy.Policy_Base.no_of_installments : '||p_mdlr_hlth_policy.Policy_Base.no_of_installments);
           dbms_lob_append(v_log, 'v_has_advance_payment : '||v_has_advance_payment);

           p_mdlr_hlth_policy.Policy_Base.no_of_installments := 1;

           dbms_lob_append(v_log, 'p_mdlr_hlth_policy.Policy_Base.no_of_installments : '||p_mdlr_hlth_policy.Policy_Base.no_of_installments);

           update wip_koc_ocp_pol_versions_ext
              set payment_type = p_mdlr_hlth_policy.Policy_Base.paymenttype,
                  installment_card_count = p_mdlr_hlth_policy.Policy_Base.Installment_Card_Count,
                  no_of_installments = p_mdlr_hlth_policy.Policy_Base.no_of_installments,
                  has_advance_payment = 1
            where contract_id = p_mdlr_hlth_policy.policy_base.contract_id;*/

       end if;

       if p_mdlr_hlth_policy.hpf.official_form_serial_no is not null and p_mdlr_hlth_policy.hpf.official_form_no is not null then

          update koc_hpf
             set sub_agent = p_mdlr_hlth_policy.policy_base.sub_agent_int_id
           where official_form_serial_no = p_mdlr_hlth_policy.hpf.official_form_serial_no
             and official_form_no = p_mdlr_hlth_policy.hpf.official_form_no;

          --if p_mdlr_hlth_policy.policy_base.company_code != '045' then --basakk : gorky => blokajli  closed by egezer for TPA 24.08.2017
          --if alz_tpa_hlth_policy_utils.get_main_partition_type (p_mdlr_hlth_policy.policy_base.contract_id) ='TSS' and   --added by egezer for TPA project 24.08.2017
          --hsenel 13032018 sprint 5
          --KK blokaj �al��mas�
          if alz_tpa_hlth_policy_utils.get_main_partition_type (p_mdlr_hlth_policy.policy_base.contract_id) in ('TSS','MD') and   --added by egezer for TPA project 24.08.2017
             not gws_utils.get_source_type(p_mdlr_hlth_policy.Policy_Base.contract_id) then  --AliSakalli TPA-FAZ2

             if p_mdlr_hlth_policy.Policy_Base.paymenttype in ('2', '3')  then
                update koc_hpf
                   set payment_type = 'KK'
                 where official_form_serial_no = p_mdlr_hlth_policy.hpf.official_form_serial_no
                   and official_form_no = p_mdlr_hlth_policy.hpf.official_form_no;
             elsif p_mdlr_hlth_policy.Policy_Base.paymenttype in ('1') then
                update koc_hpf
                   set payment_type = 'HAVL'
                 where official_form_serial_no = p_mdlr_hlth_policy.hpf.official_form_serial_no
                   and official_form_no = p_mdlr_hlth_policy.hpf.official_form_no;
             end if;
          end if;
       end if;

       update wip_koc_ocp_partitions_ext
          set term_start_date     = p_mdlr_hlth_policy.policy_base.term_start_date,
              term_end_date       = p_mdlr_hlth_policy.policy_base.term_end_date,
              business_start_date = p_mdlr_hlth_policy.policy_base.term_start_date,
              business_end_date   = p_mdlr_hlth_policy.policy_base.term_end_date
        where contract_id = p_mdlr_hlth_policy.policy_base.contract_id
          and action_code = 'A';

       update wip_policy_bases
          set term_start_date = p_mdlr_hlth_policy.policy_base.term_start_date,
              term_end_date = p_mdlr_hlth_policy.policy_base.term_end_date
        where contract_id = p_mdlr_hlth_policy.policy_base.contract_id
          and action_code = 'A';

       update wip_policy_versions
          set business_start_date = p_mdlr_hlth_policy.policy_base.term_start_date,
              business_end_date   = p_mdlr_hlth_policy.policy_base.term_end_date
        where contract_id = p_mdlr_hlth_policy.policy_base.contract_id;

    else
       dbms_lob_append(v_log, 'else k�sm�ndas�n ');
       if nvl(p_mdlr_hlth_policy.policy_base.is_return_entered_manually,0) = 1 then

          v_alinan_tahsilat := koc_acc_health_utils.calculate_collection_amount (p_mdlr_hlth_policy.policy_base.contract_id);

          open has_life(p_mdlr_hlth_policy.policy_base.contract_id);
          fetch has_life into v_has_life;
          if has_life%notfound then
             v_life_tah := 0;
          else
             v_life_tah := koc_health_policy_utils5.calculate_coll_amt_life(p_mdlr_hlth_policy.policy_base.contract_id, null);
          end if;
          close has_life;

          v_return_amount_life := round(p_mdlr_hlth_policy.policy_base.return_amount*v_life_tah/(v_life_tah+v_alinan_tahsilat),2);
          v_return_amount := p_mdlr_hlth_policy.policy_base.return_amount-nvl(v_return_amount_life,0);

          if nvl(v_life_tah, 0)+nvl(v_alinan_tahsilat, 0) = 0 then
             p_mdlr_hlth_policy.policy_base.return_amount := 0;
             --p_mdlr_hlth_policy.policy_base.is_return_entered_manually := 0;
          else
             p_mdlr_hlth_policy.policy_base.return_amount := v_return_amount;
          end if;

       end if;

       update wip_koc_ocp_pol_versions_ext
          set signature_date = p_mdlr_hlth_policy.policy_base.signature_date,
              short_period_day_basis = p_mdlr_hlth_policy.policy_base.short_period_day_basis,
              is_return_entered_manually = p_mdlr_hlth_policy.policy_base.is_return_entered_manually,
              auth_document_group_id = p_mdlr_hlth_policy.policy_base.auth_document_group_id,
              return_amount = p_mdlr_hlth_policy.policy_base.return_amount,
              return_amount_life = nvl(v_return_amount_life, return_amount_life),
              bank_sales_channel = p_mdlr_hlth_policy.Policy_Base.bank_sales_channel,
              bank_user_code = p_mdlr_hlth_policy.Policy_Base.Bank_User_Code
        where contract_id = p_mdlr_hlth_policy.policy_base.contract_id;

       if nvl(v_is_harmony_mnor, 0) = 1 then -- hazala_26072016

        dbms_lob_append(v_log, 'else k�sm�ndas�n nvl(v_is_harmony_mnor, 0) = 1 i�indesin ');

         if p_mdlr_hlth_policy.Policy_Base.paymenttype in ('2', '3') then
           v_has_advance_payment := 1;
         elsif p_mdlr_hlth_policy.Policy_Base.paymenttype = '1' and p_mdlr_hlth_policy.Policy_Base.no_of_installments > 1 then
           v_has_advance_payment := 1;
         else
           v_has_advance_payment := 0;
         end if;

           dbms_lob_append(v_log, 'else k�sm�ndas�n p_mdlr_hlth_policy.Policy_Base.paymenttype : '||p_mdlr_hlth_policy.Policy_Base.paymenttype);
           dbms_lob_append(v_log, 'else k�sm�ndas�n p_mdlr_hlth_policy.Policy_Base.Installment_Card_Count : '||p_mdlr_hlth_policy.Policy_Base.Installment_Card_Count);
           dbms_lob_append(v_log, 'else k�sm�ndas�n p_mdlr_hlth_policy.Policy_Base.no_of_installments : '||p_mdlr_hlth_policy.Policy_Base.no_of_installments);
           dbms_lob_append(v_log, 'else k�sm�ndas�n v_has_advance_payment : '||v_has_advance_payment);

         update wip_koc_ocp_pol_versions_ext
            set payment_type           = p_mdlr_hlth_policy.Policy_Base.paymenttype,
                no_of_installments     = p_mdlr_hlth_policy.Policy_Base.no_of_installments,
                installment_card_count = p_mdlr_hlth_policy.Policy_Base.Installment_Card_Count,
                has_advance_payment    = v_has_advance_payment
          where contract_id = p_mdlr_hlth_policy.policy_base.contract_id;
       end if;

       update wip_policy_versions
          set business_start_date = p_mdlr_hlth_policy.policy_base.business_start_date,
              business_end_date   = p_mdlr_hlth_policy.policy_base.term_end_date
        where contract_id = p_mdlr_hlth_policy.policy_base.contract_id;

       update wip_koc_ocp_partitions_ext
          set short_period_day_basis = p_mdlr_hlth_policy.policy_base.short_period_day_basis
        where contract_id = p_mdlr_hlth_policy.policy_base.contract_id
          and action_code in ('D', 'A', 'C');

       update wip_koc_ocp_partitions_ext
          set term_end_date          = p_mdlr_hlth_policy.policy_base.business_start_date,
              business_start_date    = p_mdlr_hlth_policy.policy_base.business_start_date
        where contract_id = p_mdlr_hlth_policy.policy_base.contract_id
          and action_code = 'D';

       update wip_koc_ocp_partitions_ext
          set term_start_date     = p_mdlr_hlth_policy.policy_base.business_start_date,
              term_end_date       = p_mdlr_hlth_policy.policy_base.term_end_date,
              business_start_date = p_mdlr_hlth_policy.policy_base.business_start_date,
              business_end_date   = p_mdlr_hlth_policy.policy_base.term_end_date
        where contract_id = p_mdlr_hlth_policy.policy_base.contract_id
          and action_code = 'A';

       update koc_hpf
          set form_ent_date = p_mdlr_hlth_policy.policy_base.business_start_date,
              payment_type = p_mdlr_hlth_policy.hpf.payment_type,
              agent_role = p_mdlr_hlth_policy.policy_base.agent_int_id,
              sub_agent = p_mdlr_hlth_policy.policy_base.sub_agent_int_id,
              validity_start_date = sysdate
        where official_form_serial_no = p_mdlr_hlth_policy.hpf.official_form_serial_no
          and official_form_no = p_mdlr_hlth_policy.hpf.official_form_no;

    end if;

   open c_write_log;
   fetch c_write_log into v_write_log;
   close c_write_log;

   if nvl(v_write_log, '0') = '1' then
      n_performance := DBMS_UTILITY.GET_TIME - n_performance;
      alz_mdlr_hlth_policy_utils7.p_insert_mdlr_log(p_mdlr_hlth_policy.policy_base.contract_id, null, v_log, 'MAIN_UPDATES', null, null, to_char(n_performance, 'FM9999999999,00'), 1);
      IF (DBMS_LOB.ISTEMPORARY (v_log) = 1) THEN
          DBMS_LOB.FREETEMPORARY (v_log);
      end if;
   end if;

exception when others then
    dbms_lob_append(v_log, substr(sqlerrm || '--' || dbms_utility.format_error_backtrace, 1, 1000));
    n_performance := DBMS_UTILITY.GET_TIME - n_performance;
    alz_mdlr_hlth_policy_utils7.p_insert_mdlr_log(p_mdlr_hlth_policy.policy_base.contract_id, null, v_log, 'MAIN_UPDATES', null, null, to_char(n_performance, 'FM9999999999,00'), -1);
    IF (DBMS_LOB.ISTEMPORARY (v_log) = 1) THEN
        DBMS_LOB.FREETEMPORARY (v_log);
    end if;
    alz_web_process_utils.process_result(0,
                                         9,
                                         -1,
                                         'ORACLE_EXCEPTION',
                                         substr(sqlerrm || '--' || dbms_utility.format_error_backtrace, 1, 1000),
                                         null,
                                         null,
                                         p_mdlr_hlth_policy.policy_base.contract_id,
                                         'alz_mdlr_hlth_policy_utils.main_updates',
                                         p_security_info.userid,
                                         p_process_results);

end;

 



  Procedure Navigate_Request(p_contract_id           in out      Number,
                           p_policy_ref            in          Varchar2,
                           p_quote_ref             in          Varchar2,
                           p_version_no            in          Number,
                           p_product_id            in          Number,
                           p_partition_type        in          Varchar2,
                           p_term_end_date         in          Date,
                           p_agent_int_id          in          Number,
                           p_sub_agent_int_id      in          Number,
                           p_mdlr_hlth_policy         out      Customer.Mdlr_Hlth_Policy_Rec,
                           p_action                in out      Customer.Action_Rec,
                           p_security_info         in          Customer.Security_Info_Rec,
                           p_simple_questions      in out      Customer.Simple_Question_Table,
                           p_process_results       in out      Customer.Process_Result_Table) is

cursor c_endorse_explanation (p_product_id           number,
                              p_partition_type       varchar2,
                              p_endorsement_no       number,
                              p_endors_reason_code   varchar2) is
select i.long_name endorsement_exp,
       d.explanation endorse_reason_exp
  from alz_web_navigation_def r,
       koc_oc_prod_end_reason_rel d,
       koc_oc_endorsements e,
       inf_v_lang_trans_api i
 where r.product_id = p_product_id
   and r.partition_type = p_partition_type
   and r.endorsement_no = p_endorsement_no
   and d.product_id = r.product_id
   and (d.endors_reason_code is null or d.endors_reason_code = p_endors_reason_code)
   and d.endorsement_no(+) = r.endorsement_no
   and d.endors_reason_code(+) = r.endorsement_reason_code
   and e.endorsement_no = r.endorsement_no
   and i.desc_int_id = e.desc_int_id;

cursor curaction(p_action_code varchar2,
                 p_product_id  number,
                 p_partition_type varchar2,
                 p_endorsement_no number) is
select *
  from alz_web_action_def a
 where a.action_code = decode(p_action_code, 'ZEYILHPFDEVAM', 'ZEYIL', p_action_code)
   and a.product_id = p_product_id
   and a.partition_type = p_partition_type
   and NVL(a.endorsement_no, nvl(p_endorsement_no, 0)) = NVL(p_endorsement_no, 0);

cursor c_term_start_date(p_contract_id number) is
select term_start_date
  from wip_koc_ocp_partitions_ext
 where contract_id = p_contract_id
   and action_code = 'A';

cursor c_quote(p_quote_ref varchar2) is
select quote_id
  from ocq_quotes a
 where a.quote_reference = p_quote_ref;

cursor c_move_code (p_contract_id number) is
select move_code
  from wip_policy_versions
 where contract_id = p_contract_id;

cursor c_region_code(p_agent_int_id number, p_date date) is
select a.region_code
  from koc_dmt_v_current_agents a
 where agen_int_id = p_agent_int_id
   and start_date <= p_date
   and (end_date >= p_date or end_date is null);

v_region_code koc_dmt_v_current_agents.region_code%type;

cursor c_has_modul(p_contract_id number) is
select count(*)
  from wip_koc_ocp_risk_packages_sub
 where contract_id = p_contract_id;

v_has_modul number;

cursor c_has_auth_abort(p_contract_id number, p_version_no number) is
select 1
  from koc_hpf_trans r
 where r.contract_id = p_contract_id
   and version_no = p_version_no
   and nvl(R.IS_ABORTED,0) = 0 ;

cursor c_has_auth(p_contract_id number, p_version_no number) is
select 1
  from koc_hpf_trans r
 where r.contract_id = p_contract_id
   and version_no = p_version_no
   and nvl(R.IS_ABORTED,0) = 0
   and (r.partition_no = 0 or r.hpf_status = 'T055'
        or exists (select 1
                     from koc_hpf_trn_det t
                    where t.contract_id = r.contract_id
                      and t.version_no = r.version_no
                      and nvl(r.hpf_status,'T055') = 'T055'
                      and (t.solution is null or t.solution_accept_date is null or t.is_rejected is null)));

cursor c_payment_type(p_contract_id number) is
select r.payment_type
  from koc_hpf r, koc_ocp_pol_versions_ext t
 where t.contract_id = p_contract_id
   and t.top_indicator = 'Y'
   and r.contract_id = t.contract_id
   and r.version_no = t.version_no;

cursor c_payment_type_pol(p_contract_id number) is
select payment_type
  from koc_hpf
 where contract_id = p_contract_id
   and version_no = 1;

v_payment_type koc_hpf.payment_type%type;
v_has_auth number;
v_signature_date          date := pme_public.opus_date;
v_term_start_date         date;
v_quote_id                number;
v_move_code               varchar2 (20);
v_is_uw_user              number := 0;
v_uw_police number;
recaction curaction%rowtype;
v_obf_serial_no varchar2(100);
v_obf_form_no number;
v_is_continue number := 1;
V_Koc_Hpf_Rec             customer.mdlr_hlth_hpf_rec;
v_user_type               koc_dmt_agents_ext.TYPE%type;
v_user_agent_id           number;
v_is_industrial_user      number;
v_agent_category_type     varchar(4);
v_parent_agent_int_id     number;
v_user_part_id            number;

v_version_no_became number;

v_official_form_serial_no varchar2(2);

cursor c_agent_int_id(p_reference_code varchar2, p_date date) is
select a.agen_int_id
  from koc_dmt_v_current_agents a
 where reference_code = p_reference_code
   and start_date <= p_date
   and (end_date >= p_date or end_date is null);

v_reference_code varchar2(10);
v_agent_int_id number;

v_user_role varchar2(10);

v_action_code varchar2(50);
v_partition_no number;
v_has_number   number;

v_process_results Customer.Process_Result_Table;

cursor c_ocp_to_wip(c_contract_id number) is
select quote_reference
  from ocq_quotes
 where contract_id_became = c_contract_id
   and version_no_became = 1;

v_quote_ref  ocq_quotes.quote_reference%type;

cursor c_has_hpf(p_contract_id number, p_version_no number) is
select 1
  from koc_hpf
 where contract_id = p_contract_id
   and version_no = p_version_no
   and pro_form_use_status = '1';

v_has_hpf number;

v_except_unauthorized_agent number;

v_is_policy_on_ren_desk number;

cursor c_is_renewal_policy(p_contract_id number) is
select 1
  from koc_ocp_health r
 where r.contract_id = p_contract_id
   and (r.old_policy_contract_id is not null or r.as400_policy_no is not null)
   and rownum < 2;

v_is_renewal_policy number;

cursor c_ocp_bases(p_contract_id number) is
select e.region_code
  from koc_ocp_pol_versions_ext e
 where e.contract_id = p_contract_id
   and e.version_no = 1;

v_base_agent_int_id ocp_policy_bases.agent_role%TYPE;
v_base_agency_code varchar2(50);
v_base_agent_name varchar2(500);
v_base_region_code wip_koc_ocp_pol_versions_ext.region_code%TYPE;
v_base_sub_agent_int_id koc_ocp_pol_versions_ext.sub_agent%TYPE;
v_base_sub_agent_code varchar2(50);
v_base_sub_agent_name varchar2(500);

cursor c_agent_role(p_contract_id number) is
select agent_role
  from wip_policy_bases
 where contract_id = p_contract_id;

v_agent_role number;

cursor c_max_quote_id (p_contract_id number) is
select quote_id, quote_reference, quote_expiry_date, move_code
  from ocq_quotes
 where quote_id in (select max(quote_id)
                      from ocq_quotes
                     where contract_id = p_contract_id);

v_max_quote_id number;

v_quote_move_code varchar2(10);

v_quote_reference varchar2(30);

v_quote_expiry_date date;

v_invoke_user  varchar2 (30) := 'ALLZWEBPOL';
v_client_route oc_components.comp_name%type;
v_route_type   oc_components.com_type%type;
v_result       integer;

v_new_contract_id number;

v_partition_class varchar2(25);
v_trans_type number;


cursor c_is_renewal (p_contract_id number) is --basakk
select nvl(is_renewal,0)
              from wip_koc_ocp_pol_contracts_ext
          where contract_id=p_contract_id;

v_is_renewal number; --basakk

cursor c_koc_hpf_status(pc_contract_id number) is
  select official_form_serial_no, official_form_no
    from koc_hpf
   where contract_id = pc_contract_id
     and pro_form_use_status = 1;

v_form_serial_no varchar2(10);
v_form_no        number;

cursor c_write_log is
select value
  from system_parameters
 where code = 'CREATE_PROPOSAL_LOG';

--dilekb
cursor c_has_wip(c_contract_id number) is
  select 1
      from wip_policy_bases w
     where w.contract_id = c_contract_id ;
w_version_no number;--dilekb
v_has_wip  number;--dilekb
v_write_log system_parameters.value%type;

v_log clob;
n_performance number(38,9);


CURSOR c_insured_partner_id IS
select distinct a.partner_id
  FROM wip_interested_parties     a,
       wip_ip_links               b,
       wip_koc_ocp_partitions_ext c
 WHERE c.contract_id = p_contract_id
   AND a.contract_id = c.contract_id
   AND b.partition_no = c.partition_no
   and b.role_type = 'INS'
   and b.contract_id = a.contract_id
   AND b.ip_no = a.ip_no;

cursor c_company_code is --basakk : gorky
  select company_code
    from koc_oc_prod_partition_rel
   where product_id        = p_product_id
        and partition_type = p_partition_type;

v_company_code             varchar2(30); --basakk : gorky

cursor c_ref_contract_id(p_ref_policy varchar2) is  --basakk : yerinekaim yk-209
select contract_id from ocp_policy_bases where policy_ref=p_ref_policy;

v_ref_contract_id          number; --basakk : yerinekaim yk-209
v_ref_version_no           number; --basakk : yerinekaim yk-209
v_yk_bildirim              varchar2(100); --basakk : yerinekaim yk-209
v_simple_question_rec      customer.simple_question_rec; --basakk : yerinekaim yk-209

cursor c_yk_wip is  --basakk : yerinekaim yk-209
select a.reference_contract_id, nvl(b.version_no,0)
  from wip_koc_ocp_pol_contracts_ext a, wip_koc_ocp_pol_versions_ext b
 where a.contract_id = b.contract_id
   and a.contract_id = p_contract_id;

cursor c_yk_old_contract_id (p_contract_id number) is --basakk : yerinekaim yk-269
select old_policy_contract_id from koc_ocp_health where contract_id=p_contract_id and old_policy_contract_id is not null;

v_yk_wip_contract_id  number; --basakk : yerinekaim yk-269
v_yk_wip_contract_id2 number; --basakk : yerinekaim ruw-45
v_ref_control         number; --basakk : yerinekaim yk-276

v_exist_red_record number;
cursor c_exist_red_record(p_contract_id number) is
select 1
  from wip_koc_ocp_pol_contracts_ext
  where contract_id = p_contract_id
  and action_code = 'U'
  and hlth_quote_status = 'T023';

--added by egezer for TPA project 07.12.2017 start
 cursor c_wip_payment_type (p_contract_id in number) is
 select payment_type ,version_no
   from wip_koc_ocp_pol_versions_ext
  where contract_id = p_contract_id;

 --closed by egezer for TPA project 24.01.2018 meb iptallerde �deme tipinin hatal� g�ncellenmesine neden oluyordu.
/* cursor c_kk_odeme_varmi (p_contract_id in number) is
 select 1
   from koc_acc_policy_details a,
        koc_acc_cc_details b,
        koc_acc_receipt_master c
  where a.contract_id = p_contract_id
    and a.receipt_id  = b.receipt_id
    and a.order_no    = b.order_no
    and a.receipt_id  = c.receipt_id
    and nvl(c.is_cc_form_cancel,0) = 0;*/

 --added by egezer for TPA project 24.01.2018 meb iptallerde hatal� g�ncellenen �deme tipleri i�in yaz�ld�. Muharrem �nal'dan destek al�nd�.
 cursor c_kk_odeme_varmi (p_contract_id in number) is
 select 1
   from koc_acc_policy_details a ,
        koc_acc_v_cc_transaction b
  where a.contract_id = p_contract_id
    and a.receipt_id = b.receipt_id
    and a.order_no = b.order_no
    and b.status = 'YOLP';

cursor c_odeme_varmi (p_contract_id  number) is
select sum(a.paid_total) paid_total
  from koc_acc_policy_details a,
       koc_acc_payment_details b,
       koc_acc_receipt_master c
 where 1=1
   and a.contract_id = p_contract_id
   and a.receipt_id  = b.receipt_id
   and a.order_no = b.order_no
   and b.batch_id is not null
   and b.batch_id <> 0
   and b.coll_acc_date is not null
   and b.receipt_id = c.receipt_id
   and b.receipt_id = c.receipt_id
   and c.receipt_type <> 'KOM'
   having sum(a.paid_total) > 0;

  cursor c_cc_exists(p_contract_id number) is
  select 1
    from koc_acc_cc_history
   where contract_id = p_contract_id
     and validity_start_date <= sysdate
     and (validity_end_date >= sysdate or validity_end_date is null);

 cursor c_ocp_count (p_contract_id number) is
 select count(*) sayi
   from ocp_policy_bases
  where contract_id=p_contract_id;

  cursor c_sona_eren (p_contract_id number,p_version_no number) is
  select 1
    from ocp_policy_bases
   where contract_id = p_contract_id
     and version_no = p_version_no
     and term_end_date < pme_public.opus_date;

 --added by egezer for ANLZ_TPA_103 31.01.2018 start
 cursor c_ocp_rec (p_contract_id in number) is
 select payment_type,installment_card_count,no_of_installments,has_advance_payment
   from koc_ocp_pol_versions_ext
  where contract_id = p_contract_id
    and version_no = 1;

 v_ocp_rec                 c_ocp_rec%rowtype;
 --added by egezer for TPA ANLZ_TPA_103 31.01.2018  finish

 cursor c_get_endors_reason is
 select k.endors_reason_code
 from wip_koc_ocp_pol_versions_ext k
 where k.contract_id = p_contract_id;

 v_endors_reason          wip_koc_ocp_pol_versions_ext.endors_reason_code%type;
 v_wip_payment_type       wip_koc_ocp_pol_versions_ext.payment_type%type;
 v_ocp_payment_type       koc_ocp_pol_versions_ext.payment_type%type;
 v_kk_odeme_count         number;
 v_cc_exists              number;
 v_zeyil                  number;
 v_paid_total             number;
 v_ocp_count              number;
 v_versions_payment_type  koc_ocp_pol_versions_ext.payment_type%type;
 v_partition_type         wip_partitions.partition_type%type;
 v_sona_eren              number;
 v_cmp                    varchar2(30); --AliSakalli log
--added by egezer for TPA project 07.12.2017 finish

 cursor c_agent_role_ocp(pc_contract_id number) is --basakk : ruw-227
  select agent_role from ocp_policy_bases where contract_id = pc_contract_id;

 cursor c_bank_sales_channel(pc_contract_id number) is --basakk: ruw-227
   select bank_sales_channel from koc_ocp_pol_versions_ext where contract_id=pc_contract_id;

 cursor c_bank_payment_type(pc_contract_id number) is --basakk: ruw-227
   select payment_type from koc_hpf where contract_id=pc_contract_id;

 cursor c_hour_control is --basakk : ruw-227
   select to_char(sysdate,'HH24'), to_char(sysdate,'MI') from dual;

 v_hour                number; --basakk : ruw-227
 v_minute              number; --basakk : ruw-227
 v_bank_sales_channel  varchar2(25); --basakk : ruw-227
 v_bank_payment_type   varchar2(25); --basakk : ruw-227
begin

   n_performance := DBMS_UTILITY.GET_TIME;
   begin
       alz_web_process_utils.security_info_log_insert (p_contract_id,
                                                       null,
                                                       'BEGIN',
                                                       p_security_info,
                                                       p_action);
   exception when others then
       null;
   end;

   v_log := null;
   dbms_lob_append(v_log,'Navigate_Request ba�l�yor...');

   v_has_number := TRANSLATE(nvl(p_action.action_code, 'X'), '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ!�''^#+$%�/{([])}=?*\-_,;<>|:. ', '1234567890');

   if nvl(p_action.action_code, 'X') like '%POLICEGORUNTULE%' and v_has_number is not null then
     v_partition_no := substr(p_action.action_code, instr(p_action.action_code, '-') + 1, length(p_action.action_code));
     p_action.action_code := 'POLICEGORUNTULE';
   end if;

   dbms_lob_append(v_log, 'p_policy_ref : '||p_policy_ref||' p_contract_id : '||p_contract_id||' p_quote_ref : '||p_quote_ref||' p_version_no : '||p_version_no);
   dbms_lob_append(v_log, 'p_product_id : '||p_product_id||' p_partition_type : '||p_partition_type||' p_term_end_date : '||p_term_end_date||' p_agent_int_id : '||p_agent_int_id);
   dbms_lob_append(v_log, 'p_sub_agent_int_id : '||p_sub_agent_int_id||' p_action.action_code : '||p_action.action_code||' p_action.current_page : '||p_action.current_page);
   dbms_lob_append(v_log, 'p_action.button_name : '||p_action.button_name||' p_action.endorsement_code : '||p_action.endorsement_code||' p_action.endors_reason_code : '||p_action.endors_reason_code);
   dbms_lob_append(v_log, 'p_security_info.userid : '||p_security_info.userid||' p_security_info.agency_code : '||p_security_info.agency_code);

   action_log (p_contract_id, p_action);
   security_info_log (p_contract_id, p_security_info);

   alz_base_function_utils.user_type(p_security_info.userid,
                                     v_user_type,
                                     v_user_agent_id,
                                     v_is_industrial_user,
                                     v_agent_category_type,
                                     v_parent_agent_int_id,
                                     v_user_part_id);

   v_user_role := koc_hpf_utils.get_user_role(p_security_info.userid);

   p_process_results := customer.process_result_table();

   if p_simple_questions is null then
      p_simple_questions := customer.simple_question_table();
   end if;

   if v_user_role is null then
      alz_web_process_utils.process_result (0,
                                            9,
                                            -1,
                                            'USERROLE_ERR',
                                            'Kullan�c� yetkilerinizde eksiklik bulnumaktad�r. L�tfen BSS''e �a�r� a�t�r�n�z.',
                                            NULL,
                                            NULL,
                                            NULL,
                                            'alz_mdlr_hlth_policy_utils.navigate_request',
                                            p_security_info.userid,
                                            p_process_results);
   end if;

   v_is_uw_user := alz_policy_core_utils.is_uw_user (p_security_info.userid);

   v_version_no_became := koc_hpf_utils3.get_top_version (p_contract_id);

   --iertekin ilk ba�ta gelen action_code'u tutmak i�in. daha sonra de�i�tirdi�imizde gelen action_code gerekebilir..
   v_action_code := nvl(p_action.action_code, 'X');

   if nvl(p_action.action_code, 'X') = 'ZEYILACENTE' then
      p_action.action_code := 'ZEYIL';
   end if;

   open c_sona_eren(p_contract_id,p_version_no);
    fetch c_sona_eren into v_sona_eren;
   close c_sona_eren;

   if nvl(p_action.action_code, 'X') = 'ZEYIL' AND nvl(v_sona_eren,0) <> 0 AND v_user_role = 'SFOPER' and (nvl(p_simple_questions.count, 0) = 0 or p_simple_questions(p_simple_questions.count).questionid = '510')then

       if alz_base_function_utils.question_exists(p_simple_questions, 510) = 0  then
           if p_simple_questions is null then
              p_simple_questions := customer.simple_question_table();
           end if;
           p_simple_questions.EXTEND;
           p_simple_questions(p_simple_questions.count) :=customer.simple_question_rec(510,'Dikkat! Bitmi� poli�eye zeyil yapmaktas�n�z, devam edilsin mi?',1,null,null);
           goto end_of_navigate;
       else
           if NVL(alz_base_function_utils.question_answer(p_simple_questions, 510), 0) = 0 then
              goto end_of_navigate;
           end if;
              alz_base_function_utils.question_delete(p_simple_questions, 510);
       end if;

   end if;

   --iertekin otorizasyonda kayd� varsa ask�y� silmek istese de silmeyece�iz AHT-5559
   if nvl(p_action.action_code, 'X') = 'ASKIVAZGEC' then

      open c_move_code(p_contract_id);
      fetch c_move_code into v_move_code;
      close c_move_code;

      open c_has_auth_abort(p_contract_id, v_version_no_became);
      fetch c_has_auth_abort into v_has_auth;
      --aski silme ismail 29_01_2016
      if c_has_auth_abort%found then
         if v_user_role = 'SFOPER' then  --sadece SFOPER ask� silebilir
           if nvl(p_mdlr_hlth_policy.policy_base.is_renewal, 0) = 0 then
              if nvl(p_action.endorsement_code, 0) not in (1, 2, 14, 11) then
                p_action.action_code := 'ASKIKAYDET';
              end if;
           else
              if nvl(p_action.endorsement_code, 0) = 1 and p_action.endors_reason_code in ('SGIR') then --sadece yenileme ve sigortali giri� var ise ask� silebilir.
                p_action.action_code := 'ASKIVAZGEC';
              else
                p_action.action_code := 'ASKIKAYDET'; --farkl� bir yenileme de ise ask� kaydet
              end if;
           end if;
         else
           p_action.action_code := 'ASKIKAYDET'; --sfoper de�ilse ask� kaydet.
         end if;
      end if;
      close c_has_auth_abort;
   end if;

   open c_quote(p_quote_ref);
   fetch c_quote into v_quote_id;
   close c_quote;

   dbms_lob_append(v_log, 'search_validations giriyoruz');

   alz_mdlr_hlth_policy_utils1.search_validations(p_action,
                                                  p_contract_id,
                                                  p_version_no,
                                                  v_quote_id,
                                                  p_security_info.userid,
                                                  p_simple_questions,
                                                  v_is_continue,
                                                  p_process_results);

   dbms_lob_append(v_log, 'search_validations bitti v_is_continue : '||v_is_continue);

   if alz_web_process_utils.process_result_err (p_process_results) = 1 or v_is_continue = 0 then
      dbms_lob_append(v_log, 'search_validations hata d�nd�rd�');
      goto end_of_navigate;
   end if;

   --iertekin arama ekran�ndan geldi�inde basvur diye geliyorsa hangi teklife basvur dediyse onunla ask�y� aolu�turmak i�in KARSILASTIR button_name ile invoke'a gidiyoruz.
   if nvl(p_action.action_code, 'X') = 'BASVURU' and nvl(p_action.button_name, 'X') <> 'BASVUR' then

       --serken tss-mdsg gecisi icin yeni buton name verildi. invoke 'dan gecerken gerekli.
       if nvl(p_action.button_name, 'X') not in ('OCQTOMDSG', 'WIPTOMDSG', 'OCQTOTSS', 'WIPTOTSS', 'WIPTOMDSGTYPE', 'WIPTOTSSTYPE') then
        p_action.button_name := 'KARSILASTIR';
       end if;
   end if;

   if p_action.endorsement_code in (2,14) then --basakk : ruw-227
      v_partition_class := nvl(alz_mdlr_hlth_policy_utils13.get_partition_class (p_contract_id), 'X');
      open  c_agent_role_ocp(p_contract_id);
      fetch c_agent_role_ocp into v_agent_role;
      close c_agent_role_ocp;

      open  c_bank_sales_channel(p_contract_id);
      fetch c_bank_sales_channel into v_bank_sales_channel;
      close c_bank_sales_channel;

      open  c_bank_payment_type(p_contract_id);
      fetch c_bank_payment_type into v_bank_payment_type;
      close c_bank_payment_type;

      dbms_lob_append(v_log, 'ruw-227 v_partition_class : ' || v_partition_class);
      dbms_lob_append(v_log, 'ruw-227 v_agent_role : ' || v_agent_role);
      dbms_lob_append(v_log, 'ruw-227 v_bank_sales_channel : ' || v_bank_sales_channel);
      dbms_lob_append(v_log, 'ruw-227 v_bank_payment_type : ' || v_bank_payment_type);

      if v_partition_class = 'MNOR' and v_agent_role = 56269 and v_bank_sales_channel='GWS_YKB' and v_bank_payment_type='HAVL' then
         dbms_lob_append(v_log, 'ruw-227 v_partition_class = MNOR and 56269 GWS_YB and HAVL');

         open  c_hour_control;
         fetch c_hour_control into v_hour, v_minute;
         close c_hour_control;

         if (v_hour >= 0 and v_hour < 9) or (v_hour = 9 and v_minute <= 30) then
            alz_web_process_utils.process_result (0,
                                                  9,
                                                  -1,
                                                  'INVOKE ERR',
                                                  '10503 partajl� NZB ve MD poli�eleri i�in 00:00 - 09:30 saatleri aras� iptal i�lemi yap�lamaz.',
                                                  NULL,
                                                  NULL,
                                                  NULL,
                                                  'alz_mdlr_hlth_policy_utils.navigate_request',
                                                  p_security_info.userid,
                                                  p_process_results);
         end if;
      end if;
      v_agent_role := null;
    end if;

   dbms_lob_append(v_log, 'ASKIDEVAM ifi �ncesi');
   dbms_lob_append(v_log, 'p_action.action_code : ' || p_action.action_code);
   if nvl(p_action.action_code, 'X') in ('ASKIDEVAM', 'HPFDEVAM', 'YERINEKAIMHPFDEVAM') then --basakk : yerinekaim yk-267 yerinekaimhpfdevam eklendi
      dbms_lob_append(v_log, 'ASKIDEVAM,HPFDEVAM ifine girdi');
      open  c_yk_wip; --basakk : yerinekaim yk-209
      fetch c_yk_wip into v_ref_contract_id, v_ref_version_no;
      close c_yk_wip;

      dbms_lob_append(v_log, 'v_ref_contract_id : ' || v_ref_contract_id);
      dbms_lob_append(v_log, 'v_ref_version_no : ' || v_ref_version_no);

      if v_ref_contract_id is not null and v_ref_version_no = 0 then --basakk : yerinekaim yk-209
         dbms_lob_append(v_log, 'reference_contract_validations �al��cak');

         v_simple_question_rec := customer.simple_question_rec(499,null,null,1,null);
         p_simple_questions.extend;
         p_simple_questions(p_simple_questions.count) := v_simple_question_rec;

         v_simple_question_rec := customer.simple_question_rec(500,null,null,1,null);
         p_simple_questions.extend;
         p_simple_questions(p_simple_questions.count) := v_simple_question_rec;

         v_simple_question_rec := customer.simple_question_rec(501,null,null,1,null);
         p_simple_questions.extend;
         p_simple_questions(p_simple_questions.count) := v_simple_question_rec;

         v_simple_question_rec := customer.simple_question_rec(508,null,null,1,null); --basakk : yerinekaim yk-308
         p_simple_questions.extend;
         p_simple_questions(p_simple_questions.count) := v_simple_question_rec;

         alz_mdlr_hlth_policy_utils16.reference_contract_validations(v_ref_contract_id, p_contract_id, p_action.action_code, p_security_info.userid, v_is_continue, p_simple_questions, p_process_results); --validasyonlar --ruw-22

         alz_base_function_utils.question_delete(p_simple_questions, 499);
         alz_base_function_utils.question_delete(p_simple_questions, 500);
         alz_base_function_utils.question_delete(p_simple_questions, 501);
         alz_base_function_utils.question_delete(p_simple_questions, 508); --basakk : yerinekaim yk-308

         v_ref_control := 0;
         dbms_lob_append(v_log, 'reference_contract_validations sonras� process_result kontrol edilecek');
         if alz_web_process_utils.process_result_err (p_process_results) = 1 then --or v_is_continue = 0 then
            dbms_lob_append(v_log, 'reference_contract_validations hata d�nd�rd� : yerine kaim ask�s� uygun de�il');
            v_ref_control := 1;
         end if;
         dbms_lob_append(v_log, 'reference_contract_validations sonras� process_result kontrol edildi : ' || v_ref_control);

         dbms_lob_append(v_log, 'ref_auth_control : ' || alz_mdlr_hlth_policy_utils16.ref_auth_control(p_contract_id));
         if nvl(v_ref_control,0) = 0 and alz_mdlr_hlth_policy_utils16.ref_auth_control(p_contract_id)=1  then --basakk : yerinekaim yk-276 kaime uygunsa do�um mod�l� ve limit kontrol� de yaps�n (otorizasyonda ise)
             --basakk : yerinekaim yk-276 => limit kontrol�
             dbms_lob_append(v_log, 'limit_control �al��acak');
             alz_mdlr_hlth_policy_utils16.limit_control(p_contract_id,
                                                        p_security_info.userid,
                                                        v_is_continue,
                                                        p_simple_questions,
                                                        p_process_results);

             if alz_web_process_utils.process_result_err (p_process_results) = 1  then
               dbms_lob_append(v_log, 'kaim ask� limit kontrol� nedeniyle durduruldu');
               alz_mdlr_hlth_policy_utils16.set_session_hpf_status ('T092'); --ruw-19
               --goto end_of_navigate;
               v_ref_control := 1;
             end if;
             dbms_lob_append(v_log, 'limit_control �al��t� :' || v_ref_control);

             --basakk : yerinekaim yk-276 => hd mod�l kontrol�
             if nvl(v_ref_control,0) = 0 then
               dbms_lob_append(v_log, 'hd_cover_control �al��acak');
               alz_mdlr_hlth_policy_utils16.hd_cover_control(p_contract_id,
                                                             p_security_info.userid,
                                                             v_is_continue,
                                                             p_simple_questions,
                                                             p_process_results);

               if alz_web_process_utils.process_result_err (p_process_results) = 1  then
                 dbms_lob_append(v_log, 'kaim ask� hd kontrol� nedeniyle durduruldu');
                 alz_mdlr_hlth_policy_utils16.set_session_hpf_status ('T091'); --ruw-19
                 --goto end_of_navigate;
                 v_ref_control := 1;
               end if;
               dbms_lob_append(v_log, 'hd_cover_control �al��t� :' || v_ref_control);
             end if;
         end if;

         --if alz_web_process_utils.process_result_err (p_process_results) = 1 or v_is_continue = 0 then
         if nvl(v_ref_control,0) = 1 then  --basakk : yerinekaim yk-276 kaime uygunlu�u bozulduysa ask�y� reddetsin
          --red �al��mal� --basakk :yerinekaim yk-210
          alz_mdlr_hlth_policy_utils16.contract_reject(p_contract_id,
                                                       v_ref_version_no,
                                                       p_security_info.userid,
                                                       v_yk_bildirim,
                                                       v_log,
                                                       p_process_results); --basakk : yerinekaim yk-276
          --
          dbms_lob_append(v_log, 'goto end_of_navigate gidiyoruuzz');
          goto end_of_navigate;
         end if;

      end if;

      alz_mdlr_hlth_policy_utils10.ren_desk_contract_load_opers(p_contract_id, p_security_info.userid, p_process_results);
      v_is_policy_on_ren_desk := alz_mdlr_hlth_policy_utils10.is_policy_on_ren_desk(p_contract_id, p_security_info.userid, p_process_results);
      if nvl(v_is_policy_on_ren_desk, 0) = 1 then
         p_action.action_code := 'ASKIGORUNTULEME';
      end if;
      if nvl( p_mdlr_hlth_policy.policy_base.endorsement_no, 0) <> 1 then--filizd, indirim zeyili
          alz_mdlr_hlth_policy_utils4.renewal_day_questions(p_contract_id, p_simple_questions, v_is_continue, p_security_info.userid, p_process_results);
          if nvl(v_is_continue, 1) = 0 then
             dbms_lob_append(v_log, 'goto end_of_navigate girdik');
             goto end_of_navigate;
          end if;
      end if;
   end if;

   dbms_lob_append(v_log, 'p_action.action_code : '||p_action.action_code);

   if nvl(p_action.action_code, 'X') = 'YENILEME' then
      dbms_lob_append(v_log, 'wip_continue_control giriyoruz p_contract_id : '||p_contract_id);
      alz_mdlr_hlth_policy_utils4.wip_continue_control(p_contract_id,
                                                       p_action,
                                                       p_simple_questions,
                                                       v_is_continue,
                                                       p_security_info.userid,
                                                       p_process_results);

      dbms_lob_append(v_log, 'wip_continue_control bitti p_contract_id : '||p_contract_id);
      dbms_lob_append(v_log, 'wip_continue_control bitti v_is_continue : '||v_is_continue);
      dbms_lob_append(v_log, 'wip_continue_control bitti p_action.action_code : '||p_action.action_code);

      if alz_web_process_utils.process_result_err (p_process_results) = 1 or v_is_continue = 0 then
         dbms_lob_append(v_log, 'goto end_of_navigate girdik');
         goto end_of_navigate;
      end if;

   elsif nvl(p_action.action_code, 'X') = 'YERINEKAIM' then --basakk : yerinekaim yk-269
      open  c_yk_old_contract_id(p_contract_id);
      fetch c_yk_old_contract_id into v_yk_wip_contract_id;
      close c_yk_old_contract_id;
      v_yk_wip_contract_id2 := v_yk_wip_contract_id;

      dbms_lob_append(v_log, 'wip_continue_control yk giriyoruz v_yk_wip_contract_id : '||v_yk_wip_contract_id);
      alz_mdlr_hlth_policy_utils4.wip_continue_control(v_yk_wip_contract_id,
                                                       p_action,
                                                       p_simple_questions,
                                                       v_is_continue,
                                                       p_security_info.userid,
                                                       p_process_results);

      dbms_lob_append(v_log, 'wip_continue_control yk bitti p_contract_id : '||v_yk_wip_contract_id);
      dbms_lob_append(v_log, 'wip_continue_control yk bitti v_is_continue : '||v_is_continue);
      dbms_lob_append(v_log, 'wip_continue_control yk bitti p_action.action_code : '||p_action.action_code);

      if alz_web_process_utils.process_result_err (p_process_results) = 1 or v_is_continue = 0 then
         dbms_lob_append(v_log, 'goto end_of_navigate girdik');
         goto end_of_navigate;
      end if;

      if v_yk_wip_contract_id <> v_yk_wip_contract_id2 then --se�ilen ask�dan devam edebilmesi i�in
        --basakk : yerinekaim ruw-45 (ask�devam i�leminde yerine kaim uygunlu�una bakm�yordu buraya da kontrol eklendi)
        v_simple_question_rec := customer.simple_question_rec(499,null,null,1,null);
        p_simple_questions.extend;
        p_simple_questions(p_simple_questions.count) := v_simple_question_rec;

        v_simple_question_rec := customer.simple_question_rec(500,null,null,1,null);
        p_simple_questions.extend;
        p_simple_questions(p_simple_questions.count) := v_simple_question_rec;

        v_simple_question_rec := customer.simple_question_rec(501,null,null,1,null);
        p_simple_questions.extend;
        p_simple_questions(p_simple_questions.count) := v_simple_question_rec;

        v_simple_question_rec := customer.simple_question_rec(508,null,null,1,null);
        p_simple_questions.extend;
        p_simple_questions(p_simple_questions.count) := v_simple_question_rec;

        alz_mdlr_hlth_policy_utils16.reference_contract_validations(p_contract_id, v_yk_wip_contract_id, p_action.action_code, p_security_info.userid, v_is_continue, p_simple_questions, p_process_results); --validasyonlar --ruw-22

        alz_base_function_utils.question_delete(p_simple_questions, 499);
        alz_base_function_utils.question_delete(p_simple_questions, 500);
        alz_base_function_utils.question_delete(p_simple_questions, 501);
        alz_base_function_utils.question_delete(p_simple_questions, 508);

        dbms_lob_append(v_log, 'reference_contract_validations sonras� process_result kontrol edilecek');
        if alz_web_process_utils.process_result_err (p_process_results) = 1 then
          alz_mdlr_hlth_policy_utils16.contract_reject(v_yk_wip_contract_id,
                                                       v_ref_version_no,
                                                       p_security_info.userid,
                                                       v_yk_bildirim,
                                                       v_log,
                                                       p_process_results);

              dbms_lob_append(v_log, 'goto end_of_navigate gidiyoruuzz');
              goto end_of_navigate;
        end if;
        --ruw-45 bitti

        p_contract_id := v_yk_wip_contract_id;
      end if;

   end if;

   if nvl(p_action.action_code, 'X') in ('ASKIVAZGEC','ASKIVAZGECYK') then --basakk : yerinekaim

      dbms_lob_append(v_log, 'ASKIVAZGEC girdi');

      begin

          p_process_results := customer.process_result_table();
          alz_policy_core_utils.complete_confirmed('A',
                                                   p_contract_id,
                                                   p_security_info.userid,
                                                   p_process_results);

      exception when others then
          null;
      end;

   elsif nvl(p_action.action_code, 'X') = 'ASKIKAYDET' then

      dbms_lob_append(v_log, 'ASKIKAYDET girdi');

      alz_policy_core_utils.add_remove_proposal_clause (p_contract_id,
                                                        p_version_no,
                                                        null,
                                                        p_security_info.userid,
                                                        p_process_results);

      alz_policy_core_utils.complete_confirmed('S',
                                               p_contract_id,
                                               p_security_info.userid,
                                               p_process_results);

   elsif nvl(p_action.action_code, 'X') in ('POLICEGORUNTULE', 'HESAPBILGI', 'AYRICALIK') then

      dbms_lob_append(v_log, 'POLICEGORUNTULE HESAPBILGI AYRICALIK');

      alz_mdlr_hlth_policy_utils4.getPolicyDetails(p_contract_id,
                                                   p_version_no,
                                                   v_partition_no,
                                                   p_security_info.userid,
                                                   p_mdlr_hlth_policy,
                                                   p_process_results);

   elsif nvl(p_action.action_code, 'X') in ('HPFGORUNTULE') then

      dbms_lob_append(v_log, 'HPFGORUNTULE');

     /*if nvl(p_action.current_page, 'X') in ('DASHBOARD') then--dilekb

       dbms_lob_append(v_log, 'HPFGORUNTULE-DASHBOARD'||chr(10));
               v_version_no_became := koc_hpf_utils3.get_top_version (p_contract_id);
             getHpfDetails(p_contract_id,
                    v_version_no_became,
                    p_security_info.userid,
                    p_mdlr_hlth_policy,
                    p_process_results);
       else*/
       open c_has_wip(p_contract_id);--dilekb
       fetch c_has_wip into v_has_wip;
       close c_has_wip;

         if v_has_wip is  null  then--dilekb
          w_version_no := p_version_no;
       else

         if  nvl(p_action.button_name,'XYZ') ='goToSelectedPageWip' then

          w_version_no := koc_hpf_utils3.get_top_version (p_contract_id);
           else
              w_version_no := p_version_no;
         end if;

       end if;
          dbms_lob_append(v_log, 'p_action.action_code:'||p_action.action_code|| ' p_action.button_name : '||p_action.button_name||' w_version_no : '||w_version_no);
          getHpfDetails(p_contract_id,
                     w_version_no,--dilekb
                     p_security_info.userid,
                     p_mdlr_hlth_policy,
                     p_process_results);

        alz_mdlr_hlth_policy_utils16.get_hpf_ocq_policy(p_contract_id, p_mdlr_hlth_policy.policy_base); -- basakk :yerinekaim ruw-55

         --end if;--dilekb end
    /*  getHpfDetails(p_contract_id,
                    p_version_no,
                    p_security_info.userid,
                    p_mdlr_hlth_policy,
                    p_process_results);*/

   elsif nvl(p_action.action_code, 'X') in ('ASKIGORUNTULEME', 'DATAYENILE') then

       dbms_lob_append(v_log, 'DATAYENILE');

       ALZ_MDLR_HLTH_POLICY_UTILS.continue_to_proposal(p_contract_id,
                            p_security_info.userid,
                            p_mdlr_hlth_policy,
                            p_process_results);

   --start added by egezer 18.07.2016
   elsif nvl(p_action.action_code, 'X') = 'TEKLIFSIL' then

       dbms_lob_append(v_log, 'TEKLIFSIL girdi');

      delete_quote ( p_contract_id,
                      p_version_no,
                      p_security_info.userid,
                      p_quote_ref,
                      p_simple_questions,
                      p_process_results);

   --finish added by egezer 18.07.2016

   elsif nvl(p_action.action_code, 'X') in ('TEKLIFGORUNTULE') then -- hazala_26072016

     dbms_lob_append(v_log, 'TEKLIFGORUNTULE');

     begin
       open  c_koc_hpf_status(p_contract_id); --basakk : koc_hpf.pro_form_use_status bozuluyordu
       fetch c_koc_hpf_status into v_form_serial_no, v_form_no;
       close c_koc_hpf_status;

       p_process_results := customer.process_result_table();
       alz_policy_core_utils.complete_confirmed('A',
                                                p_contract_id,
                                                p_security_info.userid,
                                                p_process_results);

       update koc_hpf --basakk : koc_hpf.pro_form_use_status bozuluyordu
           set pro_form_use_status = 1
         where contract_id = p_contract_id
           and official_form_serial_no = v_form_serial_no
           and official_form_no = v_form_no;
     exception when others then
       null;
     end;

     open c_max_quote_id (p_contract_id);
       fetch c_max_quote_id into v_max_quote_id, v_quote_reference, v_quote_expiry_date, v_quote_move_code;
     close c_max_quote_id;

     quo_api.fetch_and_progress_nb_quote (v_max_quote_id,
                                          v_quote_move_code,
                                          v_signature_date,
                                          'NO',
                                          'INTERACTIVE',
                                          NULL,
                                          v_invoke_user,
                                          NULL,
                                          p_contract_id,
                                          v_client_route,
                                          v_route_type,
                                          v_result);

       update inf_v_lck_logical_locks_api
          set status = 'S',
              GIOS_USERNAME = p_security_info.userid
        where object_type_code = 'POLICY'
          and object_uid       = to_char(p_contract_id);

       update wip_policy_versions a
          set a.username        = p_security_info.userid,
              a.user_partner_id = v_user_part_id
        where a.contract_id     = p_contract_id;

       update wip_koc_ocp_pol_contracts_ext a
          set a.prev_quote_ref = v_quote_reference
        where a.contract_id    = p_contract_id;

       update wip_koc_ocp_partitions_ext a
          set a.partner_validity_date = null
        where a.contract_id           = p_contract_id;

       update wip_koc_ocp_pol_versions_ext a
          set a.partner_validity_date = null
        where a.contract_id           = p_contract_id;

       ALZ_MDLR_HLTH_POLICY_UTILS.continue_to_proposal(p_contract_id,
                            p_security_info.userid,
                            p_mdlr_hlth_policy,
                            p_process_results);

       p_mdlr_hlth_policy.policy_base.quote_ref := v_quote_reference;
       p_mdlr_hlth_policy.policy_base.quote_id := v_max_quote_id;
       p_mdlr_hlth_policy.policy_base.quote_expiry_date := v_quote_expiry_date;

   else

      dbms_lob_append(v_log, 'ELSE');

      if nvl(p_action.action_code, 'X') = 'OBFISTINADEN' then
         open c_is_renewal_policy(p_contract_id);
         fetch c_is_renewal_policy into v_is_renewal_policy;
         if c_is_renewal_policy%notfound then
            v_is_renewal_policy := 0;
         end if;
         close c_is_renewal_policy;
         if nvl(v_is_renewal_policy, 0) <> 0 then
            alz_web_process_utils.process_result (0,
                                                  9,
                                                  -1,
                                                  'USERROLE_ERR',
                                                  'Girdi�iniz poli�e yenileme poli�esidir. Eski poli�esi �zerinden "Poli�eyi Yenile" se�ene�i ile ask� olu�turabilirsiniz.',
                                                  NULL,
                                                  NULL,
                                                  NULL,
                                                  'alz_mdlr_hlth_policy_utils.navigate_request',
                                                  p_security_info.userid,
                                                  p_process_results);
         end if;
      end if;

      if alz_web_process_utils.process_result_err (p_process_results) <> 1 then
         -- GAKBUL. Poli�eden ask�ya almak i�in.
         if nvl(p_action.action_code, 'X') = 'OBFISTINADEN' then
           open c_ocp_to_wip(p_contract_id);
           fetch c_ocp_to_wip into v_quote_ref;
           close c_ocp_to_wip;
         else
           v_quote_ref := p_quote_ref;
         end if;
         --

         dbms_lob_append(v_log, 'invoke giriyoruz');
         dbms_lob_append(v_log, 'v_signature_date : '||v_signature_date);
         dbms_lob_append(v_log, 'p_contract_id : '||p_contract_id);
         dbms_lob_append(v_log, 'p_policy_ref : '||p_policy_ref);
         dbms_lob_append(v_log, 'v_quote_ref : '||v_quote_ref);
         dbms_lob_append(v_log, 'v_obf_serial_no : '||v_obf_serial_no);
         dbms_lob_append(v_log, 'v_obf_form_no : '||v_obf_form_no);
         dbms_lob_append(v_log, 'p_action.endorsement_code : '||p_action.endorsement_code);
         dbms_lob_append(v_log, 'p_action.endors_reason_code : '||p_action.endors_reason_code);
         dbms_lob_append(v_log, 'p_action.action_code : '||p_action.action_code);

         alz_mdlr_hlth_pme_utils.invoke (p_product_id,
                                         p_partition_type,
                                         p_agent_int_id,
                                         p_sub_agent_int_id,
                                         v_signature_date,
                                         p_contract_id,
                                         0,
                                         p_policy_ref,
                                         v_quote_ref, --p_quote_ref,
                                         null,
                                         v_obf_serial_no,
                                         v_obf_form_no,
                                         p_action.endorsement_code,
                                         p_action.endors_reason_code,
                                         null,
                                         null,
                                         null,
                                         null,
                                         p_contract_id,
                                         v_uw_police,
                                         v_is_continue,
                                         p_security_info.userid,
                                         p_action,
                                         p_simple_questions,
                                         p_process_results);

          dbms_lob_append(v_log, 'invoke bitti p_contract_id : '||p_contract_id);
          dbms_lob_append(v_log, 'p_action.action_code : '||p_action.action_code);
          dbms_lob_append(v_log, 'p_action.endorsement_code : '||p_action.endorsement_code);
          dbms_lob_append(v_log, 'p_action.endors_reason_code : '||p_action.endors_reason_code);

          add_log_process_result(v_log, p_process_results);

         --added by egezer for ANLZ_TPA_103 31.01.2018 start
         --IF alz_tpa_hlth_policy_utils.get_main_partition_type(p_contract_id) = 'TSS' and nvl(p_action.action_code, 'X') = 'ZEYIL' THEN
          IF alz_tpa_hlth_policy_utils.get_main_partition_type(p_contract_id) in ('TSS', 'MD') and nvl(p_action.action_code, 'X') = 'ZEYIL' THEN -- hazala_22032018_mdts_md_icin_eklendi

             dbms_lob_append(v_log, 'Poli�e TSS poli�esi ve gelen i�lem zeyil');

              open  c_ocp_rec(p_contract_id);
              fetch c_ocp_rec into v_ocp_rec;
              close c_ocp_rec;

           dbms_lob_append(v_log, 'navigate request i�indesin v_ocp_rec.payment_type  : '||v_ocp_rec.payment_type);
           dbms_lob_append(v_log, 'navigate request i�indesin v_ocp_rec.installment_card_count  : '||v_ocp_rec.installment_card_count);
           dbms_lob_append(v_log, 'navigate request i�indesin v_ocp_rec.no_of_installments  : '||v_ocp_rec.no_of_installments);
           dbms_lob_append(v_log, 'navigate request i�indesin v_ocp_rec.has_advance_payment  : '||v_ocp_rec.has_advance_payment);

             update wip_koc_ocp_pol_versions_ext
                set payment_type  =v_ocp_rec.payment_type,
                    installment_card_count = v_ocp_rec.installment_card_count,
                    no_of_installments = v_ocp_rec.no_of_installments,
                    has_advance_payment = v_ocp_rec.has_advance_payment
              where contract_id = p_contract_id ;

          END IF;
          --added by egezer for ANLZ_TPA_103 31.01.2018 finish


          dbms_lob_append(v_log, 'p_product_id : '||p_product_id); --basakk : gorky
          dbms_lob_append(v_log, 'p_partition_type : '||p_partition_type); --basakk : gorky

          v_cmp := NULL;
          Begin
           Select company_code into v_cmp --AliSakalli log
             from wip_koc_ocp_pol_contracts_ext
            where contract_id = p_contract_id;
          exception when others then
            v_cmp := NULL;
          End;
          --dbms_output.put_line ('wip_koc_ocp_pol_contracts_ext-company_code �nce : ' || v_cmp);
          dbms_lob_append(v_log, 'wip_koc_ocp_pol_contracts_ext-company_code �nce : ' || v_cmp);

          if nvl(p_action.action_code, 'X') not in ('ASKIDEVAM') then --basakk : gorky
              open  c_company_code;
              fetch c_company_code into v_company_code;
              close c_company_code;

              dbms_lob_append(v_log, 'v_company_code : '||v_company_code); --basakk : gorky

              update wip_koc_ocp_pol_contracts_ext a --basakk : gorky company_code set etmek i�in
                set a.company_code   = v_company_code
              where a.contract_id    = p_contract_id;

              dbms_lob_append(v_log, 'company_code update edildi : '||v_company_code); --AliSakalli log
          end if;

          v_cmp := NULL;
          Begin
           Select company_code into v_cmp --AliSakalli log
             from wip_koc_ocp_pol_contracts_ext
            where contract_id = p_contract_id;
          exception when others then
            v_cmp := NULL;
          End;
          --dbms_output.put_line ('wip_koc_ocp_pol_contracts_ext-company_code sonra : ' || v_cmp);
          dbms_lob_append(v_log, 'wip_koc_ocp_pol_contracts_ext-company_code sonra : ' || v_cmp);

          v_partition_class := nvl(alz_mdlr_hlth_policy_utils13.get_partition_class (p_contract_id), 'X');
          dbms_lob_append(v_log, 'v_partition_class : '||v_partition_class);
          if v_partition_class = 'MNOR' then
            dbms_lob_append(v_log, 'v_partition_class = MNOR : ');
            open  c_is_renewal(p_contract_id);
            fetch c_is_renewal into v_is_renewal;
            close c_is_renewal;
            if nvl(v_is_renewal,0) = 0 then --basakk : yenilemelerde update etmemeli, sadece yeni i�lerde �al��mal�
                begin
                  update wip_koc_ocp_health
                     set transfer_type = 0
                   where contract_id   = p_contract_id;
                exception when others then
                  null;
                end;
            end if;
          end if;

          begin
          select transfer_type
            into v_trans_type
            from wip_koc_ocp_health
           where contract_id  = p_contract_id
             and partition_no = 1;
            exception when others then
              v_trans_type := 1;
            end;
          dbms_lob_append(v_log, 'v_trans_type : '||v_trans_type);

         --iertekin ask�y� d�k�man y�kledi�inde olu�ucak.. y�klemeden �nce siliyoruz. y�kledi�inde ekrandan action_code ZEYILACENTE gelicek..
         --if alz_web_process_utils.process_result_err(p_process_results) = 1 then
            --v_is_continue := 0;
         --else

         open c_move_code(p_contract_id);
         fetch c_move_code into v_move_code;
         close c_move_code;


            if (p_action.endorsement_code = 1 and p_action.endors_reason_code = 'SGCK')
               or (p_action.endorsement_code  in (2, 14, 11) and v_move_code <> 'REGRQ')then --gulumserg meriyet move_code kontrol� eklendi
               if nvl(p_action.action_code, 'X') = 'ZEYIL' and nvl(v_action_code, 'X') <> 'ZEYILACENTE' and v_user_role in ('SAGENT', 'SBGD', 'SEL', 'SBY', 'SFMT', 'SDIGI') then
                  dbms_lob_append(v_log, 'complete_confirmed giriyoruz');
                  alz_policy_core_utils.complete_confirmed('A',
                                                           p_contract_id,
                                                           p_security_info.userid,
                                                           v_process_results);

                  v_is_continue := 0;
               end if;
            end if;
         --end if;

         dbms_lob_append(v_log, 'v_is_continue : '||v_is_continue);
         if /*alz_web_process_utils.process_result_err(p_process_results) = 1 or*/ nvl(v_is_continue, 1) = 0 then
            goto end_of_navigate;
         end if;

         if nvl(p_action.action_code, 'X') in ('DEMO') then

            --iertekin BGD ise ask� banka partaj� ile olu�sun istendi..
            if web_mdlr_hlth_search_utils.is_salesperson(p_security_info.userid) is not null then
               v_reference_code := '10503';
               open c_agent_int_id(v_reference_code, v_signature_date);
               fetch c_agent_int_id into v_agent_int_id;
               close c_agent_int_id;
            else
               v_agent_int_id := p_agent_int_id;
            end if;

            open c_region_code(v_agent_int_id, v_signature_date);
            fetch c_region_code into v_region_code;
            close c_region_code;

            update wip_policy_bases
               set agent_role = v_agent_int_id
             where contract_id = p_contract_id;

            update wip_koc_ocp_pol_versions_ext
               set sub_agent = decode(p_sub_agent_int_id, 0, null, p_sub_agent_int_id),
                   region_code = v_region_code
             where contract_id = p_contract_id;
         end if;
         /* AliSakalli TPA i�in sigorta ettiren de�i�ikli�i zeyilinde otomatik yenileme bo� gelsin */
         if nvl(p_action.action_code, 'X') = 'ZEYIL' and p_action.endorsement_code = 1 and p_action.endors_reason_code = 'SGET' then
           update wip_koc_ocp_pol_contracts_ext
              set will_renewal = null
            where contract_id = p_contract_id
              and company_code <> '045';
         end if;

         if nvl(p_action.action_code, 'X') = 'ZEYIL' then

            dbms_lob_append(v_log, 'v_base_agent_int_id : '||v_base_agent_int_id);

            OPEN c_ocp_bases(p_contract_id);
            FETCH c_ocp_bases INTO v_base_region_code;
            CLOSE c_ocp_bases;

            agency_transfer(p_contract_id,
                            v_base_agent_int_id,
                            v_base_agency_code,
                            v_base_agent_name,
                            v_base_region_code,
                            v_base_agent_name);

            v_agent_role := 0;
            OPEN c_agent_role(p_contract_id);
            FETCH c_agent_role INTO v_agent_role;
            CLOSE c_agent_role;
            dbms_lob_append(v_log, 'v_agent_role : '||v_agent_role);
            dbms_lob_append(v_log, 'v_base_agent_int_id : '||v_base_agent_int_id);
            dbms_lob_append(v_log, 'v_base_agency_code : '||v_base_agency_code);

            sub_agency_transfer(p_contract_id,
                                v_base_agent_int_id,
                                v_base_agency_code,
                                v_base_agent_name,
                                v_base_region_code,
                                v_base_agent_name,
                                v_base_sub_agent_int_id,
                                v_base_sub_agent_code,
                                v_base_sub_agent_name);

      /*ITIY-18524*/
            OPEN c_exist_red_record(p_contract_id);
            FETCH c_exist_red_record INTO v_exist_red_record;
            CLOSE c_exist_red_record;
            if v_exist_red_record > 0 then
                update wip_koc_ocp_pol_contracts_ext
                set hlth_quote_status = null,
                      hlth_quote_status_exp = null,
                    quote_status_date = null,
                    quote_status_user = null
                where contract_id = p_contract_id;
            end if;

            v_agent_role := 0;
            OPEN c_agent_role(p_contract_id);
            FETCH c_agent_role INTO v_agent_role;
            CLOSE c_agent_role;
            dbms_lob_append(v_log, 'v_agent_role : '||v_agent_role);
            dbms_lob_append(v_log, 'v_base_agent_int_id : '||v_base_agent_int_id);
            dbms_lob_append(v_log, 'v_base_agency_code : '||v_base_agency_code);
            dbms_lob_append(v_log, 'v_base_sub_agent_int_id : '||v_base_sub_agent_int_id);
            dbms_lob_append(v_log, 'v_base_sub_agent_code : '||v_base_sub_agent_code);

         END IF;

         v_agent_role := 0;
         OPEN c_agent_role(p_contract_id);
         FETCH c_agent_role INTO v_agent_role;
         CLOSE c_agent_role;
         dbms_lob_append(v_log, 'v_agent_role : '||v_agent_role);
         if nvl(p_action.action_code, 'X') in ('ASKIDEVAM', 'HPFDEVAM') then

            open c_has_hpf(p_contract_id, v_version_no_became);
            fetch c_has_hpf into v_has_hpf;
            if c_has_hpf%notfound then
               v_has_hpf := 0;
            end if;
            close c_has_hpf;

            if v_move_code in ('WHNBQ2') or (v_move_code in ('WHBEXR', 'WHIEXR','HIEXR') and nvl(v_has_hpf, 0) = 1) then
               p_action.target_page := 'BASVURU';
            end if;

            open c_has_auth(p_contract_id, v_version_no_became);
            fetch c_has_auth into v_has_auth;
            if c_has_auth%found then
               p_action.action_code := 'HPFDEVAM';
               p_action.target_page := 'OTORIZASYON';
            end if;
            close c_has_auth;

            OPEN c_get_endors_reason;
            FETCH c_get_endors_reason INTO v_endors_reason;
            CLOSE c_get_endors_reason;

            IF NVL(p_action.target_page,'X') = 'OTORIZASYON' and v_user_role = 'SFOPER' then
              if v_endors_reason is null or v_endors_reason = 'SGIR' then
                alz_mdlr_hlth_policy_utils13.part_cancelled_policy (p_contract_id,
                                                                    p_action,
                                                                    p_security_info.userid,
                                                                    p_process_results);
              end if;
            END IF;

            open c_has_modul(p_contract_id);
            fetch c_has_modul into v_has_modul;
            close c_has_modul;
            if nvl(v_has_modul, 0) = 0 then
               --dashboard'dan ask� devam ile geldi�inde p_partition_type herzaman MDSG geliyor.. o y�zden tekrar al�yoruz.. iertekin
               if v_partition_class = 'MDLR' then
                  p_action.action_code := 'ASKIDEVAM';
                  p_action.target_page := 'KAPSAM';
               end if;
            end if;

         end if;

         v_agent_role := 0;
         OPEN c_agent_role(p_contract_id);
         FETCH c_agent_role INTO v_agent_role;
         CLOSE c_agent_role;
         dbms_lob_append(v_log, 'v_agent_role : '||v_agent_role);
         dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.agent_int_id : '||p_mdlr_hlth_policy.policy_base.agent_int_id);
         dbms_lob_append(v_log, 'continue_to_proposal giriyoruz p_action.action_code : '||p_action.action_code);

         --added by egezer for TPA project 14.12.2017 start

           open c_company_code;
          fetch c_company_code into v_company_code;
          close c_company_code;

          dbms_lob_append(v_log, '�r�n �zerindeki v_company_code degeri = '||v_company_code);

          v_cmp := NULL; --AliSakalli log
          Begin
            Select company_code into v_cmp
              from wip_koc_ocp_pol_contracts_ext
             where contract_id = p_contract_id;
          exception when others then
            v_cmp := NULL;
          End;
          --dbms_output.put_line ('wip_koc_ocp_pol_contracts_ext �zerindeki company_code : ' || v_cmp);
          dbms_lob_append(v_log, 'wip_koc_ocp_pol_contracts_ext �zerindeki company_code : ' || v_cmp);

          v_partition_type := alz_mdlr_hlth_policy_utils13.get_partition_type(p_contract_id);

          dbms_lob_append(v_log, 'v_partition_type degeri = '||v_partition_type);

          v_versions_payment_type := null;

         IF v_company_code = '045' and v_partition_type = 'TSS' and nvl(p_action.action_code, 'X') = 'ZEYIL' THEN

           dbms_lob_append(v_log, 'wip_koc_ocp_pol_versions_ext g�ncellemesi yap�lacak');

           v_versions_payment_type := null;

           dbms_lob_append(v_log, 'v_versions_payment_type degeri = '||v_versions_payment_type);

          /* IF (p_mdlr_hlth_policy.Policy_Base.contract_id is null) THEN

              dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base initialize edilecek');

              p_mdlr_hlth_policy.policy_base := customer.mdlr_hlth_policy_base_rec( null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,null,null,null,null,
                                                                                    null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,null,null,null,null,
                                                                                    null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,null,null,null,null,
                                                                                    null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,null,null,null,null,
                                                                                    null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,null,null,null,null,
                                                                                    null, null, null, null, null, null, null, null);

           END IF;*/

           open c_wip_payment_type(p_contract_id);
           fetch c_wip_payment_type into v_wip_payment_type, v_zeyil;

             if c_wip_payment_type%notfound then
                dbms_lob_append(v_log, 'DIKKAT !. wip_koc_ocp_pol_versions_ext tablosunda kay�t yok. ocp_policy_bases tablosu kontrol edilecek. ');

                 open c_ocp_count(p_contract_id);
                fetch c_ocp_count into v_ocp_count;
                close c_ocp_count;

                IF v_ocp_count > 0 THEN
                   v_zeyil := 1;
                  dbms_lob_append(v_log, ' v_zeyil de�eri 1 olarak set edildi.');
                END IF;

             end if;
           close c_wip_payment_type;

         --mevcut poli�e k�sm�
          IF NVL(v_zeyil, 0) > 0 THEN

            dbms_lob_append(v_log, 'Mevcut poli�e i�in i�lem yap�lacak');

            open c_odeme_varmi(p_contract_id);
           fetch c_odeme_varmi into v_paid_total;
               if c_odeme_varmi%notfound then
                 dbms_lob_append(v_log, 'Mevcut poli�e �deme varm� sorgusunda kay�t yok.�deme de�eri 0 olarak set edilecek.');
                 v_paid_total := 0;
               end if;
           close c_odeme_varmi;

           dbms_lob_append(v_log, 'Mevcut poli�e i�in v_paid_total de�eri = '||v_paid_total);

           IF nvl(v_paid_total,0) > 0 THEN
           dbms_lob_append(v_log, 'Mevcut poli�e �deme var.');

            IF NVL(v_wip_payment_type,'0') = '3' THEN   --???  ocp liden bakmas� gerekmezmi
            dbms_lob_append(v_log, 'Mevcut poli�e payment_type bilgisi KKB.Tablo g�ncellenecek');

              v_versions_payment_type := '3';

             /*update wip_koc_ocp_pol_versions_ext
                set payment_type = '3'
              where contract_id = p_contract_id;*/

             /* BEGIN
              p_mdlr_hlth_policy.Policy_Base.paymenttype := 3;
              EXCEPTION WHEN OTHERS THEN
               dbms_lob_append(v_log, '1 Mevcut poli�e. Tip de�eri g�ncellenirken hata olu�tu.' ||SQLERRM);
              END;

              --dbms_lob_append(v_log, 'Mevcut poli�e tip KKB olarak g�ncellenecek. G�ncellenecek de�er = '||p_mdlr_hlth_policy.Policy_Base.paymenttype);*/

              dbms_lob_append(v_log, 'Mevcut poli�e. Tablo KKB olarak g�ncellenecek G�ncellenecek de�er = '||v_versions_payment_type);

            ELSE

              --mevcut ask� i�in kredi kart� ile yap�lm�� �deme var m� (cursor KOCREPOCP830 adl� fmb odeme_bilgisi_dondur program biriminden al�nd�)
               open c_kk_odeme_varmi(p_contract_id);
              fetch c_kk_odeme_varmi into v_kk_odeme_count;
                 if c_kk_odeme_varmi%notfound then
                      v_kk_odeme_count := 0;
                end if;
             close c_kk_odeme_varmi;

              dbms_lob_append(v_log, 'Mevcut bir poli�e i�in v_kk_odeme_varmi = '||v_kk_odeme_count);

             IF v_kk_odeme_count > 0 THEN

              dbms_lob_append(v_log, 'Mevcut bir poli�e i�in KK �deme var. tablo KK olarak g�ncellenecek.');

              v_versions_payment_type := '2';

              /* update wip_koc_ocp_pol_versions_ext
                  set payment_type = '2'
                where contract_id = p_contract_id;*/

             /* BEGIN
              p_mdlr_hlth_policy.Policy_Base.paymenttype := 2;
              EXCEPTION WHEN OTHERS THEN
               dbms_lob_append(v_log, '2 Mevcut poli�e. Tip de�eri g�ncellenirken hata olu�tu.' ||SQLERRM);
              END;

              dbms_lob_append(v_log, 'Mevcut poli�e tip  KK olarak g�ncellenecek. Tip de�eri = '||p_mdlr_hlth_policy.Policy_Base.paymenttype);*/

              dbms_lob_append(v_log, 'Mevcut poli�e. Tablo KK olarak g�ncellenecek G�ncellenecek de�er = '||v_versions_payment_type);

             ELSE

              dbms_lob_append(v_log, 'Mevcut bir poli�e i�in �deme var.Ama kk l� �deme yok. tablo havl olarak g�ncellenecek.');

              v_versions_payment_type := '1';

              /*update wip_koc_ocp_pol_versions_ext
                  set payment_type = '1'
                where contract_id = p_contract_id;*/

             /* BEGIN
              p_mdlr_hlth_policy.Policy_Base.paymenttype := 1;
              EXCEPTION WHEN OTHERS THEN
               dbms_lob_append(v_log, '3 Mevcut poli�e. Tip de�eri g�ncellenirken hata olu�tu.' ||SQLERRM);
              END;

              dbms_lob_append(v_log, 'Mevcut poli�e tip HAVL olarak g�ncellenecek. Tip de�eri = '||p_mdlr_hlth_policy.Policy_Base.paymenttype);*/

              dbms_lob_append(v_log, 'Mevcut poli�e. Tablo HAVL olarak g�ncellenecek G�ncellenecek de�er = '||v_versions_payment_type);

             END IF;

            END IF;

            -- �deme yok k�sm�
           ELSE
           dbms_lob_append(v_log, 'Mevcut poli�e i�in �deme yok.koc_ocp_pol_versions_ext tablosunda payment_type kontrol� yap�lacak.');

             open c_wip_payment_type (p_contract_id); --??? versiyonlam� kontro letmeli,
            fetch c_wip_payment_type into v_wip_payment_type,v_zeyil;
            close c_wip_payment_type;

             dbms_lob_append(v_log, 'Mevcut poli�e i�in �deme yok.v_ocp_payment_type='||v_wip_payment_type);

            IF v_wip_payment_type is not null THEN

               v_versions_payment_type := v_wip_payment_type;

              /* update wip_koc_ocp_pol_versions_ext
                  set payment_type = v_wip_payment_type
                where contract_id = p_contract_id;*/

             /* BEGIN

              p_mdlr_hlth_policy.Policy_Base.paymenttype := to_number(v_wip_payment_type);

              EXCEPTION WHEN OTHERS THEN
               dbms_lob_append(v_log, '4 Mevcut poli�e. Tip de�eri g�ncellenirken hata olu�tu.' ||SQLERRM);
              END;

             dbms_lob_append(v_log, 'Mevcut poli�e. wip_Koc_ocp deki payment_type ile tip g�ncellenecek. Tip de�eri = '||p_mdlr_hlth_policy.Policy_Base.paymenttype); */

             dbms_lob_append(v_log, 'Mevcut poli�e. wip_koc_ocp deki payment_type ile g�ncellenecek. G�ncellenecek de�er = '||v_versions_payment_type);

            ELSE

             dbms_lob_append(v_log, 'Mevcut poli�e i�in �deme yok.v_ocp_payment_type de�eri bo�');

              open c_cc_exists(p_contract_id);
             fetch c_cc_exists into v_cc_exists;

             IF c_cc_exists%notfound THEN

              v_versions_payment_type := '1';

               /*update wip_koc_ocp_pol_versions_ext
                  set payment_type = '1'
                where contract_id = p_contract_id;*/

             /* BEGIN
                p_mdlr_hlth_policy.Policy_Base.paymenttype := 1;
              EXCEPTION WHEN OTHERS THEN
               dbms_lob_append(v_log, '5 Mevcut poli�e. Tip de�eri g�ncellenirken hata olu�tu.' ||SQLERRM);
              END;

               dbms_lob_append(v_log, 'Mevcut poli�e i�in �deme yok.Kredi kart� kayd� YOK. Payment type de�eri HAVALE olarak g�ncellendi.Tip de�eri = '||p_mdlr_hlth_policy.Policy_Base.paymenttype);*/

                dbms_lob_append(v_log, 'Mevcut poli�e i�in �deme yok.Kredi kart� kayd� yok. Payment type de�eri HAVALE olarak g�ncellenecek. G�ncellenecek de�er = '||v_versions_payment_type);

             ELSE

                v_versions_payment_type := '2';

               /* update wip_koc_ocp_pol_versions_ext
                  set payment_type = '2'
                where contract_id = p_contract_id; */

             /* BEGIN
                p_mdlr_hlth_policy.Policy_Base.paymenttype := 2;
              EXCEPTION WHEN OTHERS THEN
               dbms_lob_append(v_log, '6 Mevcut poli�e. Tip de�eri g�ncellenirken hata olu�tu.' ||SQLERRM);
              END;

                dbms_lob_append(v_log, 'Mevcut poli�e i�in �deme yok.Kredi kart� VAR. Payment type de�eri KRED� KARTI olarak g�ncellendi.Tip de�eri = '||p_mdlr_hlth_policy.Policy_Base.paymenttype);*/

                 dbms_lob_append(v_log, 'Mevcut poli�e i�in �deme yok.Kredi kart� kayd� var. Payment type de�eri KRED� KARTI olarak g�ncellenecek. G�ncellenecek de�er = '||v_versions_payment_type);

             END IF;
             close c_cc_exists;

            END IF;

           END IF;

           dbms_lob_append(v_log, 'wip_koc_ocp_pol_versions_extg�ncellenecek. G�ncellenecek de�er = '||v_versions_payment_type);

           update wip_koc_ocp_pol_versions_ext
              set payment_type=v_versions_payment_type
            where contract_id=p_contract_id;

          END IF;

          dbms_lob_append(v_log, 'wip_koc_ocp_pol_versions_ext g�ncellemesi bitti.');

         END IF;

       --added by egezer for TPA project 14.12.2017 finish

         ALZ_MDLR_HLTH_POLICY_UTILS.continue_to_proposal(p_contract_id,
                              p_security_info.userid,
                              p_mdlr_hlth_policy,
                              p_process_results);

         dbms_lob_append(v_log, 'continue_to_proposal bitti');
         v_agent_role := 0;
         OPEN c_agent_role(p_contract_id);
         FETCH c_agent_role INTO v_agent_role;
         CLOSE c_agent_role;
         dbms_lob_append(v_log, 'v_agent_role : '||v_agent_role);
         dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.region_code : '||p_mdlr_hlth_policy.policy_base.region_code);
         dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.agent_int_id : '||p_mdlr_hlth_policy.policy_base.agent_int_id);

         if alz_web_process_utils.process_result_err(p_process_results) = 1 then
            goto end_of_navigate;
         end if;

         if nvl(p_action.action_code, 'X') in ('ASKIDEVAM', 'HPFDEVAM') then

            main_validations(p_mdlr_hlth_policy,
                             v_user_type,
                             v_user_agent_id,
                             p_action,
                             p_security_info,
                             p_simple_questions,
                             p_process_results);

            if alz_web_process_utils.process_result_err(p_process_results) <> 1 then

               main_updates(p_mdlr_hlth_policy,
                            --1,
                            v_user_type,
                            v_user_agent_id,
                            p_action,
                            p_security_info,
                            p_simple_questions,
                            p_process_results);

            end if;

         end if;

         --iertekin iptal ve ��k�� zeyillerinde FZ'li, giri�lerde de FO'lu bir kay�t yaratmak i�in a�a��daki i�lemleri yap�yoruz. di�er zeyillerde ekrandan al�yor
         if p_mdlr_hlth_policy.policy_base.endorsement_no in (1, 2, 11, 14)
            and (nvl(p_mdlr_hlth_policy.hpf.official_form_no, 0) = 0 or nvl(p_mdlr_hlth_policy.hpf.pro_form_use_status, 0) in (0, 2)
                or (p_mdlr_hlth_policy.policy_base.endorsement_no in (11) and alz_mdlr_hlth_pme_utils.check_policy_amendment(p_mdlr_hlth_policy.policy_base.contract_id) = 1
                and nvl(p_action.action_code, 'X') in ('ZEYIL', 'ZEYILACENTE')) ) then

            open c_payment_type(p_mdlr_hlth_policy.policy_base.contract_id);
            fetch c_payment_type into v_payment_type;
            close c_payment_type;

            if v_payment_type is null then
               open c_payment_type_pol(p_mdlr_hlth_policy.policy_base.contract_id);
               fetch c_payment_type_pol into v_payment_type;
               close c_payment_type_pol;
            end if;

            if (p_mdlr_hlth_policy.policy_base.endorsement_no in (2, 11, 14) or
               (p_mdlr_hlth_policy.policy_base.endorsement_no = 1 and p_mdlr_hlth_policy.policy_base.endors_reason_code not in ('SGIR')  /*in ('SGCK', 'SGBD'*/)) then
               v_official_form_serial_no := 'FZ';
            else
               v_official_form_serial_no := 'FO';
            end if;

            --HMP-45 istek, meriyet zeyilinde FO alinacak.
            if (p_mdlr_hlth_policy.policy_base.endorsement_no in (11) and alz_mdlr_hlth_pme_utils.check_policy_amendment(p_mdlr_hlth_policy.policy_base.contract_id) = 1) then
               -- v_official_form_serial_no := 'FO';

                UPDATE   wip_koc_ocp_partitions_ext
                   SET   partner_validity_date = NULL
                 WHERE   contract_id = p_contract_id;

                for c1 in c_insured_partner_id
                LOOP
                    UPDATE   koc_cp_partners_ext
                       SET   height = NULL, weight = NULL
                     WHERE   part_id = c1.partner_id;
                END LOOP;


            end if;

            p_mdlr_hlth_policy.hpf := customer.mdlr_hlth_hpf_rec(v_official_form_serial_no, null, null, null, null, null, null, null, p_mdlr_hlth_policy.policy_base.business_start_date, null, null, null, null, null, null, null,
                                                                 v_payment_type, null, null, null, null, null, null, null, null, null, null, null, null, null,
                                                                 null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null,
                                                                 null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);


            alz_mdlr_hlth_policy_utils2.policy_hlth_form_validation (p_mdlr_hlth_policy,
                                                                     p_security_info.userid,
                                                                     p_process_results);


            if alz_web_process_utils.process_result_err(p_process_results) <> 1 then
                if not (p_mdlr_hlth_policy.policy_base.endorsement_no in (11) and alz_mdlr_hlth_pme_utils.check_policy_amendment(p_mdlr_hlth_policy.policy_base.contract_id) = 1) then
                   alz_mdlr_hlth_policy_utils2.policy_hlth_form_create (p_mdlr_hlth_policy,
                                                                        p_security_info.userid,
                                                                        p_process_results);
                end if;
            end if;

         end if;

         alz_mdlr_hlth_hpf_utils.get_hpf_main(p_mdlr_hlth_policy,
                                              p_mdlr_hlth_policy.policy_base.version_no,
                                              p_security_info.userid,
                                              p_process_results);

         --p_mdlr_hlth_policy.hpf := v_koc_hpf_rec;
         --iertekin iptal ve ��k�� zeyillerinde FZ'li bir kay�t yaratmak i�in a�a��daki i�lemleri yap�yoruz. di�er zeyillerde ekrandan al�yor

         alz_mdlr_hlth_policy_utils1.get_declaration_ans(p_mdlr_hlth_policy,
                                                         p_security_info.userid,
                                                         p_process_results);

         if p_action.action_code in ('ASKIDEVAM', 'YENILEME') then
            alz_mdlr_hlth_policy_utils2.policy_hlth_ren_age_validation(p_policy_ref,
                                                                       p_contract_id,
                                                                       p_action,
                                                                       p_simple_questions,
                                                                       v_is_continue,
                                                                       p_security_info.userid,
                                                                       p_process_results);
         end if;

         dbms_lob_append(v_log, 'p_action.endorsement_code : '||p_action.endorsement_code);
         dbms_lob_append(v_log, 'p_action.endors_reason_code : '||p_action.endors_reason_code);
         dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.endorsement_no : '||p_mdlr_hlth_policy.policy_base.endorsement_no);
         dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.endors_reason_code : '||p_mdlr_hlth_policy.policy_base.endors_reason_code);

         --iertekin 11se tabloya yazm�yordu o y�zden ikisi de nulllan�yordu. kapatt�m..
         if nvl(p_action.endorsement_code, 0) <> 11 then
            p_action.endorsement_code := p_mdlr_hlth_policy.policy_base.endorsement_no;
            p_action.endors_reason_code := p_mdlr_hlth_policy.policy_base.endors_reason_code;
         end if;

         if nvl(p_mdlr_hlth_policy.policy_base.version_no, 0) > 0 then
            if nvl(p_action.action_code, 'X') in ('ASKIDEVAM') then
               p_action.action_code := 'ZEYIL';
            elsif nvl(p_action.action_code, 'X') in ('HPFDEVAM') or v_action_code = 'ZEYILACENTE' then
               p_action.action_code := 'ZEYILHPFDEVAM';
            end if;
         else
            if nvl(p_action.action_code, 'X') in ('ASKIDEVAM' , 'TEKLIFDEVAM' , 'BASVURU') then --duygu teklifdevam eklendi
               if p_mdlr_hlth_policy.policy_base.is_renewal = 1 then --iuyar - dbayraktar
                 -- nvl(p_mdlr_hlth_policy.risk_subjects(1).risk_subject_base.old_contract_id, 0) <> 0
                 -- or nvl(p_mdlr_hlth_policy.risk_subjects(1).risk_subject_base.as400_policy_no, '0') <> '0' then
                  if p_mdlr_hlth_policy.policy_base.reference_policy_ref is not null then --basakk : yerinekaim
                     p_action.action_code := 'YERINEKAIM';
                  else
                     p_action.action_code := 'YENILEME';
                  end if;
               end if;
            elsif nvl(p_action.action_code, 'X') in ('HPFDEVAM') then
               if p_mdlr_hlth_policy.policy_base.is_renewal = 1 then --iuyar - dbayraktar
                  if p_mdlr_hlth_policy.policy_base.reference_policy_ref is not null then --basakk : yerinekaim
                     p_action.action_code := 'YERINEKAIMHPFDEVAM';
                  else
                     p_action.action_code := 'YENILEMEHPFDEVAM';
                  end if;
               end if;
            end if;
         end if;

         if nvl(v_user_role, 'X') in ('SEL') then
            v_except_unauthorized_agent := koc_hlth_auth_utils.f_except_unauthorized_agent (p_mdlr_hlth_policy.policy_base.contract_id, v_version_no_became);
            if nvl(v_except_unauthorized_agent, 0) = 0 then
               if nvl(p_action.action_code, 'X') in ('HPFDEVAM') then
                  p_action.action_code := 'SELOTZ';
               elsif nvl(p_action.action_code, 'X') in ('YENILEMEHPFDEVAM') then
                  p_action.action_code := 'YENILEMESELOTZ';
               end if;
            end if;
         end if;

         dbms_lob_append(v_log, 'p_action.action_code : '||p_action.action_code);
         dbms_lob_append(v_log, 'p_action.endorsement_code : '||p_action.endorsement_code);
         dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.endorsement_no : '||p_mdlr_hlth_policy.policy_base.endorsement_no);
         dbms_lob_append(v_log, 'v_move_code : '||v_move_code);

         --iertekin onur ekranda pop-up a�aa�� i�in REGRQ ile REGRP'yi ay�rmam�z gerekti bu kodu ekledik
         if nvl(p_action.action_code, 'X') in ('ZEYIL', 'ZEYILHPFDEVAM') and nvl(p_action.endorsement_code, 0) = 11 and v_move_code = 'REGRP' then
            p_action.target_page := 'GERIALMA';
         end if;

         if p_action.action_code = 'BASVURU' then
            p_mdlr_hlth_policy.policy_base.quote_ref := p_quote_ref;
            p_mdlr_hlth_policy.policy_base.quote_id := v_quote_id;
         end if;

         open curaction(p_action.action_code,
                        p_product_id,
                        p_partition_type,
                        p_action.endorsement_code);
         fetch curaction into recaction;
         close curaction;

         begin
            p_action.action_name := recaction.action_explanation;
         exception when others then
            null;
         end;

         open c_endorse_explanation(p_product_id,
                                    p_partition_type,
                                    p_action.endorsement_code,
                                    p_action.endors_reason_code);
         fetch c_endorse_explanation into p_action.endorsement_code_exp, p_action.endors_reason_code_exp;
         close c_endorse_explanation;
         --gulumserg
         if nvl(p_action.action_code, 'X') in ('ZEYIL', 'ZEYILHPFDEVAM') and nvl(p_action.endorsement_code, 0) = 11 and v_move_code = 'REGRQ' then
            p_action.endorsement_code_exp   := 'MERIYET';
            p_action.endors_reason_code_exp := null;
         end if;

      end if;

   end if;

   v_cmp := NULL; --AliSakalli log
   Begin
    Select company_code into v_cmp
      from wip_koc_ocp_pol_contracts_ext
     where contract_id = p_contract_id;
   exception when others then
     v_cmp := NULL;
   End;
   --dbms_output.put_line ('wip_koc_ocp_pol_contracts_ext �zerindeki company_code navigate_request sonu: ' || v_cmp);
   dbms_lob_append(v_log, 'wip_koc_ocp_pol_contracts_ext �zerindeki company_code navigate_request sonu: ' || v_cmp);

   <<end_of_navigate>>
   null;

   if alz_base_function_utils.all_question_responded (p_simple_questions) = 1 then
      p_simple_questions.delete;
   end if;

   begin
       alz_web_process_utils.security_info_log_insert (p_contract_id,
                                                       null,
                                                       'END',
                                                       p_security_info,
                                                       p_action);
   exception when others then
       null;
   end;

   add_log_process_result(v_log, p_process_results);

   dbms_lob_append(v_log, 'p_mdlr_hlth_policy.policy_base.agent_int_id2 : '||p_mdlr_hlth_policy.policy_base.agent_int_id);

   dbms_lob_append(v_log, 'p_policy_ref : '||p_policy_ref||' p_contract_id : '||p_contract_id||' p_quote_ref : '||p_quote_ref||' p_version_no : '||p_version_no);
   dbms_lob_append(v_log, 'p_product_id : '||p_product_id||' p_partition_type : '||p_partition_type||' p_term_end_date : '||p_term_end_date||' p_agent_int_id : '||p_agent_int_id);
   dbms_lob_append(v_log, 'p_sub_agent_int_id : '||p_sub_agent_int_id||' p_action.action_code : '||p_action.action_code||' p_action.current_page : '||p_action.current_page);
   dbms_lob_append(v_log, 'p_action.button_name : '||p_action.button_name||' p_action.endorsement_code : '||p_action.endorsement_code||' p_action.endors_reason_code : '||p_action.endors_reason_code);
   dbms_lob_append(v_log, 'p_action.target_page : '||p_action.target_page||'p_security_info.userid : '||p_security_info.userid||' p_security_info.agency_code : '||p_security_info.agency_code);

   open c_write_log;
   fetch c_write_log into v_write_log;
   close c_write_log;

   if nvl(v_write_log, '0') = '1' then
      n_performance := DBMS_UTILITY.GET_TIME - n_performance;
      alz_mdlr_hlth_policy_utils7.p_insert_mdlr_log(nvl(p_mdlr_hlth_policy.policy_base.contract_id, p_contract_id), null, v_log, 'NAVIGATE_REQUEST', p_action.action_code, p_action.current_page||'-'||p_action.button_name, to_char(n_performance, 'FM9999999999,00'), 1);
      IF (DBMS_LOB.ISTEMPORARY (v_log) = 1) THEN
          DBMS_LOB.FREETEMPORARY (v_log);
      end if;
   end if;

exception when others then

   dbms_lob_append(v_log, substr(sqlerrm || '--' || dbms_utility.format_error_backtrace, 1, 1000));
   n_performance := DBMS_UTILITY.GET_TIME - n_performance;
   alz_mdlr_hlth_policy_utils7.p_insert_mdlr_log(nvl(p_mdlr_hlth_policy.policy_base.contract_id, p_contract_id), null, v_log, 'NAVIGATE_REQUEST', p_action.action_code, p_action.current_page||'-'||p_action.button_name, to_char(n_performance, 'FM9999999999,00'), -1);
   IF (DBMS_LOB.ISTEMPORARY (v_log) = 1) THEN
       DBMS_LOB.FREETEMPORARY (v_log);
   end if;

   if p_action.action_code <> 'ASKIVAZGEC' then
      alz_web_process_utils.process_result (0,
                                            9,
                                            -1,
                                            'INVOKE ERR',
                                            substr (sqlcode || ' - ' || sqlerrm || ' - ' || dbms_utility.format_error_backtrace, 1, 1000),
                                            null,
                                            null,
                                            nvl(p_mdlr_hlth_policy.policy_base.contract_id, p_contract_id),
                                            'alz_mdlr_hlth_policy_utils.navigate_request',
                                            p_security_info.userid,
                                            p_process_results);
   end if;

end Navigate_Request;
begin
    p_contract_id := 0;
  p_quote_ref := null;
  p_version_no := 0;
  p_product_id := 63;
  p_partition_type := 'TSS';
  
   p_action := customer.action_rec(null,
                                    null,
                                    null,
                                    null,
                                    '-DASHBOARD',
                                    null,
                                    null,
                                    null,
                                    null,
                                    p_product_id,
                                     p_partition_type,
                                    'DEMO',
                                    null,
                                    null);
  -- Call the procedure
 /* p_security_info := customer.security_info_rec('10.70.81.134', --ip           varchar2 (20),
   'WFIBA8508_70001',--userid       varchar2 (30),
   '70001',--agency_code  varchar2(30),
   '70001-1', --sub_agency_code  varchar2(30),
   null, --login_date   date,
   '0' --, identity_no  varchar2(30)
   );*/
   
    p_security_info := customer.security_info_rec('10.70.81.134', --ip           varchar2 (20),
   'WSIGORTAMSIG10_5040',--userid       varchar2 (30),
   '5040',--agency_code  varchar2(30),
   null, --sub_agency_code  varchar2(30),
   null, --login_date   date,
   '0' --, identity_no  varchar2(30)
   );
   

/*19-07-2018 15:23:50.429343000 p_policy_ref :  p_contract_id : 0 p_quote_ref :  p_version_no : 0
19-07-2018 15:23:50.429502000 p_product_id : 63 p_partition_type : TSSF p_term_end_date : 19/07/2018 p_agent_int_id : 71075
19-07-2018 15:23:50.429633000 p_sub_agent_int_id : 71170 p_action.action_code : DEMO p_action.current_page : DASHBOARD
19-07-2018 15:23:50.429763000 p_action.button_name :  p_action.endorsement_code : 0 p_action.endors_reason_code : 0
19-07-2018 15:23:50.429875000 p_security_info.userid : WFIBA8508_70001 p_security_info.agency_code : 70001*/

/*19-07-2018 15:41:24.720177000 p_policy_ref :  p_contract_id : 0 p_quote_ref :  p_version_no : 0
19-07-2018 15:41:24.720321000 p_product_id : 63 p_partition_type : TSS p_term_end_date : 19/07/2018 p_agent_int_id : 12640
19-07-2018 15:41:24.720446000 p_sub_agent_int_id : 0 p_action.action_code : DEMO p_action.current_page : DASHBOARD
19-07-2018 15:41:24.720592000 p_action.button_name :  p_action.endorsement_code : 0 p_action.endors_reason_code : 0
19-07-2018 15:41:24.720703000 p_security_info.userid : WSIGORTAMSIG10_5040 p_security_info.agency_code : 5040*/

  customer.alz_mdlr_hlth_policy_utils.navigate_request(p_contract_id => p_contract_id,
                                                       p_policy_ref => null,--:p_policy_ref,
                                                       p_quote_ref => p_quote_ref,
                                                       p_version_no => p_version_no,
                                                       p_product_id =>p_product_id,
                                                       p_partition_type => p_partition_type,
                                                       p_term_end_date => NULL,--:p_term_end_date,
                                                       p_agent_int_id => NULL,--:p_agent_int_id,
                                                       p_sub_agent_int_id => null, -- :p_sub_agent_int_id,
                                                       p_mdlr_hlth_policy => p_mdlr_hlth_policy,
                                                       p_action => p_action,
                                                       p_security_info => p_security_info,
                                                       p_simple_questions => p_simple_questions,
                                                       p_process_results => p_process_results);
        
    /*  PROCESS_NO NUMBER,          -- ba�lat�lan process i�in uniqe no
    ERROR_NO NUMBER,            -- error tablosundan , tabloda olmayan hatalar i�in 0
    SEVERITY NUMBER,            -- business rules i�in 9, Application error ler i�in : takip edilmesi gereken batch i�lerde 1,kesinti yaratacak hata 2  , di�er 3
    TYPE NUMBER,                -- ERROR i�in -1 ,WARNING i�in 0,INFO i�in 100
    CODE varchar2(30),          -- INVALID_DATA,ORACLE_EXCEPTION,TERMINATE,WARNING vs.
    REASON varchar2(1000),       -- a��klama
    ACTION varchar2(500),       -- ��z�m �nerisi
    KEY_VALUE1 varchar2(250),   -- process le ilgili parametre
    KEY_VALUE2 varchar2(250),   -- process le ilgili parametre
    ERROR_ORIGIN  VARCHAR2(250) */  
   ndx := 0;
   FOR rec IN (SELECT * FROM TABLE(p_mdlr_hlth_policy.risk_subjects)) LOOP
          dbms_output.put_line('city code:'||rec.risk_subject_base.city_code); 
          --rec.policy_insured.identity_no := 13069569098;  
          --p_mdlr_hlth_policy.risk_subjects(ndx).policy_insured.identity_no := 13069569098; 
          ndx := ndx +1;
   END LOOP; 
   FOR rec IN (SELECT * FROM TABLE(p_simple_questions)) LOOP
       dbms_output.put_line(rec.questiondesc);           
   END LOOP;       
   FOR rec IN (SELECT * FROM TABLE(p_process_results)) LOOP
       dbms_output.put_line(rec.TYPE||'-'||rec.REASON);           
   END LOOP;                                                          
   dbms_output.put_line('bitti:'||p_contract_id);   
      p_action := customer.action_rec(null,
                                    null,
                                    null,
                                    null,
                                    'MUSTEKLE',
                                    null,
                                    null,
                                    null,
                                    null,
                                    p_product_id,
                                     p_partition_type,
                                    'MUSTKAYDET',
                                    null,
                                    null);
     -- p_mdlr_hlth_policy.risk_subjects.policy_insured.identity_no := 13069569098; 
      --p_mdlr_hlth_policy.risk_subjects(0).policy_insured.identity_no := 13069569098;                          
     alz_mdlr_hlth_policy_utils.Create_Proposal(p_mdlr_hlth_policy,
                                               p_mdlr_hlth_scale_part_moduls,
                                               p_action,
                                               p_security_info,
                                               p_simple_questions,
                                               p_process_results);      
     FOR rec IN (SELECT * FROM TABLE(p_mdlr_hlth_policy.risk_subjects)) LOOP
          dbms_output.put_line('city code2:'||rec.risk_subject_base.city_code);      
   END LOOP; 
   FOR rec IN (SELECT * FROM TABLE(p_simple_questions)) LOOP
       dbms_output.put_line(rec.questiondesc);           
   END LOOP;       
   FOR rec IN (SELECT * FROM TABLE(p_process_results)) LOOP
       dbms_output.put_line(rec.TYPE||'-'||rec.REASON);           
   END LOOP;                                                                                              
end;
