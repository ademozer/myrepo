declare

v_mdlr_hlth_policy customer.mdlr_hlth_policy_rec;
v_process_results customer.process_result_table := customer.process_result_table();
p_security_info    customer.security_info_rec;
p_action           customer.action_rec;
p_simple_questions customer.simple_question_table := customer.simple_question_table();
v_simple_question_rec customer.simple_question_rec;

p_mdlr_hlth_scale_part_moduls Customer.Mdlr_Hlth_Scale_Part_Mdl_Table;

begin

    BEGIN
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_LANGUAGE=''TURKISH''';
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_TERRITORY=''TURKEY''';
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_CURRENCY=''TL''';
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_ISO_CURRENCY=''TURKEY''';
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_NUMERIC_CHARACTERS='',.''';
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_CALENDAR=''GREGORIAN''';
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_DATE_FORMAT=''DD/MM/YYYY''';
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_DATE_LANGUAGE=''TURKISH''';
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_SORT=''TURKISH''';
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_TIME_FORMAT=''HH24:MI:SSXFF''';
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_TIMESTAMP_FORMAT=''DD/MM/RRRR HH24:MI:SSXFF''';
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_TIME_TZ_FORMAT=''HH24:MI:SSXFF TZR''';
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_TIMESTAMP_TZ_FORMAT=''DD/MM/RRRR HH24:MI:SSXFF TZR''';
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_DUAL_CURRENCY=''TL''';
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_COMP=''BINARY''';
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_LENGTH_SEMANTICS=''BYTE''';
    EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_NCHAR_CONV_EXCP=''FALSE''';
    END;

    alz_mdlr_hlth_policy_utils.continue_to_proposal(341095497,
                                                    'ALLZWEBPOL',
                                                    v_mdlr_hlth_policy,
                                                    v_process_results);

    p_action := customer.action_rec(null,
                                    null,
                                    null,
                                    null,
                                    'BASVURUOZET',
                                    null,
                                    'ONAYAGONDER',
                                    null,
                                    null,
                                    null,
                                    null,
                                    'A',
                                    null,
                                    null);

    p_security_info := customer.security_info_rec(null,
                                                  'WFIBA8508_70001',
                                                  12354,
                                                  null,
                                                  trunc(sysdate),
                                                  null);

    --otorizasyona y�nlendirmek istiyor musunuz sorusuna Evet demek i�in a��lmas� gerekiyor..
    /*v_simple_question_rec := customer.simple_question_rec(550,
                                                          null,
                                                          null,
                                                          1,
                                                          null);*/

    alz_mdlr_hlth_policy_utils.Create_Proposal(v_mdlr_hlth_policy,
                                               p_mdlr_hlth_scale_part_moduls,
                                               p_action,
                                               p_security_info,
                                               p_simple_questions,
                                               v_process_results);
                                               
   FOR rec IN (SELECT * FROM TABLE(p_mdlr_hlth_scale_part_moduls)) LOOP
       dbms_output.put_line(rec.scale_modul.package_name);           
   END LOOP;                                            

    dbms_output.put_line('v_mdlr_hlth_policy.contract_id : '||v_mdlr_hlth_policy.policy_base.contract_id);
    dbms_output.put_line('v_mdlr_hlth_policy.agent_int_id : '||v_mdlr_hlth_policy.policy_base.agent_int_id);

    if v_process_results.count > 0 then
       dbms_output.put_line('v_process_results.reason : '||v_process_results(1).reason);
    end if;
    if p_simple_questions.count > 0 then
       dbms_output.put_line('p_simple_questions.questionid : '||p_simple_questions(1).questionid);
    end if;

end;
