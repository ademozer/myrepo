select * from alz_tobb_user_hist where gsm='905322165846' 
