DECLARE
  v_Payload CLOB;
  p_Response_Rec                 Customer.EuroMsg_Mail_Response_Table:=Customer.EuroMsg_Mail_Response_Table();
  p_process_results              process_result_table;
  Procedure Call_TPA_Service(p_Method            In          Varchar2,
                               p_Payload           In          Clob,
                               p_User              In          Varchar2,
                               p_Response_Rec      In Out      Customer.EuroMsg_Mail_Response_Table,
                               p_Process_Results   In Out      Customer.Process_Result_Table) Is
        ---v_URL               Varchar2(500) := get_url_link('http://esb.allianz.com.tr:12000/external/Tpa/rest/euroMessageService');
        v_URL               Varchar2(500) := get_url_link('http://esb.allianz.com.tr:12000/external/MessageService/rest/euroMessageService');
        v_Req               utl_http.req;
        v_Req_Length        Number;
        v_Res               utl_http.resp;
        v_Buffer            Varchar2(32767);
        v_Offset            Number := 1;
        v_Amount            Number :=32767;
        v_Utl_Err           Varchar2(1000);
        v_value             varchar2(4000);
        hata_code           varchar2(10);
        v_output            varchar2(10);
        v_Response_Rec      customer.EuroMsg_Mail_Response_Table :=customer.EuroMsg_Mail_Response_Table();
    Begin
        v_Req_Length := dbms_lob.getlength(p_Payload);
        v_Req := utl_http.begin_request(v_URL||'/'||p_Method, 'POST', 'HTTP/1.1');
        --utl_http.set_header(v_Req, 'Auth','Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJwbGF0Zm9ybSI6IkFMWl9UUEFEQiJ9.0yhHtB8X9taBuJ5h-8ZYmz7aVK7LnMiGhKr5tP6wXfY');
        utl_http.set_header(v_Req, 'Auth','Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJwbGF0Zm9ybSI6IkRCIn0.Vcq2uIMGOq3N8o9S-E-O93YuZ8qJVH0Or7tSfTxV_Qk');
        utl_http.set_header(v_Req, 'Content-Length', v_Req_Length);
        utl_http.set_header(v_Req, 'Content-Type', 'application/json;charset=UTF-8');
        utl_http.set_header (v_Req,'Transfer-Encoding', 'chunked' );
        utl_http.set_body_charset(v_Req,'UTF-8');
        While (v_Offset < v_Req_Length)
        Loop
           dbms_lob.read(p_Payload, v_Amount, v_Offset, v_Buffer);
           utl_http.write_text(r    => v_Req, data => v_Buffer);
           v_Offset := v_Offset + v_Amount;
        End Loop;
        v_Res := utl_http.get_response(v_Req);
        Begin
           loop
              utl_http.read_line(v_Res, v_value);
              DBMS_OUTPUT.PUT_LINE('Res_value='||v_value);
              hata_code:=v_Res.status_code;
              Alz_EuroMsg_Utils.getcontenterr(v_value,
                            hata_code,
                            v_Response_Rec);
              p_Response_Rec:=v_Response_Rec;
               DBMS_OUTPUT.PUT_LINE('Res_value.1='||v_value);
           end loop;
              utl_http.end_response(v_Res);
        Exception
        When utl_http.end_of_body Then
             utl_http.end_response(v_Res);
        When utl_http.too_many_requests Then
             utl_http.end_response(v_Res);
        When Others Then
             utl_http.end_response(v_Res);
       End;
    exception when others then
    utl_http.end_response(v_Res);
    v_utl_err:= Utl_Http.Get_Detailed_Sqlerrm;
    alz_web_process_utils.process_result (0,
                                          9,
                                          -1,
                                          'INVOKE ERR',
                                          substr (sqlcode || ' - ' || sqlerrm || ' - ' || dbms_utility.format_error_backtrace, 1, 1000),
                                          v_utl_err,
                                          null,
                                          null,
                                          'Alz_Euromsg_Utils.Call_TPA_Service',
                                          p_User,
                                          p_process_results);
    End Call_TPA_Service; 
    
   BEGIN
     --  v_Payload := '{"toList":["extern.adem.ozer@allianz.com.tr"],"subject":"test","body":"deneme","companyCode":"100","clientKey":"OBF_RED_380606517","parameterMap":{"EM_EMAIL_OTHER":"true"}}';
--v_Payload := '{"smsBody":"De�erli Acentemiz T�LAY K���O�LU kullan�c�s�n�n DIGITALL sistemine giri� i�in kullan�c� ad� WDA0890_15176 ve �ifresi omTG3LPn9 olu�turulmu�tur. DIGITALL sistemine giri� yapabilirsiniz. https://digitall.allianz.com.tr","gsmNo":"905322165846","companyCode":"045","clientKey":"ALZ_TOBB_USER_905322165846","parameterMap":{"EM_SMS_OTHER":"true"}}';
      v_Payload := '{"smsBody":"deneme","gsmNo":"905423547375","companyCode":"045","clientKey":"ALZ_TOBB_USER_905423547376","parameterMap":{}}';
      v_Payload := regexp_replace(v_Payload, '([^[:graph:] | ^[:blank:]])', ''); 
  --v_Payload := REPLACE(v_Payload,CHR(9),' ');
      --Alz_Euromsg_Utils.
      Call_TPA_Service('sendSms',--'sendMail',
                         v_Payload,
                         USER,
                         p_Response_Rec,
                         p_Process_Results);   
       FOR rec IN (SELECT Hata_Code,Response_Name, Response_Value FROM TABLE(p_Response_Rec)) LOOP
         DBMS_OUTPUT.PUT_LINE('resp='||rec.Hata_Code||'-'||rec.Response_Name||'-'||rec.Response_Value);
       END LOOP;                   
       FOR rec IN (SELECT * FROM TABLE(p_Process_Results)) LOOP
              dbms_output.put_line(rec.REASON||'-'||rec.KEY_VALUE1||'-'||rec.ERROR_ORIGIN);
       END LOOP;
     EXCEPTION WHEN OTHERS THEN
           dbms_output.put_line('Hata:'||SUBSTR(SQLERRM,1,200));      

   END;
     
