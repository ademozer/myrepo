declare
 v_claim_id NUMBER := 31970395;--31935735;
 v_sf_no    NUMBER := 1;
 v_assignment_user VARCHAR2(200);
 v_event_id        NUMBER;
 v_event_order     NUMBER;
 v_func_type      NUMBER := 1;
 v_source_type     NUMBER := 1;
 v_save_log        NUMBER := 1;
 
begin
  -- Call the procedure
  alz_hlth_cpa_utils.run_automation_and_assignment(p_claim_id => v_claim_id,
                                                   p_sf_no => v_sf_no,
                                                   p_assignment_user => v_assignment_user,
                                                   p_event_id => v_event_id,
                                                   p_event_order => v_event_order,
                                                   p_save_log => v_save_log,
                                                   p_function_type => v_func_type,
                                                   p_source_type => v_source_type);
  dbms_output.put_line('v_ass_user='||v_assignment_user);
  dbms_output.put_line('v_event_id='||v_event_id);
  dbms_output.put_line('v_event_order='||v_event_order);
end;
