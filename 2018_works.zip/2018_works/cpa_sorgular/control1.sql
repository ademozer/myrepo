select * from koc_clm_hlth_detail where cpa_status='R'--where claim_id='31891343'--cpa_status='TAH'

SELECT * FROM CUSTOMER.ALZ_HLTH_CPA_EVENT_DETAILS WHERE ED_TAG='CLAIM_ID' AND ED_SHORT_VAL='31935735'

select * from alz_tpa_uw_reject_log
