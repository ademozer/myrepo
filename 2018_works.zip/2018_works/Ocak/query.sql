SELECT --(Select  Policy_Ref  From Clm_Pol_Bases Vf Where Vf.Claim_Id = Det.Claim_Id) POLICY_NO,
         vf.Policy_Ref POLICY_NO,
         det.EXT_REFERENCE HASAR_DOSYA_NO,
         det.PROVISION_DATE provision_date,
         abc,
         Det.Claim_Id Claim_Id,
         Det.add_order_no,
         det.sf_no,
         det.invoice_total,
         det.invoice_date,
         det.payment_total,
         det.swift_code,
         det.cpa_status,
         det.has_unreadable_doc,
         det.realization_date,
         X1.Part_Id Part_Id,
         X1.Abc TCKN,
        /* (SELECT identity_no
            FROM koc_cp_partners_ext
           WHERE part_id = X1.Part_Id)
            TCKN,*/
         x1.contract_id contract_id,
         TYPE_OF_INTEREST,
         x1.contract_id,
         x1.partition_no,
         Det.Close_Date,
         det.realization_date,
         det.PROCESS_DATE OLAY_TARIHI,
         clm.is_rated is_rated,
         -- e.realization_ticket_date as TAHAKKUK_TARIHI,
         -- e.payment_approved_date as KESIN_ONAY_TARIHI,
         -- e.ticket_date as ODEME_TARIHI,
         (SELECT MAX (PROCESS_DATE)
            FROM koc_clm_hlth_indem_dec
           WHERE claim_id = Det.Claim_Id AND FILE_AGREEMENT_CODE = 'P')
            PROVISION_DATETIME,
         (SELECT dref.explanation
            FROM alz_hlth_cpa_orig_docs docs, alz_hlth_cpa_doc_ref dref
           WHERE docs.doc_code = dref.doc_code AND docs.claim_id = det.claim_id)
            OB_EXP,
         (SELECT EXPLANATION
            FROM (  SELECT *
                      FROM alz_hlth_cpa_detaıl_hıstory
                  ORDER BY process_date DESC)
           WHERE claim_id = Det.Claim_Id AND ROWNUM = 1)
            payment_exp,
         (SELECT COUNT (papers.Status_Code) AS eksik_evrak_count
            -- Decode(a.Status_Code, 'A', 'Evrak Bekleniyor', 'D', 'Evrak Silindi', 'C', 'Evrak Geldi') "Evrak Durumu"
            FROM Koc_Clm_Hlth_Incomp_Papers papers
           WHERE Papers.Claim_Id = Det.Claim_Id AND Papers.Status_Code = 'A')
            Eksik_Evrak_Adedi,
         (SELECT LISTAGG (b.long_name || ' - ' || institutes.name, ' , ')
                    WITHIN GROUP (ORDER BY det.add_order_no)
            FROM Koc_Clm_Hlth_Incomp_Papers papers,
                 koc_cp_health_look_up a,
                 inf_v_lang_trans_api_tr b --, koc_mv_network_search_skrm_sup sup
           WHERE     papers.Status_Code = 'A'
                 AND papers.claim_id = Det.Claim_Id
                 AND a.parameter = Papers.Absent_Doc_Code
                 AND a.desc_int_id = b.desc_int_id
                 AND a.look_up_code = 'INDABDOC'
                 AND institutes.institute_code = det.institute_code
                 -- and sup.institute_code = det.institute_code
                 AND papers.add_order_no = det.add_order_no)
            Docs,
         (SELECT LISTAGG (b.long_name || ' - ' || institutes.name, ' , ')
                    WITHIN GROUP (ORDER BY det.add_order_no) --Within Group (Order By Papers.Claim_Id)
            FROM Koc_Clm_Hlth_Incomp_Papers papers,
                 koc_cp_health_look_up a,
                 inf_v_lang_trans_api_tr b --, koc_mv_network_search_skrm_sup sup
           WHERE     Det.CPA_STATUS = 'I'
                 AND papers.claim_id = Det.Claim_Id
                 AND a.parameter = Papers.Absent_Doc_Code
                 AND a.desc_int_id = b.desc_int_id
                 AND a.look_up_code = 'INDABDOC'
                 AND institutes.institute_code = det.institute_code
                 -- and sup.institute_code = det.institute_code
                 AND papers.add_order_no = det.add_order_no)
            MissingDocs,
         (SELECT COUNT (*)
            FROM KOC_CLM_HLTH_COMM
           WHERE CLAIM_ID = det.CLAIM_ID)
            OLAY_NEDENI_FLAG, -- 0 => Provizyon(Doğrudan ödeme), otherwise => Elden hasar(Sonradan ödeme)
         det.GROUP_CODE GRUP_KODU_FLAG,  --null => bireysel, otherwise => grup
         (SELECT C.LONG_NAME
            FROM KOC_CP_HEALTH_LOOK_UP K, CUR_TRANSLATIONS C
           WHERE     K.LOOK_UP_CODE = 'CLMSTCODE'
                 AND K.DESC_INT_ID = C.DESC_INT_ID
                 AND C.SULA_ORA_NLS_CODE = 'TR'
                 AND K.PARAMETER = det.STATUS_CODE
                 AND ROWNUM = 1)
            DURUM,
         (SELECT (FIRST_NAME || ' ' || MIDDLE_NAME || ' ' || SURNAME)
            FROM cp_partners
           WHERE PART_ID = det.PART_ID)
            RISK_KONUSU,
         det.institute_code,
         institutes.name ANLASMALI_KURUM,
         --institutes.institute_type,
         ext.institute_type,
         ext.hospital_type,
         det.specialty_subject,
         sref.explanation specialty_subject_name,
         det.doctor_code,
         doctors.doctor_name,
         doctors.doctor_surname,
         doctors.title doctor_title,
         doctors.medikal_staff_list doctor_type,
         mydoc.avg_score,
         clm.notification_type
    FROM KOC_CLM_HLTH_DETAIL det,
         Koc_Clm_Suppliers_Ext ext,
         Clm_Pol_Bases Vf,
         customer.ONEAPP_MYDOC_RATINGS mydoc,
         customer.ONEAPP_MYDOC_ELIGIBLE_CLAIMS clm,
         Koc_Oc_Specialty_Subj_Ref sref,
         (SELECT TRIM(a.name) name, a.institute_code                 --, a.institute_type
            FROM koc_v_clm_suppliers_m1 a, koc_cc_inst_sub_inst_rel b
           WHERE     a.institute_code = b.inst_sub_inst_code
                 AND a.institute_type <> '4'
          UNION
          SELECT TRIM(a.name) name, a.institute_code                 --, a.institute_type
            FROM koc_v_clm_suppliers_his1 a, koc_cc_inst_sub_inst_rel b
           WHERE     a.institute_code = b.inst_sub_inst_code
                 AND a.institute_type <> '4'
          UNION
          SELECT TRIM(a.name) name, a.institute_code                 --, a.institute_type
            FROM koc_v_clm_suppliers_m1 a
           WHERE a.institute_type <> '4'
          UNION
          SELECT TRIM(a.name), a.institute_code                 --, a.institute_type
            FROM koc_v_clm_suppliers_his1 a
           WHERE a.institute_type <> '4') Institutes,
         (SELECT DISTINCT pp.partner_id PART_ID,
                          ll.type_of_interest TYPE_OF_INTEREST,
                          pb.contract_id contract_id,
                          ll.partition_no partition_no,
                          koc.identity_no abc
            FROM ocp_interested_parties pp,
                 ocp_ip_links ll,
                 koc_ocp_health kk,
                -- koc_ocp_health k2,
                -- ocp_interested_parties p2,
                -- ocp_ip_links l2,
                 koc_cp_partners_ext koc,
                 Ocp_Policy_Bases Pb
           WHERE     pp.contract_id = ll.contract_id
                 AND pp.ip_no = ll.ip_no
                 AND pp.version_no = ll.version_no 
                 AND pp.version_no = pb.version_no                 
                 AND Pp.Top_Indicator = 'Y'
                 --AND koc.identity_no = 67063160010--48025117952         
                 AND pb.policy_ref = '0001171006124934'
                 AND pp.partner_id = koc.part_id
                 AND kk.contract_id = ll.contract_id
                 AND kk.partition_no = ll.partition_no
                 --AND kk.Family_Code = k2.Family_Code
                -- AND k2.contract_id = kk.contract_id
                 --AND p2.contract_id = pp.contract_id
                 --AND p2.contract_id = l2.contract_id
                 --AND p2.ip_no = l2.ip_no
                 --AND p2.version_no = l2.version_no
                 --AND p2.Top_Indicator = 'Y'
                 AND pb.contract_id = kk.contract_id                        --
                 AND kk.version_no = pb.version_no  --
                 --AND l2.partition_no = k2.partition_no
                -- AND Kk.Version_No = K2.Version_No
                 AND pb.term_end_date >= TRUNC (SYSDATE) - 365
                 AND Pb.Version_No =
                        (SELECT MAX (version_no)
                           FROM ocp_policy_bases b
                          WHERE     b.contract_id = pb.contract_id
                                AND B.Version_No <= Pb.Version_No
                                AND B.Reversing_Version IS NULL)
                /* AND (   (   l2.type_of_interest = 'K'
                          OR l2.type_of_interest = 'O'
                          OR l2.type_of_interest = 'KZ'
                          OR l2.type_of_interest = 'Ç')
                      OR p2.partner_id = koc.part_id)*/                      
                      ) x1,
         (SELECT institute_code,
                 doctor_code,
                 specialty_subject,
                 doctor_name,
                 doctor_surname,
                 title,
                 medikal_staff_list
            FROM Koc_Cc_Web_Inst_Doctor k
           WHERE k.Validity_End_Date IS NULL
          UNION
          SELECT institute_code,
                 doctor_code,
                 specialty_subject,
                 doctor_name,
                 doctor_surname,
                 title,
                 medikal_staff_list
            FROM Hst_Cc_Web_Inst_Doctor h
           WHERE h.Validity_End_Date IS NULL--AND NOT EXISTS (SELECT NULL FROM Koc_Cc_Web_Inst_Doctor K2 WHERE K2.Doctor_Identity_No = h.Doctor_Identity_No AND K2.Validity_End_Date IS NULL)
         ) doctors
   WHERE     Det.Part_Id = X1.Part_Id
         AND Institutes.Institute_Code = NVL (Det.Institute_Code, 30486)
         AND doctors.institute_code(+) = NVL (Det.Institute_Code, 30486)
         AND doctors.doctor_code(+) = det.doctor_code
         AND ext.institute_code = NVL (Det.Institute_Code, 30486)
         AND Vf.Claim_Id = Det.Claim_Id
         AND vf.policy_ref = '0001171006124934'
         --AND x1.partition_no = 3
        -- AND tckn = x1.abc
         AND mydoc.claim_id(+) = det.claim_id
         AND clm.claim_id(+) = det.claim_id
         AND sref.Specialty_Subject(+) = det.Specialty_Subject
         --and NVL (d.business_line_type(+), 0) IN (0, 1)
         AND sref.Validity_Start_Date(+) <= SYSDATE
         AND NVL (sref.Validity_End_Date(+), SYSDATE) >= SYSDATE
ORDER BY det.process_date DESC;
