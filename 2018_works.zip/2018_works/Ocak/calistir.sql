PROCEDURE CALISTIR IS
v_is_industrial number;
v_branch_id number;
BEGIN
	
		v_is_industrial := :kontrol.list_eb;
	
	
		v_branch_id := :kontrol.list_branch;
	
	
	:kontrol.p_error_text := null;
	alz_endofmonth_utils.insertendofmonthproc(to_number(:kontrol.yil)
																					 ,to_number(:kontrol.ay)
																					 ,v_branch_id
																					 ,v_is_industrial
																					 ,:kontrol.SECIM
																					 ,:kontrol.GEC_KAL
																					 ,:boiler.userid
																					 ,:kontrol.p_error_text);
																			 
	if(:kontrol.p_error_text is not null)then
		C_MSG('HATA: ' || :kontrol.p_error_text);
	else
		/*C_MSG('Yıl '||to_number(:kontrol.yil));
		C_MSG('Ay '||to_number(:kontrol.ay));
		C_MSG('Branch_id '||:kontrol.P_BRANCH_ID);
		C_MSG('ind_user '||:kontrol.P_IS_INDUSTRIAL_USER);
		C_MSG('proc_code '||:kontrol.SECIM);
		C_MSG('user_id '||:boiler.userid);*/
		GUNCELLE;
	end if;
exception when others then
	message(sqlerrm);message(sqlerrm);
END;
