PROCEDURE Reverseremainig(p_Contract_Id      NUMBER,
                            p_Partition_No     NUMBER,
                            p_Realization_Date DATE,
                            p_User_Id          VARCHAR2,
                            p_Clmdetail        Koc_Clm_Hlth_Detail%ROWTYPE,
                            p_Clmprovision     Koc_Clm_Hlth_Provisions%ROWTYPE) IS
    Cur                      Refcur;
    Indeminfo                Koc_Clm_Hlth_Indem_Totals%ROWTYPE;
    v_Date                   DATE;
    Policyinfo               Koc_v_Hlth_Insured_Info_Indem%ROWTYPE;
    u_s_Provision_Amount     NUMBER;
    u_s_Spend_Total          NUMBER;
    u_s_Spend_Day_Seance     NUMBER;
    u_s_Exemption_Sum        NUMBER;
    u_r_Exemption_Sum        NUMBER;
    u_r_Cover_Price          NUMBER;
    u_r_Day_Seance           NUMBER;
    v_Country_Group          NUMBER;
    v_Parite                 NUMBER := 1;
    v_Pay_Clearing_System_Id NUMBER;
    v_Pay_Curr_Get_Type      VARCHAR2(4);
    v_Cover_Swf              VARCHAR2(20);
    v_Exch_Date              VARCHAR2(20);
    v_Curr_Date              DATE;
    v_Exit                   BOOLEAN;
    Vv_Date                  DATE;
    Vv_Partittion_No         NUMBER;
    j                        NUMBER;
    i                        NUMBER;
    v_Trans_Insured          Transinsuredtyp;
    Vprodpartmdlr            VARCHAR2(10);
    Vcoverpackageid          NUMBER;
    Vcoverpackagedate        DATE;
    Vis1kezused              NUMBER(1) := 0;
    Vhaspolicy1kez           NUMBER(1) := 0;
    Vclaiminsttype           Koc_Clm_Hlth_Indem_Totals.Claim_Inst_Type%TYPE;
    v_Check_Package          NUMBER := 1;
  BEGIN
    -- 43.a--------------------------------------------------------------------------
    v_Country_Group := Koc_Clm_Hlth_Utils.Getcountrygroup(p_Clmdetail.Country_Code);
    -- 43.b--------------------------------------------------------------------------
    IF p_Clmdetail.Provision_Date IS NOT NULL THEN
      v_Date := To_Date(To_Char(p_Clmdetail.Provision_Date, 'dd/mm/yyyy') ||
                        ' 13:00:00',
                        'dd/mm/yyyy hh24:mi:ss');
    ELSE
      v_Date := To_Date(To_Char(Nvl(p_Clmdetail.Date_Of_Loss,
                                    p_Clmdetail.Invoice_Date),
                                'dd/mm/yyyy') || ' 13:00:00',
                        'dd/mm/yyyy hh24:mi:ss');
    END IF;
    -- 43.c -------------------------------------------------------------------------
    IF p_Clmdetail.Claim_Id IS NOT NULL THEN
      -- Koc_Clm_Hlth_Utils.Getpolinfoforindembyclm(p_Clmdetail.Claim_Id, NULL, Cur);
      Getpolinfoforindembyclm_Trnx(p_Clmdetail.Claim_Id, NULL, Cur);
      FETCH Cur
        INTO Policyinfo;

      CLOSE Cur;
    END IF;
    -- 43.d --------------------------------------------------
    IF Policyinfo.Contract_Id IS NULL THEN
      Koc_Clm_Hlth_Utils.Getallpolinfoforindemnity(p_Contract_Id,
                                                   p_Partition_No,
                                                   p_Clmdetail.Part_Id,
                                                   v_Date,
                                                   Cur);

      FETCH Cur
        INTO Policyinfo;

      CLOSE Cur;
    END IF;
    -- 43.e ---------------------------------------------------------
    IF Policyinfo.Contract_Id IS NULL THEN
      IF p_Clmdetail.Provision_Date IS NOT NULL THEN
        v_Date := To_Date(To_Char(p_Clmdetail.Provision_Date, 'dd/mm/yyyy') ||
                          ' 11:00:00',
                          'dd/mm/yyyy hh24:mi:ss');
      ELSE
        v_Date := To_Date(To_Char(Nvl(p_Clmdetail.Date_Of_Loss,
                                      p_Clmdetail.Invoice_Date),
                                  'dd/mm/yyyy') || ' 11:00:00',
                          'dd/mm/yyyy hh24:mi:ss');
      END IF;
  
      Koc_Clm_Hlth_Utils.Getallpolinfoforindemnity(p_Contract_Id,
                                                   p_Partition_No,
                                                   p_Clmdetail.Part_Id,
                                                   v_Date,
                                                   Cur);

      FETCH Cur
        INTO Policyinfo;

      CLOSE Cur;
    END IF;
    -- 43.f -------------------------------------------------------------
    IF Policyinfo.Contract_Id IS NULL THEN
      Raise_Application_Error(-20200, 'Poliçe bulunamadi.');
    END IF;

    --

    /*
    mustafaku koç tss
    IF p_Clmdetail.Claim_Id IS NOT NULL
    THEN
      --
      IF p_Clmdetail.Package_Id IS NOT NULL
      Then
           Policyinfo.Package_Id   := p_Clmdetail.Package_Id;
           Policyinfo.Package_Date := p_Clmdetail.Package_Date;

      END IF;
    END IF;*/
    -- 43.g -------------------------------------------------------------
    IF p_Clmdetail.Claim_Id IS NOT NULL THEN
      --
      IF p_Clmdetail.Package_Id IS NOT NULL THEN

        SELECT COUNT(1)
          INTO v_Check_Package
          FROM Koc_Clm_Hlth_Indem_Totals i
         WHERE i.Package_Id = p_Clmdetail.Package_Id
           AND i.Package_Date = p_Clmdetail.Package_Date
           AND i.Contract_Id = Policyinfo.Contract_Id
           AND i.Partition_No = Policyinfo.Partition_No
           AND i.Is_Valid = 1
           AND Rownum < 2;

        IF v_Check_Package > 0 --dosyadaki plan değişmiş mi
         THEN
          Policyinfo.Package_Id   := p_Clmdetail.Package_Id;
          Policyinfo.Package_Date := p_Clmdetail.Package_Date;
        END IF;
      END IF;
    END IF;
    -- 43.h ---------------------------------------------------
    --1KEZ ödeme tipi AHK kurumda kullanilirsa
    --Poliçenin AHK tanimli teminatlari için AK limitsizligi bozulur
    --Poliçe 1KEZ tanimli mi
    Vclaiminsttype := p_Clmdetail.Claim_Inst_Type;

    --reverseremaining baska bir metoddan çagrilmadi ise
    IF Nvl(Get_Glis1kezused, 0) = 0 THEN
      Vhaspolicy1kez := Checkpolicyforindemnity(p_Contract_Id,
                                                p_Partition_No,
                                                Policyinfo.Package_Id,
                                                Policyinfo.Package_Date,
                                                Trunc(v_Date),
                                                '1KEZ');
    -- 43.i ------------------------------------------------------
      IF Vhaspolicy1kez = 1 THEN
        --hasar dosyalarinda 1KEZ teminati kullanilmis mi
        Vis1kezused := Checkprovisionforindemnity(p_Contract_Id,
                                                  p_Partition_No,
                                                  Policyinfo.Package_Id,
                                                  Policyinfo.Package_Date,
                                                  Trunc(v_Date),
                                                  '1KEZ');
      -- 43.j ---------------------------------------------------------     
        --reverseremaing çagrilirken teminat durumu CP olabilecegi için checkprovisionforindemnity
        --metoda gelen provizyon dosyasi için ayrica bakmak gerekiyor
        IF Vis1kezused = 0 THEN
          IF p_Clmdetail.Claim_Id IS NOT NULL THEN
            Vis1kezused := Checkclaimforindemnity(p_Clmdetail.Claim_Id,
                                                  '1KEZ');
          END IF;
        END IF;
      END IF;

      Set_Glis1kezused(Vis1kezused);
    END IF;
    -- 43.k -----------------------------------------------------------
    --
    IF Nvl(Get_Glis1kezused, 0) = 1 THEN
      --Teminatin 1KEZ tanimi varsa hangi kurum tipinde oldugu bulunuyor
      BEGIN
        SELECT Claim_Inst_Type
          INTO Vclaiminsttype
          FROM Koc_Clm_Hlth_Indem_Totals
         WHERE Contract_Id = p_Contract_Id
           AND Partition_No = p_Partition_No
           AND Claim_Inst_Loc = p_Clmdetail.Claim_Inst_Loc
           AND Package_Id = Policyinfo.Package_Id
           AND Package_Date = Policyinfo.Package_Date
           AND Country_Group = Nvl(v_Country_Group, 0)
           AND Cover_Code = p_Clmprovision.Cover_Code
           AND Is_Pool_Cover = Nvl(p_Clmprovision.Is_Pool_Cover, 0)
           AND Is_Special_Cover = Nvl(p_Clmprovision.Is_Special_Cover, 0)
           AND Is_Valid = 1
           AND Validity_Start_Date <= Trunc(v_Date)
           AND (Validity_End_Date >= Trunc(v_Date) OR
               Validity_End_Date IS NULL)
           AND Indemnity_Payment_Type = '1KEZ'
           AND Rownum < 2;
      EXCEPTION
        WHEN OTHERS THEN
          Vclaiminsttype := p_Clmdetail.Claim_Inst_Type;
      END;
    END IF;
    -- 43.l -----------------------------------------------------------------------
    --aaktas
    --21012015
    --Poliçe modüler saglik ürünü mü?
    Vprodpartmdlr := Koc_Health_Policy_Utils5.Get_Prod_Part_Mdlr(Policyinfo.Product_Id,
                                                                 Policyinfo.Partition_Type,
                                                                 Trunc(p_Realization_Date));

    --abdullah aktas
    --21012015
    --mdlr tipinde ise partition_type teminatin sub_package_id sini al
    --mdlr poliçesindeki teminatlarin planlari farkli olabilir.
	-- 43.m -------------------------------------------------
    IF Nvl(Vprodpartmdlr, 'X') = 'MDLR' THEN
      Vcoverpackageid   := Indeminfo.Sub_Package_Id;
      Vcoverpackagedate := Indeminfo.Sub_Package_Date;
    ELSE
      Vcoverpackageid   := Policyinfo.Package_Id;
      Vcoverpackagedate := Policyinfo.Package_Date;
    END IF;
    -- 43. n ----------------------------------------------------------------
    Getindemtotalsmdf(p_Contract_Id,
                      p_Partition_No,
                      Vclaiminsttype,
                      p_Clmdetail.Claim_Inst_Loc,
                      v_Country_Group,
                      p_Clmprovision.Cover_Code,
                      Policyinfo.Package_Id,
                      Policyinfo.Package_Date,
                      Trunc(v_Date),
                      p_User_Id,
                      p_Clmprovision.Is_Pool_Cover,
                      p_Clmprovision.Is_Special_Cover,
                      Cur);

    FETCH Cur
      INTO Indeminfo;

    CLOSE Cur;
    -- 43.o -------------------------------------------------------------
    IF Indeminfo.Contract_Id IS NULL THEN
      Raise_Application_Error(-20200, 'Teminat plani bulunamadi.');
    END IF;
    -- 43.p ------------------------------------------------------------
    IF p_Clmprovision.Swift_Code != Indeminfo.Swift_Code THEN
      v_Cover_Swf := Indeminfo.Swift_Code;

      SELECT Decode(v_Cover_Swf,
                    Base_Swift_Code,
                    Pay_Clearing_System_Id,
                    Pay_Swf_Clear_Sys_Id),
             Decode(v_Cover_Swf,
                    Base_Swift_Code,
                    Pay_Curr_Get_Type,
                    Pay_Swf_Curr_Get_Type),
             Decode(v_Cover_Swf,
                    Base_Swift_Code,
                    Pay_Exch_Dates,
                    Pay_Swf_Exch_Dates)
        INTO v_Pay_Clearing_System_Id, v_Pay_Curr_Get_Type, v_Exch_Date
        FROM Koc_Oc_Prod_Partition_Rel
       WHERE Product_Id = Policyinfo.Product_Id
         AND Partition_Type = Policyinfo.Partition_Type
         AND Validity_Start_Date <= Policyinfo.Term_Start_Date
         AND Nvl(Validity_End_Date, Policyinfo.Term_Start_Date) >=
             Policyinfo.Term_Start_Date;

      IF v_Exch_Date = 'FAT' THEN
        v_Curr_Date := Nvl(p_Clmdetail.Provision_Date,
                           p_Clmdetail.Invoice_Date);
      ELSIF v_Exch_Date = 'OLAY' THEN
        v_Curr_Date := Nvl(p_Clmdetail.Provision_Date,
                           Nvl(p_Clmdetail.Date_Of_Loss,
                               p_Clmdetail.Invoice_Date));
      ELSIF v_Exch_Date = 'TAH' THEN
        v_Curr_Date := p_Realization_Date;
      ELSE
        v_Curr_Date := Nvl(p_Clmdetail.Provision_Date,
                           p_Clmdetail.Invoice_Date);
      END IF;

      v_Parite := Koc_Curr_Utils.Retrieve_Currency_Rate(p_Clmprovision.Swift_Code,
                                                        v_Pay_Curr_Get_Type,
                                                        Trunc(v_Curr_Date),
                                                        v_Pay_Clearing_System_Id,
                                                        TRUE) /
                  Koc_Curr_Utils.Retrieve_Currency_Rate(Indeminfo.Swift_Code,
                                                        v_Pay_Curr_Get_Type,
                                                        Trunc(v_Curr_Date),
                                                        v_Pay_Clearing_System_Id,
                                                        TRUE);
    END IF;
  -- 43.r -------------------------------------------------------------------------------
    u_s_Provision_Amount := -1 * v_Parite *
                            Nvl(p_Clmprovision.Provision_Total, 0);

    --24/01/2010 hakan keks
    u_s_Spend_Total      := -1 * v_Parite *
                            (Nvl(p_Clmprovision.Request_Amount, 0) -
                            Nvl(p_Clmprovision.Refusal_Amount, 0));
    u_s_Spend_Day_Seance := -1 * Nvl(p_Clmprovision.Req_Cure_Day_Count, 0);

    --hakan keks de indem total de exemption islemi yapilmayacak.
    IF Policyinfo.Partition_Type <> 'KEKS' THEN
      u_s_Exemption_Sum := -1 * v_Parite *
                           Nvl(p_Clmprovision.Exemption_Amount, 0);
      u_r_Exemption_Sum := -1 * v_Parite *
                           Nvl(p_Clmprovision.Exemption_Amount, 0);
    ELSE
      u_s_Exemption_Sum := 0;
      u_r_Exemption_Sum := 0;
    END IF;

    IF Indeminfo.Indemnity_Payment_Type IN ('NORM', 'DEFA', '1KEZ') THEN
      IF Policyinfo.Partition_Type <> 'KEKS' THEN
        IF Nvl(p_Clmprovision.Exemption_Rate, 0) != 0 THEN
          IF p_Clmprovision.Exemption_Rate != 1 THEN
            u_r_Cover_Price := -1 * v_Parite *
                               ((Nvl(p_Clmprovision.Provision_Total, 0) /
                               (1 - Nvl(p_Clmprovision.Exemption_Rate, 0))) --+ NVL (p_clmprovision.exemption_amount, 0)
                               );
          ELSE
            u_r_Cover_Price := -1 * v_Parite *
                               (Nvl(p_Clmprovision.Provision_Total, 0) --+ NVL (p_clmprovision.exemption_amount, 0)
                               );
          END IF;
        ELSE
          u_r_Cover_Price := -1 * v_Parite *
                             (Nvl(p_Clmprovision.Provision_Total, 0) --+ NVL (p_clmprovision.exemption_amount, 0)
                             );
        END IF;
      ELSE
        u_r_Cover_Price := -1 * v_Parite *
                           ((Nvl(p_Clmprovision.Provision_Total, 0)));
      END IF;

      u_r_Day_Seance := -1 * Nvl(p_Clmprovision.Day_Seance, 0);
    END IF;

    IF Indeminfo.Indemnity_Payment_Type IN ('DEFA', 'GUN') THEN
      u_r_Day_Seance := -1 * Nvl(p_Clmprovision.Day_Seance, 0);
    END IF;

    v_Country_Group := Koc_Clm_Hlth_Utils.Getcountrygroup(p_Clmprovision.Country_Code);

    UPDATE Koc_Clm_Hlth_Indem_Totals a
       SET a.s_Provision_Amount = Nvl(a.s_Provision_Amount, 0) +
                                  Nvl(u_s_Provision_Amount, 0),
           a.s_Spend_Total      = Nvl(a.s_Spend_Total, 0) +
                                  Nvl(u_s_Spend_Total, 0),
           a.s_Spend_Day_Seance = Nvl(a.s_Spend_Day_Seance, 0) +
                                  Nvl(u_s_Spend_Day_Seance, 0),
           a.s_Exemption_Sum    = Nvl(a.s_Exemption_Sum, 0) +
                                  Nvl(u_s_Exemption_Sum, 0)
     WHERE a.Contract_Id = p_Contract_Id
       AND (a.Partition_No = p_Partition_No OR
           a.Partition_No = Decode(Nvl(p_Clmprovision.Is_Pool_Cover, 0),
                                    0,
                                    p_Partition_No,
                                    0))
       AND a.Claim_Inst_Type = Indeminfo.Claim_Inst_Type
       AND a.Claim_Inst_Loc = Indeminfo.Claim_Inst_Loc
       AND a.Country_Group = v_Country_Group
       AND a.Cover_Code = p_Clmprovision.Cover_Code
       AND a.Main_Or_Sub_Cov = 'ALT'
       AND Nvl(a.Is_Valid, 0) = 1
       AND a.Is_Pool_Cover = Indeminfo.Is_Pool_Cover
       AND a.Is_Special_Cover = Indeminfo.Is_Special_Cover
       AND a.Package_Id = Indeminfo.Package_Id
       AND a.Package_Date = Indeminfo.Package_Date
       AND a.Validity_Start_Date =
           (SELECT MAX(Aa.Validity_Start_Date)
              FROM Koc_Clm_Hlth_Indem_Totals Aa
             WHERE Aa.Contract_Id = a.Contract_Id
               AND Aa.Partition_No = a.Partition_No
               AND Aa.Claim_Inst_Type = a.Claim_Inst_Type
               AND Aa.Claim_Inst_Loc = a.Claim_Inst_Loc
               AND Aa.Country_Group = a.Country_Group
               AND Aa.Cover_Code = a.Cover_Code
               AND Aa.Is_Special_Cover = a.Is_Special_Cover
               AND Aa.Is_Pool_Cover = a.Is_Pool_Cover
               AND Aa.Package_Date = a.Package_Date
               AND Aa.Package_Id = a.Package_Id
               AND Nvl(Aa.Is_Valid, 0) = 1
               AND Aa.Validity_Start_Date <= v_Date);

    UPDATE Koc_Clm_Hlth_Indem_Totals a
       SET a.r_Exemption_Sum = CASE
                                 WHEN Nvl(a.r_Exemption_Sum, 0) -
                                      Nvl(u_r_Exemption_Sum, 0) >
                                      Nvl(a.f_Exemption_Sum, 0) THEN
                                  Nvl(a.f_Exemption_Sum, 0)
                                 ELSE
                                  Nvl(a.r_Exemption_Sum, 0) -
                                  Nvl(u_r_Exemption_Sum, 0)
                               END
     WHERE a.Contract_Id = p_Contract_Id
       AND a.Partition_No = p_Partition_No
       AND a.Validity_Start_Date <= Trunc(v_Date)
       AND Nvl(a.Validity_End_Date, Trunc(v_Date)) >= Trunc(v_Date)
       AND Nvl(a.Is_Valid, 0) = 1
       AND a.Exemption_Group = Indeminfo.Exemption_Group;

    j := 1;
    v_Trans_Insured.Delete;
    Vv_Date          := Trunc(v_Date);
    Vv_Partittion_No := p_Partition_No;

    LOOP
      IF Nvl(Vprodpartmdlr, 'X') <> 'MDLR' THEN
        Updaterelatedcover(Indeminfo.Contract_Id,
                           Vv_Partittion_No,
                           p_Clmprovision.Cover_Code,
                           Indeminfo.Package_Id,
                           Indeminfo.Package_Date,
                           v_Country_Group,
                           Indeminfo.Claim_Inst_Type,
                           Indeminfo.Claim_Inst_Loc,
                           Indeminfo.Is_Pool_Cover,
                           Indeminfo.Is_Special_Cover,
                           Vv_Date,
                           u_r_Cover_Price,
                           u_r_Day_Seance,
                           NULL,
                           NULL,
                           NULL,
                           NULL,
                           NULL,
                           NULL,
                           NULL,
                           NULL,
                           p_Clmprovision.Prov_Date_Time,
                           -1);
      ELSE
        Updaterelatedcovermdlr(Indeminfo.Contract_Id,
                               Vv_Partittion_No,
                               p_Clmprovision.Cover_Code,
                               Indeminfo.Package_Id,
                               Indeminfo.Package_Date,
                               Indeminfo.Sub_Package_Id,
                               Indeminfo.Sub_Package_Date,
                               v_Country_Group,
                               Indeminfo.Claim_Inst_Type,
                               Indeminfo.Claim_Inst_Loc,
                               Indeminfo.Is_Pool_Cover,
                               Indeminfo.Is_Special_Cover,
                               Vv_Date,
                               u_r_Cover_Price,
                               u_r_Day_Seance,
                               NULL,
                               NULL,
                               NULL,
                               NULL,
                               NULL,
                               NULL,
                               NULL,
                               NULL,
                               p_Clmprovision.Prov_Date_Time,
                               -1);
      END IF;

      IF Indeminfo.Is_Pool_Cover = 1 THEN
        Updaterelatedpoolcover(Indeminfo.Contract_Id,
                               0,
                               p_Clmprovision.Cover_Code,
                               Indeminfo.Package_Id,
                               Indeminfo.Package_Date,
                               Vv_Date,
                               u_r_Cover_Price,
                               u_r_Day_Seance,
                               p_Clmprovision.Prov_Date_Time,
                               -1);
      END IF;

      v_Exit := FALSE;
      i      := 1;

      WHILE v_Trans_Insured.Count >= i LOOP
        IF v_Trans_Insured(i).Contract_Id = Indeminfo.Trans_Contract_Id AND v_Trans_Insured(i)
           .Partition_No = Indeminfo.Trans_Partition_No THEN
          v_Exit := TRUE;
        END IF;

        i := i + 1;
      END LOOP;

      v_Trans_Insured(j).Contract_Id := Indeminfo.Trans_Contract_Id;
      v_Trans_Insured(j).Partition_No := Indeminfo.Trans_Partition_No;
      j := j + 1;

      EXIT WHEN(Indeminfo.Trans_Contract_Id IS NULL OR v_Exit);

      Koc_Clm_Hlth_Utils.Getpolinfoforindemnity(Indeminfo.Trans_Contract_Id,
                                                Indeminfo.Trans_Partition_No,
                                                NULL,
                                                Cur);

      FETCH Cur
        INTO Policyinfo;

      CLOSE Cur;

      Vv_Date          := Policyinfo.Term_End_Date;
      Vv_Partittion_No := Indeminfo.Trans_Partition_No;

      Getindemtotalsmdf(Indeminfo.Trans_Contract_Id,
                        Indeminfo.Trans_Partition_No,
                        Indeminfo.Claim_Inst_Type,
                        Indeminfo.Claim_Inst_Loc,
                        Indeminfo.Country_Group,
                        Indeminfo.Cover_Code,
                        Policyinfo.Package_Id,
                        Policyinfo.Package_Date,
                        Policyinfo.Term_End_Date,
                        p_User_Id,
                        Indeminfo.Is_Pool_Cover,
                        Indeminfo.Is_Special_Cover,
                        Cur);

      FETCH Cur
        INTO Indeminfo;

      IF Cur%NOTFOUND THEN
        Dbms_Output.Put_Line('trans indem info bulunamadi.');

        CLOSE Cur;

        EXIT;
      ELSE
        NULL;
      END IF;

      CLOSE Cur;
    END LOOP;
  END;
