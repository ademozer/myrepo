355577538
288

  SELECT *     
      FROM Koc_Clm_Hlth_Indem_Totals
     WHERE Contract_Id = 355577538
       AND Partition_No = 288
       AND Package_Id = 255194
       AND Package_Date = TO_DATE('12/31/2017','MM/DD/YYYY')
      -- AND Indemnity_Payment_Type = 'DEFA'
      -- AND Main_Or_Sub_Cov = 'ALT'
      -- AND Nvl(Is_Valid, 0) = 1
   --   AND Validity_Start_Date <= Trunc(Pdate)
    --   AND (Validity_End_Date >= Trunc(Pdate) OR Validity_End_Date IS NULL)
      -- AND Rownum < 2;
      
       SELECT *     
      FROM Koc_Clm_Indem_Total_Rules
        WHERE Package_Id = 255194
       AND Package_Date = TO_DATE('12/31/2017','MM/DD/YYYY')
