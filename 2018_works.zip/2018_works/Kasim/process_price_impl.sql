--ibrahimk karma projesi i�in
  FUNCTION Gettdaprocesspriceimpl(p_Institute_Code          NUMBER,
                                  p_City_Code               VARCHAR2,
                                  p_Proc_Code_Main          NUMBER,
                                  p_Proc_Code_Sub1          NUMBER,
                                  p_Proc_Code_Sub2          NUMBER,
                                  p_Date                    DATE,
                                  p_Is_Vat_Included         NUMBER DEFAULT 1,
                                  p_Group_Code              VARCHAR2,
                                  p_Is_Tss_Oss              NUMBER DEFAULT 0,
                                  p_Is_Ahek                 NUMBER DEFAULT 0,
                                  p_Contract_Id             NUMBER,
                                  p_Partition_No            NUMBER,
                                  p_Is_Refferal             NUMBER DEFAULT 0,
                                  p_Doctor_Code             NUMBER,
                                  p_Is_Robotic_Surgery      NUMBER DEFAULT 0,
                                  p_Is_Laparoscopic_Surgery NUMBER DEFAULT 0)
    RETURN NUMBER IS

    CURSOR c_Bagli_Islm IS
      SELECT h.Child_Process_Code_Main,
             h.Child_Process_Code_Sub1,
             h.Child_Process_Code_Sub2,
             h.Child_Discount_Group_Code,
             h.Parent_Process_Code_Main,
             h.Parent_Process_Code_Sub1,
             h.Parent_Process_Code_Sub2,
             h.Parent_Discount_Group_Code
        FROM Koc_Cc_Hlth_Tda_Proc_List_Hie h
       WHERE h.Parent_Process_Code_Main = p_Proc_Code_Main
         AND h.Parent_Process_Code_Sub1 = p_Proc_Code_Sub1
         AND h.Parent_Process_Code_Sub2 = p_Proc_Code_Sub2
         AND h.Validity_Start_Date <= p_Date
         AND Nvl(h.Validity_End_Date, p_Date) >= p_Date;

    CURSOR c_Tda_Proc(c_Proc_Code_Main IN NUMBER,
                      c_Proc_Code_Sub1 IN NUMBER,
                      c_Proc_Code_Sub2 IN NUMBER) IS
      SELECT Proc.Discount_Group_Code,
             Proc.Tda_Process_Type,
             Proc.Tda_Coefficient,
             Agg.Agreement_Code,
             Proc.Process_Group
        FROM Koc_Cc_Hlth_Tda_Proc_List     Proc,
             Koc_Cc_Hlth_Tda_Dicnt_Agg_Rel Agg
       WHERE Proc.Process_Code_Main = c_Proc_Code_Main
         AND Proc.Process_Code_Sub1 = c_Proc_Code_Sub1
         AND Proc.Process_Code_Sub2 = c_Proc_Code_Sub2
         AND Proc.Validity_Start_Date <= p_Date
         AND Nvl(Proc.Validity_End_Date, p_Date) >= p_Date
         AND Proc.Discount_Group_Code = Agg.Discount_Code(+)
         AND Agg.Validity_End_Date IS NULL;

    CURSOR c_Inst_Val(Cp_Discount_Group_Code Koc_Cc_Hlth_Tda_Inst_Val.Discount_Group_Code%TYPE,
                      Cp_Tda_Process_Type    Koc_Cc_Hlth_Tda_Inst_Val.Process_Group%TYPE) IS
      SELECT *
        FROM (SELECT CASE
                       WHEN Nvl(p_Is_Ahek, 0) = 1 THEN
                       --AHEK_ADD_RATE
                        Decode(Ahek_Add_Rate, NULL, Add_Rate, Ahek_Add_Rate)
                       ELSE
                        Add_Rate
                     END Oss_Add_Rate,
                     Add_Unit Oss_Add_Unit,
                     Add_Price Oss_Add_Price,
                     Tss_Add_Unit,
                     Tss_Add_Rate,
                     Tss_Add_Price,
                     Ahek_Add_Rate,
                     NULL AS Group_Code
                FROM Koc_Cc_Hlth_Tda_Inst_Val
               WHERE Institute_Code = p_Institute_Code
                 AND Discount_Group_Code = Cp_Discount_Group_Code
                 AND Validity_Start_Date <= p_Date
                 AND Nvl(Validity_End_Date, p_Date) >= p_Date
                 AND Nvl(Process_Group, '0') = Nvl(Cp_Tda_Process_Type, '0')
              -- AND P_GROUP_CODE                   IS NULL
              UNION
              SELECT CASE
                       WHEN Nvl(p_Is_Ahek, 0) = 1 THEN
                       --AHEK_ADD_RATE
                        Decode(Ahek_Add_Rate, NULL, Add_Rate, Ahek_Add_Rate)
                       ELSE
                        Add_Rate
                     END Oss_Add_Rate,
                     Add_Unit Oss_Add_Unit,
                     Add_Price Oss_Add_Price,
                     Tss_Add_Unit,
                     Tss_Add_Rate,
                     Tss_Add_Price,
                     1 Ahek_Add_Rate,
                     Group_Code
                FROM Koc_Cc_Hlth_Tda_Inst_Val_Gr
               WHERE Institute_Code = p_Institute_Code
                 AND Discount_Group_Code = Cp_Discount_Group_Code
                 AND Validity_Start_Date <= p_Date
                 AND Nvl(Validity_End_Date, p_Date) >= p_Date
                 AND Nvl(Process_Group, '0') = Nvl(Cp_Tda_Process_Type, '0')
                 AND Group_Code = Nvl(p_Group_Code, 'XXX'))
       WHERE Rownum < 2
       ORDER BY Group_Code DESC NULLS LAST;

    c_Tda_Proc_Rec   c_Tda_Proc%ROWTYPE;
    c_Bagli_Islm_Rec c_Bagli_Islm%ROWTYPE;
    c_Inst_Val_Rec   Alz_Hlth_Karma_Utils.Price_Return;
    Institutinfo     Koc_v_Clm_Suppliers_Main%ROWTYPE;
    Cur              Refcur;

    v_Tda_Date       DATE;
    v_Tax_Rate       NUMBER;
    v_City_Price     NUMBER;
    v_Tss_Price      NUMBER;
    v_Price          NUMBER;
    v_City_Code      VARCHAR2(3);
    v_Country_Code   VARCHAR2(3) := 'TR';
    v_Values         CLOB;
    v_Is_Academic    NUMBER;
    v_Tpa_Coefficent NUMBER; --ademo gorki
  BEGIN
    v_Values := 'p_Institute_Code:' || p_Institute_Code || Chr(10) ||
                'p_City_Code:' || p_City_Code || Chr(10) ||
                'p_Proc_Code_Main:' || p_Proc_Code_Main || Chr(10) ||
                'p_Proc_Code_Sub1:' || p_Proc_Code_Sub1 || Chr(10) ||
                'p_Proc_Code_Sub2:' || p_Proc_Code_Sub2 || Chr(10) ||
                'p_Date:' || p_Date || Chr(10) || 'p_Is_Vat_Included:' ||
                p_Is_Vat_Included || Chr(10) || 'p_Group_Code:' ||
                p_Group_Code || Chr(10) || 'p_Is_Tss_Oss:' || p_Is_Tss_Oss ||
                Chr(10) || 'p_Is_Ahek:' || p_Is_Ahek || Chr(10) ||
                'p_Contract_Id:' || p_Contract_Id || Chr(10) ||
                'p_Partition_No:' || p_Partition_No || Chr(10) ||
                'p_Is_Refferal:' || p_Is_Refferal || Chr(10) ||
                'p_Doctor_Code:' || p_Doctor_Code || Chr(10) ||
                'p_Is_Robotic_Surgery:' || p_Is_Robotic_Surgery || Chr(10) ||
                'p_Is_Laparoscopic_Surgery:' || p_Is_Laparoscopic_Surgery;
    --INSERT INTO Tmp_Karma_Prie_Parameters (Function_Name, Paramter, Datae) VALUES ('Gettdaprocesspriceimpl', v_Values, SYSDATE);

    Koc_Clm_Hlth_Utils.Getinstitutinfobycode(p_Institute_Code, p_Date, Cur);

    FETCH Cur
      INTO Institutinfo;

    CLOSE Cur;

    Customer.Alz_Hlth_Karma_Utils.Get_Inst_City_Code(p_Institute_Code,
                                                     v_City_Code,
                                                     v_Country_Code);
    IF v_City_Code IS NULL THEN
      v_City_Code    := p_City_Code;
      v_Country_Code := 'TR';
    END IF;

    OPEN c_Bagli_Islm;
    FETCH c_Bagli_Islm
      INTO c_Bagli_Islm_Rec;
    CLOSE c_Bagli_Islm;
    ---�BRAH�M PREP KAPA/A�
    IF c_Bagli_Islm_Rec.Child_Process_Code_Main IS NOT NULL THEN
      --ba�l� i�lem tan�ml� ise
      OPEN c_Tda_Proc(c_Bagli_Islm_Rec.Child_Process_Code_Main,
                      c_Bagli_Islm_Rec.Child_Process_Code_Sub1,
                      c_Bagli_Islm_Rec.Child_Process_Code_Sub2);
      FETCH c_Tda_Proc
        INTO c_Tda_Proc_Rec;
      CLOSE c_Tda_Proc;

      c_Inst_Val_Rec := Alz_Hlth_Karma_Utils.Get_Price_Type(p_Institute_Code,
                                                            c_Bagli_Islm_Rec.Child_Process_Code_Main,
                                                            c_Bagli_Islm_Rec.Child_Process_Code_Sub1,
                                                            c_Bagli_Islm_Rec.Child_Process_Code_Sub2,
                                                            p_Date,
                                                            p_Group_Code,
                                                            p_Contract_Id,
                                                            p_Partition_No,
                                                            p_Is_Tss_Oss,
                                                            p_Is_Ahek,
                                                            p_Is_Refferal);
      IF c_Inst_Val_Rec.Price_Type IS NULL THEN
        OPEN c_Tda_Proc(c_Bagli_Islm_Rec.Parent_Process_Code_Main,
                        c_Bagli_Islm_Rec.Parent_Process_Code_Sub1,
                        c_Bagli_Islm_Rec.Parent_Process_Code_Sub2);
        FETCH c_Tda_Proc
          INTO c_Tda_Proc_Rec;
        CLOSE c_Tda_Proc;

        c_Inst_Val_Rec := Alz_Hlth_Karma_Utils.Get_Price_Type(p_Institute_Code,
                                                              c_Bagli_Islm_Rec.Parent_Process_Code_Main,
                                                              c_Bagli_Islm_Rec.Parent_Process_Code_Sub1,
                                                              c_Bagli_Islm_Rec.Parent_Process_Code_Sub2,
                                                              p_Date,
                                                              p_Group_Code,
                                                              p_Contract_Id,
                                                              p_Partition_No,
                                                              p_Is_Tss_Oss,
                                                              p_Is_Ahek,
                                                              p_Is_Refferal);
      END IF;
    ELSE
      --ba�l� i�lem tan�m� yok ise

      ---�BRAH�M PREP KAPA/A�
      OPEN c_Tda_Proc(p_Proc_Code_Main, p_Proc_Code_Sub1, p_Proc_Code_Sub2);
      FETCH c_Tda_Proc
        INTO c_Tda_Proc_Rec;
      CLOSE c_Tda_Proc;

      c_Inst_Val_Rec := Alz_Hlth_Karma_Utils.Get_Price_Type(p_Institute_Code,
                                                            p_Proc_Code_Main,
                                                            p_Proc_Code_Sub1,
                                                            p_Proc_Code_Sub2,
                                                            p_Date,
                                                            p_Group_Code,
                                                            p_Contract_Id,
                                                            p_Partition_No,
                                                            p_Is_Tss_Oss,
                                                            p_Is_Ahek,
                                                            p_Is_Refferal);
    END IF; ---�BRAH�M PREP KAPA/A�
    --VERG� ORANI
    IF Nvl(Institutinfo.Is_Vat_Included, 0) = 1 --Nvl(p_Is_Vat_Included, 0) = 1
     THEN
      v_Tax_Rate := 1 + Koc_Clm_Hlth_Utils.Gettaxrate(8, p_Date);
    ELSE
      v_Tax_Rate := 1;
    END IF;

    v_Is_Academic := Alz_Hlth_Karma_Utils.Get_Academic_Staff(p_Institute_Code,
                                                             p_Doctor_Code,
                                                             p_Date);

    IF v_Is_Academic = 1 AND Nvl(c_Inst_Val_Rec.Academic_Add_Rate, 0) <> 0 THEN
      c_Inst_Val_Rec.Oss_Add_Rate := Nvl(c_Inst_Val_Rec.Academic_Add_Rate,
                                         0);

      c_Inst_Val_Rec.Tss_Add_Rate := Nvl(c_Inst_Val_Rec.Academic_Add_Rate,
                                         0);
    END IF;

    SELECT MAX(a.Tda_Date)
      INTO v_Tda_Date
      FROM Koc_Cc_Hlth_Inst_Tda_Date a
     WHERE a.Institute_Code = p_Institute_Code
       AND a.Tda_Date <= p_Date;

    IF v_Tda_Date IS NULL THEN
      v_Tda_Date := p_Date;
    END IF;

    IF c_Tda_Proc_Rec.Agreement_Code = 'TTB' THEN
      --  �L KATSAYISI
      v_City_Price := Koc_Clm_Hlth_Trnx.Gettdacityprice(v_Country_Code,
                                                        v_City_Code,
                                                        c_Tda_Proc_Rec.Tda_Process_Type,
                                                        p_Institute_Code,
                                                        v_Tda_Date,
                                                        p_Date);
    ELSIF c_Tda_Proc_Rec.Agreement_Code = 'SGK' THEN
      --  TDA KATSAYISI

      v_Tss_Price := Koc_Clm_Hlth_Trnx.Gettdacityprice(v_Country_Code,
                                                       0,
                                                       'TSS',
                                                       0,
                                                       v_Tda_Date,
                                                       p_Date);
    END IF;

    --
    /*   dbms_output.put_line('P_IS_TSS_OSS:'||P_IS_TSS_OSS);
    dbms_output.put_line('V_TAX_RATE:'||V_TAX_RATE);
    dbms_output.put_line('C_TDA_PROC_REC.TDA_PROCESS_TYPE:'||C_TDA_PROC_REC.TDA_PROCESS_TYPE);
    dbms_output.put_line('P_INSTITUTE_CODE:'||P_INSTITUTE_CODE);
    dbms_output.put_line('V_TDA_DATE:'||V_TDA_DATE);
    dbms_output.put_line('V_CITY_PRICE:'||V_CITY_PRICE);
    dbms_output.put_line('V_TSS_PRICE:'||V_TSS_PRICE);
    dbms_output.put_line('AGREEMENT_CODE:'||C_TDA_PROC_REC.AGREEMENT_CODE);
    dbms_output.put_line('=======================');*/

    --

    IF Nvl(p_Is_Tss_Oss, 0) = 0 --�SS poli�esi
     THEN
      IF c_Tda_Proc_Rec.Agreement_Code = 'CARI' THEN
        IF Nvl(c_Inst_Val_Rec.Oss_Add_Unit, 0) <> 0 THEN
          v_Price := c_Tda_Proc_Rec.Tda_Coefficient *
                     c_Inst_Val_Rec.Oss_Add_Unit * v_Tax_Rate;
        ELSIF Nvl(c_Inst_Val_Rec.Oss_Add_Price, 0) <> 0 THEN
          v_Price := c_Inst_Val_Rec.Oss_Add_Price * v_Tax_Rate;
        ELSIF Nvl(c_Inst_Val_Rec.Oss_Add_Rate, 0) <> 0 THEN
          v_Price := c_Tda_Proc_Rec.Tda_Coefficient *
                     c_Inst_Val_Rec.Oss_Add_Rate * v_Tax_Rate;
        END IF;
      ELSIF c_Tda_Proc_Rec.Agreement_Code = 'TTB' THEN
        --
        IF Nvl(c_Inst_Val_Rec.Oss_Add_Unit, 0) <> 0 THEN
          v_Price := c_Inst_Val_Rec.Oss_Add_Unit * v_City_Price *
                     v_Tax_Rate;
        ELSIF Nvl(c_Inst_Val_Rec.Oss_Add_Price, 0) <> 0 THEN
          v_Price := c_Inst_Val_Rec.Oss_Add_Price * v_Tax_Rate;
        ELSIF Nvl(c_Inst_Val_Rec.Oss_Add_Rate, 0) <> 0 THEN
          v_Price := c_Tda_Proc_Rec.Tda_Coefficient *
                     c_Inst_Val_Rec.Oss_Add_Rate * v_City_Price *
                     v_Tax_Rate;
        END IF;
      ELSIF c_Tda_Proc_Rec.Agreement_Code = 'SGK' THEN
        --
        IF Nvl(c_Inst_Val_Rec.Oss_Add_Unit, 0) <> 0 THEN
          v_Price := c_Inst_Val_Rec.Oss_Add_Unit * v_Tss_Price * v_Tax_Rate;
        ELSIF Nvl(c_Inst_Val_Rec.Oss_Add_Price, 0) <> 0 THEN
          v_Price := c_Inst_Val_Rec.Oss_Add_Price * v_Tax_Rate;
        ELSIF Nvl(c_Inst_Val_Rec.Oss_Add_Rate, 0) <> 0 THEN
          v_Price := c_Tda_Proc_Rec.Tda_Coefficient *
                     c_Inst_Val_Rec.Oss_Add_Rate * v_Tss_Price * v_Tax_Rate;
        END IF;
      END IF;
    ELSIF Nvl(p_Is_Tss_Oss, 0) > 0 --TSS poli�esi
     THEN
      /*-- Dilek Altunba� 17/03/2017
      IF NOT (p_Is_Tss_Oss = 0.001 AND c_Tda_Proc_Rec.Agreement_Code = 'SGK')
      THEN
          --opustan gelmiyorsa kdv hesaplanmas�n
          v_Tax_Rate := 1;
      END IF;*/

      IF c_Tda_Proc_Rec.Agreement_Code = 'CARI' THEN
        v_Price := c_Tda_Proc_Rec.Tda_Coefficient *
                   c_Inst_Val_Rec.Tss_Add_Rate; --* v_Tax_Rate;-- TSS �r�nlerinde KDV eklenmesi i�in de�i�tirildi.CA=T3663795 - Dilek Altunba� - 06/03/2017
      ELSIF c_Tda_Proc_Rec.Agreement_Code = 'TTB' THEN
        --
        IF Nvl(c_Inst_Val_Rec.Tss_Add_Unit, 0) <> 0 THEN
          v_Price := c_Inst_Val_Rec.Tss_Add_Unit * v_City_Price; --  * v_Tax_Rate; -- TSS �r�nlerinde KDV eklenmesi i�in de�i�tirildi.CA=T3663795 - Dilek Altunba� - 06/03/2017
        ELSIF Nvl(c_Inst_Val_Rec.Tss_Add_Price, 0) <> 0 THEN
          v_Price := c_Inst_Val_Rec.Tss_Add_Price; -- * v_Tax_Rate; -- TSS �r�nlerinde KDV eklenmesi i�in de�i�tirildi.CA=T3663795 - Dilek Altunba� - 06/03/2017
        ELSIF Nvl(c_Inst_Val_Rec.Tss_Add_Rate, 0) <> 0 THEN
          v_Price := c_Tda_Proc_Rec.Tda_Coefficient *
                     c_Inst_Val_Rec.Tss_Add_Rate * v_City_Price; -- * v_Tax_Rate; -- TSS �r�nlerinde KDV eklenmesi i�in de�i�tirildi.CA=T3663795 - Dilek Altunba� - 06/03/2017
        END IF;
      ELSIF c_Tda_Proc_Rec.Agreement_Code = 'SGK' THEN
        IF Nvl(c_Inst_Val_Rec.Tss_Add_Unit, 0) <> 0 THEN
          --v_Price := c_Tda_Proc_Rec.Tda_Coefficient * c_Inst_Val_Rec.Tss_Add_Unit * v_Tss_Price * v_Tax_Rate;
          v_Price := c_Inst_Val_Rec.Tss_Add_Unit * v_Tss_Price * v_Tax_Rate; -- Dilek Altunba� 17/03/2017
        ELSIF Nvl(c_Inst_Val_Rec.Tss_Add_Price, 0) <> 0 THEN
          v_Price :=  /*c_Tda_Proc_Rec.Tda_Coefficient * */
           c_Inst_Val_Rec.Tss_Add_Price * v_Tax_Rate; -- Live'da fiyat hatas� i�in d�zeltme yap�ld�. Dilek Altunba� 22.02.2017
        ELSIF Nvl(c_Inst_Val_Rec.Tss_Add_Rate, 0) <> 0 THEN
          IF Nvl(p_Is_Tss_Oss, 0) > 0.001 THEN
            v_Tax_Rate := 1; --ademo 28.03.2017
            v_Price    := Nvl(p_Is_Tss_Oss, 0) *
                          c_Inst_Val_Rec.Tss_Add_Rate * v_Tax_Rate;
          ELSE
            v_Price := c_Tda_Proc_Rec.Tda_Coefficient *
                       c_Inst_Val_Rec.Tss_Add_Rate * v_Tax_Rate *
                       v_Tss_Price;
          END IF;
        END IF;
      END IF;
      /*  v_Tax_Rate := 1; -- TSS �r�nlerinde KDV eklenmesi i�in de�i�tirildi.CA=T3663795 - Dilek Altunba� - 06/03/2017

      --d DilekA 20170306 T3663795
      IF c_Tda_Proc_Rec.Agreement_Code = 'CARI'
      THEN
          v_Price := c_Tda_Proc_Rec.Tda_Coefficient * c_Inst_Val_Rec.Tss_Add_Rate; --* v_Tax_Rate;-- TSS �r�nlerinde KDV eklenmesi i�in de�i�tirildi.CA=T3663795 - Dilek Altunba� - 06/03/2017
      ELSIF c_Tda_Proc_Rec.Agreement_Code = 'TTB'
      THEN
          --
          IF Nvl(c_Inst_Val_Rec.Tss_Add_Unit, 0) <> 0
          THEN
              v_Price := c_Inst_Val_Rec.Tss_Add_Unit * v_City_Price; --  * v_Tax_Rate; -- TSS �r�nlerinde KDV eklenmesi i�in de�i�tirildi.CA=T3663795 - Dilek Altunba� - 06/03/2017
          ELSIF Nvl(c_Inst_Val_Rec.Tss_Add_Price, 0) <> 0
          THEN
              v_Price := c_Inst_Val_Rec.Tss_Add_Price; -- * v_Tax_Rate; -- TSS �r�nlerinde KDV eklenmesi i�in de�i�tirildi.CA=T3663795 - Dilek Altunba� - 06/03/2017
          ELSIF Nvl(c_Inst_Val_Rec.Tss_Add_Rate, 0) <> 0
          THEN
              v_Price := c_Tda_Proc_Rec.Tda_Coefficient * c_Inst_Val_Rec.Tss_Add_Rate * v_City_Price; -- * v_Tax_Rate; -- TSS �r�nlerinde KDV eklenmesi i�in de�i�tirildi.CA=T3663795 - Dilek Altunba� - 06/03/2017
          END IF;
      ELSIF c_Tda_Proc_Rec.Agreement_Code = 'SGK'

      THEN
          --
          IF Nvl(c_Inst_Val_Rec.Tss_Add_Unit, 0) <> 0
          THEN
              v_Price := c_Tda_Proc_Rec.Tda_Coefficient * c_Inst_Val_Rec.Tss_Add_Unit * v_Tss_Price * v_Tax_Rate;
          ELSIF Nvl(c_Inst_Val_Rec.Tss_Add_Price, 0) <> 0
          THEN
              v_Price :=  \*c_Tda_Proc_Rec.Tda_Coefficient * *\
               c_Inst_Val_Rec.Tss_Add_Price * v_Tax_Rate; -- Live'da fiyat hatas� i�in d�zeltme yap�ld�. Dilek Altunba� 22.02.2017
          ELSIF Nvl(c_Inst_Val_Rec.Tss_Add_Rate, 0) <> 0
          THEN
              IF Nvl(p_Is_Tss_Oss, 0) > 0.001
              THEN
                  v_Price := Nvl(p_Is_Tss_Oss, 0) * c_Inst_Val_Rec.Tss_Add_Rate * v_Tax_Rate;
              ELSE
                  v_Price := c_Tda_Proc_Rec.Tda_Coefficient * c_Inst_Val_Rec.Tss_Add_Rate * v_Tax_Rate * v_Tss_Price;
              END IF;
          END IF;
      END IF;*/
    END IF;

    /* IF nvl(p_is_ahek,0) = 1
       THEN
         v_price := v_price * nvl(C_INST_VAL_REC.ahek_add_rate, 1 );
       END IF;
    */
    IF (Is_Institute_Huv(p_Institute_Code, p_Date) = 1) AND
       (p_Is_Robotic_Surgery = 1 OR p_Is_Laparoscopic_Surgery = 1) THEN
      v_Price := v_Price * Get_Huv_Surgery_Type(p_Proc_Code_Main,
                                                p_Proc_Code_Sub1,
                                                p_Proc_Code_Sub2,
                                                p_Is_Robotic_Surgery,
                                                p_Is_Laparoscopic_Surgery,
                                                p_Date);
    END IF;

    -- ademo gorki_tpa_start 31.03.2017
    v_Tpa_Coefficent := Alz_Tpa_Claim_Utils.Get_Tpa_Coefficent(p_Institute_Code,
                                                               NULL,
                                                               NULL,
                                                               NULL,
                                                               NULL,
                                                               p_Contract_Id,
                                                               p_Date);
    v_Price          := v_Price * v_Tpa_Coefficent;
    -- ademo gorki_tpa_end

    RETURN Round(v_Price, 2);
  END Gettdaprocesspriceimpl;