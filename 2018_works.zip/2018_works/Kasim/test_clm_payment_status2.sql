 KOC_CLM_HLTH_TRNX.Clmpaymentstatus 
 
   SELECT *--SUM(Decode(Substr(Look_Up_Code, 7, 3), 'PES', Parameter, 0)) Pesin_Ilave,
             --SUM(Decode(Substr(Look_Up_Code, 7, 3), 'TAK', Parameter, 0)) Taksit_Ilave
        FROM Koc_Cp_Health_Look_Up
       WHERE (1 = 0 AND Look_Up_Code IN ('YENIISPES', 'YENIISTAK'))
          OR (1 = 1 AND Look_Up_Code IN ('YENILEPES', 'YENILETAK'));
          
          
           SELECT /* a.Payment_Maturity Vade,
             MIN(a.Payment_Order_No) Taksit_No,
             SUM(Nvl(a.Premium_Amount, 0)) Prim_Borcu*/
             a.*
        FROM Koc_Ocp_Payment_Plan a
       WHERE a.Contract_Id = 355577538
         AND a.Reversing_Version IS NULL
        -- AND a.version_no=210
      --   AND a.Payment_Maturity<sysdate
     --  GROUP BY a.Payment_Maturity
       order by 1
       
       
    SELECT *
      --INTO Vseancefactor
      FROM Koc_Oc_Hlth_Pack_Cov_Rel
     WHERE Package_Id = 255194
       AND Package_Date = TO_DATE('12/31/2017','MM/DD/YYYY')
      -- AND Child_Cover_Code = Pcovercode
    --   AND Validity_Start_Date <= Pdate
     --  AND Nvl(Validity_End_Date, Pdate) >= Pdate
      -- AND Rownum < 2;
