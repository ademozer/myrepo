PROCEDURE Get_Provisions(Pp_Contract_Id     NUMBER,
                           Pp_Partition_No    NUMBER,
                           p_Realization_Date DATE,
                           p_User_Id          VARCHAR2,
                           Clmdetail          IN OUT Clmdetailtype,
                           Clmprovision       IN OUT Clmprovisiontype,
                           Clmprocdetail      Clmprocdetailtyp,
                           Clmrejection       Clmrejectiontype,
                           Clmmedicineindem   Clmmedicineindemtype,
                           Clmitemindem       Clmitemindemtype,
                           Clmvaccindem       Clmvaccindemtype,
                           p_Out_Over_Price   OUT VARCHAR2) IS
 ----1.madde-------------------------------------------------------------------------------------- 						   
    CURSOR Curprovsum(p_Claim_Id     NUMBER,
                      p_Sf_No        NUMBER,
                      p_Add_Order_No NUMBER,
                      p_Cover_Code   VARCHAR2) IS
      SELECT b.Claim_Id,
             b.Sf_No,
             b.Add_Order_No,
             b.Cover_Code,
             b.Swift_Code,
             b.Is_Pool_Cover,
             b.Is_Special_Cover,
             SUM(b.Exemption_Amount) Exemption_Amount,
             SUM(b.Provision_Total) Provision_Total,
             SUM(b.Refusal_Amount) Refusal_Amount,
             SUM(b.Request_Amount) Request_Amount
        FROM Koc_Clm_Hlth_Provisions b
       WHERE b.Claim_Id = p_Claim_Id
         AND b.Sf_No = p_Sf_No
         AND b.Add_Order_No = p_Add_Order_No
         AND b.Cover_Code = p_Cover_Code
       GROUP BY b.Claim_Id,
                b.Sf_No,
                b.Add_Order_No,
                b.Cover_Code,
                b.Swift_Code,
                b.Is_Pool_Cover,
                b.Is_Special_Cover;
     Recprovsum Curprovsum%ROWTYPE;				
    /*clm_transa insert edilirken kullanılıyor. dolayısı ile burada olmasına gerek yok. insertClaimTrans sub rutinine taşınmalı ademo. backlog da 34.p ademo
	     Provision_Total, Refusal_Amount, Request_Amount => clm_trans
		 Exemption_Amount => koc_clm_trans_ext
	    
	*/
    
    v_Auth_Cnt NUMBER;  -- bu commentli kullanımlıyor. ademo.
    v_Auth     VARCHAR2(200); -- bu commentli kullanımlıyor. ademo.
    ------------- 2. madde -----------------------------------------------------------------------------------------------
    CURSOR Curclaimsum(p_Claim_Id     NUMBER,
                       p_Sf_No        NUMBER,
                       p_Add_Order_No NUMBER) IS
      SELECT b.Claim_Id,
             b.Sf_No,
             b.Add_Order_No,
             SUM(b.Exemption_Amount) Exemption_Amount,
             SUM(b.Provision_Total) Provision_Total,
             SUM(b.Refusal_Amount) Refusal_Amount,
             SUM(b.Request_Amount) Request_Amount
        FROM Koc_Clm_Hlth_Provisions b
       WHERE b.Claim_Id = p_Claim_Id
         AND b.Sf_No = p_Sf_No
         AND b.Add_Order_No = p_Add_Order_No
       GROUP BY b.Claim_Id, b.Sf_No, b.Add_Order_No;
  
    --
    Recclaimsum                Curclaimsum%ROWTYPE;
	/*
	   checkAuthLimit subrutinine (backlogda 38. madde) taşınabilir.	   
	   provision_total, request_amount => Koc_Clm_Hlth_Prov_Limit
	   
	*/
    p_Raise                    VARCHAR2(32000); 
    /* 
		log takip maksatlı kullanılmış.  ademo
	    backlog referansları 
		18   => setStatusCode öncesi
		34.g => getSubPackageInfo sonrası
		34.m => insertClaimProcess öncesi
		
	 */
    v_Err                      VARCHAR2(32000);
	/* 
		log takip maksatlı kullanılmış.  ademo
	    backlog referansları 		
		34.l => insertClaimRejects öncesi		
	 */
    v_File_Agreement_Code      VARCHAR2(10) := 'X'; -- kullanılmıyor. admemo 
    i                          NUMBER := 1;  
    j                          NUMBER;
    Jj                         NUMBER;
    p_Contract_Id              NUMBER := Pp_Contract_Id;
    p_Partition_No             NUMBER := Pp_Partition_No;
	/*
	  i,j,Jj döngü için kullanılıyor.
	  p_Contract_Id, p_Partition_No parametre aktarımı için kullanılmış. 
	  backlog referansları 
	  12.d => Koc_Clm_Hlth_Utils.Getpackageinfoforindem(p_Contract_Id,p_Partition_No,...)
	  12.e => Koc_Clm_Hlth_Utils.Getpolinfoforindemnity(p_Contract_Id,p_Partition_No,...,p_Package_Id, p_Package_Date,...)
	  12.f => Koc_Clm_Hlth_Utils.Getpolinfoforindemnity(p_Contract_Id,p_Partition_No,...) 
	  14   => Koc_Clm_Hlth_Utils.Getpolinfoforindemnity(p_Contract_Id,p_Partition_No,...)
	  23   => INSERT Clm_Pol_Oar {CONTRACT_ID, ...} 
	  24   => INSERT Clm_Pol_Oar {CONTRACT_ID, ...}
	  34.h => Reverseremainig(p_Contract_Id,p_Partition_No,...)
	  34.i => Computeremaning(Policyinfo.Contract_Id, Policyinfo.Partition_No, ...)
	  34.p => Getindemtotals(Policyinfo.Contract_Id, Policyinfo.Partition_No, ...)
	  38   => insert Koc_Clm_Hlth_Prov_Limit {CONTRACT_ID,PARTITITON_NO,...}
	  41   => Send_Provision_Sms(..., p_Contract_Id, p_Partition_No, ... }
	  43.d => Koc_Clm_Hlth_Utils.Getallpolinfoforindemnity(p_Contract_Id, p_Partition_No, ...)
	  43.e => Koc_Clm_Hlth_Utils.Getallpolinfoforindemnity(p_Contract_Id, p_Partition_No, ...)
	  43.h => Checkpolicyforindemnity(p_Contract_Id, p_Partition_No, ..., '1KEZ')  
	  43.i => Checkprovisionforindemnity(p_Contract_Id, p_Partition_No, ..., '1KEZ')
	  43.k => SELECT Koc_Clm_Hlth_Indem_Totals { CONTRACT_ID, PARTITITON_NO, ... }
	  43.n => Getindemtotalsmdf(p_Contract_Id, p_Partition_No, ...)
	  43.t => UPDATE {s_Provision_Amount, r_Exemption_Sum, s_Spend_Total, s_Spend_Day_Seance, s_Exemption_Sum} Koc_Clm_Hlth_Indem_Totals WHERE {CONTRACT_ID, PARTITITON_NO, ...}
	  44.compute remaining
	  44.a => Getindemtotalsmdftmp(p_Contract_Id, p_Partition_No, ...)
	  44.b => Getindemtotalsmdf(p_Contract_Id, p_Partition_No, ...)
	  44.e => Getindemtotalsfromrep(p_Contract_Id, p_Partition_No, ...)
	  44.k => SELECT {NETWORK_ID} Koc_v_Hlth_Insured_Info_Indem WHERE {CONTRACT_ID, PARTITITON_NO, ...}   

	  44.o => Hltprv_Log.Content     := 'sqlerrm              : ' || SQLERRM ||
                                    Chr(10) || 'p_contract_id        : ' ||
                                    p_Contract_Id || Chr(10) ||
                                    'p_partition_no       : ' ||
                                    p_Partition_No || Chr(10) ...


	  44.u => Getindemtotalsmdftmp(p_Contract_Id, p_Partition_No, ...)
           	  Getindemtotalsmdf(p_Contract_Id, p_Partition_No, ...) 

			  44.v => Getoldpolicy(p_Contract_Id, p_Partition_No,  ...)
	          Getindemtotalstmp(v_Old_Contract_Id, v_Old_Partition_No, ...)
			  Getindemtotals(v_Old_Contract_Id, v_Old_Partition_No, ...)
      
	  44.z => UPDATE {r_Exemption_Sum} Koc_Clm_Hlth_Indem_Totals WHERE {CONTRACT_ID, PARTITITON_NO, ...}
	          UPDATE {s_Provision_Amount, s_Spend_Total, s_Spend_Day_Seance , s_Exemption_Sum } Koc_Clm_Hlth_Indem_Totals  WHERE { CONTRACT_ID, PARTITITON_NO, ...}
	          UPDATE {r_Exemption_Sum} Rep_Clm_Hlth_Indem_Totals WHERE {CONTRACT_ID, PARTITITON_NO, ...}			  
			  Updaterelatedcoveronrep(p_Contract_Id, p_Partition_No, ...)
			  Updaterelatedpoolcover(Indeminfo.Contract_Id, 0, ...)
	          Updaterelatedcovermdlr(Indeminfo.Contract_Id, Vv_Partittion_No, ...) 
			  Updaterelatedcover(Indeminfo.Contract_Id, Vv_Partittion_No, ...)
              Alz_Tpa_Core_Utils.Get_Company_Code(p_Contract_Id => p_Contract_Id)
      
	  44.z1   Getindemtotalsmdftmp(Indeminfo.Trans_Contract_Id, Indeminfo.Trans_Partition_No, ...)
              Koc_Clm_Hlth_Utils.Getpolinfoforindemnity(Indeminfo.Trans_Contract_Id, Indeminfo.Trans_Partition_No, ...)
			  Alz_Tpa_Core_Utils.Get_Company_Code(p_Contract_Id => p_Contract_Id)	
			  Hltprv_Log.Content     := 'sqlerrm              : ' || SQLERRM ||
                                      Chr(10) || 'p_contract_id        : ' ||
                                      p_Contract_Id || Chr(10) ||
                                      'p_partition_no       : ' ||
                                      p_Partition_No || Chr(10) ||
              Updaterelatedcovermdlrtmp(Indeminfo.Contract_Id, Vv_Partittion_No, ...)
              Updaterelatedcovertmp(Indeminfo.Contract_Id, Vv_Partittion_No, ...)
              UPDATE {r_Exemption_Sum} Koc_Clm_Hlth_Tmp_Indem_Totals WHERE {CONTRACT_ID, PARTITITON_NO, ...}	
              UPDATE {s_Provision_Amount, s_Spend_Total, s_Spend_Day_Seance , s_Exemption_Sum } Koc_Clm_Hlth_Tmp_Indem_Totals  WHERE { CONTRACT_ID, PARTITITON_NO, ...}			  
      
	  46.a    Updaterelatedcoveronrep(p_Contract_Id, p_Partition_No, ...)
	          UPDATE {r_Exemption_Sum} Rep_Clm_Hlth_Indem_Totals  {CONTRACT_ID, PARTITITON_NO, ...}

	  46.b    UPDATE {r_Exemption_Sum} Koc_Clm_Hlth_Indem_Totals WHERE {CONTRACT_ID, PARTITITON_NO, ...}
	          UPDATE {s_Provision_Amount, s_Spend_Total, s_Spend_Day_Seance , s_Exemption_Sum } Koc_Clm_Hlth_Indem_Totals  WHERE { CONTRACT_ID, PARTITITON_NO, ...}  

      46.c    Updaterelatedpoolcover(Indeminfo.Contract_Id, 0, ...)
              Alz_Tpa_Core_Utils.Get_Company_Code(p_Contract_Id => p_Contract_Id);	  
      	      Hltprv_Log.Content     := 'sqlerrm              : ' ||
                                        SQLERRM || Chr(10) ||
                                        'p_contract_id        : ' ||
                                        p_Contract_Id || Chr(10) ||
                                        'p_partition_no       : ' ||
                                        p_Partition_No || Chr(10) ||
              Updaterelatedcovermdlr(Indeminfo.Contract_Id, Vv_Partittion_No, ...)
              Updaterelatedcover(Indeminfo.Contract_Id, Vv_Partittion_No, ...)
              
	  47.a    UPDATE {r_Exemption_Sum} Koc_Clm_Hlth_Tmp_Indem_Totals WHERE {CONTRACT_ID, PARTITITON_NO, ...}	
              UPDATE {s_Provision_Amount, s_Spend_Total, s_Spend_Day_Seance , s_Exemption_Sum } Koc_Clm_Hlth_Tmp_Indem_Totals  WHERE { CONTRACT_ID, PARTITITON_NO, ...}			
	
      47.b    Updaterelatedcovertmp(Indeminfo.Contract_Id, Vv_Partittion_No, ...)
              Updaterelatedcovermdlrtmp(Indeminfo.Contract_Id, Vv_Partittion_No, ...)
              Hltprv_Log.Content     := 'sqlerrm              : ' || SQLERRM ||
                                      Chr(10) || 'p_contract_id        : ' ||
                                      p_Contract_Id || Chr(10) ||
                                      'p_partition_no       : ' ||
                                      p_Partition_No || Chr(10) ||			  
			  Alz_Tpa_Core_Utils.Get_Company_Code(p_Contract_Id => p_Contract_Id);
			  
	*/
    Cur                        Refcur; 
	/* bir çok yerde geçiyor. genelde prosedür çağrımlarında kullanılmış. ademo. 
	*/
    Policyinfo                 Koc_v_Hlth_Insured_Info_Indem%ROWTYPE;
	/*  Policyinfo.Contract_Id,     --> elimizde var (p_Contract_Id)
        Policyinfo.Partition_No     --> elimizde var (p_Partiton_No)
		Policyinfo.Product_Id,      --> ocp_policy_contracts.Product_Id
		Policyinfo.Contract_Status, --> ocp_policy_contracts.Contract_Status
		Policyinfo.Term_Start_Date, --> koc_ocp_partitions_ext.Term_Start_Date
		Policyinfo.Term_End_Date,   --> koc_ocp_partitions_ext.Term_Start_Date | koc_ocp_partitions_ext.business_start_date | ocp_policy_versions.business_start_date
		Policyinfo.Version_No       --> koc_ocp_partitions_ext.Version_No
		Policyinfo.Policy_Ref,      --> ocp_policy_bases.Policy_Ref
		Policyinfo.Package_Id,      --> koc_ocp_risk_packages.Package_Id 
		Policyinfo.Package_Date     --> koc_ocp_risk_packages.Package_Date 
		Policyinfo.Oldsys_Policy_No	--> koc_ocp_pol_versions_ext.Oldsys_Policy_No															
		Policyinfo.Partition_Type   --> ocp_partitions.Partition_Type
		Policyinfo.Partner_Id       --> ocp_interested_parties.Partner_Id
		Policyinfo.Group_Code       --> koc_ocp_pol_versions_ext.Group_Code
		Policyinfo.Ip_No            --> ocp_ip_links.Ip_No*/
	/*
	   backlog referansları 
	  12.a  SELECT COUNT Koc_Clm_Hlth_Indem_Totals {v_Clmdetail.Package_Id,v_Clmdetail.Package_Date, Policyinfo.Contract_Id, Policyinfo.Partition_No}

	  12.c  IF Clmdetail(Clmid).Date_Of_Loss = Policyinfo.Term_Start_Date THEN

	  13    Getfirstagent(Policyinfo.Contract_Id)
            Getfirstsubagent(Policyinfo.Contract_Id)    

	  14    IF Policyinfo.Contract_Id IS NULL THEN		

	  15 	Koc_Clm_Hlth_Utils.Getinsuredinfobypartnerid(Policyinfo.Partner_Id, Cur);
	  
	  19    Customer.Alz_Affluent_Customer.Get_Policy_Customer_Value(Policyinfo.Policy_Ref, ...)
	  
	  20    INSERT {..., PACKAGE_ID, PACKAGE_DATE, ... } Koc_Clm_Hlth_Detail VALUES {..., Policyinfo.Package_Id, Policyinfo.Package_Date, ...}
	
      22    IF Policyinfo.Partition_Type = 'KEKS' THEN

      23    INSERT {..., CONTRACT_ID,PRODUCT_ID,CONRACT_STATUS,TERM_START_DATE,TERM_END_DATE,VERSION_NO,POLICY_REF  , ...} 
			Clm_Pol_Bases VALUES{...,  Policyinfo.Contract_Id,
									   Policyinfo.Product_Id,         
									   Policyinfo.Contract_Status,
									   Policyinfo.Term_Start_Date,
									   Policyinfo.Term_End_Date,
									   Policyinfo.Version_No,							
									   Policyinfo.Policy_Ref,...)  
            INSERT {..., CONTRACT_ID, PARTITION_NO, VERSION_NO} Clm_Pol_Oar VALUES {..., Policyinfo.Contract_Id,
																					     Policyinfo.Partition_No,
	  												                                     Policyinfo.Version_No)  
																						 
      24    23.maddedeki insertler burada da var.
			INSERT {..., PRODUCT_ID, TERM_START_DATE, TERM_END_DATE, POLICY_REF, OLDSYS_POLICY_NO, PARTITION_TYPE, ...} 
			Koc_Clm_Subfiles_Ext VALUES(...,Policyinfo.Product_Id,
										    Policyinfo.Term_Start_Date,
										    Policyinfo.Term_End_Date,																
										    Policyinfo.Policy_Ref,
										    Policyinfo.Oldsys_Policy_No,																
										    Policyinfo.Partition_Type,...)
            INSERT {..., VERSION_NO, ...} Clm_Interested_Parties VALUES(..., Policyinfo.Version_No, ...)	
			
	  28     IF Policyinfo.Partition_Type = 'KEKS' THEN
	  
	  30    Checkpolicyforindemnity(Policyinfo.Contract_Id,
								    Policyinfo.Partition_No,
								    Policyinfo.Package_Id,
								    Policyinfo.Package_Date,
								    Trunc(p_Provision_Date),
								    '1KEZ');
	  
	  31	Checkprovisionforindemnity(Policyinfo.Contract_Id,
									   Policyinfo.Partition_No,
									   Policyinfo.Package_Id,
									   Policyinfo.Package_Date,
									   Trunc(p_Provision_Date),
									  '1KEZ');	

            SELECT {Indemnity_Payment_Type} Koc_Clm_Hlth_Indem_Totals WHERE {..., Policyinfo.Contract_Id,
																				  Policyinfo.Partition_No,
																				  Policyinfo.Package_Id,
																				  Policyinfo.Package_Date
                                                                    			,...}									  
	
	  32    Setremaininglimitfor1kez(Policyinfo.Contract_Id, Policyinfo.Partition_No);
	  
	  34.g  Koc_Clm_Hlth_Utils.Getsubpackage(Policyinfo.Contract_Id,
                                             Policyinfo.Partition_No,
                                             Policyinfo.Package_Id,
                                             Policyinfo.Package_Date,
											 ...)
      34.i => Computeremaning(Policyinfo.Contract_Id, Policyinfo.Partition_No, ...)
	  34.p => Getindemtotals(Policyinfo.Contract_Id, Policyinfo.Partition_No, ...)
              SELECT {...} Koc_Oc_Prod_Partition_Rel WHERE {..., Policyinfo.Product_Id,
															     Policyinfo.Partition_Type,
																 Policyinfo.Term_Start_Date,
																 Policyinfo.Term_Start_Date...} 

			  INSERT {..., IP_NO, PARTITION_NO, ...} Clm_Trans VALUES {..., Policyinfo.Ip_No,
											                                 Policyinfo.Partition_No, ...}	

      38      INSERT {...,Group_Code,...} Koc_Clm_Hlth_Prov_Limit	VALUES {..., Policyinfo.Group_Code, ...} 	
	 
      41      Alz_Sms_Exceptions_Pkg.Check_Denied_Sms(...,Policyinfo.Product_Id,..., Policyinfo.Partner_Id,...)

      42      Hltprv_Log.Servicename   := 'PROVIZYON';
              Hltprv_Log.Processinfo   := 'GETPROVIZYON';
              Hltprv_Log.Insuredno     := Policyinfo.Policy_Ref;	
			  
			  Customer.Alz_Affluent_Customer.Get_Policy_Customer(Policyinfo.Policy_Ref, l_Tckn, p_Result);
			  
	  43.d	IF Policyinfo.Contract_Id IS NULL THEN
  	  
	  43.e  IF Policyinfo.Contract_Id IS NULL THEN
									
      43.f  IF Policyinfo.Contract_Id IS NULL THEN  									
              									
      43.g	12.a ile hemen hemen aynı tek fark birinde package bilgisi v_Clmdetail den diğerinde p_Clmdetail den alınıyor
            SELECT COUNT Koc_Clm_Hlth_Indem_Totals {p_Clmdetail.Package_Id,p_Clmdetail.Package_Date, Policyinfo.Contract_Id, Policyinfo.Partition_No} 	  

      43.h  Checkpolicyforindemnity(p_Contract_Id,
									p_Partition_No,
									Policyinfo.Package_Id,
									Policyinfo.Package_Date,
									Trunc(v_Date),
									'1KEZ');	
      43.i  Checkprovisionforindemnity(p_Contract_Id,
									   p_Partition_No,
									   Policyinfo.Package_Id,
									   Policyinfo.Package_Date,
									   Trunc(v_Date),
									   '1KEZ');		
      43.k  SELECT {Claim_Inst_Type} Koc_Clm_Hlth_Indem_Totals WHERE {  Policyinfo.Package_Id
                                                                        Policyinfo.Package_Date}
		  
      43.l  Koc_Health_Policy_Utils5.Get_Prod_Part_Mdlr(Policyinfo.Product_Id,
                                                        Policyinfo.Partition_Type,
                                                        Trunc(p_Realization_Date)); 

      43.m  Vcoverpackageid   := Policyinfo.Package_Id;
            Vcoverpackagedate := Policyinfo.Package_Date;	

      43.n  Getindemtotalsmdf(p_Contract_Id,
							  p_Partition_No,
							  Vclaiminsttype,
							  p_Clmdetail.Claim_Inst_Loc,
							  v_Country_Group,
							  p_Clmprovision.Cover_Code,
							  Policyinfo.Package_Id,
							  Policyinfo.Package_Date,...)

      43.p  34.p ile aynı
            SELECT {...} Koc_Oc_Prod_Partition_Rel WHERE {..., Policyinfo.Product_Id,
															   Policyinfo.Partition_Type,
															   Policyinfo.Term_Start_Date,
															   Policyinfo.Term_Start_Date...}  

      43.r  43.d,43.e,43.f ile aynı 
	        IF Policyinfo.Partition_Type <> 'KEKS' THEN		

	  43.v  Vv_Date          := Policyinfo.Term_End_Date; böyle set edilmiş ama kullanılmamış. 
	  
	  43.y  Getindemtotalsmdf(...,
								Policyinfo.Package_Id,
								Policyinfo.Package_Date,
								Policyinfo.Term_End_Date,...)
	
      44.a  Getindemtotalsmdftmp(...,
								   p_Policyinfo.Package_Id,
								   p_Policyinfo.Package_Date,...)
      
	  44.b	Getindemtotalsmdf(...,
                        p_Policyinfo.Package_Id,
                        p_Policyinfo.Package_Date,..)	

      44.f  SELECT {...} Koc_Oc_Prod_Partition_Rel WHERE {..., Policyinfo.Product_Id,
															   Policyinfo.Partition_Type,
															   Policyinfo.Term_Start_Date,
															   Policyinfo.Term_Start_Date...} 	

	  44.g  IF p_Policyinfo.Partition_Type = 'KEKS' THEN 
	  
	  44.h  43.l ile aynı 
	        Koc_Health_Policy_Utils5.Get_Prod_Part_Mdlr(Policyinfo.Product_Id,
                                                        Policyinfo.Partition_Type,
                                                        Trunc(p_Date));
														
	  44.i	43.m ile aynı
	        Vcoverpackageid   := Policyinfo.Package_Id;
            Vcoverpackagedate := Policyinfo.Package_Date;

      44.m    Expackrow.Product_Id           := Policyinfo.Product_Id;
			  Expackrow.Partition_Type       := Policyinfo.Partition_Type;
			  Expackrow.Contract_Id          := Policyinfo.Contract_Id;
			  Expackrow.Partition_No         := Policyinfo.Partition_No;			  
			  Expackrow.Part_Id              := Policyinfo.Partner_Id; 	

	  44.n  Isnetworkavailableforinst(Policyinfo.Contract_Id,
                                      Policyinfo.Partition_No,
                                      ...)
      
     44.o   p_Policyinfo.Package_Id || Chr(10) ||
		    'package_date         : ' ||
		    p_Policyinfo.Package_Date || Chr(10) 
			
	 44.p   SELECT {...} Koc_Oc_Prod_Package_Rel WHERE {..., Policyinfo.Product_Id,
															 Policyinfo.Partition_Type,
															 Policyinfo.Package_Id,
															 Policyinfo.Group_Code,...} 	

            Koc_Curr_Utils.Retrieve_Currency_Rate(...,
                                                  Trunc(Policyinfo.Policy_Start_Date),
                                                  ...;									  

      44.u  Getindemtotalsmdftmp(...,
                               p_Policyinfo.Package_Id,
                               p_Policyinfo.Package_Date,...)

            Getindemtotalsmdf(...,
                               p_Policyinfo.Package_Id,
                               p_Policyinfo.Package_Date,...)
							   	  
							   
	  44.z  p_Policyinfo.Package_Id || Chr(10) ||
			'package_date         : ' ||
			p_Policyinfo.Package_Date ||

            Vv_Date          := Policyinfo.Term_End_Date;	--kullanılmıyor bu	(43.v)	
			
			Getindemtotalsmdf(...,
			                  Policyinfo.Package_Id,
                              Policyinfo.Package_Date,
                              Policyinfo.Term_End_Date,...) 
							  
	  44.z1 Vv_Date          := Policyinfo.Term_End_Date; -- kullanılmıyor bu boşuna set edilmiş (43.v)
	        
			Getindemtotalsmdftmp(...,
                             Policyinfo.Package_Id,
                             Policyinfo.Package_Date,
                             Policyinfo.Term_End_Date,...)
							 
            p_Policyinfo.Package_Id || Chr(10) ||
                                      'package_date         : ' ||
                                      p_Policyinfo.Package_Date || Chr(10) ||

      46.c	  'package_id           : ' ||
                                        p_Policyinfo.Package_Id || Chr(10) ||
                                        'package_date         : ' ||
                                        p_Policyinfo.Package_Date ||	
      
	  46.d	Vv_Date          := Policyinfo.Term_End_Date; -- kullanılmıyor boşuna set edilmiş (43.v) 							

      46.e  Vv_Date          := Policyinfo.Term_End_Date; -- kullanılmıyor boşuna set edilmiş (43.v)
          

            Getindemtotalsmdf(...,
                            Policyinfo.Package_Id,
                            Policyinfo.Package_Date,
                            Policyinfo.Term_End_Date,
                            ...) 	

      47.b  'package_id           : ' ||
		    p_Policyinfo.Package_Id || Chr(10) ||
		    'package_date         : ' ||
		    p_Policyinfo.Package_Date || Chr(10) ||
             									  
	*/
    Institutinfo               Koc_v_Clm_Suppliers%ROWTYPE;
	/*
	   backlog referansları
	   
	   16 	  IF Institutinfo.Institute_Code IS NULL THEN
	   34.p   INSERT {...,Supp_Id,...} Clm_Trans VALUES {...,Institutinfo.Supp_Id,...}
	   44.j   Alz_Hlth_Karma_Utils.Get_Inst_City_Code(Institutinfo.Institute_Code,
                                                      v_City_Code,   --expackcovrele parametre olarak gidiyor. 
                                                      v_Country_Code --kullanılmıyor
													  
      44.m 	  Expackrow.Claim_Inst_Type      := Nvl(p_Claim_Inst_Type, Institutinfo.Claim_Inst_Type);
			  Expackrow.Claim_Inst_Loc       := Nvl(p_Claim_Inst_Loc, Institutinfo.Claim_Inst_Loc);													
			  Expackrow.Institute_Code       := Institutinfo.Institute_Code;
			  Expackrow.Inst_Cov_Type        := Institutinfo.Inst_Cov_Type;
			  Expackrow.Inst_Validity_Type   := Institutinfo.Inst_Validity_Type;
			  Expackrow.Institute_Type       := Institutinfo.Institute_Type;
              ...
              Expackrow.Institude_Group_Code := Institutinfo.Institute_Group_Code_Type_2; -- selcenk TSS 03/03/2015
              Expackrow.Spec_Group_Code      := Institutinfo.Institute_Group_Code_Type_s; -- selcenk TSS 03/03/2015   

              IF Institutinfo.Institute_Code IN (8, 693) THEN
 		
       44.n	  Isnetworkavailableforinst(...,
                                        Institutinfo.Institute_Code,...)  	
			  
	*/
    Insuredinfo                Koc_v_Health_Partner_Info%ROWTYPE;
	/*
	  15     Koc_Clm_Hlth_Utils.Getinsuredinfobypartnerid(Policyinfo.Partner_Id, Cur);
	         Cur => Insuredinfo
			 burada sorgulanan insured info sadece clm_interested_parties tablosuna kaydedilirken kullanılıyor. 
			 part_id zaten policyinfoda var. buna gerek yok gibi. 
	  24     INSERT {...,Part_Id,Object_Id...} Clm_Interested_Parties VALUES(...,Insuredinfo.Part_Id,Insuredinfo.Part_Id...)
	*/
    Userinfo                   Koc_v_Hlth_Users%ROWTYPE;
	/*
	  10    IF Userinfo.User_Type = 7 AND
      18    Getstatuscode(Clmdetail(Clmid).Status_Code, Userinfo.User_Type	
      26    Getstatuscode(Clmvaccindem(i).Status_Code, Userinfo.User_Type);	  
	  34.a  IF (Userinfo.User_Type = 7 AND
	  34.e	Getstatuscode(Clmprovision(i).Status_Code, Userinfo.User_Type);
	  34.i  ('CPI', 'I', 'H', 'TI') AND Userinfo.User_Type != 7)) AND
	  34.m  Getstatuscode(Clmprocdetail(j).Status_Code, Userinfo.User_Type);
	  34.n  Getstatuscode(Clmmedicineindem(j).Status_Code, Userinfo.User_Type);
      34.o  Getstatuscode(Clmitemindem(j).Status_Code, Userinfo.User_Type);    	  
	*/
    v_Clmprovision             Koc_Clm_Hlth_Provisions%ROWTYPE;
	/*
	  34.a  SELECT {*} Koc_Clm_Hlth_Provisions,Web_Clm_Hlth_Provisions WHERE {Clmdetail(Clmid).Claim_Id,
	                                                                          Clmdetail(Clmid).Sf_No,
				        													  Clmdetail(Clmid).Add_Order_No,
																		      Clmprovision(i).Cover_Code,
																	          Clmprovision(i).Location_Code} 																		
      34.h  v_Clmprovision.Claim_Id IS NOT NULL THEN
            Reverseremainig(...,v_Clmprovision)

      44.g  SELECT {*} Koc_Clm_Hlth_Provisions WHERE {p_Claim_Id
													  p_Sf_No
													  p_Location_Code
													  p_Cover_Code}
			v_Clmprovision.Exemption_Amount := 0;  -- KEKS kaldırılacak	
			v_Parite * Nvl(v_Clmprovision.Provision_Total,			
            v_Parite *(Nvl(v_Clmprovision.Request_Amount,
                  0) - Nvl(v_Clmprovision.Refusal_Amount
            Nvl(v_Clmprovision.Req_Cure_Day_Count,                                           
			v_Parite * Nvl(v_Clmprovision.Exemption_Amount,										            
            IF v_Clmprovision.Exemption_Rate != 1 THEN	
            ((v_Clmprovision.Provision_Total /
             (1 - v_Clmprovision.Exemption_Rate)) +
                  v_Clmprovision.Exemption_Amount)
            v_Clmprovision.Day_Seance;	

      44.l  Alz_Hlth_Karma_Utils.Get_Clm_Is_Referral(p_Claim_Id     => v_Clmprovision.Claim_Id,
                                                     p_Sf_No        => v_Clmprovision.Sf_No,
                                                     p_Add_Order_No => v_Clmprovision.Add_Order_No);			
		
	*/
    v_Clmdetail                Koc_Clm_Hlth_Detail%ROWTYPE;
	/*
	  11    SELECT {v_Clmdetail} Koc_Clm_Hlth_Detail, Web_Clm_Hlth_Detail WHERE { Clmdetail(Clmid).Claim_Id,
																		Clmdetail(Clmid).Sf_No,
																		Clmdetail(Clmid).Add_Order_No}
																		
      
      12    IF v_Clmdetail.Claim_Id IS NOT NULL THEN
  
      12.a  Getpolinfoforindembyclm_Trnx(v_Clmdetail.Claim_Id, nvl(v_Clmdetail.medula_date, p_Provision_Date ), Cur);  
	  
	  12.b  IF v_Clmdetail.Package_Id IS NOT NULL THEN
	        SELECT {COUNT} Koc_Clm_Hlth_Indem_Totals WHERE {...,v_Clmdetail.Package_Id,v_Clmdetail.Package_Date,...}
			Policyinfo.Package_Id   := v_Clmdetail.Package_Id;
            Policyinfo.Package_Date := v_Clmdetail.Package_Date;
			
	  14    IF v_Clmdetail.Claim_Id IS NOT NULL THEN
            IF v_Clmdetail.Package_Id IS NOT NULL THEN
            Policyinfo.Package_Id   := v_Clmdetail.Package_Id;
            Policyinfo.Package_Date := v_Clmdetail.Package_Date;
			
      34.h  IF v_Clmdetail.Claim_Id IS NOT NULL AND            
            Reverseremainig(...,
                            v_Clmdetail,
                            ...);			
	*/
    v_Status_Id                NUMBER;
	/*
	  34.p  SELECT Clm_Status_Id_Seq.Nextval INTO v_Status_Id FROM Dual;
	        INSERT {Status_Id} Clm_Status_History VALUES{v_Status_Id,...}            
	        INSERT {Status_Id,...} Koc_Clm_Status_History_Ext VALUES{v_Status_Id,...}	        
	*/
    v_Clm_Sf_Id                NUMBER;
	/*
	  24.   SELECT Clm_Sf_Id_Seq.Nextval INTO v_Clm_Sf_Id FROM Dual;
			INSERT {...,Sf_Id,...} Clm_Subfiles VALUES {...,v_Clm_Sf_Id,...} 			
	*/
    v_Ext_Reference            VARCHAR2(30) := NULL;
	/*
	  20.   SELECT Clm_Subfiles_Seq.Nextval INTO v_Ext_Reference FROM Dual;
	        v_Ext_Reference := Clmdetail(Clmid).Ext_Reference;
			IF v_Ext_Reference IS NULL THEN  -- yukarıdaki koddan dolayı böyle bir case gerçekleşmez. bu kod iptal edilmeli
			SELECT {Ext_Reference} Clm_Subfiles WHERE {Clmdetail(Clmid).Claim_Id, Clmdetail(Clmid).Sf_No}; -- bu da iptal 
			INSERT {...,Ext_Reference,...} Koc_Clm_Hlth_Detail VALUES {...,v_Ext_Reference,...}
			
	  34.p  IF v_Ext_Reference IS NULL THEN
            SELECT Ext_Reference
              INTO v_Ext_Reference
              FROM Clm_Subfiles
             WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
               AND Sf_No = Clmdetail(Clmid).Sf_No;
            END IF;
			INSERT {...,Ext_Reference} Clm_Trans VALUES {...,v_Ext_Reference}
	*/
    v_Int_Ref                  NUMBER;
	/*
	  34.p  SELECT Clm_Int_Ref_Seq.Nextval INTO v_Int_Ref FROM Dual; 
	        INSERT {...,Int_Ref,...} Clm_Trans VALUES {...,v_Int_Ref,...} 
	*/
    v_Trans_No                 NUMBER;
	/*
	  33    v_Trans_No := Getmaxtransno(Clmdetail(Clmid).Claim_Id, Clmdetail(Clmid).Sf_No) + 1; 
	  
	  34.p  INSERT {...,Trans_No,...} Clm_Trans VALUES {...,v_Trans_No,...}
	        Koc_Clm_Bordro.Alz_Hlth_Bordro_Trans_Log(...,
                                                     v_Trans_No,
                                                     ...}
			INSERT {...,Trans_No,...} Koc_Clm_Trans_Ext VALUES {...,v_Trans_No,...}	
            INSERT {...,Trans_No} Clm_Status_History VALUES {...,v_Trans_No}
            v_Trans_No := v_Trans_No + 1;			
	*/
    v_Provision_Amount         NUMBER := 0;
	/*
	  34.p  v_Provision_Amount := Clmprovision(i).Provision_Total; 
	        v_Provision_Amount := 0;	        
	*/
    v_Exemption_Amount         NUMBER := 0;
	/*
	  34.p  v_Exemption_Amount := Clmprovision(i).Exemption_Amount;
	        v_Exemption_Amount := 0;
	*/
    v_Currency_Exchange_Rate   NUMBER := 1;
	/*
	  34.p  v_Currency_Exchange_Rate := 1;
	        v_Currency_Exchange_Rate := Koc_Curr_Utils.Retrieve_Currency_Rate(Clmdetail(Clmid),...)
			INSERT {...,Currency_Exchange_Rate} Koc_Clm_Trans_Ext {...,v_Currency_Exchange_Rate}			
	*/
    v_Status_Code              VARCHAR2(10);
	/*
	  18    v_Status_Code := Getstatuscode(Clmdetail(Clmid).Status_Code,...)
	  
	  20    INSERT {...,Status_Code,...} Koc_Clm_Hlth_Detail VALUES{...,v_Status_Code,...}
	        UPDATE {...,Status_code,...} Koc_Clm_Hlth_Detail SET {...,v_Status_Code,...}
			
	  38	INSERT {...,Claim_Status,...} Koc_Clm_Hlth_Prov_Limit VALUES{...,v_Status_Code,...}
	  
	  41    v_Status_Code IN ('P')) OR
	        v_Status_Code IN ('R'))) AND Nvl(Glbl_Sendsms, 0) <> 1 THEN

      42    Hltprv_Log.Note  := 'Clmdetail(Clmid).Status_Code: ' || Clmdetail(Clmid)
                                                 .Status_Code || ' v_Status_Code: ' ||
                                                  v_Status_Code;	
            v_Status_Code IN ('P', 'R')) THEN	
            v_Status_Code = 'CP') THEN
            IF (Clmdetail(Clmid)
           .Status_Code IN ('CP', 'CPR') AND v_Status_Code IN ('P', 'R')) THEN 
		   
	*/
    v_Loc_Status_Code          VARCHAR2(10);
	/*
	  34.e  v_Loc_Status_Code := Getstatuscode(Clmprovision(i).Status_Code,
                                 Userinfo.User_Type);		
								 
	  34.k	INSERT {...,Status_Code,...} Koc_Clm_Hlth_Provisions VALUES {...,v_Loc_Status_Code,...}	

	  34.p  IF v_Loc_Status_Code = 'P' THEN
                v_Clm_Status := 'OPEN';
			ELSIF v_Loc_Status_Code IN ('I', 'H', 'TI') THEN
				v_Clm_Status := 'PENDING';
			ELSIF v_Loc_Status_Code = 'C' THEN
				v_Clm_Status := 'CANCELLED';
			ELSIF v_Loc_Status_Code IN ('TAH', 'ODE', 'MK', 'R') THEN
				v_Clm_Status := 'CLOSED';
			ELSE
				v_Clm_Status := NULL;
			END IF;		  
	*/
    v_Proc_Status_Code         VARCHAR2(10);
	/*
	  26    v_Proc_Status_Code := Getstatuscode(Clmvaccindem(i).Status_Code,
                                            Userinfo.User_Type);
			INSERT {...,Status_Code,...} Koc_Clm_Vacc_Indem_Totals VALUES{...,v_Proc_Status_Code,...}	
      
      34.m  v_Proc_Status_Code := Getstatuscode(Clmprocdetail(j)
            INSERT {...,Status_Code,...} Koc_Clm_Hlth_Proc_Detail VALUES{...,v_Proc_Status_Code,...} 
      
	  34.n  v_Proc_Status_Code := Getstatuscode(Clmmedicineindem(j)
			INSERT {...,Status_Code,...} Koc_Clm_Medicine_Indem_Det VALUES{...,v_Proc_Status_Code,...}
			
	  34.o	v_Proc_Status_Code := Getstatuscode(Clmitemindem(j)	
	        INSERT {...,Status_Code,...} Koc_Clm_Hlth_Item_Detail VALUES{...,v_Proc_Status_Code,...}			              			
	*/
    v_Country_Group            NUMBER;
	/*
	  34.f  v_Country_Group   := Koc_Clm_Hlth_Utils.Getcountrygroup(Clmprovision(i).Country_Code);
															  
	  34.i	Computeremaning(...,v_Country_Group,...)
	  
	  34.p  Getindemtotals(...,v_Country_Group,...)
  
      35    Alz_Hltprv_Calc_Rule_Utils.Get_Calculation_Result(...,v_Country_Group,...)
	  
      43 reverse remaining
	  
	  43.a  v_Country_Group := Koc_Clm_Hlth_Utils.Getcountrygroup(p_Clmdetail.Country_Code); 
            			
	  43.k  SELECT {Claim_Inst_Type} Koc_Clm_Hlth_Indem_Totals WHERE {...,v_Country_Group,...}		

      43.n  Getindemtotalsmdf(...,v_Country_Group,...)	  
	  
	  43.s  v_Country_Group := Koc_Clm_Hlth_Utils.Getcountrygroup(p_Clmprovision.Country_Code);
	  
	  43.t  UPDATE {...} Koc_Clm_Hlth_Indem_Totals WHERE {...,v_Country_Group,...}
	  
	  43.u  Updaterelatedcover(...,v_Country_Group,...)
	        Updaterelatedcovermdlr(...,v_Country_Group,...)			          
	*/	
    v_Clm_Status               VARCHAR2(20);
	/*
	  34.p  IF v_Loc_Status_Code = 'P' THEN
				v_Clm_Status := 'OPEN';
			ELSIF v_Loc_Status_Code IN ('I', 'H', 'TI') THEN
				v_Clm_Status := 'PENDING';
			ELSIF v_Loc_Status_Code = 'C' THEN
				v_Clm_Status := 'CANCELLED';
			ELSIF v_Loc_Status_Code IN ('TAH', 'ODE', 'MK', 'R') THEN
				v_Clm_Status := 'CLOSED';
			ELSE
				v_Clm_Status := NULL;
			END IF;
			
			INSERT {...,Clm_Status,...} Clm_Status_History VALUES {...,v_Clm_Status,...}
			
			INSERT {...,Clm_Status,...} Koc_Clm_Status_History_Ext VALUES {...,v_Clm_Status,...}			
	*/
    v_Request_Amount           NUMBER;
	/*
	  34.p  v_Request_Amount   := Clmprovision(i).Request_Amount;
            v_Request_Amount   := 0;		  	
	*/
    v_Reject_Amount            NUMBER;
	/*
	  34.p  v_Reject_Amount    := Clmprovision(i).Refusal_Amount; 
	        v_Reject_Amount    := 0;
	*/
    v_Pay_Clearing_System_Id   NUMBER;
	v_Pay_Curr_Get_Type        VARCHAR2(4);
	/*
	  34.p  SELECT {v_Pay_Clearing_System_Id,v_Pay_Curr_Get_Type} Koc_Oc_Prod_Partition_Rel WHERE {Policyinfo.Product_Id,Policyinfo.Partition_Type,...}
	        v_Currency_Exchange_Rate := Koc_Curr_Utils.Retrieve_Currency_Rate(Clmdetail(Clmid)
                                                                              .Swift_Code,
                                                                              v_Pay_Curr_Get_Type,
                                                                              Trunc(v_Curr_Date),
                                                                              v_Pay_Clearing_System_Id,
                                                                              TRUE);
																			  
	  43.p  SELECT {v_Pay_Clearing_System_Id,v_Pay_Curr_Get_Type} Koc_Oc_Prod_Partition_Rel WHERE {Policyinfo.Product_Id,Policyinfo.Partition_Type,...}
            v_Parite := Koc_Curr_Utils.Retrieve_Currency_Rate(p_Clmprovision.Swift_Code,
                                                        v_Pay_Curr_Get_Type,
                                                        Trunc(v_Curr_Date),
                                                        v_Pay_Clearing_System_Id,
                                                        TRUE) /
                        Koc_Curr_Utils.Retrieve_Currency_Rate(Indeminfo.Swift_Code,
                                                        v_Pay_Curr_Get_Type,
                                                        Trunc(v_Curr_Date),
                                                        v_Pay_Clearing_System_Id,
                                                        TRUE);	

	  44.f	SELECT {v_Pay_Clearing_System_Id,v_Pay_Curr_Get_Type} Koc_Oc_Prod_Partition_Rel WHERE {Policyinfo.Product_Id,Policyinfo.Partition_Type,...}
            v_Parite           := Koc_Curr_Utils.Retrieve_Currency_Rate(p_Swift_Code,
                                                                  v_Pay_Curr_Get_Type,
                                                                  Trunc(v_Curr_Date),
                                                                  v_Pay_Clearing_System_Id,
                                                                  TRUE) /
                            Koc_Curr_Utils.Retrieve_Currency_Rate(Indeminfo.Swift_Code,
                                                                  v_Pay_Curr_Get_Type,
                                                                  Trunc(v_Curr_Date),
                                                                  v_Pay_Clearing_System_Id,
                                                                  TRUE);																	  		
	*/
    
    p_Out_Provision_Amount     NUMBER;	
    p_Out_Day_Seance           NUMBER;	
    p_Out_Exemption_Rate       NUMBER;
    p_Out_Exemption_Sum        NUMBER;
    p_Out_Inst_Exemp_Sum       NUMBER;
	p_r_Day_Seance             NUMBER;
    p_r_Cover_Price            NUMBER;
    p_r_Exemption_Sum          NUMBER; -- kullanılmıyor bu
    p_Inst_Provision_Aval_Code VARCHAR2(4);
    p_Inst_Is_Cover_Val        NUMBER;
	/*
	  34.i  Computeremaning(...,p_Out_Provision_Amount,
	                            p_Out_Day_Seance,
								p_Out_Exemption_Rate,
								p_Out_Exemption_Sum,
								p_Out_Inst_Exemp_Sum,
								p_r_Day_Seance,
                                p_r_Cover_Price,
                                p_Inst_Provision_Aval_Code,
								...);
	        Clmprovision(i).Provision_Total := Nvl(p_Out_Provision_Amount, 0) *
			Clmprovision(i).Day_Seance := Nvl(p_Out_Day_Seance, 0);
			Clmprovision(i).Exemption_Rate := v_Rate_Dh * Nvl(p_Out_Exemption_Rate, 0);
			Clmprovision(i).Exemption_Amount := Nvl(p_Out_Exemption_Sum, 0);
			Clmprovision(i).Inst_Exemption_Amount := Nvl(p_Out_Inst_Exemp_Sum,
			
	  44.y  p_Out_Provision_Amount := Round(c_Provision_Amount * (1 / v_Parite),
	        p_Out_Day_Seance       := c_Day_Seance;	 
			p_Out_Exemption_Rate   := c_Exemption_Rate;
            p_Out_Exemption_Sum    := Round(c_Exemption_Sum * (1 / v_Parite),
            p_Out_Inst_Exemp_Sum   := Round(c_Inst_Exemption_Sum * (1 / v_Parite),
            p_r_Day_Seance  := c_r_Day_Seance;  
            p_r_Cover_Price := Round(c_r_Cover_Price,
            IF p_r_Cover_Price < p_Provision_Amount THEN 
            p_Inst_Is_Cover_Val        := c_Inst_Is_Cover_Val;
            p_Inst_Provision_Aval_Code := c_Inst_Provision_Aval_Code;
            p_Inst_Is_Cover_Val        := c_Inst_Is_Cover_Val;			
	*/
	
    v_Base_Contract_Id         NUMBER;
	/*
	  
	  bu kontroller update_provision servisinde olmalı. 
	  
	  21   v_Base_Contract_Id := Getclaimcontractid(Clmdetail(Clmid).Claim_Id); 
	  
	  23   IF Nvl(v_Base_Contract_Id, 0) != Nvl(p_Contract_Id, 0) AND
	       p_Contract_Id IS NOT NULL AND v_Base_Contract_Id IS NOT NULL THEN
		   
	  24   IF p_Contract_Id IS NOT NULL AND v_Base_Contract_Id IS NULL THEN
	  
	  25   IF v_Base_Contract_Id IS NOT NULL THEN
		   
	*/
    Clmid                      NUMBER;
	/*  bir sayaç olarak kullanılıyor. ilk değeri 1
	
	    6       IF Clmdetail(Clmid).Provision_Date IS NOT NULL THEN
		        p_Pov_Date_Time := To_Date(To_Char(Clmdetail(Clmid).Provision_Date
				
		7       IF Clmdetail(Clmid).Invoice_Date IS NOT NULL THEN
                p_Inv_Date_Time := To_Date(To_Char(Nvl(Clmdetail(Clmid).Date_Of_Loss,
                                             Clmdetail(Clmid).Invoice_Date),	
											 
		8       p_Provision_Date :=nvl(Clmdetail(Clmid).medula_date, p_Provision_Date );--mustafa 
		
		9           v_Date_Of_Loss   := Clmdetail(Clmid).Date_Of_Loss; 
                    v_Date_Of_Loss := Nvl(Clmdetail(Clmid).Provision_Date,
                    Clmdetail(Clmid).Invoice_Date);        
		 
		10
		11
		12
		12.c
		12.e
		12.f
		14
		16
		17
		18
		19
		20
		21
		22
		23
		24
		25
		26
		27
		28
		31
		33
		34.a
		34.c
		34.d
		34.i
		34.k
		34.l
		34.m
		34.n
		34.o
		34.p
		35
		36
		37
		38
		39
		40
		41
		42

	*/
	
    v_Loc_Cover                VARCHAR2(400);
	/*
	    kullanılmıyor.
	*/
	
    p_Provision_Date           DATE;
	/*
	8           p_Provision_Date := Nvl(p_Pov_Date_Time, p_Inv_Date_Time);
                p_Provision_Date :=nvl(Clmdetail(Clmid).medula_date, p_Provision_Date );--mustafa
				
	12          
	12.a
	12.c
	12.d
	12.e
	12.f
	14
	16
	30
	31
	34.g
	34.i
	34.p
	35  
	*/
	
    p_Pov_Date_Time            DATE;
	/*
	6       p_Pov_Date_Time := To_Date(To_Char(Clmdetail(Clmid).Provision_Date,
	        p_Pov_Date_Time := NULL;
			
	12
	12.c    p_Pov_Date_Time := To_Date(To_Char(Nvl(Clmdetail(Clmid)	    
	*/
	
    p_Inv_Date_Time            DATE;
	/*
	7       p_Inv_Date_Time := To_Date(To_Char(Nvl(Clmdetail(Clmid).Date_Of_Loss,
	        p_Inv_Date_Time := NULL;
	8
	12
	12.c
	14	
	*/
	
    v_Date_Of_Loss             DATE;
	/*
	9       v_Date_Of_Loss   := Clmdetail(Clmid).Date_Of_Loss; 
		    IF v_Date_Of_Loss IS NULL THEN
            v_Date_Of_Loss := Nvl(Clmdetail(Clmid).Provision_Date,
                            Clmdetail(Clmid).Invoice_Date);
							
	20
	23
	24	
	*/
	
    v_Realization_Date         DATE;
	/*
	   kullanılmıyor
	*/
	
    v_Letter_No                NUMBER;
	/*
	36    SELECT {v_Letter_No} Koc_Clm_Ltr_Doc_Process
	      INSERT {...,Letter_No...}     Koc_Clm_Ltr_Doc_Process VALUES{...,v_Letter_No,...}
	*/
	
    v_Cnt                      NUMBER;
	/*
	36    SELECT {v_Cnt} Koc_Clm_Ltr_Doc_Process
	      IF v_Cnt <= 0 THEN		  
	*/
	
    Msg                        VARCHAR2(250);
	/*
	kullanılmıyor
	*/
	
    v_Cover_Swf                VARCHAR2(20);
	v_Exch_Date                VARCHAR2(20);
	v_Curr_Date                DATE;
	/*
	34.p   v_Cover_Swf := Indeminfo.Swift_Code;
	       SELECT {v_Cover_Swf, v_Exch_Date} Koc_Oc_Prod_Partition_Rel    
	       IF v_Exch_Date = 'FAT' THEN
		   ELSIF v_Exch_Date = 'OLAY' THEN
		   ELSIF v_Exch_Date = 'TAH' THEN
		   v_Curr_Date := Nvl(Clmdetail(Clmid).Provision_Date,
		   v_Curr_Date := p_Realization_Date;
		   Koc_Curr_Utils.Retrieve_Currency_Rate(...,Trunc(v_Curr_Date),...)
		   
    43.p   v_Cover_Swf := Indeminfo.Swift_Code;
    44.f   v_Cover_Swf := Indeminfo.Swift_Code;
	*/
	
    v_Muallak_Date             DATE;
	v_Trans_Date               DATE;
	/*
	34.p   SELECT {v_Muallak_Date} Koc_Process_Close
	       IF v_Muallak_Date > Trunc(p_Provision_Date) THEN
	       v_Trans_Date := v_Muallak_Date;
		   v_Trans_Date := Trunc(p_Provision_Date);
		   INSERT {...,Trans_Date,...} Clm_Trans {...,v_Trans_Date,...}
	*/
   
    p_Prov_Sys_Time            DATE;
	/*
	34.a    p_Prov_Sys_Time := SYSDATE;
	34.i    Computeremaning(...,p_Prov_Sys_Time,...)
	34.k    INSERT {...,Prov_Date_Time,...} Koc_Clm_Hlth_Provisions VALUES {...,p_Prov_Sys_Time,...}
	35      Alz_Hltprv_Calc_Rule_Utils.Get_Calculation_Result(...,
                                                              p_Prov_Sys_Time);
	*/
	
    v_Reins_Cover_Code         VARCHAR2(20);
	/*
	   kullanılmıyor
	*/
	
    v_Business_Start_Date      DATE;
	/*
	   5.    v_Business_Start_Date := Get_Business_Start_Date(p_Contract_Id, 1); --kullanılmıyor. ademo
	*/
	
    v_First_Agent_Int_Id       NUMBER;
    v_First_Sub_Agent          NUMBER;
	/*
	  13    v_First_Agent_Int_Id := Getfirstagent(Policyinfo.Contract_Id);
            v_First_Sub_Agent    := Getfirstsubagent(Policyinfo.Contract_Id);
	  
	  23    INSERT {...,Agent_Role,...} Clm_Pol_Bases VALUES {...,v_First_Agent_Int_Id,...}
	  
	  24    INSERT {...,Agent_Role,...} Clm_Pol_Bases VALUES {...,v_First_Agent_Int_Id,...}
	        INSERT {...,Agent_Role, Sub_Agent} Koc_Clm_Subfiles_Ext {...,v_First_Agent_Int_Id, v_First_Sub_Agent}
			
	  25    UPDATE {Agent_Role,Sub_Agent} Koc_Clm_Subfiles_Ext SET {v_First_Agent_Int_Id, v_First_Sub_Agent}         
            UPDATE {Agent_Role} Clm_Pol_Bases SET {v_First_Agent_Int_Id}        
	*/
    v_Indem_Date               DATE;
	/*
	  34.p  v_Indem_Date := Nvl(Clmdetail(Clmid).Provision_Date,
	        Getindemtotals(...,
                           v_Indem_Date,...)						   	
	*/
	
    Indeminfo                  Koc_Clm_Hlth_Indem_Totals%ROWTYPE;
	/*
	34.p   v_Cover_Swf := Indeminfo.Swift_Code;
	
	43.m   Vcoverpackageid   := Indeminfo.Sub_Package_Id;
           Vcoverpackagedate := Indeminfo.Sub_Package_Date;

	43.n
	43.o
	43.p
	43.r
	43.t
	43.u
	43.v
	43.y
	44.a
	44.b
	44.c
	44.d
	44.e
	44.f
	44.g
	44.i
	44.m
	44.n
	44.o
	44.p
	44.r
	44.s
	44.t
	44.u
	44.v
	44.z
	44.z1
	46.a    UPDATE {...} Rep_Clm_Hlth_Indem_Totals WHERE {Indeminfo.Exemption_Group}
	        Updaterelatedcoveronrep(...,
                                Indeminfo.Package_Id,
                                Indeminfo.Package_Date,
                                ...,
                                Indeminfo.Is_Pool_Cover,
                                Indeminfo.Is_Special_Cover,
								...)
	46.b
	46.c
	46.d
	46.e
	47.a
	47.b
	46.c
	46.d
	*/
    v_Prov_Total               NUMBER;
	/*
	  v_Prov_Total := Koc_Clm_Hlth_Utils.Getsumprvforstatement(Clmdetail(Clmid)                                                              
      UPDATE {Invoice_Total} Koc_Clm_Hlth_Prov_Statemnt SET {v_Prov_Total}         
	*/
	
    Icur                       Koc_Clm_Hlth_Trnx.Refcur;
	/*
	Cur ile aynı 
	34.p  Getindemtotals(...,
                         Icur);
          FETCH Icur
              INTO Indeminfo; 						 
	*/
    Vacc_Status                VARCHAR2(10);
	/*
	  kullanılmıyor
	*/
    v_Sum_Claim_Amount         NUMBER;
	/*
	34.i v_Sum_Claim_Amount := Nvl(Clmprovision(i).Request_Amount, 0) -
                                v_Tlp_Dlmms_Grkn_Cvr -
                                Nvl(Clmprovision(i).Refusal_Amount, 0);
								
        v_Sum_Claim_Amount  := Nvl(Clmprovision(i).Request_Amount, 0) -
                                   v_Tlp_Dlmms_Grkn_Cvr -
                                   Nvl(Clmprovision(i).Sgk_Amount, 0);	
         
        IF Nvl(v_Sum_Claim_Amount, 0) > 0 AND  -- KEKS
        IF Nvl(v_Sum_Claim_Amount, 0) > Nvl(p_Exemption_Amount, 0) THEN         
		v_Sum_Claim_Amount := Nvl(v_Sum_Claim_Amount, 0) -
		Clmprovision(i).Exemption_Amount := v_Sum_Claim_Amount;
              p_Exemption_Amount := Nvl(p_Exemption_Amount, 0) -
                                    Nvl(v_Sum_Claim_Amount, 0);
              v_Sum_Claim_Amount := 0;
	    IF v_Sum_Claim_Amount < 0 THEN
          v_Sum_Claim_Amount := 0;
        Computeremaning(...,v_Sum_Claim_Amount,...)
		  
	*/
	
    p_Exemption_Amount         NUMBER;
	/*
	   KEKS ile ilgili yerlerde geçiyor. 
	   22   SELECT {p_Exemption_Amount} Web_Clm_Hlth_Provisions,Web_Clm_Hlth_Provisions
            UPDATE {Event_r_Exemption} Koc_Clm_Hlth_Event_Exempt SET { + p_Exemption_Amount }
            
	   28   Find_Exemption_Limit(..., p_Exemption_Amount);
						   
	   34.i  Nvl(p_Exemption_Amount, 0) > 0 THEN
	         IF Nvl(v_Sum_Claim_Amount, 0) > Nvl(p_Exemption_Amount, 0) THEN
             Clmprovision(i).Exemption_Amount := p_Exemption_Amount;
             p_Exemption_Amount := 0;
             p_Exemption_Amount := Nvl(p_Exemption_Amount, 0) -			 
	*/
	
    v_Sgk_Use                  NUMBER(1) := 0;
	/*
	   gereksiz. kaldırılacak
	  29    v_Sgk_Use := 0;
	        IF Nvl(Clmprovision(i).Sgk_Amount, 0) > 0 THEN v_Sgk_Use := 1;
				
	  34.i  IF v_Sgk_Use = 1   -- commentli
	*/
	
    v_Tlp_Dlmms_Grkn_Cvr       NUMBER;
    /*
	  34.i  v_Tlp_Dlmms_Grkn_Cvr := 0;
	        v_Tlp_Dlmms_Grkn_Cvr := Nvl(v_Tlp_Dlmms_Grkn_Cvr, 0) +
			bknz. v_Sum_Claim_Amount	
	*/
	
    Vis1kezused       NUMBER(1) := 0;
	/*
	   31     Vis1kezused := Checkprovisionforindemnity
	          IF Vis1kezused = 0 THEN
			  IF Nvl(Vindempaymtype, 'X') = '1KEZ' THEN
              Vis1kezused := 1; 
			  Set_Glis1kezused(Vis1kezused);
			  
	   32     commentli  kullanım. log maksatlı  
	   
	   34.i   IF Vis1kezused = 1 THEN  
	   
	   43.i   Vis1kezused := Checkprovisionforindemnity
	   
	   43.j	  Vis1kezused := Checkclaimforindemnity
	          Set_Glis1kezused(Vis1kezused);
	*/
	
    Vhaspolicy1kez    NUMBER(1) := 0;
	/*
	  30      Vhaspolicy1kez := Checkpolicyforindemnity
	  
	  31      IF Vhaspolicy1kez = 1 THEN
	  
	  34.i    IF Vhaspolicy1kez = 1 THEN
	  
	  43.h    Vhaspolicy1kez := Checkpolicyforindemnity
	  
	  43.i    F Vhaspolicy1kez = 1 THEN 
	*/
	
    Vindempaymtype    Koc_Clm_Hlth_Indem_Totals.Indemnity_Payment_Type%TYPE;
	/*
	   SELECT {Indemnity_Payment_Type} Koc_Clm_Hlth_Indem_Totals
	   IF Nvl(Vindempaymtype, 'X') = '1KEZ' THEN	   
	*/
	
    Vclaiminsttype    Koc_Clm_Hlth_Indem_Totals.Claim_Inst_Type%TYPE;
	/*
	   34.i   Vclaiminsttype := Clmdetail(Clmid).Claim_Inst_Type;
	          SELECT {Claim_Inst_Type} Koc_Clm_Hlth_Indem_Totals
			  Computeremaning(...,
                        Vclaiminsttype,...)
              						
	   35     Alz_Hltprv_Calc_Rule_Utils.Get_Calculation_Result(...,
                                                          Vclaiminsttype,
                                                          ...);														  
	   43.h   Vclaiminsttype := p_Clmdetail.Claim_Inst_Type;
	          
	   43.k   SELECT {Claim_Inst_Type} Koc_Clm_Hlth_Indem_Totals
	   
	   43.n   Getindemtotalsmdf(...,
                      Vclaiminsttype,...)
	*/
	
    Verrmsg           VARCHAR2(1000);
	Issetremainingrun BOOLEAN := FALSE;
	/*
	  bunlar kullanılmıyor
	*/
	
    v_Rate_Dh       INT := 1;
	/*
	   34.i   v_Rate_Dh := 1;
	          IF Clmdetail(Clmid).Hlth_Srv_Pay = 1 THEN v_Rate_Dh := 0;				  
			  IF Clmdetail(Clmid).Dh_Inst = 1 THEN v_Rate_Dh := 0;
			  Clmprovision(i).Provision_Total := Nvl(p_Out_Provision_Amount, 0) * (1 - (v_Rate_Dh * Nvl(p_Out_Exemption_Rate, 0)));	  
			  Clmprovision(i).Exemption_Rate := v_Rate_Dh * Nvl(p_Out_Exemption_Rate, 0);	
	*/
    Vseqno          NUMBER;
	/*
	  34.m     Vseqno := NULL;
               Vseqno := Nvl(Vseqno, 0) + 1;
			   INSERT {...,Seq_No,...} Koc_Clm_Hlth_Proc_Detail VALUES{...,Vseqno,...}
				
      34.n     Vseqno := NULL;
               Vseqno := Nvl(Vseqno, 0) + 1;
	           INSERT {...,Seq_No,...} Koc_Clm_Medicine_Indem_Det VALUES{...,Vseqno,...}
	           
      34.o     Vseqno := NULL;
               Vseqno := Nvl(Vseqno, 0) + 1;
	           INSERT {...,Seq_No,...} Koc_Clm_Hlth_Item_Detail VALUES{...,Vseqno,...}
	*/
	
    Vsubpackageid   NUMBER;
    Vsubpackagedate DATE;
    /*34.g    Vsubpackageid   := NULL;
               Vsubpackagedate := NULL;
	           Koc_Clm_Hlth_Utils.Getsubpackage(...,
                                       Vsubpackageid,
                                       Vsubpackagedate);
									   
	  34.k   INSERT {Sub_Package_Id,Sub_Package_Date,} Koc_Clm_Hlth_Provision	VALUES{...,Vsubpackageid,Vsubpackagedate,...}						   

	*/
    -- emre.elcik -- 20150408 --
    v_Clm_Check Alz_Clm_Hlth_Error_Log.Is_Checked%TYPE := NULL;
	v_Error_Exp Alz_Clm_Hlth_Error_Log.Explanation%TYPE := NULL;
    --
	/*
	40   Is_Hlth_Clm_Check(...,v_Clm_Check,v_Error_Exp)
	     
    41   IF Nvl(v_Clm_Check, 0) <> 1 THEN 
	*/

    l_Affluent_Flag            NUMBER; -- orhan topal
	/*
	19   l_Affluent_Flag := x_Segment_Kodu;
	     l_Affluent_Flag := NULL;
		   
    20   INSERT {...,Affluent_Flag,...} Koc_Clm_Hlth_Detail VALUES{...,l_Affluent_Flag,...} 
	     UPDATE {...,Affluent_Flag,...} Koc_Clm_Hlth_Detail SET{...,l_Affluent_Flag,...}  	
	*/
	
    x_Segment_Kodu             NUMBER; -- orhan topal
    x_Segment_Aciklamasi       VARCHAR2(200); -- orhan topal
    x_Segment_Ekran_Aciklamasi VARCHAR2(200); -- orhan topal
	l_Tckn                     VARCHAR2(20); -- orhan topal
	p_Result                   NUMBER; -- orhan topal
	Mail_Count                 NUMBER;
	/*
	19   Customer.Alz_Affluent_Customer.Get_Policy_Customer_Value(Policyinfo.Policy_Ref,
                                                               l_Tckn,
                                                               x_Segment_Kodu,
                                                               x_Segment_Aciklamasi,
                                                               x_Segment_Ekran_Aciklamasi); 
         															   
	     SELECT {l_Tckn} Koc_Cp_Partners_Ext
		 
	42   Customer.Alz_Affluent_Customer.Get_Policy_Customer(Policyinfo.Policy_Ref,
                                                            l_Tckn,
                                                            p_Result); 	
         IF (p_Result > 0 AND
         Hltprv_Log.Note          := 'Claim_Id:' || Clmdetail(Clmid)
                                     .Claim_Id || ' - Affluent mi :' ||
                                      p_Result;
									  
        SELECT {Mail_Count} Customer.Alz_Affluent_Mail_Log WHERE{AFFLUENT_YATIS_TALEBI}
		SELECT {Mail_Count} Customer.Alz_Affluent_Mail_Log WHERE{AFFLUENT_YATIS_POZISYONU}
		SELECT {Mail_Count} Customer.Alz_Affluent_Mail_Log WHERE{AFFLUENT_TABURCULUK_TALEBI}
		SELECT {Mail_Count} Customer.Alz_Affluent_Mail_Log WHERE{AFFLUENT_TABURCULUK_PROVIZYONU}
        IF (Mail_Count < 1) THEN		
									 		 
	*/
    
    v_Sgkmi_Redmi_Tutar NUMBER := 0;
	/*
	    bu set edilmiş ama hiç kullanılmamış. kaldırılabilir. 
	34.i   v_Sgkmi_Redmi_Tutar := Nvl(Clmprovision(i).Sgk_Amount, 0);
		
	*/
	
    v_Check_Package     NUMBER := 1;
	/*
	 12.b   SELECT {v_Check_Package}  Koc_Clm_Hlth_Indem_Totals
                IF v_Check_Package > 0 --dosyadaki plan değişmiş mi
     
     43.g   12.b nin aynısı 
	*/

    p_Package_Id   NUMBER;
    p_Package_Date DATE;
    /*
	12.d   Koc_Clm_Hlth_Utils.Getpackageinfoforindem(...,
	                                            p_Package_Id,
                                                p_Package_Date)
												
    12.e   Koc_Clm_Hlth_Utils.Getpolinfoforindemnity(...,
                                                  p_Package_Id,
                                                  p_Package_Date,
                                                  ...);
												  
    41      IF Alz_Sms_Exceptions_Pkg.Check_Denied_Sms(...,
            p_Package_Id     => Clmdetail(Clmid).Package_Id,
            ...)
			
	*/
    v_Complex_Enable VARCHAR2(1); --
    v_Complex_Cover  NUMBER := 0;
	/*
	    SELECT {v_Complex_Enable} Koc_v_Cp_Health_Look_Up WHERE {CALCRULE_E}
	    IF v_Complex_Enable = '1' THEN
		SELECT {v_Complex_Cover} Alz_Hltprv_Bre_Log WHERE {JEST_TEM}
		IF v_Complex_Cover > 0 THEN		
	*/
    
	/*
    vpolicyKFSstatus            number(1);
    vcancerstatus               number(1);
    vASOcoverindxold            number := 0;
    vASOcoverindxnew            number := 0;
    vhlthdetail                 customer.hlth_detail_row_type;
    vASOrefcur                  refcur;
    vASOcover                   koc_clm_hlth_indem_totals%rowtype;
    */
    --
    -------3.madde----------------------------------------------------------------------------
    FUNCTION Getstatuscode(p_Status_Code VARCHAR, p_User_Type NUMBER)
      RETURN VARCHAR2 IS
      v_Result VARCHAR2(10);
    BEGIN
      IF Nvl(p_Status_Code, 'PP') = 'PP' THEN
        v_Result := 'P';
      ELSIF p_Status_Code IN ('PI', 'CPI') AND p_User_Type = 7 THEN
        v_Result := 'I';
      ELSIF p_Status_Code IN ('PI', 'I', 'CPI', 'TI', 'H') AND
            p_User_Type != 7 THEN
        v_Result := 'P';
      ELSIF p_Status_Code IN ('PR', 'CIR', 'CPR') THEN
        v_Result := 'R';
      ELSIF p_Status_Code IN ('CI', 'CP') THEN
        -- OFIS DOKTORU , MEDISER ONAY
        v_Result := 'P';
      ELSE
        v_Result := p_Status_Code;
      END IF;

      RETURN(v_Result);
    END;
  BEGIN
    
    IF Clmdetail.Count = 0 THEN
      GOTO Son;
    END IF;
    -----------4.madde--------------------------------------------------------------------------- 
    Clmid := 1;

    Koc_Clm_Hlth_Utils.Getuserinfobyid(p_User_Id, Cur);

    FETCH Cur
      INTO Userinfo;

    CLOSE Cur;
    ------- 5. madde ---------------------------------------------------------------------------------
    v_Business_Start_Date := Get_Business_Start_Date(p_Contract_Id, 1); --kullanılmıyor. ademo
    i                     := 1;
    ------6.madde------------------------------------------------------------------------------ 
    IF Clmdetail(Clmid).Provision_Date IS NOT NULL THEN
      p_Pov_Date_Time := To_Date(To_Char(Clmdetail(Clmid).Provision_Date,
                                         'dd/mm/yyyy') || ' ' ||
                                 To_Char(SYSDATE, 'hh24:mi:ss'),
                                 'dd/mm/yyyy hh24:mi:ss');
    ELSE
      p_Pov_Date_Time := NULL;
    END IF;
    ----7.madde--------------------------------------------------------------------------------- 
    IF Clmdetail(Clmid).Invoice_Date IS NOT NULL THEN
      p_Inv_Date_Time := To_Date(To_Char(Nvl(Clmdetail(Clmid).Date_Of_Loss,
                                             Clmdetail(Clmid).Invoice_Date),
                                         'dd/mm/yyyy') || ' 13:00:00',
                                 'dd/mm/yyyy hh24:mi:ss');
    ELSE
      p_Inv_Date_Time := NULL;
    END IF;
    -------8.madde-----------------------------------------------------------------------------------
    p_Provision_Date := Nvl(p_Pov_Date_Time, p_Inv_Date_Time);
    p_Provision_Date :=nvl(Clmdetail(Clmid).medula_date, p_Provision_Date );--mustafa
    -------9.madde---------------------------------------------------------------------------------------
    v_Date_Of_Loss   := Clmdetail(Clmid).Date_Of_Loss;

    IF v_Date_Of_Loss IS NULL THEN
      v_Date_Of_Loss := Nvl(Clmdetail(Clmid).Provision_Date,
                            Clmdetail(Clmid).Invoice_Date);
    END IF;
    ----------10.madde--------------------------------------------------------------------------
    -- banko kullanici inceleme statüsünde islem yapamaz.
    IF Userinfo.User_Type = 7 AND
       Nvl(Clmdetail(Clmid).Status_Code, 'PP') IN ('I', 'H') THEN
      GOTO Son;
    END IF;

    -- reverse islemi yapilmasi durumu için
    -- detailin degismemis hali aliniyor
    i := 1;
    ---------- 11. madde -------------------------------------------------------------
    BEGIN
      SELECT *
        INTO v_Clmdetail
        FROM (SELECT a.*
                FROM Web_Clm_Hlth_Detail a
               WHERE a.Claim_Id = Clmdetail(Clmid).Claim_Id
                 AND a.Sf_No = Clmdetail(Clmid).Sf_No
                 AND a.Add_Order_No = Clmdetail(Clmid).Add_Order_No
              UNION
              SELECT a.*
                FROM Koc_Clm_Hlth_Detail a
               WHERE a.Claim_Id = Clmdetail(Clmid).Claim_Id
                 AND a.Sf_No = Clmdetail(Clmid).Sf_No
                 AND a.Add_Order_No = Clmdetail(Clmid).Add_Order_No
                 AND NOT EXISTS
               (SELECT 1
                        FROM Web_Clm_Hlth_Detail b
                       WHERE b.Claim_Id = a.Claim_Id
                         AND b.Sf_No = a.Sf_No
                         AND b.Add_Order_No = a.Add_Order_No));
    EXCEPTION
      WHEN OTHERS THEN
        --- daha önce provizyon almamis ise
        IF Clmdetail(Clmid).Claim_Id IS NULL THEN
          Clmdetail(Clmid).Claim_Id := Genclaimid;
        END IF;
    END;
    --- 12. madde ------------------------------------------------------
	/* bu madde update_provision da çalışmalı
	    SELECT a.*
          FROM Koc_v_Hlth_Insured_Info_Indem a
         WHERE a.Contract_Id = v_Contract_Id
           AND a.Partition_No = v_Partition_No
           AND a.Partner_Id = v_Part_Id
           AND a.Ip_No = v_Ip_No
           AND a.Package_Id = v_Package_Id
           AND a.Package_Date = v_Package_Date;
				   
	    12.a maddesinde koc_clm_hlth_detail,clm_pol_oar,clm_interested_parties tablolarından poliçenin aşağıdaki bilgileri getiriliyor. 
		 partner_id, 
		 contract_id, 
		 partition_no, 
		 sub_company_code, 
		 term_start_date, 
		 term_end_date, 
		 action_code, 
		 package_id, 
		 package_date, 
		 type_of_interest, 
		 partition_type, 
		 product_id, 
		 contract_status, 
		 policy_ref, 
		 policy_start_date, 
		 policy_end_date, 
		 group_code, 
		 ip_no, 
		 agent_int_id, 
		 version_no, 
		 package_status, 
		 term_start_date_time, 
		 term_end_date_time, 
		 endorsement_no, 
		 insured_old_contract, 
		 policy_old_contract, 
		 sub_agent, 
		 oldsys_policy_no, 
		 mailing_address_id, 
		 agent_role, 
		 network_id
	
	*/
    IF v_Clmdetail.Claim_Id IS NOT NULL THEN
      -- Koc_Clm_Hlth_Utils.Getpolinfoforindembyclm(v_Clmdetail.Claim_Id, NULL, Cur);
	  ---- 12.a-----------------------------------------------------------	  
      Getpolinfoforindembyclm_Trnx(v_Clmdetail.Claim_Id,
                                   nvl(v_Clmdetail.medula_date, p_Provision_Date ),
                                   Cur);
      FETCH Cur
        INTO Policyinfo;

      CLOSE Cur;

      /*      mustafaku koç tss
        IF v_Clmdetail.Package_Id IS NOT NULL
      Then
        Policyinfo.Package_Id   := v_Clmdetail.Package_Id;
        Policyinfo.Package_Date := v_Clmdetail.Package_Date;
      END IF;*/
      --mustafaku koç tss
	  ---- 12.b ---------------------------------------------
      IF v_Clmdetail.Package_Id IS NOT NULL THEN

        SELECT COUNT(1)
          INTO v_Check_Package
          FROM Koc_Clm_Hlth_Indem_Totals i
         WHERE i.Package_Id = v_Clmdetail.Package_Id
           AND i.Package_Date = v_Clmdetail.Package_Date
           AND i.Contract_Id = Policyinfo.Contract_Id
           AND i.Partition_No = Policyinfo.Partition_No
           AND i.Is_Valid = 1
           AND Rownum < 2;

        IF v_Check_Package > 0 --dosyadaki plan değişmiş mi
         THEN
          Policyinfo.Package_Id   := v_Clmdetail.Package_Id;
          Policyinfo.Package_Date := v_Clmdetail.Package_Date;
        END IF;
      END IF;
	  
      ------ 12.c -----------------------------------------
      IF Clmdetail(Clmid).Date_Of_Loss = Policyinfo.Term_Start_Date THEN
        IF Clmdetail(Clmid).Provision_Date IS NOT NULL THEN
          p_Pov_Date_Time := To_Date(To_Char(Nvl(Clmdetail(Clmid)
                                                 .Date_Of_Loss,
                                                 Clmdetail(Clmid)
                                                 .Provision_Date),
                                             'dd/mm/yyyy') || ' 13:00:00',
                                     'dd/mm/yyyy hh24:mi:ss');
        ELSE
          p_Inv_Date_Time := To_Date(To_Char(Nvl(Clmdetail(Clmid)
                                                 .Date_Of_Loss,
                                                 Clmdetail(Clmid)
                                                 .Invoice_Date),
                                             'dd/mm/yyyy') || ' 13:00:00',
                                     'dd/mm/yyyy hh24:mi:ss');
        END IF;

        p_Provision_Date := Nvl(p_Pov_Date_Time, p_Inv_Date_Time);
        p_Provision_Date :=nvl(Clmdetail(Clmid).medula_date, p_Provision_Date );--mustafa
      ELSE
        IF Clmdetail(Clmid).Provision_Date IS NOT NULL THEN
          p_Pov_Date_Time := To_Date(To_Char(Nvl(Clmdetail(Clmid)
                                                 .Date_Of_Loss,
                                                 Clmdetail(Clmid)
                                                 .Provision_Date),
                                             'dd/mm/yyyy') || ' 11:00:00',
                                     'dd/mm/yyyy hh24:mi:ss');
        ELSE
          p_Inv_Date_Time := To_Date(To_Char(Nvl(Clmdetail(Clmid)
                                                 .Date_Of_Loss,
                                                 Clmdetail(Clmid)
                                                 .Invoice_Date),
                                             'dd/mm/yyyy') || ' 11:00:00',
                                     'dd/mm/yyyy hh24:mi:ss');
        END IF;

        p_Provision_Date := Nvl(p_Pov_Date_Time, p_Inv_Date_Time);
        p_Provision_Date :=nvl(Clmdetail(Clmid).medula_date, p_Provision_Date );
      END IF;
    ELSE
	----12.d-------------------------------------------------------------------
      Koc_Clm_Hlth_Utils.Getpackageinfoforindem(p_Contract_Id,
                                                p_Partition_No,
                                                p_Provision_Date,
                                                p_Package_Id,
                                                p_Package_Date); --neslihank 31072017 plan değişikliği görmüş planlar için bu kontrol eklenmiştir.

      IF p_Package_Id IS NOT NULL THEN
	------12.e-----------------------------------------------------------------
        Koc_Clm_Hlth_Utils.Getpolinfoforindemnity(p_Contract_Id,
                                                  p_Partition_No,
                                                  Clmdetail(Clmid).Part_Id,
                                                  p_Package_Id,
                                                  p_Package_Date,
                                                  p_Provision_Date,
                                                  Cur);
      ELSE
	-----12.f------------------------------------------------------------------  
        Koc_Clm_Hlth_Utils.Getpolinfoforindemnity(p_Contract_Id,
                                                  p_Partition_No,
                                                  Clmdetail(Clmid).Part_Id,
                                                  p_Provision_Date,
                                                  Cur);
      END IF;

      FETCH Cur
        INTO Policyinfo;

      CLOSE Cur;
    END IF;


    --13.madde----------------------------------------------------------------------------------
    --pdz ile live a al
    v_First_Agent_Int_Id := Getfirstagent(Policyinfo.Contract_Id);
    v_First_Sub_Agent    := Getfirstsubagent(Policyinfo.Contract_Id);
    -- 14.madde --------------------------------------------------------------------------
    -- bu case create provisionda olabilir. update provision ile ilgili kısım 12.maddde  
    ---------------- fatura tarihi poliçe bitis tarihi ise ------
    IF Policyinfo.Contract_Id IS NULL THEN
      IF Clmdetail(Clmid).Provision_Date IS NULL THEN
        p_Inv_Date_Time := To_Date(To_Char(Nvl(Clmdetail(Clmid).Date_Of_Loss,
                                               Clmdetail(Clmid).Invoice_Date),
                                           'dd/mm/yyyy') || ' 11:00:00',
                                   'dd/mm/yyyy hh24:mi:ss');

        p_Provision_Date := Nvl(p_Pov_Date_Time, p_Inv_Date_Time);

        Koc_Clm_Hlth_Utils.Getpolinfoforindemnity(p_Contract_Id,
                                                  p_Partition_No,
                                                  Clmdetail(Clmid).Part_Id,
                                                  p_Provision_Date,
                                                  Cur);

        FETCH Cur
          INTO Policyinfo;

        CLOSE Cur;
   
        IF v_Clmdetail.Claim_Id IS NOT NULL THEN
          IF v_Clmdetail.Package_Id IS NOT NULL THEN
            Policyinfo.Package_Id   := v_Clmdetail.Package_Id;
            Policyinfo.Package_Date := v_Clmdetail.Package_Date;
          END IF;
        END IF;
      END IF;
    END IF;

    IF Policyinfo.Contract_Id IS NULL THEN
      Raise_Application_Error(-20201, 'Poliçe bulunamadi.');
    END IF;
   ---15.madde------------------------------------------------------------------------------------------------     
    Koc_Clm_Hlth_Utils.Getinsuredinfobypartnerid(Policyinfo.Partner_Id,
                                                 Cur);

    FETCH Cur
      INTO Insuredinfo;

    CLOSE Cur;
	/* 
	    Bu InsuredInfo bilgisi sadece clm_interested_parties tablosuna insert edilirken kullanılıyor.
		ve sadece part_id kullanılıyor. part_id zaten policyinfo da olduğu için bu kod bloğu gereksiz. 
	*/
   ---16.madde ----------------------------------------------------------------------------------------------------
   
    Koc_Clm_Hlth_Utils.Getinstitutinfobycode(Clmdetail(Clmid)
                                             .Institute_Code,
                                             p_Provision_Date,
                                             Cur);

    FETCH Cur
      INTO Institutinfo;

    CLOSE Cur;

    IF Institutinfo.Institute_Code IS NULL THEN
      Koc_Clm_Hlth_Utils.Getlastinstitutinfobycode(Clmdetail(Clmid)
                                                   .Institute_Code,
                                                   Cur);

      FETCH Cur
        INTO Institutinfo;

      CLOSE Cur;
    END IF;
	/*
	   bu instituteInfo compute_remaininge parametre olarak gidiyor.
	   bir de clm_trans tablosunda Supp_Id si insert ediliyor. 
	*/
   ---17.madde---------------------------------------------------------------------------------------------
    IF Nvl(Clmdetail(Clmid).Status_Code, 'PP') IN
       ('PP', 'I', 'H', 'CIR', 'CPI', 'CPR', 'TI', 'PR') THEN
      DELETE Koc_Clm_Hlth_Detail
       WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
         AND Sf_No = Clmdetail(Clmid).Sf_No
         AND Add_Order_No = Clmdetail(Clmid).Add_Order_No;

      DELETE Koc_Clm_Hlth_Reject_Loss
       WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
         AND Sf_No = Clmdetail(Clmid).Sf_No
         AND Add_Order_No = Clmdetail(Clmid).Add_Order_No
         AND Location_Code = 0
         AND Cover_Code = '0'
         AND Barcode = 0
         AND Ubb_Code = '0';
    END IF;
	/*
	   bu madde ancak updateProvision da olabilir. 
	*/
    ---18.madde-----------------------------------------------------------------------------------------------
    p_Raise       := Nvl(Clmdetail(Clmid).Status_Code, 'PP') || '/';
    v_Status_Code := Getstatuscode(Clmdetail(Clmid).Status_Code,
                                   Userinfo.User_Type);
    ---19.madde---------------------------------------------------------------------------------------------
    -- orhan topal
    BEGIN
      SELECT Identity_No
        INTO l_Tckn
        FROM Koc_Cp_Partners_Ext
       WHERE Rownum = 1
         AND Part_Id = Clmdetail(Clmid).Part_Id;

      Customer.Alz_Affluent_Customer.Get_Policy_Customer_Value(Policyinfo.Policy_Ref,
                                                               l_Tckn,
                                                               x_Segment_Kodu,
                                                               x_Segment_Aciklamasi,
                                                               x_Segment_Ekran_Aciklamasi);

      l_Affluent_Flag := x_Segment_Kodu;
    EXCEPTION
      WHEN OTHERS THEN
        l_Affluent_Flag := NULL;
    END;
    /*create_provision da olmalı*/
    -- orhan topal
    --- 20. madde ----------------------------------------------------------------------
    IF Nvl(Clmdetail(Clmid).Status_Code, 'PP') IN
       ('PP', 'PI', 'PR', 'I', 'H', 'CIR', 'CPI', 'CPR', 'TI') THEN
      -- önceden ext refence üretilmis ise tekrar üretmesin
      IF Clmdetail(Clmid).Ext_Reference IS NULL THEN
        SELECT Clm_Subfiles_Seq.Nextval INTO v_Ext_Reference FROM Dual;
      ELSE
        v_Ext_Reference := Clmdetail(Clmid).Ext_Reference;
      END IF;

      IF v_Ext_Reference IS NULL THEN
        SELECT Ext_Reference
          INTO v_Ext_Reference
          FROM Clm_Subfiles
         WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
           AND Sf_No = Clmdetail(Clmid).Sf_No;
      END IF;
	  /* bu kod bloğuna girmez. çünkü yukarudaki koda göre v_Ext_reference null olmaz. */

      Clmdetail(Clmid).Final_Class_Disease_1 := Nvl(Clmdetail(Clmid)
                                                    .Final_Class_Disease_1,
                                                    Clmdetail(Clmid)
                                                    .Class_Disease_1);
      Clmdetail(Clmid).Final_Class_Disease_2 := Nvl(Clmdetail(Clmid)
                                                    .Final_Class_Disease_2,
                                                    Clmdetail(Clmid)
                                                    .Class_Disease_2);
      Clmdetail(Clmid).Final_Class_Disease_3 := Nvl(Clmdetail(Clmid)
                                                    .Final_Class_Disease_3,
                                                    Clmdetail(Clmid)
                                                    .Class_Disease_3);

      IF Clmdetail(Clmid).Request_System = 'ULAK' THEN
        Clmdetail(Clmid).Provision_Date := Nvl(Alz_Hltprv_Utils.Getulakprovisiondate(Clmdetail(Clmid)
                                                                                     .Sgk_Ref_No,
                                                                                     Clmdetail(Clmid)
                                                                                     .Institute_Code),
                                               SYSDATE);

      END IF;

      INSERT INTO Koc_Clm_Hlth_Detail
        (Claim_Id,
         Sf_No,
         Add_Order_No,
         Process_Date,
         Communication_No,
         Close_Date,
         Group_Code,
         Provision_Fee_Charge_Date,
         Is_Patient_Visit_Made,
         Identitiy_Type,
         Identity_No,
         Institute_Code,
         Provision_Date,
         Provision_User_Id,
         Hospitalize_Date,
         Discharge_Date,
         Hospitalize_Appr_Form_Expl_1,
         Hospitalize_Appr_Form_Expl_2,
         Class_Disease_1,
         Class_Disease_2,
         Class_Disease_3,
         Claim_Inst_Type,
         Claim_Inst_Loc,
         Orig_Claim_Inst_Type,
         Orig_Claim_Inst_Loc,
         Specialty_Subject,
         Explanation,
         Status_Code,
         Part_Id,
         Ext_Reference,
         Dr_Name_Lastname,
         Prescription_Date,
         Prescription_No,
         Soc_Sec_Inst_App,
         e_Prescription_No,
         Invoice_Date,
         Invoice_No,
         Invoice_Total,
         Payment_Total,
         Invoice_Explanation,
         Country_Code,
         Deduction_Rate,
         Is_Urgent_Cure,
         Shipping_Date,
         Shipping_No,
         Is_Wrong_Provision,
         Inst_Tax_Number,
         Inst_Tax_Office,
         Final_Class_Disease_1,
         Final_Class_Disease_2,
         Final_Class_Disease_3,
         Swift_Code,
         Comm_Date,
         Contract_Message,
         Dr_Diploma_No,
         Date_Of_Loss,
         Package_Id,
         Package_Date,
         Rel_Claim_Id,
         Prov_Demand_Date,
         Is_Sgk_Used,
         Sgk_Total,
         Web_Location_Code,
         Is_Web,
         Prescription_Type,
         Process_Exp,
         Patient_Complaint,
         Complaint_Start,
         Last_Menst_Date,
         Before_Complaint_Illness,
         Medical_Background,
         Consultation_Diagnosis,
         Examinations_Results,
         Prediagnosis_Diagnosis,
         Planned_Treatment_Proc,
         Poss_Hospitalize_Date,
         Poss_Discharge_Date,
         Exam_Date,
         Is_Ext_Doctor,
         Ext_Doctor_Amt,
         Hospital_Amt,
         Doctor_Code,
         From_City_Code,
         From_District_Code,
         To_City_Code,
         To_District_Code,
         From_To_Place,
         Other_Country_City,
         Other_Country,
         Is_Pregnant,
         Inst_Gln_Code,
         Surgery_Date,
         Is_Judicial,
         Nationality,
         Identity_Number,
         Communication_Exp1,
         Communication_Number1,
         Communication_Exp2,
         Communication_Number2,
         Yt_Type,
         Doctor_Type,
         Doctor_Status,
         Is_Referral,
         Referral_Institute_Name,
         Personal_Notes,
         Patient_Admittance_Date,
         Request_Amount,
         Realization_Date,
         Time_Stamp,
         Hlth_Srv_Pay,
         Dh_Inst,
         Hospital_Ref_No,
         Request_System,
         Bre_Result_Code,
         Is_Complementary,
         Sgk_Ref_No,
         Is_Ahek,
         Affluent_Flag,
         Cpa_Status,
         Is_Original,
         Has_Unreadable_Doc,
         Visiting_Reason,
         Is_Only_Examination_Fee,
         Is_Ok,
         Is_Ex_Gratia,
         Ex_Gratia_Fee,
         Is_Automated,
         Is_Suspense,
         Suspense_Date,
         Medula_Date)
      VALUES
        (Clmdetail(Clmid).Claim_Id,
         Clmdetail(Clmid).Sf_No,
         Clmdetail(Clmid).Add_Order_No,
         Nvl(Clmdetail(Clmid).Process_Date, SYSDATE),
         Clmdetail(Clmid).Communication_No,
         Clmdetail(Clmid).Close_Date,
         Nvl(Clmdetail(Clmid).Group_Code, Policyinfo.Group_Code),
         Clmdetail(Clmid).Provision_Fee_Charge_Date,
         Clmdetail(Clmid).Is_Patient_Visit_Made,
         Clmdetail(Clmid).Identitiy_Type,
         Clmdetail(Clmid).Identity_No,
         Clmdetail(Clmid).Institute_Code,
         Clmdetail(Clmid).Provision_Date,
         Nvl(Clmdetail(Clmid).Provision_User_Id, p_User_Id),
         Clmdetail(Clmid).Hospitalize_Date,
         Clmdetail(Clmid).Discharge_Date,
         Clmdetail(Clmid).Hospitalize_Appr_Form_Expl_1,
         Clmdetail(Clmid).Hospitalize_Appr_Form_Expl_2,
         Clmdetail(Clmid).Class_Disease_1,
         Clmdetail(Clmid).Class_Disease_2,
         Clmdetail(Clmid).Class_Disease_3,
         Clmdetail(Clmid).Claim_Inst_Type,
         Clmdetail(Clmid).Claim_Inst_Loc,
         Clmdetail(Clmid).Orig_Claim_Inst_Type,
         Clmdetail(Clmid).Orig_Claim_Inst_Loc,
         Clmdetail(Clmid).Specialty_Subject,
         Clmdetail(Clmid).Explanation,
         v_Status_Code,
         Clmdetail(Clmid).Part_Id,
         v_Ext_Reference,
         Clmdetail(Clmid).Dr_Name_Lastname,
         Clmdetail(Clmid).Prescription_Date,
         Clmdetail(Clmid).Prescription_No,
         Clmdetail(Clmid).Soc_Sec_Inst_App,
         Clmdetail(Clmid).e_Prescription_No,
         Clmdetail(Clmid).Invoice_Date,
         Clmdetail(Clmid).Invoice_No,
         Clmdetail(Clmid).Invoice_Total,
         Clmdetail(Clmid).Payment_Total,
         Clmdetail(Clmid).Invoice_Explanation,
         Clmdetail(Clmid).Country_Code,
         Clmdetail(Clmid).Deduction_Rate,
         Clmdetail(Clmid).Is_Urgent_Cure,
         Clmdetail(Clmid).Shipping_Date,
         Clmdetail(Clmid).Shipping_No,
         Clmdetail(Clmid).Is_Wrong_Provision,
         Clmdetail(Clmid).Inst_Tax_Number,
         Clmdetail(Clmid).Inst_Tax_Office,
         Clmdetail(Clmid).Final_Class_Disease_1,
         Clmdetail(Clmid).Final_Class_Disease_2,
         Clmdetail(Clmid).Final_Class_Disease_3,
         Clmdetail(Clmid).Swift_Code,
         Nvl(Clmdetail(Clmid).Comm_Date, Trunc(SYSDATE)),
         Clmdetail(Clmid).Contract_Message,
         Clmdetail(Clmid).Dr_Diploma_No,
         v_Date_Of_Loss,
         Policyinfo.Package_Id,
         Policyinfo.Package_Date,
         Clmdetail(Clmid).Rel_Claim_Id,
         Clmdetail(Clmid).Prov_Demand_Date,
         Clmdetail(Clmid).Is_Sgk_Used,
         Clmdetail(Clmid).Sgk_Total,
         Clmdetail(Clmid).Web_Location_Code,
         Clmdetail(Clmid).Is_Web,
         Clmdetail(Clmid).Prescription_Type,
         Clmdetail(Clmid).Process_Exp,
         Clmdetail(Clmid).Patient_Complaint,
         Clmdetail(Clmid).Complaint_Start,
         Clmdetail(Clmid).Last_Menst_Date,
         Clmdetail(Clmid).Before_Complaint_Illness,
         Clmdetail(Clmid).Medical_Background,
         Clmdetail(Clmid).Consultation_Diagnosis,
         Clmdetail(Clmid).Examinations_Results,
         Clmdetail(Clmid).Prediagnosis_Diagnosis,
         Clmdetail(Clmid).Planned_Treatment_Proc,
         Clmdetail(Clmid).Poss_Hospitalize_Date,
         Clmdetail(Clmid).Poss_Discharge_Date,
         Clmdetail(Clmid).Exam_Date,
         Clmdetail(Clmid).Is_Ext_Doctor,
         Clmdetail(Clmid).Ext_Doctor_Amt,
         Clmdetail(Clmid).Hospital_Amt,
         Clmdetail(Clmid).Doctor_Code,
         Clmdetail(Clmid).From_City_Code,
         Clmdetail(Clmid).From_District_Code,
         Clmdetail(Clmid).To_City_Code,
         Clmdetail(Clmid).To_District_Code,
         Clmdetail(Clmid).From_To_Place,
         Clmdetail(Clmid).Other_Country_City,
         Clmdetail(Clmid).Other_Country,
         Clmdetail(Clmid).Is_Pregnant,
         Clmdetail(Clmid).Inst_Gln_Code,
         Clmdetail(Clmid).Surgery_Date,
         Clmdetail(Clmid).Is_Judicial,
         Clmdetail(Clmid).Nationality,
         Clmdetail(Clmid).Identity_Number,
         Clmdetail(Clmid).Communication_Exp1,
         Clmdetail(Clmid).Communication_Number1,
         Clmdetail(Clmid).Communication_Exp2,
         Clmdetail(Clmid).Communication_Number2,
         Clmdetail(Clmid).Yt_Type,
         Clmdetail(Clmid).Doctor_Type,
         Clmdetail(Clmid).Doctor_Status,
         Clmdetail(Clmid).Is_Referral,
         Clmdetail(Clmid).Referral_Institute_Name,
         Clmdetail(Clmid).Personal_Notes,
         Clmdetail(Clmid).Patient_Admittance_Date,
         Clmdetail(Clmid).Request_Amount,
         Clmdetail(Clmid).Realization_Date,
         Clmdetail(Clmid).Time_Stamp,
         Clmdetail(Clmid).Hlth_Srv_Pay,
         Clmdetail(Clmid).Dh_Inst,
         Clmdetail(Clmid).Hospital_Ref_No,
         Clmdetail(Clmid).Request_System,
         Clmdetail(Clmid).Bre_Result_Code,
         Clmdetail(Clmid).Is_Complementary,
         Clmdetail(Clmid).Sgk_Ref_No,
         Clmdetail(Clmid).Is_Ahek,
         l_Affluent_Flag,
         Clmdetail(Clmid).Cpa_Status,
         Clmdetail(Clmid).Is_Original,
         Clmdetail(Clmid).Has_Unreadable_Doc,
         Clmdetail(Clmid).Visiting_Reason,
         Clmdetail(Clmid).Is_Only_Examination_Fee,
         Clmdetail(Clmid).Is_Ok,
         Clmdetail(Clmid).Is_Ex_Gratia,
         Clmdetail(Clmid).Ex_Gratia_Fee,
         Clmdetail(Clmid).Is_Automated,
         Clmdetail(Clmid).Is_Suspense,
         Clmdetail(Clmid).Suspense_Date,
         Clmdetail(Clmid).Medula_Date);

      -- hasar dosya bazinda redler
      j := 1;

      WHILE j <= Clmrejection.Count LOOP
        IF (Clmrejection(j).Cover_Code = '0') AND
           (Clmrejection(j).Location_Code = 0) AND
           (Clmrejection(j).Barcode = 0) AND
           (Clmrejection(j).Ubb_Code = '0') THEN
          INSERT INTO Koc_Clm_Hlth_Reject_Loss
            (Claim_Id,
             Sf_No,
             Location_Code,
             Add_Order_No,
             Cover_Code,
             Process_Code_Main,
             Process_Code_Sub1,
             Process_Code_Sub2,
             Main_Code,
             Item_Code,
             Sub_Item_Code,
             Refuse_Explanation,
             Refuse_Amount,
             Userid,
             Entry_Date,
             Barcode,
             Is_Bre_Decision,
             Ubb_Code,
             Seq_No)
          VALUES
            (Clmdetail(Clmid).Claim_Id,
             Clmdetail(Clmid).Sf_No,
             Clmrejection(j).Location_Code,
             Clmdetail(Clmid).Add_Order_No,
             Clmrejection(j).Cover_Code,
             Clmrejection(j).Process_Code_Main,
             Clmrejection(j).Process_Code_Sub1,
             Clmrejection(j).Process_Code_Sub2,
             Clmrejection(j).Main_Code,
             Clmrejection(j).Item_Code,
             Clmrejection(j).Sub_Item_Code,
             Clmrejection(j).Refuse_Explanation,
             Nvl(Clmrejection(j).Refuse_Amount, 0),
             Nvl(Clmrejection(j).Userid, p_User_Id),
             Trunc(SYSDATE),
             Nvl(Clmrejection(j).Barcode, 0),
             Clmrejection(j).Is_Bre_Decision,
             Clmrejection(j).Ubb_Code,
             Nvl(Clmrejection(j).Seq_No, 1));
        END IF;

        j := j + 1;
      END LOOP;
    ELSE
      UPDATE Koc_Clm_Hlth_Detail
         SET Dr_Name_Lastname             = Clmdetail(Clmid).Dr_Name_Lastname,
             Prescription_Date            = Clmdetail(Clmid)
                                            .Prescription_Date,
             Prescription_No              = Clmdetail(Clmid).Prescription_No,
             Soc_Sec_Inst_App             = Clmdetail(Clmid).Soc_Sec_Inst_App,
             e_Prescription_No            = Clmdetail(Clmid)
                                            .e_Prescription_No,
             Dr_Diploma_No                = Clmdetail(Clmid).Dr_Diploma_No,
             Explanation                  = Clmdetail(Clmid).Explanation,
             Package_Id                   = Policyinfo.Package_Id,
             Package_Date                 = Policyinfo.Package_Date,
             Group_Code                   = Policyinfo.Group_Code,
             Rel_Claim_Id                 = Clmdetail(Clmid).Rel_Claim_Id,
             Prov_Demand_Date             = Clmdetail(Clmid).Prov_Demand_Date,
             Prescription_Type            = Clmdetail(Clmid)
                                            .Prescription_Type,
             Is_Sgk_Used                  = Clmdetail(Clmid).Is_Sgk_Used,
             Sgk_Total                    = Clmdetail(Clmid).Sgk_Total,
             Web_Location_Code            = Clmdetail(Clmid)
                                            .Web_Location_Code,
             Is_Web                       = Clmdetail(Clmid).Is_Web,
             Process_Exp                  = Clmdetail(Clmid).Process_Exp,
             Patient_Complaint            = Clmdetail(Clmid)
                                            .Patient_Complaint,
             Complaint_Start              = Clmdetail(Clmid).Complaint_Start,
             Last_Menst_Date              = Clmdetail(Clmid).Last_Menst_Date,
             Before_Complaint_Illness     = Clmdetail(Clmid)
                                            .Before_Complaint_Illness,
             Medical_Background           = Clmdetail(Clmid)
                                            .Medical_Background,
             Consultation_Diagnosis       = Clmdetail(Clmid)
                                            .Consultation_Diagnosis,
             Examinations_Results         = Clmdetail(Clmid)
                                            .Examinations_Results,
             Prediagnosis_Diagnosis       = Clmdetail(Clmid)
                                            .Prediagnosis_Diagnosis,
             Planned_Treatment_Proc       = Clmdetail(Clmid)
                                            .Planned_Treatment_Proc,
             Poss_Hospitalize_Date        = Clmdetail(Clmid)
                                            .Poss_Hospitalize_Date,
             Poss_Discharge_Date          = Clmdetail(Clmid)
                                            .Poss_Discharge_Date,
             Hospitalize_Date             = Clmdetail(Clmid).Hospitalize_Date,
             Discharge_Date               = Clmdetail(Clmid).Discharge_Date,
             Exam_Date                    = Clmdetail(Clmid).Exam_Date,
             Is_Ext_Doctor                = Clmdetail(Clmid).Is_Ext_Doctor,
             Ext_Doctor_Amt               = Clmdetail(Clmid).Ext_Doctor_Amt,
             Hospital_Amt                 = Clmdetail(Clmid).Hospital_Amt,
             Doctor_Code                  = Clmdetail(Clmid).Doctor_Code,
             From_City_Code               = Clmdetail(Clmid).From_City_Code,
             From_District_Code           = Clmdetail(Clmid)
                                            .From_District_Code,
             To_City_Code                 = Clmdetail(Clmid).To_City_Code,
             To_District_Code             = Clmdetail(Clmid).To_District_Code,
             From_To_Place                = Clmdetail(Clmid).From_To_Place,
             Other_Country_City           = Clmdetail(Clmid)
                                            .Other_Country_City,
             Status_Code                  = v_Status_Code,
             Other_Country                = Clmdetail(Clmid).Other_Country,
             Is_Pregnant                  = Clmdetail(Clmid).Is_Pregnant,
             Specialty_Subject            = Clmdetail(Clmid)
                                            .Specialty_Subject,
             Inst_Gln_Code                = Clmdetail(Clmid).Inst_Gln_Code,
             Surgery_Date                 = Clmdetail(Clmid).Surgery_Date,
             Is_Judicial                  = Clmdetail(Clmid).Is_Judicial,
             Nationality                  = Clmdetail(Clmid).Nationality,
             Identity_Number              = Clmdetail(Clmid).Identity_Number,
             Communication_Exp1           = Clmdetail(Clmid)
                                            .Communication_Exp1,
             Communication_Number1        = Clmdetail(Clmid)
                                            .Communication_Number1,
             Communication_Exp2           = Clmdetail(Clmid)
                                            .Communication_Exp2,
             Communication_Number2        = Clmdetail(Clmid)
                                            .Communication_Number2,
             Yt_Type                      = Clmdetail(Clmid).Yt_Type,
             Doctor_Type                  = Clmdetail(Clmid).Doctor_Type,
             Doctor_Status                = Clmdetail(Clmid).Doctor_Status,
             Is_Referral                  = Clmdetail(Clmid).Is_Referral,
             Referral_Institute_Name      = Clmdetail(Clmid)
                                            .Referral_Institute_Name,
             Personal_Notes               = Clmdetail(Clmid).Personal_Notes,
             Patient_Admittance_Date      = Clmdetail(Clmid)
                                            .Patient_Admittance_Date,
             Request_Amount               = Clmdetail(Clmid).Request_Amount,
             Realization_Date             = Clmdetail(Clmid).Realization_Date,
             Time_Stamp                   = Clmdetail(Clmid).Time_Stamp,
             Hlth_Srv_Pay                 = Clmdetail(Clmid).Hlth_Srv_Pay,
             Dh_Inst                      = Clmdetail(Clmid).Dh_Inst,
             Hospital_Ref_No              = Clmdetail(Clmid).Hospital_Ref_No,
             Request_System               = Nvl(Request_System,
                                                Clmdetail(Clmid)
                                                .Request_System),
             Bre_Result_Code              = Clmdetail(Clmid).Bre_Result_Code,
             Class_Disease_1              = Clmdetail(Clmid).Class_Disease_1,
             Class_Disease_2              = Clmdetail(Clmid).Class_Disease_2,
             Class_Disease_3              = Clmdetail(Clmid).Class_Disease_3,
             Final_Class_Disease_1        = Clmdetail(Clmid)
                                            .Final_Class_Disease_1,
             Final_Class_Disease_2        = Clmdetail(Clmid)
                                            .Final_Class_Disease_2,
             Final_Class_Disease_3        = Clmdetail(Clmid)
                                            .Final_Class_Disease_3,
             Hospitalize_Appr_Form_Expl_1 = Clmdetail(Clmid)
                                            .Hospitalize_Appr_Form_Expl_1,
             Hospitalize_Appr_Form_Expl_2 = Clmdetail(Clmid)
                                            .Hospitalize_Appr_Form_Expl_2,
             Is_Complementary             = Clmdetail(Clmid).Is_Complementary,
             Sgk_Ref_No                   = Clmdetail(Clmid).Sgk_Ref_No,
             Is_Ahek                      = Clmdetail(Clmid).Is_Ahek,
             Cpa_Status                   = Clmdetail(Clmid).Cpa_Status,
             Is_Original                  = Clmdetail(Clmid).Is_Original,
             Has_Unreadable_Doc           = Clmdetail(Clmid)
                                            .Has_Unreadable_Doc,
             Visiting_Reason              = Clmdetail(Clmid).Visiting_Reason,
             Is_Only_Examination_Fee      = Clmdetail(Clmid)
                                            .Is_Only_Examination_Fee,
             Affluent_Flag                = Clmdetail(Clmid).Affluent_Flag,
             Is_Ok                        = Clmdetail(Clmid).Is_Ok,
             Is_Ex_Gratia                 = Clmdetail(Clmid).Is_Ex_Gratia,
             Ex_Gratia_Fee                = Clmdetail(Clmid).Ex_Gratia_Fee,
             Is_Automated                 = Clmdetail(Clmid).Is_Automated,
             Is_Suspense                  = Clmdetail(Clmid).Is_Suspense,
             Suspense_Date                = Clmdetail(Clmid).Suspense_Date,
             Medula_Date                  = Clmdetail(Clmid).Medula_Date
       WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
         AND Sf_No = Clmdetail(Clmid).Sf_No
         AND Add_Order_No = Clmdetail(Clmid).Add_Order_No;
    END IF;
    --- 21. madde -------------------------------------------------------------------------
    v_Base_Contract_Id := Getclaimcontractid(Clmdetail(Clmid).Claim_Id);
    --- 22. madde ------------------------------------------------------------------------
    -- hakan keks muafiyet limiti iade
    IF Policyinfo.Partition_Type = 'KEKS' THEN
      BEGIN
        BEGIN
          SELECT SUM(Nvl(Exemption_Amount, 0)) Exemption_Amount
            INTO p_Exemption_Amount
            FROM (SELECT a.Exemption_Amount
                    FROM Web_Clm_Hlth_Provisions a
                   WHERE a.Claim_Id = Clmdetail(Clmid).Claim_Id
                     AND a.Sf_No = Clmdetail(Clmid).Sf_No
                     AND a.Add_Order_No = Clmdetail(Clmid).Add_Order_No
                  UNION
                  SELECT a.Exemption_Amount
                    FROM Koc_Clm_Hlth_Provisions a
                   WHERE a.Claim_Id = Clmdetail(Clmid).Claim_Id
                     AND a.Sf_No = Clmdetail(Clmid).Sf_No
                     AND a.Add_Order_No = Clmdetail(Clmid).Add_Order_No
                     AND Nvl(a.Status_Code, 'I') NOT IN ('I', 'H', 'TI')
                     AND NOT EXISTS
                   (SELECT 1
                            FROM Web_Clm_Hlth_Provisions b
                           WHERE b.Claim_Id = a.Claim_Id
                             AND b.Sf_No = a.Sf_No
                             AND b.Add_Order_No = a.Add_Order_No
                             AND b.Cover_Code = a.Cover_Code
                             AND b.Location_Code = a.Location_Code));
        EXCEPTION
          WHEN No_Data_Found THEN
            NULL;
        END;

        UPDATE Koc_Clm_Hlth_Event_Exempt a
           SET a.Event_r_Exemption = Nvl(a.Event_r_Exemption, 0) +
                                     Nvl(p_Exemption_Amount, 0),
               a.Event_s_Exemption = Nvl(a.Event_s_Exemption, 0) -
                                     Nvl(p_Exemption_Amount, 0)
         WHERE a.Event_Id = Clmdetail(Clmid).Rel_Claim_Id;
      EXCEPTION
        WHEN No_Data_Found THEN
          NULL;
      END;
    END IF;
    ---- 23.madde update_claim_policy-------------------------------------------------------------------------------------
    -- bu durum yalnizca detail inceleme statustündeiken ofis doktoru poliçeyi degistirir ise olusur
    IF Nvl(v_Base_Contract_Id, 0) != Nvl(p_Contract_Id, 0) AND
       p_Contract_Id IS NOT NULL AND v_Base_Contract_Id IS NOT NULL THEN
      DELETE Clm_Pol_Oar WHERE Claim_Id = Clmdetail(Clmid).Claim_Id;

      DELETE Clm_Pol_Bases WHERE Claim_Id = Clmdetail(Clmid).Claim_Id;

      INSERT INTO Clm_Pol_Bases
        (Claim_Id,
         Contract_Id,
         Product_Id,
         Prod_Version,
         Contract_Status,
         Term_Start_Date,
         Term_End_Date,
         Version_No,
         Date_Of_Loss,
         Policy_Ref,
         Agent_Role)
      VALUES
        (Clmdetail(Clmid).Claim_Id,
         Policyinfo.Contract_Id,
         Policyinfo.Product_Id,
         NULL,
         Policyinfo.Contract_Status,
         Policyinfo.Term_Start_Date,
         Policyinfo.Term_End_Date,
         Policyinfo.Version_No,
         v_Date_Of_Loss,
         Policyinfo.Policy_Ref,
         v_First_Agent_Int_Id);

      INSERT INTO Clm_Pol_Oar
        (Claim_Id, Contract_Id, Oar_No, Version_No)
      VALUES
        (Clmdetail(Clmid).Claim_Id,
         Policyinfo.Contract_Id,
         Policyinfo.Partition_No,
         Policyinfo.Version_No);
    END IF;

	--- 24. madde ------------------------------------------------------------------------------
    IF p_Contract_Id IS NOT NULL AND v_Base_Contract_Id IS NULL THEN
      -- ilk hasar dosya açiliyor
      INSERT INTO Clm_Bases
        (Claim_Id,
         Clm_Status,
         Clm_Line_Id,
         Manual_Claim,
         Date_Reported,
         Chargeable_Code)
      VALUES
        (Clmdetail(Clmid).Claim_Id, 'OPEN', 20, 'N', SYSDATE, 0);

      INSERT INTO Clm_Pol_Bases
        (Claim_Id,
         Contract_Id,
         Product_Id,
         Prod_Version,
         Contract_Status,
         Term_Start_Date,
         Term_End_Date,
         Version_No,
         Date_Of_Loss,
         Policy_Ref,
         Agent_Role)
      VALUES
        (Clmdetail(Clmid).Claim_Id,
         Policyinfo.Contract_Id,
         Policyinfo.Product_Id,
         NULL,
         Policyinfo.Contract_Status,
         Policyinfo.Term_Start_Date,
         Policyinfo.Term_End_Date,
         Policyinfo.Version_No,
         v_Date_Of_Loss,
         Policyinfo.Policy_Ref,
         v_First_Agent_Int_Id);

      INSERT INTO Clm_Pol_Oar
        (Claim_Id, Contract_Id, Oar_No, Version_No)
      VALUES
        (Clmdetail(Clmid).Claim_Id,
         Policyinfo.Contract_Id,
         Policyinfo.Partition_No,
         Policyinfo.Version_No);

      SELECT Clm_Sf_Id_Seq.Nextval INTO v_Clm_Sf_Id FROM Dual;

      INSERT INTO Clm_Subfiles
        (Claim_Id,
         Sf_No,
         Sf_Type,
         Clm_Status,
         Sf_Desc,
         Sf_Id,
         Ext_Reference)
      VALUES
        (Clmdetail(Clmid).Claim_Id,
         1,
         'HLT',
         'OPEN',
         '',
         v_Clm_Sf_Id,
         v_Ext_Reference);

      INSERT INTO Koc_Clm_Subfiles_Ext
        (Claim_Id,
         Sf_No,
         Product_Id,
         Term_Start_Date,
         Term_End_Date,
         Date_Of_Loss,
         Policy_Ref,
         Oldsys_Policy_No,
         Manual_Claim,
         Convert_Flag,
         Partition_Type,
         Agent_Role,
         Sub_Agent)
      VALUES
        (Clmdetail(Clmid).Claim_Id,
         1,
         Policyinfo.Product_Id,
         Policyinfo.Term_Start_Date,
         Policyinfo.Term_End_Date,
         v_Date_Of_Loss,
         Policyinfo.Policy_Ref,
         Policyinfo.Oldsys_Policy_No,
         'N',
         NULL,
         Policyinfo.Partition_Type,
         v_First_Agent_Int_Id,
         v_First_Sub_Agent);

      INSERT INTO Clm_Interested_Parties
        (Claim_Id,
         Ip_No,
         Object_Type,
         Part_Id,
         Ins_Obj_Uid,
         Ip_Type,
         Version_No,
         Object_Id,
         Claimant)
      VALUES
        (Clmdetail(Clmid).Claim_Id,
         Policyinfo.Ip_No,
         'CLM',
         Insuredinfo.Part_Id,
         Clmdetail(Clmid).Claim_Id,
         'INS',
         Policyinfo.Version_No,
         Insuredinfo.Part_Id,
         'N');
    END IF;
    --- 25.madde --------------------------------------------------------------------
    IF v_Base_Contract_Id IS NOT NULL THEN
      UPDATE Koc_Clm_Subfiles_Ext
         SET Agent_Role = v_First_Agent_Int_Id,
             Sub_Agent  = v_First_Sub_Agent
       WHERE Claim_Id = Clmdetail(Clmid).Claim_Id;

      UPDATE Clm_Pol_Bases
         SET Agent_Role = v_First_Agent_Int_Id
       WHERE Claim_Id = Clmdetail(Clmid).Claim_Id;
    END IF;
    ---------26. madde ---------------------------------------------------------------
    i := 1;    
    WHILE i <= Clmvaccindem.Count LOOP
      IF Nvl(Clmvaccindem(i).Status_Code, 'PP') IN
         ('PP', 'PI', 'PR', 'I', 'H', 'TI') THEN
        v_Proc_Status_Code := Getstatuscode(Clmvaccindem(i).Status_Code,
                                            Userinfo.User_Type);

        INSERT INTO Koc_Clm_Vacc_Indem_Totals
          (Part_Id,
           Vaccine_Code,
           Order_No,
           Userid,
           Vaccine_Date,
           Status_Code,
           Entry_Date,
           Claim_Id,
           Sf_No,
           Add_Order_No,
           Barcode)
        VALUES
          (Clmvaccindem(i).Part_Id,
           Clmvaccindem(i).Vaccine_Code,
           Clmvaccindem(i).Order_No,
           Nvl(Clmvaccindem(i).Userid, p_User_Id),
           Clmvaccindem(i).Vaccine_Date,
           v_Proc_Status_Code,
           SYSDATE,
           Clmdetail(Clmid).Claim_Id,
           Clmvaccindem(i).Sf_No,
           Clmvaccindem(i).Add_Order_No,
           Clmvaccindem(i).Barcode);
      END IF;

      i := i + 1;
    END LOOP;
    ----27.madde-----------------------------------------------------
    --task 12317----
    IF Clmvaccindem.Count = 0 THEN
      UPDATE Koc_Clm_Vacc_Indem_Totals
         SET Status_Code = Decode(Nvl(Status_Code, 'PP'),
                                  'PP',
                                  'P',
                                  'CP',
                                  'P',
                                  'PR',
                                  'R',
                                  'CPR',
                                  'R',
                                  Status_Code)
       WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
         AND Sf_No = Clmdetail(Clmid).Sf_No
         AND Add_Order_No = Clmdetail(Clmid).Add_Order_No;
    END IF;
    --- 28. madde -------------------------------------------------------------
    --hakan keks
    IF Policyinfo.Partition_Type = 'KEKS' THEN
      Find_Exemption_Limit('X',
                           Clmdetail         (Clmid).Claim_Id,
                           Clmdetail         (Clmid).Sf_No,
                           Clmdetail         (Clmid).Add_Order_No,
                           Clmdetail         (Clmid).Rel_Claim_Id,
                           p_Exemption_Amount);
    END IF;
    ----29.madde--------------------------------------------------------------------------------
    i         := 1;
    v_Sgk_Use := 0;

    WHILE i <= Clmprovision.Count LOOP
      IF Nvl(Clmprovision(i).Sgk_Amount, 0) > 0 THEN
        v_Sgk_Use := 1;
      END IF;

      <<nextprovision>>
      i := i + 1;
    END LOOP;

    --aaktas
    --KFS kontrolü
    --19032015
    /*
    vpolicyKFSstatus := koc_clm_hlth_hospt_utils.checkpolicyKFSstatus (p_contract_id
                                                                      ,p_provision_date
                                                                      );
    --
    if vpolicyKFSstatus = 1
    then
        vhlthdetail := customer.hlth_detail_row_type();

        vhlthdetail.contract_id             := p_contract_id;
        vhlthdetail.oar_no                  := p_partition_no;
        vhlthdetail.claim_id                := clmdetail(clmid).claim_id;
        vhlthdetail.sf_no                   := clmdetail(clmid).sf_no;
        vhlthdetail.group_code              := clmdetail(clmid).group_code;
        vhlthdetail.institute_code          := clmdetail(clmid).institute_code;
        vhlthdetail.provision_date          := clmdetail(clmid).provision_date;
        vhlthdetail.specialty_subject       := clmdetail(clmid).specialty_subject;
        vhlthdetail.package_id              := clmdetail(clmid).package_id;
        vhlthdetail.package_date            := clmdetail(clmid).package_date;
        vhlthdetail.class_disease_1         := clmdetail(clmid).class_disease_1;
        vhlthdetail.class_disease_2         := clmdetail(clmid).class_disease_2;
        vhlthdetail.class_disease_3         := clmdetail(clmid).class_disease_3;
        vhlthdetail.final_class_disease_1   := clmdetail(clmid).final_class_disease_1;
        vhlthdetail.final_class_disease_2   := clmdetail(clmid).final_class_disease_2;
        vhlthdetail.final_class_disease_3   := clmdetail(clmid).final_class_disease_3;

        vcancerstatus := koc_clm_hlth_hospt_utils.checkprovisionforcancer (vhlthdetail);

        --ASO %80 teminati var mi
        if vcancerstatus = 1
        then

            i := 1;
            --
            if nvl(clmdetail(clmid).status_code, 'PP') in ('PP')
            then
                --
                while i <= clmprovision.count
                loop
                    --
                    if nvl(clmprovision(i).cover_code, '0') = 'S767'
                    then
                        vASOcoverindxold := i;
                        exit;
                    end if;
                    i := i + 1;
                end loop;
            end if;

            getindemtotalsmdf (policyinfo.contract_id
                              ,policyinfo.partition_no
                              ,'AK'
                              ,'YI'
                              ,0
                              ,'S767'
                              ,policyinfo.package_id
                              ,policyinfo.package_date
                              ,trunc(p_provision_date)
                              ,p_user_id
                              ,0
                              ,0
                              ,vASOrefcur
                              );
            fetch vASOrefcur
            into vASOcover;
            close vASOrefcur;
        end if;
    end if;
    */
	---30.madde------------------------------------------------------------
    --aaktas
    --1KEZ kontrolü
    --Indem totals da 1 KEZ tanimli var mi
    Vhaspolicy1kez := Checkpolicyforindemnity(Policyinfo.Contract_Id,
                                              Policyinfo.Partition_No,
                                              Policyinfo.Package_Id,
                                              Policyinfo.Package_Date,
                                              Trunc(p_Provision_Date),
                                              '1KEZ');

    /*
        insert into tmp_koc_errors  (reference_code, process, error, sira, online_sq_no)
        values (policyinfo.contract_id || ':' || policyinfo.partition_no
               ,'vhaspolicy1kez : ' || vhaspolicy1kez
               ,policyinfo.contract_id || ':' || policyinfo.partition_no || ':' || policyinfo.package_id || ':' || policyinfo.package_date || ':' || trunc(p_provision_date)
               ,1
               ,-1000
               );
    */
    ---31.madde------------------------------------------------------------------------
    IF Vhaspolicy1kez = 1 THEN
      --hasar dosyalarinda 1KEZ teminati kullanilmis mi
      Vis1kezused := Checkprovisionforindemnity(Policyinfo.Contract_Id,
                                                Policyinfo.Partition_No,
                                                Policyinfo.Package_Id,
                                                Policyinfo.Package_Date,
                                                Trunc(p_Provision_Date),
                                                '1KEZ');

      /*
              insert into tmp_koc_errors  (reference_code, process, error, sira, online_sq_no)
              values (policyinfo.contract_id || ':' || policyinfo.partition_no
                     ,'vis1kezused : ' || vis1kezused
                     ,policyinfo.contract_id || ':' || policyinfo.partition_no || ':' || policyinfo.package_id || ':' || policyinfo.package_date || ':' || trunc(p_provision_date)
                     ,2
                     ,-1000
                     );
      */
      -- Daha önce 1KEZ kullanilmamis ancak mevcut dosya 1KEZ içeriyorsa limitleri güncelle
      -- checkprovisionforindemnity mevcut dosyanin 1KEZ içerdigini gösteremez
      IF Vis1kezused = 0 THEN
        i := 1;

        --
        WHILE i <= Clmprovision.Count LOOP
          --sadece onay alanlar
          IF Nvl(Clmprovision(i).Status_Code, 'PP') IN
             ('PP', 'PI', 'I', 'H', 'CP', 'TI', 'CPI') THEN
            --
            BEGIN
              SELECT Indemnity_Payment_Type
                INTO Vindempaymtype
                FROM Koc_Clm_Hlth_Indem_Totals
               WHERE Contract_Id = Policyinfo.Contract_Id
                 AND Partition_No = Policyinfo.Partition_No
                 AND Claim_Inst_Type = Clmdetail(Clmid).Claim_Inst_Type
                 AND Claim_Inst_Loc = Clmdetail(Clmid).Claim_Inst_Loc
                 AND Package_Id = Policyinfo.Package_Id
                 AND Package_Date = Policyinfo.Package_Date
                 AND Country_Group = Nvl(Koc_Clm_Hlth_Utils.Getcountrygroup(Clmdetail(Clmid)
                                                                            .Country_Code),
                                         0)
                 AND Cover_Code = Clmprovision(i).Cover_Code
                 AND Is_Pool_Cover = Nvl(Clmprovision(i).Is_Pool_Cover, 0)
                 AND Is_Special_Cover =
                     Nvl(Clmprovision(i).Is_Special_Cover, 0)
                 AND Is_Valid = 1
                 AND Validity_Start_Date <= Trunc(p_Provision_Date)
                 AND (Validity_End_Date >= Trunc(p_Provision_Date) OR
                     Validity_End_Date IS NULL)
                 AND Rownum < 2;
            EXCEPTION
              WHEN OTHERS THEN
                NULL;
            END;

            /*
                                insert into tmp_koc_errors  (reference_code, process, error, sira, online_sq_no)
                                values (policyinfo.contract_id || ':' || policyinfo.partition_no
                                       ,'vIndemPaymType : ' || vIndemPaymType
                                       ,policyinfo.contract_id || ':' ||
                                        policyinfo.partition_no || ':' ||
                                        clmdetail(clmid).claim_inst_type || ':' ||
                                        clmdetail(clmid).claim_inst_loc || ':' ||
                                        policyinfo.package_id || ':' ||
                                        policyinfo.package_date || ':' ||
                                        nvl(koc_clm_hlth_utils.getcountrygroup(clmdetail(clmid).country_code) , 0) || ':' ||
                                        clmprovision(i).cover_code || ':' ||
                                        nvl(clmprovision(i).is_pool_cover, 0) || ':' ||
                                        nvl(clmprovision(i).is_special_cover, 0) || ':' ||
                                        trunc(p_provision_date)
                                       ,3
                                       ,-1000
                                       );

            */
            --
            IF Nvl(Vindempaymtype, 'X') = '1KEZ' THEN
              Vis1kezused := 1;
              EXIT;
            END IF;
          END IF;

          i := i + 1;
        END LOOP;
      END IF;
    END IF;

    Set_Glis1kezused(Vis1kezused);
    --32.madde-----------------------------------------------------------------------------------
    --Dosya içerisinde 1KEZ varsa önceki AK da yapilan hasarlari AHK limitinden düs
 
    IF Get_Glis1kezused = 1 THEN
      /*
              insert into tmp_koc_errors  (reference_code, process, error, sira, online_sq_no)
              values (policyinfo.contract_id || ':' || policyinfo.partition_no
                     ,'vis1kezused : ' || vis1kezused
                     ,null
                     ,4
                     ,-1000
                     );
      */
      Setremaininglimitfor1kez(Policyinfo.Contract_Id,
                               Policyinfo.Partition_No);
    END IF;

    ---- provision kayitlari atiliyor.
    i          := 1;
	--- 33. madde ---------------------------------------------------------------------------------
    v_Trans_No := Getmaxtransno(Clmdetail(Clmid).Claim_Id,
                                Clmdetail(Clmid).Sf_No) + 1;
    --- 34. madde ----------------------------------------------------------
    WHILE i <= Clmprovision.Count LOOP
	  --34.a-------------------------------------------------------------
      -- banko kullanicisi inceleme statüsündeki lokasyon üzerinde islem yapamaz
      -- red veya provizyon statüsündeki lokasyon üzerinde islem yapilamaz	  
      IF (Userinfo.User_Type = 7 AND
         Nvl(Clmprovision(i).Status_Code, 'PP') IN ('I', 'H')) OR
         Nvl(Clmprovision(i).Status_Code, 'PP') IN ('R', 'P') THEN
        GOTO Nextprovision;
      END IF;

      --aaktas
      --23032015
      --webpos KFS poliçe
      /*
      if vASOcoverindxnew > 0 and i = vASOcoverindxnew and nvl(clmprovision(vASOcoverindxnew).request_amount, 0) = 0
      then
          goto nextprovision;
      end if;
      */
      --34.b---------------------------------------------------------------
      p_Prov_Sys_Time := SYSDATE;

      -- reverse islemi yapilmasi durumu için
      -- provizyonun degismemis hali aliniyor
      BEGIN
        SELECT *
          INTO v_Clmprovision
          FROM (SELECT a.*
                  FROM Web_Clm_Hlth_Provisions a
                 WHERE a.Claim_Id = Clmdetail(Clmid).Claim_Id
                   AND a.Sf_No = Clmdetail(Clmid).Sf_No
                   AND a.Add_Order_No = Clmdetail(Clmid).Add_Order_No
                   AND a.Cover_Code = Clmprovision(i).Cover_Code
                   AND a.Location_Code = Clmprovision(i).Location_Code
                UNION
                SELECT a.*
                  FROM Koc_Clm_Hlth_Provisions a
                 WHERE a.Claim_Id = Clmdetail(Clmid).Claim_Id
                   AND a.Sf_No = Clmdetail(Clmid).Sf_No
                   AND a.Add_Order_No = Clmdetail(Clmid).Add_Order_No
                   AND a.Cover_Code = Clmprovision(i).Cover_Code
                   AND a.Location_Code = Clmprovision(i).Location_Code
                   AND NOT EXISTS
                 (SELECT 1
                          FROM Web_Clm_Hlth_Provisions b
                         WHERE b.Claim_Id = a.Claim_Id
                           AND b.Sf_No = a.Sf_No
                           AND b.Add_Order_No = a.Add_Order_No
                           AND b.Cover_Code = a.Cover_Code
                           AND b.Location_Code = a.Location_Code));
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
      -- 34.c --------------------------------------------------------------
      -- inceleme statüsündeki ve provizyon almis fakat degisiklik yapilmis
      -- lokasyon ve coverlari sil çünkü tekrar insert olacak

      --'CP','CPI','CPR' cover code degismiyor. cover_code bazinda silinmeli
      --'I' cover code degisebilir tüm inceleme kayitlari silinmeli
      IF Nvl(Clmprovision(i).Status_Code, 'PP') IN
         ('PP', 'CP', 'CPI', 'CPR', 'PR', 'CPDEL') THEN
        DELETE Koc_Clm_Hlth_Provisions
         WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
           AND Sf_No = Clmdetail(Clmid).Sf_No
           AND Add_Order_No = Clmdetail(Clmid).Add_Order_No
           AND Cover_Code = Clmprovision(i).Cover_Code
           AND Location_Code = Clmprovision(i).Location_Code;

        DELETE Koc_Clm_Hlth_Proc_Detail
         WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
           AND Sf_No = Clmdetail(Clmid).Sf_No
           AND Add_Order_No = Clmdetail(Clmid).Add_Order_No
           AND Cover_Code = Clmprovision(i).Cover_Code
           AND Location_Code = Clmprovision(i).Location_Code;

        DELETE Koc_Clm_Hlth_Reject_Loss
         WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
           AND Sf_No = Clmdetail(Clmid).Sf_No
           AND Add_Order_No = Clmdetail(Clmid).Add_Order_No
           AND Cover_Code = Clmprovision(i).Cover_Code
           AND Location_Code = Clmprovision(i).Location_Code
           AND Barcode = 0
           AND Ubb_Code = '0';

        DELETE Koc_Clm_Medicine_Indem_Det
         WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
           AND Sf_No = Clmdetail(Clmid).Sf_No
           AND Add_Order_No = Clmdetail(Clmid).Add_Order_No
           AND Cover_Code = Clmprovision(i).Cover_Code
           AND Location_Code = Clmprovision(i).Location_Code;

        DELETE Koc_Clm_Hlth_Item_Detail
         WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
           AND Sf_No = Clmdetail(Clmid).Sf_No
           AND Add_Order_No = Clmdetail(Clmid).Add_Order_No
           AND Cover_Code = Clmprovision(i).Cover_Code
           AND Location_Code = Clmprovision(i).Location_Code;
      END IF;
      -- 34.d ----------------------------------------------------------------------
      IF Nvl(Clmprovision(i).Status_Code, 'PP') IN ('I', 'H', 'CIR', 'TI') THEN
        DELETE Koc_Clm_Hlth_Item_Detail
         WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
           AND Sf_No = Clmdetail(Clmid).Sf_No
           AND Add_Order_No = Clmdetail(Clmid).Add_Order_No
           AND (Cover_Code, Location_Code) IN
               (SELECT Cover_Code, Location_Code
                  FROM Koc_Clm_Hlth_Provisions
                 WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
                   AND Sf_No = Clmdetail(Clmid).Sf_No
                   AND Add_Order_No = Clmdetail(Clmid).Add_Order_No
                   AND Status_Code IN ('I', 'H', 'CIR', 'TI'));

        DELETE Koc_Clm_Medicine_Indem_Det
         WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
           AND Sf_No = Clmdetail(Clmid).Sf_No
           AND Add_Order_No = Clmdetail(Clmid).Add_Order_No
           AND (Cover_Code, Location_Code) IN
               (SELECT Cover_Code, Location_Code
                  FROM Koc_Clm_Hlth_Provisions
                 WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
                   AND Sf_No = Clmdetail(Clmid).Sf_No
                   AND Add_Order_No = Clmdetail(Clmid).Add_Order_No
                   AND Status_Code IN ('I', 'H', 'CIR', 'TI'));

        DELETE Koc_Clm_Hlth_Proc_Detail
         WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
           AND Sf_No = Clmdetail(Clmid).Sf_No
           AND Add_Order_No = Clmdetail(Clmid).Add_Order_No
           AND (Cover_Code, Location_Code) IN
               (SELECT Cover_Code, Location_Code
                  FROM Koc_Clm_Hlth_Provisions
                 WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
                   AND Sf_No = Clmdetail(Clmid).Sf_No
                   AND Add_Order_No = Clmdetail(Clmid).Add_Order_No
                   AND Status_Code IN ('I', 'H', 'CIR', 'TI'));

        DELETE Koc_Clm_Hlth_Reject_Loss
         WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
           AND Sf_No = Clmdetail(Clmid).Sf_No
           AND Add_Order_No = Clmdetail(Clmid).Add_Order_No
           AND Barcode = 0
           AND Ubb_Code = '0'
           AND (Cover_Code, Location_Code) IN
               (SELECT Cover_Code, Location_Code
                  FROM Koc_Clm_Hlth_Provisions
                 WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
                   AND Sf_No = Clmdetail(Clmid).Sf_No
                   AND Add_Order_No = Clmdetail(Clmid).Add_Order_No
                   AND Status_Code IN ('I', 'H', 'CIR', 'TI'));

        DELETE Koc_Clm_Hlth_Provisions
         WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
           AND Sf_No = Clmdetail(Clmid).Sf_No
           AND Add_Order_No = Clmdetail(Clmid).Add_Order_No
           AND Status_Code IN ('I', 'H', 'CIR', 'TI');
      END IF;
      ---------34.e----------------------------------------------------------
      v_Loc_Status_Code := Getstatuscode(Clmprovision(i).Status_Code,
                                         Userinfo.User_Type);
	  ---------34.f----------------------------------------------------------									 
      v_Country_Group   := Koc_Clm_Hlth_Utils.Getcountrygroup(Clmprovision(i)
                                                              .Country_Code);

      /*04022015 abdullah aktas
      modüler saglik koc_clm_hlth_provisions tablosun teminatin sub_package_id ve sub_package_date
      degerleri aktariliyor
      */
	  --- 34.g get_sub_package ----------------------------------------------------------------
      Vsubpackageid   := NULL;
      Vsubpackagedate := NULL;
      Koc_Clm_Hlth_Utils.Getsubpackage(Policyinfo.Contract_Id,
                                       Policyinfo.Partition_No,
                                       Policyinfo.Package_Id,
                                       Policyinfo.Package_Date,
                                       Clmprovision(i).Cover_Code,
                                       p_Provision_Date,
                                       Vsubpackageid,
                                       Vsubpackagedate);

      p_Raise := p_Raise || Clmprovision(i).Cover_Code || ':' ||
                 Nvl(Clmprovision(i).Status_Code, 'PP');
      ----- 34.h  call_reverse_remaining --------------------------------------------------------
      IF Nvl(Clmprovision(i).Status_Code, 'PP') IN
         ('CP', 'CPI', 'CPR', 'CPDEL') AND p_Contract_Id IS NOT NULL THEN
        IF v_Clmdetail.Claim_Id IS NOT NULL AND
           v_Clmprovision.Claim_Id IS NOT NULL THEN
          Reverseremainig(p_Contract_Id,
                          p_Partition_No,
                          p_Realization_Date,
                          p_User_Id,
                          v_Clmdetail,
                          v_Clmprovision);
        END IF;
      END IF;
     ------- 34.i call_compute_remaining -----------------------------------------------------------
      -- yalnizca onay almis ise kalan limit güncellenir.
      IF (Nvl(Clmprovision(i).Status_Code, 'PP') IN
         ('PP', 'PI', 'I', 'H', 'CP', 'TI') OR
         (Nvl(Clmprovision(i).Status_Code, 'PP') IN
         ('CPI', 'I', 'H', 'TI') AND Userinfo.User_Type != 7)) AND
         p_Contract_Id IS NOT NULL THEN
        v_Tlp_Dlmms_Grkn_Cvr := 0;
        j                    := 1;

        --
        IF Clmdetail(Clmid)
         .Communication_No IS NULL OR Clmdetail(Clmid)
           .Request_System IN
            ('OPUS', 'WEB-ECZ', 'WEBPOS', 'PORTAL', 'ULAK', 'WS') THEN
          WHILE j <= Clmrejection.Count LOOP
            --
            IF Clmrejection(j)
             .Cover_Code = Clmprovision(i).Cover_Code AND Clmrejection(j)
               .Main_Code = '16' AND Clmrejection(j).Item_Code = '12' THEN
              v_Tlp_Dlmms_Grkn_Cvr := Nvl(v_Tlp_Dlmms_Grkn_Cvr, 0) +
                                      Nvl(Clmrejection(j).Refuse_Amount, 0);
            END IF;

            j := j + 1;
          END LOOP;
        END IF;

        /*         IF v_Sgk_Use = 1 -- mustafaku sgk TSS de teminatlara dagilmamali
        THEN
            IF Nvl(Clmdetail(Clmid).Is_Complementary, 0) = 1
            THEN
                v_Sum_Claim_Amount := Nvl(Clmprovision(i).Request_Amount, 0) - Nvl(v_Tlp_Dlmms_Grkn_Cvr, 0);
            ELSE
                v_Sum_Claim_Amount := Nvl(Clmprovision(i).Request_Amount, 0) - Nvl(v_Tlp_Dlmms_Grkn_Cvr, 0) - Nvl(Clmprovision(i).Sgk_Amount, 0);
            END IF;
        ELSE
            v_Sum_Claim_Amount := Nvl(Clmprovision(i).Request_Amount, 0) - Nvl(v_Tlp_Dlmms_Grkn_Cvr, 0) - Nvl(Clmprovision(i).Refusal_Amount, 0);
        END IF;*/
        --mustafaku 13.01.2017

        IF Nvl(Clmdetail(Clmid).Is_Complementary, 0) = 1 THEN
          v_Sum_Claim_Amount := Nvl(Clmprovision(i).Request_Amount, 0) -
                                v_Tlp_Dlmms_Grkn_Cvr -
                                Nvl(Clmprovision(i).Refusal_Amount, 0);
        ELSE
          IF Nvl(Clmprovision(i).Sgk_Amount, 0) >=
             Nvl(Clmprovision(i).Refusal_Amount, 0)

           THEN
            v_Sgkmi_Redmi_Tutar := Nvl(Clmprovision(i).Sgk_Amount, 0);
            v_Sum_Claim_Amount  := Nvl(Clmprovision(i).Request_Amount, 0) -
                                   v_Tlp_Dlmms_Grkn_Cvr -
                                   Nvl(Clmprovision(i).Sgk_Amount, 0);
          ELSE
            v_Sgkmi_Redmi_Tutar := Nvl(Clmprovision(i).Sgk_Amount, 0);
            v_Sum_Claim_Amount  := Nvl(Clmprovision(i).Request_Amount, 0) -
                                   v_Tlp_Dlmms_Grkn_Cvr -
                                   Nvl(Clmprovision(i).Refusal_Amount, 0);
          END IF;
        END IF;

        --hakan keks
        IF Policyinfo.Partition_Type = 'KEKS' THEN
          IF Nvl(v_Sum_Claim_Amount, 0) > 0 AND
             Nvl(p_Exemption_Amount, 0) > 0 THEN
            IF Nvl(v_Sum_Claim_Amount, 0) > Nvl(p_Exemption_Amount, 0) THEN
              v_Sum_Claim_Amount := Nvl(v_Sum_Claim_Amount, 0) -
                                    Nvl(p_Exemption_Amount, 0);
              Clmprovision(i).Exemption_Amount := p_Exemption_Amount;
              p_Exemption_Amount := 0;
            ELSE
              Clmprovision(i).Exemption_Amount := v_Sum_Claim_Amount;
              p_Exemption_Amount := Nvl(p_Exemption_Amount, 0) -
                                    Nvl(v_Sum_Claim_Amount, 0);
              v_Sum_Claim_Amount := 0;
            END IF;

            --hakan keks için muafiyet limiti düsülüyor
            BEGIN
              UPDATE Koc_Clm_Hlth_Event_Exempt a
                 SET a.Event_r_Exemption = Nvl(a.Event_r_Exemption, 0) -
                                           Nvl(Clmprovision(i)
                                               .Exemption_Amount,
                                               0),
                     a.Event_s_Exemption = Nvl(a.Event_s_Exemption, 0) +
                                           Nvl(Clmprovision(i)
                                               .Exemption_Amount,
                                               0)
               WHERE a.Event_Id = Clmdetail(Clmid).Rel_Claim_Id;
            EXCEPTION
              WHEN OTHERS THEN
                NULL;
            END;
          END IF;
        END IF;

        IF v_Sum_Claim_Amount < 0 THEN
          v_Sum_Claim_Amount := 0;
        END IF;

        Vclaiminsttype := Clmdetail(Clmid).Claim_Inst_Type;

        IF Vhaspolicy1kez = 1 THEN
          --daha önce 1KEZ kullanilmis veya dosyada 1KEZ varsa
          IF Vis1kezused = 1 THEN
            --teminatin 1KEZ tanimlisi var ise onu harca
            BEGIN
              SELECT Claim_Inst_Type
                INTO Vclaiminsttype
                FROM Koc_Clm_Hlth_Indem_Totals
               WHERE Contract_Id = Policyinfo.Contract_Id
                 AND Partition_No = Policyinfo.Partition_No
                 AND Claim_Inst_Loc = Clmdetail(Clmid).Claim_Inst_Loc
                 AND Package_Id = Policyinfo.Package_Id
                 AND Package_Date = Policyinfo.Package_Date
                 AND Country_Group = Nvl(Koc_Clm_Hlth_Utils.Getcountrygroup(Clmdetail(Clmid)
                                                                            .Country_Code),
                                         0)
                 AND Cover_Code = Clmprovision(i).Cover_Code
                 AND Is_Pool_Cover = Nvl(Clmprovision(i).Is_Pool_Cover, 0)
                 AND Is_Special_Cover =
                     Nvl(Clmprovision(i).Is_Special_Cover, 0)
                 AND Is_Valid = 1
                 AND Validity_Start_Date <= Trunc(p_Provision_Date)
                 AND (Validity_End_Date IS NULL OR
                     Validity_End_Date >= Trunc(p_Provision_Date))
                 AND Indemnity_Payment_Type = '1KEZ'
                 AND Rownum < 2;
            EXCEPTION
              WHEN OTHERS THEN
                Vclaiminsttype := Clmdetail(Clmid).Claim_Inst_Type;
            END;
          END IF;
        END IF;

        Computeremaning(Policyinfo.Contract_Id,
                        Policyinfo.Partition_No,
                        Policyinfo.Partner_Id,
                        Clmdetail(Clmid).Claim_Id,
                        Clmdetail(Clmid).Sf_No,
                        Clmdetail(Clmid).Institute_Code,
                        Vclaiminsttype,
                        Clmdetail(Clmid).Claim_Inst_Loc,
                        v_Country_Group,
                        Clmprovision(i).Location_Code,
                        Clmprovision(i).Cover_Code,
                        Clmprovision(i).Swift_Code,
                        p_Provision_Date,
                        Nvl(Clmdetail(Clmid).Provision_Date,
                            Clmdetail(Clmid).Invoice_Date),
                        p_Realization_Date,
                        p_Prov_Sys_Time,
                        v_Sum_Claim_Amount,
                        Nvl(Clmprovision(i).Req_Cure_Day_Count, 0),
                        Policyinfo,
                        Institutinfo,
                        p_User_Id,
                        Clmprovision(i).Is_Pool_Cover,
                        Clmprovision(i).Is_Special_Cover,
                        1,
                        p_Out_Provision_Amount,
                        p_Out_Day_Seance,
                        p_Out_Exemption_Rate,
                        p_Out_Exemption_Sum,
                        p_Out_Inst_Exemp_Sum,
                        p_r_Day_Seance,
                        p_r_Cover_Price,
                        p_Inst_Provision_Aval_Code,
                        p_Inst_Is_Cover_Val,
                        p_Out_Over_Price,
                        NULL,
                        Clmdetail(Clmid).Is_Referral);

        v_Rate_Dh := 1;

        IF Clmdetail(Clmid).Hlth_Srv_Pay = 1 THEN
          -- 191293 task
          v_Rate_Dh := 0;
        END IF;

        IF Clmdetail(Clmid).Dh_Inst = 1 THEN
          v_Rate_Dh := 0;
        END IF;

        Clmprovision(i).Provision_Total := Nvl(p_Out_Provision_Amount, 0) *
                                           (1 -
                                            (v_Rate_Dh *
                                            Nvl(p_Out_Exemption_Rate, 0)));
        Clmprovision(i).Day_Seance := Nvl(p_Out_Day_Seance, 0);
        Clmprovision(i).Exemption_Rate := v_Rate_Dh *
                                          Nvl(p_Out_Exemption_Rate, 0);

        IF Policyinfo.Partition_Type <> 'KEKS' THEN
          Clmprovision(i).Exemption_Amount := Nvl(p_Out_Exemption_Sum, 0);
          Clmprovision(i).Inst_Exemption_Amount := Nvl(p_Out_Inst_Exemp_Sum,
                                                       0);
        ELSE
          Clmprovision(i).Inst_Exemption_Amount := 0;
        END IF;
      END IF;
      --- 34.j set_ret_amouts-------------------------------------------------------------------------------- 
      IF Nvl(Clmprovision(i).Status_Code, 'PP') IN
         ('PR', 'CPR', 'CIR', 'R') THEN
        Clmprovision(i).Provision_Total := 0;
        Clmprovision(i).Day_Seance := 0;
        Clmprovision(i).Exemption_Amount := 0;
        Clmprovision(i).Inst_Exemption_Amount := 0;
        Clmprovision(i).Exemption_Rate := 0;
      END IF;
      ----------34.k---------------------------------------------------------------------------
      IF Nvl(Clmprovision(i).Status_Code, 'PP') IN
         ('PP', 'PI', 'PR', 'I', 'H', 'CP', 'CPI', 'CPR', 'CIR', 'TI') THEN
        INSERT INTO Koc_Clm_Hlth_Provisions
          (Claim_Id,
           Sf_No,
           Add_Order_No,
           Location_Code,
           Cover_Code,
           Provision_Total,
           Provision_Explanation,
           Day_Seance,
           Request_Amount,
           Refusal_Amount,
           Exemption_Amount,
           Swift_Code,
           Req_Cure_Day_Count,
           Status_Code,
           User_Id,
           Entry_Date,
           Exemption_Rate,
           Inst_Exemption_Amount,
           Proc_Request_Amount,
           Proc_Refusal_Amount,
           Inst_Request_Amount,
           Sys_Request_Amount,
           r_Cover_Price,
           Country_Code,
           Is_Pool_Cover,
           Is_Special_Cover,
           Prov_Date_Time,
           Sgk_Amount,
           Add_Proc_Amount,
           Is_Ex_Gratia,
           Time_Stamp,
           Order_No,
           Doctor_Code,
           Doctor_Status,
           Sub_Package_Id,
           Sub_Package_Date,
           Cover_Distribution_Amount,
           Inst_Add_Proc_Amount)
        VALUES
          (Clmdetail(Clmid).Claim_Id,
           Clmdetail(Clmid).Sf_No,
           Clmdetail(Clmid).Add_Order_No,
           Clmprovision(i).Location_Code,
           Nvl(Clmprovision(i).Cover_Code, '0'),
           Clmprovision(i).Provision_Total,
           Clmprovision(i).Provision_Explanation,
           Clmprovision(i).Day_Seance,
           Clmprovision(i).Request_Amount,
           Clmprovision(i).Refusal_Amount,
           Clmprovision(i).Exemption_Amount,
           Clmprovision(i).Swift_Code,
           Clmprovision(i).Req_Cure_Day_Count,
           v_Loc_Status_Code,
           Nvl(Clmprovision(i).User_Id, p_User_Id),
           Nvl(Clmprovision(i).Entry_Date, SYSDATE),
           Clmprovision(i).Exemption_Rate,
           p_Out_Inst_Exemp_Sum,
           Clmprovision(i).Proc_Request_Amount,
           Clmprovision(i).Proc_Refusal_Amount,
           Clmprovision(i).Inst_Request_Amount,
           Clmprovision(i).Sys_Request_Amount,
           p_r_Cover_Price,
           Clmprovision(i).Country_Code,
           Nvl(Clmprovision(i).Is_Pool_Cover, 0),
           Nvl(Clmprovision(i).Is_Special_Cover, 0),
           p_Prov_Sys_Time,
           Clmprovision(i).Sgk_Amount,
           Clmprovision(i).Add_Proc_Amount,
           Clmprovision(i).Is_Ex_Gratia,
           Clmprovision(i).Time_Stamp,
           Clmprovision(i).Order_No,
           Clmprovision(i).Doctor_Code,
           Clmprovision(i).Doctor_Status,
           Vsubpackageid,
           Vsubpackagedate,
           Clmprovision(i).Cover_Distribution_Amount,
           Clmprovision(i).Inst_Add_Proc_Amount);
        -----------34.l--------------------------------------------------------   
        j := 1;

        WHILE j <= Clmrejection.Count LOOP
          IF (Clmrejection(j).Cover_Code = Clmprovision(i).Cover_Code) AND
             (Clmrejection(j).Location_Code = Clmprovision(i).Location_Code) AND
             (Clmrejection(j).Barcode = 0) AND
             (Clmrejection(j).Ubb_Code = '0') THEN
            v_Err := v_Err || ' INSERT';

            INSERT INTO Koc_Clm_Hlth_Reject_Loss
              (Claim_Id,
               Sf_No,
               Add_Order_No,
               Location_Code,
               Cover_Code,
               Process_Code_Main,
               Process_Code_Sub1,
               Process_Code_Sub2,
               Main_Code,
               Item_Code,
               Sub_Item_Code,
               Refuse_Explanation,
               Refuse_Amount,
               Userid,
               Entry_Date,
               Barcode,
               Time_Stamp,
               Is_Bre_Decision,
               Seq_No,
               Ubb_Code)
            VALUES
              (Clmdetail(Clmid).Claim_Id,
               Clmdetail(Clmid).Sf_No,
               Clmdetail(Clmid).Add_Order_No,
               Clmrejection(j).Location_Code,
               Clmrejection(j).Cover_Code,
               Clmrejection(j).Process_Code_Main,
               Clmrejection(j).Process_Code_Sub1,
               Clmrejection(j).Process_Code_Sub2,
               Clmrejection(j).Main_Code,
               Clmrejection(j).Item_Code,
               Clmrejection(j).Sub_Item_Code,
               Clmrejection(j).Refuse_Explanation,
               Nvl(Clmrejection(j).Refuse_Amount, 0),
               Nvl(Clmrejection(j).Userid, p_User_Id),
               Trunc(SYSDATE),
               Nvl(Clmrejection(j).Barcode, 0),
               Clmrejection(j).Time_Stamp,
               Clmrejection(j).Is_Bre_Decision,
               Nvl(Clmrejection(j).Seq_No, 1),
               Nvl(Clmrejection(j).Ubb_Code, '0'));
          END IF;

          j := j + 1;
        END LOOP;
        -------------34.m------------------------------------------------------------------------   
        j := 1;

        WHILE j <= Clmprocdetail.Count LOOP
          IF (Clmprocdetail(j).Cover_Code = Clmprovision(i).Cover_Code) AND
             (Clmprocdetail(j).Location_Code = Clmprovision(i).Location_Code) THEN
            p_Raise := p_Raise || 'process:' || Clmprocdetail(j)
                      .Process_Code_Main || ':' ||
                       Nvl(Clmprocdetail(j).Status_Code, 'PP') || '/';

            IF Nvl(Clmprocdetail(j).Status_Code, 'PP') IN
               ('PP', 'CP', 'PI', 'PR', 'CPR', 'I', 'H', 'TI') OR Clmprovision(i)
              .Status_Code IN
               ('PP', 'CP', 'CPI', 'CPR', 'I', 'H', 'CIR', 'TI', 'PI', 'PR') THEN
              v_Proc_Status_Code := Getstatuscode(Clmprocdetail(j)
                                                  .Status_Code,
                                                  Userinfo.User_Type);

              --seq_no pk alaninin tekrarlanan islemlerde artarak insert islemi için yapildi
              Vseqno := NULL;

              WHILE 1 = 1 LOOP
                BEGIN
                  --
                  Vseqno := Nvl(Vseqno, 0) + 1;

                  --

                  INSERT INTO Koc_Clm_Hlth_Proc_Detail
                    (Claim_Id,
                     Sf_No,
                     Add_Order_No,
                     Location_Code,
                     Cover_Code,
                     Group_No,
                     Process_Code_Main,
                     Process_Code_Sub1,
                     Process_Code_Sub2,
                     Discount_Group_Code,
                     Indemnity_Amount,
                     Process_Group,
                     Userid,
                     Entrance_Date,
                     Process_Count,
                     Status_Code,
                     Swift_Code,
                     Inst_Indemnity_Amount,
                     Explanation,
                     Time_Stamp,
                     Drg_Code,
                     Doctor_Code,
                     Doctor_Status,
                     Sgk_Amount,
                     Order_No,
                     Vat_Rate,
                     Right_Left,
                     Proc_Type,
                     Physiotherapy_Session,
                     Diagnosis_Id,
                     Surgery_Id,
                     Seq_No,
                     Bre_Result_Code,
                     Req_Process_Name,
                     Req_Process_Code,
                     Req_Process_List_Type,
                     Related_Process,
                     Related_Process_List_Type,
                     Process_Date)
                  VALUES
                    (Clmdetail(Clmid).Claim_Id,
                     Clmdetail(Clmid).Sf_No,
                     Clmdetail(Clmid).Add_Order_No,
                     Clmprocdetail(j).Location_Code,
                     Clmprocdetail(j).Cover_Code,
                     Nvl(Clmprocdetail(j).Group_No, 0),
                     Clmprocdetail(j).Process_Code_Main,
                     Clmprocdetail(j).Process_Code_Sub1,
                     Clmprocdetail(j).Process_Code_Sub2,
                     Clmprocdetail(j).Discount_Group_Code,
                     Clmprocdetail(j).Indemnity_Amount,
                     Clmprocdetail(j).Process_Group,
                     Nvl(Clmprocdetail(j).Userid, p_User_Id),
                     Clmprocdetail(j).Entrance_Date,
                     Clmprocdetail(j).Process_Count,
                     v_Proc_Status_Code,
                     Clmprocdetail(j).Swift_Code,
                     Clmprocdetail(j).Inst_Indemnity_Amount,
                     Clmprocdetail(j).Explanation,
                     Clmprocdetail(j).Time_Stamp,
                     Clmprocdetail(j).Drg_Code,
                     Clmprocdetail(j).Doctor_Code,
                     Clmprocdetail(j).Doctor_Status,
                     Clmprocdetail(j).Sgk_Amount,
                     Clmprocdetail(j).Order_No,
                     Clmprocdetail(j).Vat_Rate,
                     Clmprocdetail(j).Right_Left,
                     Clmprocdetail(j).Proc_Type,
                     Clmprocdetail(j).Physiotherapy_Session,
                     Clmprocdetail(j).Diagnosis_Id,
                     Clmprocdetail(j).Surgery_Id,
                     Vseqno,
                     Clmprocdetail(j).Bre_Result_Code,
                     Clmprocdetail(j).Req_Process_Name,
                     Clmprocdetail(j).Req_Process_Code,
                     Clmprocdetail(j).Req_Process_List_Type,
                     Clmprocdetail(j).Related_Process,
                     Clmprocdetail(j).Related_Process_List_Type,
                     Clmprocdetail(j).Process_Date);

                  EXIT;
                EXCEPTION
                  WHEN Dup_Val_On_Index THEN
                    NULL;
                END;
              END LOOP;
            END IF;
          END IF;

          j := j + 1;
        END LOOP;
        ---------34.n------------------------------------------------------------------------------------
        j := 1;

        WHILE j <= Clmmedicineindem.Count LOOP
          IF (Clmmedicineindem(j).Cover_Code = Clmprovision(i).Cover_Code) AND
             (Clmmedicineindem(j)
             .Location_Code = Clmprovision(i).Location_Code) THEN
            IF Nvl(Clmprovision(i).Status_Code, 'PP') IN
               ('PP', 'CP', 'CPI', 'CPR', 'I', 'H', 'CIR', 'TI', 'PI', 'PR') THEN
              v_Proc_Status_Code := Getstatuscode(Clmmedicineindem(j)
                                                  .Status_Code,
                                                  Userinfo.User_Type);

              --seq_no pk alaninin tekrarlanan islemlerde artarak insert islemi için yapildi
              Vseqno := NULL;

              WHILE 1 = 1 LOOP
                --
                BEGIN
                  --
                  Vseqno := Nvl(Vseqno, 0) + 1;

                  --

                  INSERT INTO Koc_Clm_Medicine_Indem_Det
                    (Claim_Id,
                     Sf_No,
                     Add_Order_No,
                     Location_Code,
                     Cover_Code,
                     Barcode,
                     Unit,
                     Dose_Period,
                     Dose1,
                     Dose2,
                     Price,
                     Class_Disease_4,
                     Second_Barcode,
                     Equ_Medicine_App,
                     Dose3,
                     Dose3_Period,
                     Expiry_Date,
                     Status_Code,
                     Dose4,
                     Dose4_Period,
                     Reject_Uncheck,
                     Reject_Unit,
                     Reject_Explanation,
                     Control_Expiry_Date,
                     Second_Barc_Given,
                     Note_Id,
                     Barcode_2d,
                     Barcode_Serial_Num,
                     Barcode_Expiry_Date,
                     Barcode_Lot_Num,
                     Time_Stamp,
                     Item_Type,
                     Drg_Code,
                     Order_No,
                     Surgery_Id,
                     Vat_Rate,
                     Explanation,
                     Bre_Result_Code,
                     Seq_No,
                     Process_Code,
                     Process_Code_List,
                     Req_Medicine_Name,
                     Req_Medicine_Barcode)
                  VALUES
                    (Clmdetail(Clmid).Claim_Id,
                     Clmdetail(Clmid).Sf_No,
                     Clmdetail(Clmid).Add_Order_No,
                     Clmmedicineindem(j).Location_Code,
                     Clmmedicineindem(j).Cover_Code,
                     Clmmedicineindem(j).Barcode,
                     Clmmedicineindem(j).Unit,
                     Clmmedicineindem(j).Dose_Period,
                     Clmmedicineindem(j).Dose1,
                     Clmmedicineindem(j).Dose2,
                     Clmmedicineindem(j).Price,
                     Clmmedicineindem(j).Class_Disease_4,
                     Clmmedicineindem(j).Second_Barcode,
                     Clmmedicineindem(j).Equ_Medicine_App,
                     Clmmedicineindem(j).Dose3,
                     Clmmedicineindem(j).Dose3_Period,
                     Clmmedicineindem(j).Expiry_Date,
                     v_Proc_Status_Code,
                     Clmmedicineindem(j).Dose4,
                     Clmmedicineindem(j).Dose4_Period,
                     Clmmedicineindem(j).Reject_Uncheck,
                     Clmmedicineindem(j).Reject_Unit,
                     Clmmedicineindem(j).Reject_Explanation,
                     Clmmedicineindem(j).Control_Expiry_Date,
                     Clmmedicineindem(j).Second_Barc_Given,
                     Clmmedicineindem(j).Note_Id,
                     Nvl(Clmmedicineindem(j).Barcode_2d, '0'),
                     Clmmedicineindem(j).Barcode_Serial_Num,
                     Clmmedicineindem(j).Barcode_Expiry_Date,
                     Clmmedicineindem(j).Barcode_Lot_Num,
                     Clmmedicineindem(j).Time_Stamp,
                     Clmmedicineindem(j).Item_Type,
                     Clmmedicineindem(j).Drg_Code,
                     Clmmedicineindem(j).Order_No,
                     Clmmedicineindem(j).Surgery_Id,
                     Clmmedicineindem(j).Vat_Rate,
                     Clmmedicineindem(j).Explanation,
                     Clmmedicineindem(j).Bre_Result_Code,
                     Vseqno,
                     Clmmedicineindem(j).Process_Code,
                     Clmmedicineindem(j).Process_Code_List,
                     Clmmedicineindem(j).Req_Medicine_Name,
                     Clmmedicineindem(j).Req_Medicine_Barcode);

                  EXIT;
                EXCEPTION
                  WHEN Dup_Val_On_Index THEN
                    NULL;
                END;
              END LOOP;

              -----   barkoda ait red nedenleri insert islemi			 
              Jj := 1;

              WHILE Jj <= Clmrejection.Count LOOP
                IF (Clmrejection(Jj).Cover_Code = Clmprovision(i).Cover_Code) AND
                   (Clmrejection(Jj)
                   .Location_Code = Clmprovision(i).Location_Code) AND
                   (Clmrejection(Jj).Barcode <> 0) AND
                   (Clmrejection(Jj).Barcode = Clmmedicineindem(j).Barcode) THEN
                  BEGIN
                    INSERT INTO Koc_Clm_Hlth_Reject_Loss
                      (Claim_Id,
                       Sf_No,
                       Location_Code,
                       Add_Order_No,
                       Cover_Code,
                       Process_Code_Main,
                       Process_Code_Sub1,
                       Process_Code_Sub2,
                       Main_Code,
                       Item_Code,
                       Sub_Item_Code,
                       Refuse_Explanation,
                       Refuse_Amount,
                       Userid,
                       Entry_Date,
                       Barcode,
                       Time_Stamp,
                       Seq_No,
                       Is_Bre_Decision,
                       Ubb_Code)
                    VALUES
                      (Clmdetail(Clmid).Claim_Id,
                       Clmdetail(Clmid).Sf_No,
                       Clmrejection(Jj).Location_Code,
                       Clmdetail(Clmid).Add_Order_No,
                       Clmrejection(Jj).Cover_Code,
                       Clmrejection(Jj).Process_Code_Main,
                       Clmrejection(Jj).Process_Code_Sub1,
                       Clmrejection(Jj).Process_Code_Sub2,
                       Clmrejection(Jj).Main_Code,
                       Clmrejection(Jj).Item_Code,
                       Clmrejection(Jj).Sub_Item_Code,
                       Clmrejection(Jj).Refuse_Explanation,
                       Nvl(Clmrejection(Jj).Refuse_Amount, 0),
                       Nvl(Clmrejection(Jj).Userid, p_User_Id),
                       Trunc(SYSDATE),
                       Nvl(Clmrejection(Jj).Barcode, 0),
                       Clmrejection(Jj).Time_Stamp,
                       Nvl(Clmrejection(Jj).Seq_No, 1),
                       Clmrejection(Jj).Is_Bre_Decision,
                       Nvl(Clmrejection(Jj).Ubb_Code, '0'));
                  EXCEPTION
                    WHEN Dup_Val_On_Index THEN
                      NULL;
                  END;
                END IF;

                Jj := Jj + 1;
              END LOOP;
              -----------------

            END IF;
          END IF;

          j := j + 1;
        END LOOP;
        --------------------34.o-----------------------------------------------------------
        j := 1;

        WHILE j <= Clmitemindem.Count LOOP
          IF (Clmitemindem(j).Cover_Code = Clmprovision(i).Cover_Code) AND
             (Clmitemindem(j).Location_Code = Clmprovision(i).Location_Code) THEN
            IF Nvl(Clmprovision(i).Status_Code, 'PP') IN
               ('PP', 'CP', 'CPI', 'CPR', 'I', 'H', 'CIR', 'TI', 'PI', 'PR') THEN
              v_Proc_Status_Code := Getstatuscode(Clmitemindem(j)
                                                  .Status_Code,
                                                  Userinfo.User_Type);

              Vseqno := NULL;

              WHILE 1 = 1 LOOP
                --
                BEGIN
                  --
                  Vseqno := Nvl(Vseqno, 0) + 1;

                  --

                  INSERT INTO Koc_Clm_Hlth_Item_Detail
                    (Claim_Id,
                     Sf_No,
                     Add_Order_No,
                     Location_Code,
                     Cover_Code,
                     Ubb_Code,
                     Quantity,
                     Price,
                     Item_Type,
                     Drg_Code,
                     Order_No,
                     Surgery_Id,
                     Vat_Rate,
                     Explanation,
                     Status_Code,
                     Time_Stamp,
                     Bre_Result_Code,
                     Seq_No,
                     Process_Code,
                     Process_Code_List,
                     Req_Item_Name,
                     Req_Item_Ubbcode)
                  VALUES
                    (Clmdetail(Clmid).Claim_Id,
                     Clmdetail(Clmid).Sf_No,
                     Clmdetail(Clmid).Add_Order_No,
                     Clmitemindem(j).Location_Code,
                     Clmitemindem(j).Cover_Code,
                     Clmitemindem(j).Ubb_Code,
                     Clmitemindem(j).Quantity,
                     Clmitemindem(j).Price,
                     Clmitemindem(j).Item_Type,
                     Clmitemindem(j).Drg_Code,
                     Clmitemindem(j).Order_No,
                     Clmitemindem(j).Surgery_Id,
                     Clmitemindem(j).Vat_Rate,
                     Clmitemindem(j).Explanation,
                     v_Proc_Status_Code,
                     Clmitemindem(j).Time_Stamp,
                     Clmitemindem(j).Bre_Result_Code,
                     Vseqno,
                     Clmitemindem(j).Process_Code,
                     Clmitemindem(j).Process_Code_List,
                     Clmitemindem(j).Req_Item_Name,
                     Clmitemindem(j).Req_Item_Ubbcode);

                  EXIT;
                EXCEPTION
                  WHEN Dup_Val_On_Index THEN
                    NULL;
                END;
              END LOOP;

              --malzemeye ait red nedenleri insert islemi			
              Jj := 1;

              WHILE Jj <= Clmrejection.Count LOOP
                IF (Clmrejection(Jj).Cover_Code = Clmprovision(i).Cover_Code) AND
                   (Clmrejection(Jj)
                   .Location_Code = Clmprovision(i).Location_Code) AND --(clmrejection (jj).barcode <> 0 ) and
                  --(clmrejection (jj).barcode = clmitemindem (j).ubb_code)
                   (Clmrejection(Jj).Ubb_Code <> 0) AND
                   (Clmrejection(Jj).Ubb_Code = Clmitemindem(j).Ubb_Code) THEN

                  BEGIN
                    INSERT INTO Koc_Clm_Hlth_Reject_Loss
                      (Claim_Id,
                       Sf_No,
                       Location_Code,
                       Add_Order_No,
                       Cover_Code,
                       Process_Code_Main,
                       Process_Code_Sub1,
                       Process_Code_Sub2,
                       Main_Code,
                       Item_Code,
                       Sub_Item_Code,
                       Refuse_Explanation,
                       Refuse_Amount,
                       Userid,
                       Entry_Date,
                       Barcode,
                       Time_Stamp,
                       Seq_No,
                       Is_Bre_Decision,
                       Ubb_Code)
                    VALUES
                      (Clmdetail(Clmid).Claim_Id,
                       Clmdetail(Clmid).Sf_No,
                       Clmrejection(Jj).Location_Code,
                       Clmdetail(Clmid).Add_Order_No,
                       Clmrejection(Jj).Cover_Code,
                       Clmrejection(Jj).Process_Code_Main,
                       Clmrejection(Jj).Process_Code_Sub1,
                       Clmrejection(Jj).Process_Code_Sub2,
                       Clmrejection(Jj).Main_Code,
                       Clmrejection(Jj).Item_Code,
                       Clmrejection(Jj).Sub_Item_Code,
                       Clmrejection(Jj).Refuse_Explanation,
                       Nvl(Clmrejection(Jj).Refuse_Amount, 0),
                       Nvl(Clmrejection(Jj).Userid, p_User_Id),
                       Trunc(SYSDATE),
                       Nvl(Clmrejection(Jj).Barcode, 0),
                       Clmrejection(Jj).Time_Stamp,
                       Nvl(Clmrejection(Jj).Seq_No, 1),
                       Clmrejection(Jj).Is_Bre_Decision,
                       Nvl(Clmrejection(Jj).Ubb_Code, '0'));
                  EXCEPTION
                    WHEN Dup_Val_On_Index THEN
                      NULL;
                  END;

                END IF;

                Jj := Jj + 1;
              END LOOP;
            END IF;
          END IF;

          j := j + 1;
        END LOOP;
        --34.p-----------------------------------------------------------------------------------
        -- yalnizca provizyon alan islemler trans tablolarina gider
        IF p_Contract_Id IS NOT NULL THEN
          v_Provision_Amount := Clmprovision(i).Provision_Total;
          v_Exemption_Amount := Clmprovision(i).Exemption_Amount;
          v_Request_Amount   := Clmprovision(i).Request_Amount;
          v_Reject_Amount    := Clmprovision(i).Refusal_Amount;

          IF Nvl(Clmprovision(i).Status_Code, 'PP') IN
             ('PR', 'R', 'CIR', 'CPR') THEN
            v_Provision_Amount := 0;
            v_Exemption_Amount := 0;
            v_Request_Amount   := 0;
            v_Reject_Amount    := 0;
          END IF;

          SELECT MIN(Process_Date)
            INTO v_Muallak_Date
            FROM Koc_Process_Close a
           WHERE a.Process_Type = 'CLMH'
             AND a.Agent_Int_Id = 12354
             AND a.Close_Date >= p_Provision_Date
             AND a.Status_Code = 1;

          v_Trans_Date := Trunc(p_Provision_Date);

          IF v_Muallak_Date > Trunc(p_Provision_Date) THEN
            v_Trans_Date := v_Muallak_Date;
          END IF;

          IF v_Loc_Status_Code = 'P' THEN
            v_Clm_Status := 'OPEN';
          ELSIF v_Loc_Status_Code IN ('I', 'H', 'TI') THEN
            v_Clm_Status := 'PENDING';
          ELSIF v_Loc_Status_Code = 'C' THEN
            v_Clm_Status := 'CANCELLED';
          ELSIF v_Loc_Status_Code IN ('TAH', 'ODE', 'MK', 'R') THEN
            v_Clm_Status := 'CLOSED';
          ELSE
            v_Clm_Status := NULL;
          END IF;

          v_Currency_Exchange_Rate := 1;

          IF Nvl(Clmdetail(Clmid).Swift_Code, Base_Swift_Code) !=
             Base_Swift_Code THEN
            v_Indem_Date := Nvl(Clmdetail(Clmid).Provision_Date,
                                Nvl(Clmdetail(Clmid).Date_Of_Loss,
                                    Clmdetail(Clmid).Invoice_Date));

            Getindemtotals(Policyinfo.Contract_Id,
                           Policyinfo.Partition_No,
                           Clmdetail              (Clmid).Claim_Inst_Type,
                           Clmdetail              (Clmid).Claim_Inst_Loc,
                           v_Country_Group,
                           Clmprovision           (i).Cover_Code,
                           v_Indem_Date,
                           0,
                           0,
                           p_User_Id,
                           Clmprovision           (i).Is_Pool_Cover,
                           Clmprovision           (i).Is_Special_Cover,
                           Icur);

            FETCH Icur
              INTO Indeminfo;

            CLOSE Icur;

            v_Cover_Swf := Indeminfo.Swift_Code;

            SELECT Decode(v_Cover_Swf,
                          Base_Swift_Code,
                          Pay_Clearing_System_Id,
                          Pay_Swf_Clear_Sys_Id),
                   Decode(v_Cover_Swf,
                          Base_Swift_Code,
                          Pay_Curr_Get_Type,
                          Pay_Swf_Curr_Get_Type),
                   Decode(v_Cover_Swf,
                          Base_Swift_Code,
                          Pay_Exch_Dates,
                          Pay_Swf_Exch_Dates)
              INTO v_Pay_Clearing_System_Id,
                   v_Pay_Curr_Get_Type,
                   v_Exch_Date
              FROM Koc_Oc_Prod_Partition_Rel
             WHERE Product_Id = Policyinfo.Product_Id
               AND Partition_Type = Policyinfo.Partition_Type
               AND Validity_Start_Date <= Policyinfo.Term_Start_Date
               AND Nvl(Validity_End_Date, Policyinfo.Term_Start_Date) >=
                   Policyinfo.Term_Start_Date;

            IF v_Exch_Date = 'FAT' THEN
              v_Curr_Date := Nvl(Clmdetail(Clmid).Provision_Date,
                                 Clmdetail(Clmid).Invoice_Date);
            ELSIF v_Exch_Date = 'OLAY' THEN
              v_Curr_Date := Nvl(Clmdetail(Clmid).Provision_Date,
                                 Nvl(Clmdetail(Clmid).Date_Of_Loss,
                                     Clmdetail(Clmid).Invoice_Date));
            ELSIF v_Exch_Date = 'TAH' THEN
              v_Curr_Date := p_Realization_Date;
            ELSE
              v_Curr_Date := Nvl(Clmdetail(Clmid).Provision_Date,
                                 Nvl(Clmdetail(Clmid).Date_Of_Loss,
                                     Clmdetail(Clmid).Invoice_Date));
            END IF;

            v_Currency_Exchange_Rate := Koc_Curr_Utils.Retrieve_Currency_Rate(Clmdetail(Clmid)
                                                                              .Swift_Code,
                                                                              v_Pay_Curr_Get_Type,
                                                                              Trunc(v_Curr_Date),
                                                                              v_Pay_Clearing_System_Id,
                                                                              TRUE);
          END IF;

          SELECT Clm_Int_Ref_Seq.Nextval INTO v_Int_Ref FROM Dual;

          IF v_Ext_Reference IS NULL THEN
            SELECT Ext_Reference
              INTO v_Ext_Reference
              FROM Clm_Subfiles
             WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
               AND Sf_No = Clmdetail(Clmid).Sf_No;
          END IF;

          OPEN Curprovsum(Clmdetail   (Clmid).Claim_Id,
                          Clmdetail   (Clmid).Sf_No,
                          Clmdetail   (Clmid).Add_Order_No,
                          Clmprovision(i).Cover_Code);

          FETCH Curprovsum
            INTO Recprovsum;

          CLOSE Curprovsum;

          INSERT INTO Clm_Trans
            (Claim_Id,
             Sf_No,
             Trans_No,
             Movement_Id,
             Assignee,
             Sf_Total_Type,
             Trans_Type,
             Trans_Date,
             Clm_Status,
             Trans_Amt,
             Trans_Amt_Swf,
             Rsv_Amt,
             Trans_Base_Amt,
             Int_Ref,
             Supp_Id,
             Ip_No,
             Oar_No,
             Ext_Reference)
          VALUES
            (Clmdetail(Clmid).Claim_Id,
             Clmdetail(Clmid).Sf_No,
             v_Trans_No,
             1,
             p_User_Id,
             10,
             10,
             v_Trans_Date,
             'TRANS',
             Recprovsum.Provision_Total,
             Clmprovision(i).Swift_Code,
             Recprovsum.Refusal_Amount,
             Recprovsum.Request_Amount,
             v_Int_Ref,
             Institutinfo.Supp_Id,
             Policyinfo.Ip_No,
             Policyinfo.Partition_No,
             v_Ext_Reference);

          BEGIN
            Koc_Clm_Bordro.Alz_Hlth_Bordro_Trans_Log(Clmdetail(Clmid)
                                                     .Claim_Id,
                                                     v_Trans_No,
                                                     'KOC_CLM_HLTH_TRNX-3494',
                                                     NULL,
                                                     1);
          EXCEPTION
            WHEN OTHERS THEN
              BEGIN
                Koc_Clm_Bordro.Alz_Hlth_Bordro_Trans_Log(Clmdetail(Clmid)
                                                         .Claim_Id,
                                                         v_Trans_No,
                                                         'KOC_CLM_HLTH_TRNX-3494',
                                                         NULL,
                                                         1,
                                                         Substr(SQLERRM,
                                                                1,
                                                                950));
              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;
          END;

          INSERT INTO Koc_Clm_Trans_Ext
            (Claim_Id,
             Sf_No,
             Add_Order_No,
             Trans_No,
             Exemption_Amount,
             Hlth_Cover_Code,
             Currency_Exchange_Rate)
          VALUES
            (Clmdetail(Clmid).Claim_Id,
             Clmdetail(Clmid).Sf_No,
             Clmdetail(Clmid).Add_Order_No,
             v_Trans_No,
             Recprovsum.Exemption_Amount,
             Clmprovision(i).Cover_Code,
             v_Currency_Exchange_Rate);

          SELECT Clm_Status_Id_Seq.Nextval INTO v_Status_Id FROM Dual;

          INSERT INTO Clm_Status_History
            (Status_Id,
             Claim_Id,
             Clm_Line_Id,
             Clm_Level,
             Clm_Status,
             Csh_Date,
             Csh_Username,
             Sf_No,
             Trans_No)
          VALUES
            (v_Status_Id,
             Clmdetail(Clmid).Claim_Id,
             20,
             'TRANS',
             v_Clm_Status,
             Trunc(SYSDATE),
             p_User_Id,
             1,
             v_Trans_No);

          INSERT INTO Koc_Clm_Status_History_Ext
            (Status_Id,
             Claim_Id,
             Sf_No,
             Clm_Status,
             Process_Date,
             Userid,
             Explanation)
          VALUES
            (v_Status_Id,
             Clmdetail(Clmid).Claim_Id,
             Clmdetail(Clmid).Sf_No,
             v_Clm_Status,
             SYSDATE,
             p_User_Id,
             NULL);

          v_Trans_No := v_Trans_No + 1;
        END IF;
      END IF;

      <<nextprovision>>
      i := i + 1;
    END LOOP;
    --- 35. madde ----------------------------------------------------------------------------------
    --Complex Cover Distribution--Complex Cover Distribution--Complex Cover Distribution
    --Complex Cover Distribution--Complex Cover Distribution--Complex Cover Distribution
    --Complex Cover Distribution--Complex Cover Distribution--Complex Cover Distribution

    SELECT Parameter
      INTO v_Complex_Enable
      FROM Koc_v_Cp_Health_Look_Up
     WHERE Look_Up_Code = 'CALCRULE_E';

    IF v_Complex_Enable = '1' THEN

      SELECT COUNT(1)
        INTO v_Complex_Cover
        FROM Alz_Hltprv_Bre_Log l
       WHERE l.Claim_Id = Clmdetail(Clmid).Claim_Id
         AND l.Sf_No = Clmdetail(Clmid).Sf_No
         AND l.Add_Order_No = Clmdetail(Clmid).Add_Order_No
         AND l.Decision_Type = 'JEST_TEM'
         AND l.Opus_Decision = 1;

      --OPEN c_Complex_Cover(Clmdetail(Clmid).Claim_Id, Clmdetail(Clmid).Sf_No, Clmdetail(Clmid).Add_Order_No);

      --FETCH c_Complex_Cover
      --    INTO v_Complex_Cover;

      --CLOSE c_Complex_Cover;

      IF v_Complex_Cover > 0 THEN

        COMMIT;

        Alz_Hltprv_Calc_Rule_Utils.Get_Calculation_Result(Clmdetail,
                                                          Clmprovision,
                                                          Clmrejection,
                                                          p_Realization_Date,
                                                          p_User_Id,
                                                          Vclaiminsttype,
                                                          v_Country_Group,
                                                          p_Provision_Date,
                                                          p_Prov_Sys_Time);
      END IF;
    END IF;

    --Complex Cover Distribution--Complex Cover Distribution--Complex Cover Distribution
    --Complex Cover Distribution--Complex Cover Distribution--Complex Cover Distribution
    --Complex Cover Distribution--Complex Cover Distribution--Complex Cover Distribution
    -- 36.madde ----------------------------------------------------------------------
    ------ red mektuplari için kayit atiliyor.
    SELECT COUNT(*)
      INTO v_Cnt
      FROM Koc_Clm_Hlth_Reject_Loss
     WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
       AND Sf_No = Clmdetail(Clmid).Sf_No
       AND Add_Order_No = Clmdetail(Clmid).Add_Order_No;

    IF v_Cnt > 0 THEN
      SELECT COUNT(*)
        INTO v_Cnt
        FROM Koc_Clm_Ltr_Doc_Process
       WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
         AND Sf_No = Clmdetail(Clmid).Sf_No
         AND Add_Order_No = Clmdetail(Clmid).Add_Order_No
         AND Letter_Type = 3;

      IF v_Cnt <= 0 THEN
        SELECT Nvl(MAX(Letter_No), 0) + 1
          INTO v_Letter_No
          FROM Koc_Clm_Ltr_Doc_Process
         WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
           AND Sf_No = Clmdetail(Clmid).Sf_No
           AND Add_Order_No = Clmdetail(Clmid).Add_Order_No;

        INSERT INTO Koc_Clm_Ltr_Doc_Process
          (Claim_Id,
           Sf_No,
           Add_Order_No,
           Letter_No,
           Letter_Type,
           Letter_Occurence_Date)
        VALUES
          (Clmdetail(Clmid).Claim_Id,
           Clmdetail(Clmid).Sf_No,
           Clmdetail(Clmid).Add_Order_No,
           v_Letter_No,
           3,
           Trunc(SYSDATE));
      END IF;
    END IF;
    -- 37.madde---------------------------------------------------------------
    BEGIN
      v_Prov_Total := Koc_Clm_Hlth_Utils.Getsumprvforstatement(Clmdetail(Clmid)
                                                               .Claim_Id,
                                                               1,
                                                               1);

      UPDATE Koc_Clm_Hlth_Prov_Statemnt a
         SET a.Invoice_Total = v_Prov_Total
       WHERE a.Claim_Id = Clmdetail(Clmid).Claim_Id
         AND a.Sf_No = Clmdetail(Clmid).Sf_No;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    -- 38.madde ------------------------------------------------------
    -->02/04/2008 yetki limitleri ile ilgili ekleme BÇ
    OPEN Curclaimsum(Clmdetail(Clmid).Claim_Id,
                     Clmdetail(Clmid).Sf_No,
                     Clmdetail(Clmid).Add_Order_No);

    FETCH Curclaimsum
      INTO Recclaimsum;

    CLOSE Curclaimsum;

    BEGIN
      DELETE Koc_Clm_Hlth_Prov_Limit
       WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
         AND Sf_No = Clmdetail(Clmid).Sf_No
         AND Add_Order_No = Clmdetail(Clmid).Add_Order_No;
    END;
    -- 39. madde ---------------------------------------------------------
    BEGIN
      --
      IF Getprovisionuserlimit(p_User_Id, Clmdetail(Clmid).Institute_Code) <
         Recclaimsum.Provision_Total OR
         (Nvl(Trunc(Clmdetail(Clmid).Discharge_Date), Trunc(SYSDATE)) -
          Trunc(Clmdetail(Clmid).Hospitalize_Date) > 10) THEN
        INSERT INTO Koc_Clm_Hlth_Prov_Limit
          (Claim_Id,
           Add_Order_No,
           Sf_No,
           Contract_Id,
           Partition_No,
           Group_Code,
           Claim_Status,
           Provision_Total,
           Request_Amount,
           Provision_User,
           Provision_Date,
           Apply_Admin_User,
           Apply_Admin_Date,
           Apply_Manager_User,
           Apply_Manager_Date,
           Apply_Gmanager_User,
           Apply_Gmanager_Date)
        VALUES
          (Clmdetail(Clmid).Claim_Id,
           Clmdetail(Clmid).Add_Order_No,
           Clmdetail(Clmid).Sf_No,
           p_Contract_Id,
           p_Partition_No,
           Nvl(Clmdetail(Clmid).Group_Code, Policyinfo.Group_Code),
           v_Status_Code,
           Recclaimsum.Provision_Total,
           Recclaimsum.Request_Amount,
           p_User_Id,
           Nvl(Clmdetail(Clmid).Provision_Date, NULL),
           NULL,
           NULL,
           NULL,
           NULL,
           NULL,
           NULL);
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    <<son>>
    Hlth_Clm_Check(Clmdetail(Clmid).Claim_Id,
                   Clmdetail(Clmid).Sf_No,
                   Clmdetail(Clmid).Add_Order_No);

    --20150408 emre.elcik -- Dosya Otomatik ONAY yada RED cevabi döndügünde sms gönderir..
    -- 40.madde --------------------------------------------
    Is_Hlth_Clm_Check(Clmdetail  (Clmid).Claim_Id,
                      Clmdetail  (Clmid).Sf_No,
                      Clmdetail  (Clmid).Add_Order_No,
                      v_Clm_Check,
                      v_Error_Exp);

    /*  INSERT INTO mustafaku.Mk_Sms_Log_Table (C1, C2, C3, C4) VALUES (glbl_sendsms,
    ' v_status_code:'||v_status_code ||' claim_id:'||clmdetail(clmid).claim_id||
    ' sf_no:'||clmdetail(clmid).sf_no ||' add_order_no:'||clmdetail (clmid).add_order_no||
    ' p_contract_id:'||p_contract_id||' p_partition_no:'||p_partition_no ||' glbl_sendsms:'||glbl_sendsms
    , '1', Sysdate);         */
    -- 41. madde ----------------------------------------------------------
    IF Nvl(v_Clm_Check, 0) <> 1 THEN
      -- PP den P ye R ye döndüysen..sms gönder..
      /* Retler PR olarak geliyor bu if retler için sms gödnerilmemesine neden oluyordu mustafaku 03.09.2015

       If      nvl( clmdetail (clmid).status_code, 'PP' ) = 'PP'
         And  v_status_code in ('P', 'R')
         And  nvl(glbl_sendsms,0)  <> 1
      Then*/
      IF ((Nvl(Clmdetail(Clmid).Status_Code, 'PP') = 'PP' AND
         v_Status_Code IN ('P')) OR
         (Nvl(Clmdetail(Clmid).Status_Code, 'PR') = 'PR' AND
         v_Status_Code IN ('R'))) AND Nvl(Glbl_Sendsms, 0) <> 1 THEN
        /*  INSERT INTO  mustafaku.Mk_Sms_Log_Table (C1, C2, C3, C4) VALUES (glbl_sendsms,
        ' v_status_code:'||v_status_code ||' claim_id:'||clmdetail(clmid).claim_id||
        ' sf_no:'||clmdetail(clmid).sf_no ||' add_order_no:'||clmdetail (clmid).add_order_no||
        ' p_contract_id:'||p_contract_id||' p_partition_no:'||p_partition_no ||' glbl_sendsms:'||glbl_sendsms
        , '2', Sysdate);          */
        Glbl_Sendsms := 1;
      END IF;

      IF Glbl_Sendsms = 1 THEN
        /*  INSERT INTO  mustafaku.Mk_Sms_Log_Table (C1, C2, C3, C4) VALUES (glbl_sendsms,
        ' v_status_code:'||v_status_code ||' claim_id:'||clmdetail(clmid).claim_id||
        ' sf_no:'||clmdetail(clmid).sf_no ||' add_order_no:'||clmdetail (clmid).add_order_no||
        ' p_contract_id:'||p_contract_id||' p_partition_no:'||p_partition_no ||' glbl_sendsms:'||glbl_sendsms
        , '3', Sysdate);           */

        --                BEGIN
        --                    SELECT COUNT(1)
        --                        INTO v_Auth_Cnt
        --                        FROM Koc_Clm_Web_Authorization a
        --                     WHERE a.Claim_Id = Clmdetail(Clmid).Claim_Id
        --                         AND Rownum < 2;
        --                EXCEPTION
        --                    WHEN OTHERS THEN
        --                        NULL;
        --                END;

        --                IF v_Auth_Cnt > 0
        --                THEN
        --                    v_Auth := 'OTORIZASYON';
        --                ELSE
        --                    v_Auth := 'OTOMASYON';
        --                END IF;

        IF Alz_Sms_Exceptions_Pkg.Check_Denied_Sms --MYALINKILIC: 213397 NO LU TASK ICIN GELISTIRME YAPILDI
           (p_Claim_Id       => Clmdetail(Clmid).Claim_Id,
            p_Product_Id     => Policyinfo.Product_Id,
            p_Group_Code     => Clmdetail(Clmid).Group_Code,
            p_Package_Id     => Clmdetail(Clmid).Package_Id,
            p_Contract_Id    => Pp_Contract_Id,
            p_Part_Id        => Policyinfo.Partner_Id,
            p_Claim_Type     => 'PROVİZYON',
            p_Institute_Type => Alz_Sms_Exceptions_Pkg.Get_Inst_Type(Clmdetail(Clmid)
                                                                     .Institute_Code),
            p_Prov_Type      => NULL,
            p_Prov_Status    => v_Status_Code,
            p_Sms_Type       => 'PROVİZYON') AND v_Force_Deny_Sms_Exp THEN
          Send_Provision_Sms(Clmdetail     (Clmid).Claim_Id,
                             Clmdetail     (Clmid).Sf_No,
                             Clmdetail     (Clmid).Add_Order_No,
                             p_Contract_Id,
                             p_Partition_No,
                             Clmdetail     (Clmid).Institute_Code);
        END IF;
      END IF;
    END IF;

    --
    ----42.madde -------------------------------------------------------------------------
    -- orhan topal
    BEGIN
      SELECT Identity_No
        INTO l_Tckn
        FROM Koc_Cp_Partners_Ext
       WHERE Rownum = 1
         AND Part_Id = Clmdetail(Clmid).Part_Id;

      Customer.Alz_Affluent_Customer.Get_Policy_Customer(Policyinfo.Policy_Ref,
                                                         l_Tckn,
                                                         p_Result);

      ----
      DECLARE
        Hltprv_Log Hltprv_Log_Typ := Hltprv_Log_Typ();
      BEGIN
        Hltprv_Log.Servicename   := 'PROVIZYON';
        Hltprv_Log.Processinfo   := 'GETPROVIZYON';
        Hltprv_Log.Insuredno     := Policyinfo.Policy_Ref;
        Hltprv_Log.Insurednotype := 'AFFLUENT_MAIL_SEND';
        Hltprv_Log.Note          := 'Clmdetail(Clmid).Status_Code: ' || Clmdetail(Clmid)
                                   .Status_Code || ' v_Status_Code: ' ||
                                    v_Status_Code;
        Hltprv_Log.Content       := Dbms_Utility.Format_Error_Backtrace ||
                                    Chr(10) || ' < ERR:' || SQLERRM || ' >';

        Hltprv_Log.Savelogwithpragma('YES');
      END;

      -----

      -- affluent ve yatis talebi olmasi kontrol edildi
      -- web_location_code bos geldiginden muhtemel yatis tarihinden gidildi.
      IF (p_Result > 0 AND
         (Clmdetail(Clmid).Hospitalize_Date IS NOT NULL OR Clmdetail(Clmid)
         .Poss_Hospitalize_Date IS NOT NULL)) THEN
        IF (Nvl(Clmdetail(Clmid).Status_Code, 'PP') = 'PP' AND Clmdetail(Clmid)
           .Request_System <> 'OPUS') THEN
          SELECT COUNT(*)
            INTO Mail_Count
            FROM Customer.Alz_Affluent_Mail_Log
           WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
             AND Mail_Type = 'AFFLUENT_YATIS_TALEBI';

          IF (Mail_Count < 1) THEN
            Customer.Alz_Affluent_Customer.Send_Mail_Hospitalization_Appl(Clmdetail(Clmid)
                                                                          .Claim_Id);
          END IF;
        END IF;

        IF (Nvl(Clmdetail(Clmid).Status_Code, 'PP') IN ('PP', 'PR') AND
           v_Status_Code IN ('P', 'R')) THEN
          SELECT COUNT(*)
            INTO Mail_Count
            FROM Customer.Alz_Affluent_Mail_Log
           WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
             AND Mail_Type = 'AFFLUENT_YATIS_POZISYONU';

          IF (Mail_Count < 1) THEN
            Customer.Alz_Affluent_Customer.Send_Mail_Hospitalization(Clmdetail(Clmid)
                                                                     .Claim_Id);
          END IF;
        END IF;

        IF (Nvl(Clmdetail(Clmid).Status_Code, 'PP') = 'P' AND
           v_Status_Code = 'CP') THEN
          SELECT COUNT(*)
            INTO Mail_Count
            FROM Customer.Alz_Affluent_Mail_Log
           WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
             AND Mail_Type = 'AFFLUENT_TABURCULUK_TALEBI';

          IF (Mail_Count < 1) THEN
            Customer.Alz_Affluent_Customer.Send_Mail_Discharge_Appl(Clmdetail(Clmid)
                                                                    .Claim_Id);
          END IF;
        END IF;

        IF (Clmdetail(Clmid)
           .Status_Code IN ('CP', 'CPR') AND v_Status_Code IN ('P', 'R')) THEN
          SELECT COUNT(*)
            INTO Mail_Count
            FROM Customer.Alz_Affluent_Mail_Log
           WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
             AND Mail_Type = 'AFFLUENT_TABURCULUK_PROVIZYONU';

          IF (Mail_Count < 1) THEN
            Customer.Alz_Affluent_Customer.Send_Mail_Discharge(Clmdetail(Clmid)
                                                               .Claim_Id);
          END IF;
        END IF;

        ----
        DECLARE
          Hltprv_Log Hltprv_Log_Typ := Hltprv_Log_Typ();
        BEGIN
          Hltprv_Log.Servicename   := 'PROVIZYON';
          Hltprv_Log.Processinfo   := 'GETPROVIZYON';
          Hltprv_Log.Insuredno     := Policyinfo.Policy_Ref;
          Hltprv_Log.Insurednotype := 'AFFLUENT_MAIL_SEND';
          Hltprv_Log.Note          := 'Claim_Id:' || Clmdetail(Clmid)
                                     .Claim_Id || ' - Affluent mi :' ||
                                      p_Result;
          Hltprv_Log.Content       := Dbms_Utility.Format_Error_Backtrace ||
                                      Chr(10) || ' < ERR:' || SQLERRM || ' >';

          Hltprv_Log.Savelogwithpragma('YES');
        END;
        -----

      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        ----
        DECLARE
          Hltprv_Log Hltprv_Log_Typ := Hltprv_Log_Typ();
        BEGIN
          Hltprv_Log.Servicename   := 'PROVIZYON';
          Hltprv_Log.Processinfo   := 'GETPROVIZYON';
          Hltprv_Log.Insuredno     := Policyinfo.Policy_Ref;
          Hltprv_Log.Insurednotype := 'AFFLUENT_MAIL_SEND';
          Hltprv_Log.Note          := 'Claim_Id:' || Clmdetail(Clmid)
                                     .Claim_Id || ' - Affluent mi :' ||
                                      p_Result;
          Hltprv_Log.Content       := Dbms_Utility.Format_Error_Backtrace ||
                                      Chr(10) || ' < ERR:' || SQLERRM || ' >';

          Hltprv_Log.Savelogwithpragma('YES');
        END;
        -----
    END;
    -- orhan topal

  END;