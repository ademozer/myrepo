CREATE OR REPLACE PACKAGE OPUS_CORE.CME_UTILS AS
--------------------------------------------------------------------------------
--  Package : CME_UTILS
--  Source:   CME_UTILS.OPS
--  Purpose:  Logical grouping of CME General purpose functions used by the CME
--------------------------------------------------------------------------------

pvcs_spec_revision CONSTANT CHAR(40) := UPPER('$Revision:   3.11  $');

FUNCTION pvcs_body_revision RETURN VARCHAR2;

--------------------------------------------------------------------------------
PROCEDURE create_claim_base(p_claim_line_id   IN  NUMBER,
                            p_manual_claim    IN  NUMBER,
                            p_loss_date      IN  DATE,
                            p_contract_id   IN  NUMBER,
                            p_error         OUT NUMBER);
--------------------------------------------------------------------------------
-- Procedure: CREATE_CLAIM_BASE
--
-- Purpose: Create (an almost empty) claim base
--
-- Parameters: p_claim_line_id  IN    : claim line against which claim is being
--                                      made
--             p_manual_claim   IN    : manual claim flag (0 = Auto claim or
--                                      1 = Manual Claim)
--             p_loss_date      IN    : Date of loss (may be null)
--             p_contract_id    IN    : policy for which claim is being made
--                                      (may be null)
--             p_error          OUT   : Return code 0 = SUCCESS, 1 = FAILURE
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
PROCEDURE find_route(p_movement_id IN NUMBER,
                     p_route_type IN VARCHAR2,
                     p_comp_name OUT VARCHAR2,
                     p_error OUT NUMBER) ;
--------------------------------------------------------------------------------
-- Procedure: FIND_ROUTE
--
-- Purpose: Query CME route and return Component name for specified movement and
--          route type
--
-- Parameters: p_movement_id IN  : movement id for which client route is
--                                 required
--             p_route_type  IN  : route type for which component is required
--             p_comp_name   OUT : name of client route component
--             p_error       OUT : return code 0 = SUCCESS, 1 = FAILURE
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
PROCEDURE invoke_route(p_claim_id IN NUMBER,
                       p_movement IN NUMBER,
                       p_route_type IN VARCHAR2,
                       p_error OUT NUMBER) ;
--------------------------------------------------------------------------------
-- Procedure: INVOKE_ROUTE (Overloaded)
--
-- Purpose: Determine the component name from the movement and route type
--          supplied, then invoke the component
--
-- Session Variables Used: SCHEMA_NAME (if NOT NULL)
--
-- Parameters: p_claim_id    IN  : Claim for which to invoke route
--             p_movement_id IN  : movement id of route to invoke
--             p_route_type  IN  : type of route
--             p_error       OUT : Return code 0 = SUCCESS, 1 = FAILURE
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
PROCEDURE invoke_route( p_claim_id     IN NUMBER,
                        p_sf_no        IN NUMBER,
                        p_movement     IN NUMBER,
                        p_route_type   IN VARCHAR2,
                        p_error        OUT NUMBER);
--------------------------------------------------------------------------------
-- Procedure: INVOKE_ROUTE (Overloaded)
--
-- Purpose: Determine the component name from the movement and route type
--          supplied, then invoke the component
--
-- Session Variables Used: SCHEMA_NAME (if NOT NULL)
--
-- Parameters: p_claim_id     IN  : Claim for which to invoke route
--             p_sf_no        IN  : Sub file for which to invoke route
--             p_movement_id  IN  : movement id of route to invoke
--             p_route_type   IN  : type of route
--             p_error        OUT : Return code 0 = SUCCESS, 1 = FAILURE
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
    PROCEDURE invoke_route( p_claim_id   IN NUMBER,
                            p_sf_no      IN NUMBER,
                            p_trans_no   IN NUMBER,
                            p_movement   IN NUMBER,
                            p_route_type IN VARCHAR2,
                            p_error      OUT NUMBER) ;
--------------------------------------------------------------------------------
-- Procedure: INVOKE_ROUTE (Overloaded)
--
-- Purpose: Determine the component name from the movement and route type
--          supplied, then invoke the component
--
-- Session Variables Used: SCHEMA_NAME (if NOT NULL)
--
-- Parameters: p_claim_id    IN  : Claim for which to invoke route
--             p_sf_no       IN  : Sub file for which to invoke route
--             p_trans_no    IN  : transaction for which to invoke route
--             p_movement    IN  : movement id of route to invoke
--             p_route_type  IN  : type of route
--             p_error       OUT : Return code 0 = SUCCESS, 1 = FAILURE
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
PROCEDURE clear_movement_errors(p_claim_id  IN NUMBER,
                                p_user_name IN VARCHAR2,
                                p_error     OUT NUMBER);
--------------------------------------------------------------------------------
-- Procedure: CLEAR_MOVEMENT_ERRORS
--
-- Purpose:    Delete all errors/warnings for a specified claim
--
-- Parameters: p_claim_id  IN  : Claim for which to delete errors
--             p_user_name IN  : User errors for a particular claim
--             p_error     OUT : Return code 0 = SUCCESS, 1 = FAILURE
--------------------------------------------------------------------------------
PROCEDURE clear_movement_errors (p_claim_id   IN  clm_bases.claim_id%TYPE ,
                                 p_session_id IN  NUMBER,
                                 p_username   IN  VARCHAR,
                                 p_result     OUT NUMBER);
--------------------------------------------------------------------------------
-- Procedure: CLEAR_MOVEMENT_ERRORS (overloaded)
--
-- Purpose:    Delete all errors/warnings for a specified claim
--
-- Parameters: p_claim_id   IN  : Claim for which to delete errors
--             p_session_id IN  : Session errors for session or session and claim
--             p_user_name  IN  : User errors for a particular claim
--             p_result     OUT : Return code 0 = SUCCESS, 1 = FAILURE
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
FUNCTION authorised_for_movement(p_username      IN VARCHAR2,
                                 p_movement_id   IN NUMBER,
                                 p_claim_line_id IN NUMBER,
                                 p_clm_level     IN VARCHAR2) RETURN NUMBER;
--------------------------------------------------------------------------------
-- Function: AUTHORISED_FOR_MOVEMENT
--
-- Purpose:    Determine if user has authority to run specified movement
--
-- Parameters: p_movement_id IN : movement to check
--             p_clm_line_id IN : claim line to check
--             p_clm_level   IN : claim level to check
--
-- Returns: 0 : Authorised
--          1 : Not authorised
--          2 : Error in Getting Security Value
--          3 : Movement to run not found
--          4 : Unexpected Error occurred
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
FUNCTION authorised_for_movement_upd(p_username      IN VARCHAR2,
                                     p_movement_id   IN NUMBER,
                                     p_claim_line_id IN NUMBER,
                                     p_clm_level     IN VARCHAR2,
                                     p_claim_id      IN NUMBER   DEFAULT claim_session_vars.session_claim_id,
                                     p_sf_no         IN NUMBER   DEFAULT claim_session_vars.session_claim_sf_no) RETURN NUMBER;
RETURN NUMBER;
--------------------------------------------------------------------------------
-- Function: AUTHORISED_FOR_MOVEMENT_UPD
--
-- Purpose: Determine if user has authority to run specified movement for update
--
-- Parameters: p_movement_id IN : movement to check
--             p_clm_line_id IN : claim line to check
--             p_clm_level   IN : claim level to check
--
-- Returns: 0 : Authorised
--          1 : Not authorised
--          2 : Error in Getting Authority Level
--          3 : Movement to run not found
--          4 : Unexpected Error occurred
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
FUNCTION movement_valid(p_movement_id IN NUMBER,
                        p_clm_line_id IN NUMBER,
                        p_clm_level   IN VARCHAR2) RETURN NUMBER;
--------------------------------------------------------------------------------
-- Function: MOVEMENT_VALID
--
-- Purpose: Determine if a movement exists and is not suspended (at claim line,
--          level and movement level
--
-- Parameters: p_movement_id    IN       : movement to check
--             p_clm_line_id    IN       : claim line to check
--             p_clm_level      IN       : claim level to check
--
-- Returns: 0 : Movement not suspended
--          1 : error or movement suspended
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
PROCEDURE report_tp_status(p_processor_type IN VARCHAR2,
                           p_master_or_slave IN CHAR,
                           p_activity IN VARCHAR2);
--------------------------------------------------------------------------------
-- Procedure: REPORT_TP_STATUS (Currently does Nothing)
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
PROCEDURE cme_error(p_claim_id   IN NUMBER,
                    p_error_code IN NUMBER,
                    p_error_text IN VARCHAR2,
                    p_func_name  IN VARCHAR2,
                    p_error_type IN VARCHAR2 DEFAULT 'O');
--------------------------------------------------------------------------------
-- Procedure: CME_ERROR (Overloaded)
--
-- Purpose: Generic error logging routine for the CME.  This routine is used
--          for Oracle errors raised through the internals of CME
--
-- Session Variables Used: SESSION_CONTEXT
--
-- Parameters: p_claim_id      IN : claim id errored on
--             p_error_code    IN : SQLCODE or Application error
--             p_error_text    IN : SQLERRM or description of app error
--             p_function_name IN : Name of module and procedure/function in
--                                  which error occurred
--             p_error_type    IN : 'O'racle or 'A'pplication Error, Default 'O'
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
PROCEDURE cme_error(p_claim_id      IN NUMBER,
                    p_claim_sf_no   IN NUMBER,
                    p_error_code    IN NUMBER,
                    p_error_text    IN VARCHAR2,
                    p_func_name     IN VARCHAR2,
                    p_error_type    IN VARCHAR2 DEFAULT 'O');
--------------------------------------------------------------------------------
-- Procedure: CME_ERROR (Overloaded)
--
-- Purpose: Generic error logging routine for the CME.  This routine is used for
--          Oracle errors raised through the internals of CME
--
-- Session Variables Used: SESSION_CONTEXT
--
-- Parameters: p_claim_id      IN : claim on which error occurred
--             p_claim_sf_no   IN : sub file on which error occurred
--             p_error_code    IN : SQLCODE or Application error
--             p_error_text    IN : SQLERRM or description of app error
--             p_function_name IN : Name of module and procedure/function in
--                                  which error occurred
--             p_error_type    IN : 'O'racle or 'A'pplication Error, Default 'O'
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
PROCEDURE cme_error(p_claim_id      IN NUMBER,
                    p_claim_sf_no   IN NUMBER,
                    p_trans_no      IN NUMBER,
                    p_error_code    IN NUMBER,
                    p_error_text    IN VARCHAR2,
                    p_func_name     IN VARCHAR2,
                    p_error_type    IN VARCHAR2 DEFAULT 'O');
--------------------------------------------------------------------------------
-- Procedure: CME_ERROR (Overloaded)
--
-- Purpose: Generic error logging routine for the CME.  This routine is used
--          for Oracle errors raised through the internals of CME
--
-- Session Variables Used: SESSION_CONTEXT
--
-- Parameters: p_claim_id      IN : claim on which error occurred
--             p_claim_sf_no   IN : sub file on which error occurred
--             p_trans_no      IN : transaction on which error occurred
--             p_error_code    IN : SQLCODE
--             p_error_text    IN : SQLERRM
--             p_function_name IN : Name of module and procedure/function in
--                                  which error occurred
--             p_error_type    IN : 'O'racle or 'A'pplication Error, Default 'O'
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
FUNCTION policy_found(p_contract_id IN NUMBER) RETURN NUMBER;
--------------------------------------------------------------------------------
-- Function:  POLICY_FOUND
--
-- Purpose:    Check the existence of a policy in the policy database
--
-- Parameters: p_contract_id  IN  : policy to check
--
-- Returns: 0 : Policy found
--          1 : error or policy not found
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
FUNCTION valid_policy(p_contract_id IN NUMBER,
                      p_loss_date   IN DATE  ) RETURN NUMBER ;
--------------------------------------------------------------------------------
-- Function: VALID_POLICY
--
-- Purpose: Check the specified policy exists in the policy database and
--          was in force on the specified date.
--
-- Parameters: p_contract_id IN : policy to check
--
-- Returns: 0 : Policy valid
--          1 : error or policy not found/not in force
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
FUNCTION check_limit(p_limit_code IN VARCHAR2,
                     p_amount IN NUMBER,
                     p_swift_code IN VARCHAR2) RETURN BOOLEAN;
--------------------------------------------------------------------------------
-- Function: CHECK_LIMIT
--
-- Purpose: The user has enough authority for a given limit.
--
-- Session Variables Used: SESSION_CLAIM_LINE_ID
--                         SESSION_CLAIM_ID
--                         SESSION_SF_NO
--
-- Parameters: p_limit_code IN : the limit code to check
--             p_amount IN     : the amount to be checked
--             p_swift_code IN : the SWIFT code of the above amount
--
-- Returns: TRUE - Has the authoirty for the given limit code
--          FALSE - Not authorised for the above limit
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
FUNCTION check_limit(p_limit_code IN VARCHAR2) RETURN BOOLEAN;
--------------------------------------------------------------------------------
-- Function: CHECK_LIMIT (Currently always return TRUE)
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
FUNCTION invoke_change_status(p_to_status IN VARCHAR2,
                              p_claim_id IN NUMBER,
                              p_sf_no IN NUMBER DEFAULT NULL,
                              p_trans_no IN NUMBER DEFAULT NULL) RETURN BOOLEAN;
--------------------------------------------------------------------------------
-- Function: INVOKE_CHANGE_STATUS -- Obsolete should use INVOKE_MOVEMENT_STATUS
--
-- Purpose: Change the status for a Claim, Subfile and Transaction. Depending if
--          there are values in p_claim_id, p_sf_no, p_trans_no will determine
--          what level the status will be changed. If p_sf_no is not null then
--          p_claim_no cannot be null, etc.
--
-- Parameters: p_to_status IN : the status the Base, Subfile or Transaction is
--                              trying to change to
--             p_claim_id IN : the claim for the status to change
--             p_sf_no  IN   : (Optional, default NULL) the subfile for the
--                             status to change
--             p_trans_no IN : (Optional, default NULL) the transaction for the
--                              status to change
---- Returns: TRUE - Status has been change successfully
--            FALSE - Status has not been change successfully
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
FUNCTION invoke_status_movement(p_to_status IN VARCHAR2,
                                p_claim_id IN NUMBER,
                                p_sf_no IN NUMBER DEFAULT NULL,
                                p_trans_no IN NUMBER DEFAULT NULL) RETURN NUMBER;
--------------------------------------------------------------------------------
-- Function: INVOKE_STATUS_MOVEMENT
--
-- Replaces INVOKE_CHANGE_STATUS, now returns an error NUMBER
--
-- Purpose: Change the status for a Claim, Subfile and Transaction. Depending if
--          there are values in p_claim_id, p_sf_no, p_trans_no will determine
--          what level the status will be changed. If p_sf_no is not null then
--          p_claim_no cannot be null, etc.
--
-- Does a update Lock specified in the Configurator
--
-- Runs all server routes, fails if it finds a CLIent route
--
-- Changes the CLM_STATUS in CLM_BASES, CLM_SUBFILES or CLM_TRANS and and adds a
-- row into clm_status_history if successful.
--
-- Unlocks the Update lock
--
-- Parameters: p_to_status IN : the status the Base, Subfile or Transaction is
--                              trying to change to
--             p_claim_id  IN : the claim for the status to change
--             p_sf_no     IN : (Optional, default NULL) the subfile for the
--                              status to change
--             p_trans_no  IN : (Optional, default NULL) the transaction for the
--                              status to change
--
-- Returns: 0  : Successful
--          1  : No Claim or Status specified
--          2  : Claim, Subfile or Trans Not Found
--          3  : Current Status of Object is Not Set
--          4  : Change Status Flow Doesnt Exist in Configurator
--          5  : No Movement specified for the Change
--          6  : Not Authorised to Run Change
--          7  : Client Route Found
--          8  : Error in Invoking Route
--          -1 : -- Unforseen Oracle Error
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
PROCEDURE get_all_flags ( p_clm_line_id IN NUMBER,
                          p_clm_level   IN VARCHAR2,
                          p_clm_status  IN VARCHAR2,
                          p_start       OUT VARCHAR2,
                          p_open        OUT VARCHAR2,
                          p_held        OUT VARCHAR2,
                          p_no_process  OUT VARCHAR2);
--------------------------------------------------------------------------------
-- Procedure : GET_ALL_FLAGS
--
-- Purpose : To return all the CME flag statuses for a given Status at a Claim
--           level and within a Claim Line
--
-- Parameters : p_clm_line_id IN  Claim Line to Check
--              p_clm_level   IN  Claim Level to Check ('BASE', 'SUBFILE' or
--                                'TRANS'
--              p_clm_status  IN  Claim Status to Check
--              p_start       OUT Returns 'Y' or 'N'
--              p_open        OUT Returns 'Y' or 'N'
--              p_held        OUT Returns 'Y' or 'N'
--              p_no_process  OUT Returns 'Y' or 'N'
--
-- If no Claim Line, Level and Status exists all flags are set to 'N'
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
FUNCTION start_status (p_clm_line_id IN NUMBER,
                       p_clm_level   IN VARCHAR2,
                       p_clm_status  IN VARCHAR2) RETURN BOOLEAN;
--------------------------------------------------------------------------------
-- Function: START_STATUS
--
-- Purpose : To return CME Start status flag for a given Status at a Claim
--           level and within a Claim Line
--
-- Parameters : p_clm_line_id IN  Claim Line to Check
--              p_clm_level   IN  Claim Level to Check ('BASE', 'SUBFILE' or
--                                'TRANS'
--              p_clm_status  IN  Claim Status to Check
--
-- Returns : TRUE :  if the status is the start status
--           FALSE : if the status is NOT the start status or the Claim Line,
--                   Level and Status does not exist
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
FUNCTION open_status (p_clm_line_id IN NUMBER,
                      p_clm_level   IN VARCHAR2,
                      p_clm_status  IN VARCHAR2) RETURN BOOLEAN;
--------------------------------------------------------------------------------
-- Function: OPEN_STATUS
--
-- Purpose : To return CME Open status flag for a given Status at a Claim
--           level and within a Claim Line
--
-- Parameters : p_clm_line_id IN  Claim Line to Check
--              p_clm_level   IN  Claim Level to Check ('BASE', 'SUBFILE' or
--                                'TRANS'
--              p_clm_status  IN  Claim Status to Check
--
-- Returns : TRUE :  if the status is an open status
--           FALSE : if the status is NOT an open status or the Claim Line,
--                   Level and Status does not exist
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
FUNCTION held_status (p_clm_line_id IN NUMBER,
                      p_clm_level   IN VARCHAR2,
                      p_clm_status  IN VARCHAR2) RETURN BOOLEAN;
--------------------------------------------------------------------------------
-- Function: HELD_STATUS
--
-- Purpose : To return CME Held status flag for a given Status at a Claim
--           level and within a Claim Line
--
-- Parameters : p_clm_line_id IN  Claim Line to Check
--              p_clm_level   IN  Claim Level to Check ('BASE', 'SUBFILE' or
--                                'TRANS'
--              p_clm_status  IN  Claim Status to Check
--
-- Returns : TRUE :  if the status is the Held status
--           FALSE : if the status is NOT the Held status or the Claim Line,
--                   Level and Status does not exist
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
FUNCTION no_process_status (p_clm_line_id IN NUMBER,
                            p_clm_level   IN VARCHAR2,
                            p_clm_status  IN VARCHAR2) RETURN BOOLEAN;
--------------------------------------------------------------------------------
-- Function: NO_PROCESS_STATUS
--
-- Purpose : To return CME No Process status flag for a given Status at a Claim
--           level and within a Claim Line
--
-- Parameters : p_clm_line_id IN  Claim Line to Check
--              p_clm_level   IN  Claim Level to Check ('BASE', 'SUBFILE' or
--                                'TRANS'
--              p_clm_status  IN  Claim Status to Check
--
-- Returns : TRUE :  if the status is the No Process status
--           FALSE : if the status is NOT the No Process status or the Claim Line,
--                   Level and Status does not exist
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
FUNCTION trans_start_status (p_clm_line_id IN NUMBER,
                             p_move_id     IN NUMBER) RETURN VARCHAR2;
--------------------------------------------------------------------------------
-- Function: TRANS_START_STATUS
--
-- Purpose : To return the CME Start status for a transaction Movement within a
--           Claim Line
--
-- Parameters : p_clm_line_id IN  Claim Line to Check
--              p_move_id     IN  Movement id of a transaction
--
-- Returns : Start Status : if the Claim Line transaction Movement is found
--           NULL         : if the Claim Line Transaction Movement does not
--                          exist
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
FUNCTION get_movement_id (p_ext_ref IN VARCHAR2) RETURN NUMBER;
--------------------------------------------------------------------------------
-- Function: GET_MOVEMENT_ID
--
-- Purpose : To return the movement id for a Movement
--
-- Parameters : p_ext_ref IN The external reference of the Movement
--
-- Returns : id   : if the Movement is found
--           NULL : if Movement does not exist
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
FUNCTION get_clm_status_name (p_clm_status IN VARCHAR2) RETURN VARCHAR2;
--------------------------------------------------------------------------------
-- Function: GET_CLM_STATUS_NAME
--
-- Purpose : To return the translation of a Status for the current user language
--
-- Parameters : p_clm_status IN The status to be checked
--
-- Returns : Status Name  : if the Status is found the translation for the
--                          Status
--           p_clm_status : if the Status does not exist the in parameter is
--                          Capitalised.
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
FUNCTION check_user_assignment(p_username IN VARCHAR2,
                               p_level IN VARCHAR2,
                               p_movement_id IN NUMBER) RETURN NUMBER;
--------------------------------------------------------------------------------
-- Function: CHECK_USER_ASSIGNMENT (Function now calls check_user_assignments)
--            ************************************************
--            * OBSOLETE * Should use check_user_assignments *
--            ************************************************
-- Purpose : Determine if there is an assignment against the claim base/subfile
--
-- Session Variables Used: SESSION_CLAIM_LINE_ID
--                         SESSION_CLAIM_ID
--                         SESSION_SF_NO
--
-- Parameter: p_username    IN VARCHAR2
--            p_level       IN VARCHAR2
--            p_movement_id IN NUMBER (Not Used)
-- Returns:   0 : Authorised
--            1 : Not authorised
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
FUNCTION check_user_authority(p_username    IN VARCHAR2 DEFAULT USER,
                              p_clm_line_id IN NUMBER   DEFAULT claim_session_vars.session_claim_line_id,
                              p_claim_id    IN NUMBER   DEFAULT claim_session_vars.session_claim_id,
                                p_sf_no       IN NUMBER   DEFAULT claim_session_vars.session_claim_sf_no)
   RETURN NUMBER;
--------------------------------------------------------------------------------
-- Function :  check_user_authority
-- Purpose  :  This function is to be used to determine what level of authority a user has
--             on a particular Claim Line, Claim or Subfile within a Claim.
--
-- The following session variables are used only if the some or no parameters
-- are passed in.
--
-- Session Variables Used: SESSION_CLAIM_ID
--                         SESSION_CLAIM_SF_NO
--
-- All parameters are optional taking the default from the session variables
-- if not passed in
--
-- Parameters: p_username (User you are checking)
--             p_clm_line_id (Claim Line to be checked, if NULL deduced from
--                            the claim)
--             p_claim_id (The Claim to be checked, if NULL only the Claim Line
--                         Level is checked)
--             p_sf_no (The Subfile to be checked of the above Claim, if Null
--                      the Claim is checked)
--
-- Returns: -1 : Not authorised
--          n  : The level of authority at the level requested (Claim Line,
--               Claim or Subfile)
--------------------------------------------------------------------------------

PROCEDURE log_message(p_clm_level     IN VARCHAR2,
                      p_claim_id      IN NUMBER,
                      p_err_text      IN VARCHAR2,
                      p_sf_no         IN NUMBER   DEFAULT NULL,
                      p_trans_no      IN NUMBER   DEFAULT NULL,
                      p_function_name IN VARCHAR2 DEFAULT NULL,
                      p_err_no        IN NUMBER   DEFAULT 0,
                      p_err_type      IN CHAR     DEFAULT 'L');
--------------------------------------------------------------------------------
-- Procedure :  log_message
-- Purpose : This procedure is to put errors/messages into the CLM_ERRORS table.
--           This is useful for debugging server code when running server
--           movements.
--           Used in CME_UTILS.INVOKE_STATUS_MOVEMENT to put a message in
--           CLM_ERRORS if changing the status failed.
--
-- No session variables are used
--
-- Parameters: p_clm_level     : Either 'BASE', 'SUBFILE', 'TRANS' or NULL. If
--                               NULL is passed in the level is dependent on the
--                               other parameters.
--             p_claim_id      : The claim message relates to
--             p_err_text      : Error text
-- Optional    p_function_name : The procedure/function the message occured in
-- Optional    p_sf_no         : The Subfile message relates to
-- Optional    p_trans_no      : The Transaction relates to
-- Optional    p_err_no        : Error number if known, defaults to 0
-- Optional    p_err_type      : Either 'A'pplication, 'O'racle or 'L'og Message
--------------------------------------------------------------------------------

END cme_utils;
/
CREATE OR REPLACE PACKAGE BODY OPUS_CORE.CME_UTILS wrapped
0
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
3
b
8106000
1
4
0
1d6
2 :e:
1PACKAGE:
1BODY:
1CME_UTILS:
1NO_ROUTE_FOUND:
1CONSTANT:
1PLS_INTEGER:
1-:
11:
1SUCCESS:
10:
1FAILURE:
1WARNING:
12:
1FUNCTION:
1PVCS_BODY_REVISION:
1RETURN:
1VARCHAR2:
1$Revision::   3.21  $. CERTIS copyright 1998:
1GET_ORG_UNIT_STRUCTURE:
1V_RETURN:
120:
1INF_UTILS:
1PARAMETER_VALUE:
1CLAIM_ORG_STRUCTURE:
1NO_DATA_FOUND:
1LOG_MESSAGE:
1P_CLM_LEVEL:
1P_CLAIM_ID:
1NUMBER:
1P_ERR_TEXT:
1P_SF_NO:
1P_TRANS_NO:
1P_FUNCTION_NAME:
1P_ERR_NO:
1P_ERR_TYPE:
1CHAR:
1L:
1V_CLM_LEVEL:
110:
1IS NULL:
1IS NOT NULL:
1TRANS:
1ELSIF:
1SUBFILE:
1BASE:
1=:
1CME_ERROR:
1OTHERS:
1GET_AUTH_LEVEL:
1P_USERNAME:
1P_SUB_FUNCTION:
1P_LIMIT_CODE:
1P_AUTH_LEVEL:
1OUT:
1BOOLEAN:
1V_BFUNC:
16:
1Claims:
1V_COUNT:
1V_FOUND:
1V_ORG_UNIT:
1V_REF_GROUP_ID:
1V_SF_GROUP_NO:
1V_VALUE:
1V_TODAY:
1DATE:
1SYSDATE:
1V_END_DATE:
1ADD_MONTHS:
1CURSOR:
1C_CA:
1COUNT:
1ROWID:
1CLM_ASSIGNMENTS:
1CA:
1CLAIM_ID:
1SUPP_ID:
1START_DATE:
1<=:
1NVL:
1<:
1END_DATE:
1C_CS:
1CS:
1SF_GROUP_NO:
1CLM_SUBFILES:
1SF_NO:
1C_CAS:
1C_CAS_USER:
1ASS_ID:
1OVERRIDE_LIMIT:
1ASSIGNEE_USERNAME:
1C_CAS_ALL:
1ORG_AUTHORISED:
1Y:
1C_CAS_ORG:
1LUA_V_USER_NODES_INFO_API:
1LV:
1ORG_UNIT:
1NODE_CODE:
1ORACLE_USERNAME:
1STRUCTURE_TYPE:
1C_CAG:
1C_CAG_USER:
1C_CAG_ALL:
1C_CAG_ORG:
1C_CAB:
1C_CAB_USER:
1C_CAB_ALL:
1C_CAB_ORG:
1CV_CA:
1ROWTYPE:
1CHECK_OVERRIDE_LIMIT:
1P_ASS_ID:
1P_ORG_OVERRIDE:
1C_CAP:
1MAX:
1SECURITY_VALUE:
1CLM_ASS_PROFILES:
1CAP:
1SEC_V_DETAIL_ITEMS:
1SV:
1ORG_OVERRIDE:
1DETAIL_ITEM_ID:
1DETAIL_ITEM_NAME:
1SUB_FUNCTION:
1OPEN:
1FOUND:
1>:
1CLOSE:
1OPU_SEC:
1GET_SECURITY_VALUE:
1NOT:
1FALSE:
1TRUE:
1!=:
1CV_CAS_ALL:
1LOOP:
1CV_CAS_ORG:
1CV_CAG_ALL:
1CV_CAG_ORG:
1CV_CAB_ALL:
1CV_CAB_ORG:
1CREATE_CLAIM_BASE:
1P_CLAIM_LINE_ID:
1P_MANUAL_CLAIM:
1P_LOSS_DATE:
1P_CONTRACT_ID:
1P_ERROR:
1FUNCTION_NAME:
150:
1CME_UTILS.CREATE_CLAIM_BASE:
1CLM_START_STATUS:
1CLM_OCCUR_SEQ:
1NEW_CLAIM_ID:
1STATUS_FOUND:
1STATUS_ERROR:
1SEQUENCE_ERROR:
1C_CLM_START_STATUS:
1CLM_STATUS:
1CC_CLM_LINE_STATUSES:
1CLM_LINE_ID:
1CLM_LEVEL:
1START_STATUS:
1C_CLAIM_ID:
1CLM_INT_REF_SEQ:
1NEXTVAL:
1SYS:
1DUAL:
1RAISE:
1CLM_BASES:
1MANUAL_CLAIM:
1OCCURENCE_SEQ:
1DATE_OF_LOSS:
1CLM_STATUS_HISTORY:
1STATUS_ID:
1CSH_DATE:
1CSH_USERNAME:
1EXT_USER:
1CLM_STATUS_ID_SEQ:
1USER:
1INF_SEC_EXT_APP_USER_API:
1EXT_APP_USER:
1COMMIT:
151032:
1OPU_MSG:
1MSG:
1A:
151033:
1SQLCODE:
1SQLERRM:
1FIND_ROUTE:
1P_MOVEMENT_ID:
1P_ROUTE_TYPE:
1P_COMP_NAME:
130:
1CME_UTILS.FIND_ROUTE:
1C_GET_ROUTE:
1CCR:
1COMP_NAME:
1CC_CME_ROUTES:
1MOVEMENT_ID:
1PRT_CODE:
1INVOKE_ROUTE:
1P_MOVEMENT:
1CME_UTILS.INVOKE_ROUTE:
1RET_CODE:
1THE_CURSOR:
1COMPONENT_NAME:
161:
1SCHEMA_PREFIX:
131:
1FUNCTION_CALL_FAILED:
1FUNCTION_INCOMPLETED:
1CLAIM_SESSION_VARS:
1SCHEMA_NAME:
1||:
1.:
1DBMS_SQL:
1OPEN_CURSOR:
1PARSE:
1BEGIN ::func_status ::= :
1(::claim_id);:
1END;:
1V7:
1BIND_VARIABLE:
1::claim_id:
1::func_status:
1EXECUTE:
1VARIABLE_VALUE:
1CLOSE_CURSOR:
151034:
1(::claim_id,::sf_no);:
1::sf_no:
151035:
1(::claim_id,::sf_no,::trans_no);:
1::trans_no:
151031:
1CLEAR_MOVEMENT_ERRORS:
1P_USER_NAME:
1PRAGMA:
1AUTONOMOUS_TRANSACTION:
1CLM_ERRORS:
1CE:
1USER_NAME:
1TYPE:
1P_SESSION_ID:
1VARCHAR:
1P_RESULT:
1NULL_PARAMETERS:
1INVALID_COMBINATION:
1SESSION_ID:
1AUTHORISED_FOR_MOVEMENT:
1C_AUTH_LEVEL:
1VIEW_AUTH_LEVEL:
1CC_CLM_LINE_MOVEMENTS:
1CLNMV:
1C_EXT_REF:
1EXT_REFERENCE:
1CC_CLM_LINES:
1BUSINESS_FUNCTION:
1V_AUTHORISED:
1V_UNAUTHORISED:
1V_SECURITY_ERROR:
1V_NO_MOVEMENT:
13:
1V_OTHER_ERROR:
14:
133:
1CME_UTILS.AUTHORISED_FOR_MOVEMENT:
1REF_GP:
1MOVE_AUTH:
1USER_AUTH:
1ERR_CD:
1MVMT_FOUND:
1EXT_REF_FOUND:
1V_EXT_REFERENCE:
1NO_USER_AUTH:
1NO_MOVEMENT:
1NO_EXT_REFERENCE:
1NOT_REQUIRED:
1>=:
151030:
1TO_CHAR:
151036:
1AUTHORISED_FOR_MOVEMENT_UPD:
1SESSION_CLAIM_ID:
1SESSION_CLAIM_SF_NO:
1C_AUTH_LEVEL_UPD:
1UPDATE_AUTH_LEVEL:
1CME_UTILS.AUTHORISED_FOR_MOVEMENT_UPD:
1CHECK_USER_AUTHORITY:
1REPORT_TP_STATUS:
1P_PROCESSOR_TYPE:
1P_MASTER_OR_SLAVE
/