DECLARE
p_Contract_Id          NUMBER :=  355577538;
p_Insured_Old_Contract NUMBER := NULL;
p_Date                 DATE := SYSDATE-40;
p_Status_Code          VARCHAR2(100);
p_Status_Exp           VARCHAR2(32000);

PROCEDURE Clmpaymentstatus(p_Contract_Id          NUMBER,
                             p_Insured_Old_Contract NUMBER,
                             p_Date                 DATE,
                             p_Status_Code          OUT VARCHAR2,
                             p_Status_Exp           OUT VARCHAR2) IS
    CURSOR c_Ilave_Gunler(p_Yenileme NUMBER) IS
      SELECT SUM(Decode(Substr(Look_Up_Code, 7, 3), 'PES', Parameter, 0)) Pesin_Ilave,
             SUM(Decode(Substr(Look_Up_Code, 7, 3), 'TAK', Parameter, 0)) Taksit_Ilave
        FROM Koc_Cp_Health_Look_Up
       WHERE (p_Yenileme = 0 AND Look_Up_Code IN ('YENIISPES', 'YENIISTAK'))
          OR (p_Yenileme = 1 AND Look_Up_Code IN ('YENILEPES', 'YENILETAK'));

    CURSOR c_Payment_Plan IS
      SELECT a.Payment_Maturity Vade,
             MIN(a.Payment_Order_No) Taksit_No,
             SUM(Nvl(a.Premium_Amount, 0)) Prim_Borcu
        FROM Koc_Ocp_Payment_Plan a
       WHERE a.Contract_Id = p_Contract_Id
         AND a.Reversing_Version IS NULL
       GROUP BY a.Payment_Maturity;

    CURSOR c_Odeme(p_Vade DATE) IS
      SELECT SUM(a.Paid_Total)
        FROM Koc_Acc_Policy_Details a,
             Koc_Acc_Receipt_Master b,
             Ocp_Policy_Versions    e,
             Koc_Ocp_Payment_Plan   f
       WHERE a.Contract_Id = p_Contract_Id
         AND a.Contract_Id = f.Contract_Id
         AND a.Version_No = f.Version_No
         AND a.Payment_Order_No = f.Payment_Order_No
         AND f.Reversing_Version IS NULL
         AND f.Payment_Maturity = p_Vade
         AND a.Receipt_Id = b.Receipt_Id
         AND b.Receipt_Type != 'KOM'
         AND b.Cancelation_Date IS NULL
         AND a.Contract_Id = e.Contract_Id
         AND a.Version_No = e.Version_No
         AND e.Reversing_Version IS NULL
         AND (b.Receipt_Type != 'KK' OR EXISTS
              (SELECT 1
                 FROM Koc_Acc_Transaction_Info c
                WHERE c.Transaction_Type = 'CC'
                  AND a.Receipt_Id = c.Receipt_Id
                  AND a.Order_No = c.Order_No
                  AND c.Status IN ('YOLP', 'TAHS')
                  AND Rownum < 2));

    CURSOR c_Pesinat IS
      SELECT MIN(a.Payment_Order_No) Pesinat
        FROM Koc_Ocp_Payment_Plan a
       WHERE a.Contract_Id = p_Contract_Id;

    CURSOR c_Baslama IS
      SELECT DISTINCT Nvl(v.Business_Start_Date, p.Term_Start_Date)
        FROM Ocp_Policy_Versions v
        JOIN Ocp_Policy_Bases p
          ON p.Contract_Id = v.Contract_Id
         AND p.Top_Indicator = 'Y'
       WHERE v.Contract_Id = p_Contract_Id
         AND Rownum < 2;

    /* SELECT Nvl(v.Business_Start_Date, p.Term_Start_Date)
        FROM Ocp_Policy_Versions v,
                 Ocp_Policy_Bases    p
     WHERE v.Contract_Id = p.Contract_Id
         AND v.Version_No = p.Version_No
         AND p.Contract_Id = p_Contract_Id
    AND p.Version_No = (
        SELECT MAX(t.Version_No)
            FROM Ocp_Policy_Bases t
         WHERE t.Contract_Id = p.Contract_Id
             AND t.Action_Code <> 'D'
             AND t.Top_Indicator = 'Y');*/

    v_Ilaveli_Date        DATE;
    v_Pesin_Ilave         NUMBER;
    v_Taksit_Ilave        NUMBER;
    v_Yenileme_Mi         NUMBER;
    v_Pesinat_No          NUMBER;
    v_Odenen              NUMBER;
    v_Business_Start_Date DATE;

    PROCEDURE Get_Valid_Day(p_Date IN OUT DATE) IS
      CURSOR c_Holiday IS
        SELECT a.* FROM Koc_Holiday a ORDER BY a.Holiday_Date;

      c_Row       c_Holiday%ROWTYPE;
      v_Temp_Date DATE;
      --eger vadeli icin kullanilan tarih koc_holiday tablosunda varsa 1 arttirilir

    BEGIN
      v_Temp_Date := p_Date;

      FOR c_Row IN c_Holiday LOOP
        IF (v_Temp_Date = c_Row.Holiday_Date) THEN
          v_Temp_Date := v_Temp_Date + 1;
        ELSE
          p_Date := v_Temp_Date;
        END IF;
      END LOOP;
    END;
  BEGIN
    SELECT Decode(Nvl(p_Insured_Old_Contract, 0), 0, 0, 1)
      INTO v_Yenileme_Mi
      FROM Dual; --yenileme ise 1, yeniis ise 0 d�ner

    SELECT DISTINCT Nvl(v.Business_Start_Date, p.Term_Start_Date)
      INTO v_Business_Start_Date
      FROM Ocp_Policy_Versions v
      JOIN Ocp_Policy_Bases p
        ON p.Contract_Id = v.Contract_Id
       AND p.Top_Indicator = 'Y'
     WHERE v.Contract_Id = p_Contract_Id
       AND Rownum < 2;

    OPEN c_Ilave_Gunler(v_Yenileme_Mi);

    FETCH c_Ilave_Gunler
      INTO v_Pesin_Ilave, v_Taksit_Ilave;

    CLOSE c_Ilave_Gunler;

    OPEN c_Pesinat;

    FETCH c_Pesinat
      INTO v_Pesinat_No;

    CLOSE c_Pesinat;

    p_Status_Code := NULL;
    p_Status_Exp  := NULL;

    FOR c IN c_Payment_Plan LOOP
      OPEN c_Odeme(c.Vade);

      FETCH c_Odeme
        INTO v_Odenen;

      CLOSE c_Odeme;

      IF Nvl(v_Odenen, 0) + 1 < c.Prim_Borcu THEN
        IF c.Taksit_No = v_Pesinat_No --pesinatsa
         THEN
          -- v_ilaveli_date := get_close_date (c.vade, v_pesin_ilave); mustafaku pesinatta poli�e baslangicini dikkate alacak
          v_Ilaveli_Date := KOC_CLM_HLTH_TRNX.Get_Close_Date(v_Business_Start_Date,
                                           v_Pesin_Ilave);
        ELSE
          v_Ilaveli_Date := c.Vade + v_Taksit_Ilave;
          Get_Valid_Day(v_Ilaveli_Date);
          /*
          IF v_ilaveli_date BETWEEN TO_DATE ('11/10/2007', 'DD/MM/YYYY')
                                AND TO_DATE ('14/10/2007', 'DD/MM/YYYY')
          THEN
             v_ilaveli_date := TO_DATE ('15/10/2007', 'DD/MM/YYYY');
          END IF;

          IF v_ilaveli_date BETWEEN TO_DATE ('19/12/2007', 'DD/MM/YYYY')
                                AND TO_DATE ('23/12/2007', 'DD/MM/YYYY')
          THEN
             v_ilaveli_date := TO_DATE ('24/12/2007', 'DD/MM/YYYY');
          END IF;

          IF v_ilaveli_date BETWEEN TO_DATE ('29/09/2008', 'DD/MM/YYYY')
                                AND TO_DATE ('03/10/2008', 'DD/MM/YYYY')
          THEN
             v_ilaveli_date := TO_DATE ('06/10/2008', 'DD/MM/YYYY');
          END IF;

          IF v_ilaveli_date BETWEEN TO_DATE ('06/12/2008', 'DD/MM/YYYY')
                                AND TO_DATE ('14/12/2008', 'DD/MM/YYYY')
          THEN
             v_ilaveli_date := TO_DATE ('15/12/2008', 'DD/MM/YYYY');
          END IF;

          IF v_ilaveli_date BETWEEN TO_DATE ('13/11/2010', 'DD/MM/YYYY')
                                AND TO_DATE ('21/11/2010', 'DD/MM/YYYY')
          THEN
             v_ilaveli_date := TO_DATE ('22/11/2010', 'DD/MM/YYYY');
          END IF;*/
        END IF;

        /*                IF To_Date(To_Char(v_Ilaveli_Date, 'yyyymmdd') || '120000', 'YYYYMMDDHH24MISS') <= p_Date
        THEN
            p_Status_Code := '1';

            IF c.Taksit_No = v_Pesinat_No
            THEN
                p_Status_Exp := 'Pesinati, ';
            ELSE
                p_Status_Exp := p_Status_Exp || To_Char(c.Vade, 'dd/mm/yyyy') || ' taksidi, ';
            END IF;
        END IF;*/
         
        IF To_Date(To_Char(v_Ilaveli_Date, 'yyyymmdd') || '120000',
                   'YYYYMMDDHH24MISS') <= p_Date THEN
          p_Status_Code := '1';
          p_Status_Exp  := To_Char(c.Vade, 'dd/mm/yyyy') || ' ' ||
                           'Vadeli �deme yap�lmam�� poli�e taksiti bulunmas� nedeniyle poli�e tazminata kapal�d�r. L�tfen anla�mal� kurum fiyatlar�n� uygulay�n�z.';
        
          DBMS_OUTPUT.PUT_LINE('p_statur_exp_inner.'|| p_Status_Exp);
        END IF;

      END IF;

    /*       IF To_Date(To_Char(v_Ilaveli_Date, 'yyyymmdd') || '120000', 'YYYYMMDDHH24MISS') <= p_Date
                                                   THEN
                                                                   p_Status_Code := '1';
                                                                   p_Status_Exp  := 'Vadesinde �deme yap�lmam�� poli�e taksiti bulunmas� nedeniyle poli�e tazminata kapal�d�r. L�tfen anla�mal� kurum fiyatlar�n� uygulay�n�z.';
                                                   END IF; */

    END LOOP;

    /*    IF p_Status_Exp IS NOT NULL
    THEN
        p_Status_Exp := p_Status_Exp || '�denmemistir.';
    END IF;*/
  END Clmpaymentstatus;
  
  BEGIN
       Clmpaymentstatus(p_Contract_Id, p_Insured_Old_Contract, p_Date, p_Status_Code,  p_Status_Exp);
       DBMS_OUTPUT.PUT_LINE('status_code='||p_Status_Code);
       DBMS_OUTPUT.PUT_LINE('status_exp='||p_Status_Exp);
  END;
