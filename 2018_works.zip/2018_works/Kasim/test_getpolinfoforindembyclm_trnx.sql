   DECLARE
   
   v_claim_id KOC_CLM_HLTH_DETAIL.claim_id%TYPE;
   v_prov_date DATE := SYSDATE;
   Policyinfo  Koc_v_Hlth_Insured_Info_Indem%ROWTYPE;
   Cur         KOC_CLM_HLTH_TRNX.Refcur;
   BEGIN
     
   v_claim_id := 38178945;
   
   KOC_CLM_HLTH_TRNX.Getpolinfoforindembyclm_Trnx(v_claim_id,
                                   v_prov_date,
                                   Cur);
      FETCH Cur
        INTO Policyinfo;

      CLOSE Cur;
      
      DBMS_OUTPUT.PUT_LINE('part_id='||Policyinfo.partner_id); 
      DBMS_OUTPUT.PUT_LINE('cont_id='||Policyinfo.contract_id);
      DBMS_OUTPUT.PUT_LINE('part_no='||Policyinfo.partition_no);
      DBMS_OUTPUT.PUT_LINE('sub_comp_code='||Policyinfo.sub_company_code); 
      DBMS_OUTPUT.PUT_LINE('ts_date='||Policyinfo.term_start_date); 
      DBMS_OUTPUT.PUT_LINE('te_date='||Policyinfo.term_end_date);
      DBMS_OUTPUT.PUT_LINE('action_code='||Policyinfo.action_code); 
      DBMS_OUTPUT.PUT_LINE('pkg_id='||Policyinfo.package_id);
      DBMS_OUTPUT.PUT_LINE('pkg_date='||Policyinfo. package_date);
      
      
  END;
  
 -- SELECT * FROM KOC_CLM_HLTH_DETAIL where process_date>to_date('01/11/2018','DD/MM/YYYY')
