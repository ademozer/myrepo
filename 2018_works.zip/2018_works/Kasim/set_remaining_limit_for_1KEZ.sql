PROCEDURE Setremaininglimitfor1kez(Pcontractid  IN Koc_Clm_Hlth_Indem_Totals.Contract_Id%TYPE,
                                     Ppartitionno IN Koc_Clm_Hlth_Indem_Totals.Partition_No%TYPE) IS
    CURSOR Crprovisions IS
      SELECT c.Contract_Id,
             c.Oar_No Partition_No,
             a.Claim_Inst_Type,
             a.Claim_Inst_Loc,
             Koc_Clm_Hlth_Utils.Getcountrygroup(a.Country_Code) Country_Group,
             b.Cover_Code,
             b.Is_Pool_Cover,
             b.Is_Special_Cover,
             Nvl(a.Swift_Code, b.Swift_Code) Swift_Code,
             a.Date_Of_Loss Main_Date,
             Nvl(a.Provision_Date, a.Invoice_Date) Prov_Date,
             Nvl(a.Provision_Date, a.Realization_Date) Realize_Date,
             Nvl(b.Request_Amount, 0) - Nvl(b.Refusal_Amount, 0) Spend_Total,
             Nvl(b.Provision_Total, 0) Prov_Amount,
             CASE
               WHEN a.Status_Code IN ('TAH', 'ODE') THEN
                Nvl(b.Provision_Total, 0)
               ELSE
                0
             END Indem_Total,
             Nvl(b.Req_Cure_Day_Count, 0) Req_Cure_Day_Count,
             Nvl(b.Day_Seance, 0) Day_Seance,
             b.Exemption_Rate,
             b.Prov_Date_Time,
             a.Claim_Id,
             a.Provision_User_Id,
             a.Package_Id,
             a.Package_Date,
             a.Part_Id,
             Nvl(b.Exemption_Amount, 0) Exemption_Amount
        FROM Clm_Pol_Oar             c,
             Koc_Clm_Hlth_Detail     a,
             Koc_Clm_Hlth_Provisions b
       WHERE c.Contract_Id = Pcontractid
         AND c.Oar_No = Ppartitionno
         AND a.Claim_Id = c.Claim_Id
         AND a.Claim_Id = b.Claim_Id
         AND a.Sf_No = b.Sf_No
         AND a.Add_Order_No = b.Add_Order_No
         AND Nvl(b.Status_Code, 'PP') NOT IN
             ('PP', 'R', 'C', 'I', 'H', 'TI') --PP de var çünkü bu metodun çagrildigi yerde provizyon durumu net olmayabilir
         AND a.Status_Code IN ('P', 'KI', 'TAH', 'ODE', 'MI')
         AND b.Cover_Code IN
             (SELECT Cover_Code
                FROM Koc_Clm_Hlth_Indem_Totals
               WHERE Contract_Id = Pcontractid
                 AND Partition_No = Ppartitionno
                 AND Nvl(Is_Valid, 0) = 1
                 AND Validity_Start_Date <=
                     Nvl(a.Provision_Date, a.Invoice_Date)
                 AND (Validity_End_Date >=
                     Nvl(a.Provision_Date, a.Invoice_Date) OR
                     Validity_End_Date IS NULL)
                 AND Parent_Cover_Code IN
                     (SELECT Parent_Cover_Code
                        FROM Koc_Clm_Hlth_Indem_Totals
                       WHERE Contract_Id = Pcontractid
                         AND Partition_No = Ppartitionno
                         AND Nvl(Is_Valid, 0) = 1
                         AND Validity_Start_Date <=
                             Nvl(a.Provision_Date, a.Invoice_Date)
                         AND (Validity_End_Date >=
                             Nvl(a.Provision_Date, a.Invoice_Date) OR
                             Validity_End_Date IS NULL)
                         AND Indemnity_Payment_Type = '1KEZ'
                       GROUP BY Parent_Cover_Code)
               GROUP BY Cover_Code)
       ORDER BY Nvl(a.Provision_Date, a.Invoice_Date) NULLS FIRST;

    Rprov              Crprovisions%ROWTYPE;
    Vprovamount        NUMBER;
    Vclaiminsttype     VARCHAR2(10);
    Vispoolcover       NUMBER(1);
    Visspecialcover    NUMBER(1);
    Voutprovamt        NUMBER;
    Voutdayseance      NUMBER;
    Voutexemprate      NUMBER;
    Voutexempsum       NUMBER;
    Voutinstexempsum   NUMBER;
    Vrdayseance        NUMBER;
    Vrcoverprice       NUMBER;
    Vinstprovavalcode  VARCHAR2(3);
    Vinstiscoverval    NUMBER;
    Voutoverprice      VARCHAR2(200);
    v_Exemp_Amount     NUMBER;
    v_Sum_Claim_Amount NUMBER;
  BEGIN
    /*
    1KEZ teminat grubunda olan teminatlarin limitleri yeniden hesaplaniyor.
    */

    UPDATE Koc_Clm_Hlth_Indem_Totals
       SET r_Cover_Price = CASE
                             WHEN Nvl(Is_Unlimited, 0) = 0 THEN
                              f_Cover_Price
                             ELSE
                              r_Cover_Price
                           END,
           r_Exemption_Sum    = f_Exemption_Sum, -- gereksiz
           r_Day_Seance       = f_Day_Seance,    --gereksiz
           s_Spend_Total      = 0,
           s_Exemption_Sum    = 0,
           s_Indemnity_Amount = 0,
           s_Provision_Amount = 0,
           s_Spend_Day_Seance = 0
     WHERE Contract_Id = Pcontractid
       AND Partition_No = Ppartitionno
       AND Parent_Cover_Code IN
           (SELECT Parent_Cover_Code
              FROM Koc_Clm_Hlth_Indem_Totals
             WHERE Pcontractid = Contract_Id
               AND Ppartitionno = Partition_No
               AND '1KEZ' = Indemnity_Payment_Type
             GROUP BY Parent_Cover_Code);  --group by gereksiz 

    OPEN Crprovisions;

    LOOP
      FETCH Crprovisions
        INTO Rprov;

      EXIT WHEN Crprovisions%NOTFOUND;

      Vclaiminsttype  := Rprov.Claim_Inst_Type;
      Vispoolcover    := Rprov.Is_Pool_Cover;
      Visspecialcover := Rprov.Is_Special_Cover;

      IF Nvl(Get_Glis1kezused, 0) = 1 THEN
        BEGIN
          SELECT Claim_Inst_Type, Is_Pool_Cover, Is_Special_Cover
            INTO Vclaiminsttype, Vispoolcover, Visspecialcover
            FROM Koc_Clm_Hlth_Indem_Totals
           WHERE Contract_Id = Rprov.Contract_Id
             AND Partition_No = Rprov.Partition_No
             AND Package_Id = Rprov.Package_Id
             AND Package_Date = Rprov.Package_Date
             AND Country_Group = Nvl(Rprov.Country_Group, 0)
             AND Claim_Inst_Loc = Rprov.Claim_Inst_Loc
             AND Cover_Code = Rprov.Cover_Code
             AND Indemnity_Payment_Type = '1KEZ'
             AND Nvl(Is_Valid, 0) = 1
             AND Validity_Start_Date <= Rprov.Prov_Date
             AND (Validity_End_Date >= Rprov.Prov_Date OR
                 Validity_End_Date IS NULL)
             AND Rownum < 2;
        EXCEPTION
          WHEN OTHERS THEN
            Vclaiminsttype  := Rprov.Claim_Inst_Type;
            Vispoolcover    := Rprov.Is_Pool_Cover;
            Visspecialcover := Rprov.Is_Special_Cover;
        END;
      END IF;

      Vprovamount    := Rprov.Prov_Amount;
      v_Exemp_Amount := Nvl(Rprov.Exemption_Amount, 0);

      IF Rprov.Exemption_Rate != 1 THEN
        Vprovamount := Vprovamount * (1 / (1 - Rprov.Exemption_Rate));
      END IF;

      v_Sum_Claim_Amount := Vprovamount + v_Exemp_Amount;

      Koc_Clm_Hlth_Trnx.Computeremaning(Rprov.Contract_Id,
                                        Rprov.Partition_No,
                                        Rprov.Part_Id,
                                        Rprov.Claim_Id,
                                        NULL,
                                        NULL,
                                        Vclaiminsttype,
                                        Rprov.Claim_Inst_Loc,
                                        Nvl(Rprov.Country_Group, 0),
                                        NULL,
                                        Rprov.Cover_Code,
                                        Rprov.Swift_Code,
                                        Rprov.Main_Date,
                                        Rprov.Prov_Date,
                                        Rprov.Realize_Date,
                                        Rprov.Prov_Date_Time,
                                        v_Sum_Claim_Amount,
                                        Nvl(Rprov.Req_Cure_Day_Count, 0),
                                        NULL,
                                        Nvl(Vispoolcover, 0),
                                        Nvl(Visspecialcover, 0),
                                        1,
                                        Voutprovamt,        -- kullanılmamış
                                        Voutdayseance,      -- kullanılmamış 
                                        Voutexemprate,      -- kullanılmamış 
                                        Voutexempsum,       -- kullanılmamış
                                        Voutinstexempsum,   -- kullanılmamış
                                        Vrdayseance,        -- kullanılmamış
                                        Vrcoverprice,       -- kullanılmamış
                                        Vinstprovavalcode,  -- kullanılmamış
                                        Vinstiscoverval,    -- kullanılmamış
                                        Voutoverprice,      -- kullanılmamış
                                        NULL,
                                        NULL);

      UPDATE Koc_Clm_Hlth_Indem_Totals a
         SET a.s_Indemnity_Amount = Nvl(a.s_Indemnity_Amount, 0) +
                                    Nvl(Rprov.Indem_Total, 0),
             a.s_Provision_Amount = CASE
                                      WHEN Nvl(a.s_Provision_Amount, 0) <
                                           Nvl(Rprov.Indem_Total, 0) THEN
                                       0
                                      ELSE
                                       Nvl(a.s_Provision_Amount, 0) -
                                       Nvl(Rprov.Indem_Total, 0)
                                    END
       WHERE a.Contract_Id = Rprov.Contract_Id
         AND a.Partition_No = Rprov.Partition_No
         AND a.Claim_Inst_Type = Vclaiminsttype
         AND a.Claim_Inst_Loc = Rprov.Claim_Inst_Loc
         AND a.Country_Group = Nvl(Rprov.Country_Group, 0)
         AND a.Is_Pool_Cover = Nvl(Rprov.Is_Pool_Cover, 0)
         AND a.Is_Special_Cover = Nvl(Rprov.Is_Special_Cover, 0)
         AND a.Cover_Code = Rprov.Cover_Code
         AND a.Is_Valid = 1
         AND a.Package_Id = Rprov.Package_Id
         AND a.Package_Date = Rprov.Package_Date
         AND a.Validity_Start_Date =
             (SELECT MAX(Aa.Validity_Start_Date)
                FROM Koc_Clm_Hlth_Indem_Totals Aa
               WHERE Aa.Contract_Id = a.Contract_Id
                 AND Aa.Partition_No = a.Partition_No
                 AND Aa.Claim_Inst_Type = a.Claim_Inst_Type
                 AND Aa.Claim_Inst_Loc = a.Claim_Inst_Loc
                 AND Aa.Country_Group = a.Country_Group
                 AND Aa.Cover_Code = a.Cover_Code
                 AND Aa.Is_Special_Cover = a.Is_Special_Cover
                 AND Aa.Is_Pool_Cover = a.Is_Pool_Cover
                 AND Aa.Package_Date = a.Package_Date
                 AND Aa.Package_Id = a.Package_Id
                 AND Nvl(Aa.Is_Valid, 0) = 1
                 AND Aa.Validity_Start_Date <= Rprov.Prov_Date);
      /*
              insert into tmp_koc_errors  (reference_code, process, sira, online_sq_no, process_date)
              values (pcontractid || ':' || ppartitionno || ':' || rprov.claim_id || ':' || rprov.cover_code
                     ,'setremaininglimitfor1KEZ'
                     ,1
                     ,-1000
                     ,sysdate
                     );
      */
    END LOOP;
  END;