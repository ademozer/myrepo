    
    DECLARE
    
    p_Opus_Date          DATE := SYSDATE;
    p_Product_Id         Clm_Pol_Bases.Product_Id%TYPE := 64; 
    p_Contract_Id        Clm_Pol_Bases.Contract_Id%TYPE := 356215039;
    p_Plan_Type           VARCHAR2(10) := 'KARMA';
    p_Inst_Code           Koc_Clm_Hlth_Detail.Institute_Code%TYPE := 13;
    p_Sgk_Agreement       VARCHAR2(100) := 'Par';
          v_speciality_subject_rec alz_hcl_speciality_subject_rec := alz_hcl_speciality_subject_rec(null,null);
      v_speciality_subject_tbl alz_hcl_speciality_subject_tbl := alz_hcl_speciality_subject_tbl();
      v_converter_row alz_hcl_converter_row := alz_hcl_converter_row();
      v_request CLOB;
      v_response CLOB;
      v_url VARCHAR2(200) := 'http://10.70.225.227:8074/hclm-health-provider-service/api/v1/specialtysubjectlinfo'; -- esb adresi ile de�i�ecek
      v_status NUMBER;
      v_message VARCHAR2(1000);
      
    function convertTableToQueryString(p_parameters IN alz_hcl_converter_row) return CLOB IS

      v_QueryString CLOB;
      v_ndx NUMBER := 0;

    BEGIN

        v_QueryString := '?';

        FOR rec IN (SELECT FIELD_NAME, FIELD_VALUE FROM TABLE(p_parameters)) LOOP

            IF v_ndx>0 THEN
                v_QueryString := v_QueryString || '&';
            END IF;

            v_QueryString := v_QueryString || rec.FIELD_NAME || '=' || rec.FIELD_VALUE;
            v_ndx := v_ndx + 1;

        END LOOP;

        RETURN v_QueryString;

    END convertTableToQueryString;

    procedure addParameterToTable(p_param_name IN VARCHAR2,
                                  p_param_value IN VARCHAR2,
                                  p_param_table IN OUT alz_hcl_converter_row) IS
    BEGIN

         p_param_table.EXTEND;
         p_param_table(p_param_table.COUNT) := alz_hcl_converter_col(p_param_name, p_param_value);

    END addParameterToTable;
    
     procedure callRestService(p_Url               In          Varchar2,
                              p_Method            In          Varchar2,
                              p_Request           In          Clob,
                              p_Response          Out         Clob,
                              p_Status            Out         Number,
                              p_Message           Out         Varchar2) IS

        v_Req               utl_http.req;
        v_Req_Length        Number;
        v_Res               utl_http.resp;
        v_Buffer            Varchar2(32767);
        v_Offset            Number := 1;
        v_Amount            Number :=32767;
        v_Utl_Err           Varchar2(1000);
        v_value             varchar2(4000);
        hata_code           varchar2(10);
        v_output            varchar2(10);
        v_Response          CLOB;
        v_Line_Number       NUMBER := 0;

        Begin
 DBMS_OUTPUT.PUT_LINE(p_Url);
            v_Req_Length := dbms_lob.getlength(p_Request);
            v_Req := utl_http.begin_request(p_Url, p_Method, 'HTTP/1.1');
            utl_http.set_header(v_Req, 'Content-Length', v_Req_Length);
            utl_http.set_header(v_Req, 'Content-Type', 'application/json;charset=UTF-8');
            --utl_http.set_header (v_Req,'Transfer-Encoding', 'chunked' );
          --  utl_http.set_body_charset(v_Req,'UTF-8');

            While (v_Offset < v_Req_Length)
            Loop
               dbms_lob.read(p_Request, v_Amount, v_Offset, v_Buffer);
               utl_http.write_text(r    => v_Req, data => v_Buffer);
               v_Offset := v_Offset + v_Amount;
            End Loop;

            v_Res := utl_http.get_response(v_Req);

            IF v_Res.status_code != 200  THEN
                Raise_Application_Error(-20200, v_Res.status_code || ' - Hata Olu�tu '||v_Res.http_version);
            END IF;

            Begin

               loop

                  utl_http.read_line(v_Res, v_value);
                   DBMS_OUTPUT.PUT_LINE(v_value);
                  IF v_Line_Number = 0 THEN
                     v_value := '';
                  END IF;

                  IF REGEXP_LIKE(v_value, '"uiMessages" :') THEN

                      v_value := TRIM(LTRIM(TRIM(v_value),'"uiMessages" :'));
                      IF NOT REGEXP_LIKE(v_value, 'null') THEN
                           p_Status := 1;
                           p_Message := v_value;
                      END IF;

                  ELSE

                      IF REGEXP_LIKE(TRIM(v_value),  '"data" :') THEN

                          v_value := TRIM(LTRIM(TRIM(v_value),'"data" :'));
                          IF INSTR(v_value,',')>0 THEN
                              v_value := TRIM(regexp_replace(v_value, '([^[:graph:] | ^[:blank:]])', ''));
                              v_value := RTRIM(v_value,',');
                          END IF;

                      END IF;

                      IF TRIM(v_value) IN ('}') THEN
                          v_value := '';
                      END IF;

                      IF REGEXP_LIKE(TRIM(v_value),  '} ],') THEN
                          v_value := '}]';
                      END IF;

                      v_Response := v_Response || v_value;

                  END IF;

                  v_Line_Number := v_Line_Number + 1;

               end loop;

               utl_http.end_response(v_Res);

            Exception
            When utl_http.end_of_body Then
                 utl_http.end_response(v_Res);
            When utl_http.too_many_requests Then
                 utl_http.end_response(v_Res);
            When Others Then
                 utl_http.end_response(v_Res);
           End;

           IF p_Status = 1 THEN
               p_Response := '';
               RETURN;
           END IF;

           p_Response := TRIM(v_Response);
           p_Status := 0;
           p_Message := 'Sorgulama Ba�ar�l�';

        EXCEPTION
           WHEN OTHERS THEN
              DBMS_OUTPUT.PUT_LINE('HATA');
              utl_http.end_response(v_Res);
              v_utl_err:= Utl_Http.Get_Detailed_Sqlerrm;
              
              p_Status := 1;
              p_Response := '';
              p_Message := v_utl_err||' - '||p_url;
              DBMS_OUTPUT.PUT_LINE(SQLERRM);    
    END callRestService;
        
 
                                    



    BEGIN

        addParameterToTable('opusDate', TO_CHAR(p_Opus_Date,'YYYY-MM-DD'), v_converter_row);
        addParameterToTable('productId', TO_CHAR(p_Product_Id), v_converter_row);
        addParameterToTable('contractId', TO_CHAR(p_Contract_Id), v_converter_row);
        addParameterToTable('planType', p_Plan_Type, v_converter_row);
        addParameterToTable('instituteCode', TO_CHAR(p_Inst_Code), v_converter_row);
        addParameterToTable('sgkAgreement', p_Sgk_Agreement, v_converter_row);

        v_request := convertTableToQueryString(v_converter_row);
        
       
        --v_url := v_url || v_request;
        v_url:='http://10.70.225.227:8074/hclm-health-provider-service/say';
         DBMS_OUTPUT.PUT_LINE(v_url);
        v_request := '';

        callRestService(v_url, 'GET', v_request, v_response, v_status, v_message);
        
           DBMS_OUTPUT.PUT_LINE(v_response);
        

        IF v_status = 1 THEN

            v_response := '[{"specialtySubject" : "0", "explanation" : "' || v_message ||'"}]';

        END IF;
        
           DBMS_OUTPUT.PUT_LINE(v_response);

        /*FOR rec_1 IN (SELECT COLUMN_VALUE FROM TABLE(convertPayloadToTable(v_response))) LOOP

            FOR rec_2 IN (SELECT FIELD_NAME, FIELD_VALUE FROM TABLE(rec_1.COLUMN_VALUE)) LOOP

                 IF rec_2.FIELD_NAME = 'specialtySubject' THEN
                    v_speciality_subject_rec.specialty_subject := rec_2.FIELD_VALUE;
                 END IF;

                 IF rec_2.FIELD_NAME = 'explanation' THEN
                    v_speciality_subject_rec.explanation := rec_2.FIELD_VALUE;
                 END IF;

            END LOOP;

            v_speciality_subject_tbl.EXTEND;
            v_speciality_subject_tbl(v_speciality_subject_tbl.COUNT) := v_speciality_subject_rec;

        END LOOP;*/
          
        

   
    
 
    
    END;
    
