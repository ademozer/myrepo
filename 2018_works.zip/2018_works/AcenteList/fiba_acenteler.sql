SELECT TITLE UNVAN,
       ADRES,
       �L,
       �L�E,
       CASE WHEN LENGTH(TELEFON) = 10 THEN SUBSTR(TELEFON,0,3) ELSE '' END ALAN_KODU,
       CASE WHEN LENGTH(TELEFON) = 10 THEN SUBSTR(TELEFON,4) ELSE '' END   TELEFON,
       FULL_NAME "YETK�L� AD SOYAD",
       Tax_Office "VERG� DA�RES�",  
       VKN,
       TCKN
FROM
(select e.int_id,e.title,
       TRIM(KOC_ADDRESS_UTILS.DMT_ADRES(p.add_id)) ADRES, 
       KOC_ADDRESS_UTILS.get_city(p.add_id) �L, 
       KOC_ADDRESS_UTILS.get_district(p.add_id) �L�E, 
       NVL(KOC_PARTNER_UTILS.get_is_tel(p.part_id),             
         NVL(KOC_PARTNER_UTILS.get_cep_tel(p.part_id),
         (SELECT EXPLANATION
            FROM KOC_CP_COMM_DEVICES
           WHERE comm_dev_type = '0080'
             AND part_id = p.part_id
             AND ROWNUM = 1))) TELEFON,         
       p.FIRST_NAME||' '||p.SURNAME FULL_NAME,
       pe.Tax_Office,
       pe.tax_number VKN,
       pe.IDENTITY_NO TCKN
from koc_dmt_agents_ext e, dmt_agents d, cp_partners p, koc_cp_partners_ext pe
where --e.int_id IN (71671,73269) 
   e.company_code='100' 
  and (e.location_code is null or e.int_id = 73269)
  and e.int_id  = d.int_id 
  and p.part_id = SUBSTR(d.cust_part_unique_code,10) 
  and p.part_id = pe.part_id)
  ORDER BY �L,�L�E
