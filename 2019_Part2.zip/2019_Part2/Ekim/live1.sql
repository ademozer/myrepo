select * from customer.alz_hlth_cpa_event_details t where t.event_id = 26357691;--26357691;  --140238401 

select * from alz_hltprv_log t where t.log_id = 140238548;
