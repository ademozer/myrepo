select * from clm_subfiles where ext_reference='58898779'--'58878972';
select * from alz_hclm_version_info where claim_id=42892811;

select institute_code, count(*) 
from alz_hclm_version_info where  NVL(HCLM_CHANNEL,'X') != 'AZNET_REIMBURSEMENT' 
and version_no=1 and entry_date > trunc(sysdate)  group by institute_code


select user_id, count(*) 
from alz_hclm_version_info where  NVL(HCLM_CHANNEL,'X') = 'AZNET_REIMBURSEMENT' 
and version_no=1 and entry_date > TO_DATE('30/09/2019 01:00:00', 'DD/MM/YYYY HH24:MI:SS')  group by user_id

select *--count(*) 
from alz_hclm_version_info
where version_no=1
and entry_date > trunc(sysdate)

42917081

SELECT * FROM ALZ_hlth_cpa_detail_history 
	where 1=1
		AND CLAIM_ID = 42917081
	ORDER BY PROCESS_DATE ASC ;
  
  
  select * from alz_hltprv_log where log_id=140029781
 select * from koc_acc_bank_history where contract_id=455430297 and validity_end_date is null
 50230231736
 56662009790
 
 select * from all_source where lower(text) like '%findeks%'
 
 select * from alz_kkb_iban_ws_req where iban='TR530006200071900006683449'
 select * from koc_acc_bank_history where iban_code='TR530006200071900006683449';
 
 
 SELECT * FROM ALZ_hlth_cpa_detail_history 
	where 1=1
		AND CLAIM_ID = 42764609
	ORDER BY PROCESS_DATE ASC ;
  
  
  
select a.*--count(*)--institute_code, count(*) 
from alz_hclm_version_info a where  NVL(HCLM_CHANNEL,'X') != 'CENTRAL_PROVISION' 
and a.version_no=1 and a.entry_date >  TO_DATE('30/09/2019 01:00:00', 'DD/MM/YYYY HH24:MI:SS')  
and exists (select 1 
              from koc_clm_hlth_indem_dec b 
             where a.claim_id = b.claim_id 
               and b.process_date < TO_DATE('30/09/2019 01:00:00', 'DD/MM/YYYY HH24:MI:SS'))
and status_code='P'
group by institute_code;


select * from koc_clm_hlth_indem_dec;

select * from customer.alz_duplicate_provision where ext_reference='58938367';

select * from alz_hltprv_log where log_id=140400391;
select * from koc_clm_hlth_detail where ext_reference='58938367';
select * from koc_clm_hlth_proc_detail where claim_id=42969758
