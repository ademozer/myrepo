DECLARE
v_string VARCHAR2(32000);
FUNCTION adjustEscapeChars(p_string IN VARCHAR2) RETURN VARCHAR2 IS
       v_string VARCHAR2(32000);
    BEGIN
        v_string := REPLACE(p_string, CHR(39), CHR(39)||CHR(39));
        v_string := REPLACE(v_string, CHR(92), CHR(92)||CHR(92));
        v_string := REPLACE(v_string, CHR(34), CHR(92)||CHR(34));
        v_string := regexp_replace(v_string, '([^[:graph:] | ^[:blank:]])', '\n');
        RETURN v_string;
    END adjustEscapeChars;
    
BEGIN
  --v_string := 't/h"is"'||chr(9)||'is a|te\st';
v_string :='Onay�m�z, 0001171006127653 nolu poli�enin sona erece�i 30/09/2019 tarihi saat 12:00 ye "kadar" ge�erlidir . Talep etti�iniz  tedavi bu tarihten sonra yap�lacak veya devam edecek ise 30/09/2019 tarihinde mevcut provizyonu sonland�rarak , yeniden onay alman�z gerekmektedir.
PNS BT CD S�(KORONEL PLAN ��EREN) PROV�ZYON MERKEZ� �ALI�ANI B��RA MUMCU ADINA (ADRES:ALL�ANZ KAMP�S  FAT�H MAH.SANAY� CAD. NO:35  GAZ�EM�R\�ZM�R) G�NDER�LD�KTEN SONRA �N ONAY DE�ERLEND�RMES� YAPILACAKTIR.

UZMAN DR.  DE�ERLEND�RME S�REC�  SALI VE  PER�EMBE G�NLER� : YAPILMAKTA VE DE�ERLEND�RME SONU�LARI SALI VE  PER�EMBE G�N� **16:00** �T�BAR�YLE �LET�LMEKTED�R. B�LG� ���N ; 0850 399 91 91 NO LU TELEFONA  VEYA busra.mumcu@allianz.com.tr ADRES�NE D�N�� YAPAB�L�RS�N�Z.';
  v_string := '{"text":"'|| adjustEscapeChars(v_string)||'"}';
  DBMS_OUTPUT.PUT_LINE(v_string);
END;


