INSERT INTO ALZ_HLTH_ANNOUNCEMENT(announcement_no,
       validity_start_date,
       from_user,user_department,
       announc_date,
       validity_end_date,
       announc_header,
       announc_subject,
       announc_explanation,
       content_type,
       attachment)
select announcement_no,
       validity_start_date,
       from_user,user_department,
       announc_date,
       validity_end_date,
       announc_header,
       announc_subject,
       announc_explanation,
       content_type,
       CASE WHEN content_type IS NULL THEN NULL ELSE '\\dysfileshare\docsharetest\ANNOUNCEMENT\announcement_'||announcement_no||(CASE content_type WHEN 'application/pdf' THEN '.pdf' WHEN 'application/msword' THEN '.doc' ELSE '.docx' END) END ATTACHMENT  
  from KOC_ANNOUNCEMENT@KASCV@EPROVIZYON
/
COMMIT
/
