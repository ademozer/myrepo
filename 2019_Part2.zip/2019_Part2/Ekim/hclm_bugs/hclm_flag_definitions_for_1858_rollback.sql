update alz_hclm_institute_info
   set hclm_usage = 0
 where institute_code = 1858; 
 
COMMIT;

