delete koc_auth_user_role_rel where role_code='HCLMPROV' and username NOT IN('WYSALICI','WAOZTURKLER')
/
COMMIT
/
