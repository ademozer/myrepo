--create table hclm_log_takip(log_id NUMBER, service_name VARCHAR2(100), log_date DATE, log_content VARCHAR2(4000),ext_reference VARCHAR2(10));
DECLARE

   v_services VARCHAR2(4000) := 'CREATE_PROVISION;UPDATE_PROVISION;REJECT_PROVISION;CANCEL_PROVISION;COMPUTE_REMAINING;PROCESS_PRICE';   
   v_date     DATE := TRUNC(SYSDATE-1);
   v_count    NUMBER :=0;
BEGIN
   FOR rec IN (SELECT ELEMENT FROM (SELECT Regexp_Substr (v_services, '[^;]+', 1, LEVEL) ELEMENT
                                      FROM Dual
                            CONNECT BY LEVEL <= LENGTH (Regexp_Replace (v_services, '[^;]+')) + 1)) 
   LOOP
            --DBMS_OUTPUT.PUT_LINE(rec.ELEMENT);
            FOR rec2 IN (select log_id, note service_name, log_date, SUBSTR(content,1,3000) log_content, TO_CHAR(insuredno) ext_reference 
                           from alz_hltprv_log a where TRUNC(log_date) = v_date 
                            and servicename='ALZ_HCLM_CONVERTER_UTILS' 
                            and note=rec.ELEMENT||'_REQUEST'
                            and exists(select 1 
                                         from alz_hltprv_log b 
                                        where servicename='ALZ_HCLM_CONVERTER_UTILS' 
                                          and note=rec.ELEMENT||'_EXCEPTION' 
                                          and a.log_id = b. log_id)) 
             LOOP
                 insert into hclm_log_takip(log_id, service_name, log_date, log_content, ext_reference)
                 values(rec2.log_id, rec2.service_name, rec2.log_date, rec2.log_content, rec2.ext_reference);
                 v_count := v_count + 1;
             END LOOP;
                               
   END LOOP;
   
   COMMIT;
   
   DBMS_OUTPUT.PUT_LINE(v_date||' tarihinde '||v_count|| ' adet hata tespit edildi');
   
END;
