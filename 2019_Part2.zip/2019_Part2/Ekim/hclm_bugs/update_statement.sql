Update Koc_Clm_Hlth_Prov_Statemnt 
   Set status_code = 'P'
 Where claim_id=43095562;
 
 COMMIT;
 
