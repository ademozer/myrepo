insert into koc_auth_user_role_rel (USERNAME, ROLE_CODE, VALIDITY_START_DATE, VALIDITY_END_DATE, IS_AUTHORIZED_AGENCY_USER, REGION_CODE)
values ('WOUGURLU', 'HCLMPROV', trunc(sysdate), null, null, null);

insert into koc_auth_user_role_rel (USERNAME, ROLE_CODE, VALIDITY_START_DATE, VALIDITY_END_DATE, IS_AUTHORIZED_AGENCY_USER, REGION_CODE)
values ('WDBASODA', 'HCLMPROV', trunc(sysdate), null, null, null);

insert into koc_auth_user_role_rel (USERNAME, ROLE_CODE, VALIDITY_START_DATE, VALIDITY_END_DATE, IS_AUTHORIZED_AGENCY_USER, REGION_CODE)
values ('WORYILMAZ', 'HCLMPROV', trunc(sysdate), null, null, null);

insert into koc_auth_user_role_rel (USERNAME, ROLE_CODE, VALIDITY_START_DATE, VALIDITY_END_DATE, IS_AUTHORIZED_AGENCY_USER, REGION_CODE)
values ('WKGURLU', 'HCLMPROV', trunc(sysdate), null, null, null);

COMMIT;




