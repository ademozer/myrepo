update alz_hclm_institute_info 
   set hclm_usage=0
 where hclm_usage=1 
   and institute_code not in(28,6411,553)
/
COMMIT
/
