DECLARE
  
  v_url VARCHAR2(4000) := 
 --'http://10.70.47.81:17101/healthProvisionWS/ProxyServices/BreServices?WSDL';
  Get_Url_Link ('http://eprovesb.allianz.com.tr:12000/healthProvisionWS/ProxyServices/BreServices?WSDL');

  v_request CLOB;
  
  v_response CLOB;
  
  v_message VARCHAR2(4000);
  
  v_status NUMBER;
  
  v_method VARCHAR2(100) := 'POST';
  
  procedure callRestService(p_Url               In          Varchar2,
                              p_Method            In          Varchar2,
                              p_Request           In          Clob,
                              p_Response          Out         Clob,
                              p_Status            Out         Number,
                              p_Message           Out         Varchar2) IS

        v_Req               utl_http.req;
        v_Req_Length        Number;
        v_Res               utl_http.resp;
        v_Buffer            Varchar2(32767);
        v_Offset            Number := 1;
        v_Amount            Number :=32767;
        v_Utl_Err           Varchar2(1000);
        v_value             varchar2(4000);
        hata_code           varchar2(10);
        v_output            varchar2(10);
        v_Response          CLOB;
        v_Line_Number       NUMBER := 0;

        Begin

            v_Req_Length := dbms_lob.getlength(p_Request);
            v_Req := utl_http.begin_request(p_Url, p_Method, 'HTTP/1.1');
            utl_http.set_header(v_Req, 'Content-Length', v_Req_Length);
            utl_http.set_header(v_Req, 'Content-Type', 'application/json;charset=UTF-8');
            utl_http.set_header(v_Req, 'Transfer-Encoding', 'chunked' );
            utl_http.set_header(v_Req, 'hclm-channel', 'PHARMACY');
            utl_http.set_header(v_Req, 'hclm-institute', '1150');
            utl_http.set_transfer_timeout(300);
            utl_http.set_body_charset(v_Req,'UTF-8');

            While (v_Offset < v_Req_Length)
            Loop
               dbms_lob.read(p_Request, v_Amount, v_Offset, v_Buffer);
               utl_http.write_text(r    => v_Req, data => v_Buffer);
               v_Offset := v_Offset + v_Amount;
            End Loop;

            v_Res := utl_http.get_response(v_Req);
            p_status := 0;
            p_message := v_Res.status_code || ':' || v_Res.reason_phrase;
            IF v_Res.status_code != 200  THEN
                p_Status := 1;
            END IF;
            Begin
               loop
                  utl_http.read_line(v_Res, v_value);
                  v_value := TRIM(regexp_replace(v_value, '([^[:graph:] | ^[:blank:]])', ''));
                  v_Response := v_Response || v_value;
               end loop;
               utl_http.end_response(v_Res);
            Exception
            When utl_http.end_of_body Then
                 utl_http.end_response(v_Res);
            When utl_http.too_many_requests Then
                 utl_http.end_response(v_Res);
            When Others Then
                 utl_http.end_response(v_Res);
           End;
           p_Response := TRIM(v_Response);
           IF INSTR(p_Response,'"errors"')>0 THEN
               p_Status := 1;
               p_message := 'Business Exception';
           END IF;
        EXCEPTION
           WHEN OTHERS THEN
              utl_http.end_response(v_Res);
              v_utl_err:= Utl_Http.Get_Detailed_Sqlerrm;
              p_Status := 1;
              p_Response := '';
              p_Message := v_utl_err||' - '||p_url;
    END callRestService;
    
    BEGIN
         v_request := '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://service.ws.provision.health.allianz.com/"><soapenv:Header>
    <CustomSoapHeader>
      <hclm-channel>PHARMACY</hclm-channel>
      <hclm-institute>1150</hclm-institute>
    </CustomSoapHeader>
   </soapenv:Header><soapenv:Body><ser:getHltMedBreObj><arg0><claimid>46161598</claimid><contractid>441564560</contractid><medicineFlow>TEMINAT_KONTROL</medicineFlow><medicineList><barcode>8699832090055</barcode><price></price><unit>3</unit><coverCode>S512</coverCode></medicineList><partitionno>10621</partitionno><prescription></prescription><provisiondate>2019-10-04T10:21:25</provisiondate><specialitySubject>1030</specialitySubject></arg0></ser:getHltMedBreObj></soapenv:Body> </soapenv:Envelope> ';

         callRestService(v_url, v_method, v_request, v_response, v_status, v_message);
         DBMS_OUTPUT.PUT_LINE(v_response);
    END; 
