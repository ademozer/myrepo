DELETE koc_clm_medicine_indem_det
 where claim_id = 43060932
   and sf_no = 1
   and add_order_no = 1
/
COMMIT
/
