select * from clm_subfiles where claim_id=43309096

select * from koc_clm_hlth_provisions where claim_id in(
select claim_id from clm_pol_oar where contract_id=443334736 and oar_no=4)
and status_code IN('P','ODE')

select * from cfg_v_prod_covers_api where cover_code='S539';
select * from koc_clm_hlth_indem_totals where contract_id=443334736 and partition_no=4 and cover_code='S539' FOR UPDATE;

select * from customer.alz_duplicate_provision where ext_reference='59201488'
