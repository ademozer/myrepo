select * from clm_subfiles where ext_reference = '58912049';
select * from clm_pol_oar where claim_id=42934947
select * from alz_hclm_version_info where claim_id = 43159427 for update;
select * from koc_clm_hlth_provisions where claim_id=43127764 for update;
select * from koc_clm_hlth_detail where claim_id=43306586  for update;
select * from koc_clm_hlth_reject_loss where claim_id=43306586;
select * from koc_clm_hlth_indem_dec where claim_id=43306586;

select * from 

delete koc_clm_close_to_indemnity where contract_id = 424217403 and partition_no = 1


select 
and not exists(select 1 from koc_clm_web_auth_pool where claim_id=d.claim_id)
and medula_date is not null
and status_code = 'P'

 --and bre_result_code not in('PP','R')--claim_id=42725209 for update;
select * from clm_pol_oar where contract_id=456562298 and oar_no=118 order by 1
 SELECT d.Claim_Id,
             d.Sf_No,
             d.Add_Order_No,
             
             
             d.Institute_Code
        FROM Koc_Clm_Hlth_Detail d
       WHERE Nvl(d.Is_Suspense, 0) = 1
         AND d.Suspense_Date = TO_DATE('21/10/2019','DD/MM/YYYY')
         --AND ext_reference='56896909'
         AND Nvl(d.Status_Code, 'PP') IN ('P', 'I', 'KI', 'MI')
         And d.Discharge_Date Is Null;
         
select * from alz_hclm_version_info v
where exists(select 1 from koc_clm_hlth_detail where claim_id=v.claim_id and status_code='P')
order by entry_date
KOC_CLM_HLTH_TRNX;

select * from clm_pol_oar where contract_id=428579506;

select * from clm_subfiles where claim_id=43232650

select * from alz_hclm_version_info where claim_id=43079690  for update 

select * from alz_hltprv_log where log_id=143414075;


update alz_hclm_version_info 
   set hclm_usage = 0
 where claim_id in (select claim_id 
                      from clm_subfiles 
                     where ext_reference in('59122718'))

select * 
  from  alz_hclm_version_info 
 where claim_id in (select claim_id 
                      from clm_subfiles 
                     where ext_reference in('59122730', '59122822', '59122673', '59059805', '59112053','59122793', '59122704'))

SELECT CHR(34) FROM DUAL

SELECT CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.getHclmUsage(null, 
  null,
     	    	                                                                 null,
     	    	                                                                 'WKGURLU',
     	    	                                                                 NULL,
     	    	                                                                 NULL) FROM DUAL;
                                                                             
                                                                             select * from customer.alz_hlth_announcement_inst
