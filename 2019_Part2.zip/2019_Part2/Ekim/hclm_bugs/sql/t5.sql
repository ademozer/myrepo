select * from alz_hltprv_log where log_id in(
select log_id from hclm_log_takip  where trunc(log_date)=trunc(sysdate-1) and SERVICE_NAME='COMPUTE_REMAINING_REQUEST')
--and NOTE IN('COMPUTE_REMAINING_REQUEST','COMPUTE_REMAINING_RESPONSE')
and LOG_SOURCE!='PLSQL CENTRAL_REIMBURSEMENT'
and LOG_SOURCE='PLSQL CENTRAL_COVERS'
order by log_id


select * from hclm_log_takip  where trunc(log_date)=trunc(sysdate-1)
select * from alz_hltprv_log where log_id=43236458--142135488--141997052--141746197
Hasar dosyas� MEDISER168 �zerinde g�r�nmektedir. {ProvisionValidationServiceImpl.java#validateWebAuthPool:2164};
Hasar dosyas� , MEDISER168 �zerinde g�r�nmektedir

ALZ_HCLM_CONVERTER_UTILS;



select * from alz_hltprv_log where trunc(log_date) = trunc(sysdate-1) and NOTE='COMPUTE_REMAINING_REQUEST' and LOG_SOURCE='PLSQL CENTRAL_PROVISION:43236194:1:1'
