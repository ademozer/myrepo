select * from alz_hltprv_log where log_id=140417828;

select * from koc_clm_hlth_detail where ext_reference in ('58935773','58950079')--claim_id=42966158;  --58950079
select * from clm_pol_bases where claim_id=42966158
select * from alz_hclm_version_info where claim_id = 42966158;

SELECT * FROM CUSTOMER.ALZ_DUPLICATE_PROVISION WHERE EXT_REFERENCE='58935773';

SELECT * FROM ALZ_HLTPRV_LOG WHERE LOG_ID=140975898--141334047

SELECT * FROM ALZ_HCLM_VERSION_INFO WHERE ENTRY_DATE>TRUNC(SYSDATE) AND VERSION_NO=1 and institute_Code=13;

select * from koc_clm_medicine_indem_det where vat_rate is not null and vat_rate NOT IN(8,0,18) and rownum<4;

select *
      from koc_clm_medicine_indem_det
     where claim_id = 43060932
       and sf_no = 1
       and add_order_no = 1;
       
       select * from clm_subfiles where ext_reference='59009137';
       
       select * from cfg_v_prod_covers_api where cover_code='S355';
       select * from cur_translations where desc_int_id=166385
