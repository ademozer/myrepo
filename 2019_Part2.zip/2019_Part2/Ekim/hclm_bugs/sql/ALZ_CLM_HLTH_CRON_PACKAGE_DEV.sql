
  CREATE OR REPLACE PACKAGE "CUSTOMER"."ALZ_CLM_HLTH_CRON" IS

	--Sa�l�k Hasar Ekibi ron i�ler

	/*
     Yat�� Tarihin = sysdate && muallak flag = 1 && Dosya statusu =  P olan dosyalar�n is_complementary ve kullan�lan teminatlar�n� �ekip
     E�er TSS ? TSS_PERIOD_DAY , OSS ?  OSS_PERIOD_DAY , teminat cover codelar� ? COVER_CODE_PERIOD (ALZ_HLTH_PRV_PENDING_PERIOD)
     Belirlenen g�n hlth_detail da ki suspense_date e set ediliyor.
     saat 12 den sonra �al��t��� i�in (sysdate-1)
  */
	PROCEDURE Get_Valid_Day(p_Date IN OUT DATE);
	PROCEDURE Calc_Working_Date(p_Date IN OUT DATE,
															p_Day  IN NUMBER);
	FUNCTION Get_Suspense_Day(p_Claim_Id Koc_Clm_Hlth_Detail.Claim_Id%TYPE) RETURN NUMBER;
	PROCEDURE Pr_Set_Suspense_Date;
	PROCEDURE Pr_Cancel_Suspense;

	--
	PROCEDURE Pr_Mydoc;
	PROCEDURE informMailCPAInv(p_testmail   VARCHAR2);

END Alz_Clm_Hlth_Cron;

CREATE OR REPLACE PACKAGE BODY "CUSTOMER"."ALZ_CLM_HLTH_CRON" IS

	PROCEDURE Get_Valid_Day(p_Date IN OUT DATE) IS
		CURSOR c_Holiday(Pc_Date DATE) IS
			SELECT a.* FROM Koc_Holiday a WHERE a.Holiday_Date = Pc_Date;

		c_Row       c_Holiday%ROWTYPE;
		v_Temp_Date DATE;
		v_Day       VARCHAR2(50);
	BEGIN
		v_Temp_Date := p_Date;
		IF TRIM(To_Char(v_Temp_Date, 'DAY')) IN ('PAZAR', 'SUNDAY')
		THEN
			v_Temp_Date := v_Temp_Date + 1;
		ELSIF TRIM(To_Char(v_Temp_Date, 'DAY')) IN ('CUMARTESI', 'CUMARTES�', 'SATURDAY')
		THEN
			v_Temp_Date := v_Temp_Date + 2;
		END IF;
		--v_day := To_Char(v_Temp_Date, 'DAY')  ;
		FOR c_Row IN c_Holiday(v_Temp_Date)
		LOOP
			v_Temp_Date := v_Temp_Date + 1;
			Get_Valid_Day(v_Temp_Date);
		END LOOP;
		p_Date := v_Temp_Date;

	END;

	PROCEDURE Calc_Working_Date(p_Date IN OUT DATE,
															p_Day  IN NUMBER)

	 IS
		v_Date DATE := p_Date;

	BEGIN
		v_Date := v_Date + p_Day;
		Alz_Clm_Hlth_Cron.Get_Valid_Day(v_Date);
		/*FOR DAY IN 1 .. p_Day
    LOOP

      Alz_Clm_Hlth_Cron.Get_Valid_Day(v_Date);
      v_Date := v_Date + 1;
    END LOOP;*/
		p_Date := v_Date;
	END;

	FUNCTION Get_Suspense_Day(p_Claim_Id Koc_Clm_Hlth_Detail.Claim_Id%TYPE) RETURN NUMBER IS
		v_Day NUMBER := 0;
	BEGIN

		SELECT MIN(Claim_Period)
			INTO v_Day
			FROM (SELECT d.Claim_Id,
									 d.Sf_No,
									 d.Add_Order_No,
									 d.Provision_Date,
									 d.Hospitalize_Date,
									 d.Is_Complementary,
									 p.Cover_Code,
									 Decode(Sign(Nvl(a.Cover_Code_Period, 0) - Nvl(Decode(d.Is_Complementary, 1, a.Tss_Period_Day, a.Oss_Period_Day), 0)), 1,
													Nvl(a.Cover_Code_Period, 0), Nvl(Decode(d.Is_Complementary, 1, a.Tss_Period_Day, a.Oss_Period_Day), 0)) Claim_Period
							FROM Koc_Clm_Hlth_Detail         d,
									 Koc_Clm_Hlth_Provisions     p,
									 Alz_Hlth_Prv_Pending_Period a
						 WHERE 1 = 1
							 AND d.Claim_Id = p_Claim_Id
									-- And Trunc(d.Hospitalize_Date) <= Trunc(SYSDATE - 1)
									--AND Nvl(d.Is_Suspense, 0) = 1
									-- AND d.Suspense_Date IS NULL
							 AND d.Claim_Id = p.Claim_Id
							 AND d.Sf_No = p.Sf_No
							 AND d.Add_Order_No = p.Add_Order_No
							 AND p.Cover_Code = Nvl(a.Cover_Code, p.Cover_Code)
							 AND d.Provision_Date BETWEEN a.Validity_Start_Date AND Nvl(a.Validity_End_Date, d.Provision_Date))
		 WHERE Claim_Period <> 0
		 GROUP BY Claim_Id,
							Sf_No,
							Add_Order_No;

		RETURN v_Day;

	EXCEPTION
		WHEN OTHERS THEN
			RETURN v_Day;
	END;

	--
	PROCEDURE Pr_Set_Suspense_Date IS
		v_Date     DATE;
		v_Day      NUMBER;
		v_Term_Day NUMBER;
	BEGIN

		FOR Claims IN (SELECT Claim_Id,
													Sf_No,
													Add_Order_No,
													Hospitalize_Date,
                          Is_Complementary
										 FROM (SELECT d.Claim_Id,
																	d.Sf_No,
																	d.Add_Order_No,
																	d.Provision_Date,
																	d.Hospitalize_Date,
																	nvl(d.Is_Complementary,0) Is_Complementary
														 FROM Koc_Clm_Hlth_Detail d
														WHERE Trunc(d.Hospitalize_Date) <= Trunc(SYSDATE - 1)
															AND Nvl(d.Is_Suspense, 0) = 1
															AND d.Discharge_Date IS NULL
															AND d.Suspense_Date IS NULL)
										GROUP BY Claim_Id,
													Sf_No,
													Add_Order_No,
													Hospitalize_Date,
                          Is_Complementary)
		LOOP

			SELECT p.Term_End_Date - Trunc(Claims.Hospitalize_Date)
				INTO v_Term_Day
				FROM Ocp_Policy_Bases p
			 WHERE EXISTS (SELECT NULL
								FROM Clm_Pol_Oar c
							 WHERE c.Claim_Id = Claims.Claim_Id
								 AND c.Contract_Id = p.Contract_Id)
				 AND p.Top_Indicator = 'Y'
				 AND p.Action_Code <> 'D';

			v_Date := Claims.Hospitalize_Date;
			v_Day  := Get_Suspense_Day(Claims.Claim_Id);

      IF v_Term_Day < v_Day AND Claims.Is_Complementary <> 1
			THEN
				v_Day := v_Term_Day + 1 ;
			END IF;

			Calc_Working_Date(v_Date, v_Day);

			UPDATE Koc_Clm_Hlth_Detail d
				 SET d.Suspense_Date = v_Date --Claims.Suspense_Date
			 WHERE d.Claim_Id = Claims.Claim_Id
				 AND d.Sf_No = Claims.Sf_No
				 AND d.Add_Order_No = Claims.Add_Order_No;

			COMMIT;
		END LOOP;
	EXCEPTION
		WHEN OTHERS THEN
			ROLLBACK;
			Raise_Application_Error(-20110, 'pr_set_suspense_date:' || SQLERRM);
	END Pr_Set_Suspense_Date;

	--
	PROCEDURE Pr_Cancel_Suspense IS

		v_Date DATE := Trunc(SYSDATE);
		CURSOR c_Suspense IS
			SELECT d.Claim_Id,
						 d.Sf_No,
						 d.Add_Order_No,
						 d.Institute_Code
				FROM Koc_Clm_Hlth_Detail d
			 WHERE Nvl(d.Is_Suspense, 0) = 1
				 AND d.Suspense_Date = v_Date
				 AND Nvl(d.Status_Code, 'PP') IN ('P', 'I', 'KI', 'MI')
         And d.Discharge_Date Is Null;

		c_Sus        c_Suspense%ROWTYPE;
		v_Err_Sq     NUMBER;
		v_Err_Msg    VARCHAR2(5000);
		v_Cancel_Exp VARCHAR2(5000) := '�lgili provizyon i�in �n onay ge�erlilik s�resi doldu�undan provizyon iptal edilmi�tir.';

		PROCEDURE Delete_Provisions(p_Del_Or_Rej   NUMBER,
																p_Cancel_Exp   VARCHAR2,
																p_Claim_Id     Koc_Clm_Hlth_Detail.Claim_Id%TYPE,
																p_Sf_No        Koc_Clm_Hlth_Detail.Sf_No%TYPE,
																p_Add_Order_No Koc_Clm_Hlth_Detail.Add_Order_No%TYPE) IS
			Clmdetail Koc_Clm_Hlth_Trnx.Clmdetailtype;

			v_User_Id      VARCHAR2(30) := 'OTOIPT';
			v_Contract_Id  NUMBER;
			v_Partition_No NUMBER;
			j              NUMBER;
			i              NUMBER;
			v_Reject       NUMBER;
			Startreq       Customer.Web_Provision.Startazprovision_Req;
			Startres       Customer.Web_Provision.Startazprovision_Res;
			Providereq     Customer.Web_Provision.Provideprovision_Req;
			Provideres     Customer.Web_Provision.Provideprovision_Res;
			v_Msg_Level    NUMBER;

			CURSOR c_Data(Pp_Claim_Id NUMBER,
										Pp_Sf_No    NUMBER) IS
				SELECT x.Claim_Id,
							 x.Institute_Code,
							 x.Part_Id,
							 x.Provision_Date,
							 x.Package_Id,
							 x.Group_Code,
							 x.Status_Code,
							 y.Policy_Ref,
							 y.Product_Id,
							 y.Contract_Id,
							 y.Agent_Role
					FROM Koc_Clm_Hlth_Detail x,
							 Clm_Pol_Bases       y
				 WHERE x.Claim_Id = Pp_Claim_Id
					 AND x.Sf_No = Pp_Sf_No
					 AND x.Claim_Id = y.Claim_Id;

			Rec_Data c_Data%ROWTYPE;

			CURSOR c_Partition_Type(Pp_Contract_Id NUMBER) IS
				SELECT Partition_Type FROM Ocp_Partitions WHERE Contract_Id = Pp_Contract_Id;

			v_Partition_Type Ocp_Partitions.Partition_Type%TYPE;

			CURSOR c_Location_Code(Pp_Claim_Id NUMBER,
														 Pp_Sf_No    NUMBER) IS
				SELECT Location_Code
					FROM Koc_Clm_Hlth_Provisions
				 WHERE Claim_Id = Pp_Claim_Id
					 AND Sf_No = Pp_Sf_No;

			v_Location_Code Koc_Clm_Hlth_Provisions.Location_Code%TYPE;

			v_Clm_Check NUMBER := 0;
			v_Error_Exp VARCHAR2(500);

		BEGIN

			SELECT Contract_Id,
						 Oar_No
				INTO v_Contract_Id,
						 v_Partition_No
				FROM Clm_Pol_Oar c
			 WHERE c.Claim_Id = p_Claim_Id;

			Koc_Pk_Hlth_Provision.Getdetaildata_Trnx(p_Claim_Id, p_Sf_No, p_Add_Order_No, Clmdetail);
      --[ademo.HRCL1-2601 21.10.2019
      IF ALZ_HCLM_CONVERTER_UTILS.getHclmUsage(null, p_Claim_Id, null, null, 'OTOMATIK_MUALLAK_IPTALI','CENTRAL_PROVISION') = 1 THEN
          ALZ_HCLM_CONVERTER_UTILS.setChannel('CENTRAL_PROVISION');
          ALZ_HCLM_CONVERTER_UTILS.cancelProvision(v_Contract_Id,
                                                   v_Partition_No,
                                                   COALESCE(Clmdetail(1).Medula_Date, Clmdetail(1).Provision_Date),
                                                   v_User_Id,
                                                   Clmdetail,
                                                   v_Cancel_Exp);
      ELSE
          Koc_Clm_Hlth_Trnx.Delete_Provisions(v_Contract_Id, v_Partition_No, Clmdetail(1).Provision_Date, NULL, NULL, v_User_Id, p_Del_Or_Rej, Clmdetail,
                                              v_Cancel_Exp);

          Koc_Clm_Hlth_Hospt_Utils.Resetsyt0(Clmdetail(1).Claim_Id, Clmdetail(1).Sf_No);
          Koc_Clm_Hlth_Trnx.Is_Hlth_Clm_Check(Clmdetail(1).Claim_Id, Clmdetail(1).Sf_No, 1, v_Clm_Check, v_Error_Exp);

          IF v_Clm_Check <> 1
          THEN
            IF p_Del_Or_Rej IN (1, 2)
            THEN
              BEGIN
                UPDATE Koc_Clm_Hlth_Incomp_Papers
                   SET Status_Code = 'C'
                 WHERE Claim_Id = Clmdetail(1).Claim_Id
                   AND Status_Code = 'A';
              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;
            END IF;
            --\\

            Koc_Clm_Hlth_Trnx.Datacommit;

            OPEN c_Data(Clmdetail(1).Claim_Id, Clmdetail(1).Sf_No);
            FETCH c_Data
              INTO Rec_Data;
            CLOSE c_Data;

            OPEN c_Partition_Type(Rec_Data.Contract_Id);
            FETCH c_Partition_Type
              INTO v_Partition_Type;
            CLOSE c_Partition_Type;

            IF Nvl(Clmdetail(1).Status_Code, 'X') IN ('PP', 'CP')
            THEN

              SELECT r.Instance_Id
                INTO Providereq.Instance_Id
                FROM Koc_Clm_Web_Auth_Pool r
               WHERE Claim_Id = p_Claim_Id
                 AND Status_Code <> 'C'
                 AND Rownum < 2;

              Providereq.User_Name   := v_User_Id;
              Providereq.Status_Code := Rec_Data.Status_Code;
              BEGIN
                Provideres := Customer.Web_Provision.Provideprovision(Providereq);

              EXCEPTION
                WHEN OTHERS THEN
                  Web_Clm_Hlth_Hospt_Utils.Koc_Bpm_Project_Log_Write(SYSDATE, 'WEB PROVISON', 'KOCCLM300', 'delete_provison', Clmdetail(1).Claim_Id,
                                                                     v_User_Id, 'customer.web_provision.provideProvision', SQLERRM);
              END;

            ELSE
              OPEN c_Location_Code(Clmdetail(1).Claim_Id, Clmdetail(1).Sf_No);
              FETCH c_Location_Code
                INTO v_Location_Code;
              CLOSE c_Location_Code;

              Startreq.User_Name      := v_User_Id;
              Startreq.Claim_Id       := Clmdetail(1).Claim_Id;
              Startreq.Institute_Code := Rec_Data.Institute_Code;
              Startreq.Location_Code  := v_Location_Code;
              Startreq.Part_Id        := Rec_Data.Part_Id;
              Startreq.Unit_Id        := Koc_Clm_Hlth_Bpm_Utils.Gettounitinfobyinstitutecode(Rec_Data.Institute_Code, Rec_Data.Provision_Date);
              Startreq.Package_Id     := Rec_Data.Package_Id;
              Startreq.Product_Id     := Nvl(Rec_Data.Product_Id, 0);
              Startreq.Partition_Type := v_Partition_Type;
              Startreq.Group_Code     := Rec_Data.Group_Code;
              Startreq.Policy_Ref     := Rec_Data.Policy_Ref;
              Startreq.Agency_Code    := Koc_Clm_Hlth_Utils.Getacencycode(Rec_Data.Agent_Role, Rec_Data.Provision_Date);
              Startreq.Provision_Type := Koc_Clm_Hlth_Bpm_Utils.Getuserroletype(v_User_Id);
              IF Nvl(Rec_Data.Status_Code, 'PP') = 'PP'
              THEN
                Startreq.Processtype := 'false';
              ELSE
                Startreq.Processtype := 'true';
              END IF;
              Startreq.Status_Code := Rec_Data.Status_Code;
              ----------------------------
              BEGIN
                Startres := Customer.Web_Provision.Startazprovision(Startreq);
              EXCEPTION
                WHEN OTHERS THEN
                  Web_Clm_Hlth_Hospt_Utils.Koc_Bpm_Project_Log_Write(SYSDATE, 'WEB PROVISON', 'KOCCLM300', 'delete_provison', Clmdetail(1).Claim_Id,
                                                                     v_User_Id, 'customer.web_provision.startAZProvision', SQLERRM);
              END;

            END IF;
          END IF;
      END IF; --ademo.HRCL1-2601]
		EXCEPTION
			WHEN OTHERS THEN
				NULL;
		END Delete_Provisions;

	BEGIN
		v_Err_Sq := Koc_Hlth_Clm_Transfer.Geterrseq;

		OPEN c_Suspense;
		LOOP
			FETCH c_Suspense
				INTO c_Sus;
			EXIT WHEN c_Suspense%NOTFOUND;

			BEGIN
				--
				Delete_Provisions(1, 'Otomatik Muallak Dosya �ptali', c_Sus.Claim_Id, c_Sus.Sf_No, c_Sus.Add_Order_No);
				COMMIT;
				--
			EXCEPTION
				WHEN OTHERS THEN

					v_Err_Msg := SQLERRM;
					v_Err_Msg := Substr(v_Err_Msg, 1, 500);
					ROLLBACK;

					INSERT INTO Tmp_Koc_Errors
						(Reference_Code, Process, Error, Process_Date, Script_Name, Sira, Online_Sq_No)
					VALUES
						(c_Sus.Claim_Id, 'SUSPENSE', v_Err_Msg, SYSDATE, 'SUSPENSE', NULL, v_Err_Sq);
					COMMIT;
			END;
		END LOOP;
	END Pr_Cancel_Suspense;

	PROCEDURE Pr_Mydoc IS
	BEGIN
		Alz_Hlth_Mydoc_Pck.Call_Mydoc;
	EXCEPTION
		WHEN OTHERS THEN
			ROLLBACK;
			Raise_Application_Error(-20110, 'pr_mydoc:' || SQLERRM);

	END Pr_Mydoc;
	PROCEDURE informMailCPAInv(p_testmail   VARCHAR2) IS

    v_String_Rec_to                 customer.String_Table := customer.String_Table ();
    v_String_Rec_cc                 customer.String_Table := customer.String_Table ();
    v_String_Rec_bcc                customer.String_Table := customer.String_Table ();
    v_EuroMsg_Mail_Attachment_Rec   customer.EuroMsg_Mail_Attachment_Table
        := customer.EuroMsg_Mail_Attachment_Table ();
    v_EuroMsg_Mail_Input_Rec        customer.EuroMsg_Mail_Input_Rec;
    v_Application_Name              VARCHAR2 (50) := NULL;
    v_subject                       VARCHAR2 (500) := NULL;
    v_Mail_Body                     VARCHAR2 (4000) := NULL;
    v_Response_Rec                  customer.EuroMsg_Mail_Response_Table
        := customer.EuroMsg_Mail_Response_Table ();
    p_process_results               customer.process_result_table;
    v_result                        NUMBER := 0;
    CURSOR c_1
    IS
          SELECT hc.statement_no,da.reference_code,da.int_id,e.part_id
            FROM Koc_Clm_Hlth_Comm   hc,
                 koc_clm_hlth_detail d,
                 web_sec_system_users su,
                 koc_cp_partners_ext e,
                 DMT_AGENTS da
           WHERE     1 = 1
                 AND hc.claim_id = d.claim_id
                 AND d.is_original = 0
                 AND d.comm_date > SYSDATE-41
                 AND d.comm_date < SYSDATE-10
                 AND (   hc.create_user = su.USER_NAME
                      OR hc.create_user = su.REFERENCE_OPUS_USER)
                 AND e.part_id=su.CUSTOMER_PARTNER_ID
                 AND da.INT_ID=e.agen_int_id
                 AND d.cpa_status IN ('TAH', 'OB', 'HT')
                 AND D.provision_date IS NULL
                 AND hc.statement_no NOT IN
                         (SELECT statement_no
                            FROM ALZ_HLTH_CPA_ORG_INV_MAILS
                           WHERE     (   mail_count > 3
                                      OR TRUNC (LAST_MAIL_DATE) >
                                             TRUNC (SYSDATE) - 10)
                                 AND statement_no = hc.statement_no)
        GROUP BY hc.statement_no,e.part_id,da.reference_code,da.int_id,e.part_id;

    v_statement_no                  VARCHAR2 (50) := NULL;
    v_email                         VARCHAR2 (500);
    v_mail_count                    NUMBER := 0;
BEGIN
    FOR rec IN c_1
    LOOP
        v_statement_no := rec.statement_no;

        BEGIN
            SELECT email
              INTO v_email
              FROM (SELECT c.explanation email
                      FROM KOC_CP_COMM_DEVICES c
                     WHERE     c.part_id = rec.part_id
                           AND c.COMM_DEV_TYPE = '0090'
                           AND c.explanation LIKE '%@%'
                    UNION
                    SELECT email
                      FROM koc_DMT_AGENTS_ext
                     WHERE int_id = rec.int_id)
             WHERE email IS NOT NULL and rownum=1;
        EXCEPTION
            WHEN OTHERS
            THEN
                CONTINUE;
        END;


        BEGIN
                SELECT mail_count
                  INTO v_mail_count
                  FROM CUSTOMER.ALZ_HLTH_CPA_ORG_INV_MAILS
                 WHERE statement_no = v_statement_no AND ROWNUM < 2;
            EXCEPTION
                WHEN OTHERS
                THEN
                    v_mail_count := NULL;
        END;

        IF v_mail_count = 3 then
            insert into ALZ_HLTH_CPA_AGEN_NC_RESTRICT (agency_code,
                                                       user_name,
                                                       close_date,
                                                       open_date,
                                                       create_user,
                                                       create_date,
                                                       update_user,
                                                       update_date)
                    VALUES (rec.reference_code,
                            '-',
                            SYSDATE,
                            null,
                            user,
                            SYSDATE,
                            user,
                            sysdate);

                    UPDATE CUSTOMER.ALZ_HLTH_CPA_ORG_INV_MAILS
                       SET mail_count = 4
                     WHERE statement_no = v_statement_no;
                    continue;
        end if;

        IF v_email IS NOT NULL
        THEN
            v_String_Rec_to := customer.String_Table ();
            v_String_Rec_cc := customer.String_Table ();
            v_String_Rec_bcc := customer.String_Table ();
            v_EuroMsg_Mail_Attachment_Rec :=
                customer.EuroMsg_Mail_Attachment_Table ();
            v_String_Rec_to.EXTEND;
            if nvl(p_testmail,'') = '' then
                v_String_Rec_to (v_String_Rec_to.COUNT) := String_Rec (v_email);
            else
                v_String_Rec_to (v_String_Rec_to.COUNT) :=
                String_Rec ('arzu.tosun@allianz.com.tr');
            end if;
            v_String_Rec_cc.EXTEND;
            v_String_Rec_cc (v_String_Rec_cc.COUNT) :=
                String_Rec ('arzu.tosun@allianz.com.tr');
            v_String_Rec_bcc.EXTEND;
            v_String_Rec_bcc (v_String_Rec_bcc.COUNT) := String_Rec ('');

            v_Subject := 'Hat�rlatma';
            v_Mail_Body :=
                   v_statement_no
                || ' icmal numaral� talebiniz i�in fatura asl� g�nderilmeyen kay�tlar bulunmaktad�r. As�llar 10 i� g�n� i�erisinde g�nerilmedi�i taktirde yeni kay�t yetkiniz kapat�lacakt�r.<br/><br/>';

            v_EuroMsg_Mail_Input_Rec :=
                customer.EuroMsg_Mail_Input_Rec (
                    v_EuroMsg_Mail_Attachment_Rec,
                    NULL,
                    NULL,
                    v_String_Rec_to,
                    v_String_Rec_cc,
                    v_String_Rec_bcc,
                    v_Subject,
                    v_Mail_Body,
                    v_Application_Name,
                    NULL,
                    '045',
                    ' ',
                    NULL);
            ALZ_EUROMSG_UTILS.Send_Mail (v_EuroMsg_Mail_Input_Rec,
                                         USER,
                                         v_Response_Rec,
                                         p_Process_Results);

            FOR Xt IN 1 .. V_Response_Rec.COUNT
            LOOP
                IF V_Response_Rec (Xt).Hata_Code = '200'
                THEN
                    v_result := 1;
                END IF;
            END LOOP;
        END IF;

        v_mail_count := NULL;

        IF v_result = 1
        THEN
            BEGIN
                SELECT mail_count
                  INTO v_mail_count
                  FROM CUSTOMER.ALZ_HLTH_CPA_ORG_INV_MAILS
                 WHERE statement_no = v_statement_no AND ROWNUM < 2;
            EXCEPTION
                WHEN OTHERS
                THEN
                    v_mail_count := NULL;
            END;

            IF v_mail_count IS NULL
            THEN
                INSERT
                  INTO CUSTOMER.ALZ_HLTH_CPA_ORG_INV_MAILS (statement_no,
                                                            last_mail_date,
                                                            mail_count,
                                                            email,
                                                            institute_code)
                VALUES (v_statement_no,
                        TRUNC (SYSDATE),
                        NVL (v_mail_count, 0) + 1,
                        v_email,
                        0);
            ELSE
                    UPDATE CUSTOMER.ALZ_HLTH_CPA_ORG_INV_MAILS
                       SET mail_count = NVL (v_mail_count, 0) + 1 , last_mail_date=trunc(sysdate)
                     WHERE statement_no = v_statement_no;
            END IF;

            COMMIT;
        END IF;
    END LOOP;
EXCEPTION
    WHEN OTHERS
    THEN
      ROLLBACK;
			Raise_Application_Error(-20110, 'informMailCPAInv:' || SQLERRM);
END informMailCPAInv;
END Alz_Clm_Hlth_Cron;
/
