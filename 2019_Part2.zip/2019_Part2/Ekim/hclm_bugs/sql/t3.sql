select log_id, note service_name, log_date, content log_content, TO_CHAR(insuredno) ext_reference, LOG_SOURCE 
                           from alz_hltprv_log a where TRUNC(log_date) =  trunc(sysdate-1)
                           -- and servicename='ALZ_HCLM_CONVERTER_UTILS' 
                            and log_id in(143592167,
143592171,
143669117,
143703667,
143735951,
143696235,
143592565,
143606103,
143592575,
143619886,
143707337,
143783766,
143783772,
143783782,
143783785,
143783843,
143695295
)

                          --and note='COMPUTE_REMAINING_REQUEST'
                           ORDER BY log_id
                           
                           select * from alz_hltprv_log where log_id
                           
                           select * from alz_hltprv_log where trunc(log_Date)=trunc(sysdate-1) and insurednotype='EXT_REFERENCE' and insuredno='59199649';
                           select * from alz_hltprv_log where log_Date>trunc(sysdate) and note='COMPUTE_REMAINING_REQUEST' order by log_date desc
                           select * from alz_hltprv_log where log_id = 143237123
                           
                           select * from koc_clm_hlth_indem_totals where contract_id=428579506 and partition_no=1 and cover_code='S176';
                           
                           koc_clm_hlth_trnx
--141997134;
                           
                           
                           SELECT * FROM koc_clm_suppliers_ext where institute_code=13
                           select * from clm_suppliers where supp_id=5135697
                           
                           --DELETE 
                           ALZ_HLTH_PROVISIONS_HIST WHERE CLAIM_ID=43013235 for update 
                           
                           select * from alz_hlth_proc_hist WHERE CLAIM_ID=43013235 for update
                           
                           
                           select * from koc_clm_medicine_indem_det where claim_id=43063544;
                           
                           select * from clm_subfiles where claim_id=43213436--ext_reference='58971711';
                           select * from alz_hclm_version_info where claim_id=43213436  for update--42566674;
                           select * from customer.alz_duplicate_provision where ext_reference='58625801';
                           
                           select * from koc_clm_suppliers_ext where institute_code=5104 for update;
                           select * from alz_hclm_institute_info where institute_code = 1464 for update;
                           
                           select * from koc_clm_hlth_detail where ext_reference='56318436';
                           
                           
SELECT * FROM CLM_POL_OAR o WHERE CONTRACT_ID=419037035 AND OAR_NO=996

AND EXISTS (SELECT 1 FROM KOC_CLM_HLTH_DETAIL WHERE claim_id=o.claim_id AND provision_Date > trunc(sysdate))

SELECT * FROM KOC_CLM_HLTH_DETAIL WHERE EXT_REFERENCE = '59101675'

SELECT * FROM KOC_CLM_HLTH_PROVISIONS WHERE CLAIM_ID=43180180;
SELECT * FROM KOC_CLM_HLTH_PROC_DETAIL WHERE CLAIM_ID=43180180;
                           
                         
                           select * from koc_clm_hlth_provisions where claim_id = 39547517
                           select * from alz_hltprv_log where trunc(log_date) = '02/07/2019' and insuredno='56318436';
                           select * from customer.alz_duplicate_provision where ext_reference='56318436';
                           select * from clm_pol_oar where claim_id = 39547517;
                           select * from clm_pol_oar where contract_id=411980850 and oar_no=343
                           select * from koc_clm_hlth_indem_totals@opusdev where contract_id=411980850 and partition_no=343 and claim_inst_type='AK' AND claim_inst_loc='YI' 
                           and cover_code IN('S511','S513','S504','S521','S512','S691','S510')
                           
                           select * from koc_ocp_risk_packages where contract_id=411980850 and partition_no=343;
                           
                           select * from koc_clm_hlth_provisions where claim_id in(      select claim_id from clm_pol_oar where contract_id=411980850 and oar_no=343)
                           and cover_code IN ('S511','S513','S504','S521','S512','S691','S510') order by entry_date;
                           
                           select * from hst_cc_web_inst_doctor;
                           
                           KOC_CLM_HLTH_BPM_UTILS
                            
                           SELECT LENGTH('Anla�mal� Doktor // Tan�mlanmam�� hematuri hematom // RIRS***yanl�zca tan�sal i�lem olmas� halinde teminat 3.600tl limitli %80''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''lidir') 
                           FROM DUAL
                           
                           
                           SELECT * FROM koc_clm_hlth_provisions where provision_total<0 and entry_date>TO_DATE('01/01/2016','DD/MM/YYYY');
                           
select * from clm_subfiles where claim_id in(
39547517,
39275665,
39531690,
39354311,
39439896)
