select * from alz_hltprv_log where log_id=59047100--141153131

select * from alz_hclm_version_info where hclm_channel='AZNET_REIMBURSEMENT' order by entry_date desc
select * from clm_subfiles where claim_id=43304814--43309973;
select * from koc_clm_hlth_detail where ext_reference='58971711'--'59047100'
select * from KOC_CLM_MEDICINE_INDEM_DET where claim_id=43001895;
select * from alz_hclm_version_info where claim_id=42968748--43103004--43110973

Koc_Clm_Hlth_Trnx.Delete_Provisions
select * from alz_hltprv_log where log_id=141849013
select * from alz_hltprv_log where  log_date>trunc(sysdate) and servicename='ALZ_HCLM_CONVERTER_UTILS' and note='UPDATE_PROVISION_REQUEST' and insurednotype='EXT_REFERENCE' and insuredno='59069124'
