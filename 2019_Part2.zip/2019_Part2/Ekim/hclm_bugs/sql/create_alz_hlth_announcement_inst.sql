-- Create table
create table CUSTOMER.ALZ_HLTH_ANNOUNCEMENT_INST
(
  announcement_no        NUMBER(10) not null,
  payment_group_code     VARCHAR2(4) not null,
  institute_code         NUMBER(10) not null,
  validity_start_date    DATE not null,
  validity_end_date      DATE,
  inst_aggreement_status VARCHAR2(1),
  sgk_aggreement_type    VARCHAR2(1),
  hospital_type          VARCHAR2(2000),
  institute_group_code   VARCHAR2(2000)
)
tablespace AZS_DATA_TS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
-- Grant/Revoke object privileges 
grant select, insert, update, delete on CUSTOMER.ALZ_HLTH_ANNOUNCEMENT_INST to DEVELOPER_USER;
grant select, insert, update, delete on CUSTOMER.ALZ_HLTH_ANNOUNCEMENT_INST to READ_ROLE;
