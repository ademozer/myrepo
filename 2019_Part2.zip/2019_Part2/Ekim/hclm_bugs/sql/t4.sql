select * from koc_clm_hlth_indem_totals where contract_id=515683285 and partition_no=2039 and cover_code='S521';

ALZ_HCLM_CONVERTER_UTILS;
KOC_CLM_HLTH_TRNX;
KOC_CLM_HLTH_HOSPT_UTILS;
KOC_CLM_HLTH_BPM_UTILS;
KOC_HELPDESK;
select * from all_objects where object_name like '%FILENET%';
select * from all_source where lower(text) like '%filenet%'
ALZ_FILENET_UTILS;
ALZ_MDLR_HLTH_FILENET_UTILS
select * from ALZ_HLTH_FILENET_JMS_LOG;
ALZ_HLTH_DOC_UTILS;
ALZ_COMMON_FILENET_UTILS;
ALZ_CLM_DMS_UTILS;
ALZ_MODCORP_UW_UTILS;
ALZ_HLTH_KARMA_UTILS
