select * from alz_hltprv_log a where log_date>trunc(sysdate) and servicename='ALZ_HCLM_CONVERTER_UTILS' and note='UPDATE_PROVISION_REQUEST' and institutecode!=13
and exists(select 1 from alz_hltprv_log b where b.log_date>trunc(sysdate) and servicename='ALZ_HCLM_CONVERTER_UTILS' and note='UPDATE_PROVISION_EXCEPTION' and a.log_id = b. log_id) 
