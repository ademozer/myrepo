select * from alz_hclm_institute_info where institute_code=1874 for update;

select * from koc_cp_health_look_up where look_up_code='HCLM_USAGE' for update

select * from alz_hltprv_log where  log_date>trunc(sysdate) order by log_date desc; --140972061, 140972063
8988555 kart noda
46161600
provizyon

select * from alz_hltprv_log where log_id=140972061, --140972063 [save_prescription_log], --46161600 [ext_ref]

select * from koc_clm_hlth_detail where ext_reference='46161599'
SELECT ALZ_HCLM_CONVERTER_UTILS.getHclmUsage(null, null, null, null, null, null) from dual;

select * from alz_hltprv_log where log_id=140705028--140705119--140705066 --140705028;
select * from alz_hclm_version_info where trunc(entry_date) = TO_DATE('04/10/2019','DD/MM/YYYY') and version_no=1 and HCLM_CHANNEL='AZNET_REIMBURSEMENT' order by entry_date

select * from alz_hltprv_log where log_id=143415093;

alz_hclm_version_info

select * from koc_clm_web_auth_pool where claim_id=42923254 for update

    SELECT parameter
      FROM KOC_CP_HEALTH_LOOK_UP
     WHERE LOOK_UP_CODE = 'ICM_BRE';       
     
     ECZ0115001
     
     SELECT KOC_CLM_HLTH_PHARMACY_UTILS.Getuserinstitutecode ('ECZ0115001', SYSDATE) FROM DUAL  ;
     
     
     SELECT * FROM ALZ_HLTH_CPA_NW_USER WHERE IS_QUIT=1;
     
     select null kod,'Hepsi' aciklama 
  from dual
union all
select '0' kod,hlth_its_utils.get_its_status_exp(0) aciklama 
  from dual
union all
select '1' kod,hlth_its_utils.get_its_status_exp(1) aciklama 
  from dual
union all  
select '2' kod,hlth_its_utils.get_its_status_exp(2) aciklama 
  from dual
union all
select '3' kod,hlth_its_utils.get_its_status_exp(3) aciklama 
  from dual
union all
select '4' kod,hlth_its_utils.get_its_status_exp(4) aciklama 
  from dual
union all
select '5' kod,hlth_its_utils.get_its_status_exp(5) aciklama 
  from dual
     
     
     
     
    -- Hlth_Its_Utils       
  KOC_CLM_HLTH_PHARMACY_UTILS;
  ALZ_HCLM_CONVERTER_UTILS;
  
  select * from clm_subfiles where claim_id=43011661
  
  select * from koc_clm_hlth_detail where ext_reference='59002712'--'58937576'

  select * from alz_hclm_version_info where claim_id=43112073--42968748 for update
  select * from alz_hltprv_log where log_id=141581089;
  
  select * from koc_clm_hlth_reject_loss where claim_id=43112073
  
  KOC_CLM_HLTH_HOSPT_UTILS.Isprocessgroupvalue;
  
select * from 

SELECT GET_URL_LINK('http://esb.allianz.com.tr:12000/eProvision/ProxyServices/EProvisionUserOperations') FROM DUAL
