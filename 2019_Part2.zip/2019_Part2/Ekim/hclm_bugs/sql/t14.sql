select * from alz_hclm_institute_info where hclm_usage=1 and institute_code not in(28,6411,553)
