ALZ_HEALTH_INFORMER_UTILS;
select * from koc_clm_hlth_detail where ext_reference='58671388'
SELECT kcc.*
  FROM customer.koc_cp_comm_devices kcc
 WHERE     kcc.part_id = 6303136
       AND kcc.comm_dev_type = '0090'
       AND kcc.validity_end_date IS NULL
       AND kcc.explanation IS NOT NULL
       AND kcc.explanation LIKE '%hulyadikmen@hotmail.com%';
       
       CUSTOMER.WEB_CLM_HLTH_HOSPT_UTILS.GETPOLICYCOVERS
                                   
                                   
                                   
