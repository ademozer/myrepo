SELECT a.*
        FROM Koc_Clm_Hlth_Indem_Totals a
       WHERE a.Claim_Inst_Type = 'AK'
         AND a.Claim_Inst_Loc = 'YI'
         AND a.Country_Group = '0'            
         AND a.Contract_Id = 490901387
         AND a.Partition_No = 50
         AND Nvl(a.Is_Valid, 0) = 1
         --AND a.Validity_Start_Date <= v_Indem_Query_Date
        -- AND Nvl(a.Validity_End_Date, v_Indem_Query_Date) >=
         --   v_Indem_Query_Date
       --  AND ((p_Cover_Code IS NOT NULL AND a.Cover_Code = p_Cover_Code) OR
         --    (p_Cover_Code IS NULL AND
         AND    a.Cover_Code IN
            (SELECT a.Cover_Code
                  FROM Koc_Oc_Cover_Definitions  a,
                       Koc_Cc_Hlth_Web_Cover_Grp b
                 WHERE a.Web_Cover_Grp_Code = b.Web_Cover_Grp_Code
                   AND Nvl(b.Is_Auth_Web_Cover_Group, 0) = 1)--))
        /* AND (a.User_Group IS NULL OR 1 = 1 OR EXISTS
              (SELECT 'x'
                 FROM Koc_Oc_Hlth_User_Grp_Rel
                WHERE User_Group = a.User_Group
                  AND User_Type = v_User_Type))*/
         AND (Nvl(a.Paid_Premium_Percentage, 0) = 0 OR
             Koc_Acc_Health_Utils.Calculate_Collection_Percent(a.Contract_Id) >=
             a.Paid_Premium_Percentage)
        -- AND (p_Cover_Code IS NULL OR a.Cover_Code = p_Cover_Code)
         AND a.Cover_Code NOT IN ('S660', 'S685')
       ORDER BY Parent_Cover_Code,
                Decode(Parent_Cover_Code, a.Cover_Code, 1, 2),
                Priority_Level_For_Claim;
                
                
                
                SELECT a.Cover_Code
                  FROM Koc_Oc_Cover_Definitions  a,
                       Koc_Cc_Hlth_Web_Cover_Grp b
                 WHERE a.Web_Cover_Grp_Code = b.Web_Cover_Grp_Code
                   AND Nvl(b.Is_Auth_Web_Cover_Group, 0) = 1
                  
                 INSERT INTO Koc_Cc_Hlth_Web_Cover_Grp
                 SELECT * FROM Koc_Cc_Hlth_Web_Cover_rel WHERE WEB_COVER_GRP_CODE='S849' FOR UPDATE
                 
                 select * from koc_clm_suppliers_ext where institute_code=3049 for update
                 INSERT INTO Koc_Cc_Hlth_Web_Cover_Grp              
       SELECT 'S849' Web_Cover_Grp_Code, (SYSDATE-1) VALIDITY_START_DATE, EXPLANATION, VALIDITY_END_DATE, IS_AUTH_WEB_COVER_GROUP, IS_AUTH_WEB_POS, WEB_POS_FOOTNOTE, INSTITUTE_TYPE    
         FROM Koc_Cc_Hlth_Web_Cover_Grp where Web_Cover_Grp_Code = 'S691'
/ 

INSERT INTO Koc_Cc_Hlth_Web_Cover_Rel
       SELECT 'S849' Web_Cover_Grp_Code, Order_No, Group_Code, Hospital_Type, Institute_Code, Institute_Type, (SYSDATE-1) VALIDITY_START_DATE, VALIDITY_END_DATE
       FROM Koc_Cc_Hlth_Web_Cover_Rel
       WHERE Web_Cover_Grp_Code = 'S691';
       
       koc_clm_hlth_utils;
       
       
        SELECT x.Network_Id
        FROM Koc_Ocp_Risk_Packages x
       WHERE x.Contract_Id = 490901387
         AND x.Partition_No = 50
         --AND x.Action_Code <> 'D'  -- orderlamak daha do�ru olacak.
         AND x.Version_No = (SELECT MAX(Version_No)
                               FROM Koc_Ocp_Partitions_Ext
                              WHERE Contract_Id = x.Contract_Id
                                AND Partition_No = x.Partition_No
                                AND Business_Start_Date <= SYSDATE)
       ORDER BY (CASE
                  WHEN x.Action_Code <> 'D' THEN
                   0
                  ELSE
                   99
                END) DESC;
                
select * from koc_mv_skrm_suppliers where claim_inst_type='AK' and exp_date is null and institute_type not in(2,3) and
institute_code not in (               
     SELECT r.institute_code
    --  INTO l_Result
      FROM Koc_Oc_Network_Inst_Rel r
     WHERE 1 = 1
       --AND p_Date BETWEEN Nvl(r.Validity_Start_Date, SYSDATE - 1) AND
     --      Nvl(r.Validity_End_Date, SYSDATE + 1)
       --AND r.Institute_Code = p_Institute_Code
       AND r.network_id = 35
      -- AND r.institute_code = 6060
       --AND r.Network_Id = Nvl(l_Network_Id, r.Network_Id)
       );
