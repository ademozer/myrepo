DECLARE 
  PROCEDURE Pr_Cancel_Suspense IS

    v_Date DATE := TO_DATE('21/10/2019','DD/MM/YYYY');--Trunc(SYSDATE);
    CURSOR c_Suspense IS
      SELECT d.Claim_Id,
             d.Sf_No,
             d.Add_Order_No,
             d.Institute_Code
        FROM Koc_Clm_Hlth_Detail d
       WHERE Nvl(d.Is_Suspense, 0) = 1
         AND d.Suspense_Date = v_Date
        -- AND ext_reference='56896909'
         AND Nvl(d.Status_Code, 'PP') IN ('P', 'I', 'KI', 'MI')
         And d.Discharge_Date Is Null;

    c_Sus        c_Suspense%ROWTYPE;
    v_Err_Sq     NUMBER;
    v_Err_Msg    VARCHAR2(5000);
    v_Cancel_Exp VARCHAR2(5000) := '�lgili provizyon i�in �n onay ge�erlilik s�resi doldu�undan provizyon iptal edilmi�tir.';

    PROCEDURE Delete_Provisions(p_Del_Or_Rej   NUMBER,
                                p_Cancel_Exp   VARCHAR2,
                                p_Claim_Id     Koc_Clm_Hlth_Detail.Claim_Id%TYPE,
                                p_Sf_No        Koc_Clm_Hlth_Detail.Sf_No%TYPE,
                                p_Add_Order_No Koc_Clm_Hlth_Detail.Add_Order_No%TYPE) IS
      Clmdetail Koc_Clm_Hlth_Trnx.Clmdetailtype;

      v_User_Id      VARCHAR2(30) := 'OTOIPT';
      v_Contract_Id  NUMBER;
      v_Partition_No NUMBER;
      j              NUMBER;
      i              NUMBER;
      v_Reject       NUMBER;
      Startreq       Customer.Web_Provision.Startazprovision_Req;
      Startres       Customer.Web_Provision.Startazprovision_Res;
      Providereq     Customer.Web_Provision.Provideprovision_Req;
      Provideres     Customer.Web_Provision.Provideprovision_Res;
      v_Msg_Level    NUMBER;

      CURSOR c_Data(Pp_Claim_Id NUMBER,
                    Pp_Sf_No    NUMBER) IS
        SELECT x.Claim_Id,
               x.Institute_Code,
               x.Part_Id,
               x.Provision_Date,
               x.Package_Id,
               x.Group_Code,
               x.Status_Code,
               y.Policy_Ref,
               y.Product_Id,
               y.Contract_Id,
               y.Agent_Role
          FROM Koc_Clm_Hlth_Detail x,
               Clm_Pol_Bases       y
         WHERE x.Claim_Id = Pp_Claim_Id
           AND x.Sf_No = Pp_Sf_No
           AND x.Claim_Id = y.Claim_Id;

      Rec_Data c_Data%ROWTYPE;

      CURSOR c_Partition_Type(Pp_Contract_Id NUMBER) IS
        SELECT Partition_Type FROM Ocp_Partitions WHERE Contract_Id = Pp_Contract_Id;

      v_Partition_Type Ocp_Partitions.Partition_Type%TYPE;

      CURSOR c_Location_Code(Pp_Claim_Id NUMBER,
                             Pp_Sf_No    NUMBER) IS
        SELECT Location_Code
          FROM Koc_Clm_Hlth_Provisions
         WHERE Claim_Id = Pp_Claim_Id
           AND Sf_No = Pp_Sf_No;

      v_Location_Code Koc_Clm_Hlth_Provisions.Location_Code%TYPE;

      v_Clm_Check NUMBER := 0;
      v_Error_Exp VARCHAR2(500);

    BEGIN

      SELECT Contract_Id,
             Oar_No
        INTO v_Contract_Id,
             v_Partition_No
        FROM Clm_Pol_Oar c
       WHERE c.Claim_Id = p_Claim_Id;

      Koc_Pk_Hlth_Provision.Getdetaildata_Trnx(p_Claim_Id, p_Sf_No, p_Add_Order_No, Clmdetail);
      
      IF ALZ_HCLM_CONVERTER_UTILS.getHclmUsage(null, p_Claim_Id, null, null, 'OTOMATIK_MUALLAK_IPTALI','CONTROL_M_JOB') = 1 THEN
          DBMS_OUTPUT.PUT_LINE('HCLM');
          ALZ_HCLM_CONVERTER_UTILS.setChannel('CENTRAL_PROVISION');
          ALZ_HCLM_CONVERTER_UTILS.cancelProvision(v_Contract_Id, 
                                                   v_Partition_No,
                                                   COALESCE(Clmdetail(1).Medula_Date, Clmdetail(1).Provision_Date),
                                                   v_User_Id,
                                                   Clmdetail,
                                                   v_Cancel_Exp);                                                                                                                                                         
      ELSE
          DBMS_OUTPUT.PUT_LINE('ESKI');
        Koc_Clm_Hlth_Trnx.Delete_Provisions(v_Contract_Id, v_Partition_No, Clmdetail(1).Provision_Date, NULL, NULL, v_User_Id, p_Del_Or_Rej, Clmdetail,
                                            v_Cancel_Exp);

        Koc_Clm_Hlth_Hospt_Utils.Resetsyt0(Clmdetail(1).Claim_Id, Clmdetail(1).Sf_No);
        Koc_Clm_Hlth_Trnx.Is_Hlth_Clm_Check(Clmdetail(1).Claim_Id, Clmdetail(1).Sf_No, 1, v_Clm_Check, v_Error_Exp);

        IF v_Clm_Check <> 1
        THEN
          IF p_Del_Or_Rej IN (1, 2)
          THEN
            BEGIN
              UPDATE Koc_Clm_Hlth_Incomp_Papers
                 SET Status_Code = 'C'
               WHERE Claim_Id = Clmdetail(1).Claim_Id
                 AND Status_Code = 'A';
            EXCEPTION
              WHEN OTHERS THEN
                NULL;
            END;
          END IF;
          --\\

          Koc_Clm_Hlth_Trnx.Datacommit;
                  
          OPEN c_Data(Clmdetail(1).Claim_Id, Clmdetail(1).Sf_No);
          FETCH c_Data
            INTO Rec_Data;
          CLOSE c_Data;

          OPEN c_Partition_Type(Rec_Data.Contract_Id);
          FETCH c_Partition_Type
            INTO v_Partition_Type;
          CLOSE c_Partition_Type;

          IF Nvl(Clmdetail(1).Status_Code, 'X') IN ('PP', 'CP')
          THEN

            SELECT r.Instance_Id
              INTO Providereq.Instance_Id
              FROM Koc_Clm_Web_Auth_Pool r
             WHERE Claim_Id = p_Claim_Id
               AND Status_Code <> 'C'
               AND Rownum < 2;

            Providereq.User_Name   := v_User_Id;
            Providereq.Status_Code := Rec_Data.Status_Code;
            BEGIN
              Provideres := Customer.Web_Provision.Provideprovision(Providereq);

            EXCEPTION
              WHEN OTHERS THEN
                Web_Clm_Hlth_Hospt_Utils.Koc_Bpm_Project_Log_Write(SYSDATE, 'WEB PROVISON', 'KOCCLM300', 'delete_provison', Clmdetail(1).Claim_Id,
                                                                   v_User_Id, 'customer.web_provision.provideProvision', SQLERRM);
            END;

          ELSE
            OPEN c_Location_Code(Clmdetail(1).Claim_Id, Clmdetail(1).Sf_No);
            FETCH c_Location_Code
              INTO v_Location_Code;
            CLOSE c_Location_Code;

            Startreq.User_Name      := v_User_Id;
            Startreq.Claim_Id       := Clmdetail(1).Claim_Id;
            Startreq.Institute_Code := Rec_Data.Institute_Code;
            Startreq.Location_Code  := v_Location_Code;
            Startreq.Part_Id        := Rec_Data.Part_Id;
            Startreq.Unit_Id        := Koc_Clm_Hlth_Bpm_Utils.Gettounitinfobyinstitutecode(Rec_Data.Institute_Code, Rec_Data.Provision_Date);
            Startreq.Package_Id     := Rec_Data.Package_Id;
            Startreq.Product_Id     := Nvl(Rec_Data.Product_Id, 0);
            Startreq.Partition_Type := v_Partition_Type;
            Startreq.Group_Code     := Rec_Data.Group_Code;
            Startreq.Policy_Ref     := Rec_Data.Policy_Ref;
            Startreq.Agency_Code    := Koc_Clm_Hlth_Utils.Getacencycode(Rec_Data.Agent_Role, Rec_Data.Provision_Date);
            Startreq.Provision_Type := Koc_Clm_Hlth_Bpm_Utils.Getuserroletype(v_User_Id);
            IF Nvl(Rec_Data.Status_Code, 'PP') = 'PP'
            THEN
              Startreq.Processtype := 'false';
            ELSE
              Startreq.Processtype := 'true';
            END IF;
            Startreq.Status_Code := Rec_Data.Status_Code;
            ----------------------------
            BEGIN
              Startres := Customer.Web_Provision.Startazprovision(Startreq);
            EXCEPTION
              WHEN OTHERS THEN
                Web_Clm_Hlth_Hospt_Utils.Koc_Bpm_Project_Log_Write(SYSDATE, 'WEB PROVISON', 'KOCCLM300', 'delete_provison', Clmdetail(1).Claim_Id,
                                                                   v_User_Id, 'customer.web_provision.startAZProvision', SQLERRM);
            END;

          END IF;
        END IF;
    END IF;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END Delete_Provisions;

  BEGIN
    v_Err_Sq := Koc_Hlth_Clm_Transfer.Geterrseq;

    OPEN c_Suspense;
    LOOP
      FETCH c_Suspense
        INTO c_Sus;
      EXIT WHEN c_Suspense%NOTFOUND;

      BEGIN
        --
        Delete_Provisions(1, 'Otomatik Muallak Dosya �ptali', c_Sus.Claim_Id, c_Sus.Sf_No, c_Sus.Add_Order_No);
           DBMS_OUTPUT.PUT_LINE( 'success');
        COMMIT;
        --
      EXCEPTION
        WHEN OTHERS THEN
         
          v_Err_Msg := SQLERRM;
          v_Err_Msg := Substr(v_Err_Msg, 1, 500);
          ROLLBACK;
             DBMS_OUTPUT.PUT_LINE( 'Hata:'||v_Err_Msg);
          INSERT INTO Tmp_Koc_Errors
            (Reference_Code, Process, Error, Process_Date, Script_Name, Sira, Online_Sq_No)
          VALUES
            (c_Sus.Claim_Id, 'SUSPENSE', v_Err_Msg, SYSDATE, 'SUSPENSE', NULL, v_Err_Sq);
          COMMIT;
      END;
    END LOOP;
  END Pr_Cancel_Suspense;
  
  BEGIN
    Pr_Cancel_Suspense;
  
  END;
  
  
