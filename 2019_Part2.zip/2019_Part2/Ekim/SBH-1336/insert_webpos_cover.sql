INSERT INTO Koc_Cc_Hlth_Web_Cover_Grp              
       SELECT 'ST838' Web_Cover_Grp_Code, (SYSDATE-1) VALIDITY_START_DATE, EXPLANATION, VALIDITY_END_DATE, IS_AUTH_WEB_COVER_GROUP, IS_AUTH_WEB_POS, WEB_POS_FOOTNOTE, INSTITUTE_TYPE    
         FROM Koc_Cc_Hlth_Web_Cover_Grp where Web_Cover_Grp_Code = 'S814'
/ 
INSERT INTO Koc_Cc_Hlth_Web_Cover_Rel
       SELECT 'ST838' Web_Cover_Grp_Code, Order_No, Group_Code, Hospital_Type, Institute_Code, Institute_Type, (SYSDATE-1) VALIDITY_START_DATE, VALIDITY_END_DATE
       FROM Koc_Cc_Hlth_Web_Cover_Rel
       WHERE Web_Cover_Grp_Code = 'S814'
/
COMMIT
/
       
