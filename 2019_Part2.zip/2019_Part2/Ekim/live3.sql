select * from alz_hltprv_log where log_id=139756737--140339765;

SELECT * FROM ALZ_HCLM_VERSION_INFO WHERE CLAIM_ID=42888792

SELECT * FROM CUSTOMER.ALZ_DUPLICATE_PROVISION WHERE EXT_REFERENCE='58876031';

SELECT * FROM koc_clm_hlth_detail where status_code='KI' and claim_id in(select claim_id from alz_hclm_version_info)
