--alz_hlth_cpa.getPool


select a.*
from alz_hclm_version_info a where  NVL(a.HCLM_CHANNEL,'X') = 'AZNET_REIMBURSEMENT' 
and a.version_no=1 and a.entry_date > TO_DATE('05/09/2019 01:00:00', 'DD/MM/YYYY HH24:MI:SS')  
and exists(select 1 from koc_clm_hlth_detail d where d.claim_id=a.claim_id and d.status_code NOT IN('R','C'))
order by a.entry_date desc;

select * from clm_subfiles where claim_id=43075563;

select * from koc_clm_vacc_indem_totals where claim_id=43075563 
and barcode in (select barcode from koc_cc_medicine_cover_rel where cover_code = 'S512')

select * from koc_clm_hlth_reject_loss where claim_id=43075563
select * from koc_clm_medicine_indem_det where seq_no is null--claim_id=43075563

select * from koc_cc_medicine_cover_rel where barcode in(8699572969147, 8699625960138);

select * from alz_hltprv_log where log_date > trunc(sysdate) and insurednotype='EXT_REFERENCE' and insuredno='59020412'
