select * from all_errors where owner='CUSTOMER' and name='ALZ_CLM_HLTH_CRON';

KOC_CLM_HLTH_TRNX;

select * from alz_tpa_message_definitions where message_name IN('TSS_PROVISION_AUTH_SMS_MESSAGE','TSS_PROVISION_REJECT_SMS_MESSAGE') 
select * from alz_tpa_companies;
select * from alz_tpa_parameters where parameter_type='CALL_CENTER_PHONE'
SELECT ALZ_TPA_CORE_UTILS.f_get_param_value ('045'
                              , 0
                              , 0
                              , 0
                              , 'CALL_CENTER_PHONE'
                              , USER
                              , SYSDATE
                              , 0) FROM DUAL

--Alz_Tpa_Claim_Utils.Get_Alz_Message

select * from dba_tab_privs where table_name='ALZ_HLTH_ANNOUNCEMENT';
