DECLARE
   v_request CLOB;
   v_response CLOB;
   v_url      VARCHAR2(1000) := -- 'http://10.70.47.85:19101/hclm-health-claim-service/api/v1/provision/updateProvision';--
                                get_url_link('http://esb.allianz.com.tr:12000/hclm-health-claim-service/api/v1/provision/updateProvision');
   v_status   NUMBER := 0;
   v_message  VARCHAR2(1000);
   
   procedure callRestService(p_Url               In          Varchar2,
                              p_Method            In          Varchar2,
                              p_Request           In          Clob,
                              p_Response          Out         Clob,
                              p_Status            Out         Number,
                              p_Message           Out         Varchar2) IS

        v_Req               utl_http.req;
        v_Req_Length        Number;
        v_Res               utl_http.resp;
        v_Buffer            Varchar2(32767);
        v_Offset            Number := 1;
        v_Amount            Number :=32767;
        v_Utl_Err           Varchar2(1000);
        v_value             varchar2(32767);
        hata_code           varchar2(10);
        v_output            varchar2(10);
        v_Response          CLOB;
        v_Line_Number       NUMBER := 0;

        Begin

            v_Req_Length := dbms_lob.getlength(p_Request);
            v_Req := utl_http.begin_request(p_Url, p_Method, 'HTTP/1.1');
            utl_http.set_header(v_Req, 'Content-Length', v_Req_Length);
            utl_http.set_header(v_Req, 'Content-Type', 'application/json;charset=UTF-8');
            utl_http.set_header(v_Req, 'Transfer-Encoding', 'chunked' );
            utl_http.set_header(v_Req, 'Hclm-Channel', 'CENTRAL_PROVISION' );
            utl_http.set_transfer_timeout(300);
            utl_http.set_body_charset(v_Req,'UTF-8');

            While (v_Offset < v_Req_Length)
            Loop
               dbms_lob.read(p_Request, v_Amount, v_Offset, v_Buffer);
               utl_http.write_text(r    => v_Req, data => v_Buffer);
               v_Offset := v_Offset + v_Amount;
            End Loop;

            v_Res := utl_http.get_response(v_Req);
            p_status := 0;
            p_message := v_Res.status_code || ':' || v_Res.reason_phrase;
            IF v_Res.status_code != 200  THEN
                p_Status := 1;
            END IF;
            DBMS_OUTPUT.PUT_LINE('1');
            Begin
               loop
                  DBMS_OUTPUT.PUT_LINE('1.a');
                  utl_http.read_line(v_Res, v_value);
                  DBMS_OUTPUT.PUT_LINE('1.b');
                  DBMS_OUTPUT.PUT_LINE(v_value);
                  v_value := TRIM(regexp_replace(v_value, '([^[:graph:] | ^[:blank:]])', ''));
                  DBMS_OUTPUT.PUT_LINE('1.c');
                  v_Response := v_Response || v_value;
                  DBMS_OUTPUT.PUT_LINE('1.d');
               end loop;
                   DBMS_OUTPUT.PUT_LINE('2');
               utl_http.end_response(v_Res);
            Exception
            When utl_http.end_of_body Then
                DBMS_OUTPUT.PUT_LINE('2.a');
                 utl_http.end_response(v_Res);
            When utl_http.too_many_requests Then
                   DBMS_OUTPUT.PUT_LINE('2.b');
                 utl_http.end_response(v_Res);
            When Others Then
                    DBMS_OUTPUT.PUT_LINE('2.c:'||SQLERRM);
                 utl_http.end_response(v_Res);
           End;
            DBMS_OUTPUT.PUT_LINE('3');
           p_Response := TRIM(v_Response);
           IF INSTR(p_Response,'"errors"')>0 THEN
               p_Status := 1;
               p_message := 'Business Exception';
           END IF;
        EXCEPTION
           WHEN OTHERS THEN
              DBMS_OUTPUT.PUT_LINE('parse error');
              utl_http.end_response(v_Res);
              v_utl_err:= Utl_Http.Get_Detailed_Sqlerrm;
              p_Status := 1;
              p_Response := '';
              p_Message := v_utl_err||' - '||p_url;
    END callRestService;
BEGIN
  v_request := '{              "contractId" : "485359680",              "instituteCode" : "2635",              "partitionNo" : "5580",              "realizationDate" : "2019-10-15T00:00:00.000+03:00",              "logId" : "142291160",              "claimDetailDto" : {"extReference" : "59059502",              "claimId" : "43127374",              "addOrderNo" : "1",              "sfNo" : "1",              "ahek" : "false",              "automated" : "false",              "beforeComplaintIllness" : "",              "breResultCode" : "",              "claimInstLoc" : "YI",              "claimInstType" : "AK",              "claimStatusType" : "H",              "classDisease1" : "10099",              "classDisease2" : "",              "classDisease3" : "",              "closeDate" : "",              "commDate" : "2019-10-11T13:47:18.000+03:00",              "communicationExp1" : "",              "communicationExp2" : "",              "communicationNo" : "2019428169",              "communicationNumber1" : "",              "communicationNumber2" : "",              "complaintStart" : "",              "complementary" : "false",              "consultationDiagnosis" : "",              "contractMessage" : "",              "countryCode" : "",              "cpaStatus" : "HT",              "dateOfLoss" : "2019-10-08T00:00:00.000+03:00",              "deductionRate" : "",              "dhInst" : "",              "dischargeDate" : "2019-10-08T00:00:00.000+03:00",              "doctorCode" : "",              "doctorStatus" : "",              "doctorType" : "",              "drDiplomaNo" : "",              "drNameLastname" : "",              "eprescriptionNo" : "",              "exGratia" : "true",              "exGratiaFee" : "333.25",              "examDate" : "",              "examinationsResults" : "",              "explanation" : "limit a��m tutar� ex-gratia �dendi. Onay mailleri ekte",              "extDoctor" : "false",              "extDoctorAmt" : "",              "finalClassDisease1" : "",              "finalClassDisease2" : "",              "finalClassDisease3" : "",              "fromCityCode" : "",              "fromDistrictCode" : "",              "fromToPlace" : "",              "groupCode" : "S6880",              "hasUnreadableDoc" : "0",              "hlthSrvPay" : "",              "hospitalAmt" : "",              "hospitalRefNo" : "",              "hospitalizeApprFormExpl1" : "",              "hospitalizeApprFormExpl2" : "",              "hospitalizeDate" : "2019-10-08T00:00:00.000+03:00",              "identitiyType" : "",              "identityNo" : "",              "identityNumber" : "",              "instGlnCode" : "",              "instTaxNumber" : "",              "instTaxOffice" : "",              "instituteCode" : "2635",              "invoiceDate" : "2019-10-08T00:00:00.000+03:00",              "invoiceExplanation" : "",              "invoiceNo" : "179671",              "invoiceTotal" : "332.25",              "judicial" : "false",              "lastMenstDate" : "",              "medicalBackground" : "",              "medulaDate" : "",              "nationality" : "",              "ok" : "true",              "onlyExaminationFee" : "false",              "origClaimInstLoc" : "YI",              "origClaimInstType" : "AK",              "original" : "false",              "otherCountry" : "",              "otherCountryCity" : "",              "packageDate" : "",              "packageId" : "",              "partId" : "6208867",              "patientAdmittanceDate" : "",              "patientComplaint" : "",              "patientVisitMade" : "false",              "paymentTotal" : "",              "personalNotes" : "",              "plannedTreatmentProc" : "",              "possDischargeDate" : "",              "possHospitalizeDate" : "",              "prediagnosisDiagnosis" : "",              "pregnant" : "false",              "prescriptionDate" : "",              "prescriptionNo" : "",              "prescriptionType" : "",              "processDate" : "2019-10-15T14:14:54.000+03:00",              "provisionFeeChargeDate" : "",              "provisionDate" : "",              "provisionUserId" : "WKGURLU",              "provDemandDate" : "",              "processExp" : "",              "sgkRefNo" : "",              "socSecInstApp" : "",              "shippingDate" : "",              "shippingNo" : "",              "realizationDate" : "",              "relClaimId" : "",              "sgkTotal" : "",              "referralInstituteName" : "",              "requestAmount" : "",              "requestSystem" : "MUHABERAT",              "sgkUsed" : "false",              "referral" : "false",              "suspense" : "false",              "suspenseDate" : "",              "specialtySubject" : "1320",              "statusCode" : "H",              "swiftCode" : "TL",              "toCityCode" : "",              "toDistrictCode" : "",              "timeStamp" : "",              "surgeryDate" : "",              "visitingReason" : "0",              "urgentCure" : "false",              "wrongProvision" : "false",              "web" : "false",              "webLocationCode" : "",              "ytType" : "",              "updateLimit" : "true",              "versionNo" : "1",              "previousStatusCode" : "",              "denySms":"false",                  "itemList" : [],                  "medicineList" : [],                  "processList": [],                  "provisionList": [{                "daySeance" : "0",                "exemptionAmount" : "0",                "entryDate" : "",                "countryCode" : "",                "exemptionRate" : "",                "addOrderNo" : "1",                "addProcAmount" : "",                "doctorCode" : "",                "doctorStatus" : "",                "breResultCode" : "",                "coverDistributionAmount" : "",                "claimId" : "43127374",                "coverCode" : "S501",                "isExGratia" : "",                "isPoolCover" : "0",                "isSpecialCover" : "0",                "procRequestAmount" : "0",                "procRefusalAmount" : "0",                "instExemptionAmount" : "0",                "instRequestAmount" : "332.25",                "provDateTime" : "",                "orderNo" : "",                "instAddProcAmount" : "",                "locationCode" : "920",                "provisionTotal" : "332.25",                "provisionExplanation" : "",                "requestAmount" : "332.25",                "refusalAmount" : "0",                "swiftCode" : "TL",                "reqCureDayCount" : "1",                "statusCode" : "",                "userId" : "ENURAY",                "sysRequestAmount" : "0",                "sgkAmount" : "",                "timeStamp" : "",                "subPackageId" : "",                "subPackageDate" : "",                "sfNo" : "1"              }],                  "rejectLossList": [],                  "vaccineList" : []               },               "userDto" : {                  "userId" : "ENURAY",                  "userName" : "ENURAY"               }          }';
  
  --ALZ_HCLM_CONVERTER_UTILS.
  callRestService(v_url, 'POST', v_request, v_response, v_status, v_message);
  
  DBMS_OUTPUT.PUT_LINE(v_message);
  DBMS_OUTPUT.PUT_LINE(v_response);
 END;
 
