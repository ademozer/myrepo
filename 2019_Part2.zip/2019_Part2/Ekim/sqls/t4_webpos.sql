select * from koc_clm_hlth_indem_totals where contract_id=429720980 and partition_no=374 and cover_code IN('S814','ST838')
--485359680 6131
union
select * from koc_clm_hlth_indem_totals where contract_id=485359680 and partition_no=6131 and cover_code IN('S814','ST838')
--485359680 6131

SELECT * FROM Koc_Cc_Hlth_Web_Cover_Grp
where web_cover_grp_code IN('S814','ST838')
485359680 6131;

ALZ_HCLM_CONVERTER_UTILS;

select * from koc_clm_vacc_indem_totals;

select * from koc_auth_user_role_rel where role_code='HCLMPROV' and username='WORYILMAZ';

KOC_CLM_HLTH_HOSPT_UTILS.GETPOLICYWEBPOSCOVERS;

