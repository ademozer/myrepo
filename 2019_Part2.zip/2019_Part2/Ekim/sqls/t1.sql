  Koc_Clm_Hlth_Bpm_Utils.Getauthinf(:Koc_Clm_Hlth_Provisions.Claim_Id, :Parameter.Instance_Id, v_Is_Authorized, v_User_Name,
                                        :Parameter.State_Date, :Parameter.Is_Emergency, p_Status_Code);
                                        
                                        
                                        
         SELECT /*Stated_By,
                Instance_Id,
                State_Date,
                NVL (Is_Emergency, 0),
                Status_Code*/
                *
           FROM Koc_Clm_Web_Auth_Pool r 
          WHERE     Claim_Id = 42507290
                AND Create_Date = (SELECT MAX (b.Create_Date)
                                     FROM Koc_Clm_Web_Auth_Pool b
                                    WHERE b.Claim_Id = r.Claim_Id)
                --and nvl(b.status_code, 'X') = nvl(r.status_code, 'X'))
                AND (Status_Code IN ('A', 'U', 'AD') OR Status_Code IS NULL
               );
                
                
                select * from clm_subfiles where ext_reference='58578387'
