DECLARE

v_string VARCHAR2(10000) := --'Anla�mal� Doktor // Tan�mlanmam�� hematuri " hematom // RIRS\n***yanl�zca tan�sal \ i�lem olmas� halinde teminat 3.600tl limitli %80''''''lidir';
                           'Hasta \"sol uylukta bacakta g��s�zl�k\" �ikayetiyle 10.06.2019 tarihinden beri takiplidir.'; 

/*FUNCTION adjustEscapeChars(p_string IN VARCHAR2) RETURN VARCHAR2 IS
       v_string VARCHAR2(32000);
    BEGIN
        --v_string := REPLACE(p_string, CHR(39)||CHR(39), '[apos]');
        v_string := REPLACE(p_string, CHR(39), CHR(92)||CHR(39));        
        v_string := REPLACE(v_string, CHR(92), CHR(92)||CHR(92));
        v_string := REPLACE(v_string, CHR(34), CHR(92)||CHR(34));
        v_string := regexp_replace(v_string, '([^[:graph:] | ^[:blank:]])', '\n');
        RETURN v_string;
    END adjustEscapeChars;*/
 FUNCTION adjustEscapeChars(p_string IN VARCHAR2) RETURN VARCHAR2 IS
       v_string VARCHAR2(32000);
    BEGIN
        v_string := TRIM(p_string);
        v_string := REPLACE(v_string, CHR(92)||CHR(92), CHR(92));
        v_string := REPLACE(v_string, CHR(92)||CHR(34), CHR(34));
        v_string := REPLACE(v_string, CHR(39)||CHR(39), CHR(39));
        v_string := REPLACE(v_string, CHR(39), CHR(39)||CHR(39));
        v_string := REPLACE(v_string, CHR(92), CHR(92)||CHR(92));
        v_string := REPLACE(v_string, CHR(34), CHR(92)||CHR(34));
        v_string := regexp_replace(v_string, '([^[:graph:] | ^[:blank:]])', '\n');
        RETURN v_string;
    END adjustEscapeChars;
BEGIN
    DBMS_OUTPUT.PUT_LINE(v_string);
    v_string := adjustEscapeChars(v_string);
    DBMS_OUTPUT.PUT_LINE('{"desc" : "'||v_string||'"}');
    v_string := adjustEscapeChars(v_string);
    DBMS_OUTPUT.PUT_LINE('{"desc" : "'||v_string||'"}');
    v_string := adjustEscapeChars(v_string);
    DBMS_OUTPUT.PUT_LINE('{"desc" : "'||v_string||'"}');
END;
