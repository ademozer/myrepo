update alz_hclm_version_info 
   set hclm_usage = 0
 where claim_id in (select claim_id 
                      from clm_subfiles 
                     where ext_reference in('59122730', '59122822', '59122673', '59059805', '59112053','59122793', '59122704', '59122718'))
                     
