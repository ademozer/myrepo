select institute_code, count(*) 
from alz_hclm_version_info where  NVL(HCLM_CHANNEL,'X') != 'AZNET_REIMBURSEMENT' 
and version_no=1 and entry_date > TO_DATE('30/09/2019 01:00:00', 'DD/MM/YYYY HH24:MI:SS')  group by institute_code

select user_id , count(*) 
from alz_hclm_version_info where  NVL(HCLM_CHANNEL,'X') = 'AZNET_REIMBURSEMENT' 
and version_no=1 and entry_date > TO_DATE('30/09/2019 01:00:00', 'DD/MM/YYYY HH24:MI:SS')  group by user_id;


--koc_hlth_clm_transfer.pr_clm_hlth_set_remaining

select add_months(sysdate, 9) from dual

