 SELECT Proc.Discount_Group_Code,
             Proc.Tda_Process_Type,
             Proc.Tda_Coefficient,
             Agg.Agreement_Code,
             Nvl(Proc.Process_Group, '0'),
             nvl(proc.is_multiple_branches,0) is_multiple_branches
        
        FROM Koc_Cc_Hlth_Tda_Proc_List     Proc,
             Koc_Cc_Hlth_Tda_Dicnt_Agg_Rel Agg
       WHERE Proc.Process_Code_Main = 92
         AND Proc.Process_Code_Sub1 = 70
         AND Proc.Process_Code_Sub2 = 105
        -- AND Proc.Validity_Start_Date <= p_Date
        -- AND Nvl(Proc.Validity_End_Date, p_Date) >= p_Date
         AND Proc.Discount_Group_Code = Agg.Discount_Code(+)
         AND Agg.Validity_End_Date IS NULL;
         
         
      SELECT a.*--a.sut_discount_code I--NTO v_return
        FROM alz_hlth_mnw_link_sut_subj a
       WHERE a.is_valid = 1
        and sut_doctor_branch=1800
        --AND a.validity_start_date < p_date
        --AND NVL(a.validity_end_date , trunc(SYSDATE)) >=trunc( p_date)
       -- AND a.sut_doctor_branch = p_doctor_sut_branch ;
       
       
      select * from customer.alz_duplicate_provision  where ext_reference='58691673';
      
      select * from alz_hltprv_log where log_id=137897176
      select * from clm_subfiles where ext_reference='58691673';
      select * from alz_hclm_version_info where claim_id=42650567
select * from alz_hltprv_log where log_id=137898204
