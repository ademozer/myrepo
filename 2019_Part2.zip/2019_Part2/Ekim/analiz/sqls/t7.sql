select * from alz_hclm_institute_info for update;

update alz_hclm_institute_info set HCLM_USAGE=1 WHERE HCLM_USAGE=0;

 Select Sum(a.Refuse_Amount) Refuse_Amount
           from Koc_clm_hlth_reject_loss a
          where 1=1 
          and rownum<2
            And a.Main_Code = 16
            And a.Item_Code = 12;

select * from alz_hclm_version_info;


