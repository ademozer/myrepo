Alz_Affluent_Mail_Log 
ALZ_CALL_AFFLUENT_CRM_WS_LOG 

select distinct table_name from dba_tab_privs where grantee = 'ALLZWEBPOL' and owner='COGNOS'
MINUS 
select distinct table_name from dba_tab_privs where grantee = 'ALLZWEBPRV' and owner='COGNOS'
