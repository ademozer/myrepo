select * from clm_subfiles where ext_reference='58521392'
select * from alz_hclm_version_info where claim_id=42436180;
select * from koc_clm_hlth_provisions where claim_id=42436180;
select * from alz_hltprv_log where note='UPDATE_PROVISION_REQUEST' and insuredno='58521392' and insurednotype='EXT_REFERENCE' 
and log_date>TRUNC(SYSDATE-5)  -- 137489381 prep

select * from alz_hltprv_log where log_id=132499433--132483409;

ALZ_HLTH_KARMA_UTILS

SELECT * FROM ALZ_HCLM_VERSION_INFO WHERE CLAIM_ID=42888792 FOR UPDATE
select * from alz_hclm_institute_info where institute_code=813 for update;

select * from koc_clm_suppliers_ext where institute_code=813 for update

select * from clm_subfiles where claim_id=42888792;

select * from ocp_policy_bases where policy_ref='0001171006129113';
select * from clm_pol_oar where contract_id=485359680 and oar_no=292;
select * from clm_subfiles where claim_id=42894286
