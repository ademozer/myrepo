--select * from clm_subfiles where ext_reference='58916665';
ALZ_HCLM_CONVERTER_UTILS

select * from alz_hltprv_log a where log_date>trunc(sysdate-1) and note='COMPUTE_REMAINING_REQUEST'
and exists(select 1 from alz_hltprv_log b where b.log_date>trunc(sysdate-1) and note='COMPUTE_REMAINING_EXCEPTION' and a.log_id = b. log_id )
and a.institutecode in (6475, 28, 4547, 1407, 553, 6411, 1540, 5104)
--and log_source='PLSQL CENTRAL_PROVISION'
--select * from alz_hltprv_log a where log_date>trunc(sysdate-1) and note='PROCESS_PRICE_REQUEST'

select * from alz_hltprv_log where log_id=140156342--140155048;
select * from koc_clm_hlth_detail where ext_reference='58902049' for update
select ascii('-') from dual
select * from alz_hclm_version_info where claim_id=42920710
select * from clm_subfiles where ext_reference='58902049'

SELECT REGEXP_REPLACE('t/h"is"'||chr(9)||'is a|te\st', '([/\|"])', '\\\1', 1, 0) FROM dual;

select * from alz_hltprv_log a where log_date>trunc(sysdate) and note='UPDATE_PROVISION_REQUEST' and insuredno='58902049'
