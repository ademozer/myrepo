select * from all_source where lower(text) like '%getinstitutename%';
ALZ_KKB_FINDEKS_UTILS;

select * from alz_kkb_iban_ws_req where tck_vkn_no = '56662009790'
                    (req_id, req_key, tck_vkn_no, iban, channel, branch,
                     platform, app_screen, username, req_xml, resp_xml,
                     create_date, error_code, error_msg, add_error_expl,
                     process_result, verify_result, explanation;
                     
                      select * from koc_acc_bank_history where contract_id=455430297 and validity_end_date is null for update
                      
                       select * from alz_kkb_iban_ws_req where iban='TR530006200071900006683449'
                       
                       select * from koc_cp_partners_ext where identity_no='50230231736'
                        50230231736
 56662009790;
 
 SELECT KOC_CLM_HLTH_UTILS.Getinstitutenamebasic(6411) FROM DUAL;
 
 SELECT * FROM clm_subfiles where ext_reference='58900653';
 select * from alz_hclm_version_info where claim_id=42917949 for update
 
 SELECT 1 FROM (SELECT  DISTINCT comp_name,
            SUBSTR (oracle_username, INSTR (oracle_username, '_', 1, 1) + 1) partaj,
            c.oracle_username user_name,
            d.grandparent_label ust_menu_adi,
            d.parent_label menu_adi,
            b.long_name program_adi
    FROM    sec_functions a,
            sec_dnm_menu_item_functions b,
            sec_system_users c,
            sec_dnm_full_menu d
    WHERE   a.function_id = b.function_id
        AND b.ora_nls_code = 'TR'
        AND b.context_group_name = c.main_menu_context_grp
        AND c.end_date IS NULL
        AND d.context_group = b.context_group_name
        AND d.menu_item = b.menu_item       
    UNION ALL
    SELECT  DISTINCT component_name comp_name,
            SUBSTR (oracle_username, INSTR (oracle_username, '_', 1, 1) + 1) partaj,        
            c.oracle_username user_name,
            a.grandparent_label,
            a.parent_label,
            item_label
    FROM    sec_dnm_full_menu a, 
            sec_dnm_menu_item_functions b, 
            sec_system_users c
    WHERE a.context_group = b.new_ctxt_grp_name
        AND a.ora_nls_code = 'TR'
        AND b.context_group_name = c.main_menu_context_grp)
   WHERE comp_name LIKE '%KOCREPOCP%300%'
   --  AND user_name = P_USER_NAME;
