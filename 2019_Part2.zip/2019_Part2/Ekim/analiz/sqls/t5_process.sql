    SELECT DISTINCT A3.Cover_Code,
                                            A3.Swift_Code,
                                            Nvl(A3.Is_Special_Cover, 0) Is_Special_Cover,
                                            Nvl(A3.Is_Pool_Cover, 0) Is_Pool_Cover,
                                            A3.f_Day_Seance,
                                            A3.Main_Or_Sub_Cov
                FROM Koc_Cc_Hlth_Loc_Cover_Proc A1,
                         Koc_Oc_Cover_Definitions   A2,
                         Koc_Clm_Hlth_Indem_Totals  A3,
                         Koc_Oc_Cover_Definitions   A4
             WHERE A1.Location_Code = 910
                 AND A1.Process_Code_Main = 92
                 AND A1.Process_Code_Sub1 = 70
                 AND A1.Process_Code_Sub2 = 105
                 AND A1.Validity_Start_Date <= Trunc(SYSDATE)
                 AND (A1.Validity_End_Date >= Trunc(SYSDATE) OR A1.Validity_End_Date IS NULL)
                 AND A1.Cover_Code = A2.Cover_Code
                 AND A2.Validity_Start_Date <= Trunc(SYSDATE)
                 AND (A2.Validity_End_Date >= Trunc(SYSDATE) OR A2.Validity_End_Date IS NULL)
                 AND A3.Contract_Id = 469386319
                 AND A3.Partition_No = 1543
                 AND A3.Claim_Inst_Type = 'AK'
                 AND A3.Claim_Inst_Loc = 'YI'
                 AND Nvl(A3.Is_Valid, 0) = 1
                 AND A3.Cover_Code = A4.Cover_Code
                 AND A4.Web_Cover_Grp_Code = A2.Web_Cover_Grp_Code
                 AND A3.Country_Group = Nvl(null, 0)
                 AND A3.Validity_Start_Date <= Trunc(SYSDATE)
                 AND (A3.Validity_End_Date >= Trunc(SYSDATE) OR A3.Validity_End_Date IS NULL)
                 AND A4.Validity_Start_Date <= Trunc(SYSDATE)
                 AND (A4.Validity_End_Date >= Trunc(SYSDATE) OR A4.Validity_End_Date IS NULL);
                 
                 --select * from koc_clm_hlth_indem_totals where contract_id= 469386319 and partition_no=1543 
                 --and claim_inst_type='AK' and claim_inst_loc='YI'
                 
                select * from Koc_Cc_Hlth_Loc_Cover_Proc where location_code=910  and cover_code='ST534'
                and process_code_main=92 and process_code_sub1=70 and process_code_sub2=105 for update
