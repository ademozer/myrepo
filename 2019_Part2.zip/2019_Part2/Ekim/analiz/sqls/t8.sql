select * from alz_hclm_institute_info where institute_code=175 for update;


select * from koc_clm_medicine_indem_det where claim_id = 41906847

select * from koc_clm_hlth_detail where ext_reference = '58666673'

