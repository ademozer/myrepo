﻿select a.PARAMETER,lower(a.EXPLANATION) EXPLANATION_SEARCH,a.EXPLANATION, 'STD_ILAC' MEDICINE_NOTE_TYPE,'ÝLAÇ NOTU' MEDICINE_NOTE_TYPE_DESC
from alz_look_up a
where a.CODE='STD_ILAC'
and a.VALIDITY_END_DATE is null 
and REGEXP_LIKE(lower(a.explanation),'gebelik') 
--and :koc_notes_authorization.NOTE_TYPE='ILAC'
union
select a.PARAMETER,lower(a.EXPLANATION) EXPLANATION_SEARCH,a.EXPLANATION, 'SPC_ILAC' MEDICINE_NOTE_TYPE,'ÖZEL ÝLAÇ NOTU' MEDICINE_NOTE_TYPE_DESC
from alz_look_up a
where a.CODE='SPC_ILAC'
and a.VALIDITY_END_DATE is null
and REGEXP_LIKE(lower(a.explanation),'gebelik') 
--and :koc_notes_authorization.NOTE_TYPE='ILAC'
select a.* 
from alz_look_up a
where a.CODE='STD_ILAC'
and a.parameter=34;

