DECLARE
    v_out VARCHAR2(4000);
    HCLM_CHANNEL VARCHAR2(100) := 'CENTRAL_PROVISION';
    procedure setRemaining(p_Contract_Id           IN NUMBER,
                           p_Partition_No          IN NUMBER,
                           p_Compute_Pool          IN NUMBER,
                           p_User_Id               IN VARCHAR2,
                           p_Message               OUT VARCHAR2) IS

         v_hltprv_Log          Hltprv_Log_Typ := Hltprv_Log_Typ();
         v_request CLOB;
         v_response CLOB;
         v_url VARCHAR2(400) := get_url_link('http://esb.allianz.com.tr:12000/hclm-health-claim-service/api/v1/computeremaining/set');
         v_status NUMBER;
         v_message VARCHAR2(1000);
         v_complementary_type VARCHAR2(10);
         v_ulak_price VARCHAR2(100);  --ademo.HRCL1-2715
         v_price NUMBER := NULL;

     BEGIN
          v_hltprv_Log.Log_Id        := Customer.Alz_hltprv_log_id_seq.Nextval;
          v_hltprv_Log.Order_No      := 1;
          
          v_request := '{            
            "contractId" : "'||TO_CHAR(p_Contract_Id)||'",                      
            "partitionNo" : "'||TO_CHAR(p_Partition_No)||'",
            "computePool" : "'||TO_CHAR(p_Compute_Pool)||'",
            "logId" : "'||TO_CHAR(v_hltprv_Log.Log_Id)||'",
            "userDto" : {
                "userId" : "' || p_User_Id || '",
                "userName" : "' ||p_User_Id || '"
            }
        }';

          v_request := regexp_replace(v_request, '([^[:graph:] | ^[:blank:]])', '');

          v_hltprv_Log.Servicename   := 'ALZ_HCLM_CONVERTER_UTILS';
          v_hltprv_Log.Processinfo   := v_url;
          v_hltprv_Log.Note          := 'SET_REMAINING_REQUEST';
          v_hltprv_Log.Content       := v_request;        
          v_hltprv_Log.insurednotype := 'CONTRACT_ID';
          v_hltprv_Log.insuredno     := p_Contract_Id;  
          v_hltprv_Log.Log_Type      := 'INFO';
          v_hltprv_Log.Log_Source    := 'PLSQL '||HCLM_CHANNEL;
          v_hltprv_Log.Savelogwithpragma;

          ALZ_HCLM_CONVERTER_UTILS.callRestService(v_url, 'POST', v_request, v_response, v_status, v_message);

          v_hltprv_Log.Servicename   := 'ALZ_HCLM_CONVERTER_UTILS';
          v_hltprv_Log.Processinfo   := v_url;
          v_hltprv_Log.Note          := 'SET_REMAINING_RESPONSE';
          v_hltprv_Log.Content       := v_response;        
          v_hltprv_Log.insurednotype := 'CONTRACT_ID';
          v_hltprv_Log.insuredno     := p_Contract_Id;  
          v_hltprv_Log.Log_Type      := 'INFO';
          v_hltprv_Log.Log_Source    := 'PLSQL '||HCLM_CHANNEL;
          v_hltprv_Log.Savelogwithpragma;

          v_response := replace(replace(replace(replace(v_response,'[{', ''),'}',''),'}]',''),'{','');
          FOR rec IN (SELECT TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1) , '"',''))   KEY,
                             TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1, 2), '"','')) VALUE
                       FROM (SELECT Regexp_Substr (v_response, '[^,]+', 1, LEVEL) ELEMENT
                               FROM Dual
                            CONNECT BY LEVEL <= LENGTH (Regexp_Replace (v_response, '[^,]+')) + 1)) LOOP
             IF rec.KEY IN('message') THEN
                  v_message := rec.value;
             END IF;
          END LOOP;
          IF v_status = 1 THEN
              Raise_Application_Error(-20200,  v_message);
          END IF;
          p_message := v_message;
        
     EXCEPTION
     WHEN OTHERS THEN
          v_hltprv_Log.Servicename   := 'ALZ_HCLM_CONVERTER_UTILS';
          v_hltprv_Log.Processinfo   := v_url;
          v_hltprv_Log.Note          := 'SET_REMAINING_EXCEPTION';
          v_hltprv_Log.Content       := v_message || dbms_utility.format_error_stack || dbms_utility.format_error_backtrace;  
          v_hltprv_Log.insurednotype := 'CONTRACT_ID';
          v_hltprv_Log.insuredno     := p_Contract_Id;          
          v_hltprv_Log.Log_Type      := 'ERROR';
          v_hltprv_Log.Log_Source    := 'PLSQL '||HCLM_CHANNEL;
          v_hltprv_Log.Savelogwithpragma;
          Raise_Application_Error(-20200,  'Limit G�ncelleme S�ras�nda Hata Olu�tu:'||v_hltprv_Log.Log_Id||':'||v_message);
     END setRemaining;
BEGIN
     setRemaining(441564560,9880, 1, 'ADEMO', v_out);
     DBMS_OUTPUT.PUT_LINE(v_out);
END;
