DECLARE

vl_claim_id NUMBER := 44178582;
v_result    NUMBER := 0;
 FUNCTION Update_Uncompleted_Claim (p_Claim_Id NUMBER)
      RETURN NUMBER
   IS
      CURSOR c_Trans
      IS
           SELECT Hlth_Cover_Code, MAX (Trans_No)
             FROM Koc_Clm_Trans_Ext
            WHERE Claim_Id = p_Claim_Id AND Sf_No = 1
         GROUP BY Hlth_Cover_Code;

      CURSOR c
      IS
         SELECT 1
           FROM Koc_Clm_Hlth_Detail
          WHERE Claim_Id = p_Claim_Id AND Status_Code = 'PP';

      Cur                   KOC_CLM_HLTH_BPM_UTILS.Refcur;
      v_Is_Exists           NUMBER := 0;
      v_Web_Location_Code   NUMBER (5);
      Institutinfo          Koc_v_Clm_Suppliers%ROWTYPE;
      Policyinfo            Koc_v_Hlth_Insured_Info_Indem%ROWTYPE;
      v_Trans_No            NUMBER;
      v_Int_Ref             NUMBER;
      v_Status_Id           NUMBER;

      v_Add_Order_No        NUMBER (2);
      v_Institute_Code      NUMBER;
      v_Ext_Reference       VARCHAR2 (30);
      v_User_Name           VARCHAR2 (50) := 'faxUser';
      v_Contract_Id         NUMBER;
      v_Partition_No       NUMBER;
      v_Clmdetail    Koc_Clm_Hlth_Trnx.Clmdetailtype;
      v_Clmrejection KOC_CLM_HLTH_TRNX.Clmrejectiontype;
   BEGIN
      OPEN c;

      FETCH c INTO v_Is_Exists;

      CLOSE c;

      IF v_Is_Exists = 1
      THEN
        IF ALZ_HCLM_CONVERTER_UTILS.getHclmUsage(null,  p_Claim_Id, null, null, 'EKSIK_EVRAK_RET', 'CENTRAL_PROVISION') = 1 THEN
            ALZ_HCLM_CONVERTER_UTILS.setChannel('CENTRAL_PROVISION');
            BEGIN
               SELECT contract_id,
                      oar_no
               INTO v_Contract_Id,
                    v_Partition_No
               FROM clm_pol_oar
               WHERE claim_id = p_Claim_Id;
               Koc_Pk_Hlth_Provision.Getdetaildata_Trnx(p_Claim_Id, 1, 1, v_Clmdetail);    
            EXCEPTION
            WHEN OTHERS THEN
                NULL;
            END;
            
            v_clmRejection(1).claim_id           := p_Claim_Id;
            v_clmRejection(1).sf_no              := 1;
            v_clmRejection(1).location_code      := v_Clmdetail(1).Web_Location_Code;
            v_clmRejection(1).cover_code         := '0' ;
            v_clmRejection(1).process_code_main  := 0;
            v_clmRejection(1).process_code_sub1  := 0;
            v_clmRejection(1).process_code_sub2  := 0;
            v_clmRejection(1).add_order_no       := v_Clmdetail(1).add_order_no;
            v_clmRejection(1).main_code          := 17;
            v_clmRejection(1).item_code          := 12;
            v_clmRejection(1).sub_item_code      := 21;
            v_clmRejection(1).refuse_amount      := 0;
            v_clmRejection(1).refuse_explanation := 'Eksik Evraklarin Zamaninda Tamamlanmamasi';
            v_clmRejection(1).userid             := v_User_Name;
            v_clmRejection(1).barcode            := 0;
            v_clmRejection(1).is_bre_decision    := '0';
            v_clmRejection(1).seq_no             := 1;
            v_clmRejection(1).ubb_code           := '0';
    
            ALZ_HCLM_CONVERTER_UTILS.rejectProvision(v_Contract_Id,
                                                     v_Partition_No,
                                                     COALESCE(v_Clmdetail(1).Medula_Date, v_Clmdetail(1).Provision_Date),
                                                     v_User_Name,
                                                     v_Clmdetail,
                                                     v_clmRejection,
                                                     'Eksik Evrak Otomatik Ret');
                                                     
                                                     
        ELSE 
         UPDATE Koc_Clm_Hlth_Proc_Detail
            SET Status_Code = 'R'
          WHERE Claim_Id = p_Claim_Id;

         UPDATE Koc_Clm_Hlth_Provisions
            SET Status_Code = 'R',
                Provision_Total = 0,
                Exemption_Amount = 0,
                Sgk_Amount = 0
          WHERE Claim_Id = p_Claim_Id;

         UPDATE Koc_Clm_Hlth_Detail
            SET Status_Code = 'R', Provision_Date = SYSDATE
          WHERE Claim_Id = p_Claim_Id;

         UPDATE Koc_Clm_Medicine_Indem_Det
            SET Status_Code = 'R'
          WHERE Claim_Id = p_Claim_Id;

         UPDATE Koc_Clm_Vacc_Indem_Totals
            SET Status_Code = 'R'
          WHERE Claim_Id = p_Claim_Id;

         SELECT Web_Location_Code
           INTO v_Web_Location_Code
           FROM Koc_Clm_Hlth_Detail
          WHERE Claim_Id = p_Claim_Id AND Sf_No = 1;

         INSERT INTO Koc_Clm_Hlth_Reject_Loss (Claim_Id,
                                               Sf_No,
                                               Add_Order_No,
                                               Location_Code,
                                               Main_Code,
                                               Item_Code,
                                               Sub_Item_Code,
                                               Refuse_Explanation,
                                               Userid,
                                               Entry_Date,
                                               Cover_Code,
                                               Process_Code_Main,
                                               Process_Code_Sub1,
                                               Process_Code_Sub2,
                                               Barcode,
                                               Refuse_Amount)
              VALUES (p_Claim_Id,
                      1,
                      1,
                      v_Web_Location_Code,
                      17,
                      12,
                      21,
                      'Eksik Evraklarin Zamaninda Tamamlanmamasi',
                      v_User_Name,
                      TRUNC (SYSDATE),
                      0,
                      0,
                      0,
                      0,
                      0,
                      0);

         Koc_Clm_Hlth_Utils.Getpolinfoforindembyclm (p_Claim_Id, NULL, Cur);

         FETCH Cur INTO Policyinfo;

         CLOSE Cur;

         Koc_Clm_Hlth_Utils.Getinstitutinfobycode (v_Institute_Code,
                                                   TRUNC (SYSDATE),
                                                   Cur);

         FETCH Cur INTO Institutinfo;

         SELECT r.Add_Order_No, r.Institute_Code, r.Ext_Reference
           INTO v_Add_Order_No, v_Institute_Code, v_Ext_Reference
           FROM Koc_Clm_Hlth_Detail r
          WHERE     r.Claim_Id = p_Claim_Id
                AND r.Sf_No = 1
                AND r.Add_Order_No = 1;

         FOR r IN c_Trans
         LOOP
            SELECT Clm_Int_Ref_Seq.NEXTVAL INTO v_Int_Ref FROM DUAL;

            v_Trans_No :=
               Koc_Clm_Hlth_Hospt_Utils.Getmaxtransno (p_Claim_Id, 1) + 1;

            INSERT INTO Clm_Trans (Claim_Id,
                                   Sf_No,
                                   Trans_No,
                                   Movement_Id,
                                   Assignee,
                                   Sf_Total_Type,
                                   Trans_Type,
                                   Trans_Date,
                                   Clm_Status,
                                   Trans_Amt,
                                   Trans_Amt_Swf,
                                   Rsv_Amt,
                                   Trans_Base_Amt,
                                   Int_Ref,
                                   Supp_Id,
                                   Ip_No,
                                   Oar_No,
                                   Ext_Reference)
                 VALUES (p_Claim_Id,
                         1,
                         v_Trans_No,
                         1,
                         v_User_Name,
                         10,
                         10,
                         TRUNC (SYSDATE),
                         'TRANS',
                         0,
                         'TL',
                         0,
                         0,
                         v_Int_Ref,
                         Institutinfo.Supp_Id,
                         Policyinfo.Ip_No,
                         Policyinfo.Partition_No,
                         v_Ext_Reference);

             begin
             koc_clm_bordro.alz_hlth_bordro_trans_log(p_Claim_Id,v_trans_no,'KOC_CLM_HLTH_BPM_UTILS-7059',null,1);
             exception when others then
                begin
                    koc_clm_bordro.alz_hlth_bordro_trans_log(p_Claim_Id,v_trans_no,'KOC_CLM_HLTH_BPM_UTILS-7059',null,1,substr(sqlerrm,1,950));
                exception when others then
                    null;
                end;
             end;

            INSERT INTO Koc_Clm_Trans_Ext (Claim_Id,
                                           Sf_No,
                                           Add_Order_No,
                                           Trans_No,
                                           Exemption_Amount,
                                           Hlth_Cover_Code,
                                           Currency_Exchange_Rate)
                 VALUES (p_Claim_Id,
                         1,
                         v_Add_Order_No,
                         v_Trans_No,
                         0,
                         r.Hlth_Cover_Code,
                         1);

            SELECT Clm_Status_Id_Seq.NEXTVAL INTO v_Status_Id FROM DUAL;

            INSERT INTO Clm_Status_History (Status_Id,
                                            Claim_Id,
                                            Clm_Line_Id,
                                            Clm_Level,
                                            Clm_Status,
                                            Csh_Date,
                                            Csh_Username,
                                            Sf_No,
                                            Trans_No)
                 VALUES (v_Status_Id,
                         p_Claim_Id,
                         20,
                         'TRANS',
                         'CANCELLED',
                         TRUNC (SYSDATE),
                         v_User_Name,
                         1,
                         v_Trans_No);

            INSERT INTO Koc_Clm_Status_History_Ext (Status_Id,
                                                    Claim_Id,
                                                    Sf_No,
                                                    Clm_Status,
                                                    Process_Date,
                                                    Userid,
                                                    Explanation)
                 VALUES (v_Status_Id,
                         p_Claim_Id,
                         1,
                         'CANCELLED',
                         SYSDATE,
                         v_User_Name,
                         NULL);
         END LOOP;

         INSERT INTO Koc_Clm_Hlth_Indem_Dec (Claim_Id,
                                             Sf_No,
                                             Add_Order_No,
                                             Process_Date,
                                             File_Agreement_Code,
                                             Explanation,
                                             Userid)
              VALUES (p_Claim_Id,
                      1,
                      1,
                      SYSDATE,
                      'R',
                      'Eksik Evrak Otomatik Red',
                      v_User_Name);

         --
         UPDATE Koc_Clm_Hlth_Incomp_Papers
            SET Status_Code = 'C'
          WHERE Claim_Id = p_Claim_Id AND Status_Code = 'A';

         --
         UPDATE Clm_Subfiles
            SET Clm_Status = 'CANCELLED'
          WHERE Claim_Id = p_Claim_Id;
      --
      END IF;
      END IF;

      RETURN v_Is_Exists;
   END Update_Uncompleted_Claim;
   BEGIN
       v_result := Update_Uncompleted_Claim(vl_claim_id); 
       DBMS_OUTPUT.PUT_LINE('result='||v_result);
   END;
