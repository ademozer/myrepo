DECLARE
    v_Ext_Ref      VARCHAR2(100) := '59310195';
    v_Claim_Id     NUMBER;
    v_Contract_Id  NUMBER;
    v_Partition_No NUMBER;
    v_Clmdetail    Koc_Clm_Hlth_Trnx.Clmdetailtype;
    v_User_Id      VARCHAR2(20) := 'ADEMO';    
    v_Cancel_Exp   VARCHAR2(400) := 'T6451287 Nolu �a�r� Kapsam�nda �ptal Edilmi�tir.';
BEGIN
    SELECT claim_id 
      INTO v_Claim_Id
      FROM clm_subfiles
     WHERE ext_reference = v_Ext_Ref;
     
    SELECT Contract_Id,
             Oar_No
        INTO v_Contract_Id,
             v_Partition_No
        FROM Clm_Pol_Oar c
       WHERE c.Claim_Id = v_Claim_Id;

     Koc_Pk_Hlth_Provision.Getdetaildata_Trnx(v_Claim_Id, 1, 1, v_Clmdetail);
     ALZ_HCLM_CONVERTER_UTILS.setChannel('CENTRAL_PROVISION');
     ALZ_HCLM_CONVERTER_UTILS.cancelProvision(v_Contract_Id,
                                              v_Partition_No,
                                              COALESCE(v_Clmdetail(1).Medula_Date, v_Clmdetail(1).Provision_Date),
                                              v_User_Id,
                                              v_Clmdetail,
                                              v_Cancel_Exp);
                                              
     DBMS_OUTPUT.PUT_LINE('�ptal ��lemi Ba�ar�l�');
     COMMIT;
EXCEPTION WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Hata: '||SQLERRM);
    ROLLBACK;
END;
/
                                    
                                              
                                              
