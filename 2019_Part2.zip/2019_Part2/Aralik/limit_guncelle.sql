DECLARE
v_err_seq NUMBER;
v_err_msg VARCHAR2(32000);
v_adet NUMBER := 0;
v_limit NUMBER := 500;
BEGIN
  
FOR rec IN (SELECT contract_id, partition_no FROM ademo.limit_guncelle@opusdev WHERE is_updated = 'NO' AND ROWNUM<v_limit) LOOP
  
    KOC_HLTH_CLM_TRANSFER.Pr_Clm_Hlth_Set_Remaining(rec.contract_id, rec.partition_no, 1, v_err_seq, v_err_msg);
    
    UPDATE ademo.limit_guncelle@opusdev
       SET is_updated = 'E',
           err_msg = v_err_seq
     WHERE contract_id = rec.contract_id
       AND partition_no = rec.partition_no;
   
    IF MOD(v_adet, 100) = 0 THEN 
       COMMIT;
    END IF;   
      
    v_adet := v_adet + 1;
END LOOP;
    COMMIT; 
   DBMS_OUTPUT.PUT_LINE(v_adet||' adet kay�t g�ncellendi');
EXCEPTION 
WHEN OTHERS THEN
   DBMS_OUTPUT.PUT_LINE('Hata:'||SQLERRM);
END;
 
