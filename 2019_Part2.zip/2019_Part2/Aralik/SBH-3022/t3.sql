select * from koc_clm_hlth_detail  where ext_reference='59748658';

select * from alz_hclm_version_info where claim_id=44014150 for update
