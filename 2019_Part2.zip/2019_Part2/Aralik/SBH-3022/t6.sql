select distinct policy_ref as Police_No, sira_no, (select identity_no from koc_cp_partners_ext@opusprep where part_id = 
                                                   (select part_id from koc_clm_hlth_detail@opusprep  where claim_id = a.claim_id and add_order_no = 1 and sf_no=1)) IDENTITY_NO,                                                   
                                                   text as �la�_Notu_A��klamas�, CASE WHEN (select count(*) from sbh3022 where note_id = a.note_id and prescription_status='ONAYLI')>0 THEN 'VAR' ELSE 'YOK' END ER_DURUMU
from sbh3022 a


select distinct a.policy_ref as Police_No, a.sira_no, e.identity_no, a.text, CASE WHEN (select count(*) from sbh3022 where note_id = a.note_id and prescription_status='ONAYLI')>0 THEN 'VAR' ELSE 'YOK' END ER_DURUMU
from sbh3022 a,      
     koc_clm_hlth_detail@opusprep d,
     koc_cp_partners_ext@opusprep e 
where a.claim_id = d.claim_id
  and d.part_id = e.part_id
order by 1,2,3;


select distinct policy_ref as Police_No, sira_no,text , claim_id, CASE WHEN (select count(*) from sbh3022 where note_id = a.note_id and prescription_status='ONAYLI')>0 THEN 'VAR' ELSE 'YOK' END ER_DURUMU
from sbh3022 a
minus                                                                                            
select distinct a.policy_ref as Police_No, a.sira_no, a.text, a.claim_id, CASE WHEN (select count(*) from sbh3022 where note_id = a.note_id and prescription_status='ONAYLI')>0 THEN 'VAR' ELSE 'YOK' END ER_DURUMU
from sbh3022 a,      
     koc_clm_hlth_detail@opusprep d,
     koc_cp_partners_ext@opusprep e 
where a.claim_id = d.claim_id
  and d.part_id = e.part_id
order by 1,2,3;

alz_hclm_converter_utils;
koc_hlth_clm_transfer
