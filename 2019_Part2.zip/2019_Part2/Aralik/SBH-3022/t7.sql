select distinct a.policy_ref as Police_No, a.sira_no, e.identity_no, d.ext_reference, a.text,  a.barcode, b.medicine_name, a.prescription_status
from sbh3022 a, 
     (select barcode, medicine_name 
  from koc_cc_medicines@opusprep m
 where 1=1
   and validity_date = (select max(validity_date) from koc_cc_medicines@opusprep where barcode=m.barcode)) b,
     koc_clm_hlth_detail@opusprep d,
     koc_cp_partners_ext@opusprep e 
where a.barcode = b.barcode 
  and a.claim_id = d.claim_id
  and d.part_id = e.part_id
order by 1,2,3

select a.*,e.identity_no
  from sbh3022 a, koc_clm_hlth_detail@opusprep d, koc_cp_partners_ext@opusprep e
 where a.claim_id = d.claim_id 
   and d.part_id = e.part_id

select * from koc_cp_partners_ext@opusprep e

select * from clm_pol_bases where claim_id=39122592
select * from koc_clm_hlth_detail where claim_id=39122592
