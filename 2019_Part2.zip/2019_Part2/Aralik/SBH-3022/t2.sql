SELECT Round(SUM(Nvl(Decode(Exemption_Rate, 1, 0, ((Provision_Total) / (1 - Exemption_Rate))) * Exemption_Rate, 0)), 2) Katilim_Tutar,
               Round(SUM(Nvl(Request_Amount, 0) - Nvl(Exemption_Amount, 0) -
                         Nvl(Decode(Exemption_Rate, 1, 0, ((Provision_Total) / (1 - Exemption_Rate))) * Exemption_Rate, 0) - Nvl(Provision_Total, 0) +
                         Decode(Insured_Refuse_Sgk, 0, -nvl(Refusal_Amount, 0) - Sign(Decode(q.Is_Complementary, 1, 0, 1)) * Nvl(Sgk_Amount, 0),
                                -nvl(Refusal_Amount, 0)) - Nvl(q.Talep_Edilmemesi_Gereken_Tutar, 0)), 2) Limit_Asimi,
               Round(SUM(Nvl(Sgk_Amount, 0)), 2) Sgk_Tutar,
               --    SUM(Insured_Refuse_Sgk) Insured_Refuse_Sgk,
               p.Swift_Code,
               p.Cover_Code,
               q.Institute_Code,
               q.Group_Code,
               p.Sgk_Amount,
               p.Refusal_Amount,
               SUM(Decode(Insured_Refuse_Sgk, 0, Decode(Sign(Nvl(p.Refusal_Amount, 0) - Nvl(p.Sgk_Amount, 0)), -1, 0, Nvl(p.Refusal_Amount, 0)),
                          Insured_Refuse_Sgk)) Insured_Refuse_Sgk
          FROM Koc_Clm_Hlth_Provisions p,
               (
                
                SELECT Claim_Id,
                        Sf_No,
                        Add_Order_No,
                        Swift_Code,
                        Cover_Code,
                        Is_Complementary,
                        Institute_Code,
                        Group_Code,
                        SUM(Talep_Edilmemesi_Gereken_Tutar) Talep_Edilmemesi_Gereken_Tutar,
                        SUM(Insured_Refuse_Sgk) Insured_Refuse_Sgk
                  FROM (SELECT p.Claim_Id,
                                p.Sf_No,
                                p.Add_Order_No,
                                b.Swift_Code,
                                p.Cover_Code,
                                (SELECT Nvl(SUM(r.Refuse_Amount), 0)
                                   FROM Koc_Clm_Hlth_Reject_Loss r
                                  WHERE r.Main_Code = 16
                                    AND r.Item_Code = 12
                                    AND r.Cover_Code = p.Cover_Code
                                    AND r.Claim_Id = p.Claim_Id
                                    AND r.Sf_No = p.Sf_No
                                    AND r.Add_Order_No = p.Add_Order_No) Talep_Edilmemesi_Gereken_Tutar,
                                --Decode(a.Main_Code, 16, Decode(a.Item_Code, 12, Round(a.Refuse_Amount, 2), 0), 0) Talep_Edilmemesi_Gereken_Tutar,
                                --fn_16_12_by_cover (p.Claim_Id  ,  p.Sf_No   , p.Add_Order_No   ,   p.Cover_Code   ) Talep_Edilmemesi_Gereken_Tutar,                                
                                Sign(Nvl(p.Sgk_Amount, 0)) *
                                Decode(Sign(Nvl(p.Refusal_Amount, 0) - Nvl(p.Sgk_Amount, 0)), 1, Nvl(p.Refusal_Amount, 0) - Nvl(p.Sgk_Amount, 0), 0) Insured_Refuse_Sgk,
                                b.Is_Complementary,
                                b.Institute_Code,
                                b.Group_Code
                           FROM Koc_Clm_Hlth_Provisions p,
                                --Koc_Clm_Hlth_Reject_Loss a,
                                Koc_Clm_Hlth_Detail b
                          WHERE p.Claim_Id = 44014150 -- 29405608 --
                            AND p.Sf_No = 1 --  1 -- 
                            AND p.Add_Order_No = 1 -- 1 -- 
                            AND p.Claim_Id = b.Claim_Id
                            AND p.Sf_No = b.Sf_No
                         -- AND a.Claim_Id(+) = p.Claim_Id
                         -- AND a.Sf_No(+) = p.Sf_No
                         --    AND a.Add_Order_No(+) = p.Add_Order_No
                         -- AND a.Cover_Code(+) = p.Cover_Code
                         )
