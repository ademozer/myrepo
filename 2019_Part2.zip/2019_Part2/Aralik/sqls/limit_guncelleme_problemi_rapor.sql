create table limit_guncelle as 
select distinct contract_id,partition_no, 'NO' is_updated from koc_clm_hlth_indem_totals_log@opusprep 
where entry_date between TO_DATE('03/12/2019','DD/MM/YYYY') and TO_DATE('13/12/2019','DD/MM/YYYY') 
and log_state='COMPUTEREMANING'

select count(*) from ademo.limit_guncelle@opusdev where is_updated != 'NO'
alter table limit_guncelle add(err_msg varchar2(4000))

GRANT SELECT,INSERT,UPDATE,DELETE ON limit_guncelle TO PUBLIC

select * from koc_clm_hlth_indem_totals_log
where entry_date > trunc(sysdate)
and log_state='COMPUTEREMANING';

update ademo.limit_guncelle@opusdev set is_updated = 'NO' where is_updated != 'NO'

