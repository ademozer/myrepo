DECLARE
v_Contract_Id  NUMBER := 441564560;--369341525;
v_Partition_No NUMBER := 9880;--185;
v_Pool_Calc    NUMBER := 1;
v_Calc_Type    NUMBER := 0;
v_Err_Seq      NUMBER := 0;
v_Err_Msg      VARCHAR2(1000);
g_provOutList  CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.ProvOutParamTyp;
g_institute_code  NUMBER;
g_ProvOutParamRec  CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.ProvOutParamRec;
PROCEDURE computeRemainingForCover(p_Contract_Id     IN NUMBER, 
                                          p_Partition_No    IN NUMBER,
                                          p_Claim_Id        IN NUMBER,
                                          p_Cover_Code      IN VARCHAR2, 
                                          p_Is_Pool_Cover   IN NUMBER,
                                          p_Is_Special_Cover IN NUMBER,                                    
                                          p_Institute_Code  IN NUMBER,
                                          p_Clm_Inst_Type   IN VARCHAR2,
                                          p_Clm_Inst_Loc    IN VARCHAR2,
                                          p_Country_Group   IN VARCHAR2,                                          
                                          p_Query_Date      IN DATE,
                                          p_User_Type       IN VARCHAR2) IS
      p_Out_Cur KOC_CLM_HLTH_TRNX.refcur;
      v_indem_total Koc_Clm_Hlth_Indem_Totals%ROWTYPE;
      v_coverInfoList CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.coverInfoParamTyp;  
      v_provOutList   CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.ProvOutParamTyp;
      ndx NUMBER := 1;
      v_Swift_Code VARCHAR2(10);
      v_pol_info   VARCHAR2(400);
      v_institute_code  NUMBER;
   BEGIN
       v_coverInfoList(1).Cover_Code := p_cover_code;
      v_coverInfoList(1).Day_Seance := 0;
      v_coverInfoList(1).Provision_Amount := 0;
      v_coverInfoList(1).Exemption_Over_Amount := NULL;
      v_coverInfoList(1).Is_Pool_Cover :=  p_Is_Pool_Cover;
      v_coverInfoList(1).Is_Special_Cover := p_Is_Special_Cover;
      v_Swift_Code := 'TL';
      SELECT institute_code INTO v_institute_code FROM koc_clm_hlth_detail where claim_id = p_claim_id and add_order_no = 1 and sf_no = 1;
                    
      CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.setChannel('CENTRAL_COVERS:'||p_Claim_Id||':1:1');
      CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.computeRemainingList(p_Contract_Id,
                                                             p_Partition_No,
                                                             v_Institute_Code,
                                                             p_Clm_Inst_Type,
                                                             p_Clm_Inst_Loc,
                                                             p_Country_Group,
                                                             v_coverInfoList,
                                                             NVL(v_Swift_Code, 'TL'),
                                                             p_Query_Date,
                                                             0,   
                                                             'MEDISER28',
                                                             g_provOutList);
   END computeRemainingForCover;
   
   FUNCTION getRemainingForCover(p_cover_code IN VARCHAR2) RETURN CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.ProvOutParamRec IS
      v_ProvOutParamRec  CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.ProvOutParamRec;
   BEGIN
       FOR ndx IN 1..g_provOutList.COUNT LOOP
          IF p_cover_code = g_provOutList(ndx).Cover_Code THEN
             v_ProvOutParamRec := g_provOutList(ndx);
          END IF;
       END LOOP;  
       RETURN v_ProvOutParamRec; 
   END getRemainingForCover;
PROCEDURE Pr_Clm_Hlth_Set_Remaining(p_Contract_Id  NUMBER,
                                                                            p_Partition_No NUMBER,
                                                                            p_Pool_Calc    NUMBER,
                                                                            p_Call_Type    NUMBER,
                                                                            p_Err_Seq      NUMBER,
                                                                            p_Err_Msg      OUT VARCHAR2) IS

        --p_call_type =0 --no commit;
        --p_call_type =1 --commit;
        --p_call_type =2 --no commit no rollback;

        CURSOR Oldcontract(Pp_Contract_Id  NUMBER,
                                             Pp_Partition_No NUMBER) IS
            SELECT DISTINCT a.Contract_Id,
                                            a.Partition_No
                FROM Koc_Clm_Hlth_Indem_Totals a
             WHERE a.Trans_Contract_Id = Pp_Contract_Id
                 AND a.Trans_Partition_No = Pp_Partition_No
                 AND Nvl(Is_Valid, 0) = 1
                 AND Nvl(Is_Unlimited, 0) = 0;

        CURSOR Newcontract(Pp_Contract_Id  NUMBER,
                                             Pp_Partition_No NUMBER) IS
            SELECT *
                FROM Koc_v_Health_Insured_Info a
             WHERE a.Contract_Id = Pp_Contract_Id
                 AND a.Partition_No = Pp_Partition_No
                 AND a.Contract_Status = 'I';

        Roldcontract               Oldcontract%ROWTYPE;
        Rnewcontract               Newcontract%ROWTYPE;
        Anyclm                     BOOLEAN;
        v_Prov_Amount              NUMBER;
        p_Out_Inst_Exemp_Sum       NUMBER;
        p_Out_Provision_Amount     NUMBER;
        p_Out_Day_Seance           NUMBER;
        p_Out_Exemption_Rate       NUMBER;
        p_Out_Exemption_Sum        NUMBER;
        p_Out_Inst_Exemption_Sum   NUMBER;
        p_r_Day_Seance             NUMBER;
        p_r_Cover_Price            NUMBER;
        p_r_Exemption_Sum          NUMBER;
        p_Inst_Provision_Aval_Code VARCHAR2(3);
        p_Inst_Is_Cover_Val        NUMBER;
        p_Out_Over_Price           VARCHAR2(200);
        v_Contract_Id              NUMBER;
        p_Part_Id                  NUMBER;
        v_Partition_No             NUMBER;
        p_Ip_No                    NUMBER;
        v_Exemp_Mess               VARCHAR2(4000) := '';
        v_Err_Mess                 VARCHAR2(4000) := '';
        v_Exemp_Cnt                NUMBER;
        Cur                        Koc_Clm_Hlth_Utils.Refcur;
        Policyinfo                 Koc_v_Hlth_Insured_Info_Indem%ROWTYPE;
        Indeminfo                  Koc_Clm_Hlth_Indem_Totals%ROWTYPE;
        v_Cnt                      NUMBER := 0;
        v_Count                    NUMBER := 0;
        v_Claim_Id                 NUMBER;
        v_Err                      VARCHAR2(1000);
        v_Exemp_Amount             NUMBER;
        v_Sum_Claim_Amount         NUMBER;
        Vhaspolicy1kez             NUMBER(1) := 0;
        Vis1kezused                NUMBER(1) := 0;
        p_Indemrec                 Koc_Clm_Hlth_Indem_Totals_Log%ROWTYPE;

    BEGIN
        IF p_Pool_Calc = 1
        THEN
            SELECT COUNT(*)
                INTO v_Cnt
                FROM Koc_Clm_Hlth_Indem_Totals a
             WHERE a.Contract_Id = p_Contract_Id
                 AND a.Partition_No = p_Partition_No
                 AND a.Is_Pool_Cover = 1;

            IF (v_Cnt > 0 OR p_Partition_No IS NULL)
            THEN
                UPDATE Koc_Clm_Hlth_Indem_Totals
                     SET r_Cover_Price = f_Cover_Price
                 WHERE Contract_Id = p_Contract_Id
                     AND Partition_No = 0
                     AND Nvl(Is_Unlimited, 0) = 0;

                UPDATE Koc_Clm_Hlth_Indem_Totals
                     SET r_Exemption_Sum = f_Exemption_Sum,
                             r_Day_Seance    = f_Day_Seance
                 WHERE Contract_Id = p_Contract_Id
                     AND Partition_No = 0;

                UPDATE Koc_Clm_Hlth_Indem_Totals a
                     SET a.s_Spend_Total      = 0,
                             a.s_Exemption_Sum    = 0,
                             a.s_Indemnity_Amount = 0,
                             a.s_Provision_Amount = 0,
                             a.s_Spend_Day_Seance = 0
                 WHERE a.Contract_Id = p_Contract_Id
                     AND a.Partition_No = 0;
            END IF;
        END IF;

        FOR Main IN (SELECT DISTINCT Contract_Id,
                                                                 Partition_No,
                                                                 1 Ord
                                     FROM (SELECT Contract_Id,
                                                                Partition_No
                                                     FROM Koc_Clm_Hlth_Indem_Totals a
                                                    WHERE a.Contract_Id = p_Contract_Id
                                                        AND a.Is_Pool_Cover = 1
                                                        AND v_Cnt > 0
                                                        AND Partition_No != 0
                                                        AND p_Partition_No IS NOT NULL
                                                        AND EXISTS (SELECT 1
                                                                     FROM Clm_Pol_Oar             x,
                                                                                Koc_Clm_Hlth_Provisions z
                                                                    WHERE x.Claim_Id = z.Claim_Id
                                                                        AND x.Contract_Id = a.Contract_Id
                                                                        AND x.Oar_No = a.Partition_No
                                                                        AND z.Is_Pool_Cover = 1)
                                                 UNION
                                                 SELECT p_Contract_Id,
                                                                p_Partition_No Partition_No
                                                     FROM Dual
                                                    WHERE p_Partition_No IS NOT NULL
                                                        AND p_Partition_No <> 0
                                                 UNION
                                                 SELECT p_Contract_Id,
                                                                To_Number(NULL) Partition_No
                                                     FROM Dual
                                                    WHERE p_Partition_No IS NULL) Q1
                                 UNION
                                 SELECT Trans_Contract_Id,
                                                Trans_Partition_No,
                                                2 Ord
                                     FROM Koc_Clm_Hlth_Indem_Totals a
                                    WHERE a.Contract_Id = p_Contract_Id
                                        AND Partition_No = p_Partition_No
                                        AND Trans_Contract_Id IS NOT NULL
                                 UNION
                                 SELECT Trans_Contract_Id,
                                                Trans_Partition_No,
                                                2 Ord
                                     FROM Koc_Clm_Hlth_Indem_Totals a
                                    WHERE a.Contract_Id = p_Contract_Id
                                        AND p_Partition_No IS NULL
                                        AND Trans_Contract_Id IS NOT NULL
                                    ORDER BY 3)
        LOOP
            Anyclm := FALSE;

            FOR Par IN (SELECT DISTINCT Oar_No Partition_No,
                                                                    Contract_Id
                                        FROM Clm_Pol_Oar a
                                     WHERE Contract_Id = Main.Contract_Id
                                         AND (Oar_No = Main.Partition_No OR Main.Partition_No IS NULL))
            LOOP
                BEGIN
                    v_Contract_Id  := Main.Contract_Id;
                    v_Partition_No := Par.Partition_No;
                    Anyclm         := TRUE;

                    BEGIN
                        SELECT Ip_No
                            INTO p_Ip_No
                            FROM Ocp_Ip_Links b
                         WHERE b.Role_Type = 'INS'
                             AND b.Top_Indicator = 'Y'
                             AND b.Contract_Id = v_Contract_Id
                             AND b.Partition_No = v_Partition_No
                             AND Rownum < 2;

                        SELECT a.Partner_Id
                            INTO p_Part_Id
                            FROM Ocp_Interested_Parties a
                         WHERE a.Contract_Id = v_Contract_Id
                             AND a.Ip_No = p_Ip_No
                             AND a.Top_Indicator = 'Y'
                             AND Rownum < 2;
                    EXCEPTION
                        WHEN OTHERS THEN
                            p_Part_Id := NULL;
                    END;

                    UPDATE Koc_Clm_Hlth_Indem_Totals
                         SET r_Cover_Price = f_Cover_Price
                     WHERE Contract_Id = v_Contract_Id
                         AND Partition_No = v_Partition_No
                         AND Nvl(Is_Unlimited, 0) = 0;

                    UPDATE Koc_Clm_Hlth_Indem_Totals
                         SET r_Exemption_Sum = f_Exemption_Sum,
                                 r_Day_Seance    = f_Day_Seance
                     WHERE Contract_Id = v_Contract_Id
                         AND Partition_No = v_Partition_No;

                    UPDATE Koc_Clm_Hlth_Indem_Totals a
                         SET a.s_Spend_Total      = 0,
                                 a.s_Exemption_Sum    = 0,
                                 a.s_Indemnity_Amount = 0,
                                 a.s_Provision_Amount = 0,
                                 a.s_Spend_Day_Seance = 0
                     WHERE a.Contract_Id = v_Contract_Id
                         AND a.Partition_No = v_Partition_No;

                    Roldcontract := NULL;

                    OPEN Oldcontract(v_Contract_Id, v_Partition_No);
                    FETCH Oldcontract
                        INTO Roldcontract;
                    CLOSE Oldcontract;

                    Rnewcontract := NULL;
                    OPEN Newcontract(v_Contract_Id, v_Partition_No);
                    FETCH Newcontract
                        INTO Rnewcontract;
                    CLOSE Newcontract;

                    IF Roldcontract.Contract_Id IS NOT NULL
                    THEN
                        Koc_Hlth_Clm_Transfer.New_Indem_Total_Update(Roldcontract.Contract_Id, Roldcontract.Partition_No, Rnewcontract);
                    END IF;

                    FOR t IN (
                                        /* SELECT c.contract_id
                                                                                         , c.oar_no partition_no
                                                                                         , a.claim_inst_type
                                                                                         , a.claim_inst_loc
                                                                                         , koc_clm_hlth_utils.getcountrygroup(a.country_code)country_group
                                                                                         , b.cover_code
                                                                                         , NVL (b.is_pool_cover, 0) is_pool_cover
                                                                                         , NVL (b.is_special_cover, 0) is_special_cover
                                                                                         , NVL (a.swift_code, b.swift_code) swift_code
                                                                                         , a.date_of_loss main_date
                                                                                         , NVL (a.provision_date, a.invoice_date) prov_date
                                                                                         , NVL (a.provision_date, a.realization_date) realiza_date
                                                                                         , SUM (NVL (b.request_amount, 0) - NVL (b.refusal_amount, 0) - NVL (b.exemption_amount, 0)) spend_total
                                                                                         , SUM (NVL (b.provision_total, 0)) prov_amount
                                                                                         , SUM (DECODE (a.status_code,'TAH', NVL (b.provision_total, 0),'ODE', NVL (b.provision_total, 0),0)) indem_total
                                                                                         , DECODE (a.status_code, 'TAH', 1, 'ODE', 1, 0)
                                                                                         , NVL (b.req_cure_day_count, 0) req_cure_day_count
                                                                                         , NVL (b.day_seance, 0) day_seance
                                                                                         , b.exemption_rate
                                                                                         , b.prov_date_time
                                                                                         , a.claim_id
                                                                                         , a.provision_user_id
                                                                                         , nvl(b.sub_package_id, a.package_id) package_id
                                                                                         , nvl(b.sub_package_date, a.package_date) package_date
                                                                                         , SUM (nvl(b.exemption_amount, 0)) exemption_amount
                                                                                      FROM koc_clm_hlth_detail a
                                                                                         , koc_clm_hlth_provisions b
                                                                                         , clm_pol_oar c
                                                                                     WHERE a.claim_id     = b.claim_id
                                                                                       AND a.sf_no        = b.sf_no
                                                                                       AND a.add_order_no = b.add_order_no
                                                                                       AND a.claim_id     = c.claim_id
                                                                                       AND c.contract_id  = v_contract_id
                                                                                       AND c.oar_no       = v_partition_no
                                                                                      -- AND b.status_code NOT IN ('R', 'C', 'I', 'H', 'TI')
                                                                                      -- AND a.status_code IN ('P', 'KI', 'TAH', 'ODE', 'MI')
                                                                                       AND (b.status_code NOT IN ( 'R', 'C', 'I', 'H', 'TI') or
                                                                                           (b.status_code  = 'R' and  a.claim_id in(select claim_id from KOC_CLM_HLTH_REJECT_LOSS
                                                                                                                                                          where MAIN_CODE = '18' AND
                                                                                                                                                                ITEM_CODE ='11' AND
                                                                                                                                                                SUB_ITEM_CODE = '11' and
                                                                                                                                                                claim_id =a.claim_id and
                                                                                                                                                                sf_no = a.sf_no)))
                                                                                       AND (a.status_code IN ('P', 'KI', 'TAH', 'ODE', 'MI')
                                                                                           Or a.status_code = 'R' And B.status_code = 'P' And a.provision_user_id Like 'ECZ%'
                                                                                           )
                                                                                     GROUP BY c.contract_id, c.oar_no, a.claim_inst_type, a.claim_inst_loc,
                                                                                              a.country_code, b.cover_code, b.is_pool_cover, b.is_special_cover,
                                                                                              a.swift_code, b.swift_code, a.date_of_loss, a.realization_date,
                                                                                              DECODE (a.status_code, 'TAH', 1, 'ODE', 1, 0),
                                                                                              a.date_of_loss, NVL (a.provision_date, a.invoice_date),
                                                                                              NVL (a.provision_date, a.realization_date), b.req_cure_day_count,
                                                                                              b.day_seance, b.exemption_rate, b.prov_date_time, a.claim_id,
                                                                                              a.provision_user_id, nvl(b.sub_package_id, a.package_id)
                                                                                              , nvl(b.sub_package_date, a.package_date)
                                                                                     ORDER BY NVL (b.prov_date_time,TO_DATE ('01/01/1985', 'dd/mm/yyyy')) Asc*/

                                        SELECT c.Contract_Id,
                                                        c.Oar_No Partition_No,
                                                        a.Claim_Inst_Type,
                                                        a.Claim_Inst_Loc,
                                                        Koc_Clm_Hlth_Utils.Getcountrygroup(a.Country_Code) Country_Group,
                                                        b.Cover_Code,
                                                        Nvl(b.Is_Pool_Cover, 0) Is_Pool_Cover,
                                                        Nvl(b.Is_Special_Cover, 0) Is_Special_Cover,
                                                        Nvl(a.Swift_Code, b.Swift_Code) Swift_Code,
                                                        Nvl(a.Date_Of_Loss, a.Provision_Date) Main_Date,
                                                        Nvl(a.Provision_Date, a.Invoice_Date) Prov_Date,
                                                        Nvl(a.Provision_Date, a.Realization_Date) Realiza_Date,                                               
                                                        SUM(Nvl(b.Request_Amount, 0) - Nvl(b.Refusal_Amount, 0) - Nvl(b.Exemption_Amount, 0)) Spend_Total,
                                                        SUM(Nvl(b.Provision_Total, 0)) Prov_Amount,
                                                        SUM(Decode(a.Status_Code, 'TAH', Nvl(b.Provision_Total, 0), 'ODE', Nvl(b.Provision_Total, 0), 0)) Indem_Total,
                                                        Decode(a.Status_Code, 'TAH', 1, 'ODE', 1, 0),
                                                        Nvl(b.Req_Cure_Day_Count, 0) Req_Cure_Day_Count,
                                                        Nvl(b.Day_Seance, 0) Day_Seance,
                                                        b.Exemption_Rate,
                                                        b.Prov_Date_Time,
                                                        a.Claim_Id,
                                                        a.Add_Order_No,
                                                        a.Provision_User_Id,
                                                        Nvl(b.Sub_Package_Id, a.Package_Id) Package_Id,
                                                        Nvl(b.Sub_Package_Date, a.Package_Date) Package_Date,
                                                        SUM(Nvl(b.Exemption_Amount, 0)) Exemption_Amount
                                            FROM Koc_Clm_Hlth_Detail     a,
                                                        Koc_Clm_Hlth_Provisions b,
                                                        Clm_Pol_Oar             c
                                         WHERE a.Claim_Id = b.Claim_Id
                                             AND a.Sf_No = b.Sf_No
                                             AND a.Add_Order_No = b.Add_Order_No
                                             AND a.Claim_Id = c.Claim_Id
                                             AND c.Contract_Id = v_Contract_Id
                                             AND c.Oar_No = v_Partition_No
                                             AND ((b.Status_Code NOT IN ('PP', 'R', 'C', 'I', 'H', 'TI') OR
                                                     ((b.Status_Code = 'R' AND EXISTS (SELECT NULL
                                                                                                                                 FROM Koc_Clm_Hlth_Reject_Loss r
                                                                                                                                WHERE r.Main_Code = '18'
                                                                                                                                    AND r.Item_Code = '11'
                                                                                                                                    AND r.Sub_Item_Code = '11'
                                                                                                                                    AND r.Claim_Id = a.Claim_Id
                                                                                                                                    AND r.Sf_No = a.Sf_No
                                                                                                                                    AND r.Add_Order_No = a.Add_Order_No
                                                                                                                                    AND r.Cover_Code = b.Cover_Code)) OR
                                                     (b.Status_Code = 'R' AND a.Status_Code = 'R' AND EXISTS
                                                        (SELECT NULL
                                                                    FROM Koc_Clm_Hlth_Reject_Loss r
                                                                 WHERE r.Main_Code = '18'
                                                                     AND r.Item_Code = '11'
                                                                     AND r.Sub_Item_Code = '11'
                                                                     AND r.Claim_Id = a.Claim_Id
                                                                     AND r.Sf_No = a.Sf_No
                                                                     AND r.Add_Order_No = a.Add_Order_No
                                                                     AND r.Cover_Code = '0'
                                                                     AND r.Process_Code_Main = 0
                                                                     AND r.Process_Code_Sub1 = 0
                                                                     AND r.Process_Code_Sub2 = 0)))) OR
                                                     (a.Status_Code IN ('P', 'KI', 'TAH', 'ODE', 'MI') OR
                                                     (a.Status_Code = 'R' AND b.Status_Code = 'P' AND a.Provision_User_Id LIKE 'ECZ%')))
                                         GROUP BY c.Contract_Id,
                                                             c.Oar_No,
                                                             a.Claim_Inst_Type,
                                                             a.Claim_Inst_Loc,
                                                             a.Country_Code,
                                                             b.Cover_Code,
                                                             b.Is_Pool_Cover,
                                                             b.Is_Special_Cover,
                                                             a.Swift_Code,
                                                             b.Swift_Code,
                                                             NVL(a.Date_Of_Loss, a.Provision_Date), --a.Date_Of_Loss,
                                                             a.Realization_Date,
                                                             Decode(a.Status_Code, 'TAH', 1, 'ODE', 1, 0),
                                                             a.Date_Of_Loss,
                                                             Nvl(a.Provision_Date, a.Invoice_Date),
                                                             Nvl(a.Provision_Date, a.Realization_Date),
                                                             b.Req_Cure_Day_Count,
                                                             b.Day_Seance,
                                                             b.Exemption_Rate,
                                                             b.Prov_Date_Time,
                                                             a.Claim_Id,
                                                             a.Add_Order_No,
                                                             a.Provision_User_Id,
                                                             Nvl(b.Sub_Package_Id, a.Package_Id),
                                                             Nvl(b.Sub_Package_Date, a.Package_Date)
                                         ORDER BY a.Claim_Id,
                                                             Nvl(b.Prov_Date_Time, To_Date('01/01/1985', 'dd/mm/yyyy')) ASC)
                    LOOP

                        BEGIN

                            v_Claim_Id     := t.Claim_Id;
                            v_Prov_Amount  := Nvl(t.Prov_Amount, 0);
                            v_Exemp_Amount := Nvl(t.Exemption_Amount, 0);

                            IF t.Exemption_Rate != 1
                            THEN
                                v_Prov_Amount := (v_Prov_Amount * (1 / (1 - t.Exemption_Rate)));
                            END IF;

                            v_Sum_Claim_Amount := v_Prov_Amount + v_Exemp_Amount;
                            
                            SELECT institute_code 
                              INTO g_institute_code
                              FROM koc_clm_hlth_detail
                             WHERE claim_id = t.claim_id
                              AND add_order_no = 1
                              AND sf_no = 1;

                            Koc_Clm_Hlth_Trnx.Computeremaning(t.Contract_Id, t.Partition_No, p_Part_Id, t.Claim_Id, NULL, g_institute_code, t.Claim_Inst_Type, t.Claim_Inst_Loc,
                                                                                                t.Country_Group, NULL, t.Cover_Code, t.Swift_Code, t.Main_Date, t.Prov_Date, t.Realiza_Date,
                                                                                                t.Prov_Date_Time,v_Sum_Claim_Amount, t.Req_Cure_Day_Count, NULL, t.Is_Pool_Cover, t.Is_Special_Cover,
                                                                                                1, p_Out_Provision_Amount, p_Out_Day_Seance, p_Out_Exemption_Rate, p_Out_Exemption_Sum,
                                                                                                p_Out_Inst_Exemp_Sum, p_r_Day_Seance, p_r_Cover_Price, p_Inst_Provision_Aval_Code, p_Inst_Is_Cover_Val,
                                                                                                p_Out_Over_Price, v_Exemp_Amount
                                                                                                 -- Muafiyet tutar�n� d�zenleme
                                                                                                );
                                                                                                
                           /*computeRemainingForCover(t.Contract_Id, 
                                          t.Partition_No,
                                          t.Claim_Id,
                                          t.Cover_Code, 
                                          t.Is_Pool_Cover,
                                          t.Is_Special_Cover,                                    
                                          null, --t.Institute_Code,
                                          t.Claim_Inst_Type,
                                          t.Claim_Inst_Loc,
                                          t.Country_Group,                                          
                                          t.main_date,
                                          '1');
                                                                                                                                         
                             g_ProvOutParamRec := getRemainingForCover(t.Cover_Code);
                             
                             p_Out_Provision_Amount   := g_ProvOutParamRec.Provision_Amount;
                             p_Out_Day_Seance         := g_ProvOutParamRec.Day_Seance;
                             p_Out_Exemption_Rate     := g_ProvOutParamRec.Exemption_Rate; 
                             p_Out_Exemption_Sum      := g_ProvOutParamRec.Exemption_Sum;                              
                             p_Out_Inst_Exemption_Sum := g_ProvOutParamRec.Inst_Exemp_Sum;
                             p_r_Day_Seance           := g_ProvOutParamRec.Remained_Day_Seance;
                             p_r_Cover_Price          := g_ProvOutParamRec.Remained_Cover_Price;
                             p_Out_Over_Price         := g_ProvOutParamRec.Over_Price;  */  
                            --aaktas
                            --koc_clm_hlth_trnx.computeremaning i�erisinde farkl� de�erlerle limitten d��t��� i�in
                            --�nce trnx te d��t��� tutar limite tekrar eklenerek burada hesaplanan tutar limitten d���r�l�yor
                            --spend_total ve exempton_sum kald�r�ld�
                            UPDATE Koc_Clm_Hlth_Indem_Totals a
                                 SET s_Indemnity_Amount = Nvl(s_Indemnity_Amount, 0) + Nvl(t.Indem_Total, 0),
                                         s_Provision_Amount = Decode(Sign(Nvl(s_Provision_Amount, 0) - Nvl(t.Indem_Total, 0)), -1, 0,
                                                                                                 Nvl(s_Provision_Amount, 0) - Nvl(t.Indem_Total, 0))
                             WHERE a.Contract_Id = t.Contract_Id
                                 AND (a.Partition_No = t.Partition_No OR a.Partition_No = Decode(t.Is_Pool_Cover, 0, t.Partition_No, 0))
                                 AND a.Claim_Inst_Loc = t.Claim_Inst_Loc
                                 AND a.Claim_Inst_Type = t.Claim_Inst_Type
                                 AND a.Country_Group = Nvl(t.Country_Group, 0)
                                 AND a.Is_Pool_Cover = t.Is_Pool_Cover
                                 AND a.Is_Special_Cover = t.Is_Special_Cover
                                 AND a.Cover_Code = t.Cover_Code
                                 AND a.Is_Valid = 1
                                 AND a.Package_Id = t.Package_Id
                                 AND a.Package_Date = t.Package_Date
                                 AND a.Validity_Start_Date = (SELECT MAX(Aa.Validity_Start_Date)
                                                                                                FROM Koc_Clm_Hlth_Indem_Totals Aa
                                                                                             WHERE Aa.Contract_Id = a.Contract_Id
                                                                                                 AND Aa.Partition_No = a.Partition_No
                                                                                                 AND Aa.Claim_Inst_Type = a.Claim_Inst_Type
                                                                                                 AND Aa.Claim_Inst_Loc = a.Claim_Inst_Loc
                                                                                                 AND Aa.Country_Group = a.Country_Group
                                                                                                 AND Aa.Cover_Code = a.Cover_Code
                                                                                                 AND Aa.Is_Special_Cover = a.Is_Special_Cover
                                                                                                 AND Aa.Is_Pool_Cover = a.Is_Pool_Cover
                                                                                                 AND Aa.Package_Date = a.Package_Date
                                                                                                 AND Aa.Package_Id = a.Package_Id
                                                                                                 AND Nvl(Aa.Is_Valid, 0) = 1
                                                                                                 AND Aa.Validity_Start_Date <= t.Prov_Date);

                        EXCEPTION
                            WHEN OTHERS THEN

                                v_Err      := SQLERRM;
                                v_Err_Mess := v_Err_Mess || ',' || v_Partition_No;

                                p_Indemrec := NULL;

                                IF SQLCODE = -20222
                                THEN
                                    p_Indemrec.Log_Type := 'NO_COVER_CODE'; --neslihank teminat yoksa kullan�c� uyar�lacak
                                ELSE
                                    p_Indemrec.Log_Type := 'COMPUTEREMANING_ERROR';
                                END IF;

                                p_Indemrec.Contract_Id      := t.Contract_Id;
                                p_Indemrec.Partition_No     := t.Partition_No;
                                p_Indemrec.Country_Group    := t.Country_Group;
                                p_Indemrec.Claim_Inst_Type  := t.Claim_Inst_Type;
                                p_Indemrec.Claim_Inst_Loc   := t.Claim_Inst_Loc;
                                p_Indemrec.Is_Pool_Cover    := t.Is_Pool_Cover;
                                p_Indemrec.Is_Special_Cover := t.Is_Special_Cover;
                                p_Indemrec.Cover_Code       := t.Cover_Code;
                                p_Indemrec.Package_Id       := t.Package_Id;
                                p_Indemrec.Package_Date     := t.Package_Date;
                                p_Indemrec.Claim_Id         := t.Claim_Id;
                                p_Indemrec.Add_Order_No     := t.Add_Order_No;
                                p_Indemrec.Log_Detail       := Substr(SQLERRM, 1, 200);
                                p_Indemrec.Log_State        := 'COMPUTEREMANING';
                                p_Indemrec.Log_Status       := 0;
                                p_Indemrec.Online_Sq_No     := p_Err_Seq;

                                Koc_Indemnity_Utils.Insert_Indem_Totals_Log(p_Indemrec, NULL, NULL);

                        END;
                    END LOOP;

                    --aaktas
                    --1KEZ kullan�lm�� ise
                    --AK da harcanan teminatlar� AHK dan d��
                   /* Vhaspolicy1kez := Koc_Clm_Hlth_Trnx.Checkpolicyforindemnity(Rnewcontract.Contract_Id, Rnewcontract.Partition_No, Rnewcontract.Package_Id,
                                                                                                                                            Rnewcontract.Package_Date, Trunc(SYSDATE), '1KEZ');

                    --
                    IF Vhaspolicy1kez = 1
                    THEN

                        --hasar dosyalar�nda 1KEZ teminat� kullan�lm�� m�
                        Vis1kezused := Koc_Clm_Hlth_Trnx.Checkprovisionforindemnity(Rnewcontract.Contract_Id, Rnewcontract.Partition_No, Rnewcontract.Package_Id,
                                                                                                                                                Rnewcontract.Package_Date, Trunc(SYSDATE), '1KEZ');
                    END IF;

                    IF Vis1kezused = 1
                    THEN
                        --setremaininglimitfor1KEZ i�erisinde gl_is1Kezused kullan�ld��� i�in set ediyoruz.
                        Koc_Clm_Hlth_Trnx.Set_Glis1kezused(Vis1kezused);
                        Koc_Clm_Hlth_Trnx.Setremaininglimitfor1kez(Rnewcontract.Contract_Id, Rnewcontract.Partition_No);
                    END IF;*/

                    IF p_Call_Type = 1
                    THEN
                        COMMIT;
                    END IF;

                EXCEPTION
                    WHEN OTHERS THEN

                        v_Err      := SQLERRM;
                        v_Err_Mess := v_Err_Mess || ',' || v_Partition_No;
                        p_Indemrec := NULL;

                        p_Indemrec.Contract_Id  := v_Contract_Id;
                        p_Indemrec.Partition_No := v_Partition_No;
                        p_Indemrec.Log_Type     := 'SETREMAININGLIMITFOR1KEZ';
                        p_Indemrec.Log_Detail   := Substr(SQLERRM, 1, 200);
                        p_Indemrec.Log_State    := 'PR_CLM_HLTH_SET_REMAINING';
                        p_Indemrec.Log_Status   := 0;
                        p_Indemrec.Online_Sq_No := p_Err_Seq;

                        Koc_Indemnity_Utils.Insert_Indem_Totals_Log(p_Indemrec, NULL, NULL);

                END;

            END LOOP;

            BEGIN
                IF NOT Anyclm AND
                     Main.Partition_No IS NOT NULL
                THEN
                    v_Partition_No := Main.Partition_No;
                    v_Contract_Id  := Main.Contract_Id;

                    UPDATE Koc_Clm_Hlth_Indem_Totals
                         SET r_Cover_Price = f_Cover_Price
                     WHERE Contract_Id = v_Contract_Id
                         AND Partition_No = v_Partition_No
                         AND Nvl(Is_Unlimited, 0) = 0;

                    UPDATE Koc_Clm_Hlth_Indem_Totals
                         SET r_Exemption_Sum = f_Exemption_Sum,
                                 r_Day_Seance    = f_Day_Seance
                     WHERE Contract_Id = v_Contract_Id
                         AND Partition_No = v_Partition_No;

                    UPDATE Koc_Clm_Hlth_Indem_Totals a
                         SET a.s_Spend_Total      = 0,
                                 a.s_Exemption_Sum    = 0,
                                 a.s_Indemnity_Amount = 0,
                                 a.s_Provision_Amount = 0,
                                 a.s_Spend_Day_Seance = 0
                     WHERE Contract_Id = v_Contract_Id
                         AND Partition_No = v_Partition_No;

                    OPEN Oldcontract(v_Contract_Id, v_Partition_No);
                    FETCH Oldcontract
                        INTO Roldcontract;
                    CLOSE Oldcontract;

                    OPEN Newcontract(v_Contract_Id, v_Partition_No);
                    FETCH Newcontract
                        INTO Rnewcontract;
                    CLOSE Newcontract;

                    IF Roldcontract.Contract_Id IS NOT NULL
                    THEN
                        Koc_Hlth_Clm_Transfer.New_Indem_Total_Update(Roldcontract.Contract_Id, Roldcontract.Partition_No, Rnewcontract);
                    END IF;
                END IF;
            EXCEPTION
                WHEN OTHERS THEN

                    v_Err      := SQLERRM;
                    v_Err_Mess := v_Err_Mess || ',' || v_Partition_No;
                    p_Indemrec := NULL;

                    p_Indemrec.Contract_Id  := v_Contract_Id;
                    p_Indemrec.Partition_No := v_Partition_No;
                    p_Indemrec.Log_Type     := 'NO_CLAIM_ERROR';
                    p_Indemrec.Log_Detail   := Substr(SQLERRM, 1, 200);
                    p_Indemrec.Log_State    := 'PR_CLM_HLTH_SET_REMAINING';
                    p_Indemrec.Log_Status   := 0;
                    p_Indemrec.Online_Sq_No := p_Err_Seq;

                    Koc_Indemnity_Utils.Insert_Indem_Totals_Log(p_Indemrec, NULL, NULL);
            END;

            IF p_Call_Type = 1
            THEN
                COMMIT;
            END IF;
        END LOOP;

        p_Err_Msg := 'hata alanlar:' || v_Err_Mess;
    END Pr_Clm_Hlth_Set_Remaining;
    
    BEGIN

       Pr_Clm_Hlth_Set_Remaining(v_Contract_Id, v_Partition_No, v_Pool_Calc, v_Calc_Type, v_Err_Seq, v_Err_Msg);
       dbms_output.put_line(v_Err_Msg);
    
    END;
