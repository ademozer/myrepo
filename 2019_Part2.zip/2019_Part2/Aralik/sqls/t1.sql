select * from ocp_policy_bases where policy_ref='0001171006128482';
select * from ocp_policy_bases where policy_ref='0001171006129172';
0001 1710 0612 9172

select * from clm_pol_oar where contract_id=453413447 and oar_no=161;
select * from clm_pol_oar where contract_id=489033702 and oar_no=249
select * from koc_clm_hlth_provisions where claim_id in(select claim_id from clm_pol_oar where contract_id=453413447 and oar_no=161);
select * from koc_clm_hlth_provisions where claim_id in(select claim_id from clm_pol_oar where contract_id=489033702 and oar_no=249);
select * from alz_hclm_version_info where claim_id=43544647;
select * from koc_clm_hlth_detail where claim_id=43544647;

select * from alz_hclm_institute_info where institute_code=46;

select * from koc_clm_hlth_indem_totals where contract_id=453413447 and partition_no=161 and cover_code='S552'
select * from koc_clm_hlth_indem_totals where contract_id=489033702 and partition_no=249 and cover_code='S703'
select * from koc_clm_hlth_indem_totals where contract_id=489033702 and partition_no=0 and parent_cover_code='S699' and package_id=282653


select * from koc_auth_user_role_rel where username='WKGURLU'
