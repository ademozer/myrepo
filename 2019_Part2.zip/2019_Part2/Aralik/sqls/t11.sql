    SELECT f.institute_code/*,
           CASE
             WHEN LOWER(b.district_name) = LOWER(:t_district) AND
                  LOWER(a.city_name) = LOWER(:t_city) -- ZONGULDAK
              THEN
              1 -- error: hata alacak
             WHEN LOWER(b.district_name) <> LOWER(:t_district)
             --AND LOWER (a.city_name) <> LOWER (:t_city)   -- ZONGULDAK
              THEN
              0 --UYARI: Ayny Kurum i�in farkly lokasyon kaydy olu?turuyor
           END result*/
      FROM koc_cp_cities_ref    a,
           koc_cp_districts_ref b,
           koc_cp_address_links c,
           koc_cp_address_ext   d,
           koc_cp_partners_ext  e,
           koc_v_clm_suppliers  f
     WHERE a.city_code = b.city_code
       AND a.country_code = 'TR'
       AND d.city_code = a.city_code
       AND d.district_code = b.district_code
       AND e.part_id = f.part_id
          --       AND LOWER (a.city_name) = LOWER (:t_city)                  -- ZONGULDAK
          --       AND LOWER (b.district_name) = LOWER (:t_district)
       AND c.add_id = d.add_id
       AND c.part_id = e.part_id
       AND e.tax_number = '0580016099'
       AND f.Exp_Date IS NULL
          --AND f.institute_code = :t_institute_code
       /*AND 1 = CASE
             WHEN :t_institute_code IS NULL THEN
              1
             ELSE
              CASE
                WHEN f.institute_code = :t_institute_code THEN
                 0
                ELSE
                 1
              END
           END;0*/
           
           SELECT ABS(5-7) FROM DUAL
         
