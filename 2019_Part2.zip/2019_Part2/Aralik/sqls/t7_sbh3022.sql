select policy_ref,sira_no,note_id,count(*) from sbh3022
group by policy_ref,sira_no,note_id
having count(*)>1


select distinct policy_ref as Police_No, sira_no,text as �la�_Notu_A��klamas�, CASE WHEN (select count(*) from sbh3022 where note_id = a.note_id and prescription_status='ONAYLI')>0 THEN 'VAR' ELSE 'YOK' END ER_DURUMU
from sbh3022 a

select distinct a.policy_ref as Police_No, a.sira_no, a.claim_id, a.text,  a.barcode, b.medicine_name, a.prescription_status
from sbh3022 a, 
     (select barcode, medicine_name 
  from koc_cc_medicines m
 where 1=1
   and validity_date = (select max(validity_date) from koc_cc_medicines where barcode=m.barcode)) b   
where a.barcode = b.barcode 
order by 1,2,3

select barcode, medicine_name 
  from koc_cc_medicines m
 where barcode=8699532095534
   and validity_date = (select max(validity_date) from koc_cc_medicines where barcode=m.barcode)
   
