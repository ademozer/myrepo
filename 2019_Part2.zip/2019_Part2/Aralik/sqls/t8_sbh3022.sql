create table sbh3022 as select distinct p.policy_ref, a.sub_level1 as S�ra_No, a.note_id, c.barcode, c.claim_id,  n.text, c.prescription_status                                                                                              
  from ocp_policy_bases@opusprep p, 
       koc_notes_authorization@opusprep a,
       koc_clm_auto_prescriptions@opusprep c,
       koc_notes@opusprep n
 where p.contract_id = a.INS_OBJ_UID 
   and a.note_id = n.note_id
   and a.note_type = 'ILAC'
   and a.medicine_note_id = 999
   and a.note_id = c.note_id
   and p.term_start_date>TO_DATE('01/12/2018','DD/MM/YYYY')
   --and rownum<10
