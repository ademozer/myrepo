select * from koc_clm_hlth_reject_loss where claim_id=43913980
select * from alz_hclm_version_info where claim_id=43913976;
select * from koc_clm_hlth_detail where  claim_id=43680829;
