select * from clm_subfiles where ext_reference='59363217';
select * from clm_pol_oar where claim_id=43516295
select * from clm_pol_oar where contract_id=494731011 and oar_no=5
--select * from alz_hclm_version_info where claim_id=43516295
select * from koc_clm_hlth_reject_loss where
claim_id in(43533934,
43516295,
42638317
)


select * from koc_clm_hlth_provisions where claim_id in(43533934,
43516295,
42638317
)

select * from koc_clm_hlth_detail where ext_reference='59658706'
select * from alz_hclm_version_info where claim_id=43895602 for update
