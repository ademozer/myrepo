select * from koc_oc_packages where ext_reference='S4914-22'

263647
select * from koc_oc_hlth_expack_cov_rel where package_id=263647 and sub_rule_code=30 and child_cover_code='S500'  and claim_inst_type='AK' and claim_inst_loc='YI'
--and institude_group_code=20
select * from koc_oc_hlth_expack_cov_rel_his where package_id=263647 and package_date = TO_DATE('27/04/2019','DD/MM/YYYY') 
and sub_rule_code=30 and child_cover_code='S500' and claim_inst_type='AK' and claim_inst_loc='YI' and exemption_rate > 0--and institude_group_code=20;

KOC_CLM_HLTH_BPM_UTILS
