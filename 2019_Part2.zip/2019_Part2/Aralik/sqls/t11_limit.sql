﻿select * from ocp_policy_bases where policy_ref = '0001171006126995'

select * from koc_clm_hlth_indem_totals_log where contract_id =369341525 and partition_no=185 order by entry_date desc;
select * from alz_hltprv_log where log_id=155334029;



--[‎12/‎10/‎2019 9:20 AM]  Canan Evran:  
0001 1710 0612 6995 -185;

koc_clm_hlth_status;

KOC_GROUP_HEALTH_UTILS2;

select * from koc_clm_hlth_status_his@opusdev
 


alz_hclm_converter_utils;

select * from koc_clm_hlth_prov_statemnt;

koc_hlth_clm_transfer.pr_clm_hlth_set_remaining
