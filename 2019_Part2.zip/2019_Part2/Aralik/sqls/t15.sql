select * from clm_subfiles where ext_reference='59564167';
select * from koc_clm_hlth_detail where ext_reference='59564167';
select * from clm_pol_oar where claim_id=43774269;
select * from clm_pol_oar where contract_id=473828120 and oar_no=1
select * from alz_hclm_version_info where claim_id=43774313--43774269
select * from koc_clm_hlth_provisions where claim_id in(43581458,
43774269,
43774313,
43774709
)

select * from alz_hlth_detail_hist where ext_reference='59564167';
select * from koc_clm_hlth_indem_totals where contract_id=442787105 and partition_no=326 and cover_code='S511'

442787105 - 326
