DECLARE
  v_result NUMBER;
  v_claim_id NUMBER := 44245241;
BEGIN
  v_result := Koc_Clm_Hlth_Bpm_Utils.Update_Uncompleted_Claim(v_claim_id);
  
  DBMS_OUTPUT.PUT_LINE('result=' || v_result);
  
END;
