  update koc_cp_partners_ext
     set identity_no = '11111111111'
   where part_id IN (81810329, 121675978);
   
  update koc_cp_partners_ext
    set identity_no = '10246118384'
  where part_id = 31380222;
  
   update koc_cp_partners_ext
    set identity_no = '12529104138'
  where part_id = 29953955;
