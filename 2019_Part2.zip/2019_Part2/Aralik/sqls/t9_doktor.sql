select * from Hst_Cc_Web_Inst_Doctor where institute_code=1289 and doctor_name='�AH�N' and doctor_surname='KABAY' order by 3
select * from koc_clm_hlth_detail where institute_code=1289 and process_Date>(sysdate-3) and 
--18383292332
select * from clm_pol_bases where claim_id=43763686
select * from clm_subfiles  where claim_id=43763686
--1720
2700
--59733717 eski dosya ret
select * from Alz_Branch_Code_Cgm_Rel where branchcodeallz='1720';

select * from Hst_Cc_Web_Inst_Doctor where institute_code=1289 and doctor_name='�AH�N' and doctor_surname='KABAY' for update;

select * from alz_hclm_institute_info where institute_code=1407 for update;


502084
--153169337, 153169346
select * from koc_clm_suppliers_ext where institute_code=1407 for update
select * from 
