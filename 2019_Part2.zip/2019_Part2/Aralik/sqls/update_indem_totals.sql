update koc_clm_hlth_indem_totals 
   set r_day_seance = 1
 where contract_id= 445493185 
   and partition_no=114 
   and cover_code='S539';
   
commit;

