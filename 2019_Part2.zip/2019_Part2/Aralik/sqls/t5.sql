select * from customer.alz_duplicate_provision where ext_reference='59715680';
--59734728 eski sistem

select * from alz_hltprv_log where log_id=152748663;
select * from koc_clm_suppliers_ext where institute_code='1114' for update;
select * from alz_hclm_institute_info where institute_code='1114'  for update;

500265
1114
