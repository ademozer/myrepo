                                      SELECT c.Contract_Id,
                                                        c.Oar_No Partition_No,
                                                        a.Claim_Inst_Type,
                                                        a.Claim_Inst_Loc,
                                                        Koc_Clm_Hlth_Utils.Getcountrygroup(a.Country_Code) Country_Group,
                                                        b.Cover_Code,
                                                        Nvl(b.Is_Pool_Cover, 0) Is_Pool_Cover,
                                                        Nvl(b.Is_Special_Cover, 0) Is_Special_Cover,
                                                        Nvl(a.Swift_Code, b.Swift_Code) Swift_Code,
                                                        Nvl(a.Date_Of_Loss, a.Provision_Date) Main_Date,
                                                        Nvl(a.Provision_Date, a.Invoice_Date) Prov_Date,
                                                        Nvl(a.Provision_Date, a.Realization_Date) Realiza_Date,
                                                        SUM(Nvl(b.Request_Amount, 0) - Nvl(b.Refusal_Amount, 0) - Nvl(b.Exemption_Amount, 0)) Spend_Total,
                                                        SUM(Nvl(b.Provision_Total, 0)) Prov_Amount,
                                                        SUM(Decode(a.Status_Code, 'TAH', Nvl(b.Provision_Total, 0), 'ODE', Nvl(b.Provision_Total, 0), 0)) Indem_Total,
                                                        Decode(a.Status_Code, 'TAH', 1, 'ODE', 1, 0),
                                                        Nvl(b.Req_Cure_Day_Count, 0) Req_Cure_Day_Count,
                                                        Nvl(b.Day_Seance, 0) Day_Seance,
                                                        b.Exemption_Rate,
                                                        b.Prov_Date_Time,
                                                        a.Claim_Id,
                                                        a.Add_Order_No,
                                                        a.Provision_User_Id,
                                                        Nvl(b.Sub_Package_Id, a.Package_Id) Package_Id,
                                                        Nvl(b.Sub_Package_Date, a.Package_Date) Package_Date,
                                                        SUM(Nvl(b.Exemption_Amount, 0)) Exemption_Amount
                                            FROM Koc_Clm_Hlth_Detail     a,
                                                        Koc_Clm_Hlth_Provisions b,
                                                        Clm_Pol_Oar             c
                                         WHERE a.Claim_Id = b.Claim_Id
                                             AND a.Sf_No = b.Sf_No
                                             AND a.Add_Order_No = b.Add_Order_No
                                             AND a.Claim_Id = c.Claim_Id
                                             AND c.Contract_Id = 485359680
                                             AND c.Oar_No = 508
                                             AND ((b.Status_Code NOT IN ('PP', 'R', 'C', 'I', 'H', 'TI') OR
                                                     ((b.Status_Code = 'R' AND EXISTS (SELECT NULL
                                                                                                                                 FROM Koc_Clm_Hlth_Reject_Loss r
                                                                                                                                WHERE r.Main_Code = '18'
                                                                                                                                    AND r.Item_Code = '11'
                                                                                                                                    AND r.Sub_Item_Code = '11'
                                                                                                                                    AND r.Claim_Id = a.Claim_Id
                                                                                                                                    AND r.Sf_No = a.Sf_No
                                                                                                                                    AND r.Add_Order_No = a.Add_Order_No
                                                                                                                                    AND r.Cover_Code = b.Cover_Code)) OR
                                                     (b.Status_Code = 'R' AND a.Status_Code = 'R' AND EXISTS
                                                        (SELECT NULL
                                                                    FROM Koc_Clm_Hlth_Reject_Loss r
                                                                 WHERE r.Main_Code = '18'
                                                                     AND r.Item_Code = '11'
                                                                     AND r.Sub_Item_Code = '11'
                                                                     AND r.Claim_Id = a.Claim_Id
                                                                     AND r.Sf_No = a.Sf_No
                                                                     AND r.Add_Order_No = a.Add_Order_No
                                                                     AND r.Cover_Code = '0'
                                                                     AND r.Process_Code_Main = 0
                                                                     AND r.Process_Code_Sub1 = 0
                                                                     AND r.Process_Code_Sub2 = 0)))) OR
                                                     (a.Status_Code IN ('P', 'KI', 'TAH', 'ODE', 'MI') OR
                                                     (a.Status_Code = 'R' AND b.Status_Code = 'P' AND a.Provision_User_Id LIKE 'ECZ%')))
                                         GROUP BY c.Contract_Id,
                                                             c.Oar_No,
                                                             a.Claim_Inst_Type,
                                                             a.Claim_Inst_Loc,
                                                             a.Country_Code,
                                                             b.Cover_Code,
                                                             b.Is_Pool_Cover,
                                                             b.Is_Special_Cover,
                                                             a.Swift_Code,
                                                             b.Swift_Code,
                                                             Nvl(a.Date_Of_Loss, a.Provision_Date), --a.Date_Of_Loss,
                                                             a.Realization_Date,
                                                             Decode(a.Status_Code, 'TAH', 1, 'ODE', 1, 0),
                                                             a.Date_Of_Loss,
                                                             Nvl(a.Provision_Date, a.Invoice_Date),
                                                             Nvl(a.Provision_Date, a.Realization_Date),
                                                             b.Req_Cure_Day_Count,
                                                             b.Day_Seance,
                                                             b.Exemption_Rate,
                                                             b.Prov_Date_Time,
                                                             a.Claim_Id,
                                                             a.Add_Order_No,
                                                             a.Provision_User_Id,
                                                             Nvl(b.Sub_Package_Id, a.Package_Id),
                                                             Nvl(b.Sub_Package_Date, a.Package_Date)
                                         ORDER BY a.Claim_Id,
                                                             Nvl(b.Prov_Date_Time, To_Date('01/01/1985', 'dd/mm/yyyy')) ASC
