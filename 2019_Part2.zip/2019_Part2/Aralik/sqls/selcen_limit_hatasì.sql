select *-- max(entry_date)
from koc_clm_hlth_indem_totals_log
where  -- trunc(entry_date) = trunc(sysdate)
log_detail = 'ORA-06504: PL/SQL: Sonu� Seti de�i�kenlerinin veya sorgunun d�n�� tipleri t�rleri e�le�miyor'
order by entry_date desc;

select * from tmp_koc_errors where process='pr_clm_hlth_set_remaining'

select * from koc_clm_hlth_detail where claim_id=43553393;
select * from koc_mv_skrm_suppliers where institute_code=175;
select * from clm_pol_oar where claim_id=43553393;
441564560-9880-102500038


   select distinct  b.package_id, a.cover_code, a.cover_name, b.claim_inst_type, b.claim_inst_loc
              from cfg_v_prod_covers_api a
                  ,koc_oc_hlth_pack_cov_rel b 
             where a.product_id IN (63,64)
               and b.package_id = :parameter.p_package_id
               and b.child_cover_code = a.cover_code
               and a.cover_code = p_cover_code
               AND claim_inst_type NOT IN('AK-IS','AHK-IS')
          ORDER BY b.claim_inst_type, b.claim_inst_loc; 
