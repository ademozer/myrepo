KOC_CLM_BORDRO;
KOC_CLM_HLTH_BPM_UTILS.update_uncomplated_claim;
alz_hclm_converter_utils;
koc_hlth_clm_transfer


select * from alz_hltprv_log where log_id=154343339;


   SELECT Partner_Id, Policy_Start_Date, Group_Code
     FROM CUSTOMER.Koc_v_Hlth_Insured_Info_Indem
    where contract_id = 444047895
      and partition_no = 1;

select * from clm_pol_oar where claim_id=44057712;

select * from customer.alz_duplicate_provision where ext_reference='59782875';
select * from alz_hltprv_log where log_id=154328170
