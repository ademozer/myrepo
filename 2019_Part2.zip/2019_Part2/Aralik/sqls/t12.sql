 SELECT s.INSTITUTE_CODE  KURUM_KODU,
        s.NAME            KURUM_ADI,
        s.INSTYPNAME      KURUM_TURU,
        s.CLAIM_INST_TYPE KURUM_ANLASMA_TIPI,
        e.tax_office      VERGI_DAIRESI,
        e.tax_number      VERGI_NO,
        e.identity_no     IDENTITY_NO,
        adres.city_name KURUM_IL,
        adres.district_name KURUM_ILCE
   FROM koc_v_clm_suppliers_main s, koc_cp_partners_ext e, (select a.part_id, b.city_code, b.district_code, 
       (SELECT MAX(CITY_NAME) FROM koc_cp_cities_ref where city_code = b.city_code and country_code = 'TR') city_name,
       (SELECT MAX(DISTRICT_NAME) FROM koc_cp_districts_ref where city_code = b.city_code and district_code = b.district_code and country_code = 'TR') district_name
from koc_cp_address_links a, koc_cp_address_ext b
where a.add_id = b.add_id
and a.TO_DATE IS NULL) adres
  WHERE 1=1 --s.EXP_DATE IS NULL
    AND s.Institute_Code IS NOT NULL
  --  AND s.CLAIM_INST_TYPE = 'AHK'
    AND s.Part_Id = e.part_id
    AND adres.part_id = s.Part_Id
    AND s.Institute_Code IN(22332,3776)
    
    
    select * from koc_v_clm_suppliers_main  where Institute_Code IN(31696);
    --select * from cp_partners where part_id=7259244
    
    select * from koc_cp_partners_ext where part_id in(20743737,7259244)
    select * from koc_mv_skrm_suppliers_his where Institute_Code IN(31696);
    select * from koc_clm_suppliers_ext  where Institute_Code IN(31696);
    
    select * from clm_suppliers where supp_id=5196027
    select * from cp_partners where part_id=8072017

  select * from koc_clm_suppliers_ext  where Institute_Code IN(130751, 3135);
  select * from koc_mv_skrm_suppliers where NAME LIKE '%M�STEYDE%POLAT%' --Institute_Code IN(3202);
  select * from koc_cp_partners_ext where part_id in(46523549,11285809)
  --63101, 6087
   select * from koc_cp_partners_ext where part_id  in ( select part_id from koc_mv_skrm_suppliers where Institute_Code IN(50180, 6981));
   
   select * from koc_cp_partners_ext where part_id in ( select part_id from koc_mv_skrm_suppliers where Institute_Code IN(175315));
--select * from koc_cp_partners_ext where identity_no='16942119632'


update koc_cp_partners_ext 
   set tax_office = 'LEFKO�A',
       tax_number = '124139'
 where part_id = 12313920;
 
 update koc_cp_partners_ext
    set identity_no = '10942160700'
  where part_id = 9651898;
     
  update koc_cp_partners_ext
     set identity_no = '11111111111'
   where part_id IN (81810329, 121675978);
        
   update koc_cp_partners_ext
    set identity_no = '11111111111'
  where part_id = 114040225
   
    select * from koc_cp_partners_ext
  --   set identity_no = '11111111111'
   where part_id IN (--121748356, 121748241, 34965137, 7549417, 11563445, 14634934, 11109944, 7872330, 9033716, 14355104,73876267, 
   81810329, 121675978, 31380222,29953955, 99303808,118416561, 12906443,85350155,82257241,114040225,9651898,120613209,121796962,113561852);
 --8072017
 
 
 select * from koc_cp_partners_ext where part_id=8072017
