SELECT s.*
   FROM koc_v_clm_suppliers_main s
   WHERE NOT EXISTS (SELECT 1
           FROM alz_hclm_institute_info 
          WHERE institute_code = s.institute_code )
    and institute_type != '2'      
    and instypname='Hastane'
    and claim_inst_loc = 'YI'
    and claim_inst_type='AK'
    and exp_date is null
    and tss_agreement_status != 0
    and oss_agreement_status != 1
