select * from clm_subfiles where ext_reference='59310195';
select * from alz_hclm_version_info where claim_id=43914856;

select * from koc_clm_hlth_detail where ext_reference='59310195' for update
select * from koc_clm_hlth_proc_detail where claim_id=43447026;
