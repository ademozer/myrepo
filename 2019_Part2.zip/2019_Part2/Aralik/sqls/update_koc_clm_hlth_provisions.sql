update koc_clm_hlth_provisions
   set sub_package_id =  114683,
       sub_package_date = TO_DATE('01/07/2017','DD/MM/YYYY')
 where claim_id in(40566339,
38382105,
38352397);

commit;
