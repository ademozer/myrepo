121803799;
select * from clm_subfiles where claim_id=21149195

 update koc_cp_partners_ext
    set identity_no = '11111111111'
  where part_id in (114040225, 120613209,121796962,113561852);
  
  
select *--claim_id,sf_no,add_order_no,count(*) 
  from koc_clm_hlth_status 
 where status_code IS NOT NULL
 and claim_id=21149195--23095551
group by claim_id,sf_no,add_order_no
having count(*)>2

SELECT DISTINCT l.parameter, c.long_name , c.desc_int_id
  FROM koc_cp_health_look_up l, cur_translations c
 WHERE l.desc_int_id = c.desc_int_id
   AND c.sula_ora_nls_code = 'TR'
   and look_up_code = 'STATUS'
   and l.validity_end is null
  order by c.desc_int_id


59715680;

select * from dba_tab_privs where table_name='ALZ_HLTH_ANNOUNCEMENT';
 SELECT a.Object_Id,
             a.Doc_Code,
             b.Barcode,
             c.Dm_Sys_Id,
             a.Doc_Link,
             a.Doc_Folder,
             b.Create_Date,
             a.claim_id
        FROM CUSTOMER.Alz_Clm_Docs a,
             CUSTOMER.Alz_Doc_Infos b,
             CUSTOMER.Alz_Docs c 
       WHERE a.Object_Id = b.Object_Id
        AND  to_number(b.add_order_no) = 1
        AND  b.add_order_no IS NOT NULL
        AND  a.Object_Id = c.Object_Id
        AND  a.Claim_Id IN (select claim_id from koc_clm_hlth_prov_statemnt where entry_Date>trunc(sysdate-2))
        AND  a.Sf_No = 1;

select * from koc_clm_hlth_prov_statemnt where claim_id = 29802741;--entry_Date>trunc(sysdate-2)
