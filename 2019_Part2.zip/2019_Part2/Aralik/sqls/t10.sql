select p.policy_ref,a.* from muratk.tmp_gebelis@opusdev a, ocp_policy_bases p

where a.ins_obj_uid = p.contract_id;

alz_hclm_converter_utils

select * from alz_hltprv_log where log_date>trunc(sysdate) order by log_date desc
