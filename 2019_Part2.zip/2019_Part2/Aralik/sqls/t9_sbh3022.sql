﻿SELECT DISTINCT A.NOTE_TYPE,N.DESCRIPTION 
FROM KOC_NOTES_AUTH_REL A,KOC_AUTH_USER_ROLE_REL R,KOC_NOTE_TYPE_REF N
WHERE A.USER_ROLE_CODE=R.ROLE_CODE
AND   A.NOTE_TYPE=N.NOTE_TYPE
AND   A.VALIDITY_END_DATE IS NULL AND R.VALIDITY_END_DATE IS NULL
--AND   R.USERNAME=:PARAMETER.P_USER
AND   a.NOTE_APP_TYPE='QUERY'

select * from koc_notes_authorization a where note_type='ILAC' and medicine_note_id=999
select * from koc_notes  where note_id = 12200627

select p.policy_ref as Poliçe_No, a.sub_level1 as Sıra_No, a.note_id,c.barcode, n.text as İlaç_Notu_Açıklaması, CASE c.prescription_status 
                                                                                               WHEN 'ONAYLI' THEN 'VAR'
                                                                                               ELSE 'YOK'
                                                                                           END ER_DURUMU
  from ocp_policy_bases p, 
       koc_notes_authorization a,
       koc_clm_auto_prescriptions c,
       koc_notes n
 where p.contract_id = a.INS_OBJ_UID 
   and a.note_id = n.note_id
   and a.note_type = 'ILAC'
   and a.medicine_note_id = 999
   and a.note_id = c.note_id
   and p.term_start_date>TO_DATE('01/12/2018','DD/MM/YYYY')
   and rownum<10
    
   
select distinct p.policy_ref as Poliçe_No, a.sub_level1 as Sıra_No,p.claim_id, a.note_id,c.barcode,m.medicine_name, n.text as İlaç_Notu_Açıklaması, CASE c.prescription_status 
                                                                                               WHEN 'ONAYLI' THEN 'VAR'
                                                                                               ELSE 'YOK'
                                                                                           END ER_DURUMU
  from clm_pol_bases p,
       koc_notes_authorization a,
       koc_clm_auto_prescriptions c,      
       koc_notes n,
       koc_cc_medicines m
 where p.contract_id = a.INS_OBJ_UID 
   and a.note_id = n.note_id
   and a.note_type = 'ILAC'
   and a.medicine_note_id = 999
   and a.note_id = c.note_id
   and c.claim_id = p.claim_id
   and p.term_start_date>TO_DATE('01/12/2018','DD/MM/YYYY')
   and c.barcode = m.barcode
   and m.validity_date between c.validity_start_date and c.validity_end_date
   and a.note_id = 32593713
   and rownum<10
   
   
   
   
   select p.policy_ref as Poliçe_No, a.sub_level1 as Sıra_No,n.text as İlaç_Notu_Açıklaması,
   CASE WHEN (SELECT count(*) FROM koc_clm_auto_prescriptions where claim_id=p.claim_id and note_id = a.note_id and prescription_status ='ONAYLI')>0 THEN 'VAR' 
        ELSE 'YOK' END ER_DURUMU
  from clm_pol_bases p,
       koc_notes_authorization a,
       --koc_clm_auto_prescriptions c,      
       koc_notes n--,
      -- koc_cc_medicines m
 where p.contract_id = a.INS_OBJ_UID 
   and a.note_id = n.note_id
   and a.note_type = 'ILAC'
   and a.medicine_note_id = 999
   --and a.note_id = c.note_id
   --and c.claim_id = p.claim_id
   and p.term_start_date>TO_DATE('01/12/2019','DD/MM/YYYY')
   --and c.barcode = m.barcode
   --and m.validity_date between c.validity_start_date and c.validity_end_date
   --and a.note_id = 32593713
   and rownum<10
   
   
   select * from koc_clm_auto_prescriptions where note_id=32593713
   select * from koc_notes_authorization where note_id=32593713
   select * from koc_notes where note_id=32593713
   select * from koc_cc_medicines
   select * from clm_pol_bases where claim_id = 38617521
   
   
 
SELECT DISTINCT A.NOTE_TYPE,N.DESCRIPTION 
FROM KOC_NOTES_AUTH_REL A,KOC_AUTH_USER_ROLE_REL R,KOC_NOTE_TYPE_REF N
WHERE A.USER_ROLE_CODE=R.ROLE_CODE
AND   A.NOTE_TYPE=N.NOTE_TYPE
AND   A.VALIDITY_END_DATE IS NULL AND R.VALIDITY_END_DATE IS NULL
--AND   R.USERNAME=:PARAMETER.P_USER
AND   a.NOTE_APP_TYPE='CREATE'

select * from koc_notes_auth_rel where note_type='ILAC' and note_app_type='QUERY';


select a.PARAMETER,a.EXPLANATION, 'STD_ILAC' MEDICINE_NOTE_TYPE,'ÝLAÇ NOTU' MEDICINE_NOTE_TYPE_DESC
from alz_look_up a
where a.CODE = 'STD_ILAC'
and a.VALIDITY_END_DATE is null 
--and :koc_notes_authorization.NOTE_TYPE='ILAC'
union
select a.PARAMETER,a.EXPLANATION, 'SPC_ILAC' MEDICINE_NOTE_TYPE,'ÖZEL ÝLAÇ NOTU' MEDICINE_NOTE_TYPE_DESC
from alz_look_up a
where a.CODE='SPC_ILAC'
and a.VALIDITY_END_DATE is null 
order by 1
--and :koc_notes_authorization.NOTE_TYPE='ILAC';

koc_clm_hlth_trnx;

select * from alz_hclm_institute_info where institute_code=6914 for update;

select * from alz_hltprv_log where log_id=153531100;

 SELECT Alz_Hltprv_Utils.Convertbranchcode2('ULAK',
                                                                                                     SYSDATE,
                                                                                                      1500) FROM DUAL
