DECLARE

  v_user_name VARCHAR2(100);
  
BEGIN
  
  v_user_name := COALESCE(ALZ_BASE_FUNCTION_UTILS.GET_SESSION_METADATA().USERNAME, USER);
 
  dbms_output.put_line(v_user_name);
  
END;
