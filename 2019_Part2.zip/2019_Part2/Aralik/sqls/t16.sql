 SELECT a.*,
              Def.Tss_Statement_Permitted_Day,
              Def.Oss_Statement_Permitted_Day
         FROM Koc_v_Clm_Suppliers_Main a
         LEFT JOIN Koc_Clm_Hlth_Sttmnt_Ws_Def Def ON Def.Institute_Code = a.Institute_Code
                                                 AND Def.Institute_Code = a.Institute_Code
                                                 AND Def.Validity_Start_Date <= SYSDATE
                                                 AND (Def.Validity_End_Date IS NULL OR Def.Validity_End_Date >= SYSDATE)
                                                 AND Def.Is_Ws = 1
        WHERE a.Institute_Code IN('6411','1750','180','3655');
        
        
          SELECT /*+ index (a.b KOC_CLM_SUPPLIERS_EXT_IDX1) */
       a.*
        FROM Koc_v_Clm_Suppliers_Main a
       WHERE a.Institute_Code IN('6411','1750','180','3655')
         AND a.Eff_Date <= TO_DATE('14/11/2019','DD/MM/YYYY')
         AND Nvl(a.Exp_Date, TO_DATE('14/11/2019','DD/MM/YYYY')) >= TO_DATE('14/11/2019','DD/MM/YYYY')
      UNION ALL
      SELECT a.*
        FROM Koc_v_Clm_Suppliers_His a
       WHERE a.Institute_Code IN('6411','1750','180','3655')
         AND a.Eff_Date <= TO_DATE('14/11/2019','DD/MM/YYYY')
         AND Nvl(a.Exp_Date, TO_DATE('14/11/2019','DD/MM/YYYY')) >= TO_DATE('14/11/2019','DD/MM/YYYY');
        
        
        6411
1750
180
3655

        
       select institute_code from koc_clm_hlth_detail where claim_id in(43531212,
43531212,
43635578,
43635578,
43635578,
43635580,
43635580,
43682855)
