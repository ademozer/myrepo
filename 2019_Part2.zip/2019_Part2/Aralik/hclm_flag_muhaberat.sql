insert into koc_auth_user_role_rel (USERNAME, ROLE_CODE, VALIDITY_START_DATE, VALIDITY_END_DATE, IS_AUTHORIZED_AGENCY_USER, REGION_CODE)
values ('WEMARSLAN', 'HCLMPROV', to_date('02-12-2019', 'dd-mm-yyyy'), null, null, null);

insert into koc_auth_user_role_rel (USERNAME, ROLE_CODE, VALIDITY_START_DATE, VALIDITY_END_DATE, IS_AUTHORIZED_AGENCY_USER, REGION_CODE)
values ('WYEKOSALI', 'HCLMPROV', to_date('02-12-2019', 'dd-mm-yyyy'), null, null, null);

insert into koc_auth_user_role_rel (USERNAME, ROLE_CODE, VALIDITY_START_DATE, VALIDITY_END_DATE, IS_AUTHORIZED_AGENCY_USER, REGION_CODE)
values ('WITURFAN', 'HCLMPROV', to_date('02-12-2019', 'dd-mm-yyyy'), null, null, null);

commit;

