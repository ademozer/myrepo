update koc_clm_hlth_detail
  set status_code = 'C'
where ext_reference in ('59251505',
                        '56638367',
                        '59083411',
                        '59160161',
                        '59031923',
                        '58954640',
                        '59258120',
                        '59342127',
                        '59079860',
                        '59234491',
                        '59141093');
commit;                        
                            
