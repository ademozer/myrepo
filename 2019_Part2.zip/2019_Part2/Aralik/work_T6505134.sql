select d.ext_reference, d.status_code from alz_hclm_version_info a, koc_clm_hlth_detail d 
 where a.version_no = (select max(b.version_no) from alz_hclm_version_info b where a.claim_id = b.claim_id) and a.status_code='C'
   and a.claim_id = d.claim_id 
   and d.status_code != 'C'
   
   
   update koc_clm_hlth_detail
      set status_code = 'C'
    where ext_reference in ('59251505',
                            '56638367',
                            '59083411',
                            '59160161',
                            '59031923',
                            '58954640',
                            '59258120',
                            '59342127',
                            '59079860',
                            '59234491',
                            '59141093');
                            
                            
   update koc_clm_hlth_detail
      set status_code = 'C'
    where ext_reference in ('59197789');
    
    commit;
