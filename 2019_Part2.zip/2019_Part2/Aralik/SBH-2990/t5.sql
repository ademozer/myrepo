koc_clm_hlth_report_utils.sendclmabsentdoclist(
                                                               :FERDIGRUP,
                                                               :tarih1,
                                                               :tarih2,
                                                               :GKODU,
                                                               :kontrol.ILKPOLICE,--:parameter.p_contract1 ,
                                                               :kontrol.SONPOLICE,--:parameter.p_contract2,
                                                               AgentRec.Agent_role,
                                                               AgentRec.Sub_agent ,
                                                               :parameter.P_MAIL_ADRESS,
                                                               vmailtype,
                                                               null,
                                                               '045', -- engine 29032017 TPA
                                                               vreturn);
