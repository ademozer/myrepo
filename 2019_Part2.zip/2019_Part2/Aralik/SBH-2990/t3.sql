   select distinct y.reference_code,
                   yy.title,
                   x.agent_role,
                   x.sub_agent,
                   ext.company_code company_code
     from koc_hpf x, dmt_agents y, koc_dmt_agents_ext yy, koc_ocp_pol_contracts_ext ext
    where decode (nvl (x.sub_agent, 0), 0, x.agent_role, x.sub_agent) = y.int_id
      and yy.int_id = y.int_id
      and (reference_code = '5032' or '5032' is null)
      and x.validity_start_date >= trunc(add_months(sysdate,-12),'YYYY')
      and x.official_form_serial_no not in ('GM', 'GO', 'GW')
      and ext.contract_id = x.contract_id
      and exists (select 1
                    from clm_pol_bases xx
                   where xx.contract_id = x.contract_id)
      and (('045' is not null and ext.company_code in ('045')) 
            or ('045' is null and ext.company_code in (select u.company_code from alz_tpa_companies u)))
    order by   reference_code;
    
    select * from dmt_agents  where reference_code='1572'  ---11499
    select * from dmt_agents where int_id=11499
    
