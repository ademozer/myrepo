select /*+ INDEX (ext KOC_OCP_POL_CONTRACTS_EXT_PK) */
 c.product_id,
 a.add_order_no,
 a.claim_id,
 a.refuse_explanation,
 a.main_code,
 a.item_code,
 a.sub_item_code,
 a.entry_date,
 a.refuse_amount,
 'Red Bildirimi' status_exp,
 'KST-' || b.ext_reference mektup_no,
 substr(c.policy_ref, 1, 4) || ' ' || substr(c.policy_ref, 5, 4) || ' ' ||
 substr(c.policy_ref, 9, 4) || ' ' || substr(c.policy_ref, 13, 4) policy_ref,
 b.part_id,
 d.oar_no,
 b.ext_reference,
 b.group_code,
 b.invoice_total,
 b.comm_date,
 b.status_code,
 pol_b.agent_role,
 pol_ext.sub_agent,
 b.invoice_date,
 b.invoice_no,
 b.institute_code,
 b.date_of_loss,
 p.sub_company_code
  from koc_clm_hlth_reject_loss  a,
       koc_clm_hlth_detail       b,
       clm_pol_bases             c,
       clm_pol_oar               d,
       koc_ocp_partitions_ext    p,
       koc_ocp_pol_contracts_ext ext,
       koc_ocp_pol_versions_ext  pol_ext,
       ocp_policy_bases          pol_b,
       ocp_policy_versions       pol_v
 where a.claim_id = b.claim_id
   and a.sf_no = b.sf_no
   and a.add_order_no = b.add_order_no
   and b.claim_id = c.claim_id
   and b.claim_id = d.claim_id
   and c.contract_id = pol_ext.contract_id
   and b.provision_date is null
   and c.product_id = 64
   and ext.contract_id = c.contract_id
   and ext.company_code = '045'
   and b.status_code = 'R'
   and d.contract_id = p.contract_id
   and d.oar_no = p.partition_no
   and d.version_no = p.version_no
   and pol_b.contract_id = pol_ext.contract_id
   and pol_v.contract_id = pol_ext.contract_id
   and pol_v.version_no = pol_ext.version_no
   and pol_v.product_id = c.product_id
   and ((nvl(pol_ext.endorsement_no, 0) = 54 and
       pol_ext.version_no = pol_b.version_no) or
       (nvl(pol_ext.endorsement_no, 0) <> 54 and pol_b.top_indicator = 'Y'))
   and pol_ext.reversing_version is null
   and ((exists (select 1
                   from koc_ocp_pol_versions_ext aa
                  where aa.contract_id = pol_ext.contract_id
                    and nvl(aa.endorsement_no, 0) = 54
                    and aa.reversing_version is null) and
        pol_ext.version_no =
        (select max(version_no)
                   from koc_ocp_pol_versions_ext aa
                  where aa.contract_id = pol_ext.contract_id
                    and nvl(aa.endorsement_no, 0) = 54
                    and aa.reversing_version is null)) or
       (not exists (select 1
                       from koc_ocp_pol_versions_ext aa
                      where aa.contract_id = pol_ext.contract_id
                        and nvl(aa.endorsement_no, 0) = 54
                        and aa.reversing_version is null) and
        pol_ext.top_indicator = 'Y'))
   and a.entry_date >= '10/12/2019'
   and a.entry_date <= '18/12/2019'
   and b.group_code = 'S7203'
   and c.policy_ref = '0001171006129498'
   and pol_b.agent_role = 11493
--S7203
--11493
