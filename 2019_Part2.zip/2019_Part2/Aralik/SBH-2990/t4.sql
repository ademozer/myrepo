SELECT   DISTINCT a.version_no,
                        a.contract_id,
                        o.policy_ref,
                        a.group_code,                        
                        ext.company_code company_code, -- engine 30032017 TPA added
                        o.agent_role
        --FROM   ocp_policy_bases o, koc_ocp_pol_versions_ext a -- engine 24072017 TPA commented
        FROM   ocp_policy_bases o, koc_ocp_pol_versions_ext a, koc_ocp_pol_contracts_ext ext, dmt_agents d -- engine 24072017 TPA added
       WHERE       o.policy_ref LIKE '000117%' --grup policeleri alarak daralttik
               AND o.term_start_date > SYSDATE - 731                   --- 400
               --AND:kontrol.ILKPOLICE IS NOT NULL
              -- AND:kontrol.SONPOLICE IS NOT NULL
               --AND o.policy_ref >= :kontrol.ILKPOLICE
             --  AND o.policy_ref <= :kontrol.SONPOLICE
               AND o.contract_id = a.contract_id
               AND ext.contract_id = o.contract_id    -- engine 24072017 TPA added
               AND o.agent_role = d.int_id
               AND d.reference_code = '5032'               
               AND a.version_no = 1
               AND a.signature_date > SYSDATE - 731                    --- 400
               /*AND ((p_company_list is not null and ext.company_code IN (p_company_list))
                    or (p_company_list is null and ext.company_code in (select company_code from alz_tpa_companies)))    -- engine 30032017 TPA added
               AND (:kontrol.boyner = 1
                    OR (:kontrol.boyner = 0 AND a.group_code NOT IN ('S6793')))*/
      UNION ALL
      SELECT   DISTINCT a.version_no,
                        a.contract_id,
                        o.policy_ref,
                        a.group_code,
                        ext.company_code company_code -- engine 30032017 TPA added
        --FROM   ocp_policy_bases o, koc_ocp_pol_versions_ext a -- engine 24072017 TPA commented
        FROM   ocp_policy_bases o, koc_ocp_pol_versions_ext a, koc_ocp_pol_contracts_ext ext -- engine 24072017 TPA added
       WHERE       o.policy_ref LIKE '000117%' --grup policeleri alarak daralttik
               AND o.term_start_date > SYSDATE - 731                   --- 400
               AND:kontrol.ILKPOLICE IS NULL
               AND:kontrol.SONPOLICE IS NULL
               AND o.contract_id = a.contract_id
               AND ext.contract_id = o.contract_id    -- engine 24072017 TPA added
               AND a.version_no = 1
               AND a.signature_date > SYSDATE - 731                    --- 400
               AND ((p_company_list is not null and ext.company_code IN (p_company_list))
                    or (p_company_list is null and ext.company_code in (select company_code from alz_tpa_companies)))    -- engine 30032017 TPA added
               AND (:kontrol.boyner = 1
                    OR (:kontrol.boyner = 0 AND a.group_code NOT IN ('S6793')));
