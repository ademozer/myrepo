select * from tmp_koc_errors  where reference_code='ademo_KOCREPCLM710_3' and error like '%0001171006126427%'

select * from ocp_policy_bases where policy_ref='0001171006126427'--11499

select * from tmp_koc_errors  where reference_code='ademo_KOCREPCLM710_3' and error like '%agent_role%'
