select * from Koc_V_Cp_Health_Look_Up where look_up_code='STATUS'
select * from Koc_Cp_Health_Look_Up where look_up_code='NEW_STATUS'
delete Koc_Cp_Health_Look_Up where look_up_code='NEW_STATUS'
delete cur_translations where desc_int_id=424466
