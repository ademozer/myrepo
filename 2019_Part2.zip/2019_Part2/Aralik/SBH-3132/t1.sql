  SELECT Koc_Clm_Hlth_Utils.Getrejectlossdesc(Main_Code, Item_Code, Sub_Item_Code, Provision_Date) Aciklama1,
        Kapsam_Disi_Tutar,
        Swift_Code
   FROM (SELECT SUM(Round(a.Refuse_Amount, 2)) Kapsam_Disi_Tutar,
                a.Main_Code,
                a.Item_Code,
                a.Sub_Item_Code,
                b.Provision_Date,
                b.Swift_Code
           FROM Koc_Clm_Hlth_Reject_Loss a,
                Koc_Clm_Hlth_Detail      b 
          WHERE b.ext_reference = '59807007'
            --a.Claim_Id = b.claim_id
            --AND a.Sf_No = b.Sf_No     
            AND NOT (a.Main_Code = 16 AND a.Item_Code = 12)
            AND b.Claim_Id = a.Claim_Id
            AND b.Sf_No = a.Sf_No 
          GROUP BY a.Main_Code,
                   a.Item_Code,
                   a.Sub_Item_Code,
                   b.Provision_Date,
                   b.Swift_Code)
                   
                   select * from Koc_Clm_Hlth_Reject_Loss where claim_id = 44088518
                   select * from Koc_Clm_Hlth_Detail where ext_reference = '59807007';
                   
                   Alz_Clm_Hlth_Cron.Get_Suspense_Day
                   
                   select * from Alz_Hlth_Prv_Pending_Period
