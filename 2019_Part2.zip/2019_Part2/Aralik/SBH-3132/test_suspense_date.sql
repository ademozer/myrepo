DECLARE
  v_Is_Suspense      Koc_Clm_Hlth_Detail.Is_Suspense%TYPE;
  v_Message          VARCHAR2(4000);
  v_Day              VARCHAR2(2);
  v_Day2              VARCHAR2(2);
  v_Hospitalize_Date DATE;
  v_Term_End_Date    DATE;
  v_Suspense_Date    DATE;
  v_Claim_Id         NUMBER;
BEGIN

  SELECT Nvl(d.Is_Suspense, 0),
         Hospitalize_Date,
         Suspense_Date
    INTO v_Is_Suspense,
         v_Hospitalize_Date,
         v_Suspense_Date
    FROM Koc_Clm_Hlth_Detail d
   WHERE d.Claim_Id = v_Claim_Id
     AND d.Sf_No = 1
     AND d.Add_Order_No = 1;
  
  BEGIN
    SELECT p.Term_End_Date
      INTO v_Term_End_Date
      FROM Ocp_Policy_Bases p
     WHERE EXISTS (SELECT NULL
              FROM Clm_Pol_Oar c
             WHERE c.Claim_Id = v_Claim_Id
               AND c.Contract_Id = p.Contract_Id)
       AND p.Top_Indicator = 'Y'
       AND p.Action_Code <> 'D';
  
  EXCEPTION
    WHEN OTHERS THEN
      v_Term_End_Date := NULL;
  END;
  
  v_Day := Alz_Clm_Hlth_Cron.Get_Suspense_Day(v_Claim_Id);
  IF trunc(v_Term_End_Date) - trunc(v_Hospitalize_Date ) < v_Day
  THEN
    v_Day := Trunc(v_Term_End_Date) - Trunc(v_Hospitalize_Date); 
  END IF;
  
  DBMS_OUTPUT.PUT_LINE(v_Day);
  
  END;
