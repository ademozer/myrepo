KOC_GROUP_HEALTH_UTILS;

 SELECT CUSTOMER.KOC_CLM_HLTH_UTILS.GetlookupparamDesc('STATUS', 'EL', SYSDATE) FROM DUAL
 
 select CUSTOMER.KOC_CLM_HLTH_UTILS.GetlookupparamDesc('STATUS', status_code, SYSDATE) text,status_code from koc_clm_hlth_status_his
 
 
 SELECT LENGTH('Ekip Lideri  taraf�ndan  onaylanm��t�r') FROM DUAL
 
 
select * from koc_clm_hlth_status_his

select * from clm_subfiles where claim_id=41913009;
 select * from koc_oc_hlth_expack_cov_rel where sub_rule_code='35' and package_id=263642 and child_cover_code='S534'
 delete koc_oc_hlth_expack_cov_rel where sub_rule_code='35' and package_id=263642 and child_cover_code='S507'
 select * from koc_clm_htlh_indem_totals 
 
 select * from alz_hltprv_log where log_date>trunc(sysdate) order by log_date desc;
 select * from alz_hltprv_log where log_id in (155722050,155722035) and note like '%RESPONSE%'  --155722050,155722035
 
 select * from alz_hltprv_log where log_id=154464668
