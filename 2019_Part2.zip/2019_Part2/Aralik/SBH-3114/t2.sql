SELECT *
  FROM koc_cp_health_look_up 
 WHERE look_up_code = 'STATUS'
   --and validity_end is null
   and parameter in ('SKS','DY', 'DR-1','DR-2', 'DR-3', 'TK', 'SVK','SLH', 'KT', 'XXX', 'YYY');
   
   
   
update koc_cp_health_look_up
   set validity_end = sysdate
 WHERE look_up_code = 'STATUS'
   and validity_end is null
   and parameter in ('SKS','DY', 'DR-1','DR-2', 'DR-3', 'TK', 'SVK','SLH', 'KT', 'XXX', 'YYY');   
   
   alz_hclm_converter_utils
