DECLARE 
  
   procedure create_new_statu(p_code IN VARCHAR2, p_text IN VARCHAR2) IS
      v_desc_int_id NUMBER;
   BEGIN
      select max(int_id) + 1
      INTO v_desc_int_id
      from  DESCRIPTIONS;
       
      insert into DESCRIPTIONS (INT_ID, JOIN_TABLE)
      values (v_desc_int_id, 'KOC_CP_HEALTH_LOOK_UP');

      insert into cur_translations (SULA_ORA_NLS_CODE, DESC_INT_ID, SHORT_CODE, LONG_NAME, COMMENTS)
      values ('TR', v_desc_int_id, 'STATUS', p_text, null);

      insert into cur_translations (SULA_ORA_NLS_CODE, DESC_INT_ID, SHORT_CODE, LONG_NAME, COMMENTS)
      values ('US', v_desc_int_id, 'STATUS', p_text, null);

      insert into koc_cp_health_look_up (LOOK_UP_CODE, PARAMETER, DESC_INT_ID, VALIDITY_START, VALIDITY_END, USERID, ENTRY_DATE, DETAIL_EXPLANATION)
      values ('STATUS', p_code, v_desc_int_id, sysdate, null, 'ADEMO', null, 'Ek Bilgi Yeni Stat� Kodlar�');

   END create_new_statu;
   
BEGIN

/*  SKS Sistem Kesintisi                              - Eski
DY  De�erlendirme Yap�ld�                         - Eski
DR-1  Yetkili Doktor 1 Taraf�ndan Onaylanm��t�r   - Eski
DR-2  Yetkili Doktor 2 Taraf�ndan Onaylanm��t�r   - Eski
DR-3  Yetkili Doktor 3 Taraf�ndan Onaylanm��t�r   - Eski
TK  Trafik Kazas�                                 - Eski
SVK Di�er Kuruma Sevk                             - Eski
SLH Salah �le Taburcu                             - Eski
KT  Komplikasyonlu Taburcu                        - Eski
XXX Opsiyonel Bilgi 1                             - Eski
YYY Opsiyonel Bilgi 2                             - Eski
KY  Komplikasyon Yat���                           - Ortak
EX  Exitus                                        - Ortak
YNT Y�netici Taraf�ndan Onaylanm��t�r             - Ortak
MDR M�d�r Taraf�ndan Onaylanm��t�r                - Ortak
TO  Telefon Onay�                                 - Ortak 
MHA Mevcut Hastal�k Ara�t�rma                     - Ortak
EL  Ekip Lideri  taraf�ndan  onaylanm��t�r        - Yeni
�T  �ifa ile taburcu                              - Yeni
HT  Haliyle taburcu                               - Yeni
TV  Tedaviden vazge�me                            - Yeni
A-SVK Ayn� kapsaml� ba�ka bir hastaneye sevk      - Yeni
D-SVK Dahakapsaml� ba�ka bir hastaneye sevk       - Yeni
E-SVK Evde Bak�m kurulu�una sevk                  - Yeni
UY  Uzun yat��                                    - Yeni
EBT Evde Bak�m i�in taburcu                       - Yeni
UW  UW de  bekliyor                               - Yeni
�RT �retimde bekliyor                             - Yeni
*/

--Eski Stat� Kodlar�n� Kapatal�m. 
  
  UPDATE koc_cp_health_look_up
     SET validity_end = sysdate
   WHERE look_up_code = 'STATUS'
     AND validity_end is null
     AND parameter in ('SKS','DY', 'DR-1','DR-2', 'DR-3', 'TK', 'SVK','SLH', 'KT', 'XXX', 'YYY');

-- Yeni Stat� Kodlar�n� Tan�mlayal�m. 
  create_new_statu('EL', 'Ekip Lideri  taraf�ndan  onaylanm��t�r');   
  create_new_statu('�T', '�ifa ile taburcu');
  create_new_statu('HT', 'Haliyle taburcu');
  create_new_statu('TV', 'Tedaviden vazge�me');
  create_new_statu('A-SVK', 'Ayn� kapsaml� ba�ka bir hastaneye sevk');
  create_new_statu('D-SVK', 'Daha kapsaml� ba�ka bir hastaneye sevk');
  create_new_statu('E-SVK', 'Evde Bak�m kurulu�una sevk');
  create_new_statu('UY', 'Uzayan yat�� ');
  create_new_statu('UW', 'UW de  bekliyor');
  create_new_statu('EBT', 'Evde Bak�m i�in taburcu ');
  create_new_statu('�RT', '�retimde bekliyor');
  DBMS_OUTPUT.PUT_LINE('��lem Ba�ar�l�');
  COMMIT; 
EXCEPTION WHEN OTHERS THEN
  DBMS_OUTPUT.PUT_LINE('Hata Olu�tu');
  ROLLBACK;  
END;
/

