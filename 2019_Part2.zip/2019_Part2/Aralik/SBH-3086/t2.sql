SELECT DISTINCT l.parameter, c.long_name , c.desc_int_id
  FROM koc_cp_health_look_up l, cur_translations c
 WHERE l.desc_int_id = c.desc_int_id
   AND c.sula_ora_nls_code = 'TR'
   and look_up_code = 'STATUS'
   and parameter = 'MHA'
  -- and l.validity_end is null
  order by c.desc_int_id
  
  select * from koc_clm_hlth_status where claim_id = 41910249
select * from clm_subfiles where ext_reference='58118318';

alz_hclm_converter_utils
SELECT *
  FROM koc_cp_health_look_up 
 WHERE look_up_code = 'STATUS'
   and validity_end is null for update
   select * from cur_translations where desc_int_id in(
   599468,
   599469,
   599470) for update
   /*
   MHA -Mevcut hastal�k Ara�t�rma 

TO-Telefon Onay� 

EL-Ekip Lideri  taraf�ndan  onaylanm��t�r

YNT-Y�netici taraf�ndan onaylanm��t�r

MDR-M�d�r taraf�ndan onaylanm��t�r 

�T-�ifa ile taburcu

HT-Haliyle taburcu

TV-Tedaviden vazge�me

A- SVK-Ayn� kapsaml� ba�ka bir hastaneye sevk

D-SVK- kapsaml� ba�ka bir hastaneye sevk

E-.SVK- Evde Bak�m kurulu�una sevk

UY-Uzun yat��

KY-Komplikasyon Yat���

EBT-Evde Bak�m i�in taburcu

EX-Exitus

UW-UW de  bekliyor 

�RT-�retimde bekliyor 
   */
 /*  1)	�ifa ile taburcu 
2)	Haliyle taburcu
3)	Tedaviden vazge�me
4)	Ayn� kapsaml� ba�ka bir hastaneye sevk 
5)	Daha kapsaml� ba�ka bir hastaneye sevk
6)	Orta dereceli bir ba�ka bak�m kurulu�una sevk
7)	Uzayan yat�� 
8)	Komplikasyon Yat��� 
9)	Evde Bak�m i�in taburcu 
10)	Exiutus*/


MHA Mevcut Hastal�k Ara�t�rma                     - Ortak
SKS Sistem Kesintisi                              - Eski 
TO  Telefon Onay�                                 - Ortak 
DY  De�erlendirme Yap�ld�                         - Eski
DR-1  Yetkili Doktor 1 Taraf�ndan Onaylanm��t�r   - Eski
DR-2  Yetkili Doktor 2 Taraf�ndan Onaylanm��t�r   - Eski
DR-3  Yetkili Doktor 3 Taraf�ndan Onaylanm��t�r   - Eski
YNT Y�netici Taraf�ndan Onaylanm��t�r             - Eski
MDR M�d�r Taraf�ndan Onaylanm��t�r                - Ortak
TK  Trafik Kazas�                                 - Eski
EX  Exitus                                        - Ortak
SVK Di�er Kuruma Sevk                             - Eski
SLH Salah �le Taburcu                             - Eski
KT  Komplikasyonlu Taburcu                        - Eski
KY  Komplikasyon Yat���                           - Ortak
XXX Opsiyonel Bilgi 1                             - Eski
YYY Opsiyonel Bilgi 2                             - Eski
