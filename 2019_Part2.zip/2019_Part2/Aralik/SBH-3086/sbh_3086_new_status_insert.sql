DECLARE 
  
   procedure create_new_statu(p_code IN VARCHAR2, p_text IN VARCHAR2) IS
      v_desc_int_id NUMBER;
   BEGIN
      select max(int_id) + 1
      INTO v_desc_int_id
      from  DESCRIPTIONS;
       
      insert into DESCRIPTIONS (INT_ID, JOIN_TABLE)
      values (v_desc_int_id, 'KOC_CP_HEALTH_LOOK_UP');

      insert into cur_translations (SULA_ORA_NLS_CODE, DESC_INT_ID, SHORT_CODE, LONG_NAME, COMMENTS)
      values ('TR', v_desc_int_id, 'NEW_STATUS', p_text, null);

      insert into cur_translations (SULA_ORA_NLS_CODE, DESC_INT_ID, SHORT_CODE, LONG_NAME, COMMENTS)
      values ('US', v_desc_int_id, 'NEW_STATUS', p_text, null);

      insert into koc_cp_health_look_up (LOOK_UP_CODE, PARAMETER, DESC_INT_ID, VALIDITY_START, VALIDITY_END, USERID, ENTRY_DATE, DETAIL_EXPLANATION)
      values ('NEW_STATUS', p_code, v_desc_int_id, sysdate, null, 'ADEMO', null, 'Ek Bilgi Yeni Stat� Kodlar�');

   END create_new_statu;
   
BEGIN
  
/*
1)	�ifa ile taburcu 
2)	Haliyle taburcu
3)	Tedaviden vazge�me
4)	Ayn� kapsaml� ba�ka bir hastaneye sevk 
5)	Daha kapsaml� ba�ka bir hastaneye sevk
6)	Orta dereceli bir ba�ka bak�m kurulu�una sevk
7)	Uzayan yat�� 
8)	Komplikasyon Yat��� 
9)	Evde Bak�m i�in taburcu 
10)	Exitus
*/
  create_new_statu('1', '�ifa �le Taburcu');
  create_new_statu('2', 'Haliyle taburcu');
  create_new_statu('3', 'Tedaviden vazge�me');
  create_new_statu('4', 'Ayn� kapsaml� ba�ka bir hastaneye sevku');
  create_new_statu('5', 'Daha kapsaml� ba�ka bir hastaneye sevk');
  create_new_statu('6', 'Orta dereceli bir ba�ka bak�m kurulu�una sevk');
  create_new_statu('7', 'Uzayan yat�� ');
  create_new_statu('8', 'Komplikasyon Yat���');
  create_new_statu('9', 'Evde Bak�m i�in taburcu ');
  create_new_statu('10', 'Exitus');
  DBMS_OUTPUT.PUT_LINE('��lem Ba�ar�l�');
  COMMIT; 
EXCEPTION WHEN OTHERS THEN
  DBMS_OUTPUT.PUT_LINE('Hata Olu�tu');
  ROLLBACK;  
END;
/

