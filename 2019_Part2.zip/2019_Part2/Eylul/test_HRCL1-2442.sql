DECLARE
  p_cur ALZ_HLTH_CPA.Refcur;
  
  PROCEDURE getPool (
      p_hold_user                IN     KOC_CLM_HLTH_COMM.hold_user%TYPE, --isi �zerine alan kullanici
      p_status                   IN     KOC_CLM_HLTH_DETAIL.cpa_status%TYPE,
      p_request_system           IN     KOC_CLM_HLTH_DETAIL.request_system%TYPE,
      p_group_code               IN     KOC_CLM_HLTH_DETAIL.group_code%TYPE,
      p_sub_company_code         IN     KOC_OCP_PARTITIONS_EXT.sub_company_code%TYPE,
      p_product_type             IN     KOC_V_HEALTH_INSURED_INFO3.product_id%TYPE,
      p_part_id_identity_no      IN     KOC_CLM_HLTH_COMM.part_id_identity_no%TYPE,
      p_policy_ref               IN     OCP_POLICY_BASES.policy_ref%TYPE,
      p_partition_no             IN     KOC_CLM_HLTH_COMM.partition_no%TYPE,
      p_claim_id_ext_reference   IN     KOC_CLM_HLTH_COMM.claim_id_ext_reference%TYPE,
      p_comm_no                  IN     KOC_CLM_HLTH_COMM.comm_no%TYPE,
      p_comm_date_start          IN     KOC_CLM_HLTH_COMM.comm_date%TYPE,
      p_realization_date         IN     KOC_CLM_HLTH_DETAIL.realization_date%TYPE,
      p_partaj                   IN     KOC_DMT_AGENTS_TITLE_EXT.title%TYPE,
      p_region                   IN     KOC_DMT_REGION_CODE_REF.explanation%TYPE,
      p_taz_user                 IN     KOC_CLM_HLTH_COMM.taz_user%TYPE, --isin atandigi kullanici
      p_card_no                  IN     KOC_HLTH_CUSTOMER_ID_CARDS.card_no%TYPE,
      p_is_automated             IN     KOC_CLM_HLTH_DETAIL.is_automated%TYPE,
      p_comm_date_end            IN     KOC_CLM_HLTH_COMM.comm_date%TYPE,
      p_agen_int_id              IN     KOC_DMT_V_CURRENT_AGENTS.agen_int_id%TYPE,
      p_statement_no             IN     KOC_CLM_HLTH_COMM.statement_no%TYPE,
      p_consider_all_status      IN     NUMBER,
      p_approval_status          IN     NUMBER,
      p_approval_date            IN     DATE,
      p_is_complementary         IN     NUMBER,      --ATASPINAR  Hibrit Taski
      p_reject_start_date        IN     KOC_CLM_HLTH_COMM.reject_letter_date%TYPE, --ATASPINAR  TYH-59751
      p_reject_end_date          IN     KOC_CLM_HLTH_COMM.reject_letter_date%TYPE, --ATASPINAR   YH-59751
      p_bireysel                 IN     NUMBER,
      p_tpa_company              IN     VARCHAR2,
      p_cur                      IN OUT ALZ_HLTH_CPA.Refcur)
   IS
      v_sql                 CLOB;
      v_columns             VARCHAR2 (2000);
      v_tables              VARCHAR2 (500);
      v_where               CLOB;
      v_order               VARCHAR2 (500);
      v_reject_start_date   DATE;
      v_reject_end_date     DATE;
      v_is_group            NUMBER(1);

   BEGIN
      v_columns :=
            'SELECT  DISTINCT c1.partition_no,
                                nvl(cpe.identity_no,c1.part_id_identity_no) part_id_identity_no,
                                nvl(cp.first_name||'' ''||cp.name,c1.ins_name) ins_name,
                                c1.claim_id_ext_reference,
                                c1.comm_no,
                                (CASE WHEN c2.cpa_status=''ET'' THEN 0 ELSE 1 END) cpa_status_order,
                                c1.claim_id,
                                c1.contract_id,
                                c1.institute_code,
                                c2.group_code,
                                ii.Policy_Ref,
                                ii.sub_company_code,
                                ii.sub_company_name,
                                ii.group_name,
                                c2.request_system,
                                ii.product_id,
                                c1.comm_doc_type,
                                c1.statement_no,
                                ii.pack_name,
                                nvl(c2.affluent_flag,0) affluent_flag,
                                c2.part_id,
                                ALZ_HLTH_CPA.Isinsuredvip_New(c2.part_id,'''|| USER|| ''') vip_flag, '||
                                --ALZ_HLTH_CPA.IsInsuredVip(c2.part_id,'''|| USER|| ''') vip_flag,--SBH-2231 vip bilgileri segment nedeniyle gelmiyor
                                'c2.package_id,
                                c2.package_date';
                                --decode(nvl(ii.is_complementary,0),1,''TSS'',0,''OSS'',2,''KARMA'') IS_COMP'; --ATASPINAR
      v_tables := 'FROM  KOC_CLM_HLTH_COMM c1,
                    KOC_CLM_HLTH_DETAIL c2,
                    KOC_V_HEALTH_INSURED_INFO ii,
                    koc_cp_partners_ext cpe ,
                    cp_partners cp';
      v_where := 'WHERE  1=1
               AND  nvl(c1.partition_no,0) <> 0
               AND  nvl(c1.claim_id,0) <> 0
               AND  cpe.part_id = cp.part_id
               AND  c1.comm_no = c2.communication_no
               AND  c1.claim_id = c2.claim_id
               AND  c2.part_id = cp.part_id
               AND  c2.sf_no = 1
               AND  c1.contract_id = ii.contract_id
               AND  c1.partition_no = ii.partition_no
               AND  ii.partner_id=c2.part_id
               AND  ii.package_id=c2.package_id
               AND  ii.package_date=c2.package_date
               AND c1.validity_start_date = (   SELECT  MAX(co.validity_start_date)
                                                FROM    KOC_CLM_HLTH_COMM co
                                                WHERE   co.comm_no = c1.comm_no)';
      --max validity_start_date, son muhaberat kaydi i�in eklendi
      --plan degisikliginde hasar da yeni plana tasiniyor
      --package_id, plan degisikliginde sadece hasara bagli planin gelmesi i�in eklendi

      v_order :=
         'ORDER BY nvl(c2.affluent_flag,0) desc,vip_flag desc,cpa_status_order,c1.comm_no';

      IF p_status IS NOT NULL
      THEN
         v_where := v_where || ' AND c2.cpa_status=:p_status';
      ELSE
         v_where := v_where || ' AND ((1=1) or :p_status is null)';
      END IF;

      --default olarak HS-HM-OB-I statuleri gelmesin
      --AND nvl(c2.cpa_status,''X'') not in(''HS'',''HM'',''OB'',''I'')
      --dosyada a�ik statulu fatura var mi kontrolu
      IF NVL (p_consider_all_status, 0) = 0
      THEN
         /*v_where:=v_where||' AND EXISTS (SELECT 1
                                 FROM   KOC_CLM_HLTH_DETAIL d1
                                 WHERE  d1.claim_id=c1.claim_id
                                   and  d1.sf_no=1
                                   and  nvl(d1.cpa_status,''X'') not in(''TAH'',''R'',''C'',''I'',''OB'',''RL''))'; Performans i�in degistirildi. Aykutt 24.06.2016*/
         v_where :=
               v_where
            || ' AND nvl(c2.cpa_status,''X'') not in(''TAH'',''R'',''C'',''I'',''OB'',''RL'',''TAH_BT'')';
      END IF;

      IF p_is_automated IS NOT NULL
      THEN
         v_where := v_where || ' AND nvl(c2.is_automated,0)=:p_is_automated';
      ELSE
         v_where := v_where || ' AND ((1=1) or :p_is_automated is null)';
      END IF;

      IF p_hold_user IS NOT NULL
      THEN
         v_where := v_where || ' AND c1.hold_user=:p_hold_user';
      ELSE
         v_where := v_where || ' AND ((1=1) or :p_hold_user is null)';
      END IF;

      IF p_group_code IS NOT NULL
      THEN
         v_where := v_where || ' AND ii.group_code=:p_group_code';
      ELSE
         v_where := v_where || ' AND ((1=1) or :p_group_code is null)';
      END IF;

      IF p_sub_company_code IS NOT NULL
      THEN
         v_where := v_where || ' AND ii.sub_company_code=:p_sub_company_code';
      ELSE
         v_where := v_where || ' AND ((1=1) or :p_sub_company_code is null)';
      END IF;

      IF p_part_id_identity_no IS NOT NULL
      THEN
         v_where := v_where || ' AND cpe.identity_no =:p_part_id_identity_no';
      ELSE
         v_where :=
            v_where || ' AND ((1=1) or :p_part_id_identity_no is null)';
      END IF;

      IF p_policy_ref IS NOT NULL
      THEN
         v_where := v_where || ' AND ii.policy_ref = :p_policy_ref';
      ELSE
         v_where := v_where || ' AND ((1=1) or :p_policy_ref is null)';
      END IF;

      IF p_partition_no IS NOT NULL
      THEN
         v_where := v_where || ' AND c1.partition_no = :p_partition_no';
      ELSE
         v_where := v_where || ' AND ((1=1) or :p_partition_no is null)';
      END IF;

      IF p_claim_id_ext_reference IS NOT NULL
      THEN
         v_where :=
               v_where
            --|| ' AND c1.claim_id_ext_reference = :p_claim_id_ext_reference'; omert performans iyilestirme
            || ' AND c2.ext_reference = :p_claim_id_ext_reference';
      ELSE
         v_where :=
            v_where || ' AND ((1=1) or :p_claim_id_ext_reference is null)';
      END IF;

      IF p_comm_no IS NOT NULL
      THEN
         v_where := v_where || ' AND c1.comm_no = :p_comm_no';
      ELSE
         v_where := v_where || ' AND ((1=1) or :p_comm_no is null)';
      END IF;

      IF p_comm_date_start IS NOT NULL AND p_comm_date_end IS NOT NULL
      THEN
         v_where :=
               v_where
            || ' AND TRUNC (c1.comm_date) >= TO_DATE(:p_comm_date_start,''DD.MM.YYYY'')
                        AND TRUNC (c1.comm_date) <= TO_DATE(:p_comm_date_end,''DD.MM.YYYY'')';
      ELSE
         v_where :=
               v_where
            || ' AND ((1=1) or :p_comm_date_start is null)
                        AND ((1=1) or :p_comm_date_end is null)';
      END IF;

      IF p_realization_date IS NOT NULL
      THEN
         v_where :=
               v_where
            || ' AND TRUNC (c2.realization_date) = TO_DATE(:p_realization_date,''DD.MM.YYYY'')';
      ELSE
         v_where := v_where || ' AND ((1=1) or :p_realization_date is null)';
      END IF;

      IF p_partaj IS NOT NULL AND p_agen_int_id IS NOT NULL
      THEN
         v_tables := v_tables || ',DMT_AGENTS ca';
         v_where :=
               v_where
            || ' AND ii.agent_int_id = ca.int_id AND ca.reference_code = :p_partaj
                        AND ca.int_id=:p_agen_int_id';
      ELSE
         v_where :=
               v_where
            || ' AND ((1=1) or :p_partaj is null)
                        AND ((1=1) or :p_agen_int_id is null)';
      END IF;

      IF p_region IS NOT NULL
      THEN
         v_where :=
               v_where
            || ' AND (LOWER (:p_region) IN
                               (SELECT   LOWER (f.explanation)
                                  FROM   KOC_CP_USER_REGION_REL r,
                                         KOC_DMT_REGION_CODE_REF f
                                 WHERE   r.region_code = f.region_code
                                   AND   r.validity_end_date IS NULL
                                   AND   r.username = c1.create_user))';
      ELSE
         v_where := v_where || ' AND ((1=1) or :p_region is null)';
      END IF;

      IF p_taz_user IS NOT NULL
      THEN
         v_where := v_where || ' AND c1.taz_user = :p_taz_user';
      ELSE
         v_where := v_where || ' AND ((1=1) or :p_taz_user is null)';
      END IF;

      IF p_card_no IS NOT NULL
      THEN
         v_tables := v_tables || ',KOC_HLTH_CUSTOMER_ID_CARDS cic';
         v_where :=
               v_where
            || ' AND cic.part_id = ii.partner_id
                        AND cic.validity_end_date IS NULL
                        AND cic.card_no = :p_card_no';
      ELSE
         v_where := v_where || ' AND ((1=1) or :p_card_no is null)';
      END IF;

      IF p_request_system IS NOT NULL
      THEN
         v_where := v_where || ' AND c2.request_system=:p_request_system';
      ELSE
         v_where := v_where || ' AND ((1=1) or :p_request_system is null)';
      END IF;

      IF p_product_type IS NOT NULL
      THEN
         v_where := v_where || ' AND ii.product_id=:p_product_type';
      ELSE
         v_where := v_where || ' AND ((1=1) or :p_product_type is null)';
      END IF;

      IF p_statement_no IS NOT NULL
      THEN
         v_where := v_where || ' AND c1.statement_no=:p_statement_no';
      ELSE
         v_where := v_where || ' AND ((1=1) or :p_statement_no is null)';
      END IF;

      IF NVL(p_bireysel,0)=0
      THEN
      v_is_group:=1;
      ELSE
      v_is_group:=0;
      END IF;

      IF p_is_complementary = 1
      THEN
         v_where := v_where || ' AND alz_hlth_karma_utils.is_complementary(c1.contract_id,c2.package_id,c2.package_date,c1.partition_no,'||v_is_group||')=1';
      ELSIF p_is_complementary = 2
      THEN
         v_where := v_where || ' AND alz_hlth_karma_utils.is_complementary(c1.contract_id,c2.package_id,c2.package_date,c1.partition_no,'||v_is_group||')=2';
      ELSIF p_is_complementary = 0
      THEN
         v_where := v_where || ' AND alz_hlth_karma_utils.is_complementary(c1.contract_id,c2.package_id,c2.package_date,c1.partition_no,'||v_is_group||')=0';
      ELSIF p_is_complementary=3 -- 0-1
      THEN
         v_where := v_where || ' AND (alz_hlth_karma_utils.is_complementary(c1.contract_id,c2.package_id,c2.package_date,c1.partition_no,'||v_is_group||')=0 or
                                     alz_hlth_karma_utils.is_complementary(c1.contract_id,c2.package_id,c2.package_date,c1.partition_no,'||v_is_group||')=1)';
      ELSIF p_is_complementary=4 -- 0-2
      THEN
         v_where := v_where || ' AND (alz_hlth_karma_utils.is_complementary(c1.contract_id,c2.package_id,c2.package_date,c1.partition_no,'||v_is_group||')=0 or
                                     alz_hlth_karma_utils.is_complementary(c1.contract_id,c2.package_id,c2.package_date,c1.partition_no,'||v_is_group||')=2)';
      ELSIF p_is_complementary=5 -- 1-2
      THEN
         v_where := v_where || ' AND (alz_hlth_karma_utils.is_complementary(c1.contract_id,c2.package_id,c2.package_date,c1.partition_no,'||v_is_group||')=1 or
                                     alz_hlth_karma_utils.is_complementary(c1.contract_id,c2.package_id,c2.package_date,c1.partition_no,'||v_is_group||')=2)';
      END IF;

      IF p_tpa_company IS NOT NULL
      THEN
        v_where := v_where || ' AND ii.company_code in ('||p_tpa_company||')';
      END IF;

      IF p_reject_start_date IS NOT NULL
      THEN   --ATASPINAR  TYH-59751 KOCCLM351 Ekrani fitltreleme icin eklendi.
         v_reject_start_date := TO_DATE (p_reject_start_date, 'dd.mm.yyyy');
         v_where :=
               v_where
            || ' AND EXISTS (SELECT NULL FROM ALZ_HLTH_CPA_DETAIL_HISTORY DH WHERE DH.CLAIM_ID = c2.CLAIM_ID and DH.ADD_ORDER_NO = c2.ADD_ORDER_NO AND DH.CPA_STATUS = ''R'' AND TRUNC(DH.PROCESS_DATE) >='''
            || TO_DATE (v_reject_start_date, 'dd.mm.yyyy')
            || ''')';
      END IF;

      IF p_reject_end_date IS NOT NULL
      THEN   --ATASPINAR  TYH-59751 KOCCLM351 Ekrani fitltreleme icin eklendi.
         v_reject_end_date := TO_DATE (p_reject_end_date, 'dd.mm.yyyy');
         v_where :=
               v_where
            || ' AND EXISTS (SELECT NULL FROM ALZ_HLTH_CPA_DETAIL_HISTORY DH WHERE DH.CLAIM_ID = c2.CLAIM_ID and DH.ADD_ORDER_NO = c2.ADD_ORDER_NO AND DH.CPA_STATUS = ''R'' AND TRUNC(DH.PROCESS_DATE) <='''
            || TO_DATE (v_reject_end_date, 'dd.mm.yyyy')
            || ''')';
      END IF;

      IF p_approval_status IS NOT NULL
      THEN
         v_tables := v_tables || ',KOC_CLM_TRANS_EXT te';
         v_where :=
               v_where
            || ' AND c2.claim_id=te.claim_id
                        AND c2.sf_no=te.sf_no
                        AND c2.add_order_no=te.add_order_no
                        AND payment_type NOT IN (''7'')
                        AND trans_no IN (
                                            SELECT x.trans_no
                                              FROM koc_clm_trans_ext x, clm_trans y
                                             WHERE x.claim_id = y.claim_id
                                               AND x.sf_no = y.sf_no
                                               AND y.trans_no = y.trans_no
                                               AND x.claim_id = te.claim_id
                                               AND x.sf_no = te.sf_no
                                               AND x.add_order_no = te.add_order_no
                                               AND y.sf_total_type IN (''11''))
                        AND trans_no IN (
                                            SELECT   MAX (x.trans_no)
                                                FROM koc_clm_trans_ext x, clm_trans y
                                               WHERE x.claim_id = y.claim_id
                                                 AND x.sf_no = y.sf_no
                                                 AND y.trans_no = y.trans_no
                                                 AND x.claim_id = te.claim_id
                                                 AND x.sf_no = te.sf_no
                                                 AND x.add_order_no = te.add_order_no
                                                 AND y.sf_total_type IN (''11'', ''12'')
                                            GROUP BY x.hlth_cover_code)';

         IF p_approval_status = 1
         THEN
            v_where :=
                  v_where
               || ' AND :p_approval_status=1
                         AND te.technical_approved_date=TO_DATE(:p_approval_date,''DD.MM.YYYY'')
                         AND c2.cpa_status in (''TAH'',''TAH_BT'')';
         ELSIF p_approval_status = 2
         THEN
            v_where :=
                  v_where
               || ' AND :p_approval_status=2
                         AND te.technical_approved_date IS NULL
                         AND c2.cpa_status in (''TAH'',''TAH_BT'')';
         ELSIF p_approval_status = 3
         THEN
            v_where :=
                  v_where
               || ' AND :p_approval_status=3
                         AND te.payment_approved_date=TO_DATE(:p_approval_date,''DD.MM.YYYY'')
                         AND c2.cpa_status=''TAH''';
         ELSIF p_approval_status = 4
         THEN
            v_where :=
                  v_where
               || ' AND :p_approval_status=4
                         AND te.payment_approved_date IS NULL
                         AND te.technical_approved_date IS NOT NULL
                         AND c2.cpa_status=''TAH''';
         END IF;
      ELSE
         v_where :=
               v_where
            || ' AND ((1=1) or :p_approval_status is null or :p_approval_date is null)';
      END IF;

      v_sql :=
         v_columns || ' ' || v_tables || ' ' || v_where || ' ' || v_order;
      DBMS_OUTPUT.PUT_LINE(v_sql);
      ALZ_HLTH_CPA.logAlzHlthCpa ('ALZ_HLTH_CPA2.xxxxxxxxxxxx',
                                  'v_sql ' || v_sql,
                                  NULL);

      ALZ_HLTH_CPA.logAlzHlthCpa (
         'ALZ_HLTH_CPA.xxxxxxxxxxxx',
            'parametreler: '
         || p_status
         || '-'
         || p_is_automated
         || '-'
         || p_hold_user
         || '-'
         || p_group_code
         || '-'
         || p_sub_company_code
         || '-'
         || p_part_id_identity_no
         || '-'
         || p_policy_ref
         || '-'
         || p_partition_no
         || '-'
         || p_claim_id_ext_reference
         || '-'
         || p_comm_no
         || '-'
         || p_comm_date_start
         || '-'
         || p_comm_date_end
         || '-'
         || p_realization_date
         || '-'
         || p_partaj
         || '-'
         || p_agen_int_id
         || '-'
         || p_region
         || '-'
         || p_taz_user
         || '-'
         || p_card_no
         || '-'
         || p_request_system
         || '-'
         || p_product_type
         || '-'
         || p_statement_no
         || '-'
         || p_approval_status
         || '-'
         || p_approval_date
         || '-'
         || p_reject_start_date
         || '-'
         || p_reject_end_date
         || '-'
         || p_consider_all_status,
         NULL);

      --IF NOT p_Cur%ISOPEN THEN
      OPEN p_Cur FOR v_sql
         USING p_status,
               p_is_automated,
               p_hold_user,
               p_group_code,
               p_sub_company_code,
               p_part_id_identity_no,
               p_policy_ref,
               p_partition_no,
               p_claim_id_ext_reference,
               p_comm_no,
               p_comm_date_start,
               p_comm_date_end,
               p_realization_date,
               p_partaj,
               p_agen_int_id,
               p_region,
               p_taz_user,
               p_card_no,
               p_request_system,
               p_product_type,
               p_statement_no,
               p_approval_status,
               p_approval_date; --,p_reject_start_date,p_reject_end_date; --ATASPINAR
   --END IF;

   EXCEPTION
      WHEN OTHERS
      THEN
         ALZ_HLTH_CPA.logAlzHlthCpa (
            'ALZ_HLTH_CPA.getPool',
               'Sonradan �deme Ekran� - �� havuzu listelenirken hata al�nd�! '
            || SUBSTR (SQLERRM, 1, 2000),
            NULL);
   END getPool;


  procedure print_data(cur_ IN ALZ_HLTH_CPA.Refcur) IS 
    v_data_msg CLOB;
    v_keys_data VARCHAR2(4000);
    v_ndx number := 0;
    BEGIN
    v_data_msg := '[';
  FOR rec_1 IN (SELECT ROWNUM ROW_NO, 
                                      t1.column_value.getStringVal() ROW_DATA
                                 FROM (SELECT * FROM TABLE (XMLSEQUENCE(cur_))) t1)    
                 LOOP                   
                     IF rec_1.ROW_NO>1 THEN
                         v_data_msg := v_data_msg || ',';
                     END IF;
                     v_data_msg := v_data_msg || '{';
                     v_ndx := 0;
                     FOR rec_2 IN (SELECT EXTRACTVALUE (t.COLUMN_VALUE, '/*') AS NODE_VALUE,
                                                        t.COLUMN_VALUE.getrootelement () AS NODE_NAME
                                     FROM TABLE (XMLSEQUENCE (EXTRACT(EXTRACT(XMLTYPE(rec_1.ROW_DATA), '//*'), '/ROW/*'))) t)
                     LOOP
                        IF v_ndx>0 THEN
                           v_data_msg := v_data_msg || ',';
               IF rec_1.ROW_NO = 1 THEN
                v_keys_data := v_keys_data || ',';
               END IF;
                        END IF;
            IF rec_1.ROW_NO = 1 THEN
              v_keys_data := v_keys_data || LOWER(rec_2.NODE_NAME);
            END IF;
                        v_data_msg := v_data_msg || '"' || LOWER(rec_2.NODE_NAME) || '":"' || TRIM(rec_2.Node_Value) || '"';
                        v_ndx := v_ndx + 1;                         
                     END LOOP;
                     v_data_msg := v_data_msg || '}';
                 END LOOP;     
    --DBMS_OUTPUT.PUT_LINE(v_keys_data);
    v_data_msg := v_data_msg || ']';
    DBMS_OUTPUT.PUT_LINE(v_data_msg);
  END print_data;
BEGIN

  --ALZ_HLTH_CPA.
  getPool(null,null,null,null,null,null,null,null,null,'58648657',null,null,null,null,null,'ARTOSUN',null,0,null,null,null,0,null,null,6,null,null,0,null,p_cur);
  
  print_data(p_cur);
  
END;
