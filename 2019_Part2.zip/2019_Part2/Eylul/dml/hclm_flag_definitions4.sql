insert into alz_hclm_institute_info(institute_code, hclm_usage) values(1540, 1); 

insert into alz_hclm_institute_info(institute_code, hclm_usage) values(5104, 1); 
 
COMMIT;

 
