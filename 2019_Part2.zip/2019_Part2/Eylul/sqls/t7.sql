alz_hlth_cpa.getPool;

select * from ALZ_HLTH_CPA_LOG WHERE USERNAME='ARTOSUN' AND LOG_DATE>TRUNC(SYSDATE)

-0---------------ARTOSUN---------0

SELECT * FROM alz_hclm_institute_info where institute_code=1464 for update
