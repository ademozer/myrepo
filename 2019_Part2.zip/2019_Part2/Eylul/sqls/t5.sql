select * from koc_clm_hlth_detail where ext_reference='58108697' for update
--'56236535' for update--'58108579'
56236535

select * from KOC_CLM_HLTH_COMM where claim_id= 41906626   --2019307356

select * from alz_hclm_version_info where claim_id=41906626;

select * from ALZ_HLTH_CPA_LOG WHERE name LIKE 'ALZ_HLTH_CPA.HRCL1-2442%' and  LOG_DATE>TRUNC(SYSDATE);

koc_clm_hlth_trnx;

SELECT *--Contract_Id, Vade_Tarihi
        FROM Alz_Payment_Diff_Table;
        
        select * from clm_subfiles where ext_reference='58108605';
        select SUM(PROVISION_TOTAL) from koc_clm_hlth_provisions where claim_id=41906672--41906673
        select * from alz_hclm_version_info where claim_id=41906672--41906673;
        
        select * from alz_hltprv_log where log_id=132473852;
        
        koc_clm_hlth_report_utils.sendclmabsentdoclist
        
        
