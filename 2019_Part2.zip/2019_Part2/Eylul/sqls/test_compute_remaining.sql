DECLARE

  p_Out_Provision_Amount NUMBER;
  p_Out_Day_Seance       NUMBER;
  p_Out_Exemption_Rate   NUMBER;
  p_Out_Exemption_Sum    NUMBER;
  p_Out_Inst_Exemp_Sum   NUMBER;
  p_r_Day_Seance         NUMBER;
  p_r_Cover_Price        NUMBER;
  p_Out_Over_Price       NUMBER;
 
  TYPE CoverInfoParamRec IS RECORD(
      Cover_Code            VARCHAR2(10),
      Provision_Amount       NUMBER,
      Day_Seance            NUMBER,
      Exemption_Over_Amount NUMBER,
      Is_Pool_Cover            NUMBER,
      Is_Special_Cover         NUMBER
  );

 TYPE CoverInfoParamTyp IS TABLE OF CoverInfoParamRec INDEX BY BINARY_INTEGER;
 
 TYPE ProvOutParamRec IS RECORD(
      Cover_Code                 VARCHAR2(10),
      Provision_Amount           NUMBER,
      Day_Seance                 NUMBER,
      Exemption_Rate             NUMBER,
      Exemption_Sum              NUMBER,
      Inst_Exemp_Sum             NUMBER,
      Remained_Day_Seance        NUMBER,
      Remained_Cover_Price       NUMBER,
      Over_Price                 NUMBER
  );

  TYPE ProvOutParamTyp IS TABLE OF ProvOutParamRec INDEX BY BINARY_INTEGER;
  
  
    FUNCTION booleanToString(p_boolean IN NUMBER) RETURN VARCHAR2 IS
    BEGIN
        RETURN (CASE NVL(p_boolean, 0) WHEN 1 THEN 'true' ELSE 'false' END);
    END booleanToString;

    FUNCTION dateToString(p_date IN DATE) RETURN VARCHAR2 IS
          v_date  DATE;
          v_timestamp TIMESTAMP;
          v_timezone VARCHAR2(20);
          v_return VARCHAR2(100);
    BEGIN
        v_return := '';
        v_date := p_date;
        IF v_date IS NOT NULL THEN
           /*
             dbtimezone fonksiyonu +03:00 d�nd�rmektedir.
             2017 y�l�nda kal�c� yaz saati uygulamas�na ge�ilmi�tir.
             bu tarihten �nceki y�lllarda Eyl�l ve Mart aylar� aras�nda +02:00 olabilmektedir.
           */
           IF v_date > TO_DATE('2017','YYYY') THEN
               v_timezone := dbtimezone;
           ELSE
               v_timezone := TO_CHAR(TO_TIMESTAMP_TZ(TO_CHAR(v_date,'YYYY-MM-DD')||' Europe/Istanbul','YYYY-MM-DD TZR'),'TZH:TZM');
           END IF;
           v_timestamp := CAST (v_date AS TIMESTAMP WITH LOCAL TIME ZONE);
           v_return := TO_CHAR(v_date,'YYYY-MM-DD')||'T'||TO_CHAR(v_timestamp,'HH24:MI:SS.FF3')||v_timezone;
        END IF;
        RETURN v_return;
    END dateToString;

    FUNCTION numberToString(p_number IN NUMBER) RETURN VARCHAR2 IS
        v_string VARCHAR2(100);
    BEGIN
        v_string := REPLACE(TO_CHAR(p_number),',','.');
        IF INSTR(v_string,'.') = 1 THEN
           v_string := '0'||v_string;
        END IF;
        RETURN v_string;
    END numberToString;

    FUNCTION stringToNumber(p_string IN VARCHAR2) RETURN NUMBER IS
    BEGIN
       IF NVL(p_string, 'null') = 'null' THEN
          RETURN NULL;
       END IF;
       RETURN TO_NUMBER(p_string,'999999999.9999');
    END stringToNumber;
  
  function convertCoverInfoListToPayload(p_Cover_Info_List       IN CoverInfoParamTyp) RETURN CLOB IS
        v_cover_list CLOB;
     BEGIN

          v_cover_list := '[';

          FOR ndx IN 1..p_Cover_Info_List.COUNT LOOP

              IF ndx>1 THEN
                 v_cover_list := v_cover_list || ',';
              END IF;

              v_cover_list := v_cover_list || '{
                    "coverCode" : "'||p_Cover_Info_List(ndx).Cover_Code||'",
                    "daySeance" : "'||TO_CHAR(NVL(p_Cover_Info_List(ndx).Day_Seance,0))||'",
                    "exemptionOverAmount" : "'||numberToString(p_Cover_Info_List(ndx).Exemption_Over_Amount)||'",
                    "poolCover" : "'||booleanToString(p_Cover_Info_List(ndx).Is_Pool_Cover)||'",
                    "provisionAmount" : "'||numberToString(NVL(p_Cover_Info_List(ndx).Provision_Amount,0))||'",
                    "specialCover" : "'||booleanToString(p_Cover_Info_List(ndx).Is_Special_Cover)||'"
              }';

          END LOOP;

          v_cover_list := v_cover_list || ']';

          RETURN v_cover_list;

     END convertCoverInfoListToPayload;
     
 procedure computeRemainingList(p_Contract_Id           IN NUMBER,
                                    p_Partition_No          IN NUMBER,
                                    p_Institute_Code        IN NUMBER,
                                    p_Claim_Inst_Type       IN VARCHAR2 DEFAULT NULL,
                                    p_Claim_Inst_Loc        IN VARCHAR2 DEFAULT NULL,
                                    p_Country_Group         IN VARCHAR2 DEFAULT NULL,
                                    p_Cover_Info_List       IN CoverInfoParamTyp,
                                    p_Swift_Code            IN VARCHAR2,
                                    p_Query_Date            IN DATE,
                                    p_Is_Referral           IN NUMBER DEFAULT NULL,
                                    p_User_Id               IN VARCHAR2,
                                    p_Out_Param_List        OUT ProvOutParamTyp) IS
       CURSOR crs_user IS
          SELECT d.user_type, g.user_group
            FROM CUSTOMER.Koc_Cp_User_Detail d, CUSTOMER.Koc_Oc_Hlth_User_Grp_Rel g
           WHERE d.Userid = p_User_Id
             AND d.user_type = g.user_type
             AND d.Validity_Start_Date <= p_Query_Date
             AND (d.Validity_End_Date IS NULL OR d.Validity_End_Date >= p_Query_Date)
             AND g.Validity_Start_Date <= p_Query_Date
             AND (g.Validity_End_Date IS NULL OR g.Validity_End_Date >= p_Query_Date);

        rec_user crs_user%ROWTYPE;

        CURSOR crs_policy IS
           SELECT Partner_Id, Policy_Start_Date, Group_Code
             FROM CUSTOMER.Koc_v_Hlth_Insured_Info_Indem
            where contract_id = p_Contract_Id
              and partition_no = p_Partition_No;

         rec_policy crs_policy%ROWTYPE;

         v_hltprv_Log          Hltprv_Log_Typ := Hltprv_Log_Typ();

         v_request CLOB;
         v_response CLOB;
         v_url VARCHAR2(200) := get_url_link('http://esb.allianz.com.tr:12000/hclm-health-claim-service/api/v1/computeremaining/list');
         v_status NUMBER;
         v_message VARCHAR2(1000);
         v_cover_info VARCHAR2(32000);
         v_user_group VARCHAR2(32000);
         v_ndx NUMBER:=0;
         v_ndx1      NUMBER;
         v_ndx2      NUMBER;
     BEGIN

         OPEN crs_policy;
         FETCH crs_policy INTO rec_policy;
         CLOSE crs_policy;

         v_user_group := '';

         FOR rec_user IN crs_user LOOP

            IF v_ndx > 0 THEN

                v_user_group :=  v_user_group || ',';

            END IF;

            v_user_group := v_user_group||'"'||rec_user.user_group||'"';

            v_ndx := v_ndx + 1;

         END LOOP;

         v_request := '{
            "claimInstLoc" : "'||p_Claim_Inst_Loc||'",
            "claimInstType" : "'||p_Claim_Inst_Type||'",
            "countryGroup" : "'||p_Country_Group||'",
            "contractId" : "'||TO_CHAR(p_Contract_Id)||'",
            "coverInfoParamList" : '|| convertCoverInfoListToPayload(p_Cover_Info_List) ||',
            "instituteCode" : "'||TO_CHAR(p_Institute_Code)||'",
            "invoiceDate" : "'||dateToString(p_Query_Date)||'",
            "partitionNo" : "'||TO_CHAR(p_Partition_No)||'",
            "partnerId" : "'||TO_CHAR(rec_policy.Partner_Id)||'",
            "policyGroupCode" : "'||rec_policy.Group_Code||'",
            "policyStartDate" : "'||dateToString(rec_policy.Policy_Start_Date)||'",
            "queryDate" : "'||dateToString(p_Query_Date)||'",
            "realizationDate" : "'||dateToString(p_Query_Date)||'",
            "referral" : "'||booleanToString(p_Is_Referral)||'",
            "swiftCode": "'||p_Swift_Code||'",
            "userGroup": ['||v_user_group||']
        }';

         v_hltprv_Log.Log_Id        := NULL;
         v_hltprv_Log.Servicename   := 'ALZ_HCLM_CONVERTER_UTILS';
         v_hltprv_Log.Processinfo   := v_url;
         v_hltprv_Log.Note          := 'COMPUTE_REMAINING_REQUEST';
         v_hltprv_Log.Content       := v_request;
         v_hltprv_Log.Institutecode := p_Institute_Code;
         v_hltprv_Log.Log_Source    := 'PLSQL';
         v_hltprv_Log.Savelogwithpragma;

         CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.callRestService(v_url, 'POST', v_request, v_response, v_status, v_message);

         v_hltprv_Log.Servicename   := 'ALZ_HCLM_CONVERTER_UTILS';
         v_hltprv_Log.Processinfo   := v_url;
         v_hltprv_Log.Note          := 'COMPUTE_REMAINING_RESPONSE';
         v_hltprv_Log.Content       := v_response;
         v_hltprv_Log.Institutecode := p_Institute_Code;
         v_hltprv_Log.Log_Source    := 'PLSQL';
         v_hltprv_Log.Savelogwithpragma;

         IF v_status = 0 THEN
             v_ndx1 := INSTR(v_response,'{"data" : {');
             v_ndx2 := INSTR(v_response,'},"uiMessages"') - v_ndx1;
             v_response := SUBSTR(v_response, v_ndx1+11, v_ndx2-11);
         ELSE
             v_ndx1 := INSTR(v_response,'{"errors" : [');
             v_ndx2 := INSTR(v_response,'],"warnings"') - v_ndx1;
             v_response := SUBSTR(v_response, v_ndx1+15, v_ndx2-17);
         END IF;

         v_response := replace(replace(replace(replace(v_response,'[{', ''),'}',''),'}]',''),'{','');
         v_ndx := 0;
         FOR rec IN (SELECT TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1) , '"',''))   KEY,
                            TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1, 2), '"','')) VALUE1,
                            TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1, 3), '"','')) VALUE2
                     FROM (SELECT Regexp_Substr (v_response, '[^,]+', 1, LEVEL) ELEMENT
                             FROM Dual
                          CONNECT BY LEVEL <= LENGTH (Regexp_Replace (v_response, '[^,]+')) + 1)) LOOP

              IF rec.KEY = 'message' THEN
                v_message := rec.value1;
              END IF;

              IF rec.VALUE2 IS NOT NULL THEN
                  IF rec.VALUE1 = 'provisionAmount' THEN
                      v_ndx := v_ndx + 1;
                      p_Out_Param_List(v_ndx).Provision_Amount := stringToNumber(rec.VALUE2);
                      p_Out_Param_List(v_ndx).Cover_Code       := rec.KEY;
                  END IF;
              END IF;

              IF rec.KEY = 'daySeance' THEN
                  p_Out_Param_List(v_ndx).Day_Seance := stringToNumber(rec.VALUE1);
              END IF;

              IF rec.KEY = 'exemptionRate' THEN
                  p_Out_Param_List(v_ndx).Exemption_Rate := stringToNumber(rec.VALUE1);
              END IF;

              IF rec.KEY = 'exemptionSumAmount' THEN
                  p_Out_Param_List(v_ndx).Exemption_Sum := stringToNumber(rec.VALUE1);
              END IF;

              IF rec.KEY = 'instituteExemptionSumAmount' THEN
                  p_Out_Param_List(v_ndx).Inst_Exemp_Sum := stringToNumber(rec.VALUE1);
              END IF;

              IF rec.KEY = 'overPriceAmount' THEN
                  p_Out_Param_List(v_ndx).Over_Price := stringToNumber(rec.VALUE1);
              END IF;

              IF rec.KEY = 'remainedCoverPriceAmount' THEN
                  p_Out_Param_List(v_ndx).Remained_Cover_Price := stringToNumber(rec.VALUE1);
              END IF;

              IF rec.KEY = 'remainedDaySeance' THEN
                  p_Out_Param_List(v_ndx).Remained_Day_Seance := stringToNumber(rec.VALUE1);
              END IF;

        END LOOP;

        IF v_status = 1 THEN
           Raise_Application_Error(-20200,  v_message);
        END IF;
     EXCEPTION
     WHEN OTHERS THEN
          v_hltprv_Log.Servicename   := 'ALZ_HCLM_CONVERTER_UTILS';
          v_hltprv_Log.Processinfo   := v_url;
          v_hltprv_Log.Note          := 'COMPUTE_REMAINING_EXCEPTION';
          v_hltprv_Log.Content       := v_message || dbms_utility.format_error_stack || dbms_utility.format_error_backtrace;
          v_hltprv_Log.Institutecode := p_Institute_Code;
          v_hltprv_Log.Log_Source    := 'PLSQL';
          v_hltprv_Log.Savelogwithpragma;
          Raise_Application_Error(-20200,  'Limit Hesaplama S�ras�nda Bir Hata Olu�tu:'||v_hltprv_Log.Log_Id||':'||v_message);
     END computeRemainingList;

     procedure computeRemaining(p_Contract_Id           IN NUMBER,
                                p_Partition_No          IN NUMBER,
                                p_Institute_Code        IN NUMBER,
                                p_Claim_Inst_Type       IN VARCHAR2 DEFAULT NULL,
                                p_Claim_Inst_Loc        IN VARCHAR2 DEFAULT NULL,
                                p_Country_Group         IN VARCHAR2 DEFAULT NULL,
                                p_Cover_Code            IN VARCHAR2,
                                p_Swift_Code            IN VARCHAR2,
                                p_Query_Date            IN DATE,
                                p_Provision_Amount      IN NUMBER,
                                p_Day_Seance            IN NUMBER,
                                p_Is_Pool_Cover         IN NUMBER,
                                p_Is_Special_Cover      IN NUMBER,
                                p_Exemption_Ovr_Amount  IN NUMBER DEFAULT NULL,
                                p_Is_Referral           IN NUMBER DEFAULT NULL,
                                p_User_Id               IN VARCHAR2,
                                p_Out_Provision_Amount OUT NUMBER,
                                p_Out_Day_Seance       OUT NUMBER,
                                p_Out_Exemption_Rate   OUT NUMBER,
                                p_Out_Exemption_Sum    OUT NUMBER,
                                p_Out_Inst_Exemp_Sum   OUT NUMBER,
                                p_r_Day_Seance         OUT NUMBER,
                                p_r_Cover_Price        OUT NUMBER,
                                p_Out_Over_Price       OUT NUMBER) IS

         coverInfoList coverInfoParamTyp;
         ProvOutList   ProvOutParamTyp;

     BEGIN
         coverInfoList(1).Cover_Code := p_Cover_Code;
         coverInfoList(1).Day_Seance := p_Day_Seance;
         coverInfoList(1).Provision_Amount := p_Provision_Amount;
         coverInfoList(1).Exemption_Over_Amount := p_Exemption_Ovr_Amount;
         coverInfoList(1).Is_Pool_Cover := p_Is_Pool_Cover;
         coverInfoList(1).Is_Special_Cover := p_Is_Special_Cover;

         computeRemainingList(p_Contract_Id,
                              p_Partition_No,
                              p_Institute_Code,
                              p_Claim_Inst_Type,
                              p_Claim_Inst_Loc,
                              p_Country_Group,
                              coverInfoList,
                              p_Swift_Code,
                              p_Query_Date,
                              p_Is_Referral,
                              p_User_Id,
                              ProvOutList);

          IF ProvOutList.COUNT > 0 THEN
              p_Out_Provision_Amount := ProvOutList(1).Provision_Amount;
              p_Out_Day_Seance       := ProvOutList(1).Day_Seance;
              p_Out_Exemption_Rate   := ProvOutList(1).Exemption_Rate;
              p_Out_Exemption_Sum    := ProvOutList(1).Exemption_Sum;
              p_Out_Inst_Exemp_Sum   := ProvOutList(1).Inst_Exemp_Sum;
              p_r_Day_Seance         := ProvOutList(1).Remained_Day_Seance;
              p_r_Cover_Price        := ProvOutList(1).Remained_Cover_Price;
              p_Out_Over_Price       := ProvOutList(1).Over_Price;
          END IF;

     END computeRemaining;
 BEGIN
   
 /*v_request := '{
            "claimInstLoc" : "YI",
            "claimInstType" : "AK",
            "countryGroup" : "0",
            "contractId" : "419139242",
            "coverInfoParamList" : [{
                    "coverCode" : "S511",
                    "daySeance" : "0",
                    "exemptionOverAmount" : "",
                    "poolCover" : "false",
                    "provisionAmount" : "10000",
                    "specialCover" : "false"
              }],
            "instituteCode" : "175",
            "invoiceDate" : "2019-09-06T00:00:00.000+03:00",
            "partitionNo" : "40797",
            "partnerId" : "45796623",
            "policyGroupCode" : "S9136",
            "policyStartDate" : "2018-10-01T00:00:00.000+03:00",
            "queryDate" : "2019-09-06T00:00:00.000+03:00",
            "realizationDate" : "2019-09-06T00:00:00.000+03:00",
            "referral" : "false",
            "swiftCode": "TL",
            "userGroup": ["2","3","4"]
        }';*/
        
        computeRemaining(419139242,                         
                         40797,
                         175,
                         'AK',
                         'YI',
                         '0',
                         'S511',
                         'TL',
                         SYSDATE,
                         10000,
                         0,
                         0,
                         0,
                         null,
                         0,
                         'MEDISER161',
                         p_Out_Provision_Amount,
                         p_Out_Day_Seance,
                         p_Out_Exemption_Rate,
                         p_Out_Exemption_Sum,
                         p_Out_Inst_Exemp_Sum,
                         p_r_Day_Seance,
                         p_r_Cover_Price,
                         p_Out_Over_Price);
                         
     DBMS_OUTPUT.PUT_LINE('prov_amo='||p_Out_Provision_Amount);
     DBMS_OUTPUT.PUT_LINE('exmp_rat='||p_Out_Exemption_Rate);
 END;                        
        
        
