DECLARE
    v_rt NUMBER:=0;
    PROCEDURE sendclmabsentdoclist (p_grup_ferdi         clm_pol_bases.product_id%TYPE,
                                   p_tarih_start        koc_clm_hlth_incomp_papers.entry_date%TYPE DEFAULT NULL,
                                   p_tarih_end          koc_clm_hlth_incomp_papers.entry_date%TYPE DEFAULT NULL,
                                   p_group_code         koc_clm_hlth_detail.group_code%TYPE DEFAULT NULL,
                                   p_pol_ref_start      clm_pol_bases.policy_ref%TYPE,
                                   p_pol_ref_end        clm_pol_bases.policy_ref%TYPE,
                                   --p_contract_start_id  clm_pol_bases.contract_id%TYPE, --cozbay task148244 artil police no gelecek
                                   --p_contract_end_id    clm_pol_bases.contract_id%TYPE,
                                   p_agent_role         NUMBER DEFAULT NULL,
                                   p_sub_agent          NUMBER DEFAULT NULL,
                                   p_email              VARCHAR2,
                                   p_email_type         VARCHAR2,
                                   p_sub_company_code   koc_ocp_partitions_ext.sub_company_code%TYPE,
                                   p_company_code       VARCHAR2 DEFAULT NULL, -- engine 29032017 TPA
                                   p_rt             OUT NUMBER) IS
      v_row_line            VARCHAR2 (3000);
      v_head_line           VARCHAR2 (3000);
      v_number              NUMBER;
      v_mail                koc_smtp_wa_util.par_list;
      v_attachment          koc_smtp_wa_util.attachs;
      v_p_to                koc_smtp_wa_util.addresses;
      v_p_cc                koc_smtp_wa_util.addresses;
      v_offset              NUMBER;
      v_html                VARCHAR2 (2000);
      v_summary             VARCHAR2 (2000);
      v_db                  VARCHAR2 (500);
      v_mail_address        VARCHAR2 (100)                   DEFAULT '';
      v_chr_lf     CONSTANT VARCHAR2 (4)                     := CHR (13);
      v_chr_tab    CONSTANT VARCHAR2 (4)                     := CHR (9);
      v_mail_status         NUMBER                           := 0;
      p_txtlinetype         koc_smtp_wa_util.txtlinetype;
      p_txtlinetype1        koc_smtp_wa_util.txtlinetype;
      p_txtlinetype2        koc_smtp_wa_util.txtlinetype;
      p_txtlinetype3        koc_smtp_wa_util.txtlinetype;
      p_txtlinetype4        koc_smtp_wa_util.txtlinetype;
      p_txtlinetype5        koc_smtp_wa_util.txtlinetype;
      p_txtlinetype6        koc_smtp_wa_util.txtlinetype;
      filename1             VARCHAR2 (100);
      filename2             VARCHAR2 (100);
      filename3             VARCHAR2 (100);
      filename4             VARCHAR2 (100);
      filename5             VARCHAR2 (100);
      filename6             VARCHAR2 (100);
      n_fmt                 VARCHAR2 (30)         := '999G999G999G999G999D99';
      v_grup_ferdi          NUMBER                           := 63;
      vacente               dmt_agents.reference_code%TYPE;
      vacente2              dmt_agents.reference_code%TYPE;
      vekipkodu             dmt_agents.reference_code%TYPE;
      vsigortaliadi         VARCHAR2 (200);
      vneden                VARCHAR2 (200);
      vikincionaytarih      DATE;
      vgrupkodu             VARCHAR2 (20);
      vgrupadi              VARCHAR2 (100);
      vkalanteminat         NUMBER                           := 0;
      vkalanmuaf            NUMBER                           := 0;
      verr                  NUMBER                           := 0;
      vrefuse_explanation   VARCHAR2 (200);
      v_cc_email            VARCHAR2 (200);
      vmain_code            VARCHAR2 (4);
      vitem_code            VARCHAR2 (4);
      vsub_item_code        VARCHAR2 (4);
      vrefuse_amount        NUMBER;
      vtah_red_neden        VARCHAR2 (750);
      vteminat_disi         VARCHAR2 (200);
      vtarih_subject        VARCHAR2 (30);
      vek_subject           VARCHAR2 (50);
      vstring               VARCHAR2 (4000);
      vwhere                VARCHAR2 (4000);
      vred_neden            VARCHAR2 (750);
      veksik_neden          VARCHAR2 (750);
      vpartner_name         VARCHAR2 (500);
      vgroup_desc           VARCHAR2 (100);
      v_mail_id             NUMBER;
      v_sub_comp_code_name  koc_cp_group_master.description%TYPE;
      v_found               NUMBER;
      v_user                VARCHAR2(100); -- engine 29032017 TPA
      v_company_title       alz_tpa_companies.title%type;

      TYPE redrec IS RECORD (
         product_id           NUMBER (5),
         add_order_no         NUMBER (5),
         claim_id             NUMBER (10),
         refuse_explanation   VARCHAR2 (750),
         main_code            VARCHAR2 (4),
         item_code            VARCHAR2 (4),
         sub_item_code        VARCHAR2 (4),
         entry_date           DATE,
         refuse_amount        NUMBER,
         status_exp           VARCHAR2 (50),
         mektup_no            VARCHAR2 (100),
         policy_ref           VARCHAR2 (50),
         part_id              NUMBER (10),
         oar_no               NUMBER (5),
         ext_reference        VARCHAR2 (30),
         group_code           VARCHAR2 (10),
         invoice_total        NUMBER,
         comm_date            DATE,
         status_code          VARCHAR2 (30),
         agent_role           NUMBER (10),
         sub_agent            NUMBER (10),
         invoice_date         DATE,
         invoice_no           VARCHAR2(50),
         institute_code       NUMBER,
         date_of_loss         DATE,
         sub_company_code     VARCHAR2(10)
      );

      TYPE vrefcur IS REF CURSOR;

      vredcur               vrefcur;

      TYPE tredrec IS TABLE OF redrec;

      red_rec               tredrec;
      red_kontrol           NUMBER                           := 0;

      TYPE eksikrec IS RECORD (
         product_id        NUMBER (5),
         add_order_no      NUMBER (5),
         claim_id          NUMBER (10),
         absent_doc_code   VARCHAR2 (4),
         contract_id       NUMBER (10),
         entry_date        DATE,
         status_exp        VARCHAR2 (50),
         mektup_no         VARCHAR2 (100),
         policy_ref        VARCHAR2 (50),
         oar_no            NUMBER (5),
         part_id           NUMBER (10),
         --partnername       VARCHAR2 (500),   24.06.2009 aysel
         group_code        VARCHAR2 (10),
         invoice_total     NUMBER,
         comm_date         DATE,
         ext_reference     VARCHAR2 (30),
         agent_role        NUMBER (10),
         sub_agent         NUMBER (10),
         explanation       VARCHAR2 (75),
         invoice_date      DATE,
         invoice_no        VARCHAR2(50),
         institute_code    NUMBER,
         date_of_loss      DATE ,
         user_id           VARCHAR2(30),
         sub_company_code  VARCHAR2(10)
      );

      veksikcur             vrefcur;

      TYPE teksikrec IS TABLE OF eksikrec;

      eksik_rec             teksikrec;
      eksik_kontrol         NUMBER                           := 0;

      TYPE kesinrec IS RECORD (
         ext_reference                 VARCHAR2 (30),
         policy_ref                    VARCHAR2 (50),
         approve_date                  DATE,
         payment_approve_cancel_date   DATE,
         cancel_reason_code            VARCHAR2 (10),
         invoice_total                 NUMBER,
         agent_role                    NUMBER (10),
         sub_agent                     NUMBER (10),
         part_id                       NUMBER (10),
         claim_id                      NUMBER (10),
         sf_no                         NUMBER (4),
         add_order_no                  NUMBER (2)
      );

      vkesincur             vrefcur;

      TYPE tkesinrec IS TABLE OF kesinrec;

      kesin_rec             tkesinrec;
      kesin_kontrol         NUMBER                           := 0;
      vodeme_tutar          NUMBER;

      TYPE tahakkukrec IS RECORD (
         claim_id                  NUMBER (10),
         sf_no                     NUMBER (5),
         process_date              DATE,
         product_id                NUMBER (5),
         add_order_no              NUMBER (5),
         group_code                VARCHAR2 (20),
         policy_ref                VARCHAR2 (50),
         sig_no                    NUMBER (10),
         version_no                NUMBER (5),
         part_id                   NUMBER (15),
         realization_ticket_date   DATE,
         contract_id               NUMBER (15),
         exemption_rate            NUMBER,
         creditor_bank             NUMBER,
         creditor_subsidiary       NUMBER,
         account_no                VARCHAR2 (50),
         hlth_cover_code           VARCHAR2 (10),
         ext_reference             VARCHAR2 (30),
         claim_inst_type           VARCHAR2 (10),
         claim_inst_loc            VARCHAR2 (10),
         country_code              VARCHAR2 (10),
         is_special_cover          NUMBER,
         is_pool_cover             NUMBER,
         location_code             NUMBER,
         invoice_amt               NUMBER,
         sumtrans                  NUMBER,
         invoice_date              DATE,
         invoice_no                VARCHAR2(50),
         institute_code            NUMBER,
         date_of_loss              DATE,
         user_id                   VARCHAR2 (30) -- engine 29032017 TPA
      );

      vtahakkukcur          vrefcur;

      TYPE ttahakkukrec IS TABLE OF tahakkukrec;

      tahakkuk_rec          ttahakkukrec;
      tahakkuk_kontrol      NUMBER                           := 0;
      vwhere_tarih          VARCHAR2 (200);
      vwhere_groupby        VARCHAR2 (600);
      vfamily_code          VARCHAR2 (50);
      vbank_name            VARCHAR2 (200);
      vsubsidiary_name      VARCHAR2 (200);
      vcover_def            VARCHAR2 (200);
      vcountry_group        VARCHAR2 (200);

      TYPE bankasiztahakkukrec IS RECORD (
         claim_id                  NUMBER (10),
         sf_no                     NUMBER (5),
         process_date              DATE,
         product_id                NUMBER (5),
         add_order_no              NUMBER (5),
         group_code                VARCHAR2 (20),
         policy_ref                VARCHAR2 (50),
         sig_no                    NUMBER (10),
         version_no                NUMBER (5),
         part_id                   NUMBER (15),
         realization_ticket_date   DATE,
         contract_id               NUMBER (15),
         exemption_rate            NUMBER,
         creditor_bank             NUMBER,
         creditor_subsidiary       NUMBER,
         account_no                VARCHAR2 (50),
         hlth_cover_code           VARCHAR2 (10),
         ext_reference             VARCHAR2 (30),
         claim_inst_type           VARCHAR2 (10),
         claim_inst_loc            VARCHAR2 (10),
         country_code              VARCHAR2 (10),
         is_special_cover          NUMBER,
         is_pool_cover             NUMBER,
         location_code             NUMBER,
         invoice_amt               NUMBER,
         sumtrans                  NUMBER,
         invoice_date              DATE,
         invoice_no                VARCHAR2(50),
         institute_code            NUMBER,
         date_of_loss              DATE,
         user_id                   VARCHAR2 (30) -- engine 29032017 TPA
      );

      vbankasiztahakkukcur          vrefcur;

      TYPE tbankasiztahakkukrec IS TABLE OF bankasiztahakkukrec;

      bankasiztahakkuk_rec          tbankasiztahakkukrec;
      bankasiztahakkuk_kontrol      NUMBER                           := 0;

      TYPE mahsuprec IS RECORD (
         product_id                NUMBER (3),
         group_code                VARCHAR2 (20),
         realization_ticket_date   DATE,
         part_id                   NUMBER (10),
         sig_no                    NUMBER (10),
         policy_ref                VARCHAR2 (50),
         ext_reference             VARCHAR2 (30),
         process_date              DATE,
         contract_id               NUMBER (10),
         sumtrans                  NUMBER,
         sumtrans_banka            NUMBER,
         sumtrans_elden            NUMBER
      );

      vmahsupcur            vrefcur;

      TYPE tmahsuprec IS TABLE OF mahsuprec;

      mahsup_rec            tmahsuprec;
      mahsup_kontrol        NUMBER                           := 0;

      v_term_end_date       DATE;

      CURSOR cur_end_date IS
        SELECT term_end_date
          FROM ocp_policy_bases
         WHERE policy_ref =p_pol_ref_start;

      CURSOR cur_mail (psub_company_code IN VARCHAR2, pterm_end_date IN DATE) IS
        SELECT TRIM(mail) mail
          FROM koc_cp_hlth_group_people s
         WHERE group_code = psub_company_code
           AND TYPE = 'TAZM�NAT'
           AND pterm_end_date BETWEEN validity_start_date AND NVL(validity_end_date,pterm_end_date)
           --AND NVL (validity_end_date, SYSDATE) >= SYSDATE
           AND TRIM(mail) IS NOT NULL;

      CURSOR cur_sub_comp IS
        SELECT DISTINCT re.sub_company_code
          FROM koc_ocp_partitions_ext re
         WHERE re.contract_id IN (SELECT contract_id
                                   FROM ocp_policy_bases
                                  WHERE policy_ref =p_pol_ref_start)
           AND re.version_no = 1;

      CURSOR cur_group (pgroup_code IN VARCHAR2)IS
        SELECT NVL (M.description, '0')
          FROM koc_cp_group_master M
         WHERE M.group_code = pgroup_code
           AND M.validity_start_date <= TRUNC(SYSDATE)
           AND ( M.validity_end_date >=TRUNC(SYSDATE)
               OR M.validity_end_date IS NULL )
           AND ROWNUM < 2;

           v_sgk_srv INT; -- task 191293

   BEGIN
      v_mail_address := p_email;
      vstring := NULL;
      vwhere := NULL;

      -- engine 24072017 performans problem icin duzenlendi
      begin
          select title
            into v_company_title
            from alz_tpa_companies comp
           where comp.company_code = p_company_code
             and trunc(sysdate) between trunc(validity_start_date)
                                    and trunc(nvl(validity_end_date, to_date('31/12/9999', 'DD/MM/YYYY')));
      exception
        when no_data_found then
            p_rt := 16; -- �irket koduna ait kay�t bulunamad�
            return;
      end;
      -- engine 24072017 performans problem icin duzenlendi

      /*cozbay task148244 10.10.2012 tum sorgulara koc_ocp_partitions_ext eklendi cunku sub_company_code'dan gidilecek ferdi'de gelmicek */
      --red start

      IF SUBSTR (p_email_type, 1, 1) = '1'
      THEN
         BEGIN
            p_txtlinetype1.DELETE;
            -- engine 29032017 TPA
            v_head_line := 'SIRKET';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'POLI�E NO';
            --v_head_line := 'POLI�E NO';
            -- engine 29032017 TPA
            v_head_line := v_head_line || v_chr_tab || ' ' || 'POLI�E ADI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'SIRA NO';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'SIGORTALI ISMI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'HASAR DOSYA NO';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'FATURA TUTARI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'RED SEBEBI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'A�IKLAMA';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'BELGE GIRIS TARIHI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'ISLEM TARIHI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'KARAR KODU ';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'FATURA TARIHI ';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'FATURA NO ';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'KURUM ADI ';
            p_txtlinetype1 (p_txtlinetype1.COUNT + 1) := v_head_line;
            v_row_line := '';

            vstring :=
                  ' select /*+ INDEX (ext KOC_OCP_POL_CONTRACTS_EXT_PK) */ c.product_id, a.add_order_no,a.claim_id, '
               || ' a.refuse_explanation ,a.main_code,a.item_code,a.sub_item_code,a.entry_date,a.refuse_amount,''Red Bildirimi'' status_exp,''KST-'' ||b.ext_reference mektup_no, '
               || ' substr(c.policy_ref,1,4)||'' ''||substr(c.policy_ref,5,4)||'' ''||substr(c.policy_ref,9,4)||'' ''||substr(c.policy_ref,13,4) policy_ref, '
               || ' b.part_id ,d.oar_no,b.ext_reference,b.group_code, '
               || ' b.invoice_total,b.comm_date,b.status_code,pol_b.agent_role,pol_ext.sub_agent, '
               || ' b.invoice_date, b.invoice_no, b.institute_code, b.date_of_loss, p.sub_company_code '
               --|| ' from koc_clm_hlth_reject_loss a,koc_clm_hlth_detail b,clm_pol_bases c ,clm_pol_oar d,  koc_v_policy_agent e , koc_ocp_partitions_ext p ' -- engine 30072017 TPA commented
               || ' from koc_clm_hlth_reject_loss a,koc_clm_hlth_detail b,clm_pol_bases c ,clm_pol_oar d, koc_ocp_partitions_ext p ' -- engine 30072017 TPA added
               || ' ,koc_ocp_pol_contracts_ext ext, koc_ocp_pol_versions_ext pol_ext, ocp_policy_bases pol_b, ocp_policy_versions pol_v' -- engine 30072017 TPA added
               || ' where a.claim_id= b.claim_id '
               || ' and a.sf_no = b.sf_no  and a.add_order_no = b.add_order_no and b.claim_id= c.claim_id'
               --|| ' and b.claim_id = d.claim_id  and c.contract_id = e.contract_id and b.provision_date is null ' -- engine 30072017 TPA commented
               || ' and b.claim_id = d.claim_id  and c.contract_id = pol_ext.contract_id and b.provision_date is null '-- engine 30072017 TPA added
               || ' and c.product_id = '
               || p_grup_ferdi
               || ' and ext.contract_id = c.contract_id '
               || ' and ext.company_code = ''' || p_company_code || ''''
               || ' and  b.status_code=''R'' '
               || ' and d.contract_id = p.contract_id '
               || ' and d.oar_no = p.partition_no '
               || ' and d.version_no = p.version_no '
               -- engine 30072017 TPA added
               || ' and pol_b.contract_id = pol_ext.contract_id and pol_v.contract_id = pol_ext.contract_id and pol_v.version_no = pol_ext.version_no and pol_v.product_id = c.product_id '
               || ' and ((nvl (pol_ext.endorsement_no, 0) = 54 and pol_ext.version_no = pol_b.version_no) or (nvl (pol_ext.endorsement_no, 0) <> 54 and pol_b.top_indicator = ''Y'')) '
               || ' and pol_ext.reversing_version is null and ( (exists (select 1 from   koc_ocp_pol_versions_ext aa where aa.contract_id = pol_ext.contract_id '
               || ' and nvl (aa.endorsement_no, 0) = 54 and aa.reversing_version is null) and pol_ext.version_no = (select max (version_no) from koc_ocp_pol_versions_ext aa '
               || ' where aa.contract_id = pol_ext.contract_id and nvl (aa.endorsement_no, 0) = 54 and aa.reversing_version is null)) or (not exists '
               || ' (select 1 from koc_ocp_pol_versions_ext aa where aa.contract_id = pol_ext.contract_id and nvl (aa.endorsement_no, 0) = 54 and aa.reversing_version is null) '
               || ' and pol_ext.top_indicator = ''Y''))';
               -- engine 30072017 TPA added
               --|| ' and p.action_code <> ''D'' '
               --|| ' and p.top_indicator = ''Y'' ';
            vwhere := ' ';

            IF p_tarih_start IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || ' and a.entry_date >= '
                  || CHR (39)
                  || p_tarih_start
                  || CHR (39);
            END IF;

            IF p_tarih_end IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || ' and a.entry_date <= '
                  || CHR (39)
                  || p_tarih_end
                  || CHR (39);
            END IF;

            IF p_group_code IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || ' and b.group_code = '
                  || CHR (39)
                  || p_group_code
                  || CHR (39);
            END IF;

            IF p_sub_company_code IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || ' and p.sub_company_code = '
                  || CHR (39)
                  || p_sub_company_code
                  || CHR (39);
            END IF;

            --cozbay task148244 artik police no kullanilacak
            IF p_grup_ferdi = 64 THEN
              vwhere := vwhere || ' and c.policy_ref = ' || p_pol_ref_start;
            ELSE
              IF p_pol_ref_start IS NOT NULL  THEN
                 vwhere := vwhere || ' and c.policy_ref >= ' || p_pol_ref_start;
              END IF;

              IF p_pol_ref_end IS NOT NULL  THEN
                 vwhere := vwhere || ' and c.policy_ref <= ' || p_pol_ref_end;
              END IF;
            END IF;

            /*
            IF p_contract_start_id IS NOT NULL
            THEN
               vwhere :=
                    vwhere || ' and c.contract_id >= ' || p_contract_start_id;
            END IF;

            IF p_contract_end_id IS NOT NULL
            THEN
               vwhere :=
                       vwhere || ' and c.contract_id <= ' || p_contract_end_id;
            END IF;
            */

            IF p_agent_role IS NOT NULL
            THEN
               --vwhere := vwhere || ' and e.agent_role = ' || p_agent_role;-- engine 30072017 TPA commented
               vwhere := vwhere || ' and pol_b.agent_role = ' || p_agent_role;-- engine 30072017 TPA added
            END IF;

            IF p_sub_agent IS NOT NULL
            THEN
               --vwhere := vwhere || ' and e.sub_agent = ' || p_sub_agent;-- engine 30072017 TPA commented
               vwhere := vwhere || ' and pol_ext.sub_agent = ' || p_sub_agent;-- engine 30072017 TPA added
            END IF;

            vstring := vstring || vwhere;

            OPEN vredcur FOR vstring;

            FETCH vredcur
            BULK COLLECT INTO red_rec;

            CLOSE vredcur;
            --dbms_output.put_line('red_query='||vstring);
            red_kontrol := 0;

            -- engine 25072017 kay�t olmazsa loop'a girerken exception al�yordu.
            -- Exception handle edildi�i i�in form ekran�nda anla��lmaz hata mesaj� verebilir. Bu y�zden if eklendi.
            IF (red_rec.COUNT > 0) THEN
                FOR i IN red_rec.FIRST .. red_rec.LAST
                LOOP
                   red_kontrol := red_kontrol + 1;

                   IF p_grup_ferdi = 64
                   THEN
                      vrefuse_explanation := red_rec (i).refuse_explanation;
                   ELSIF p_grup_ferdi = 63
                   THEN
                      vrefuse_explanation := '';
                   END IF;

                   BEGIN
                      vred_neden :=
                         UPPER
                            (koc_clm_hlth_utils.getrejectlossdesc
                                                        (red_rec (i).main_code,
                                                         red_rec (i).item_code,
                                                         red_rec (i).sub_item_code,
                                                         red_rec (i).entry_date
                                                        )
                            );
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vred_neden := ' ';
                      WHEN OTHERS
                      THEN
                         vred_neden := ' ';
                   END;

                   BEGIN
                      vpartner_name :=
                         koc_clm_hlth_utils.getpartnernamebypartid
                                                              (red_rec (i).part_id
                                                              );
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vpartner_name := ' ';
                      WHEN OTHERS
                      THEN
                         vpartner_name := ' ';
                   END;

                   BEGIN
                      IF p_grup_ferdi = 64 AND red_rec (i).sub_company_code IS NOT NULL THEN
                        vgroup_desc :=  koc_clm_hlth_utils.getgroupdesc (red_rec (i).sub_company_code);
                      ELSE
                        vgroup_desc :=  koc_clm_hlth_utils.getgroupdesc (red_rec (i).group_code);
                      END IF;
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vgroup_desc := ' ';
                      WHEN OTHERS
                      THEN
                         vgroup_desc := ' ';
                   END;

                   -- engine 29032017 TPA
                   v_row_line := v_company_title;
                   v_row_line := v_row_line || v_chr_tab || ' ' || red_rec (i).policy_ref;
                   --v_row_line := red_rec (i).policy_ref;
                   -- engine 29032017 TPA
                   v_row_line := v_row_line || v_chr_tab || ' ' || vgroup_desc;
                   v_row_line := v_row_line || v_chr_tab || ' ' || red_rec (i).oar_no;
                   v_row_line := v_row_line || v_chr_tab || ' ' || vpartner_name;
                   v_row_line := v_row_line || v_chr_tab || ' ' || red_rec (i).ext_reference;
                   v_row_line := v_row_line || v_chr_tab || ' ' || LPAD (TO_CHAR (red_rec (i).invoice_total, '999G999G999G999D99' ), 20 );
                   v_row_line := v_row_line || v_chr_tab || ' ' || vred_neden;
                   v_row_line := v_row_line || v_chr_tab || ' ' || vrefuse_explanation;
                   v_row_line := v_row_line || v_chr_tab || ' ' || red_rec (i).comm_date;
                   v_row_line := v_row_line || v_chr_tab || ' ' || red_rec (i).entry_date;
                   v_row_line := v_row_line || v_chr_tab || ' ' || red_rec (i).status_exp;
                   v_row_line := v_row_line || v_chr_tab || ' ' || red_rec (i).invoice_date;
                   v_row_line := v_row_line || v_chr_tab || ' ' || red_rec (i).invoice_no;
                   v_row_line := v_row_line || v_chr_tab || ' ' || koc_clm_hlth_utils.GETINSTITUTNAMEBYCODE(red_rec (i).institute_code, red_rec (i).date_of_loss);
                   p_txtlinetype1 (p_txtlinetype1.COUNT + 1) := v_row_line;
                END LOOP;
            END IF; -- engine 25072017
         EXCEPTION
            WHEN OTHERS
            THEN
               verr := 1;
         END;
      END IF;

      --red end

      --eksik start
      IF SUBSTR (p_email_type, 2, 1) = '1'
      THEN
         vstring := NULL;
         vwhere := NULL;

         BEGIN
            p_txtlinetype2.DELETE;
            -- engine 29032017 TPA
            v_head_line := 'SIRKET';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'POLI�E NO';
            --v_head_line := 'POLI�E NO';
            -- engine 29032017 TPA
            v_head_line := v_head_line || v_chr_tab || ' ' || 'POLI�E ADI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'SIRA NO';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'SIGORTALI ISMI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'HASAR DOSYA NO';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'EKSIK EVRAK/ISTENEN BELGELER';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'A�IKLAMA';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'FATURA TUTARI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'BELGE GIRIS TARIHI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'ISLEM TARIHI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'KARAR KODU ';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'FATURA TARIHI ';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'FATURA NO ';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'KURUM ADI ';
            --v_head_line := v_head_line || v_chr_tab || ' ' || 'EKSIK EVRAGI ILETECEGI MAIL ';  bu ve alttaki kapat�ld�  SBH-92
            --v_head_line := v_head_line || v_chr_tab || ' ' || 'KULLANICI'; -- engine 30032017 TPA
            p_txtlinetype2 (p_txtlinetype2.COUNT + 1) := v_head_line;
            v_row_line := '';
            vstring :=
                  ' SELECT  /*+ INDEX (ext KOC_OCP_POL_CONTRACTS_EXT_PK) */ c.product_id, a.add_order_no, a.claim_id,a.absent_doc_code evrak_no, c.contract_id,  '
               || ' a.entry_date, ''Eksik Evrak Bildirimi'' status_exp, ''KST-'' || b.ext_reference mektup_no,  '
               || ' substr(c.policy_ref,1,4)||'' ''||substr(c.policy_ref,5,4)||'' ''||substr(c.policy_ref,9,4)||'' ''||substr(c.policy_ref,13,4) policy_ref, '
               || ' d.oar_no,b.part_id,b.group_code, '
               || ' b.invoice_total, b.comm_date, b.ext_reference, pol_b.agent_role, '
               || ' pol_ext.sub_agent,a.EXPLANATION, b.invoice_date, b.invoice_no, b.institute_code, b.date_of_loss, a.userid,  p.sub_company_code '
               --|| ' FROM koc_clm_hlth_incomp_papers a,koc_clm_hlth_detail b,clm_pol_bases c,clm_pol_oar d,koc_v_policy_agent e , koc_ocp_partitions_ext p '-- engine 30072017 TPA commented
               || ' FROM koc_clm_hlth_incomp_papers a,koc_clm_hlth_detail b,clm_pol_bases c,clm_pol_oar d, koc_ocp_partitions_ext p ' -- engine 30072017 TPA added
               || ' ,koc_ocp_pol_contracts_ext ext, koc_ocp_pol_versions_ext pol_ext, ocp_policy_bases pol_b, ocp_policy_versions pol_v ' -- engine 30072017 TPA added
               || ' WHERE a.claim_id = b.claim_id AND a.sf_no = b.sf_no AND a.add_order_no = b.add_order_no AND a.status_code = ''A'' '
               --|| ' AND b.claim_id = c.claim_id AND b.claim_id = d.claim_id AND c.contract_id = e.contract_id AND b.provision_date IS NULL '-- engine 30072017 TPA commented
               || ' AND b.claim_id = c.claim_id AND b.claim_id = d.claim_id AND c.contract_id = pol_ext.contract_id AND b.provision_date IS NULL '-- engine 30072017 TPA added
               --|| ' AND b.STATUS_CODE<>''R'' AND c.product_id = '
               || ' AND b.STATUS_CODE not in(''R'',''C'',''ODE'',''TAH'' ) AND c.product_id = '
               || p_grup_ferdi
               || ' and ext.contract_id = c.contract_id '
               || ' and ext.company_code = ''' || p_company_code || ''''
               || ' and d.contract_id = p.contract_id '
               || ' and d.oar_no = p.partition_no '
               || ' and d.version_no = p.version_no '
               -- engine 30072017 TPA added
               || ' and pol_b.contract_id = pol_ext.contract_id and pol_v.contract_id = pol_ext.contract_id and pol_v.version_no = pol_ext.version_no and pol_v.product_id = c.product_id '
               || ' and ((nvl (pol_ext.endorsement_no, 0) = 54 and pol_ext.version_no = pol_b.version_no) or (nvl (pol_ext.endorsement_no, 0) <> 54 and pol_b.top_indicator = ''Y'')) '
               || ' and pol_ext.reversing_version is null and ( (exists (select 1 from   koc_ocp_pol_versions_ext aa where aa.contract_id = pol_ext.contract_id '
               || ' and nvl (aa.endorsement_no, 0) = 54 and aa.reversing_version is null) and pol_ext.version_no = (select max (version_no) from koc_ocp_pol_versions_ext aa '
               || ' where aa.contract_id = pol_ext.contract_id and nvl (aa.endorsement_no, 0) = 54 and aa.reversing_version is null)) or (not exists '
               || ' (select 1 from koc_ocp_pol_versions_ext aa where aa.contract_id = pol_ext.contract_id and nvl (aa.endorsement_no, 0) = 54 and aa.reversing_version is null) '
               || ' and pol_ext.top_indicator = ''Y''))';
               -- engine 30072017 TPA added
               --|| ' and p.action_code <> ''D'' '
               --|| ' and p.top_indicator = ''Y'' ';
            vwhere := ' ';

            IF p_tarih_start IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || ' and a.entry_date >= '
                  || CHR (39)
                  || p_tarih_start
                  || CHR (39);
            END IF;

            IF p_tarih_end IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || 'and a.entry_date <= '
                  || CHR (39)
                  || p_tarih_end
                  || CHR (39);
            END IF;

            IF p_group_code IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || ' and b.group_code = '
                  || CHR (39)
                  || p_group_code
                  || CHR (39);
            END IF;

            IF p_sub_company_code IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || ' and p.sub_company_code = '
                  || CHR (39)
                  || p_sub_company_code
                  || CHR (39);
            END IF;

            --cozbay task148244 artik police no kullanilacak
            IF p_grup_ferdi = 64 THEN
              vwhere := vwhere || ' and c.policy_ref = ' || p_pol_ref_start;
            ELSE
              IF p_pol_ref_start IS NOT NULL  THEN
                 vwhere := vwhere || ' and c.policy_ref >= ' || p_pol_ref_start;
              END IF;

              IF p_pol_ref_end IS NOT NULL  THEN
                 vwhere := vwhere || ' and c.policy_ref <= ' || p_pol_ref_end;
              END IF;
            END IF;

            /*
            IF p_contract_start_id IS NOT NULL
            THEN
               vwhere :=
                     vwhere || ' and c.contract_id >= ' || p_contract_start_id;
            END IF;

            IF p_contract_end_id IS NOT NULL
            THEN
               vwhere :=
                       vwhere || ' and c.contract_id <= ' || p_contract_end_id;
            END IF;*/

            IF p_agent_role IS NOT NULL
            THEN
               --vwhere := vwhere || ' and e.agent_role = ' || p_agent_role;-- engine 30072017 TPA commented
               vwhere := vwhere || ' and pol_b.agent_role = ' || p_agent_role;-- engine 30072017 TPA added
            END IF;

            IF p_sub_agent IS NOT NULL
            THEN
               --vwhere := vwhere || ' and e.sub_agent = ' || p_sub_agent;-- engine 30072017 TPA commented
               vwhere := vwhere || ' and pol_ext.sub_agent = ' || p_sub_agent;-- engine 30072017 TPA added
            END IF;

            vstring := vstring || vwhere;

            OPEN veksikcur FOR vstring;

            FETCH veksikcur
            BULK COLLECT INTO eksik_rec;

            CLOSE veksikcur;
            --dbms_output.put_line('eksik_query='||vstring);
            eksik_kontrol := 0;
            vpartner_name := NULL;
            vgroup_desc := NULL;

            -- engine 25072017 kay�t olmazsa loop'a girerken exception al�yordu.
            -- Exception handle edildi�i i�in form ekran�nda anla��lmaz hata mesaj� verebilir. Bu y�zden if eklendi.
            IF (eksik_rec.COUNT > 0) THEN
                FOR i IN eksik_rec.FIRST .. eksik_rec.LAST
                LOOP
                   eksik_kontrol := eksik_kontrol + 1;

                   BEGIN
                      veksik_neden :=
                         koc_clm_hlth_utils.getlookupparamdesc
                                                   ('INDABDOC',
                                                    eksik_rec (i).absent_doc_code,
                                                    eksik_rec (i).entry_date
                                                   );
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         veksik_neden := ' ';
                      WHEN OTHERS
                      THEN
                         veksik_neden := ' ';
                   END;

                   BEGIN
                      vpartner_name :=
                         koc_clm_hlth_utils.getpartnernamebypartid
                                                            (eksik_rec (i).part_id
                                                            );
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vpartner_name := ' ';
                      WHEN OTHERS
                      THEN
                         vpartner_name := ' ';
                   END;

                   BEGIN
                     IF p_grup_ferdi = 64 AND eksik_rec (i).sub_company_code IS NOT NULL THEN
                        vgroup_desc := koc_clm_hlth_utils.getgroupdesc (eksik_rec (i).sub_company_code);
                      ELSE
                        vgroup_desc := koc_clm_hlth_utils.getgroupdesc (eksik_rec (i).group_code);
                      END IF;

                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vgroup_desc := ' ';
                      WHEN OTHERS
                      THEN
                         vgroup_desc := ' ';
                   END;

                   -- engine 29032017 TPA
                   v_row_line := v_company_title;
                   v_row_line := v_row_line || v_chr_tab || ' ' || eksik_rec (i).policy_ref;
                   --v_row_line := eksik_rec (i).policy_ref;
                   -- engine 29032017 TPA
                   v_row_line := v_row_line || v_chr_tab || ' ' || vgroup_desc;
                   v_row_line := v_row_line || v_chr_tab || ' ' || eksik_rec (i).oar_no;
                   v_row_line := v_row_line || v_chr_tab || ' ' || vpartner_name;
                   v_row_line := v_row_line || v_chr_tab || ' ' || eksik_rec (i).ext_reference;
                   v_row_line := v_row_line || v_chr_tab || ' ' || veksik_neden;
                   v_row_line := v_row_line || v_chr_tab || ' ' || eksik_rec (i).explanation;
                   v_row_line := v_row_line || v_chr_tab || ' ' || LPAD (TO_CHAR (eksik_rec (i).invoice_total, '999G999G999G999D99' ), 20 );
                   v_row_line := v_row_line || v_chr_tab || ' ' || eksik_rec (i).comm_date;
                   v_row_line := v_row_line || v_chr_tab || ' ' || eksik_rec (i).entry_date;
                   v_row_line := v_row_line || v_chr_tab || ' ' || eksik_rec (i).status_exp;
                   v_row_line := v_row_line || v_chr_tab || ' ' || eksik_rec (i).invoice_date;
                   v_row_line := v_row_line || v_chr_tab || ' ' || eksik_rec (i).invoice_no;
                   v_row_line := v_row_line || v_chr_tab || ' ' || koc_clm_hlth_utils.GETINSTITUTNAMEBYCODE(eksik_rec (i).institute_code, eksik_rec (i).date_of_loss);
                   --v_row_line := v_row_line || v_chr_tab || ' ' || koc_clm_hlth_report_utils.PROV_MAIL(eksik_rec (i).user_id);  bu ve alttaki kapat�ld� SBH-92 omert
                   --v_row_line := v_row_line || v_chr_tab || ' ' || eksik_rec (i).user_id; -- engine 30032017 TPA
                   p_txtlinetype2 (p_txtlinetype2.COUNT + 1) := v_row_line;
                END LOOP;
            END IF; -- engine 25072017
         EXCEPTION
            WHEN OTHERS
            THEN
               verr := 2;
         END;
      END IF;


      ---eksik end
      IF SUBSTR (p_email_type, 3, 1) = '1'
      THEN
         BEGIN
            p_txtlinetype3.DELETE;
            -- engine 29032017 TPA
            v_head_line := 'SIRKET';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'DOSYA NO';
            --v_head_line := 'DOSYA NO';
            -- engine 29032017 TPA
            v_head_line := v_head_line || v_chr_tab || ' ' || 'POLI�E NO';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'PARTAJ';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'EKIP KODU';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'SIGORTALI ADI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'ILK ONAY TARIHI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'IPTAL ONAY TARIHI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'IPTAL NEDEN KODU A�IKLAMASI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'IKINCI ONAY TARIHI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'FATURA TUTARI';
            v_head_line := v_head_line || v_chr_tab || ' ' || '�DEME TUTARI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'SAGLIK SERVIS ODEME';   -- task 191293
            p_txtlinetype3 (p_txtlinetype3.COUNT + 1) := v_head_line;
            v_row_line := '';
            vstring := NULL;
            vwhere := NULL;
            vstring :=
                  ' SELECT /*+ INDEX (ext KOC_OCP_POL_CONTRACTS_EXT_PK) */ B.ext_reference, substr(c.policy_ref,1,4)||'' ''||substr(c.policy_ref,5,4)||'' ''||substr(c.policy_ref,9,4)||'' ''||substr(c.policy_ref,13,4) policy_ref, '
               || ' a.approve_date,a.payment_approve_cancel_date,a.cancel_reason_code, b.invoice_total , '
               || ' pol_b.agent_role,pol_ext.sub_agent    ,b.part_id  ,b.claim_id,b.sf_no,b.add_order_no '
               --|| ' FROM koc_clm_ind_app_canc_reas a,koc_clm_hlth_detail b,clm_pol_bases c, clm_pol_oar d, koc_v_policy_agent r  , koc_ocp_partitions_ext p '-- engine 30072017 TPA commented
               || ' FROM koc_clm_ind_app_canc_reas a,koc_clm_hlth_detail b,clm_pol_bases c, clm_pol_oar d, koc_ocp_partitions_ext p '-- engine 30072017 TPA added
               || ' ,koc_ocp_pol_contracts_ext ext, koc_ocp_pol_versions_ext pol_ext, ocp_policy_bases pol_b, ocp_policy_versions pol_v '-- engine 30072017 TPA added
               || ' WHERE a.claim_id = b.claim_id AND a.sf_no = b.sf_no '
               || ' AND a.add_order_no = b.add_order_no AND a.claim_id = c.claim_id and  b.claim_id = d.claim_id AND b.provision_date IS NULL '
               --|| ' AND C.contract_id = R.contract_id  And c.product_id= '-- engine 30072017 TPA commented
               || ' AND C.contract_id = pol_ext.contract_id  And c.product_id= '-- engine 30072017 TPA added
               || p_grup_ferdi
               || ' and ext.contract_id = c.contract_id '
               || ' and ext.company_code = ''' || p_company_code || ''''
               || ' and d.contract_id = p.contract_id '
               || ' and d.oar_no = p.partition_no '
               || ' and d.version_no = p.version_no '
               -- engine 30072017 TPA added
               || ' and pol_b.contract_id = pol_ext.contract_id and pol_v.contract_id = pol_ext.contract_id and pol_v.version_no = pol_ext.version_no and pol_v.product_id = c.product_id '
               || ' and ((nvl (pol_ext.endorsement_no, 0) = 54 and pol_ext.version_no = pol_b.version_no) or (nvl (pol_ext.endorsement_no, 0) <> 54 and pol_b.top_indicator = ''Y'')) '
               || ' and pol_ext.reversing_version is null and ( (exists (select 1 from   koc_ocp_pol_versions_ext aa where aa.contract_id = pol_ext.contract_id '
               || ' and nvl (aa.endorsement_no, 0) = 54 and aa.reversing_version is null) and pol_ext.version_no = (select max (version_no) from koc_ocp_pol_versions_ext aa '
               || ' where aa.contract_id = pol_ext.contract_id and nvl (aa.endorsement_no, 0) = 54 and aa.reversing_version is null)) or (not exists '
               || ' (select 1 from koc_ocp_pol_versions_ext aa where aa.contract_id = pol_ext.contract_id and nvl (aa.endorsement_no, 0) = 54 and aa.reversing_version is null) '
               || ' and pol_ext.top_indicator = ''Y''))';
               -- engine 30072017 TPA added
               --|| ' and p.action_code <> ''D'' '
               --|| ' and p.top_indicator = ''Y'' ' ;
            vwhere := ' ';

            IF p_tarih_start IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || ' and payment_approve_cancel_date >= '
                  || CHR (39)
                  || p_tarih_start
                  || CHR (39);
            END IF;

            IF p_tarih_end IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || ' and payment_approve_cancel_date <= '
                  || CHR (39)
                  || p_tarih_end
                  || CHR (39);
            END IF;

            IF p_group_code IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || ' and b.group_code =  '
                  || CHR (39)
                  || p_group_code
                  || CHR (39);
            END IF;

            IF p_sub_company_code IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || ' and p.sub_company_code = '
                  || CHR (39)
                  || p_sub_company_code
                  || CHR (39);
            END IF;

            --cozbay task148244 artik police no kullanilacak
            IF p_grup_ferdi = 64 THEN
              vwhere := vwhere || ' and c.policy_ref = ' || p_pol_ref_start;
            ELSE
              IF p_pol_ref_start IS NOT NULL  THEN
                 vwhere := vwhere || ' and c.policy_ref >= ' || p_pol_ref_start;
              END IF;

              IF p_pol_ref_end IS NOT NULL  THEN
                 vwhere := vwhere || ' and c.policy_ref <= ' || p_pol_ref_end;
              END IF;
            END IF;

            /*
            IF p_contract_start_id IS NOT NULL
            THEN
               vwhere :=
                    vwhere || ' and c.contract_id >= ' || p_contract_start_id;
            END IF;

            IF p_contract_end_id IS NOT NULL
            THEN
               vwhere :=
                      vwhere || ' and c.contract_id <= ' || p_contract_end_id;
            END IF;*/

            IF p_agent_role IS NOT NULL
            THEN
               --vwhere := vwhere || ' and r.agent_role = ' || p_agent_role;-- engine 30072017 TPA commented
               vwhere := vwhere || ' and pol_b.agent_role = ' || p_agent_role;-- engine 30072017 TPA added
            END IF;

            IF p_sub_agent IS NOT NULL
            THEN
               --vwhere := vwhere || ' and r.sub_agent = ' || p_sub_agent;-- engine 30072017 TPA commented
               vwhere := vwhere || ' and pol_ext.sub_agent = ' || p_sub_agent;-- engine 30072017 TPA added
            END IF;

            vstring :=
                  vstring
               || ' '
               || vwhere
               || ' and exists (select 1 from clm_trans aa, koc_clm_trans_ext bb '
               || ' where aa.claim_id = bb.claim_id and aa.sf_no = bb.sf_no and aa.trans_no = bb.trans_no and bb.claim_id = b.claim_id '
               || ' and bb.sf_no = b.sf_no and bb.add_order_no =b.add_order_no and aa.sf_total_type = ''11'' and aa.trans_no = '
               || ' (select max (y.trans_no) from clm_trans y, koc_clm_trans_ext x where x.claim_id = y.claim_id '
               || ' and x.sf_no = y.sf_no and x.trans_no = y.trans_no and x.claim_id = bb.claim_id and x.sf_no = bb.sf_no '
               || ' and y.sf_total_type in(''11'',''10'',''12'') and x.add_order_no = bb.add_order_no and x.hlth_cover_code = bb.hlth_cover_code and bb.payment_approved_date IS NULL)) ';

            dbms_output.put_line('kesin_query='||vstring);
            OPEN vkesincur FOR vstring;

            FETCH vkesincur
            BULK COLLECT INTO kesin_rec;

            CLOSE vkesincur;
            
            kesin_kontrol := 0;

            -- engine 25072017 kay�t olmazsa loop'a girerken exception al�yordu.
            -- Exception handle edildi�i i�in form ekran�nda anla��lmaz hata mesaj� verebilir. Bu y�zden if eklendi.
            IF (kesin_rec.COUNT > 0) THEN
                FOR i IN kesin_rec.FIRST .. kesin_rec.LAST
                LOOP
                   kesin_kontrol := kesin_kontrol + 1;
                   vacente := NULL;
                   vekipkodu := NULL;
                   vsigortaliadi := NULL;
                   vneden := NULL;
                   vikincionaytarih := NULL;

                   BEGIN
                      SELECT reference_code
                        INTO vacente
                        FROM dmt_agents dm
                       WHERE dm.int_id = kesin_rec (i).agent_role;
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vacente := NULL;
                   END;

                   BEGIN
                      SELECT reference_code
                        INTO vekipkodu
                        FROM dmt_agents dm
                       WHERE dm.int_id = kesin_rec (i).sub_agent;
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vekipkodu := NULL;
                   END;

                   BEGIN
                      SELECT first_name || ' ' || surname
                        INTO vsigortaliadi
                        FROM cp_partners zz
                       WHERE zz.part_id = kesin_rec (i).part_id;
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vsigortaliadi := NULL;
                   END;

                   BEGIN
                      SELECT long_name
                        INTO vneden
                        FROM koc_cp_health_look_up lk, cur_translations cur
                       WHERE lk.look_up_code = 'CANREASCOD'
                         AND lk.desc_int_id = cur.desc_int_id
                         AND cur.sula_ora_nls_code = 'TR'
                         AND lk.parameter = kesin_rec (i).cancel_reason_code;
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vneden := NULL;
                   END;

                   BEGIN
                      SELECT MAX (E.payment_approved_date)
                        INTO vikincionaytarih
                        FROM koc_clm_trans_ext E
                       WHERE E.claim_id = kesin_rec (i).claim_id
                         AND E.sf_no = kesin_rec (i).sf_no
                         AND E.add_order_no = kesin_rec (i).add_order_no
                         AND E.realization_ticket_date IS NOT NULL
                         AND E.payment_approved_date IS NOT NULL;
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vikincionaytarih := NULL;
                   END;

                   BEGIN
                      vodeme_tutar :=
                         koc_clm_hlth_utils.getsumtransbyclaim
                                                       (kesin_rec (i).claim_id,
                                                        kesin_rec (i).sf_no,
                                                        kesin_rec (i).add_order_no
                                                       );
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vodeme_tutar := 0;
                      WHEN OTHERS
                      THEN
                         vodeme_tutar := 0;
                   END;

                    -- task 191293
                   SELECT HLTH_SRV_PAY INTO v_sgk_srv FROM koc_clm_hlth_detail WHERE claim_id=kesin_rec (i).claim_id AND sf_no=kesin_rec (i).sf_no AND add_order_no=kesin_rec (i).add_order_no;

                   -- engine 29032017 TPA
                   v_row_line := v_company_title;
                   v_row_line := v_row_line || v_chr_tab || ' ' || kesin_rec (i).ext_reference;
                   --v_row_line := kesin_rec (i).ext_reference;
                   -- engine 29032017 TPA
                   v_row_line := v_row_line || v_chr_tab || ' ' || kesin_rec (i).policy_ref;
                   v_row_line := v_row_line || v_chr_tab || ' ' || vacente;
                   v_row_line := v_row_line || v_chr_tab || ' ' || vekipkodu;
                   v_row_line := v_row_line || v_chr_tab || ' ' || vsigortaliadi;
                   v_row_line :=
                      v_row_line || v_chr_tab || ' ' || kesin_rec (i).approve_date;
                   v_row_line :=
                         v_row_line
                      || v_chr_tab
                      || ' '
                      || kesin_rec (i).payment_approve_cancel_date;
                   v_row_line := v_row_line || v_chr_tab || ' ' || vneden;
                   v_row_line :=
                                v_row_line || v_chr_tab || ' ' || vikincionaytarih;
                   v_row_line :=
                         v_row_line
                      || v_chr_tab
                      || ' '
                      || LPAD (TO_CHAR (kesin_rec (i).invoice_total,
                                        '999G999G999G999D99'
                                       ),
                               20
                              );
                   v_row_line :=
                         v_row_line
                      || v_chr_tab
                      || ' '
                      || LPAD (TO_CHAR (vodeme_tutar, '999G999G999G999D99'), 20);

                      IF v_sgk_srv=1 THEN
                        v_row_line := v_row_line || v_chr_tab || ' SaglikServisOde' ; -- task 191293
                      ELSE
                        v_row_line := v_row_line || v_chr_tab || ' - ' ;
                      END IF;

                   p_txtlinetype3 (p_txtlinetype3.COUNT + 1) := v_row_line;
                END LOOP;
            END IF; -- engine 25072017
         EXCEPTION
            WHEN OTHERS
            THEN
               verr := 3;
         END;
      END IF;

      ---kesin end

      ---tahakkuk start
      IF SUBSTR (p_email_type, 4, 1) = '1'
      THEN
         vstring := ' ';

         BEGIN
            p_txtlinetype4.DELETE;
            -- engine 29032017 TPA
            v_head_line := 'SIRKET';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'POLI�E NO';
            --v_head_line := 'POLI�E NO';
            -- engine 29032017 TPA
            --v_head_line := v_head_line || v_chr_tab || ' ' || 'GRUP KODU';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'GRUP ADI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'AILE KODU';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'SIRA NO';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'ADI SOYADI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'DOSYA NO';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'TEMINAT ADI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'FATURA TUTARI';
            v_head_line := v_head_line || v_chr_tab || ' ' || '�DEME ORANI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'TUTAR';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'TEMINAT DISI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'RED NEDENLERI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'KALAN TEMINAT';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'KALAN MUAF';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'HESAP NO';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'FATURA TARIHI ';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'FATURA NO ';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'KURUM ADI ';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'SAGLIK SERVIS ODEME';   -- task 191293
            v_head_line := v_head_line || v_chr_tab || ' ' || 'KULLANICI'; -- engine 30032017 TPA
            p_txtlinetype4 (p_txtlinetype4.COUNT + 1) := v_head_line;
            v_row_line := '';
            vstring :=
                  ' select /*+ INDEX (ext KOC_OCP_POL_CONTRACTS_EXT_PK) */ e.claim_id,e.sf_no,e.process_date,c.product_id,e.add_order_no ,e.group_code, '
               || ' substr(c.policy_ref,1,4)||'' ''||substr(c.policy_ref,5,4)||'' ''||substr(c.policy_ref,9,4)||'' ''||substr(c.policy_ref,13,4) policy_ref, '
               || ' a.oar_no sig_No,c.version_no,e.part_id,realization_ticket_date,c.contract_id,(1-f.exemption_rate)*100 exemption_rate, '
               || ' b.creditor_bank,b.creditor_subsidiary,b.account_no,b.hlth_cover_code,a.ext_reference,e.claim_inst_type,e.claim_inst_loc,e.country_code, '
               --|| ' f.is_special_cover,f.is_pool_cover,f.location_code ,SUM(DECODE(a.sf_total_type,11,1,12,-1,0)*a.trans_base_amt*NVL(b.currency_exchange_rate,1)*(f.provision_total/a.trans_base_amt)) invoice_amt, '
               || ' f.is_special_cover,f.is_pool_cover,f.location_code ,round(SUM(DECODE(a.sf_total_type,11,1,12,-1,0)*a.trans_base_amt*NVL(b.currency_exchange_rate,1)),2) invoice_amt, '
               || ' sum(decode(a.sf_total_type,11,1,12,-1,0)*a.trans_amt*nvl(b.currency_exchange_rate,1)) sumtrans ,'
               || ' e.invoice_date, e.invoice_no, e.institute_code, e.date_of_loss '
               || ' , f.user_id user_id '
               --|| ' from clm_trans a ,koc_clm_trans_ext b ,clm_pol_bases c,koc_clm_hlth_detail e,koc_clm_hlth_provisions f, clm_pol_oar d, koc_v_policy_agent g , koc_ocp_partitions_ext p ' -- engine 30072017 TPA commented
               || ' from clm_trans a ,koc_clm_trans_ext b ,clm_pol_bases c,koc_clm_hlth_detail e,koc_clm_hlth_provisions f, clm_pol_oar d, koc_ocp_partitions_ext p ' -- engine 30072017 TPA added
               || ' ,koc_ocp_pol_contracts_ext ext,koc_ocp_pol_versions_ext pol_ext, ocp_policy_bases pol_b, ocp_policy_versions pol_v '
               || ' where nvl(e.CPA_STATUS,''XXX'') != ''TAH_BT'' and c.claim_id = a.claim_id  and c.claim_id = b.claim_id  and a.sf_no = b.sf_no and a.trans_no = b.trans_no and '
               --|| '  c.contract_id=g.contract_id and  e.claim_id = d.claim_id and e.provision_date is null '-- engine 30072017 TPA commented
               || '  c.contract_id=pol_ext.contract_id and  e.claim_id = d.claim_id and e.provision_date is null '-- engine 30072017 TPA added
               || ' and b.project_code is null and b.claim_id = e.claim_id and b.sf_no = e.sf_no and b.add_order_no = e.add_order_no and b.claim_id = f.claim_id and '
               || ' b.sf_no = f.sf_no and b.add_order_no = f.add_order_no and b.hlth_cover_code= f.cover_code '
               || ' and ext.contract_id = c.contract_id '
               || ' and ext.company_code = ''' || p_company_code || ''''
               || ' and d.contract_id = p.contract_id '
               || ' and d.oar_no = p.partition_no '
               || ' and d.version_no = p.version_no '
               -- engine 30072017 TPA added
               || ' and pol_b.contract_id = pol_ext.contract_id and pol_v.contract_id = pol_ext.contract_id and pol_v.version_no = pol_ext.version_no and pol_v.product_id = c.product_id '
               || ' and ((nvl (pol_ext.endorsement_no, 0) = 54 and pol_ext.version_no = pol_b.version_no) or (nvl (pol_ext.endorsement_no, 0) <> 54 and pol_b.top_indicator = ''Y'')) '
               || ' and pol_ext.reversing_version is null and ( (exists (select 1 from   koc_ocp_pol_versions_ext aa where aa.contract_id = pol_ext.contract_id '
               || ' and nvl (aa.endorsement_no, 0) = 54 and aa.reversing_version is null) and pol_ext.version_no = (select max (version_no) from koc_ocp_pol_versions_ext aa '
               || ' where aa.contract_id = pol_ext.contract_id and nvl (aa.endorsement_no, 0) = 54 and aa.reversing_version is null)) or (not exists '
               || ' (select 1 from koc_ocp_pol_versions_ext aa where aa.contract_id = pol_ext.contract_id and nvl (aa.endorsement_no, 0) = 54 and aa.reversing_version is null) '
               || ' and pol_ext.top_indicator = ''Y''))';
               -- engine 30072017 TPA added
               --|| ' and p.action_code <> ''D'' '
               --|| ' and p.top_indicator = ''Y'' ' ;
            vwhere_groupby := ' ';
            vwhere := ' ';
            vwhere_tarih := ' ';

            IF p_grup_ferdi IS NOT NULL
            THEN
               vwhere := vwhere || ' And c.product_id = ' || p_grup_ferdi;
            END IF;

            IF p_tarih_start IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || ' And b.realization_ticket_date >= '
                  || CHR (39)
                  || p_tarih_start
                  || CHR (39);
               vwhere_tarih :=
                     vwhere_tarih
                  || ' And b.realization_ticket_date >= '
                  || CHR (39)
                  || p_tarih_start
                  || CHR (39);
            END IF;

            IF p_tarih_end IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || ' And b.realization_ticket_date <= '
                  || CHR (39)
                  || p_tarih_end
                  || CHR (39);
               vwhere_tarih :=
                     vwhere_tarih
                  || ' And b.realization_ticket_date <= '
                  || CHR (39)
                  || p_tarih_end
                  || CHR (39);
            END IF;

            IF p_group_code IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || ' And e.group_code = '
                  || CHR (39)
                  || p_group_code
                  || CHR (39);
            END IF;

            IF p_sub_company_code IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || ' and p.sub_company_code = '
                  || CHR (39)
                  || p_sub_company_code
                  || CHR (39);
            END IF;

            IF p_agent_role IS NOT NULL
            THEN
               --vwhere := vwhere || ' And g.agent_role = ' || p_agent_role; -- engine 30072017 TPA commented
               vwhere := vwhere || ' And pol_b.agent_role = ' || p_agent_role;-- engine 30072017 TPA added
            END IF;

            IF p_sub_agent IS NOT NULL
            THEN
               --vwhere := vwhere || ' And g.sub_agent = ' || p_sub_agent;-- engine 30072017 TPA commented
               vwhere := vwhere || ' And pol_ext.sub_agent = ' || p_sub_agent;-- engine 30072017 TPA added
            END IF;

            --cozbay task148244 artik police no kullanilacak
            IF p_grup_ferdi = 64 THEN
              vwhere := vwhere || ' and c.policy_ref = ' || p_pol_ref_start;
            ELSE
              IF p_pol_ref_start IS NOT NULL  THEN
                 vwhere := vwhere || ' and c.policy_ref >= ' || p_pol_ref_start;
              END IF;

              IF p_pol_ref_end IS NOT NULL  THEN
                 vwhere := vwhere || ' and c.policy_ref <= ' || p_pol_ref_end;
              END IF;
            END IF;

            /*
            IF p_contract_start_id IS NOT NULL
            THEN
               vwhere :=
                    vwhere || ' And c.contract_id >= ' || p_contract_start_id;
            END IF;

            IF p_contract_end_id IS NOT NULL
            THEN
               vwhere :=
                      vwhere || ' And c.contract_id <= ' || p_contract_end_id;
            END IF;*/

            vwhere_groupby :=
                  ' group by  e.claim_id,e.sf_no,e.process_date,c.product_id,e.add_order_no ,e.group_code ,c.policy_ref,a.oar_no, c.version_no,e.part_id, realization_ticket_date, '
               || '  c.contract_id, f.exemption_rate,b.creditor_bank, b.creditor_subsidiary, b.account_no,b.hlth_cover_code, a.ext_reference, e.claim_inst_type, '
               || '  e.claim_inst_loc, e.country_code,f.is_special_cover,f.is_pool_cover,f.location_code, '
               || '  e.invoice_date, e.invoice_no, e.institute_code, e.date_of_loss '
               || ' , f.user_id '
               || '   having SUM(DECODE(a.sf_total_type,11,1,12,-1,0)*a.trans_amt*NVL(b.currency_exchange_rate,1)) > 0 ';
            vstring :=
                  vstring
               || ' '
               || vwhere
               || ' and b.trans_no = (select  max(trans_no) from koc_clm_trans_ext bb where bb.claim_id = b.claim_id '
               || ' and bb.sf_no = b.sf_no and   bb.add_order_no = f.add_order_no and   bb.hlth_cover_code= f.cover_code '
               || vwhere_tarih
               || ') '
               || vwhere_groupby;
            
            dbms_output.put_line('tahakkuk_query='||vstring);
            OPEN vtahakkukcur FOR vstring;

            FETCH vtahakkukcur
            BULK COLLECT INTO tahakkuk_rec;

            CLOSE vtahakkukcur;

            tahakkuk_kontrol := 0;

            -- engine 25072017 kay�t olmazsa loop'a girerken exception al�yordu.
            -- Exception handle edildi�i i�in form ekran�nda anla��lmaz hata mesaj� verebilir. Bu y�zden if eklendi.
            IF (tahakkuk_rec.COUNT > 0) THEN
                FOR i IN tahakkuk_rec.FIRST .. tahakkuk_rec.LAST
                LOOP
                   tahakkuk_kontrol := tahakkuk_kontrol + 1;
                   vgrupadi := NULL;
                   vgrupkodu := NULL;
                   vsigortaliadi := NULL;
                   vmain_code := NULL;
                   vitem_code := NULL;
                   vsub_item_code := NULL;
                   vrefuse_amount := NULL;
                   vtah_red_neden := NULL;
                   vteminat_disi := NULL;

                   BEGIN

                     FOR rec IN (SELECT DISTINCT main_code, item_code, sub_item_code,
                                       refuse_explanation, refuse_amount
                                  FROM koc_clm_hlth_reject_loss
                                 WHERE claim_id = tahakkuk_rec (i).claim_id
                                   AND sf_no = tahakkuk_rec (i).sf_no
                                   AND location_code = tahakkuk_rec (i).location_code
                                   AND add_order_no = tahakkuk_rec (i).add_order_no
                                   AND cover_code = tahakkuk_rec (i).hlth_cover_code) LOOP

                       IF NVL(rec.refuse_amount,0) <> 0 AND  rec.refuse_explanation IS NOT NULL THEN

                         vteminat_disi :=  SUBSTR(vteminat_disi||TO_CHAR (rec.refuse_amount, '999G999G999G999D99')||' Nedenleri:'||rec.refuse_explanation||' ', 1,200);

                       END IF;

                       v_found := 0;

                       FOR rec2 IN (SELECT SUBSTR (i.long_name, 1, 200) longname
                                      FROM koc_cc_hlth_out_pr_types T, inf_v_lang_trans_api i
                                     WHERE main_code = rec.main_code
                                       AND item_code = rec.item_code
                                       AND sub_item_code = rec.sub_item_code
                                       AND letter_type IN (SELECT letter_type
                                                             FROM koc_cc_hlth_out_gr_let
                                                            WHERE out_reas_group_code = 2
                                                              AND (   group_code = p_group_code
                                                              OR p_group_code IS NULL) )
                                       AND i.desc_int_id = T.desc_int_id
                                  ORDER BY letter_type) LOOP


                         vtah_red_neden := SUBSTR(vtah_red_neden||rec2.longname||' ',1, 750);
                         v_found        := 1;
                       END LOOP;

                       IF v_found = 0 THEN

                         FOR rec3 IN (SELECT SUBSTR (i.long_name, 1, 200) longname
                                        FROM koc_cc_hlth_out_pr_types T, inf_v_lang_trans_api i
                                       WHERE main_code = rec.main_code
                                         AND item_code = rec.item_code
                                         AND sub_item_code = rec.sub_item_code
                                         AND letter_type IN (SELECT letter_type
                                                               FROM koc_cc_hlth_out_gr_let
                                                              WHERE out_reas_group_code = 2
                                                                AND group_code =  '0' )
                                         AND i.desc_int_id = T.desc_int_id
                                    ORDER BY letter_type) LOOP

                           vtah_red_neden := SUBSTR(vtah_red_neden||rec3.longname||' ',1,750);

                         END LOOP;

                       END IF;


                     END LOOP;
                   EXCEPTION
                     WHEN OTHERS THEN
                       vtah_red_neden := ' ';
                       vteminat_disi  := ' ';
                   END;

                   /*
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vmain_code := ' ';
                         vitem_code := ' ';
                         vsub_item_code := ' ';
                         vrefuse_explanation := ' ';
                         vrefuse_amount := 0;
                      WHEN OTHERS
                      THEN
                         vmain_code := ' ';
                         vitem_code := ' ';
                         vsub_item_code := ' ';
                         vrefuse_explanation := ' ';
                         vrefuse_amount := 0;
                   END;

                   BEGIN
                      SELECT SUBSTR (i.long_name, 1, 200)
                        INTO vtah_red_neden
                        FROM koc_cc_hlth_out_pr_types t, inf_v_lang_trans_api i
                       WHERE main_code = vmain_code
                         AND item_code = vitem_code
                         AND sub_item_code = vsub_item_code
                         AND letter_type IN (
                                SELECT letter_type
                                  FROM koc_cc_hlth_out_gr_let
                                 WHERE out_reas_group_code = 2
                                   AND (   group_code = p_group_code
                                        OR p_group_code IS NULL
                                       ) )
                         AND i.desc_int_id = t.desc_int_id
                         AND ROWNUM < 2;
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vtah_red_neden := ' ';
                      WHEN OTHERS
                      THEN
                         vtah_red_neden := ' ';
                   END;

                   IF TRIM(vtah_red_neden) IS NULL THEN
                     BEGIN
                        SELECT SUBSTR (i.long_name, 1, 200)
                          INTO vtah_red_neden
                          FROM koc_cc_hlth_out_pr_types t, inf_v_lang_trans_api i
                         WHERE main_code = vmain_code
                           AND item_code = vitem_code
                           AND sub_item_code = vsub_item_code
                           AND letter_type IN (
                                  SELECT letter_type
                                    FROM koc_cc_hlth_out_gr_let
                                   WHERE out_reas_group_code = 2
                                     AND group_code =  '0' )
                           AND i.desc_int_id = t.desc_int_id
                           AND ROWNUM < 2;
                     EXCEPTION
                        WHEN NO_DATA_FOUND
                        THEN
                           vtah_red_neden := ' ';
                        WHEN OTHERS
                        THEN
                           vtah_red_neden := ' ';
                     END;
                   END IF;

                   IF vrefuse_amount <> 0 AND vrefuse_explanation <> ' '
                   THEN
                      vteminat_disi :=
                            TO_CHAR (vrefuse_amount, '999G999G999G999D99')
                         || ' Nedenleri:'
                         || vrefuse_explanation;
                   ELSE
                      vteminat_disi := ' ';
                   END IF;
                   */

                   IF p_grup_ferdi = 64
                   THEN
                      BEGIN
                         SELECT NVL (M.group_code, '0'), NVL (M.description, '0')
                           INTO vgrupkodu, vgrupadi
                           FROM --bv_koc_ocp_partitions_ext p,
                                koc_ocp_partitions_ext P,
                                koc_cp_group_master M
                          WHERE P.contract_id = tahakkuk_rec (i).contract_id
                            AND P.partition_no = tahakkuk_rec (i).sig_no
                            AND P.version_no = tahakkuk_rec (i).version_no
                            AND M.group_code = P.sub_company_code
                            AND M.validity_start_date <=
                                             TRUNC (tahakkuk_rec (i).process_date)
                            AND (   M.validity_end_date >=
                                             TRUNC (tahakkuk_rec (i).process_date)
                                 OR M.validity_end_date IS NULL
                                )
                            AND ROWNUM < 2;
                      EXCEPTION
                         WHEN NO_DATA_FOUND
                         THEN
                            vgrupkodu := '';
                            vgrupadi := ' ';
                         WHEN OTHERS
                         THEN
                            vgrupkodu := ' ';
                            vgrupadi := ' ';
                      END;
                   ELSIF p_grup_ferdi = 63
                   THEN
                      vgrupkodu := '';
                      vgrupadi := 'Grup tanimli degil';
                   END IF;

                   BEGIN
                      SELECT NVL
                                (SUBSTR
                                    (koc_clm_hlth_utils.getpartnernamebypartid
                                                          (tahakkuk_rec (i).part_id
                                                          ),
                                     1,
                                     100
                                    ),
                                 '***Sigortali Tanimli Degil***'
                                )
                        INTO vsigortaliadi
                        FROM DUAL;
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vsigortaliadi := '***Sigortali Tanimli Degil***';
                      WHEN OTHERS
                      THEN
                         vsigortaliadi := '***Sigortali Tanimli Degil***';
                   END;

                   BEGIN
                      SELECT NVL (A.r_cover_price, 0), NVL (A.r_exemption_sum, 0)
                        INTO vkalanteminat, vkalanmuaf
                        FROM koc_clm_hlth_indem_totals A
                       WHERE contract_id = tahakkuk_rec (i).contract_id
                         AND partition_no = tahakkuk_rec (i).sig_no
                         AND claim_inst_type = tahakkuk_rec (i).claim_inst_type
                         AND claim_inst_loc = tahakkuk_rec (i).claim_inst_loc
                         AND country_group =
                                DECODE
                                   (koc_clm_hlth_trnx.hascovercountrygroup
                                         (A.contract_id,
                                          A.partition_no,
                                          A.claim_inst_type,
                                          A.claim_inst_loc,
                                          A.country_group,
                                          A.cover_code,
                                          tahakkuk_rec (i).realization_ticket_date,
                                          A.is_pool_cover
                                         ),
                                    0, 0,
                                    A.country_group
                                   )
                         AND A.cover_code = tahakkuk_rec (i).hlth_cover_code
                         AND validity_start_date <=
                                          tahakkuk_rec (i).realization_ticket_date
                         AND NVL (validity_end_date,
                                  tahakkuk_rec (i).realization_ticket_date
                                 ) >= tahakkuk_rec (i).realization_ticket_date
                         AND NVL (A.is_pool_cover, 0) =
                                                    tahakkuk_rec (i).is_pool_cover
                         AND NVL (A.is_special_cover, 0) =
                                                 tahakkuk_rec (i).is_special_cover
                         AND NVL (is_valid, 0) = 1
                         AND EXISTS (
                                SELECT package_id
                                  FROM koc_ocp_risk_packages r
                                 WHERE r.contract_id = A.contract_id
                                   AND r.partition_no = A.partition_no
                                   AND r.package_id = A.package_id
                                   AND r.top_indicator = 'Y'
                                   AND r.action_code != 'D');
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vkalanteminat := 0;
                         vkalanmuaf := 0;
                      WHEN OTHERS
                      THEN
                         vkalanteminat := 0;
                         vkalanmuaf := 0;
                   END;

                   BEGIN
                      vfamily_code :=
                         NVL
                            (SUBSTR
                                (koc_clm_hlth_utils.getfamiliycode
                                                     (tahakkuk_rec (i).contract_id,
                                                      tahakkuk_rec (i).sig_no
                                                     ),
                                 1,
                                 10
                                ),
                             0
                            );
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vfamily_code := 0;
                      WHEN OTHERS
                      THEN
                         vfamily_code := 0;
                   END;

                   BEGIN
                      vbank_name :=
                         NVL
                            (koc_clm_hlth_utils2.getbankname
                                                    (tahakkuk_rec (i).creditor_bank
                                                    ),
                             ' '
                            );
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vbank_name := ' ';
                      WHEN OTHERS
                      THEN
                         vbank_name := ' ';
                   END;

                   BEGIN
                      vsubsidiary_name :=
                         NVL
                            (koc_clm_hlth_utils2.getsubsidiaryname
                                              (tahakkuk_rec (i).creditor_bank,
                                               tahakkuk_rec (i).creditor_subsidiary
                                              ),
                             ' '
                            );
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vsubsidiary_name := ' ';
                      WHEN OTHERS
                      THEN
                         vsubsidiary_name := ' ';
                   END;

                   BEGIN
                      vcover_def :=
                         NVL
                            (koc_clm_hlth_utils.getcoverdef
                                                  (tahakkuk_rec (i).hlth_cover_code
                                                  ),
                             ' '
                            );
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vcover_def := ' ';
                      WHEN OTHERS
                      THEN
                         vcover_def := ' ';
                   END;

                   BEGIN
                      vcountry_group :=
                         NVL
                            (koc_clm_hlth_utils.getcountrygroup
                                                     (tahakkuk_rec (i).country_code
                                                     ),
                             0
                            );
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vcountry_group := 0;
                      WHEN OTHERS
                      THEN
                         vcountry_group := 0;
                   END;

                  SELECT HLTH_SRV_PAY INTO v_sgk_srv FROM koc_clm_hlth_detail WHERE claim_id = tahakkuk_rec (i).claim_id AND sf_no = tahakkuk_rec (i).sf_no AND
                                                                                    add_order_no = tahakkuk_rec (i).add_order_no; -- task 191293

                   -- engine 29032017 TPA
                   v_row_line := v_company_title;
                   v_row_line := v_row_line || v_chr_tab || ' ' || tahakkuk_rec (i).policy_ref;
                   --v_row_line := tahakkuk_rec (i).policy_ref;
                   -- engine 29032017 TPA
                   --v_row_line := v_row_line || v_chr_tab || ' ' || NVL (vgrupkodu, '');
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (vgrupadi, ' ');
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (vfamily_code, 0);
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (tahakkuk_rec (i).sig_no, 1);
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (vsigortaliadi, ' ');
                   v_row_line := v_row_line || v_chr_tab || ' ' || tahakkuk_rec (i).ext_reference;
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (vcover_def, ' ');
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (LPAD (TO_CHAR (tahakkuk_rec (i).invoice_amt,'999G999G999G999D99'),20),0);
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (tahakkuk_rec (i).exemption_rate, 0);
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (LPAD (TO_CHAR (tahakkuk_rec (i).sumtrans,'999G999G999G999D99'),20),0);
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (vteminat_disi, ' ');
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (vtah_red_neden, ' ');
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (LPAD (TO_CHAR (vkalanteminat, '999G999G999G999D99'),20),0);
                   v_row_line := v_row_line || v_chr_tab || ' ' || LPAD (TO_CHAR (vkalanmuaf, '999G999G999G999D99'), 20);
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (vbank_name, ' ') || '/' || NVL (vsubsidiary_name, ' ') || ' ' || NVL (tahakkuk_rec (i).account_no, 0);
                   v_row_line := v_row_line || v_chr_tab || ' ' || tahakkuk_rec (i).invoice_date;
                   v_row_line := v_row_line || v_chr_tab || ' ' || tahakkuk_rec (i).invoice_no;
                   v_row_line := v_row_line || v_chr_tab || ' ' || koc_clm_hlth_utils.GETINSTITUTNAMEBYCODE(tahakkuk_rec (i).institute_code, tahakkuk_rec (i).date_of_loss);
                   IF v_sgk_srv=1 THEN
                     v_row_line := v_row_line || v_chr_tab || ' SaglikServisOde' ; -- task 191293
                   ELSE
                     v_row_line := v_row_line || v_chr_tab || ' - ' ;
                   END IF;

                   v_row_line := v_row_line || v_chr_tab || ' ' || tahakkuk_rec (i).user_id; -- engine 30032017 TPA

                   p_txtlinetype4 (p_txtlinetype4.COUNT + 1) := v_row_line;
                END LOOP;
            END IF; -- engine 25072017
         EXCEPTION
            WHEN OTHERS
            THEN
               verr := 4;
         END;
      END IF;

      --tahakkuk end

      ---bankas�z tahakkuk start
      IF SUBSTR (p_email_type, 6, 1) = '1'
      THEN
         vstring := ' ';

         BEGIN
            p_txtlinetype6.DELETE;
            v_head_line := 'SIRKET';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'POLI�E NO';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'GRUP ADI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'AILE KODU';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'SIRA NO';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'ADI SOYADI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'DOSYA NO';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'TEMINAT ADI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'FATURA TUTARI';
            v_head_line := v_head_line || v_chr_tab || ' ' || '�DEME ORANI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'TUTAR';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'TEMINAT DISI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'RED NEDENLERI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'KALAN TEMINAT';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'KALAN MUAF';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'HESAP NO';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'FATURA TARIHI ';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'FATURA NO ';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'KURUM ADI ';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'SAGLIK SERVIS ODEME';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'KULLANICI';
            p_txtlinetype6 (p_txtlinetype6.COUNT + 1) := v_head_line;
            v_row_line := '';
            vstring :=
                  ' select /*+ INDEX (ext KOC_OCP_POL_CONTRACTS_EXT_PK) */ e.claim_id,e.sf_no,e.process_date,c.product_id,e.add_order_no ,e.group_code, '
               || ' substr(c.policy_ref,1,4)||'' ''||substr(c.policy_ref,5,4)||'' ''||substr(c.policy_ref,9,4)||'' ''||substr(c.policy_ref,13,4) policy_ref, '
               || ' a.oar_no sig_No,c.version_no,e.part_id,realization_ticket_date,c.contract_id,(1-f.exemption_rate)*100 exemption_rate, '
               || ' b.creditor_bank,b.creditor_subsidiary,b.account_no,b.hlth_cover_code,a.ext_reference,e.claim_inst_type,e.claim_inst_loc,e.country_code, '
               --|| ' f.is_special_cover,f.is_pool_cover,f.location_code ,SUM(DECODE(a.sf_total_type,11,1,12,-1,0)*a.trans_base_amt*NVL(b.currency_exchange_rate,1)*(f.provision_total/a.trans_base_amt)) invoice_amt, '
               || ' f.is_special_cover,f.is_pool_cover,f.location_code ,round(SUM(DECODE(a.sf_total_type,11,1,12,-1,0)*a.trans_base_amt*NVL(b.currency_exchange_rate,1)),2) invoice_amt, '
               || ' sum(decode(a.sf_total_type,11,1,12,-1,0)*a.trans_amt*nvl(b.currency_exchange_rate,1)) sumtrans ,'
               || ' e.invoice_date, e.invoice_no, e.institute_code, e.date_of_loss '
               || ' , f.user_id user_id '
               --|| ' from clm_trans a ,koc_clm_trans_ext b ,clm_pol_bases c,koc_clm_hlth_detail e,koc_clm_hlth_provisions f, clm_pol_oar d, koc_v_policy_agent g , koc_ocp_partitions_ext p ' -- engine 30072017 TPA commented
               || ' from clm_trans a ,koc_clm_trans_ext b ,clm_pol_bases c,koc_clm_hlth_detail e,koc_clm_hlth_provisions f, clm_pol_oar d, koc_ocp_partitions_ext p ' -- engine 30072017 TPA added
               || ' ,koc_ocp_pol_contracts_ext ext,koc_ocp_pol_versions_ext pol_ext, ocp_policy_bases pol_b, ocp_policy_versions pol_v '
               || ' where nvl(e.CPA_STATUS,''XXX'') = ''TAH_BT'' and c.claim_id = a.claim_id  and c.claim_id = b.claim_id  and a.sf_no = b.sf_no and a.trans_no = b.trans_no and '
               --|| '  c.contract_id=g.contract_id and  e.claim_id = d.claim_id and e.provision_date is null '-- engine 30072017 TPA commented
               || '  c.contract_id=pol_ext.contract_id and  e.claim_id = d.claim_id and e.provision_date is null '-- engine 30072017 TPA added
               || ' and b.project_code is null and b.claim_id = e.claim_id and b.sf_no = e.sf_no and b.add_order_no = e.add_order_no and b.claim_id = f.claim_id and '
               || ' b.sf_no = f.sf_no and b.add_order_no = f.add_order_no and b.hlth_cover_code= f.cover_code '
               || ' and ext.contract_id = c.contract_id '
               || ' and ext.company_code = ''' || p_company_code || ''''
               || ' and d.contract_id = p.contract_id '
               || ' and d.oar_no = p.partition_no '
               || ' and d.version_no = p.version_no '
               -- engine 30072017 TPA added
               || ' and pol_b.contract_id = pol_ext.contract_id and pol_v.contract_id = pol_ext.contract_id and pol_v.version_no = pol_ext.version_no and pol_v.product_id = c.product_id '
               || ' and ((nvl (pol_ext.endorsement_no, 0) = 54 and pol_ext.version_no = pol_b.version_no) or (nvl (pol_ext.endorsement_no, 0) <> 54 and pol_b.top_indicator = ''Y'')) '
               || ' and pol_ext.reversing_version is null and ( (exists (select 1 from   koc_ocp_pol_versions_ext aa where aa.contract_id = pol_ext.contract_id '
               || ' and nvl (aa.endorsement_no, 0) = 54 and aa.reversing_version is null) and pol_ext.version_no = (select max (version_no) from koc_ocp_pol_versions_ext aa '
               || ' where aa.contract_id = pol_ext.contract_id and nvl (aa.endorsement_no, 0) = 54 and aa.reversing_version is null)) or (not exists '
               || ' (select 1 from koc_ocp_pol_versions_ext aa where aa.contract_id = pol_ext.contract_id and nvl (aa.endorsement_no, 0) = 54 and aa.reversing_version is null) '
               || ' and pol_ext.top_indicator = ''Y''))';
               -- engine 30072017 TPA added
               --|| ' and p.action_code <> ''D'' '
               --|| ' and p.top_indicator = ''Y'' ' ;
            vwhere_groupby := ' ';
            vwhere := ' ';
            vwhere_tarih := ' ';

            IF p_grup_ferdi IS NOT NULL
            THEN
               vwhere := vwhere || ' And c.product_id = ' || p_grup_ferdi;
            END IF;

            IF p_tarih_start IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || ' And b.realization_ticket_date >= '
                  || CHR (39)
                  || p_tarih_start
                  || CHR (39);
               vwhere_tarih :=
                     vwhere_tarih
                  || ' And b.realization_ticket_date >= '
                  || CHR (39)
                  || p_tarih_start
                  || CHR (39);
            END IF;

            IF p_tarih_end IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || ' And b.realization_ticket_date <= '
                  || CHR (39)
                  || p_tarih_end
                  || CHR (39);
               vwhere_tarih :=
                     vwhere_tarih
                  || ' And b.realization_ticket_date <= '
                  || CHR (39)
                  || p_tarih_end
                  || CHR (39);
            END IF;

            IF p_group_code IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || ' And e.group_code = '
                  || CHR (39)
                  || p_group_code
                  || CHR (39);
            END IF;

            IF p_sub_company_code IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || ' and p.sub_company_code = '
                  || CHR (39)
                  || p_sub_company_code
                  || CHR (39);
            END IF;

            IF p_agent_role IS NOT NULL
            THEN
               --vwhere := vwhere || ' And g.agent_role = ' || p_agent_role; -- engine 30072017 TPA commented
               vwhere := vwhere || ' And pol_b.agent_role = ' || p_agent_role;-- engine 30072017 TPA added
            END IF;

            IF p_sub_agent IS NOT NULL
            THEN
               --vwhere := vwhere || ' And g.sub_agent = ' || p_sub_agent;-- engine 30072017 TPA commented
               vwhere := vwhere || ' And pol_ext.sub_agent = ' || p_sub_agent;-- engine 30072017 TPA added
            END IF;

            --cozbay task148244 artik police no kullanilacak
            IF p_grup_ferdi = 64 THEN
              vwhere := vwhere || ' and c.policy_ref = ' || p_pol_ref_start;
            ELSE
              IF p_pol_ref_start IS NOT NULL  THEN
                 vwhere := vwhere || ' and c.policy_ref >= ' || p_pol_ref_start;
              END IF;

              IF p_pol_ref_end IS NOT NULL  THEN
                 vwhere := vwhere || ' and c.policy_ref <= ' || p_pol_ref_end;
              END IF;
            END IF;

            /*
            IF p_contract_start_id IS NOT NULL
            THEN
               vwhere :=
                    vwhere || ' And c.contract_id >= ' || p_contract_start_id;
            END IF;

            IF p_contract_end_id IS NOT NULL
            THEN
               vwhere :=
                      vwhere || ' And c.contract_id <= ' || p_contract_end_id;
            END IF;*/

            vwhere_groupby :=
                  ' group by  e.claim_id,e.sf_no,e.process_date,c.product_id,e.add_order_no ,e.group_code ,c.policy_ref,a.oar_no, c.version_no,e.part_id, realization_ticket_date, '
               || '  c.contract_id, f.exemption_rate,b.creditor_bank, b.creditor_subsidiary, b.account_no,b.hlth_cover_code, a.ext_reference, e.claim_inst_type, '
               || '  e.claim_inst_loc, e.country_code,f.is_special_cover,f.is_pool_cover,f.location_code, '
               || '  e.invoice_date, e.invoice_no, e.institute_code, e.date_of_loss '
               || ' , f.user_id '
               || '   having SUM(DECODE(a.sf_total_type,11,1,12,-1,0)*a.trans_amt*NVL(b.currency_exchange_rate,1)) > 0 ';
            vstring :=
                  vstring
               || ' '
               || vwhere
               || ' and b.trans_no = (select  max(trans_no) from koc_clm_trans_ext bb where bb.claim_id = b.claim_id '
               || ' and bb.sf_no = b.sf_no and   bb.add_order_no = f.add_order_no and   bb.hlth_cover_code= f.cover_code '
               || vwhere_tarih
               || ') '
               || vwhere_groupby;
            dbms_output.put_line('tahbt_query='||vstring);  
            OPEN vbankasiztahakkukcur FOR vstring;

            FETCH vbankasiztahakkukcur
            BULK COLLECT INTO bankasiztahakkuk_rec;

            CLOSE vbankasiztahakkukcur;

            bankasiztahakkuk_kontrol := 0;

            IF (bankasiztahakkuk_rec.COUNT > 0) THEN
                FOR i IN bankasiztahakkuk_rec.FIRST .. bankasiztahakkuk_rec.LAST
                LOOP
                   bankasiztahakkuk_kontrol := bankasiztahakkuk_kontrol + 1;
                   vgrupadi := NULL;
                   vgrupkodu := NULL;
                   vsigortaliadi := NULL;
                   vmain_code := NULL;
                   vitem_code := NULL;
                   vsub_item_code := NULL;
                   vrefuse_amount := NULL;
                   vtah_red_neden := NULL;
                   vteminat_disi := NULL;

                   BEGIN

                     FOR rec IN (SELECT DISTINCT main_code, item_code, sub_item_code,
                                       refuse_explanation, refuse_amount
                                  FROM koc_clm_hlth_reject_loss
                                 WHERE claim_id = bankasiztahakkuk_rec (i).claim_id
                                   AND sf_no = bankasiztahakkuk_rec (i).sf_no
                                   AND location_code = bankasiztahakkuk_rec (i).location_code
                                   AND add_order_no = bankasiztahakkuk_rec (i).add_order_no
                                   AND cover_code = bankasiztahakkuk_rec (i).hlth_cover_code) LOOP

                       IF NVL(rec.refuse_amount,0) <> 0 AND  rec.refuse_explanation IS NOT NULL THEN

                         vteminat_disi :=  SUBSTR(vteminat_disi||TO_CHAR (rec.refuse_amount, '999G999G999G999D99')||' Nedenleri:'||rec.refuse_explanation||' ', 1,200);

                       END IF;

                       v_found := 0;

                       FOR rec2 IN (SELECT SUBSTR (i.long_name, 1, 200) longname
                                      FROM koc_cc_hlth_out_pr_types T, inf_v_lang_trans_api i
                                     WHERE main_code = rec.main_code
                                       AND item_code = rec.item_code
                                       AND sub_item_code = rec.sub_item_code
                                       AND letter_type IN (SELECT letter_type
                                                             FROM koc_cc_hlth_out_gr_let
                                                            WHERE out_reas_group_code = 2
                                                              AND (   group_code = p_group_code
                                                              OR p_group_code IS NULL) )
                                       AND i.desc_int_id = T.desc_int_id
                                  ORDER BY letter_type) LOOP


                         vtah_red_neden := SUBSTR(vtah_red_neden||rec2.longname||' ',1, 750);
                         v_found        := 1;
                       END LOOP;

                       IF v_found = 0 THEN

                         FOR rec3 IN (SELECT SUBSTR (i.long_name, 1, 200) longname
                                        FROM koc_cc_hlth_out_pr_types T, inf_v_lang_trans_api i
                                       WHERE main_code = rec.main_code
                                         AND item_code = rec.item_code
                                         AND sub_item_code = rec.sub_item_code
                                         AND letter_type IN (SELECT letter_type
                                                               FROM koc_cc_hlth_out_gr_let
                                                              WHERE out_reas_group_code = 2
                                                                AND group_code =  '0' )
                                         AND i.desc_int_id = T.desc_int_id
                                    ORDER BY letter_type) LOOP

                           vtah_red_neden := SUBSTR(vtah_red_neden||rec3.longname||' ',1,750);

                         END LOOP;

                       END IF;


                     END LOOP;
                   EXCEPTION
                     WHEN OTHERS THEN
                       vtah_red_neden := ' ';
                       vteminat_disi  := ' ';
                   END;


                   IF p_grup_ferdi = 64
                   THEN
                      BEGIN
                         SELECT NVL (M.group_code, '0'), NVL (M.description, '0')
                           INTO vgrupkodu, vgrupadi
                           FROM --bv_koc_ocp_partitions_ext p,
                                koc_ocp_partitions_ext P,
                                koc_cp_group_master M
                          WHERE P.contract_id = bankasiztahakkuk_rec (i).contract_id
                            AND P.partition_no = bankasiztahakkuk_rec (i).sig_no
                            AND P.version_no = bankasiztahakkuk_rec (i).version_no
                            AND M.group_code = P.sub_company_code
                            AND M.validity_start_date <=
                                             TRUNC (bankasiztahakkuk_rec (i).process_date)
                            AND (   M.validity_end_date >=
                                             TRUNC (bankasiztahakkuk_rec (i).process_date)
                                 OR M.validity_end_date IS NULL
                                )
                            AND ROWNUM < 2;
                      EXCEPTION
                         WHEN NO_DATA_FOUND
                         THEN
                            vgrupkodu := '';
                            vgrupadi := ' ';
                         WHEN OTHERS
                         THEN
                            vgrupkodu := ' ';
                            vgrupadi := ' ';
                      END;
                   ELSIF p_grup_ferdi = 63
                   THEN
                      vgrupkodu := '';
                      vgrupadi := 'Grup tanimli degil';
                   END IF;

                   BEGIN
                      SELECT NVL
                                (SUBSTR
                                    (koc_clm_hlth_utils.getpartnernamebypartid
                                                          (bankasiztahakkuk_rec (i).part_id
                                                          ),
                                     1,
                                     100
                                    ),
                                 '***Sigortali Tanimli Degil***'
                                )
                        INTO vsigortaliadi
                        FROM DUAL;
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vsigortaliadi := '***Sigortali Tanimli Degil***';
                      WHEN OTHERS
                      THEN
                         vsigortaliadi := '***Sigortali Tanimli Degil***';
                   END;

                   BEGIN
                      SELECT NVL (A.r_cover_price, 0), NVL (A.r_exemption_sum, 0)
                        INTO vkalanteminat, vkalanmuaf
                        FROM koc_clm_hlth_indem_totals A
                       WHERE contract_id = bankasiztahakkuk_rec (i).contract_id
                         AND partition_no = bankasiztahakkuk_rec (i).sig_no
                         AND claim_inst_type = bankasiztahakkuk_rec (i).claim_inst_type
                         AND claim_inst_loc = bankasiztahakkuk_rec (i).claim_inst_loc
                         AND country_group =
                                DECODE
                                   (koc_clm_hlth_trnx.hascovercountrygroup
                                         (A.contract_id,
                                          A.partition_no,
                                          A.claim_inst_type,
                                          A.claim_inst_loc,
                                          A.country_group,
                                          A.cover_code,
                                          bankasiztahakkuk_rec (i).realization_ticket_date,
                                          A.is_pool_cover
                                         ),
                                    0, 0,
                                    A.country_group
                                   )
                         AND A.cover_code = bankasiztahakkuk_rec (i).hlth_cover_code
                         AND validity_start_date <=
                                          bankasiztahakkuk_rec (i).realization_ticket_date
                         AND NVL (validity_end_date,
                                  bankasiztahakkuk_rec (i).realization_ticket_date
                                 ) >= bankasiztahakkuk_rec (i).realization_ticket_date
                         AND NVL (A.is_pool_cover, 0) =
                                                    bankasiztahakkuk_rec (i).is_pool_cover
                         AND NVL (A.is_special_cover, 0) =
                                                 bankasiztahakkuk_rec (i).is_special_cover
                         AND NVL (is_valid, 0) = 1
                         AND EXISTS (
                                SELECT package_id
                                  FROM koc_ocp_risk_packages r
                                 WHERE r.contract_id = A.contract_id
                                   AND r.partition_no = A.partition_no
                                   AND r.package_id = A.package_id
                                   AND r.top_indicator = 'Y'
                                   AND r.action_code != 'D');
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vkalanteminat := 0;
                         vkalanmuaf := 0;
                      WHEN OTHERS
                      THEN
                         vkalanteminat := 0;
                         vkalanmuaf := 0;
                   END;

                   BEGIN
                      vfamily_code :=
                         NVL
                            (SUBSTR
                                (koc_clm_hlth_utils.getfamiliycode
                                                     (bankasiztahakkuk_rec (i).contract_id,
                                                      bankasiztahakkuk_rec (i).sig_no
                                                     ),
                                 1,
                                 10
                                ),
                             0
                            );
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vfamily_code := 0;
                      WHEN OTHERS
                      THEN
                         vfamily_code := 0;
                   END;

                   BEGIN
                      vbank_name :=
                         NVL
                            (koc_clm_hlth_utils2.getbankname
                                                    (bankasiztahakkuk_rec (i).creditor_bank
                                                    ),
                             ' '
                            );
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vbank_name := ' ';
                      WHEN OTHERS
                      THEN
                         vbank_name := ' ';
                   END;

                   BEGIN
                      vsubsidiary_name :=
                         NVL
                            (koc_clm_hlth_utils2.getsubsidiaryname
                                              (bankasiztahakkuk_rec (i).creditor_bank,
                                               bankasiztahakkuk_rec (i).creditor_subsidiary
                                              ),
                             ' '
                            );
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vsubsidiary_name := ' ';
                      WHEN OTHERS
                      THEN
                         vsubsidiary_name := ' ';
                   END;

                   BEGIN
                      vcover_def :=
                         NVL
                            (koc_clm_hlth_utils.getcoverdef
                                                  (bankasiztahakkuk_rec (i).hlth_cover_code
                                                  ),
                             ' '
                            );
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vcover_def := ' ';
                      WHEN OTHERS
                      THEN
                         vcover_def := ' ';
                   END;

                   BEGIN
                      vcountry_group :=
                         NVL
                            (koc_clm_hlth_utils.getcountrygroup
                                                     (bankasiztahakkuk_rec (i).country_code
                                                     ),
                             0
                            );
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vcountry_group := 0;
                      WHEN OTHERS
                      THEN
                         vcountry_group := 0;
                   END;

                  SELECT HLTH_SRV_PAY INTO v_sgk_srv FROM koc_clm_hlth_detail WHERE claim_id = bankasiztahakkuk_rec (i).claim_id AND sf_no = bankasiztahakkuk_rec (i).sf_no AND
                                                                                    add_order_no = bankasiztahakkuk_rec (i).add_order_no; -- task 191293


                   v_row_line := v_company_title;
                   v_row_line := v_row_line || v_chr_tab || ' ' || bankasiztahakkuk_rec (i).policy_ref;
                   --v_row_line := tahakkuk_rec (i).policy_ref;
                   -- engine 29032017 TPA
                   --v_row_line := v_row_line || v_chr_tab || ' ' || NVL (vgrupkodu, '');
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (vgrupadi, ' ');
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (vfamily_code, 0);
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (bankasiztahakkuk_rec (i).sig_no, 1);
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (vsigortaliadi, ' ');
                   v_row_line := v_row_line || v_chr_tab || ' ' || bankasiztahakkuk_rec (i).ext_reference;
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (vcover_def, ' ');
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (LPAD (TO_CHAR (bankasiztahakkuk_rec (i).invoice_amt,'999G999G999G999D99'),20),0);
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (bankasiztahakkuk_rec (i).exemption_rate, 0);
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (LPAD (TO_CHAR (bankasiztahakkuk_rec (i).sumtrans,'999G999G999G999D99'),20),0);
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (vteminat_disi, ' ');
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (vtah_red_neden, ' ');
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (LPAD (TO_CHAR (vkalanteminat, '999G999G999G999D99'),20),0);
                   v_row_line := v_row_line || v_chr_tab || ' ' || LPAD (TO_CHAR (vkalanmuaf, '999G999G999G999D99'), 20);
                   v_row_line := v_row_line || v_chr_tab || ' ' || NVL (vbank_name, ' ') || '/' || NVL (vsubsidiary_name, ' ') || ' ' || NVL (bankasiztahakkuk_rec (i).account_no, 0);
                   v_row_line := v_row_line || v_chr_tab || ' ' || bankasiztahakkuk_rec (i).invoice_date;
                   v_row_line := v_row_line || v_chr_tab || ' ' || bankasiztahakkuk_rec (i).invoice_no;
                   v_row_line := v_row_line || v_chr_tab || ' ' || koc_clm_hlth_utils.GETINSTITUTNAMEBYCODE(bankasiztahakkuk_rec (i).institute_code, bankasiztahakkuk_rec (i).date_of_loss);
                   IF v_sgk_srv=1 THEN
                     v_row_line := v_row_line || v_chr_tab || ' SaglikServisOde' ; -- task 191293
                   ELSE
                     v_row_line := v_row_line || v_chr_tab || ' - ' ;
                   END IF;

                   v_row_line := v_row_line || v_chr_tab || ' ' || bankasiztahakkuk_rec (i).user_id; -- engine 30032017 TPA

                   p_txtlinetype6 (p_txtlinetype6.COUNT + 1) := v_row_line;
                END LOOP;
            END IF; -- engine 25072017
         EXCEPTION
            WHEN OTHERS
            THEN
               verr := 6;
         END;
      END IF;

      --bankas�z tahakkuk end

      --MAHSUP start
      IF SUBSTR (p_email_type, 5, 1) = '1'
      THEN
         vstring := ' ';
         vwhere := NULL;

         BEGIN
            p_txtlinetype5.DELETE;
            -- engine 29032017 TPA
            v_head_line := 'SIRKET';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'SIGORTALI NO';
            --v_head_line := 'SIGORTALI NO';
            -- engine 29032017 TPA
            v_head_line := v_head_line || v_chr_tab || ' ' || 'AILE KODU';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'ADI SOYADI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'POLI�E NO';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'TAHAKKUK TARIHI';
            v_head_line := v_head_line || v_chr_tab || ' ' || 'TUTAR';
            p_txtlinetype5 (p_txtlinetype5.COUNT + 1) := v_head_line;
            v_row_line := '';
            vstring :=
                  ' SELECT * FROM ( SELECT /*+ INDEX (ext KOC_OCP_POL_CONTRACTS_EXT_PK) */ c.product_id, e.group_code, realization_ticket_date, '
               || '  e.part_id, a.oar_no sig_no, '
               || ' substr(c.policy_ref,1,4)||'' ''||substr(c.policy_ref,5,4)||'' ''||substr(c.policy_ref,9,4)||'' ''||substr(c.policy_ref,13,4) policy_ref, '
               || ' a.ext_reference,MIN (e.process_date) process_date,c.contract_id, '
               || ' ROUND (SUM (  DECODE (a.sf_total_type, 11, 1, 12, -1, 0)* a.trans_amt* NVL (b.currency_exchange_rate, 1)),2) sumtrans ,'
               || ' ROUND(SUM (DECODE (b.payment_type,''5'', (  DECODE (a.sf_total_type,11, 1,12, -1,0)* a.trans_amt* NVL (b.currency_exchange_rate, 1)),0)),2) sumtrans_banka, '
               || ' ROUND(SUM (DECODE (b.payment_type,''8'', (  DECODE (a.sf_total_type,11, 1,12, -1,0)* a.trans_amt* NVL (b.currency_exchange_rate, 1)),0)),2) sumtrans_elden '
               --|| ' FROM koc_clm_trans_ext b,clm_trans a,clm_pol_bases c,koc_clm_hlth_detail e, clm_pol_oar d, koc_v_policy_agent G , koc_ocp_partitions_ext p '-- engine 30072017 TPA commented
               || ' FROM koc_clm_trans_ext b,clm_trans a,clm_pol_bases c,koc_clm_hlth_detail e, clm_pol_oar d, koc_ocp_partitions_ext p '-- engine 30072017 TPA added
               || ' ,koc_ocp_pol_contracts_ext ext, koc_ocp_pol_versions_ext pol_ext, ocp_policy_bases pol_b, ocp_policy_versions pol_v '-- engine 30072017 TPA added
               || ' WHERE b.claim_id = c.claim_id AND a.claim_id = b.claim_id AND a.sf_no = b.sf_no AND a.trans_no = b.trans_no '
               --|| ' and c.contract_id=g.contract_id AND b.claim_id = e.claim_id '-- engine 30072017 TPA commented
               || ' and c.contract_id=pol_ext.contract_id AND b.claim_id = e.claim_id '-- engine 30072017 TPA added
               || ' AND b.sf_no = e.sf_no AND b.add_order_no = e.add_order_no '
               || ' AND e.claim_id = d.claim_id AND e.provision_date IS NULL'
               || ' and ext.contract_id = c.contract_id '
               || ' and ext.company_code = ''' || p_company_code || ''''
               || ' and d.contract_id = p.contract_id '
               || ' and d.oar_no = p.partition_no '
               || ' and d.version_no = p.version_no '
               -- engine 30072017 TPA added
               || ' and pol_b.contract_id = pol_ext.contract_id and pol_v.contract_id = pol_ext.contract_id and pol_v.version_no = pol_ext.version_no and pol_v.product_id = c.product_id '
               || ' and ((nvl (pol_ext.endorsement_no, 0) = 54 and pol_ext.version_no = pol_b.version_no) or (nvl (pol_ext.endorsement_no, 0) <> 54 and pol_b.top_indicator = ''Y'')) '
               || ' and pol_ext.reversing_version is null and ( (exists (select 1 from   koc_ocp_pol_versions_ext aa where aa.contract_id = pol_ext.contract_id '
               || ' and nvl (aa.endorsement_no, 0) = 54 and aa.reversing_version is null) and pol_ext.version_no = (select max (version_no) from koc_ocp_pol_versions_ext aa '
               || ' where aa.contract_id = pol_ext.contract_id and nvl (aa.endorsement_no, 0) = 54 and aa.reversing_version is null)) or (not exists '
               || ' (select 1 from koc_ocp_pol_versions_ext aa where aa.contract_id = pol_ext.contract_id and nvl (aa.endorsement_no, 0) = 54 and aa.reversing_version is null) '
               || ' and pol_ext.top_indicator = ''Y''))';
               -- engine 30072017 TPA added

               --|| ' and p.action_code <> ''D'' '
               --|| ' and p.top_indicator = ''Y'' ' ;
            vwhere := ' ';

            IF p_grup_ferdi IS NOT NULL
            THEN
               vwhere := vwhere || 'AND c.product_id =' || p_grup_ferdi;
            END IF;

            IF p_tarih_start IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || ' and b.realization_ticket_date >= '
                  || CHR (39)
                  || p_tarih_start
                  || CHR (39);
            END IF;

            IF p_tarih_end IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || ' and b.realization_ticket_date <= '
                  || CHR (39)
                  || p_tarih_end
                  || CHR (39);
            END IF;

            IF p_group_code IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || ' and e.group_code = '
                  || CHR (39)
                  || p_group_code
                  || CHR (39);
            END IF;

            IF p_sub_company_code IS NOT NULL
            THEN
               vwhere :=
                     vwhere
                  || ' and p.sub_company_code = '
                  || CHR (39)
                  || p_sub_company_code
                  || CHR (39);
            END IF;

            --cozbay task148244 artik police no kullanilacak
            IF p_grup_ferdi = 64 THEN
              vwhere := vwhere || ' and c.policy_ref = ' || p_pol_ref_start;
            ELSE
              IF p_pol_ref_start IS NOT NULL  THEN
                 vwhere := vwhere || ' and c.policy_ref >= ' || p_pol_ref_start;
              END IF;

              IF p_pol_ref_end IS NOT NULL  THEN
                 vwhere := vwhere || ' and c.policy_ref <= ' || p_pol_ref_end;
              END IF;
            END IF;
            /*
            IF p_contract_start_id IS NOT NULL
            THEN
               vwhere :=
                    vwhere || ' and c.contract_id >= ' || p_contract_start_id;
            END IF;

            IF p_contract_end_id IS NOT NULL
            THEN
               vwhere :=
                       vwhere || ' and c.contract_id <= ' || p_contract_end_id;
            END IF;*/

            IF p_agent_role IS NOT NULL
            THEN
               --vwhere := vwhere || ' and g.agent_role = ' || p_agent_role;-- engine 30072017 TPA commented
               vwhere := vwhere || ' and pol_b.agent_role = ' || p_agent_role;-- engine 30072017 TPA added
            END IF;

            IF p_sub_agent IS NOT NULL
            THEN
               --vwhere := vwhere || ' and g.sub_agent = ' || p_sub_agent;-- engine 30072017 TPA commented
               vwhere := vwhere || ' and pol_ext.sub_agent = ' || p_sub_agent;-- engine 30072017 TPA added
            END IF;

            vstring :=
                  vstring
               || ' '
               || vwhere
               || ' group by c.product_id,e.group_code,a.ext_reference,realization_ticket_date, '
               || ' e.part_id,a.oar_no,c.policy_ref,c.contract_id ) WHERE sumtrans != 0 ';
               dbms_output.put_line('mahsup_query='||vstring);
            OPEN vmahsupcur FOR vstring;

            FETCH vmahsupcur
            BULK COLLECT INTO mahsup_rec;

            CLOSE vmahsupcur;

            mahsup_kontrol := 0;

            -- engine 25072017 kay�t olmazsa loop'a girerken exception al�yordu.
            -- Exception handle edildi�i i�in form ekran�nda anla��lmaz hata mesaj� verebilir. Bu y�zden if eklendi.
            IF (mahsup_rec.COUNT > 0) THEN
                FOR i IN mahsup_rec.FIRST .. mahsup_rec.LAST
                LOOP
                   mahsup_kontrol := mahsup_kontrol + 1;
                   vsigortaliadi := NULL;
                   vfamily_code := NULL;

                   BEGIN
                      SELECT NVL
                                (SUBSTR
                                    (koc_clm_hlth_utils.getpartnernamebypartid
                                                            (mahsup_rec (i).part_id
                                                            ),
                                     1,
                                     100
                                    ),
                                 '***Sigortali Tanimli Degil***'
                                )
                        INTO vsigortaliadi
                        FROM DUAL;
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vsigortaliadi := ' ';
                      WHEN OTHERS
                      THEN
                         NULL;
                   END;

                   BEGIN
                      vfamily_code :=
                         SUBSTR
                            (koc_clm_hlth_utils.getfamiliycode
                                                       (mahsup_rec (i).contract_id,
                                                        mahsup_rec (i).part_id
                                                       ),
                             1,
                             10
                            );
                   EXCEPTION
                      WHEN NO_DATA_FOUND
                      THEN
                         vfamily_code := ' ';
                      WHEN OTHERS
                      THEN
                         NULL;
                   END;

                   -- engine 29032017 TPA
                   v_row_line := v_company_title;
                   v_row_line := v_row_line || v_chr_tab || ' ' || mahsup_rec (i).sig_no;
                   --v_row_line := mahsup_rec (i).sig_no;
                   -- engine 29032017 TPA
                   v_row_line := v_row_line || v_chr_tab || ' ' || vfamily_code;
                   v_row_line := v_row_line || v_chr_tab || ' ' || vsigortaliadi;
                   v_row_line :=
                       v_row_line || v_chr_tab || ' ' || mahsup_rec (i).policy_ref;
                   v_row_line :=
                         v_row_line
                      || v_chr_tab
                      || ' '
                      || mahsup_rec (i).realization_ticket_date;
                   v_row_line :=
                         v_row_line
                      || v_chr_tab
                      || ' '
                      || LPAD (TO_CHAR (mahsup_rec (i).sumtrans,
                                        '999G999G999G999D99'
                                       ),
                               20
                              );
                   p_txtlinetype5 (p_txtlinetype5.COUNT + 1) := v_row_line;
                END LOOP;
            END IF; -- engine 25072017
         EXCEPTION
            WHEN OTHERS
            THEN
               verr := 5;
         END;
      END IF;

      --mahsup end
      IF v_mail_address IS NOT NULL
      THEN
         v_p_to (1) := v_mail_address;
      ELSE
         IF p_grup_ferdi = 63
         THEN
            v_p_to (1) := 'bireyselsaglik@allianz.com.tr';
         ELSE
           --cozbay task148244 mail gondermeyi artik burda yapiyoruz
           v_mail_id := 1;

           OPEN cur_end_date;
           FETCH cur_end_date INTO v_term_end_date;
           CLOSE cur_end_date;

           IF p_sub_company_code IS NOT NULL THEN

             FOR rec_mail IN cur_mail(p_sub_company_code, v_term_end_date) LOOP
               v_p_to (v_mail_id) := rec_mail.mail;
               v_mail_id := v_mail_id+1;
             END LOOP;

           ELSE
             FOR rec IN cur_sub_comp LOOP

               FOR rec_mail IN cur_mail(rec.sub_company_code, v_term_end_date) LOOP
                 v_p_to (v_mail_id) := rec_mail.mail;
                 v_mail_id := v_mail_id+1;
               END LOOP;

             END LOOP;

           END IF;

           IF v_mail_id = 1 THEN --yani hic mail yok ise
             v_p_to (1) := 'Allianz.KurumsalTazminat@allianz.com.tr';
           END IF;

         END IF;
      END IF;

      v_mail.v_to := v_p_to;

      IF p_grup_ferdi = 63
      THEN
         --v_p_cc (1) := 'tarkan.dizdar@allianz.com.tr';   --sabit bir email konacak
         v_p_cc (1) := 'bireyselsaglik@allianz.com.tr';
      --sabit bir email konacak
      ELSE
         /*grp yetkilisine cc email gidecek*/
         --Task 130330 - grup i�in cc mailinin sadece Allianz.KurumsalTazminat@allianz.com.tr adresine gonderilmesi istendi (Mine Kaptan bilgisi ile)
         /*BEGIN
            SELECT email
              INTO v_cc_email
              FROM cp_partners a
             WHERE a.part_id =
                      (SELECT customer_partner_id
                         FROM koc_v_sec_system_users a
                        WHERE a.oracle_username =
                                 (SELECT DISTINCT a.related_user
                                             FROM koc_cp_hlth_group_roles a
                                            WHERE role_type = 'STAZMYET'
                                              AND a.group_code = p_group_code
                                              AND a.related_user IS NOT NULL
                                              AND a.group_validity_start_date =
                                                     (SELECT MAX
                                                                (group_validity_start_date
                                                                )
                                                        FROM koc_cp_hlth_group_roles
                                                       WHERE role_type =
                                                                    'STAZMYET'
                                                         AND group_code =
                                                                  p_group_code
                                                         AND related_user IS NOT NULL
                                                         AND validity_end_date IS NULL)
                                              AND ROWNUM < 2));
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               v_cc_email := 'Allianz.KurumsalTazminat@allianz.com.tr';
            WHEN OTHERS
            THEN
               v_cc_email := 'Allianz.KurumsalTazminat@allianz.com.tr';
         END;*/

         v_cc_email := 'Allianz.KurumsalTazminat@allianz.com.tr';

         v_p_cc (1) := v_cc_email;
      END IF;

      v_mail.v_cc := v_p_cc;

      IF p_grup_ferdi = 63
      THEN
         v_mail.v_from := '"Bireysel Saglik Tazminat"';
      ELSIF p_grup_ferdi = 64
      THEN
         v_mail.v_from := '"Kurumsal Saglik Tazminat"';
      END IF;

      --subject
      vtarih_subject := NULL;
      vek_subject := NULL;
      vacente2 := NULL;

      IF p_tarih_start != p_tarih_end
      THEN
         vtarih_subject :=
               TO_CHAR (p_tarih_start, 'DD/MM/YYYY')
            || '-'
            || TO_CHAR (p_tarih_end, 'DD/MM/YYYY');
         vek_subject := 'Tarih Araligindaki Listeleri';
      ELSE
         vek_subject := 'Tarihli Listeleri';
         vtarih_subject := TO_CHAR (p_tarih_start, 'DD/MM/YYYY');
      END IF;

      BEGIN
         SELECT reference_code
           INTO vacente2
           FROM dmt_agents dm
          WHERE dm.int_id = p_agent_role;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            vacente2 := NULL;
      END;

      IF p_grup_ferdi = 63   THEN
         v_mail.v_subject :=  vacente2 || ' ' || vtarih_subject || ' ' || vek_subject;
      ELSIF p_grup_ferdi = 64 THEN
         OPEN cur_group(NVL(p_sub_company_code,p_group_code));
         FETCH cur_group INTO v_sub_comp_code_name;
         CLOSE cur_group;
         v_mail.v_subject :=  /*p_group_code*/NVL(v_sub_comp_code_name,p_sub_company_code) || ' ' || vtarih_subject || ' ' || vek_subject;
      END IF;

      DBMS_LOB.createtemporary (v_mail.v_message_body, FALSE, 10);
      v_offset := DBMS_LOB.getlength (v_mail.v_message_body) + 1;
      v_html :=
            '<html>'
         --|| '<br>'
         || '<p>'
         || 'Merhaba,'
         || '</p>'
         --|| '<br>'
         || '<p>'
         || 'Partajiniza kayitli sigortalilarimiza ait tazminat islemleri ekli listelerde bildirilmistir.'
         || '</p>'
         --|| '<br>'
         ||'<ul>'
         --|| '<br>'
         || '<LI><b>�denmis ve Red Tazminatlara</b> ait listeler bilgi i�indir.'
         --|| '</br>'
         --|| '<br>'
         --|| '<br>'
         --|| 'Banka Bilgi Degisikligi ve Eksik Evrak Bekleyen Tazminatlara iliskin bilgi/belgelerin 1 ay i�inde tamamlanmasi i�in geregini rica ederiz.'
         --|| '<LI><b>Eksik Evrak Bekleyen Tazminatlara</b> iliskin bilgi/belgelerin listede "EKS�K EVRA�I �LETECE�� MA�L" kolonu alt�nda yer alan mail adresine iletilmesini �nemle rica ederiz.'  SBH-92 omert kapat�ld�
         || '<LI><b>Eksik Evrak Bekleyen Tazminatlara</b> iliskin bilgi/belgelerin AZNET/Hasar Y�netimi/Sa�l�k Tazminat Kay�t Sorgu ekran�ndan dosya i�ine dijital dok�man olarak eklenmesi gerekmektedir.'
         --|| '</br>'
         --|| '<br>'
         || '<LI><b>Kesin Onay �ptalli Tazminatlar</b> banka bilgi de�i�ikli�i yap�larak dosyan�n teknik onay�n�n al�nmas� taraf�n�zca sa�lanmal�d�r. Mail ile ayr�ca bilgilendirme yap�lmas�na gerek bulunmamaktad�r.'
         --|| '</br>'
         ||'</ul>'
         --|| '<br>'
         --|| '<br>'
         || '<p>'
         --|| 'Not: Bilgi/belgeleri 1 ay i�inde tamamlanmayan tazminat evraklari geri iade edilmektedir.'
         ||'Not:  Eksik Evrak Bekleyen Tazminatlar i�in, Bilgi/belgeleri 1 ay i�inde tamamlanmayan tazminat evraklari geri iade edilmektedir.'
         || '</p>'
         --|| '<br>'
         --|| '<br>'
         || '<p>'
         || 'Saygilarimizla,'
         || '</p>'
         || '</html>';
      DBMS_LOB.WRITE (v_mail.v_message_body, LENGTH (v_html), v_offset,
                      v_html);
      filename1 := 'Red Tazminatlar.xls';
      filename2 := 'Eksik Evrak Bekleyen Tazminatlar.xls';
      filename3 := 'Banka Bilgi Degisikligi Bekleyen Tazminatlar.xls';
      -- TPA_041 engine 21032017
      --filename4 := '�denmis Tazminatlar.xls';
      filename4 := '�denecek Tazminatlar.xls';
      -- TPA_041 engine 21032017
      filename5 := 'Mahsup Listesi.xls';
      filename6 := 'Hesap G�ncellemesi Bekleyen Tazminatlar.xls';

      IF red_kontrol = 0
      THEN
         p_txtlinetype1.DELETE;
         filename1 := NULL;
      END IF;

      IF eksik_kontrol = 0
      THEN
         p_txtlinetype2.DELETE;
         filename2 := NULL;
      END IF;

      IF kesin_kontrol = 0
      THEN
         p_txtlinetype3.DELETE;
         filename3 := NULL;
      END IF;

      IF tahakkuk_kontrol = 0
      THEN
         p_txtlinetype4.DELETE;
         filename4 := NULL;
      END IF;

      IF mahsup_kontrol = 0
      THEN
         p_txtlinetype5.DELETE;
         filename5 := NULL;
      END IF;

      IF bankasiztahakkuk_kontrol = 0
      THEN
         p_txtlinetype6.DELETE;
         filename6 := NULL;
      END IF;
      
      IF    red_kontrol != 0
         OR eksik_kontrol != 0
         OR kesin_kontrol != 0
         OR tahakkuk_kontrol != 0
         OR mahsup_kontrol != 0
         OR bankasiztahakkuk_kontrol != 0
      THEN
         DBMS_OUTPUT.PUT_LINE('sending');
         koc_smtp_wa_util.mail_files (v_mail,
                                      p_txtlinetype,
                                      filename1,
                                      filename2,
                                      filename3,
                                      filename4,
                                      filename5,
                                      filename6,
                                      p_txtlinetype1,
                                      p_txtlinetype2,
                                      p_txtlinetype3,
                                      p_txtlinetype4,
                                      p_txtlinetype5,
                                      p_txtlinetype6
                                     );
         DBMS_LOB.freetemporary (v_mail.v_message_body);
      ELSE 
           DBMS_OUTPUT.PUT_LINE('not sending'); 
           DBMS_OUTPUT.PUT_LINE('red_kontrol='||red_kontrol);
           DBMS_OUTPUT.PUT_LINE('eksik_kontrol='||eksik_kontrol);
           DBMS_OUTPUT.PUT_LINE('kesin_kontrol='||kesin_kontrol);
           DBMS_OUTPUT.PUT_LINE('tahakkuk_kontrol='||tahakkuk_kontrol);
           DBMS_OUTPUT.PUT_LINE('mahsup_kontrol='||mahsup_kontrol);
           DBMS_OUTPUT.PUT_LINE('bankas�z_tahakkuk_kontrol='||bankas�ztahakkuk_kontrol);
      END IF;

      p_rt := 20;
   EXCEPTION
      WHEN OTHERS
      THEN
         p_rt := 10 + verr;
   END;
BEGIN
    sendclmabsentdoclist(63,
                         TO_DATE('01/09/2019','DD/MM/YYYY'),
                         TO_DATE('05/09/2019','DD/MM/YYYY'),
                         null,
                         null,
                         null,                                 
                         53362,
                         null,
                         'extern.adem-ozer@allianz.com.tr',
                         '11110',
                          null,
                          '045',
                          v_rt);
                          
   dbms_output.put_line('v_rt='||v_rt);
END;
