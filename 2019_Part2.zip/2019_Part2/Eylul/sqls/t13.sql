select * from alz_hltprv_log where log_id = 132466533;
--132466344;

ALZ_HCLM_CONVERTER_UTILS

select * from clm_subfiles where ext_reference='58108378' '58108376', '58108370';'58108368'
select * from koc_clm_hlth_detail where ext_reference='58108383'  '58108379'--'58108378'
select * from alz_hclm_version_info where claim_id=41906348 41906342  41906339--41906333--41906331;
select * from alz_hltprv_log where log_id=132467208--log_date>trunc(sysdate) and note='COMPUTE_REMAINING_REQUEST' and log_id>132467080

select * from koc_clm_hlth_detail where ext_reference='58107571'

select ALZ_HCLM_CONVERTER_UTILS.getHclmUsage(null, null, null, 'WHBEKMEZ', null, null) FROM DUAL;

select * from alz_hclm_version_info where claim_id=41905918  41906348 for update;

select * from alz_hltprv_log where log_id=132461526--132467080

select ALZ_HCLM_CONVERTER_UTILS.getHclmUsage(null, null, null, 'WDA01_05083', null, null) FROM DUAL;
SELECT * from koc_auth_user_role_rel where username='WSIGORTAMSIG10_5040' and role_code='HCLMPROV' FOR UPDATE
WRONESANSSIG1_5125
WBOGAZICISIG1_5080;

select * from alz_hclm_institute_info where institute_code=1740 for update;


select * from alz_hltprv_log where log_id=132467620;

select * from koc_clm_hlth_detail where ext_reference='58108365'
select * from alz_hclm_version_info where claim_id=41906328
select * from koc_clm_hlth_indem_dec where claim_id=41906328 order by process_date

SELECT * FROM alz_hltprv_log a WHERE a.log_id = 132467990

select * from clm_pol_oar o where contract_id=419139242 and oar_no=25634 
and exists(select 1 from alz_hclm_version_info where claim_id = o.claim_id) order by claim_i

select * from koc_clm_hlth_provisions where claim_id=41906085;
select * from koc_clm_hlth_detail where claim_id=41906085

select * from alz_hltprv_log where log_id=132468571;

select * from clm_subfiles where ext_reference='58108476';
select * from alz_hclm_version_info where claim_id=41906468;
select * from alz_hltprv_log where log_id=132468633
