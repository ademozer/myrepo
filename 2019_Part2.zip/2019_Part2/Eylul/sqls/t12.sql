  select * from clm_subfiles where ext_reference='58108451'--'58107551'
  select * from alz_hclm_version_info where claim_id = 41906441 for update;
  select * from koc_clm_hlth_detail where ext_reference='58108451'
  
  
    select * from clm_subfiles where ext_reference='58108521'--'58107551'
  select * from alz_hclm_version_info where claim_id = 41906555 for update;
  
  58108524
  
  
      select * from clm_subfiles where ext_reference='58108524'--'58107551'
  select * from alz_hclm_version_info where claim_id = 41906558 for update;
  58108525
  
  select * from koc_clm_hlth_detail where ext_reference = '58108526' for update
  
  
  
    select *--- count(1) 
    --into vcount
    from koc_clm_hlth_reject_loss a
   where a.claim_id      = 41906441
     and a.sf_no         = 1
	   and a.add_order_no  = 1
	   and a.main_code     = '18' 
	   and a.item_code     = '11' 
	   and a.sub_item_code = '11'
     
  
  select * from alz_hltprv_log where log_id=132469098;
  
  select * from clm_subfiles where ext_reference='58108474'
  
  select * from alz_hclm_version_info where claim_id=41906465 for update
  
  koc_clm_hlth_trnx2.doClmRealizationAcc(clmDetail(1).claim_id
                                                  ,clmDetail(1).sf_no
                                                  ,clmDetail(1).add_order_no
                                                  ,1
                                                  ,pk_general_utils.policyInfo.product_id
                                                  ,pk_general_utils.policyInfo.partition_type
                                                  ,pk_general_utils.policyInfo.term_start_date 
                                                  ,1
                                                  ,:payment_param.payment_date
                                                  ,v_realization_batch_id
                                                  );
                                                  
                                                   KOC_CLM_HLTH_TRNX.Clmprovisiontype
