DECLARE
v_hltprv_Log          Hltprv_Log_Typ := Hltprv_Log_Typ();  

BEGIN

         v_hltprv_Log.Log_Id := Customer.Alz_hltprv_log_id_seq.Nextval;
         v_hltprv_Log.Order_No := 1;
         v_hltprv_Log.Servicename := 'ALZ_HCLM_CONVERTER_UTILS';
         --v_hltprv_Log.Processinfo := v_url;
         v_hltprv_Log.Note        := 'REJECT_PROVISION_REQUEST';
         v_hltprv_Log.Content     := 'LOG_ID';
         --v_hltprv_Log.Institutecode := v_institute_code;
         v_hltprv_Log.Log_Source    := 'PLSQL';
         v_hltprv_Log.Savelogwithpragma;
         
         v_hltprv_Log.Servicename := 'ALZ_HCLM_CONVERTER_UTILS';
         --v_hltprv_Log.Processinfo := v_url;
         v_hltprv_Log.Note        := 'REJECT_PROVISION_RESPONSE';
         v_hltprv_Log.Content     := 'LOG_ID2';
         --v_hltprv_Log.Institutecode := v_institute_code;
         v_hltprv_Log.Log_Source    := 'PLSQL';
         v_hltprv_Log.Savelogwithpragma;
         
         DBMS_OUTPUT.PUT_LINE( v_hltprv_Log.Log_Id);
         
END;        
