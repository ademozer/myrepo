BEGIN
  UPDATE KOC_CLM_HLTH_DETAIL
  SET INSTITUTE_CODE=NULL
  WHERE EXT_REFERENCE='58108526';
  
 COMMIT;
 
END;


BEGIN
koc_hlth_clm_transfer.pr_clm_hlth_set_remaining(vcontract_id,
                                                   voar_no,
                                                  0,--commit
                                                  9999,
                                                  p_err_msg);
END;                                                                                                    
