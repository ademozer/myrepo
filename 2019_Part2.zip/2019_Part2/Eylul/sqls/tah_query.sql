SELECT /*+ INDEX (ext KOC_OCP_POL_CONTRACTS_EXT_PK) */
 B.ext_reference,
 substr(c.policy_ref, 1, 4) || ' ' || substr(c.policy_ref, 5, 4) || ' ' ||
 substr(c.policy_ref, 9, 4) || ' ' || substr(c.policy_ref, 13, 4) policy_ref,
 a.approve_date,
 a.payment_approve_cancel_date,
 a.cancel_reason_code,
 b.invoice_total,
 pol_b.agent_role,
 pol_ext.sub_agent,
 b.part_id,
 b.claim_id,
 b.sf_no,
 b.add_order_no
  FROM koc_clm_ind_app_canc_reas a,
       koc_clm_hlth_detail       b,
       clm_pol_bases             c,
       clm_pol_oar               d,
       koc_ocp_partitions_ext    p,
       koc_ocp_pol_contracts_ext ext,
       koc_ocp_pol_versions_ext  pol_ext,
       ocp_policy_bases          pol_b,
       ocp_policy_versions       pol_v
 WHERE a.claim_id = b.claim_id
   AND a.sf_no = b.sf_no
   AND a.add_order_no = b.add_order_no
   AND a.claim_id = c.claim_id
   and b.claim_id = d.claim_id
   AND b.provision_date IS NULL
   AND C.contract_id = pol_ext.contract_id
   And c.product_id = 63
   and ext.contract_id = c.contract_id
   and ext.company_code = '045'
   and d.contract_id = p.contract_id
   and d.oar_no = p.partition_no
   and d.version_no = p.version_no
   and pol_b.contract_id = pol_ext.contract_id
   and pol_v.contract_id = pol_ext.contract_id
   and pol_v.version_no = pol_ext.version_no
   and pol_v.product_id = c.product_id
   and ((nvl(pol_ext.endorsement_no, 0) = 54 and
       pol_ext.version_no = pol_b.version_no) or
       (nvl(pol_ext.endorsement_no, 0) <> 54 and pol_b.top_indicator = 'Y'))
   and pol_ext.reversing_version is null
   and ((exists (select 1
                   from koc_ocp_pol_versions_ext aa
                  where aa.contract_id = pol_ext.contract_id
                    and nvl(aa.endorsement_no, 0) = 54
                    and aa.reversing_version is null) and
        pol_ext.version_no =
        (select max(version_no)
                   from koc_ocp_pol_versions_ext aa
                  where aa.contract_id = pol_ext.contract_id
                    and nvl(aa.endorsement_no, 0) = 54
                    and aa.reversing_version is null)) or
       (not exists (select 1
                       from koc_ocp_pol_versions_ext aa
                      where aa.contract_id = pol_ext.contract_id
                        and nvl(aa.endorsement_no, 0) = 54
                        and aa.reversing_version is null) and
        pol_ext.top_indicator = 'Y'))
   and payment_approve_cancel_date >= '01/09/2019'
   and payment_approve_cancel_date <= '05/09/2019'
   and pol_b.agent_role = 53362
   and exists
 (select 1
          from clm_trans aa, koc_clm_trans_ext bb
         where aa.claim_id = bb.claim_id
           and aa.sf_no = bb.sf_no
           and aa.trans_no = bb.trans_no
           and bb.claim_id = b.claim_id
           and bb.sf_no = b.sf_no
           and bb.add_order_no = b.add_order_no
           and aa.sf_total_type = '11'
           and aa.trans_no =
               (select max(y.trans_no)
                  from clm_trans y, koc_clm_trans_ext x
                 where x.claim_id = y.claim_id
                   and x.sf_no = y.sf_no
                   and x.trans_no = y.trans_no
                   and x.claim_id = bb.claim_id
                   and x.sf_no = bb.sf_no
                   and y.sf_total_type in ('11', '10', '12')
                   and x.add_order_no = bb.add_order_no
                   and x.hlth_cover_code = bb.hlth_cover_code
                   and bb.payment_approved_date IS NULL))
