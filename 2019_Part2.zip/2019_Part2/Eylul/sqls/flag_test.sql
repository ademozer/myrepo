DECLARE
       v_parameter VARCHAR2(10);
       CURSOR c1 IS
          SELECT HCLM_USAGE
          FROM ALZ_HCLM_INSTITUTE_INFO
          WHERE INSTITUTE_CODE = 175;
       v_hclm_usage NUMBER;
 BEGIN
      v_parameter := CUSTOMER.KOC_CLM_HLTH_UTILS.Getlookupparamvalue('HCLM_USAGE', SYSDATE);
      v_parameter := NVL(v_parameter, '1');
      IF v_parameter = '0' THEN
         OPEN c1;
         FETCH c1 INTO v_hclm_usage;
         CLOSE c1;
         v_hclm_usage := NVL(v_hclm_usage, 0);
      ELSE
         v_hclm_usage := TO_NUMBER(v_parameter);
      END IF;
          
      DBMS_OUTPUT.PUT_LINE('Hclm_Usage='||v_hclm_usage);
          
 END;
