select * from clm_subfiles where ext_reference='58108674';

select * from alz_hclm_version_info where claim_id=41906755;

select * from alz_hltprv_log where log_id=132473151;
132473167
