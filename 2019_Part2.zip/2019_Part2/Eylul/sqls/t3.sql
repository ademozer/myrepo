﻿SELECT institute_code,
       assignee,
       process_date,
       sf_total_type,
       ext_reference,
       hlth_cover_code,
       cover_exp,
       sirket_payi,
       realization_ticket_date,
       clm_status
  FROM (SELECT e.institute_code,
               a.assignee,
               d.process_date,
               DECODE(a.sf_total_type,
                      '10',
                      'Provizyon/Muallak',
                      '11',
                      'Tahakkuk',
                      12,
                      'Tahakkuk Ýptal',
                      'Diðer') sf_total_type,
               a.ext_reference,
               b.hlth_cover_code,
               koc_clm_hlth_utils.getcoverdef(b.hlth_cover_code) cover_exp,
               a.trans_amt * NVL(b.currency_exchange_rate, 1) sirket_payi,
               b.realization_ticket_date,
               decode(c.clm_status,
                      'CANCELLED',
                      'Ýptal',
                      'OPEN',
                      'Açýk',
                      c.clm_status) clm_status
          FROM clm_trans                  a,
               koc_clm_trans_ext          b,
               clm_status_history         c,
               koc_clm_status_history_ext d,
               koc_mv_skrm_suppliers      e
         WHERE a.claim_id = b.claim_id
           AND a.sf_no = b.sf_no
           AND a.trans_no = b.trans_no
           AND a.claim_id = c.claim_id
           AND a.sf_no = c.sf_no
           AND a.trans_no = c.trans_no
           AND c.status_id = d.status_id
           AND a.supp_id = e.supp_id
           and a.ext_reference='58108605'
         ORDER BY d.process_date DESC)
         
         select a.claim_id,a.sf_no,a.trans_no,a.assignee,a.trans_type,a.clm_status,a.trans_amt, b.hlth_cover_code 
         from clm_trans a, koc_clm_trans_ext b 
         where a.ext_reference='58108605' 
         and a.claim_id=b.claim_id 
         and a.trans_no=b.trans_no 
         and a.sf_no=b.sf_no 
         
         --and trans_no=1
         
         
         
         
         
