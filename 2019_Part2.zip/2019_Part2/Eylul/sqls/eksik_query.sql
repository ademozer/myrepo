SELECT /*+ INDEX (ext KOC_OCP_POL_CONTRACTS_EXT_PK) */
 c.product_id,
 a.add_order_no,
 a.claim_id,
 a.absent_doc_code evrak_no,
 c.contract_id,
 a.entry_date,
 'Eksik Evrak Bildirimi' status_exp,
 'KST-' || b.ext_reference mektup_no,
 substr(c.policy_ref, 1, 4) || ' ' || substr(c.policy_ref, 5, 4) || ' ' ||
 substr(c.policy_ref, 9, 4) || ' ' || substr(c.policy_ref, 13, 4) policy_ref,
 d.oar_no,
 b.part_id,
 b.group_code,
 b.invoice_total,
 b.comm_date,
 b.ext_reference,
 pol_b.agent_role,
 pol_ext.sub_agent,
 a.EXPLANATION,
 b.invoice_date,
 b.invoice_no,
 b.institute_code,
 b.date_of_loss,
 a.userid,
 p.sub_company_code
  FROM koc_clm_hlth_incomp_papers a,
       koc_clm_hlth_detail        b,
       clm_pol_bases              c,
       clm_pol_oar                d,
       koc_ocp_partitions_ext     p,
       koc_ocp_pol_contracts_ext  ext,
       koc_ocp_pol_versions_ext   pol_ext,
       ocp_policy_bases           pol_b,
       ocp_policy_versions        pol_v
 WHERE a.claim_id = b.claim_id
   AND a.sf_no = b.sf_no
   AND a.add_order_no = b.add_order_no
   AND a.status_code = 'A'
   AND b.claim_id = c.claim_id
   AND b.claim_id = d.claim_id
   AND c.contract_id = pol_ext.contract_id
   AND b.provision_date IS NULL
   AND b.STATUS_CODE not in ('R', 'C', 'ODE', 'TAH')
   AND c.product_id = 63
   and ext.contract_id = c.contract_id
   and ext.company_code = '045'
   and d.contract_id = p.contract_id
   and d.oar_no = p.partition_no
   and d.version_no = p.version_no
   and pol_b.contract_id = pol_ext.contract_id
   and pol_v.contract_id = pol_ext.contract_id
   and pol_v.version_no = pol_ext.version_no
   and pol_v.product_id = c.product_id
   and ((nvl(pol_ext.endorsement_no, 0) = 54 and
       pol_ext.version_no = pol_b.version_no) or
       (nvl(pol_ext.endorsement_no, 0) <> 54 and pol_b.top_indicator = 'Y'))
   and pol_ext.reversing_version is null
   and ((exists (select 1
                   from koc_ocp_pol_versions_ext aa
                  where aa.contract_id = pol_ext.contract_id
                    and nvl(aa.endorsement_no, 0) = 54
                    and aa.reversing_version is null) and
        pol_ext.version_no =
        (select max(version_no)
                   from koc_ocp_pol_versions_ext aa
                  where aa.contract_id = pol_ext.contract_id
                    and nvl(aa.endorsement_no, 0) = 54
                    and aa.reversing_version is null)) or
       (not exists (select 1
                       from koc_ocp_pol_versions_ext aa
                      where aa.contract_id = pol_ext.contract_id
                        and nvl(aa.endorsement_no, 0) = 54
                        and aa.reversing_version is null) and
        pol_ext.top_indicator = 'Y'))
   and a.entry_date >= '01/09/2019'
   and a.entry_date <= '05/09/2019'
   and pol_b.agent_role = 53362     
