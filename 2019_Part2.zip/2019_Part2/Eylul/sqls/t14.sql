select * from clm_subfiles where ext_reference='58107669'--'58107663';
select * from alz_hclm_version_info where claim_id=41906093 for update--132466413--41906084  for update

select * from alz_hltprv_log where note='COMPUTE_REMAINING_REQUEST' and log_id>132466344 order by 1

select * from alz_hltprv_log where log_id=132466608;


SELECT distinct K.PARAMETER,K.PARAMETER_NAME
FROM KOC_V_CP_HEALTH_LOOK_UP K
--,KOC_CLM_LTR_DOC_PROCESS c
WHERE K.LOOK_UP_CODE='LETTERTYPE'
AND K.SULA_ORA_NLS_CODE='TR'
--and c.CLAIM_ID=:CLAIM_ID
--and c.LETTER_TYPE=k.PARAMETER


select * from clm_subfiles where ext_reference='58108350'--'58107681'
select * from koc_clm_ltr_doc_process where claim_id=41906114 
select * from alz_hclm_version_info where claim_id=41906306

select * from alz_hltprv_log where log_id=132464815

select ext_reference, AFFLUENT_FLAG from koc_clm_hlth_detail where ext_reference in('58108350','58041620')
