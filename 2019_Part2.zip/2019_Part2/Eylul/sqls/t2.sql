--UPDATE CUSTOMER.ALZ_HLTH_CPA_DETAIL_HISTORY
--    SET   explanation=substr(:koc_clm_hlth_detail.invoice_explanation,1,200)
SELECT * FROM KOC_CLM_HLTH_DETAIL WHERE EXT_REFERENCE='58108843'

SELECT * FROM CUSTOMER.ALZ_HLTH_CPA_DETAIL_HISTORY  
  WHERE claim_id=41906995--:KOC_CLM_HLTH_DETAIL.claim_id
      and sf_no=1
      and add_order_no=1--:KOC_CLM_HLTH_DETAIL.add_order_no
      and cpa_status='TI'
      and process_date=(SELECT MAX(process_date) 
                           FROM CUSTOMER.ALZ_HLTH_CPA_DETAIL_HISTORY 
                          WHERE claim_id=41906995--:KOC_CLM_HLTH_DETAIL.claim_id
                             and sf_no=1
                            and add_order_no=1--:KOC_CLM_HLTH_DETAIL.add_order_no
                            and cpa_status='TI'
                            and userid='ARTOSUN'--:boiler.userid
                            and log_type=1)
      and userid='ARTOSUN'--:boiler.userid
      and log_type=1;
      
      ALZ_HLTH_CPA.insertInvoiceHistory;
      
       SELECT *--TRIM(mail) mail
          FROM koc_cp_hlth_group_people s
         WHERE 1=1 --group_code = psub_company_code
           AND TYPE = 'TAZM�NAT'
          -- AND pterm_end_date BETWEEN validity_start_date AND NVL(validity_end_date,pterm_end_date)
           --AND NVL (validity_end_date, SYSDATE) >= SYSDATE
           AND TRIM(mail) IS NOT NULL;
