select /*+ INDEX (ext KOC_OCP_POL_CONTRACTS_EXT_PK) */
 e.claim_id,
 e.sf_no,
 e.process_date,
 c.product_id,
 e.add_order_no,
 e.group_code,
 substr(c.policy_ref, 1, 4) || ' ' || substr(c.policy_ref, 5, 4) || ' ' ||
 substr(c.policy_ref, 9, 4) || ' ' || substr(c.policy_ref, 13, 4) policy_ref,
 a.oar_no sig_No,
 c.version_no,
 e.part_id,
 realization_ticket_date,
 c.contract_id,
 (1 - f.exemption_rate) * 100 exemption_rate,
 b.creditor_bank,
 b.creditor_subsidiary,
 b.account_no,
 b.hlth_cover_code,
 a.ext_reference,
 e.claim_inst_type,
 e.claim_inst_loc,
 e.country_code,
 f.is_special_cover,
 f.is_pool_cover,
 f.location_code,
 round(SUM(DECODE(a.sf_total_type, 11, 1, 12, -1, 0) * a.trans_base_amt *
           NVL(b.currency_exchange_rate, 1)),
       2) invoice_amt,
 sum(decode(a.sf_total_type, 11, 1, 12, -1, 0) * a.trans_amt *
     nvl(b.currency_exchange_rate, 1)) sumtrans,
 e.invoice_date,
 e.invoice_no,
 e.institute_code,
 e.date_of_loss,
 pol_b.agent_role,
 f.user_id user_id
  from clm_trans                 a,
       koc_clm_trans_ext         b,
       clm_pol_bases             c,
       koc_clm_hlth_detail       e,
       koc_clm_hlth_provisions   f,
       clm_pol_oar               d,
       koc_ocp_partitions_ext    p,
       koc_ocp_pol_contracts_ext ext,
       koc_ocp_pol_versions_ext  pol_ext,
       ocp_policy_bases          pol_b,
       ocp_policy_versions       pol_v
 where nvl(e.CPA_STATUS, 'XXX') != 'TAH_BT'
   and c.claim_id = a.claim_id
   and c.claim_id = b.claim_id
   and a.sf_no = b.sf_no
   and a.trans_no = b.trans_no
   and c.contract_id = pol_ext.contract_id
   and e.claim_id = d.claim_id
   and e.provision_date is null
   and b.project_code is null
   and b.claim_id = e.claim_id
   and b.sf_no = e.sf_no
   and b.add_order_no = e.add_order_no
   and b.claim_id = f.claim_id
   and b.sf_no = f.sf_no
   and b.add_order_no = f.add_order_no
   and b.hlth_cover_code = f.cover_code
   and ext.contract_id = c.contract_id
   and ext.company_code = '045'
   and d.contract_id = p.contract_id
   and d.oar_no = p.partition_no
   and d.version_no = p.version_no
   and pol_b.contract_id = pol_ext.contract_id
   and pol_v.contract_id = pol_ext.contract_id
   and pol_v.version_no = pol_ext.version_no
   and pol_v.product_id = c.product_id
   and ((nvl(pol_ext.endorsement_no, 0) = 54 and
        pol_ext.version_no = pol_b.version_no) or
        (nvl(pol_ext.endorsement_no, 0) <> 54 and pol_b.top_indicator = 'Y'))
   and pol_ext.reversing_version is null
   and ((exists (select 1
                   from koc_ocp_pol_versions_ext aa
                  where aa.contract_id = pol_ext.contract_id
                    and nvl(aa.endorsement_no, 0) = 54
                    and aa.reversing_version is null) and
         pol_ext.version_no =
         (select max(version_no)
                   from koc_ocp_pol_versions_ext aa
                  where aa.contract_id = pol_ext.contract_id
                    and nvl(aa.endorsement_no, 0) = 54
                    and aa.reversing_version is null)) or
        (not exists (select 1
                       from koc_ocp_pol_versions_ext aa
                      where aa.contract_id = pol_ext.contract_id
                        and nvl(aa.endorsement_no, 0) = 54
                        and aa.reversing_version is null) and
         pol_ext.top_indicator = 'Y'))
   And c.product_id = 63
   And b.realization_ticket_date >= '01/09/2019'
   And b.realization_ticket_date <= '05/09/2019'
   --And pol_b.agent_role = 53362
   and b.trans_no =
       (select max(trans_no)
          from koc_clm_trans_ext bb
         where bb.claim_id = b.claim_id
           and bb.sf_no = b.sf_no
           and bb.add_order_no = f.add_order_no
           and bb.hlth_cover_code = f.cover_code
           And b.realization_ticket_date >= '01/09/2019'
           And b.realization_ticket_date <= '05/09/2019')
 group by e.claim_id,
          e.sf_no,
          e.process_date,
          c.product_id,
          e.add_order_no,
          e.group_code,
          c.policy_ref,
          a.oar_no,
          c.version_no,
          e.part_id,
          realization_ticket_date,
          c.contract_id,
          f.exemption_rate,
          b.creditor_bank,
          b.creditor_subsidiary,
          b.account_no,
          b.hlth_cover_code,
          a.ext_reference,
          e.claim_inst_type,
          e.claim_inst_loc,
          e.country_code,
          f.is_special_cover,
          f.is_pool_cover,
          f.location_code,
          e.invoice_date,
          e.invoice_no,
          e.institute_code,
          e.date_of_loss,
           pol_b.agent_role,
          f.user_id
having SUM(DECODE(a.sf_total_type, 11, 1, 12, -1, 0) * a.trans_amt * NVL(b.currency_exchange_rate, 1)) > 0
