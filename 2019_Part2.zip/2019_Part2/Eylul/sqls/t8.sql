with q1 as
(
 select distinct customer_segment_type from
    (   select kimlik_no,customer_segment_type
   from
    (
    select customer_segment_type,
      case when TR_IDENTITY_NUMBER is not null then TR_IDENTITY_NUMBER
           when FOREIGN_IDENTITY_NUMBER is not null then FOREIGN_IDENTITY_NUMBER
           when TAX_NUMBER is not null then TAX_NUMBER
      end kimlik_no
    from cognos.affluent_customer
    )
    where kimlik_no='42352329774'
    ) a
 inner join
    (   select
            case when PH_TR_IDENTITY_NUMBER is not null then PH_TR_IDENTITY_NUMBER
                when PH_FOREIGN_IDENTITY_NUMBER is not null then PH_FOREIGN_IDENTITY_NUMBER
            when PH_TAX_NUMBER is not null then PH_TAX_NUMBER
            end kimlik_no
    from cognos.affluent_policy
    where policy_ref='0001171006127993'
    )b
    on a.kimlik_no=b.kimlik_no
)select distinct b.SEGMENT_CODE as SEGMENT_KODU,b.EXPLANATION as SEGMENT_ACIKLAMASI ,b.EXPLANATION_ON_DISPLAY as SEGMENT_EKRAN_ACIKLAMASI
    from q1
         inner join cognos.DIM_AFFLUENT_SEGMENT b
     on q1.CUSTOMER_SEGMENT_TYPE=b.SEGMENT_CODE
     
     SELECT AFFLUENT_GET_SEG(42673490702) FROM DUAL
     
     
     select * from koc_cc_vaccines where max_dose>0
     
     select * from koc_clm_hlth_detail where ext_reference='58108746' 
     
   select *--count(*)
    --into v_kullanilan
    from koc_clm_vacc_indem_totals v
        ,clm_pol_bases         pb
   where v.part_id = 18788880--:parameter.part_id
     and v.claim_id = pb.claim_id
     and v.vaccine_code = 'GRIP'
     /*and v.order_no = ( select max(order_no) 
                          from koc_clm_vacc_indem_totals vac
                         where vac.vaccine_code = :koc_cc_vaccines.vaccine_code
                           and vac.part_id = :parameter.p_part_id 
                      )*/
     and v.status_code not in('C','R'); 
