--insert into koc_process_close
--select * from koc_process_close@opusprep  where trunc(process_date)=TO_DATE('01/09/2019','DD/MM/YYYY') and process_type IN('CLOH')
select koc_clm_hlth_trnx.Ismonthclosedforacc(sysdate) from dual;

Koc_Clm_Hlth_Trnx;


select * from koc_dmt_agents_ext where upper(title) LIKE '%YALTI%'
select * from koc_dmt_agents_title_ext2 where upper(title) = '%YALT%'
select * from koc_dmt_agents_ext where int_id=12179 
select * from dmt_agents  where reference_code='362';

select * from web_sec_system_users
select * from koc_dmt_agency_tech_emp@opusprep where agent_int_id=25056 
select * from koc_dmt_agency_employees@opusprep where agent_int_id=25056 ;

--ALZ_TOBB_USER

SELECT * --MAX(AGEN_INT_ID) INTO v_user_agen_int_id 
FROM koc_cp_partners_ext WHERE identity_no='56713007010' and is_health_partner=1

select * from web_sec_system_users@opusprep where customer_partner_id in(
SELECT part_id --MAX(AGEN_INT_ID) INTO v_user_agen_int_id 
FROM koc_cp_partners_ext@opusprep WHERE identity_no='56713007010' 
)

 part_id IN (SELECT customer_partner_id FROM web_sec_system_users WHERE user_name = p_user_name);
 
 select * from web_sec_system_users where user_name like '%362' and end_date is null and active=1;
 
 select distinct username, ALZ_HCLM_CONVERTER_UTILS.getHclmUsage(null,null,null,username,null,null) 
 from KOC_AUTH_USER_ROLE_REL where username in('WDA4312_362','WDA4258_362','WDA4486_362', 'WDA0810_362') and role_code='HCLMPROV' for update
 
SELECT Customer.Alz_Affluent_Customer.Get_Policy_Customer(Koc_Ocp_Hlth_Utils.Get_Policy_Ref(441564560)) FROM DUAL
select Koc_Ocp_Hlth_Utils.Get_Policy_Ref(441564560) from dual
select * from clm_subfiles where ext_reference='58108604'
select * from clm_pol_oar where claim_id=41906671


 select distinct username, ALZ_HCLM_CONVERTER_UTILS.getHclmUsage(null,null,null,username,null,null) 
 from KOC_AUTH_USER_ROLE_REL where username in('WCPA_MOBILE') and role_code='HCLMPROV' for update
