select * from clm_pol_oar where claim_id=41906563
select * from clm_subfiles where claim_id=41906441--ext_reference ='58108527';

select * from koc_clm_hlth_provisions where claim_id in(select claim_id from clm_pol_oar where contract_id = 464674822 and oar_no=4341 )

select * from koc_clm_hlth_detail where claim_id in(select claim_id from clm_pol_oar where contract_id = 464674822 and oar_no=4341 )

select * from koc_clm_hlth_reject_loss where claim_id=41906554

select * from clm_subfiles where ext_reference='58108357';
select * from alz_hclm_version_info where claim_id=41906315;
select * from alz_hltprv_log where log_id=132467116
select * from alz_hltprv_log where log_id=132467112

41906563

select * from clm_subfiles where ext_reference='58108546'
select * from koc_clm_hlth_aso_prov where claim_id=41906585 

select * from koc_clm_hlth_indem_totals where contract_id = 464674822 and partition_no=4341 and claim_inst_type='AHK' and exemption_group='1'

BEGIN
koc_hlth_clm_transfer.pr_clm_hlth_set_remaining(vcontract_id,
                                                   voar_no,
                                                  0,--commit
                                                  9999,
                                                  p_err_msg);
END;                                                                                                    



 SELECT ALZ_HLTH_CPA_COMM_UTILS.GENERATE_INVOICE_HASH
    (A.CLAIM_ID,A.SF_NO, A.ADD_ORDER_NO, A.Invoice_Date,A.Invoice_No,
    A.Invoice_Total,A.Is_Original,A.Has_Unreadable_Doc,A.Institute_Code,
    A.Comm_Date,A.Claim_Inst_Type,A.Claim_Inst_Loc,A.Swift_Code,A.Date_Of_Loss,A.specialty_subject,
    A.STATUS_CODE,A.CPA_STATUS) 
   -- into v_clm_hash
    FROM Koc_Clm_Hlth_Detail A
    WHERE Claim_Id = 41906554
      AND Sf_No =1
      AND Add_Order_No = 1
      
      
      --1595620627
      
