SELECT *
  FROM (SELECT Claim_Id,
               Fax_Id,
               Fax_Arrival_Date Doc_Coming_Date,
               NULL Order_No,
               NULL Doc_Code,
               NULL Doc_Name,
               Fax_Relation_Date,
               'FAX' Doc_Source,
               NULL Doc_Type
          FROM Koc_Clm_Web_Fax_Path Fp
         WHERE NOT EXISTS (SELECT *
                  FROM Alz_Hltprv_Clm_Docs Cd
                 WHERE Fp.Fax_Id = Cd.Fax_Id)
           AND (CASE
                 WHEN Fax_Arrival_Date <=
                      (SELECT To_Date(Parameter, 'DD/MM/YYYY')
                         FROM Alz_Look_Up
                        WHERE Code = 'PROV_FNET_DATE') Then
                  1
                 WHEN fax_relation_date is null and
                      (SELECT Parameter
                         FROM Alz_Look_Up
                        WHERE Code = 'FAX_ACTIVE_CLM815') = '1' Then
                  1
                 Else
                  0
               End) = 1
        UNION ALL
        SELECT Claim_Id,
               Fax_Id,
               Received_Date Doc_Coming_Date,
               Order_No,
               Doc_Code,
               Doc_Name,
               NULL Fax_Relation_Date,
               'DYS' Doc_Source,
               Doc_Type
          FROM Alz_Hltprv_Clm_Docs
        UNION ALL
        SELECT Kchd.Claim_Id,
               Adi.Object_Id AS Fax_Id,
               Adi.Create_Date AS Doc_Coming_Date,
               Kchd.Add_Order_No AS Order_No,
               Adi.Doc_Code,
               Adi.File_Name AS Doc_Name,
               NULL Fax_Relation_Date,
               'FILENET' Doc_Source,
               Adi.Mime_Type AS Doc_Type
          FROM Alz_Doc_Infos Adi, Koc_Clm_Hlth_Detail Kchd
         WHERE Kchd.Ext_Reference = Adi.Ext_Reference
           AND Kchd.Add_Order_No = 1)
           WHERE Claim_Id = &p_Claim_ID
           ORDER BY doc_coming_date desc
