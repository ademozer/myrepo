SELECT DISTINCT USERNAME,ALZ_HCLM_CONVERTER_UTILS.getHclmUsage(null, null, null, USERNAME, null, null) 
FROM KOC_AUTH_USER_ROLE_REL WHERE USERNAME IN('WARTOSUN','WDALTUN','WEPUNAR','WHANSAHIN','WYSALICI','WMARSH23_5072','WDA9412_6687','WHSAHIN')
AND ROLE_CODE='HCLMPROV'


SELECT * FROM KOC_AUTH_USER_ROLE_REL WHERE USERNAME IN('WHANSAHIN') 
AND ROLE_CODE='HCLMPROV' FOR UPDATE

select * from alz_hclm_institute_info
--select * from web_sec_system_users  where user_name like '%6687'


SELECT * FROM ALZ_HCLM_INSTITUTE_INFO where institute_code=175 for update;

select * from alz_hltprv_log where log_id=132481532;

select * from koc_clm_hlth_detail d where request_system NOT IN('WS','ULAK','OPUS','PORTAL') and provision_date IS NULL
AND process_date>TO_DATE('01/08/2019','DD/MM/YYYY')
AND exists (SELECT 1 FROM koc_clm_hlth_proc_detail WHERE claim_id = d.claim_id)

select * from alz_hclm_version_info where claim_id=41905943 for update;

SET_REMAINING
