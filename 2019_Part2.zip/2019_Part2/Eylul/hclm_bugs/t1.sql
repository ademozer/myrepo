select * from alz_hltprv_log where log_id=132478128;

select * from koc_clm_hlth_indem_totals where contract_id= 419139242 and partition_no= 40797 and claim_inst_type='AK' and claim_inst_loc='YI'
 and cover_code IN ('S685','S699'),
 
 select * from alz_hclm_institute_info where institute_code='852' for update;
 
--and institutecode='128450'
  select * from alz_hltprv_log where log_date>trunc(sysdate) and note='COMPUTE_REMAINING_REQUEST' 
 order by log_date desc
 
 select * from koc_clm_hlth_indem_totals where contract_id=427380128 and partition_no=1 
 select * from alz_hltprv_log where log_id=137631102;
 
 select * from Koc_Cp_Health_Look_Up where look_up_code='HCLM_USAGE' FOR UPDATE
 
 select ALZ_HCLM_CONVERTER_UTILS.getHclmUsageForInst(175) FROM DUAL;
 select ALZ_HCLM_CONVERTER_UTILS.getHclmUsage(null, null, null, 'WARTOSUN', 'HCLM_USAGE', null ) FROM DUAL
 SELECT TO_NUMBER('-1') FROM DUAL;

insert into alz_hclm_institute_info   
create table diff_alz_hclm_institute_info
select * from alz_hclm_institute_info where institute_code in(1289,
3488,
2278,
2847,
2146,
2168,
323,
3311,
6411,
2072,
4549,
36,
2630,
5949,
529,
2780,
1750,
132740,
996,
337,
4617,
175,
6105,
746,
1752,
4538,
852,
3717,
6475,
28,
4547,
1407,
553,
6411) --for update

select * from alz_hclm_institute_info where institute_code=852 for update 
select * from diff_alz_hclm_institute_info for update

select * from alz_hclm_institute_info where hclm_usage=1
 
