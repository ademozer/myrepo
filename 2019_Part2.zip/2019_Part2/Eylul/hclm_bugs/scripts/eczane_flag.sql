 SELECT KOC_CLM_HLTH_UTILS.Getlookupparamvalue('PHRM_CLMID',SYSDATE) FROM DUAL;
 
 
select * from koc_cp_health_look_up  WHERE Look_Up_Code = 'PHRM_CLMID' for update;
select * from alz_hclm_institute_info where institute_code = 1683 for update;

select * from clm_subfiles where ext_reference='58840686';
select * from alz_hclm_version_info where claim_id=42841188 for update
