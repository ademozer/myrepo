 SELECT DISTINCT DECODE(kapd.payment_type,'KK','KK','HAVL'), max(kapd.coll_acc_date) coll_acc_date
    FROM Koc_Acc_Policy_Details  Koc_Apd,
         Koc_Acc_Receipt_Master  kar_master,
         koc_acc_payment_details kapd
   WHERE Koc_Apd.contract_id = 469727991--469390768--&p_contract_id
     AND Koc_Apd.family_code = 23144--3600--&p_family_code
     AND Koc_Apd.Receipt_Id = Kar_Master.Receipt_Id
     AND Kar_Master.Receipt_Type <> 'KOM'
     AND kapd.receipt_id = kar_master.receipt_id
     AND KAPD.ORDER_NO = KOC_APD.ORDER_NO
     AND KAPD.PAYMENT_TYPE NOT IN ('IADC', 'IADS')
     AND kar_master.cancelation_date IS NULL
     AND KOC_APD.IS_CANCELLED IS NULL
     AND KAPD.COLL_ACC_DATE IS NOT NULL
     GROUP BY kapd.payment_type
