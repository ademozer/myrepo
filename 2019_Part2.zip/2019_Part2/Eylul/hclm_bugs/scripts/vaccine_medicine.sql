select * from alz_hltprv_bre_log where claim_id=42761147 order by execution_date

select * from koc_cc_vaccines
select * from koc_cc_vacc_medicine_rel where barcode='8699636950104';

283
select * from all_tables where table_name like '%CLAUSE%'
select * from all_tab_columns where column_name like '%CLAUSE_ID%'

select * from koc_cc_clauses where clause_id=283


select * from ALZ_CLM_HLTH_CLAUSE_DECISION where clause_id=283




select *--s.institute_code,s.institute_skrs_code,m.institute_code,m.institute_skrs_code 
from koc_mv_skrm_suppliers
