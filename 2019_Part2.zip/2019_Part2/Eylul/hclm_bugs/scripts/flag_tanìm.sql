select * from alz_hclm_institute_info where institute_code=1464 for update
--0,1150683
select * from koc_auth_user_role_rel where username='WARTOSUN' for update;

select * from koc_cp_health_look_up where look_up_code='HCLM_USAGE' for update;

select * from koc_cp_health_look_up where look_up_code='PHRM_CLMID' 

select * from koc_clm_hlth_detail where process_date>TRUNC(SYSDATE-1) and institute_code=1605

select * from alz_hclm_institute_info where institute_code in(6475, 28, 4547, 1407, 553, 6411) for update

select * from alz_hclm_institute_info@opustest  where institute_code IN(6475,
28,
4547,
1407,
553,
5060,
45499,
6381,
0,
1150,
1683)

INSERT INTO KOC_AUTH_USER_ROLE_REL
SELECT * FROM KOC_AUTH_USER_ROLE_REL WHERE USERNAME IN('WARTOSUN','WDALTUN','WEPUNAR','WHANSAHIN','WYSALICI','WMARSH23_5072','WDA9412_6687')
AND ROLE_CODE='HCLMPROV'
/


6475
28
4547
1407
553
5060
45499
0
1150
1683


--update alz_hclm_institute_info  set hclm_usage=0
select * from koc_clm_suppliers_ext where institute_code = 6475 --1150 for update
select * from koc_mv_skrm_suppliers where hospital_type is null and exp_date is not null and instypname!='Eczane' and institute_type = 2

SELECT ALZ_HCLM_CONVERTER_UTILS.getHclmUsageForInst(1150), ALZ_HCLM_CONVERTER_UTILS.getHclmUsage(1150, null, '37557769', null, null, 'HCLM_PHARMACY') 
FROM DUAL;

SELECT ALZ_HCLM_CONVERTER_UTILS.getHclmUsage(1150, null, null, 'WEPUNAR', null, null) FROM DUAL;  --37557769
select * from koc_clm_hlth_detail where ext_reference='37557769'

koc_clm_hlth_utils.getsumprvbyclaim;

update alz_hclm_institute_info  set hclm_usage=1 where hclm_usage=0;

select * from clm_subfiles where ext_reference='58897654'
select * from alz_hclm_version_info where claim_id=42915747--42915742;
select * from alz_hltprv_log where log_id=139956050--139956032


58897654

select * from alz_hltprv_log where log_id=140155078

SELECT * FROM alz_hltprv_log WHERE log_id = (SELECT LOG_ID FROM CUSTOMER.ALZ_DUPLICATE_PROVISION WHERE EXT_REFERENCE='57789420');


SELECT * FROM ALZ_HCLM_VERSION_INFO WHERE CLAIM_ID=42888792;
KOC_CLM_HLTH_DETAIL;
ALZ_HLTH_DETAIL_HIST

