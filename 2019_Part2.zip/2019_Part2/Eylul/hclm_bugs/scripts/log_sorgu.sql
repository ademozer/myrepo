select * from alz_hltprv_log where log_date>trunc(sysdate) and servicename='ALZ_HCLM_CONVERTER_UTILS' and note='COMPUTE_REMAINING_REQUEST' 
and institutecode=1750 order by log_date desc;

select * from clm_subfiles where ext_reference='58824707'--'58825669';
select * from alz_hltprv_bre_log where claim_id=42820999;--42821980;
select * from koc_clm_medicine_indem_det where claim_id=42820999--42821980;
select * from alz_hltprv_log where log_id=139679499--139388063
select * from customer.alz_duplicate_provision where ext_reference='42821980';

select * from alz_hltprv_log where log_id=139388335--139229836--139229746
SELECT Barcode, Price, Unit
           FROM Rep_Clm_Medicine_Indem_Det a
          WHERE a.Claim_Id = 42821980 and a.cover_code = 'S512'
            --AND a.barcode = p_barcode
         UNION
         SELECT Barcode, Price, Unit
           FROM Koc_Clm_Medicine_Indem_Det a
          WHERE a.Claim_Id = 42821980
            AND a.cover_code = 'S512'
            
           select * from alz_hclm_version_info where claim_id=42821980 for update;
            
           KOC_CLM_HLTH_PHARMACY_UTILS;
           
           ALZ_HCLM_CONVERTER_UTILS;
           
           select * from ocp_policy_bases where contract_id=419139242
           
           select * from alz_hclm_institute_info where institute_code=6411 for update 
           
           
           select * from koc_clm_hlth_detail where ext_reference='58839654';
           select * from alz_hclm_version_info where claim_id=42842144;
           
           select * from clm_subfiles where ext_reference = '58867138'--'58868661'
           select * from koc_clm_hlth_provisions where claim_id=42878755;
           select * from customer.alz_duplicate_provision where ext_reference = '58868687'--'58868661';
           select * from alz_hltprv_log where log_id=139677217--139677217
           
           select * from koc_clm_hlth_detail where ext_reference = '58867138'
           
    
select * from alz_hltprv_log where log_id=139679499 
 
