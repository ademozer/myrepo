select m.*
  from koc_cc_medicines m
 where m.barcode != '8699676950164'
  and regexp_like(m.medicine_name, 'GARDA')
   --and m.is_special_medicine3 = 0
   --and nvl(m.is_special_medicine3, 0) = 0
   and m.validity_date = (select max(validity_date)
                          from koc_cc_medicines mm
                         where m.barcode = mm.barcode)
;
select * from koc_clm_medicine_indem_det 
select * from clm_subfiles where ext_reference='58868706';
select * from clm_pol_oar  where claim_id=42761147

select * from koc_cc_vaccines;
select * from koc_cc_vacc_medicine_rel where barcode='8699522967513'  


 SELECT Barcode, Price, Unit
           FROM Rep_Clm_Medicine_Indem_Det a
          WHERE a.Claim_Id = 42877810 and a.cover_code = 'S512'
            --AND a.barcode = p_barcode
         UNION
         SELECT Barcode, Price, Unit
           FROM Koc_Clm_Medicine_Indem_Det a
          WHERE a.Claim_Id =42877810
            AND a.cover_code = 'S512'

SELECT * FROM KOC_AUTHORIZATION_ROLE_DEF where role_code='HCLMPROV';

58777656;

KOC_CLM_HLTH_PHARMACY_UTILS

--

select * from all_objects where object_name like '%HCL%'
