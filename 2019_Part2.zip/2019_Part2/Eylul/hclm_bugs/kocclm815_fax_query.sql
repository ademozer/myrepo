SELECT Claim_Id,
       Fax_Id,
       Fax_Arrival_Date Doc_Coming_Date,
       NULL Order_No,
       NULL Doc_Code,
       NULL Doc_Name,
       Fax_Arrival_Date,
       Fax_Relation_Date,
       'FAX' Doc_Source,
       NULL Doc_Type
  FROM Koc_Clm_Web_Fax_Path Fp
 WHERE Claim_Id = &p_Claim_Id
 AND NOT EXISTS (SELECT *
                  FROM Alz_Hltprv_Clm_Docs Cd
                 WHERE Fp.Fax_Id = Cd.Fax_Id)
           AND (CASE
                 WHEN Fax_Arrival_Date <=
                      (SELECT To_Date(Parameter, 'DD/MM/YYYY')
                         FROM Alz_Look_Up
                        WHERE Code = 'PROV_FNET_DATE') Then
                  1
                 WHEN fax_relation_date is null and
                      (SELECT Parameter
                         FROM Alz_Look_Up
                        WHERE Code = 'FAX_ACTIVE_CLM815') = '1' Then
                  1
                 Else
                  0
               End) = 1
               
               SELECT To_Date(Parameter, 'DD/MM/YYYY')
                         FROM Alz_Look_Up
                        WHERE Code = 'PROV_FNET_DATE';
                        
               SELECT Parameter
                         FROM Alz_Look_Up
                        WHERE Code = 'FAX_ACTIVE_CLM815'   ;
                        
                        
SELECT *
                  FROM Alz_Hltprv_Clm_Docs Cd
                 WHERE Cd.Fax_Id = '167193565564043'                           
                        
