SELECT *
  FROM (SELECT claim_id,
               fax_id,
               fax_arrival_date doc_coming_date,
               NULL order_no,
               NULL doc_code,
               NULL doc_name,
               fax_relation_date,
               'FAX' doc_source,
               NULL doc_type
          FROM koc_clm_web_fax_path fp
         WHERE NOT EXISTS (SELECT *
                  FROM alz_hltprv_clm_docs cd
                 WHERE fp.fax_id = cd.fax_id)
           AND fax_arrival_date >=
               (SELECT TO_DATE(parameter, 'DD/MM/YYYY')
                  FROM alz_look_up
                 WHERE code = 'PROV_FNET_DATE')
        UNION ALL
        SELECT claim_id,
               fax_id,
               received_date doc_coming_date,
               order_no,
               doc_code,
               doc_name,
               NULL fax_relation_date,
               'DYS' doc_source,
               doc_type
          FROM alz_hltprv_clm_docs
        UNION ALL
        SELECT kchd.claim_id,
               adi.object_id AS fax_id,
               adi.create_date AS doc_coming_date,
               kchd.add_order_no AS order_no,
               adi.doc_code,
               adi.file_name AS doc_name,
               NULL fax_relation_date,
               'FILENET' doc_source,
               adi.mime_type AS doc_type
          FROM alz_doc_infos adi, koc_clm_hlth_detail kchd
         WHERE kchd.ext_reference = adi.ext_reference
           AND kchd.add_order_no = 1)
          WHERE claim_id=&p_claim_id
