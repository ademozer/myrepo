select * from koc_cc_vaccines

select * from clm_subfiles where ext_reference='58108746'
            select *--count(*)
              --into v_kullanilan
    from koc_clm_vacc_indem_totals v
       -- ,clm_pol_bases         pb
   where 1=1--v.part_id = :parameter.part_id
     and v.claim_id = 41906842
     and v.vaccine_code = 'GRIP'
     /*and v.order_no = ( select max(order_no) 
                          from koc_clm_vacc_indem_totals vac
                                                                where vac.vaccine_code = :koc_cc_vaccines.vaccine_code
                                                                  and vac.part_id = :parameter.p_part_id 
                                                                        )*/
                         and v.status_code not in('C','R');  


select * from alz_hclm_version_info where claim_id= 41906842;
select * from alz_hltprv_log where log_id=132482291

select * from clm_subfiles where ext_reference = ''
select * from alz_hclm_version_info where claim_id = 41906847-- 58108751

SELECT * FROM KOC_CLM_MEDICINE_INDEM_DET WHERE claim_id= 41906847 FOR UPDATE
--8699625960558

select * from alz_hclm_version_info
