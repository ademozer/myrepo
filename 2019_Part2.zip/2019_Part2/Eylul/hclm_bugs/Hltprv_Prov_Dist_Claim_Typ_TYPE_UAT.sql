
  CREATE OR REPLACE TYPE "CUSTOMER"."HLTPRV_PROV_DIST_CLAIM_TYP" AS OBJECT(
      --
      Claim_id                Number(10)
    , Sf_no                   Number(4)
    , Cover_Details           Customer.Hltprv_prov_dist_cover_tbl
    --
    , Constructor Function Hltprv_prov_dist_claim_typ Return Self As Result
    --
    , Constructor Function Hltprv_prov_dist_claim_typ(p_Claim_Id   number
                                                    , p_Sf_No      Number
      ) Return Self As Result
    --
    , member function GetCoverIndex(p_Cover_Code              Varchar2
                                  , p_Add_order_no            Number
                                  , p_Location_code           Number
      ) Return Pls_Integer
      --
    , member function GetNotBilledRejectAmount (p_Cover_Code    Varchar2
                                              , p_Add_order_no  Number
                                              , p_Location_code Number
      ) Return Number
      --
    , member function GetPatientRejectAmount (p_Cover_Code      Varchar2
                                            , p_Add_order_no    Number
                                            , p_Location_code   Number
      ) Return Number
      --
    , member Procedure SetCoverDetails(p_Cover_Code              Varchar2
                                    , p_Add_order_no            Number
                                    , p_Location_code           Number
                                    , p_Provision_total         Number
                                    , p_Request_amount          Number
                                    , p_Refusal_amount          Number
                                    , p_Exemption_amount        Number
                                    , p_Exemption_rate          Number
                                    , p_Sgk_amount              Number
                                    , p_Add_proc_amount         Number
                                    , p_CovInd            Out   Pls_Integer
      )

    , member procedure GetCoverAmountFromClaimfile(p_Claim_Id   number
                                                 , p_Sf_No      Number
      )
      --
    , member procedure DistCoversAmountsToDetails
      --
    , Member Function GetTypeValueInClob(p_indent_level  pls_integer default Null
      ) return clob
      --
    , Member Procedure WriteObjectToLog(p_logid  number default null)
)
CREATE OR REPLACE TYPE BODY "CUSTOMER"."HLTPRV_PROV_DIST_CLAIM_TYP" IS
      --
      Constructor Function Hltprv_prov_dist_claim_typ Return Self As Result Is
      Begin
         --
         Return;
         --
      End;
      --
      Constructor Function Hltprv_prov_dist_claim_typ(p_Claim_Id   number
                                                    , p_Sf_No      Number
      ) Return Self As Result Is
        --
      Begin
         --
         GetCoverAmountFromClaimfile(p_Claim_Id, p_Sf_No);
         --
         Return;
         --
      End;
      --
      member procedure DistCoversAmountsToDetails Is
         --
         v_Ind  Pls_Integer;
         --
      Begin
         --
         If Self.Cover_Details Is Null Then
            Return;
         End if;
         --
         v_Ind  :=  Self.Cover_Details.First;
         While v_Ind Is Not Null Loop
             Self.Cover_Details(v_Ind).DistCoverAmountsToDetails;
             v_Ind  :=  Self.Cover_Details.Next(v_Ind);
         End loop;
         --
      End;
      --
      member function GetCoverIndex(p_Cover_Code              Varchar2
                                  , p_Add_order_no            Number
                                  , p_Location_code           Number
      ) Return Pls_Integer Is
         --
         v_Ind  Pls_Integer;
         --
      Begin
         --
         If Self.Cover_Details Is Null Then
            Return 0;
         End if;
         --
         v_Ind := Self.Cover_Details.First;
         While v_Ind Is Not Null loop
             If Self.Cover_Details(v_Ind).Cover_Code    = p_Cover_Code And
                Self.Cover_Details(v_Ind).Add_order_no  = p_Add_order_no And
                Self.Cover_Details(v_Ind).Location_code = p_Location_code
             Then
                --
                Return v_Ind;
                --
             End if;
             v_Ind := Self.Cover_Details.Next(v_Ind);
         End Loop;
         --
         Return 0;
         --
      End;
      --
      member function GetNotBilledRejectAmount (p_Cover_Code    Varchar2
                                              , p_Add_order_no  Number
                                              , p_Location_code Number
      ) Return Number Is
         --
         cursor cRejectLoss(pc_Cover_Code              Varchar2
                          , pc_Add_order_no            Number
                          , pc_Location_code           Number
         ) Is
         Select Sum(a.Refuse_Amount) Refuse_Amount
           from Koc_clm_hlth_reject_loss a
          where a.Claim_Id          = Self.Claim_ID
            And a.Sf_No             = Self.Sf_No
            And a.Cover_Code        = pc_Cover_Code
            And a.Add_Order_No      = pc_Add_order_no
            And a.Location_code     = pc_Location_code
            And a.Barcode           = 0
            And A.Process_code_main = 0
            And a.Main_Code         = 16
            And a.Item_Code         = 12;
         cRejectLossRec   cRejectLoss%Rowtype;

      Begin
         --
         Open cRejectLoss(p_Cover_Code
                        , p_Add_order_no
                        , p_Location_code);
         Fetch  cRejectLoss Into cRejectLossRec;
         Close cRejectLoss;
         --
         Return nvl(cRejectLossRec.Refuse_Amount, 0);
         --
      End;
      --
      member function GetPatientRejectAmount (p_Cover_Code      Varchar2
                                            , p_Add_order_no    Number
                                            , p_Location_code   Number
      ) Return Number Is
         --
         cursor cRejectLoss(pc_Cover_Code              Varchar2
                          , pc_Add_order_no            Number
                          , pc_Location_code           Number
         ) Is
         Select Sum(a.Refuse_Amount) Refuse_Amount
           from Koc_clm_hlth_reject_loss a
          where a.Claim_Id          = Self.Claim_ID
            And a.Sf_No             = Self.Sf_No
            And a.Cover_Code        = pc_Cover_Code
            And a.Add_Order_No      = pc_Add_order_no
            And a.Location_code     = pc_Location_code
            And a.Barcode           = 0
            And A.Process_code_main = 0
            And (a.Main_Code, a.Item_Code) not in ((16,12));

         cRejectLossRec   cRejectLoss%Rowtype;

      Begin
         --
         Open cRejectLoss(p_Cover_Code
                        , p_Add_order_no
                        , p_Location_code);
         Fetch  cRejectLoss Into cRejectLossRec;
         Close cRejectLoss;
         --
         Return nvl(cRejectLossRec.Refuse_Amount, 0);
         --
      End;

      member Procedure SetCoverDetails(p_Cover_Code             Varchar2
                                     , p_Add_order_no            Number
                                     , p_Location_code           Number
                                     , p_Provision_total         Number
                                     , p_Request_amount          Number
                                     , p_Refusal_amount          Number
                                     , p_Exemption_amount        Number
                                     , p_Exemption_rate          Number
                                     , p_Sgk_amount              Number
                                     , p_Add_proc_amount         Number
                                     , p_CovInd            Out   Pls_Integer
      ) Is

        v_Ind               Pls_Integer;
        v_provision_total   Number;

      Begin
         --
         -- Key bilgide eksiklik varsa y�kleme yap�lamaz.
         If p_Cover_Code Is Null Or p_Add_order_no Is Null Or p_Location_code Is Null Then
            Return;
         End if;
         --
         -- Obje ilk defa kullan�l�yorsa
         If Cover_Details Is Null Then
            Cover_Details := Customer.Hltprv_prov_dist_cover_tbl();
         End if;
         --
         -- Zaten bu teminata ili�kin bilgiler y�klendi ise ��k
         v_Ind := Self.GetCoverIndex(p_Cover_Code, p_Add_order_no, p_Location_code);
         If v_Ind > 0 Then
            p_CovInd := v_Ind;
            Return;
         End if;
         --
         -- teminat daha �nce y�klenmedi ise ekle
         Self.Cover_Details.Extend;
         v_Ind := Self.Cover_Details.Last;
         Self.Cover_Details(v_Ind) := Customer.Hltprv_prov_dist_cover_typ();
         --
         --
         Self.Cover_Details(V_ind).Claim_id          := Self.Claim_id;
         Self.Cover_Details(V_ind).Sf_no             := Self.Sf_no;
         Self.Cover_Details(v_Ind).Cover_Code        := p_Cover_Code;
         Self.Cover_Details(v_Ind).Add_order_no      := p_Add_order_no;
        Self.Cover_Details(v_Ind).Location_code     := p_Location_code;

         v_provision_total := p_Provision_total;

         --ek i�lem tutar� ��kar�lmaz ise provizyon tutar�n� i�lemlere da��t�rken
         --ek i�lem tutar�ndan dolay� Detaylara da��t�lamayan tutar hatas� vermektedir.
         if p_Add_proc_amount is not null
         then
            v_provision_total := v_provision_total - (p_Add_proc_amount * (1 - nvl(p_Exemption_rate, 0)));
         end if;

         Self.Cover_Details(v_Ind).Provision_total   := v_provision_total;
         Self.Cover_Details(v_Ind).Request_amount    := p_Request_amount;
         Self.Cover_Details(v_Ind).Refusal_amount    := p_Refusal_amount;
         Self.Cover_Details(v_Ind).Exemption_amount  := p_Exemption_amount;
         Self.Cover_Details(v_Ind).Exemption_rate    := p_Exemption_rate;
         Self.Cover_Details(v_Ind).Sgk_amount        := p_Sgk_amount;
         --
         Self.Cover_Details(v_Ind).NotBilledRejectAmount  := GetNotBilledRejectAmount(P_cover_code, p_Add_order_no, p_Location_code);
         Self.Cover_Details(v_Ind).PatientRejectAmount    := GetPatientRejectAmount(P_cover_code, p_Add_order_no, p_Location_code);
         --
         p_CovInd := v_Ind;
         Return;
         --
      End;

      --
      member procedure GetCoverAmountFromClaimfile(p_Claim_Id   number
                                                 , p_Sf_No      Number
      ) Is
        --
        Cursor cClaimCover(pc_claim_id  number
                         , pc_Sf_No     Number) Is
        Select a.Cover_Code
             , a.Add_order_no
             , a.Location_code
             , a.Provision_total
             , a.Request_amount
             , a.Refusal_amount
             , a.Exemption_amount
             , a.Exemption_rate
             , a.Sgk_amount
             , a.Add_proc_amount
          from Koc_clm_hlth_provisions a
         where a.Claim_Id = pc_claim_id
           and a.sf_No    = pc_Sf_No
         Order By a.Add_Order_No;
        cClaimCoverRec   cClaimCover%Rowtype;
        --
        v_CovInd       Pls_Integer;
        --
      Begin
         --
         Open cClaimCover(p_claim_Id
                        , p_Sf_No);
         Fetch cClaimCover Into cClaimCoverRec;
         If cClaimCover%Found Then
            Cover_Details := Customer.Hltprv_prov_dist_cover_tbl();
         End if;

         --
         While cClaimCover%Found loop
           --
           SetCoverDetails(cClaimCoverRec.Cover_Code
                         , cClaimCoverRec.Add_order_no
                         , cClaimCoverRec.Location_code
                         , cClaimCoverRec.Provision_total
                         , cClaimCoverRec.Request_amount
                         , cClaimCoverRec.Refusal_amount
                         , cClaimCoverRec.Exemption_amount
                         , cClaimCoverRec.Exemption_rate
                         , cClaimCoverRec.Sgk_amount
                         , cClaimCoverRec.Add_proc_amount
                         , v_CovInd
                         );
             --
             Self.Cover_Details(v_CovInd).GetProvDetailsFromClaimfile(p_Claim_Id
                                                                    , p_Sf_No
                                                                    , cClaimCoverRec.Add_order_no
                                                                    , cClaimCoverRec.Location_code
                                                                    , cClaimCoverRec.Cover_Code
                                                                    );
             --
             Fetch cClaimCover Into cClaimCoverRec;
         End Loop;
         --
         Self.DistCoversAmountsToDetails;
         --
      End;
      --
      Member Function GetTypeValueInClob(p_indent_level  pls_integer default Null
      ) return clob is
        v_ind            pls_integer;
        v_level          pls_integer;
        v_indent         varchar2(1000);
        --
        v_Return        CLOB;
        --
      Begin
          --
          if abs(nvl(p_indent_level, 0)) > 1  then
             v_level := abs(nvl(p_indent_level, 0));
          else
             v_level := 1;
          end if;
          for i in 1..v_level loop
             v_indent := v_indent||'    ';
          end loop;
          v_indent := v_indent||'  --> ';
          --
          v_Return := v_Return||Chr(10);
          v_Return := v_Return||'HLTPRV_PROV_DIST_COVER_TYP'||Chr(10);
          v_Return := v_Return||v_indent||'Claim_Id        :'||self.Claim_Id        ||Chr(10);
          v_Return := v_Return||v_indent||'Sf_No           :'||self.Sf_No           ||Chr(10);
          if Self.Cover_Details Is Not Null Then
             v_Ind := self.Cover_Details.First;
             While v_Ind Is Not Null Loop
                 V_return := V_return||Self.Cover_Details(v_Ind).Gettypevalueinclob(P_indent_level);
                 v_Ind := self.Cover_Details.Next(v_Ind);
             End Loop;
          else
             v_Return := v_Return||v_indent||'TYPE - HLTPRV_PROV_DIST_COVER_TBL: Null';
          end if;
          --
          return v_Return;
          --;
      end;
      --
      Member Procedure WriteObjectToLog(p_logid  number default null) is
         --
         hltprv_log      hltprv_log_typ  := hltprv_log_typ();
         v_Log_Mode      Varchar2(50);
         --
      begin
         --
         If Coalesce(p_logid, 0) > 0 Then
            v_Log_Mode := Customer.hltprv_log_typ.GetLogMode(p_logid);
         End if;
         --
         v_Log_Mode := Coalesce(v_Log_Mode, '&');
         --
         If v_Log_Mode = 'NORMAL' then
            Return;
         End if;
         --
         hltprv_log.log_id := p_logid;
         hltprv_log.processinfo     := 'HLTPRV_PROV_DIST_CLAIM_TYP';
         If v_Log_Mode <> 'STRESS' then
            hltprv_log.Content := Self.GetTypeValueInClob;
         End if;
         --
         hltprv_log.savelogwithpragma;
      --
      End;
      --
End;
/
