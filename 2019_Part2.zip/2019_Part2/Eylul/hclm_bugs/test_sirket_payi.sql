DECLARE
  v_prov_total NUMBER;

  FUNCTION Getsumprvbyclaim(p_Claim_Id     NUMBER,
                            p_Sf_No        NUMBER,
                            p_Add_Order_No NUMBER) RETURN NUMBER IS
    v_Result NUMBER;
  BEGIN
    SELECT SUM(Decode(a.Sf_Total_Type, 10, 1, 0) * a.Trans_Amt *
               Nvl(b.Currency_Exchange_Rate, 1)) Sumtrans
      INTO v_Result
      FROM Clm_Trans a, Koc_Clm_Trans_Ext b
     WHERE a.Claim_Id = b.Claim_Id
       AND a.Sf_No = b.Sf_No
       AND a.Trans_No = b.Trans_No
       AND b.Claim_Id = p_Claim_Id
       AND b.Sf_No = p_Sf_No
       AND b.Add_Order_No =
           Decode(p_Add_Order_No, NULL, b.Add_Order_No, p_Add_Order_No)
       AND a.Trans_No =
           (SELECT MAX(x.Trans_No)
              FROM Koc_Clm_Trans_Ext x, Clm_Trans y
             WHERE x.Claim_Id = y.Claim_Id
               AND x.Sf_No = y.Sf_No
               AND x.Trans_No = y.Trans_No
               AND x.Claim_Id = b.Claim_Id
               AND x.Sf_No = b.Sf_No
               AND x.Add_Order_No = b.Add_Order_No
               AND x.Hlth_Cover_Code = b.Hlth_Cover_Code
               AND y.Sf_Total_Type IN ('10', '11', '12'));

    RETURN(Nvl(v_Result, 0));
  EXCEPTION
    WHEN OTHERS THEN
      RETURN(0);
  END Getsumprvbyclaim;
  
 BEGIN
   
   v_prov_total := Getsumprvbyclaim(41905852, 1 , 1);
   
   DBMS_OUTPUT.PUT_LINE(v_prov_total);
 END;
  
