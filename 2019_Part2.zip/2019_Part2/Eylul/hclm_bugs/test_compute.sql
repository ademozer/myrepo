DECLARE
   g_Contract_Id      NUMBER;    
    g_Partition_No     NUMBER;       
    g_Institute_Code   NUMBER;
    g_Claim_Inst_Type  VARCHAR2(100);   
    g_Claim_Inst_Loc   VARCHAR2(100);      
    g_Country_Group    VARCHAR2(100);                                                      
    g_Query_Date       DATE;                              
    g_Is_Referral      NUMBER := 0;      
    g_User_Id          VARCHAR2(100);
    g_provOutList   CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.ProvOutParamTyp; 
    HCLM_CHANNEL       VARCHAR2(100);
    VERSION_NO         VARCHAR2(100);
    PREV_STATUS        VARCHAR2(100);
    DENY_SMS           VARCHAR2(100);
    FUNCTION booleanToString(p_boolean IN NUMBER) RETURN VARCHAR2 IS
    BEGIN
        RETURN (CASE NVL(p_boolean, 0) WHEN 1 THEN 'true' ELSE 'false' END);
    END booleanToString;

    FUNCTION dateToString(p_date IN DATE) RETURN VARCHAR2 IS
          v_date  DATE;
          v_timestamp TIMESTAMP;
          v_timezone VARCHAR2(20);
          v_return VARCHAR2(100);
    BEGIN
        v_return := '';
        v_date := p_date;
        IF v_date IS NOT NULL THEN
           /*
             dbtimezone fonksiyonu +03:00 d�nd�rmektedir.
             2017 y�l�nda kal�c� yaz saati uygulamas�na ge�ilmi�tir.
             bu tarihten �nceki y�lllarda Eyl�l ve Mart aylar� aras�nda +02:00 olabilmektedir.
           */
           IF v_date > TO_DATE('2017','YYYY') THEN
               v_timezone := dbtimezone;
           ELSE
               v_timezone := TO_CHAR(TO_TIMESTAMP_TZ(TO_CHAR(v_date,'YYYY-MM-DD')||' Europe/Istanbul','YYYY-MM-DD TZR'),'TZH:TZM');
           END IF;
           v_timestamp := CAST (v_date AS TIMESTAMP WITH LOCAL TIME ZONE);
           v_return := TO_CHAR(v_date,'YYYY-MM-DD')||'T'||TO_CHAR(v_timestamp,'HH24:MI:SS.FF3')||v_timezone;
        END IF;
        RETURN v_return;
    END dateToString;

    FUNCTION numberToString(p_number IN NUMBER) RETURN VARCHAR2 IS
        v_string VARCHAR2(100);
    BEGIN
        v_string := REPLACE(TO_CHAR(p_number),',','.');
        IF INSTR(v_string,'.') = 1 THEN
           v_string := '0'||v_string;
        END IF;
        RETURN v_string;
    END numberToString;

    FUNCTION stringToNumber(p_string IN VARCHAR2) RETURN NUMBER IS
    BEGIN
       IF NVL(p_string, 'null') = 'null' THEN
          RETURN NULL;
       END IF;
       RETURN TO_NUMBER(p_string,'999999999.9999');
    END stringToNumber;
    function convertCoverInfoListToPayload(p_Cover_Info_List       IN ALZ_HCLM_CONVERTER_UTILS.CoverInfoParamTyp) RETURN CLOB IS
        v_cover_list CLOB;
     BEGIN

          v_cover_list := '[';

          FOR ndx IN 1..p_Cover_Info_List.COUNT LOOP

              IF ndx>1 THEN
                 v_cover_list := v_cover_list || ',';
              END IF;

              v_cover_list := v_cover_list || '{
                    "coverCode" : "'||p_Cover_Info_List(ndx).Cover_Code||'",
                    "daySeance" : "'||TO_CHAR(NVL(p_Cover_Info_List(ndx).Day_Seance,0))||'",
                    "exemptionOverAmount" : "'||numberToString(p_Cover_Info_List(ndx).Exemption_Over_Amount)||'",
                    "poolCover" : "'||booleanToString(p_Cover_Info_List(ndx).Is_Pool_Cover)||'",
                    "provisionAmount" : "'||numberToString(NVL(p_Cover_Info_List(ndx).Provision_Amount,0))||'",
                    "specialCover" : "'||booleanToString(p_Cover_Info_List(ndx).Is_Special_Cover)||'"
              }';

          END LOOP;

          v_cover_list := v_cover_list || ']';

          RETURN v_cover_list;

     END convertCoverInfoListToPayload;
    procedure setChannel(p_channel IN VARCHAR2) IS
    BEGIN
       IF p_channel IS NOT NULL THEN
            FOR rec IN (SELECT LEVEL, Regexp_Substr (p_channel, '[^-]+', 1, LEVEL) ELEMENT
                          FROM Dual CONNECT BY LEVEL <= LENGTH (Regexp_Replace (p_channel, '[^-]+')) + 1)
            LOOP
                IF rec.LEVEL = 1 THEN
                    HCLM_CHANNEL := rec.ELEMENT;
                END IF;
                IF rec.LEVEL = 2 THEN
                    VERSION_NO   := rec.ELEMENT;
                END IF;
                IF rec.LEVEL = 3 THEN
                    PREV_STATUS  := rec.ELEMENT;
                END IF;
                IF rec.LEVEL = 4 THEN
                    DENY_SMS := rec.ELEMENT;
                END IF;
            END LOOP;
       END IF;
    END setChannel;
     procedure callRestService(p_Url               In          Varchar2,
                              p_Method            In          Varchar2,
                              p_Request           In          Clob,
                              p_Response          Out         Clob,
                              p_Status            Out         Number,
                              p_Message           Out         Varchar2) IS

        v_Req               utl_http.req;
        v_Req_Length        Number;
        v_Res               utl_http.resp;
        v_Buffer            Varchar2(32767);
        v_Offset            Number := 1;
        v_Amount            Number :=32767;
        v_Utl_Err           Varchar2(1000);
        v_value             varchar2(4000);
        hata_code           varchar2(10);
        v_output            varchar2(10);
        v_Response          CLOB;
        v_Line_Number       NUMBER := 0;

        Begin

            v_Req_Length := dbms_lob.getlength(p_Request);
            v_Req := utl_http.begin_request(p_Url, p_Method, 'HTTP/1.1');
            utl_http.set_header(v_Req, 'Content-Length', v_Req_Length);
            utl_http.set_header(v_Req, 'Content-Type', 'application/json;charset=UTF-8');
            utl_http.set_header(v_Req, 'Transfer-Encoding', 'chunked' );
            utl_http.set_header(v_Req, 'Hclm-Channel', HCLM_CHANNEL );
            --utl_http.set_header(v_Req, 'hclm-channel', HCLM_CHANNEL );
            DBMS_OUTPUT.PUT_LINE(HCLM_CHANNEL);
            utl_http.set_transfer_timeout(300);
            utl_http.set_body_charset(v_Req,'UTF-8');

            While (v_Offset < v_Req_Length)
            Loop
               dbms_lob.read(p_Request, v_Amount, v_Offset, v_Buffer);
               utl_http.write_text(r    => v_Req, data => v_Buffer);
               v_Offset := v_Offset + v_Amount;
            End Loop;

            v_Res := utl_http.get_response(v_Req);
            p_status := 0;
            p_message := v_Res.status_code || ':' || v_Res.reason_phrase;
            IF v_Res.status_code != 200  THEN
                p_Status := 1;
            END IF;
            Begin
               loop
                  utl_http.read_line(v_Res, v_value);
                  v_value := TRIM(regexp_replace(v_value, '([^[:graph:] | ^[:blank:]])', ''));
                  v_Response := v_Response || v_value;
               end loop;
               utl_http.end_response(v_Res);
            Exception
            When utl_http.end_of_body Then
                 utl_http.end_response(v_Res);
            When utl_http.too_many_requests Then
                 utl_http.end_response(v_Res);
            When Others Then
                 utl_http.end_response(v_Res);
           End;
           p_Response := TRIM(v_Response);
           IF INSTR(p_Response,'"errors"')>0 THEN
               p_Status := 1;
               p_message := 'Business Exception';
           END IF;
        EXCEPTION
           WHEN OTHERS THEN
              utl_http.end_response(v_Res);
              v_utl_err:= Utl_Http.Get_Detailed_Sqlerrm;
              p_Status := 1;
              p_Response := '';
              p_Message := v_utl_err||' - '||p_url;
    END callRestService;
    
    procedure computeRemainingList(p_Contract_Id           IN NUMBER,
                                    p_Partition_No          IN NUMBER,
                                    p_Institute_Code        IN NUMBER,
                                    p_Claim_Inst_Type       IN VARCHAR2 DEFAULT NULL,
                                    p_Claim_Inst_Loc        IN VARCHAR2 DEFAULT NULL,
                                    p_Country_Group         IN VARCHAR2 DEFAULT NULL,
                                    p_Cover_Info_List       IN ALZ_HCLM_CONVERTER_UTILS.CoverInfoParamTyp,
                                    p_Swift_Code            IN VARCHAR2,
                                    p_Query_Date            IN DATE,
                                    p_Is_Referral           IN NUMBER DEFAULT NULL,
                                    p_User_Id               IN VARCHAR2,
                                    p_Out_Param_List        OUT ALZ_HCLM_CONVERTER_UTILS.ProvOutParamTyp) IS
       CURSOR crs_user IS
          SELECT d.user_type, g.user_group
            FROM CUSTOMER.Koc_Cp_User_Detail d, CUSTOMER.Koc_Oc_Hlth_User_Grp_Rel g
           WHERE d.Userid = p_User_Id
             AND d.user_type = g.user_type
             AND d.Validity_Start_Date <= p_Query_Date
             AND (d.Validity_End_Date IS NULL OR d.Validity_End_Date >= p_Query_Date)
             AND g.Validity_Start_Date <= p_Query_Date
             AND (g.Validity_End_Date IS NULL OR g.Validity_End_Date >= p_Query_Date);

        rec_user crs_user%ROWTYPE;

        CURSOR crs_policy IS
           SELECT Partner_Id, Policy_Start_Date, Group_Code
             FROM CUSTOMER.Koc_v_Hlth_Insured_Info_Indem
            where contract_id = p_Contract_Id
              and partition_no = p_Partition_No;

         rec_policy crs_policy%ROWTYPE;

         v_hltprv_Log          Hltprv_Log_Typ := Hltprv_Log_Typ();

         v_request CLOB;
         v_response CLOB;
         v_url VARCHAR2(200) := get_url_link('http://esb.allianz.com.tr:12000/hclm-health-claim-service/api/v1/computeremaining/list');
         --v_url VARCHAR2(200) := 'http://10.70.225.42:8070/hclm-health-claim-service/api/v1/computeremaining/list';
         v_status NUMBER;
         v_message VARCHAR2(1000);
         v_cover_info VARCHAR2(32000);
         v_user_group VARCHAR2(32000);
         v_ndx NUMBER:=0;
         v_ndx1      NUMBER;
         v_ndx2      NUMBER;
     BEGIN

         OPEN crs_policy;
         FETCH crs_policy INTO rec_policy;
         CLOSE crs_policy;

         v_user_group := '';

         FOR rec_user IN crs_user LOOP

            IF v_ndx > 0 THEN

                v_user_group :=  v_user_group || ',';

            END IF;

            v_user_group := v_user_group||'"'||rec_user.user_group||'"';

            v_ndx := v_ndx + 1;

         END LOOP;

         v_request := '{
            "claimInstLoc" : "'||p_Claim_Inst_Loc||'",
            "claimInstType" : "'||p_Claim_Inst_Type||'",
            "countryGroup" : "'||p_Country_Group||'",
            "contractId" : "'||TO_CHAR(p_Contract_Id)||'",
            "coverInfoParamList" : '|| convertCoverInfoListToPayload(p_Cover_Info_List) ||',
            "instituteCode" : "'||TO_CHAR(p_Institute_Code)||'",
            "invoiceDate" : "'||dateToString(p_Query_Date)||'",
            "partitionNo" : "'||TO_CHAR(p_Partition_No)||'",
            "partnerId" : "'||TO_CHAR(rec_policy.Partner_Id)||'",
            "policyGroupCode" : "'||rec_policy.Group_Code||'",
            "policyStartDate" : "'||dateToString(rec_policy.Policy_Start_Date)||'",
            "queryDate" : "'||dateToString(p_Query_Date)||'",
            "realizationDate" : "'||dateToString(p_Query_Date)||'",
            "referral" : "'||booleanToString(p_Is_Referral)||'",
            "swiftCode": "'||p_Swift_Code||'",
            "userGroup": ['||v_user_group||'],
            "userDto" : {
                "userId" : "' || p_User_Id || '",
                "userName" : "' ||p_User_Id || '"
            }
        }';

         v_hltprv_Log.Log_Id        := Customer.Alz_hltprv_log_id_seq.Nextval;
         v_hltprv_Log.Order_No      := 1;
         v_hltprv_Log.Servicename   := 'ALZ_HCLM_CONVERTER_UTILS';
         v_hltprv_Log.Processinfo   := v_url;
         v_hltprv_Log.Note          := 'COMPUTE_REMAINING_REQUEST';
         v_hltprv_Log.Content       := v_request;
         v_hltprv_Log.Institutecode := p_Institute_Code;
         v_hltprv_Log.Log_Source    := 'PLSQL';
         v_hltprv_Log.Savelogwithpragma;

         callRestService(v_url, 'POST', v_request, v_response, v_status, v_message);

         v_hltprv_Log.Servicename   := 'ALZ_HCLM_CONVERTER_UTILS';
         v_hltprv_Log.Processinfo   := v_url;
         v_hltprv_Log.Note          := 'COMPUTE_REMAINING_RESPONSE';
         v_hltprv_Log.Content       := v_response;
         v_hltprv_Log.Institutecode := p_Institute_Code;
         v_hltprv_Log.Log_Source    := 'PLSQL';
         v_hltprv_Log.Savelogwithpragma;

         IF v_status = 0 THEN
             v_ndx1 := INSTR(v_response,'{"data" : {');
             v_ndx2 := INSTR(v_response,'},"uiMessages"') - v_ndx1;
             v_response := SUBSTR(v_response, v_ndx1+11, v_ndx2-11);
         ELSE
             v_ndx1 := INSTR(v_response,'{"errors" : [');
             v_ndx2 := INSTR(v_response,'],"warnings"') - v_ndx1;
             v_response := SUBSTR(v_response, v_ndx1+15, v_ndx2-17);
         END IF;

         v_response := replace(replace(replace(replace(v_response,'[{', ''),'}',''),'}]',''),'{','');
         v_ndx := 0;
         FOR rec IN (SELECT TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1) , '"',''))   KEY,
                            TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1, 2), '"','')) VALUE1,
                            TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1, 3), '"','')) VALUE2
                     FROM (SELECT Regexp_Substr (v_response, '[^,]+', 1, LEVEL) ELEMENT
                             FROM Dual
                          CONNECT BY LEVEL <= LENGTH (Regexp_Replace (v_response, '[^,]+')) + 1)) LOOP

              IF rec.KEY = 'message' THEN
                v_message := rec.value1;
              END IF;

              IF rec.VALUE2 IS NOT NULL THEN
                  IF rec.VALUE1 = 'provisionAmount' THEN
                      v_ndx := v_ndx + 1;
                      p_Out_Param_List(v_ndx).Provision_Amount := stringToNumber(rec.VALUE2);
                      p_Out_Param_List(v_ndx).Cover_Code       := rec.KEY;
                  END IF;
              END IF;

              IF rec.KEY = 'daySeance' THEN
                  p_Out_Param_List(v_ndx).Day_Seance := stringToNumber(rec.VALUE1);
              END IF;

              IF rec.KEY = 'exemptionRate' THEN
                  p_Out_Param_List(v_ndx).Exemption_Rate := stringToNumber(rec.VALUE1);
              END IF;

              IF rec.KEY = 'exemptionSumAmount' THEN
                  p_Out_Param_List(v_ndx).Exemption_Sum := stringToNumber(rec.VALUE1);
              END IF;

              IF rec.KEY = 'instituteExemptionSumAmount' THEN
                  p_Out_Param_List(v_ndx).Inst_Exemp_Sum := stringToNumber(rec.VALUE1);
              END IF;

              IF rec.KEY = 'overPriceAmount' THEN
                  p_Out_Param_List(v_ndx).Over_Price := stringToNumber(rec.VALUE1);
              END IF;

              IF rec.KEY = 'remainedCoverPriceAmount' THEN
                  p_Out_Param_List(v_ndx).Remained_Cover_Price := stringToNumber(rec.VALUE1);
              END IF;

              IF rec.KEY = 'remainedDaySeance' THEN
                  p_Out_Param_List(v_ndx).Remained_Day_Seance := stringToNumber(rec.VALUE1);
              END IF;

        END LOOP;

        IF v_status = 1 THEN
           Raise_Application_Error(-20200,  v_message);
        END IF;
     EXCEPTION
     WHEN OTHERS THEN
          v_hltprv_Log.Servicename   := 'ALZ_HCLM_CONVERTER_UTILS';
          v_hltprv_Log.Processinfo   := v_url;
          v_hltprv_Log.Note          := 'COMPUTE_REMAINING_EXCEPTION';
          v_hltprv_Log.Content       := v_message || dbms_utility.format_error_stack || dbms_utility.format_error_backtrace;
          v_hltprv_Log.Institutecode := p_Institute_Code;
          v_hltprv_Log.Log_Source    := 'PLSQL';
          v_hltprv_Log.Savelogwithpragma;
          Raise_Application_Error(-20200,  'Limit Hesaplama S�ras�nda Bir Hata Olu�tu:'||v_hltprv_Log.Log_Id||':'||v_message);
     END computeRemainingList;

PROCEDURE COMPUTE_REMAINING_LIST IS
                             
        v_clmProvisions    KOC_CLM_HLTH_TRNX.Clmprovisiontype;                               
        v_provOutParam     KOC_CLM_HLTH_TRNX.Provoutparamtyp;
        
        v_Prov_Data_Rec Koc_Pk_Hlth_Provision.Provdatarec;  
        v_Count NUMBER := 0;   
        v_coverInfoList CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.coverInfoParamTyp;          
        v_Swift_Code     VARCHAR2(100);    
             
     BEGIN
       
        FOR rec IN (SELECT Claim_Id, Add_Order_No, Sf_No, Institute_Code, Claim_Inst_Type, Claim_Inst_Loc, medula_date, date_of_loss, provision_date
                      FROM Koc_Clm_Hlth_Detail WHERE EXT_REFERENCE = '58839654') LOOP
                
        --g_Contract_Id     := COALESCE(rec.Contract_Id, g_Contract_Id);
        --g_Partition_No    := COALESCE(rec.Partition_No, g_Partition_No);
        g_Institute_Code  := COALESCE(rec.Institute_Code, g_Institute_Code);
        g_Claim_Inst_Type := COALESCE(rec.Claim_Inst_Type, g_Claim_Inst_Type);
        g_Claim_Inst_Loc  := COALESCE(rec.Claim_Inst_Loc, g_Claim_Inst_Loc);
        g_Country_Group   := 0;
        g_Query_Date      := COALESCE(rec.medula_date, rec.Date_Of_Loss, rec.Provision_Date, g_Query_Date);
        g_Is_Referral     := NULL;
        g_User_Id         := 'MEDISER28';--COALESCE(:Koc_v_Hlth_Users.Userid, g_User_Id, 'MEDISER28');
        BEGIN
           SELECT contract_id, oar_no
           INTO g_Contract_Id,g_Partition_No
           FROM clm_pol_oar 
           WHERE claim_id = rec.claim_id;
        EXCEPTION WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('oar problem');
        END; 
        --CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.
        setCHANNEL('CENTRAL_PROVISION:'||rec.Claim_Id||':'||rec.Sf_No||':'||rec.Add_Order_No);  
        END LOOP;
       
       
                          
          v_coverInfoList(1).Cover_Code := 'S176';
          v_coverInfoList(1).Day_Seance := 150;
          v_coverInfoList(1).Provision_Amount := 201.15;
          v_coverInfoList(1).Exemption_Over_Amount := NULL;
          v_coverInfoList(1).Is_Pool_Cover :=  0;
          v_coverInfoList(1).Is_Special_Cover := 0;
          
          v_coverInfoList(2).Cover_Code := 'S177';
          v_coverInfoList(2).Day_Seance := 10;
          v_coverInfoList(2).Provision_Amount := 200.95;
          v_coverInfoList(2).Exemption_Over_Amount := NULL;
          v_coverInfoList(2).Is_Pool_Cover :=  0;
          v_coverInfoList(2).Is_Special_Cover := 0;
          --v_Swift_Code := G_PROVISIONS(ndx).Swift_Code;         
           
            --message('compute_remaining_list2('||ndx||') - '||G_PROVISIONS(ndx).Cover_Code||'-'||G_PROVISIONS(ndx).Provision_Total); 
       
        
        v_Swift_Code := NVL(v_Swift_Code, 'TL');
        
      
        --CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.setCHANNEL('CENTRAL_PROVISION:'||:Koc_Clm_Hlth_Detail.Claim_Id||':'||:Koc_Clm_Hlth_Detail.Sf_No||':'||:Koc_Clm_Hlth_Detail.Add_Order_No);                                
     
        --CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.
        computeRemainingList(g_Contract_Id,
                                                               g_Partition_No,
                                                               g_Institute_Code,
                                                               g_Claim_Inst_Type,
                                                               g_Claim_Inst_Loc,
                                                               g_Country_Group,
                                                               v_coverInfoList,
                                                               v_Swift_Code,
                                                               g_Query_Date,
                                                               g_Is_Referral,   
                                                               g_User_Id,
                                                               g_provOutList);  
                                                                                                
        --message('compute_remaining_list bitti.'||g_provOutList(1).Cover_Code||':'||g_provOutList(1).Provision_Amount);
           
     END COMPUTE_REMAINING_LIST;  
     
  BEGIN
         COMPUTE_REMAINING_LIST;
         FOR ndx IN 1..g_provOutList.COUNT LOOP
             DBMS_OUTPUT.PUT_LINE('Cover_Code:'||g_provOutList(ndx).Cover_Code||':'||g_provOutList(ndx).Provision_Amount||':'||g_provOutList(ndx).Day_Seance);
         END LOOP;
  END;
    
