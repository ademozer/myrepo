DECLARE
v_hclm NUMBER := 0;
  
function getHclmUsageForInstCore(p_institute_code IN NUMBER) RETURN NUMBER IS
       v_parameter VARCHAR2(10);
       CURSOR c1 IS
          SELECT HCLM_USAGE
          FROM ALZ_HCLM_INSTITUTE_INFO
          WHERE INSTITUTE_CODE = p_institute_code;
       v_hclm_usage NUMBER;
     BEGIN
          v_parameter := CUSTOMER.KOC_CLM_HLTH_UTILS.Getlookupparamvalue('HCLM_USAGE', SYSDATE);
          v_parameter := NVL(v_parameter, '1');
          IF v_parameter = '0' THEN
             OPEN c1;
             FETCH c1 INTO v_hclm_usage;
             CLOSE c1;
             v_hclm_usage := NVL(v_hclm_usage, 0);
          ELSE
             v_hclm_usage := TO_NUMBER(v_parameter);
          END IF;

         RETURN NVL(v_hclm_usage, 0);

     END getHclmUsageForInstCore;

      /*function getHclmUsage(p_Institute_Code IN NUMBER,
                           p_Claim_Id       IN NUMBER,
                           p_Ext_Reference  IN VARCHAR2,
                           p_User_Id        IN VARCHAR2,
                           p_Service_Name   IN VARCHAR2,
                           p_Hclm_Channel   IN VARCHAR2) RETURN NUMBER IS
          v_Claim_Id   NUMBER;
          v_hclm_usage NUMBER;
          v_Inst_Code  NUMBER;
          
          CURSOR crs_detail IS
             SELECT institute_code, claim_id 
               FROM koc_clm_hlth_detail
              WHERE ext_reference = p_Ext_Reference
              UNION
             SELECT institute_code, claim_id 
               FROM rep_clm_hlth_detail
              WHERE ext_reference = p_Ext_Reference;
          
          rec_detail crs_detail%ROWTYPE;
              
          CURSOR crs_version(pc_Claim_Id IN NUMBER) IS 
             SELECT hclm_usage 
               FROM alz_hclm_version_info
              WHERE claim_id = pc_Claim_Id
           ORDER BY version_no;
           
          
     BEGIN
       
         IF p_Hclm_Channel = 'HCLM_PHARMACY' THEN

              OPEN crs_detail;
              FETCH crs_detail INTO rec_detail;
              CLOSE crs_detail;
              
              v_hclm_usage := getHclmUsageForInstCore(rec_detail.institute_code);
              
              IF NVL(v_hclm_usage, 0) = 0 THEN
                
                  BEGIN
                     v_Claim_Id := TO_NUMBER(p_Ext_Reference);
                  EXCEPTION
                  WHEN OTHERS THEN
                     v_Claim_Id := NULL;
                  END;
                  
                  IF v_Claim_Id IS NOT NULL THEN
                    
                       OPEN crs_version(v_Claim_Id);
                       FETCH crs_version INTO v_hclm_usage;
                       CLOSE crs_version;  
                       
                  END IF;
                  
              END IF;
              
              RETURN NVL(v_hclm_usage, 0);
              
         END IF;       
           
         v_hclm_usage := getHclmUsageForInstCore(p_Institute_Code);
         
         IF NVL(v_hclm_usage, 0) = 0 THEN
                             
             IF p_Claim_Id IS NOT NULL THEN
               
                 v_Claim_Id := p_Claim_Id;
             
             ELSE  
               
                 IF p_Ext_Reference IS NOT NULL THEN
                   
                      OPEN crs_detail;
                      FETCH crs_detail INTO rec_detail;
                      CLOSE crs_detail; 
                      
                      v_Claim_Id := rec_detail.claim_id;  
                                                              
                 END IF;
                   
             END IF;
         
             IF v_Claim_Id IS NOT NULL THEN
               
                  OPEN crs_version(v_Claim_Id);
                  FETCH crs_version INTO v_hclm_usage;
                  CLOSE crs_version;       
                                                   
             END IF;
         
             IF NVL(v_hclm_usage, 0) = 0
             AND p_User_Id IS NOT NULL THEN                        
                  v_hclm_usage := CUSTOMER.KOC_AUTH_UTILS.is_user_authorized_rn(p_User_Id, 'HCLMPROV');              
             END IF;
             
         END IF;
         
         RETURN NVL(v_hclm_usage, 0);
         
     END getHclmUsage; */
     
      function getHclmUsage(p_Institute_Code IN NUMBER,
                           p_Claim_Id       IN NUMBER,
                           p_Ext_Reference  IN VARCHAR2,
                           p_User_Id        IN VARCHAR2,
                           p_Service_Name   IN VARCHAR2,
                           p_Hclm_Channel   IN VARCHAR2) RETURN NUMBER IS

          v_Claim_Id   NUMBER;
          v_hclm_usage NUMBER;

          CURSOR crs_detail_by_claim_id IS
             SELECT claim_id, institute_code
               FROM koc_clm_hlth_detail
              WHERE claim_id = p_Claim_Id;

          CURSOR crs_detail_by_ext_ref IS
             SELECT claim_id, institute_code
               FROM koc_clm_hlth_detail
              WHERE ext_reference = p_Ext_Reference;

          rec_detail crs_detail_by_ext_ref%ROWTYPE;

          CURSOR crs_version(pc_Claim_Id IN NUMBER) IS
             SELECT hclm_usage
               FROM alz_hclm_version_info
              WHERE claim_id = pc_Claim_Id
           ORDER BY version_no;


     BEGIN

         v_hclm_usage := getHclmUsageForInstCore(p_Institute_Code);

         IF NVL(v_hclm_usage, 0) = 0 THEN

             IF p_Claim_Id IS NOT NULL THEN

                 v_Claim_Id := p_Claim_Id;
                 
             ELSE

                 IF p_Ext_Reference IS NOT NULL THEN

                      OPEN crs_detail_by_ext_ref;
                      FETCH crs_detail_by_ext_ref INTO rec_detail;
                      CLOSE crs_detail_by_ext_ref;

                      v_Claim_Id := rec_detail.claim_id;

                 END IF;

             END IF;

             IF v_Claim_Id IS NOT NULL THEN

                  OPEN crs_version(v_Claim_Id);
                  FETCH crs_version INTO v_hclm_usage;
                  CLOSE crs_version;
                 DBMS_OUTPUT.PUT_LINE('vclaim_id='||v_claim_id||' hclm_usage='||v_hclm_usage);  
             END IF;

             IF NVL(v_hclm_usage, 0) = 0
             AND p_User_Id IS NOT NULL THEN
                  v_hclm_usage := CUSTOMER.KOC_AUTH_UTILS.is_user_authorized_rn(p_User_Id, 'HCLMPROV');
             END IF;

             IF NVL(v_hclm_usage, 0) = 0
             AND p_Hclm_Channel = 'HCLM_PHARMACY' THEN

                 OPEN crs_detail_by_claim_id;
                 FETCH crs_detail_by_claim_id INTO rec_detail;
                 CLOSE crs_detail_by_claim_id;
                 DBMS_OUTPUT.PUT_LINE('inst_code='||rec_detail.institute_code);
                 v_hclm_usage := getHclmUsageForInstCore(rec_detail.institute_code);

              END IF;
         END IF;

         RETURN NVL(v_hclm_usage, 0);

     END getHclmUsage;
       

BEGIN
    v_hclm := getHclmUsage(1150, 42821980, null, null, null, 'HCLM_PHARMACY');
    DBMS_OUTPUT.PUT_LINE(v_hclm);
END;
