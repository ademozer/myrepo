select * from alz_hltprv_log where log_id=132482592--132482579--136047047;

select * from koc_clm_suppliers_ext where institute_code='3201' for update
select * from koc_mv_skrm_suppliers where institute_skrs_code='538148';

HLTH_PROVISIONS_TABLE_TYPE;
select * from hst_cc_web_inst_doctor where doctor_name||' '||doctor_surname='EM�NE Y�KSEL KARS'
select 

select * from Koc_Cc_Hlth_Tda_Inst_Val where institute_code='3201' and discount_group_code IN('SUT-ORT','SUT-FTR') and validity_end_date is null FOR UPDATE
select * from Koc_Cc_Hlth_Tda_Proc_List where sut_code='P610820' and validity_end_date is null;

