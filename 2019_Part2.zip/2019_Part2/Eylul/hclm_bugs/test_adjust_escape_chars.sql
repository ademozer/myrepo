DECLARE
   v_text VARCHAR2(400) := 'Scotchcast OneStep Splint 10.16x38.1cm 4"x15". 3M. Ref:76415A';
   FUNCTION adjustEscapeChars(p_string IN VARCHAR2) RETURN VARCHAR2 IS
       v_string VARCHAR2(32000);
    BEGIN
        v_string := REPLACE(p_string, CHR(39), CHR(39) || CHR(39));
        v_string := REPLACE(v_string, CHR(34), CHR(92)||CHR(34));
        RETURN v_string;
    END adjustEscapeChars;
    
 BEGIN
      
    v_text := adjustEscapeChars(v_text);
    
    DBMS_OUTPUT.PUT_LINE(v_text);
    
 END;
