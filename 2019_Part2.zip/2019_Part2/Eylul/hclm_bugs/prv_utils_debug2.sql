/******************************************************************************
  Auto Generated PL/SQL call block by Bora.Demir
  **** CALL PROVISION ****
******************************************************************************/
DECLARE
  provisionReqTyp  CUSTOMER.HLTPRV_PROVISION_REQ_TYP;
  breProvisionTyp  CUSTOMER.HLTPRV_BRE_PROVISION_TYP;
  provisionRespTyp  CUSTOMER.HLTPRV_PROVISION_RESP_TYP;
  processResultTable  CUSTOMER.PROCESS_RESULT_TABLE;
 
  /*Global Variables*/
  Glbaseswiftcode   VARCHAR2(5);
    Glclaimid         Koc_Clm_Hlth_Detail.Claim_Id%TYPE;
    Glsfno            Koc_Clm_Hlth_Detail.Sf_No%TYPE;
    Glprovisiondate   Koc_Clm_Hlth_Detail.Provision_Date%TYPE;
    Glinvoicedate     Koc_Clm_Hlth_Detail.Invoice_Date%TYPE;
    Glrealizationdate Koc_Clm_Hlth_Detail.Realization_Date%TYPE;
    Gldateofloss      Koc_Clm_Hlth_Detail.Date_Of_Loss%TYPE;

    Glclaimswf      Koc_Clm_Hlth_Indem_Totals.Swift_Code%TYPE;
    Glproductid     Koc_v_Health_Insured_Info.Product_Id%TYPE;
    Glpartitiontype Koc_v_Health_Insured_Info.Partition_Type%TYPE;
    Gltermstartdate Koc_v_Health_Insured_Info.Term_Start_Date%TYPE;
    Gltermenddate   Koc_v_Health_Insured_Info.Term_End_Date%TYPE;

    Glpayclearingsystemid Koc_Oc_Prod_Partition_Rel.Pay_Clearing_System_Id%TYPE;
    Glpayswfclearsysid    Koc_Oc_Prod_Partition_Rel.Pay_Swf_Clear_Sys_Id%TYPE;
    Glpaycurrgettype      Koc_Oc_Prod_Partition_Rel.Pay_Curr_Get_Type%TYPE;
    Glpayswfcurrgettype   Koc_Oc_Prod_Partition_Rel.Pay_Swf_Curr_Get_Type%TYPE;
    Glpayexchdates        Koc_Oc_Prod_Partition_Rel.Pay_Exch_Dates%TYPE;
    Glpayswfexchdates     Koc_Oc_Prod_Partition_Rel.Pay_Swf_Exch_Dates%TYPE;
    
    v_Cover_Details   Customer.Hltprv_prov_dist_cover_tbl;
    v_Prov_Details    Customer.Hltprv_prov_dist_det_tbl;
    v_Claim_Id        NUMBER;
    v_Sf_No           NUMBER;
 
    function GetReject1612Amount(p_Detail_Type        Varchar2
                             , p_Process_Code_Main  Number
                             , p_Process_Code_Sub1  Number
                             , p_Process_Code_Sub2  Number
                             , p_Barcode            Number
                             , p_UBBCode            Varchar2
                             , p_SeqNo              Number
                             , p_Claim_Id           NUMBER
                             , p_Sf_No              NUMBER
                             , p_Add_Order_No       NUMBER
                             , p_Cover_Code         VARCHAR2) RETURN NUMBER IS
   
      CURSOR cRejectLoss IS 
       Select Sum(a.Refuse_Amount) Refuse_Amount
         from Koc_clm_hlth_reject_loss a
        where a.Claim_Id          = p_Claim_Id
          And a.Sf_No             = p_Sf_No
          And a.Add_Order_No      = p_Add_Order_No
          And a.Cover_Code        = p_Cover_Code
          And a.Seq_No            = p_SeqNo
          And Case When p_Detail_Type      = 'PROCESS' And
                        a.Process_Code_Main = p_Process_Code_Main And
                        a.Process_Code_Sub1 = p_Process_Code_Sub1 And
                        a.Process_Code_Sub2 = p_Process_Code_Sub2 And
                        a.Barcode           = 0
                    Then 1
                    When p_Detail_Type      = 'MEDICINE' And
                        a.Process_Code_Main = 0 And
                        a.Process_Code_Sub1 = 0 And
                        a.Process_Code_Sub2 = 0 And
                        a.Barcode           = p_Barcode
                    Then 1
                    When p_Detail_Type      = 'ITEM' And
                        a.Process_Code_Main = 0 And
                        a.Process_Code_Sub1 = 0 And
                        a.Process_Code_Sub2 = 0 And
                        a.ubb_code          = p_UBBCode
                    Then 1
                    Else 0
               End = 1
          And a.Main_Code = 16
          And a.Item_Code = 12;

         cRejectLossRec   cRejectLoss%Rowtype;

      Begin

         --
         Open cRejectLoss;
         Fetch  cRejectLoss Into cRejectLossRec;
         Close cRejectLoss;
         
         Return nvl(cRejectLossRec.Refuse_Amount, 0);
         
   END GetReject1612Amount;
    
   procedure DistCoverAmountsToDetails(p_ProvisionTotal NUMBER,
                                       p_NotBilledRejectAmount NUMBER,
                                       p_PatientRejectAmount NUMBER,
                                       p_Exemption_rate NUMBER) IS
         --
         v_Ind                      Pls_Integer;
         v_RndInd                   Pls_Integer;
         v_CoverProvisionAmount     Number;
         v_DetailProvisionAmount    Number;
         v_AmountRequest            Number;
         v_NotBilledRejectAmount    Number;
         v_PatientRejectAmount      Number;
         --
      Begin
        DBMS_OUTPUT.PUT_LINE('Provision_Total:'||p_ProvisionTotal);
        DBMS_OUTPUT.PUT_LINE('NotBilledReject:'||p_NotBilledRejectAmount);
        DBMS_OUTPUT.PUT_LINE('PatitentReject :'||p_PatientRejectAmount);
        --
        v_CoverProvisionAmount  := p_ProvisionTotal;
        v_NotBilledRejectAmount := Nvl(p_NotBilledRejectAmount, 0);
        v_PatientRejectAmount   := Nvl(p_PatientRejectAmount, 0);

        v_RndInd := Null;
        v_Ind    := v_Prov_Details.First;

        While v_Ind Is Not Null
        Loop          
            DBMS_OUTPUT.PUT_LINE('AmountRequest                            :'||v_Prov_Details(v_Ind).Amount_request);
            DBMS_OUTPUT.PUT_LINE('Indemnitiy_Amount(TalepTutar�)           :'||v_Prov_Details(v_Ind).Indemnity_amount);  
            DBMS_OUTPUT.PUT_LINE('Inst_Indemnitiy_Amount(KurumTalepTutar�) :'||v_Prov_Details(v_Ind).Inst_Indemnity_amount);  
            --Amount_request  (Talep edilen tutar)
            If v_Prov_Details(v_Ind).Amount_request Is Null
            Then

                If v_Prov_Details(v_Ind).Inst_indemnity_amount Is Not Null
                Then
                    v_Prov_Details(v_Ind).Amount_request := v_Prov_Details(v_Ind).Inst_indemnity_amount;
                Elsif v_Prov_Details(v_Ind).indemnity_amount is not null
                Then
                    v_Prov_Details(v_Ind).Amount_request := v_Prov_Details(v_Ind).Indemnity_amount;
                End if;

            End if;

            Case
            When v_Prov_Details(v_Ind).Indemnity_amount Is Not Null And v_Prov_Details(v_Ind).Inst_indemnity_amount Is Not Null
            Then
                Case When v_Prov_Details(v_Ind).Indemnity_amount < v_Prov_Details(v_Ind).Inst_indemnity_amount
                     Then
                        v_AmountRequest := v_Prov_Details(v_Ind).Indemnity_amount;
                     Else
                        v_AmountRequest := v_Prov_Details(v_Ind).Inst_indemnity_amount;
                End Case;
            When v_Prov_Details(v_Ind).Indemnity_amount Is Not Null And v_Prov_Details(v_Ind).Inst_indemnity_amount Is Null
            Then
                v_AmountRequest := v_Prov_Details(v_Ind).Indemnity_amount;
            When v_Prov_Details(v_Ind).Indemnity_amount Is Null And v_Prov_Details(v_Ind).Inst_indemnity_amount Is Not Null
            Then
                v_AmountRequest := v_Prov_Details(v_Ind).Inst_indemnity_amount;
            Else
                Raise_Application_Error(-20110, '��lem talep tutar� hesaplanamad�!');
            End Case;

            v_AmountRequest := v_AmountRequest * nvl(v_Prov_Details(v_Ind).count, 1);

            --teminat baz�nda ret varsa ret olmayan i�lemlere da��t
            If Nvl(v_Prov_Details(v_Ind).Status_Code, 'PP') Not In ('PR', 'R', 'C')
            Then

                If v_NotBilledRejectAmount + v_PatientRejectAmount > 0
                Then

                    --Amount_not_billed  (Hastanenin talep etmemesi gereken tutar)
                    If v_NotBilledRejectAmount > 0
                    Then

                        If v_AmountRequest >= v_NotBilledRejectAmount
                        Then
                            v_Prov_Details(v_Ind).Amount_not_billed := v_NotBilledRejectAmount;
                            v_AmountRequest         := v_AmountRequest - v_Prov_Details(v_Ind).Amount_not_billed;
                            v_NotBilledRejectAmount := 0;
                        Else
                            v_Prov_Details(v_Ind).Amount_not_billed := v_AmountRequest;
                            v_AmountRequest         := 0;
                            v_NotBilledRejectAmount := v_NotBilledRejectAmount - v_Prov_Details(v_Ind).Amount_not_billed;
                        End If;

                    End If;

                    --Amount_out_of_scope
                    If v_PatientRejectAmount > 0
                    Then

                        If v_AmountRequest >= v_PatientRejectAmount
                        Then
                            v_Prov_Details(v_Ind).Amount_out_of_scope := v_PatientRejectAmount;
                            v_AmountRequest         := v_AmountRequest - v_Prov_Details(v_Ind).Amount_out_of_scope;
                            v_PatientRejectAmount := 0;
                        Else
                            v_Prov_Details(v_Ind).Amount_out_of_scope := v_AmountRequest;
                            v_AmountRequest         := 0;
                            v_PatientRejectAmount := v_PatientRejectAmount - v_Prov_Details(v_Ind).Amount_out_of_scope;
                        End If;

                    End If;

                End If;
            End If;

            --Amount_provision  (�irket pay�)
            --Amount_exceeding (Limit a��m�)
            --Amount_participation (Sigortal� katk� pay�)
            If Nvl(v_Prov_Details(v_Ind).Status_Code, 'PP') Not In ('PR', 'R', 'C')
            Then
                --
                if v_AmountRequest > 0
                then
                    --
                    If v_CoverProvisionAmount > 0
                    Then

                        v_DetailProvisionAmount := v_AmountRequest * (1 - p_Exemption_rate);

                        If v_RndInd Is Null
                        Then
                            v_RndInd := v_Ind;
                        End if;

                        --Amount_provision
                        if v_DetailProvisionAmount <= v_CoverProvisionAmount
                        then
                            v_Prov_Details(v_Ind).Amount_provision := v_DetailProvisionAmount;
                        else
                            v_Prov_Details(v_Ind).Amount_provision := v_CoverProvisionAmount;
                        end if;

                        v_CoverProvisionAmount := v_CoverProvisionAmount - v_Prov_Details(v_Ind).Amount_provision;

                        v_Prov_Details(v_Ind).Amount_exceeding       := v_DetailProvisionAmount - v_Prov_Details(v_Ind).Amount_provision;
                        v_Prov_Details(v_Ind).Amount_participation   := v_AmountRequest * p_Exemption_rate;

                    Else

                        v_Prov_Details(v_Ind).Amount_provision       := 0;
                        v_Prov_Details(v_Ind).Amount_exceeding       := v_AmountRequest;
                        v_Prov_Details(v_Ind).Amount_participation   := 0;

                    End If;

                else
                    v_Prov_Details(v_Ind).Amount_provision       := 0;
                    v_Prov_Details(v_Ind).Amount_exceeding       := 0;
                    v_Prov_Details(v_Ind).Amount_participation   := 0;
                end if;

            Else

                v_Prov_Details(v_Ind).Amount_provision       := 0;
                v_Prov_Details(v_Ind).Amount_exceeding       := 0;
                v_Prov_Details(v_Ind).Amount_participation   := 0;

                If v_Prov_Details(v_Ind).Reject1612Amount > 0
                Then
                    v_Prov_Details(v_Ind).Amount_not_billed   := v_Prov_Details(v_Ind).Reject1612Amount;
                Else
                    v_Prov_Details(v_Ind).Amount_out_of_scope := v_AmountRequest;
                End if;

            End if;

            --Amount_sgk (SGK taraf�ndan kar��lanan tutar)
            v_Prov_Details(v_Ind).Amount_Sgk := v_Prov_Details(v_Ind).Sgk_Amount;

            --Amount_incompatible
            If v_Prov_Details(v_Ind).Inst_indemnity_amount is not null and v_Prov_Details(v_Ind).Indemnity_amount is not null
            Then
                v_Prov_Details(v_Ind).Amount_incompatible := (v_Prov_Details(v_Ind).Inst_indemnity_amount - v_Prov_Details(v_Ind).Indemnity_amount)
                                                              * nvl(v_Prov_Details(v_Ind).count, 1);
            End If;

            If v_Prov_Details(v_Ind).Amount_incompatible < 0
            Then
                v_Prov_Details(v_Ind).Amount_incompatible := 0;
            End if;

            --Amount_exemption


            -- LimitExceedingStatus = 0    : Hi� limit a��m� / kapsam d��� yoksa
            -- LimitExceedingStatus = 1    : K�smi limit a��m� / kapsam d���
            -- LimitExceedingStatus = 2    : Tam limit a��m�/ kapsam d���
            if nvl(v_Prov_Details(v_Ind).Amount_out_of_scope, 0) + nvl(v_Prov_Details(v_Ind).Amount_exceeding, 0) = 0
            then
                v_Prov_Details(v_Ind).LimitExceedingStatus := 0; --Limit a��m� ve teminat reddi yok

            elsif nvl(v_Prov_Details(v_Ind).Amount_out_of_scope, 0) + nvl(v_Prov_Details(v_Ind).Amount_exceeding, 0)
                < nvl(v_Prov_Details(v_Ind).Amount_request, 0) - (nvl(v_Prov_Details(v_Ind).Amount_incompatible, 0) + nvl(v_Prov_Details(v_Ind).Amount_not_billed, 0))
            then
                v_Prov_Details(v_Ind).LimitExceedingStatus := 1; --Limit a��m� ve teminat reddi k�smi var

            elsif nvl(v_Prov_Details(v_Ind).Amount_out_of_scope, 0) + nvl(v_Prov_Details(v_Ind).Amount_exceeding, 0)
                >= nvl(v_Prov_Details(v_Ind).Amount_request, 0) - (nvl(v_Prov_Details(v_Ind).Amount_incompatible, 0) + nvl(v_Prov_Details(v_Ind).Amount_not_billed, 0))
            then
                v_Prov_Details(v_Ind).LimitExceedingStatus := 2; --Limit a��m� ve teminat reddi tam var
            end if;


            /*
            Self.Prov_Details(v_Ind).LimitExceedingStatus := Case When Self.Prov_Details(v_Ind).Amount_exceeding = 0
                                                                  Then 0
                                                                  When Self.Prov_Details(v_Ind).Amount_exceeding > 0 And Self.Prov_Details(v_Ind).Amount_provision > 0
                                                                  Then 1
                                                                  When Self.Prov_Details(v_Ind).Amount_exceeding > 0 And Self.Prov_Details(v_Ind).Amount_participation > 0
                                                                  Then 1
                                                                  Else 2
                                                             End;
            */

            v_Ind := v_Prov_Details.Next(v_Ind);

        End loop;

        --
        If Abs(v_CoverProvisionAmount) between 0 and 1
        Then
            If v_RndInd Is Not Null
            Then
                v_Prov_Details(v_RndInd).Amount_provision := v_Prov_Details(v_RndInd).Amount_provision + v_CoverProvisionAmount;
            End if;
        Else
            Raise_Application_Error(-20110, 'Detaylara da��t�lamam�� provizyon tutar� var! ('||v_CoverProvisionAmount||')');
        End if;
         --
      End DistCoverAmountsToDetails;
      
   PROCEDURE Finddoctor(Pinstitutecode    IN NUMBER,
                         Pspecialtysubject IN VARCHAR2,
                         Pnamesurname      IN VARCHAR2,
                         Pidentityno       IN VARCHAR2,
                         Prequestsystem    IN VARCHAR2,
                         Pdoctor           OUT Koc_Cc_Web_Inst_Doctor%ROWTYPE) IS

  CURSOR Crdoctorbyidentity_Mnw IS
    SELECT *
      FROM Koc_Cc_Web_Inst_Doctor
     WHERE Institute_Code       = Pinstitutecode
       AND Specialty_Subject    = Pspecialtysubject
       AND Doctor_Identity_No   = Pidentityno
       AND Pidentityno          IS NOT NULL
       AND Validity_End_Date    IS NULL;

  CURSOR Crdoctorbynamesurname IS
    SELECT *
      FROM Koc_Cc_Web_Inst_Doctor
     WHERE Institute_Code      = Pinstitutecode
       AND Specialty_Subject   = Pspecialtysubject
       AND Nls_Upper(Doctor_Name || ' ' || Doctor_Surname, 'nls_sort=xturkish') = Nls_Upper(Pnamesurname, 'nls_sort=xturkish')
       AND Pnamesurname IS NOT NULL
       AND Validity_End_Date IS NULL
    UNION ALL
    SELECT *
      FROM Hst_Cc_Web_Inst_Doctor
     WHERE Institute_Code    = Pinstitutecode
       AND Specialty_Subject = Pspecialtysubject
       AND Nls_Upper(Doctor_Name || ' ' || Doctor_Surname, 'nls_sort=xturkish') = Nls_Upper(Pnamesurname, 'nls_sort=xturkish')
       AND Pnamesurname      IS NOT NULL
       AND Validity_End_Date IS NULL
       AND Doctor_Source     NOT IN ('PORTAL');

      Vdoctor Koc_Cc_Web_Inst_Doctor%ROWTYPE;
      v_Errmsg VARCHAR2(500) := NULL;
    BEGIN
      IF Pidentityno IS NULL AND Pspecialtysubject IS NULL AND
         Pnamesurname IS NULL THEN
        RETURN;
      ELSIF Vdoctor.Doctor_Code IS NULL THEN

        OPEN Crdoctorbyidentity_Mnw;
        FETCH Crdoctorbyidentity_Mnw
          INTO Vdoctor;
        CLOSE Crdoctorbyidentity_Mnw;

         IF Vdoctor.Doctor_Code IS NULL THEN

          OPEN Crdoctorbynamesurname;
          FETCH Crdoctorbynamesurname
            INTO Vdoctor;
          CLOSE Crdoctorbynamesurname;
         END IF;

      END IF;

      IF Vdoctor.Doctor_Code IS NULL THEN
        RETURN; --doktor kimlik no tan�ml� de�il
      END IF;

    Pdoctor := Vdoctor;
    END finddoctor;
   FUNCTION Iscoverexists(Pclaimid       Koc_Clm_Hlth_Detail.Claim_Id%TYPE,
                                                 Psfno          Koc_Clm_Hlth_Detail.Sf_No%TYPE,
                                                 Paddorderno    Koc_Clm_Hlth_Detail.Add_Order_No%TYPE,
                                                 Plocation      Koc_Clm_Hlth_Detail.Web_Location_Code%TYPE,
                                                 Pcovercode     Koc_Clm_Hlth_Provisions.Cover_Code%TYPE,
                                                 Phlthprovision Customer.Hlth_Provisions_Table_Type) RETURN NUMBER IS
        Vcnt NUMBER;
    BEGIN
        SELECT COUNT(1)
            INTO Vcnt
            FROM TABLE(Phlthprovision)
         WHERE Claim_Id = Pclaimid
             AND Sf_No = Psfno
             AND Add_Order_No = Paddorderno
             AND Location_Code = Plocation
             AND Cover_Code = Pcovercode;

        --
        IF Vcnt = 0
        THEN
            RETURN 0;
        ELSE
            RETURN 1;
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN 0;
    END;
    PROCEDURE Insertnotmatch(Phlthdetail IN Customer.Hlth_Detail_Row_Type,
                                                     Phlthproc   IN OUT Customer.Hlth_Proc_Detail_Row_Type) IS
        --
        v_Seq_No Koc_Clm_Web_Notmatch_Proc.Seq_No%TYPE;
        --
    BEGIN
        --

        --
        IF Phlthproc.Covermatchstatus = 'NOT_MATCHED'
        THEN
            --
            v_Seq_No := Nvl(Phlthproc.Seq_No, 1);

            --
            WHILE 1 = 1
            LOOP
                BEGIN
                    --
                    ALZ_HLTPRV_UTILS.Insertsurgery(Phlthdetail, Phlthproc.Procsurgery);

                    --
                    INSERT INTO Koc_Clm_Web_Notmatch_Proc
                        (Claim_Id,
                         Instance_Id,
                         Process_Code_Main,
                         Process_Code_Sub1,
                         Process_Code_Sub2,
                         Is_Completed,
                         Is_Aborted,
                         Cover_Code,
                         Indemnity_Amount,
                         Inst_Indemnity_Amount,
                         Location_Code,
                         Userid,
                         Process_Count,
                         Drg_Code,
                         Doctor_Code,
                         Doctor_Status,
                         Sgk_Amount,
                         Order_No,
                         Vat_Rate,
                         Right_Left,
                         Proc_Type,
                         Physiotherapy_Session,
                         Diagnosis_Id,
                         Surgery_Id,
                         Time_Stamp,
                         Seq_No,
                         Bre_Result_Code,
                         Req_Process_Name,
                         Req_Process_Code,
                         Req_Process_List_Type,
                         Related_Process,
                         Related_Process_List_Type,
                         process_date)
                    VALUES
                        (Phlthdetail.Claim_Id,
                         '999999',
                         Phlthproc.Process_Code_Main,
                         Phlthproc.Process_Code_Sub1,
                         Phlthproc.Process_Code_Sub2,
                         NULL,
                         NULL,
                         NULL,
                         Round(Phlthproc.Indemnity_Amount, 2),
                         Round(Phlthproc.Inst_Indemnity_Amount, 2),
                         Phlthproc.Location_Code,
                         Phlthproc.Userid,
                         Phlthproc.Process_Count,
                         Phlthproc.Drg_Code,
                         Phlthproc.Doctor_Code,
                         Phlthproc.Doctor_Status,
                         Phlthproc.Sgk_Amount,
                         Phlthproc.Order_No,
                         Phlthproc.Vat_Rate,
                         Phlthproc.Right_Left,
                         Phlthproc.Proc_Type,
                         Phlthproc.Physiotherapy_Session,
                         Phlthproc.Diagnosis_Id,
                         Phlthproc.Procsurgery.Surgery_Id,
                         --Phlthproc.Surgery_Id,
                         Phlthproc.Time_Stamp,
                         v_Seq_No,
                         Phlthproc.Breresultcode,
                         Phlthproc.Req_Process_Name,
                         Phlthproc.Req_Process_Code,
                         Phlthproc.Req_Process_List_Type,
                         Phlthproc.Related_Process,
                         Phlthproc.Related_Process_List_Type,
                         Phlthproc.process_date
                         );

                    EXIT;
                EXCEPTION
                    WHEN Dup_Val_On_Index THEN
                        --
                        v_Seq_No := Nvl(v_Seq_No, 0) + 1;
                        --
                END;
            END LOOP;
        END IF;
    END;
    FUNCTION Ischemoteraphymedicine(Pbarcode Koc_Cc_Medicines.Barcode%TYPE,
                                                                    Pdate    DATE) RETURN NUMBER IS
        Vmedgroup Koc_Cc_Med_Groups_Rel.Med_Group_Code%TYPE;
        --
    BEGIN
        SELECT b.Med_Group_Code
            INTO Vmedgroup
            FROM Koc_Cc_Medicines      a,
                     Koc_Cc_Med_Groups_Rel b
         WHERE a.Barcode = Pbarcode
             AND a.Validity_Date = (SELECT MAX(Validity_Date) FROM Koc_Cc_Medicines x WHERE x.Barcode = a.Barcode)
             AND b.Barcode = a.Barcode
             AND b.Validity_Start_Date <= Trunc(Pdate)
             AND (b.Validity_End_Date >= Trunc(Pdate) OR b.Validity_End_Date IS NULL)
             AND b.Med_Group_Code = 'KEMOTERAPI';

        RETURN 1;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN 0;
    END;
    FUNCTION Findmedicinecover(Pcontractid    IN Koc_Clm_Hlth_Indem_Totals.Contract_Id%TYPE,
                                                         Ppartitionno   IN Koc_Clm_Hlth_Indem_Totals.Partition_No%TYPE,
                                                         Pclaiminsttype IN Koc_Clm_Hlth_Indem_Totals.Claim_Inst_Type%TYPE,
                                                         Pclaiminstloc  IN Koc_Clm_Hlth_Indem_Totals.Claim_Inst_Loc%TYPE,
                                                         Pcountrygroup  IN Koc_Clm_Hlth_Indem_Totals.Country_Group%TYPE,
                                                         Plocationcode  IN Koc_Clm_Hlth_Detail.Web_Location_Code%TYPE,
                                                         Pbarcode       IN Koc_Cc_Medicines.Barcode%TYPE,
                                                         Pdate          IN DATE,
                                                         Phlthprovision IN Customer.Hlth_Provisions_Table_Type,
                                                         Pcomplementary IN Koc_Clm_Hlth_Detail.Is_Complementary%TYPE) RETURN VARCHAR2 IS
        CURSOR Crmedcovers IS
            SELECT c.Cover_Code
                FROM Koc_Cc_Medicines          b,
                         Koc_Cc_Medicine_Cover_Rel c
             WHERE b.Barcode = Pbarcode
                 AND b.Barcode = c.Barcode
                 AND c.Validity_Start_Date <= Trunc(Pdate)
                 AND (c.Validity_End_Date >= Trunc(Pdate) OR c.Validity_End_Date IS NULL)
                 AND b.Validity_Date = (SELECT MAX(M1.Validity_Date)
                                                                    FROM Koc_Cc_Medicines M1
                                                                 WHERE M1.Barcode = b.Barcode
                                                                     AND M1.Validity_Date <= Trunc(Pdate));

        CURSOR Crmedpolicycover IS
        --SELECT d.Cover_Code, u.PHARMACY_PRIORITY
            SELECT d.Cover_Code,
                         u.Priority
                FROM Koc_Clm_Hlth_Indem_Totals      d,
                         Koc_Oc_Cover_Definitions       r,
                         Koc_Cc_Hlth_Loc_Cover_Priority u,
                         Koc_Cc_Medicines               b,
                         Koc_Cc_Medicine_Cover_Rel      c
             WHERE d.Contract_Id = Pcontractid
                 AND d.Partition_No = Ppartitionno
                 AND d.Claim_Inst_Type = Pclaiminsttype
                 AND d.Claim_Inst_Loc = Pclaiminstloc
                 AND d.Main_Or_Sub_Cov = 'ALT'
                 AND Nvl(d.Is_Valid, 0) = 1
                 AND d.Validity_Start_Date <= Trunc(Pdate)
                 AND d.Validity_End_Date >= Trunc(Pdate)
                 AND r.Cover_Code = d.Cover_Code
                 AND r.Validity_Start_Date <= Trunc(Pdate)
                 AND (r.Validity_End_Date >= Trunc(Pdate) OR r.Validity_End_Date IS NULL)
                 AND u.Web_Cover_Grp_Code = r.Web_Cover_Grp_Code
                 AND u.Validity_Start_Date <= Trunc(Pdate)
                 AND (u.Validity_End_Date >= Trunc(Pdate) OR u.Validity_End_Date IS NULL)
                 AND u.Location_Code = Plocationcode
                 AND d.Country_Group = Nvl(Pcountrygroup, 0)
                 AND b.Barcode = Pbarcode
                 AND b.Validity_Date = (SELECT MAX(M1.Validity_Date)
                                                                    FROM Koc_Cc_Medicines M1
                                                                 WHERE M1.Barcode = b.Barcode
                                                                     AND M1.Validity_Date <= Trunc(Pdate))
                 AND b.Barcode = c.Barcode
                 AND c.Validity_Start_Date <= Trunc(Pdate)
                 AND (c.Validity_End_Date >= Trunc(Pdate) OR c.Validity_End_Date IS NULL)
                 AND d.Cover_Code = c.Cover_Code
                 AND ((Pcomplementary = 1 AND d.Cover_Code LIKE 'ST%') OR Pcomplementary = 0) --TYH-60565
            --ORDER BY u.PHARMACY_PRIORITY desc NULLS LAST;--MYALINKILIC PRIORTY TASK
             ORDER BY u.Priority NULLS LAST;

        Vmedcover Koc_Clm_Hlth_Provisions.Cover_Code%TYPE;
        Vpriority Koc_Cc_Hlth_Loc_Cover_Priority.Priority%TYPE;
    BEGIN
        --
        IF Phlthprovision IS NOT NULL
        THEN
            IF Phlthprovision.First IS NOT NULL
            THEN
                FOR Rcovers IN Crmedcovers
                LOOP
                    FOR i IN 1 .. Phlthprovision.Count
                    LOOP
                        --
                        IF Rcovers.Cover_Code = Phlthprovision(i).Cover_Code
                        THEN
                            Vmedcover := Phlthprovision(i).Cover_Code;
                            EXIT;
                        END IF;
                    END LOOP;
                END LOOP;
            END IF;
        END IF;

        --
        IF Vmedcover IS NULL
        THEN
            OPEN Crmedpolicycover;

            FETCH Crmedpolicycover
                INTO Vmedcover,
                         Vpriority;

            CLOSE Crmedpolicycover;
        END IF;

        RETURN Vmedcover;
    END;

     PROCEDURE Findpreferredcoverforitem(Ploccode        NUMBER,
                                                                            Pdate           DATE,
                                                                            Phlthprovision  Hlth_Provisions_Table_Type,
                                                                            Phlthdetail     IN Customer.Hlth_Detail_Row_Type,
                                                                            Pcovercode      OUT VARCHAR2,
                                                                            Pispoolcover    OUT VARCHAR2,
                                                                            Pisspecialcover OUT VARCHAR2,
                                                                            Pswiftcode      OUT VARCHAR2,
                                                                            Pfdayseance     OUT VARCHAR2) IS
        CURSOR Crpolicycover IS
        --           SELECT DISTINCT A3.Cover_Code, A1.MATERIAL_PRIORITY
        --             FROM Koc_Cc_Hlth_Loc_Cover_Priority A1,
        --                  Koc_Oc_Cover_Definitions A2,
        --                  TABLE (Phlthprovision) A3
        --            WHERE     A1.Location_Code = Ploccode
        --                  AND A1.Validity_Start_Date <= Pdate
        --                  AND (   A1.Validity_End_Date >= Pdate
        --                       OR A1.Validity_End_Date IS NULL)
        --                  AND A1.Web_Cover_Grp_Code = A2.Web_Cover_Grp_Code
        --                  AND A2.Validity_Start_Date <= Pdate
        --                  AND (   A2.Validity_End_Date >= Pdate
        --                       OR A2.Validity_End_Date IS NULL)
        --                  AND A2.Cover_Code = A3.Cover_Code
        --                  AND A3.Location_Code = Ploccode
        --         ORDER BY A1.material_Priority desc;--A1.Priority;
            SELECT Cd.Cover_Code,
                         Nvl(Cit.Is_Pool_Cover, 0) Is_Pool_Cover,
                         Nvl(Cit.Is_Special_Cover, 0) Is_Special_Cover,
                         Cit.Swift_Code,
                         Cit.f_Day_Seance
                FROM Koc_Clm_Hlth_Indem_Totals      Cit,
                         Koc_Oc_Cover_Definitions       Cd,
                         Koc_Cc_Hlth_Loc_Cover_Priority Lcp
             WHERE Cit.Contract_Id = Phlthdetail.Contract_Id
                 AND Cit.Partition_No = Phlthdetail.Oar_No
                 AND Cit.Cover_Code = Cd.Cover_Code
                 AND Cd.Web_Cover_Grp_Code = Lcp.Web_Cover_Grp_Code
                 AND Lcp.Location_Code = Ploccode
                 AND Cit.Is_Valid = '1'
                 AND Main_Or_Sub_Cov = 'ALT'
                 AND Pdate BETWEEN Cit.Validity_Start_Date AND Cit.Validity_End_Date
                 AND Pdate BETWEEN Lcp.Validity_Start_Date AND Nvl(Lcp.Validity_End_Date, Pdate)
            --   and cit.claim_inst_type=Phlthdetail.claim_inst_type
                 AND    ((Phlthdetail.Iscomplementary = 1 AND Cit.Cover_Code LIKE 'ST%') OR Phlthdetail.Iscomplementary = 0) --TYH-60565
             ORDER BY Lcp.Material_Priority DESC;

        Rpolcover Crpolicycover%ROWTYPE;
    BEGIN
        --i�lemler ve ila�lar ile e�le�en teminatlar aras�nda prioritysi en y�ksek olan bulunur
        --poli�ede tan�ml� olan teminatlar�n web_cover_grp_code tan�mlar� koc_cc_hlth_loc_cover_item tan�m tablosunda priority e g�re �ekiliyor

        OPEN Crpolicycover;

        FETCH Crpolicycover
            INTO Rpolcover;

        CLOSE Crpolicycover;

        Pcovercode      := Rpolcover.Cover_Code;
        Pispoolcover    := Rpolcover.Is_Pool_Cover;
        Pisspecialcover := Rpolcover.Is_Special_Cover;
        Pswiftcode      := Rpolcover.Swift_Code;
        Pfdayseance     := Rpolcover.f_Day_Seance;
    END Findpreferredcoverforitem;

     PROCEDURE Choosecoverforitem(Phlthdetail    IN Customer.Hlth_Detail_Row_Type,
                                                             Phlthitem      IN OUT Customer.Hltprv_Dml_Item_Tbl,
                                                             Phlthproc      IN Customer.Hlth_Proc_Detail_Table_Type,
                                                             Pinstituteinfo IN Koc_v_Clm_Suppliers%ROWTYPE,
                                                             Phlthprovision IN OUT Customer.Hlth_Provisions_Table_Type

                                                             --      Phlthbre         IN     Customer.Hltprv_Bre_Provision_Typ
                                                             ) IS
        CURSOR Critemcovers(Pcontractid    NUMBER,
                                                Ppartitionno   NUMBER,
                                                Pdate          DATE,
                                                Pclaiminsttype VARCHAR2,
                                                Pclaiminstloc  VARCHAR2,
                                                Pcountrygroup  NUMBER,
                                                piscomplementary NUMBER DEFAULT 0 ) IS
            SELECT DISTINCT Nvl(d.Is_Pool_Cover, 0) Is_Pool_Cover,
                                            Nvl(d.Is_Special_Cover, 0) Is_Special_Cover,
                                            d.Swift_Code,
                                            d.f_Day_Seance,
                                            d.Cover_Code
                FROM Koc_Clm_Hlth_Indem_Totals d,
                         Koc_Oc_Cover_Definitions  r
             WHERE d.Contract_Id = Pcontractid
                 AND d.Partition_No = Ppartitionno
                 AND d.Claim_Inst_Type = Pclaiminsttype
                 AND d.Claim_Inst_Loc = Pclaiminstloc
                 AND d.Main_Or_Sub_Cov = 'ALT'
                 AND Nvl(d.Is_Valid, 0) = 1
                 AND d.Validity_Start_Date <= Pdate
                 AND d.Validity_End_Date >= Pdate
                 AND r.Web_Cover_Grp_Code = 'S685'
                 AND r.Cover_Code = d.Cover_Code
                 AND r.Validity_Start_Date <= Pdate
                 AND (r.Validity_End_Date >= Pdate OR r.Validity_End_Date IS NULL)
                 AND d.Country_Group = Nvl(Pcountrygroup, 0)
                 AND ((piscomplementary = 1 AND d.cover_code LIKE 'ST%') OR piscomplementary = 0  );

        Ritemcov        Critemcovers%ROWTYPE;
        Vcnt            NUMBER;
        Vcovercode      VARCHAR2(10);
        Vispoolcover    VARCHAR2(10);
        Visspecialcover VARCHAR2(10);
        Vswiftcode      VARCHAR2(10);
        Vdayseance      VARCHAR2(10);

    BEGIN
        --Malzeme - teminat ili�kisi �ncesi i�lem teminatlar�n�n �al��mas� gerekir.
        --��lemlerde elde edilen teminatlar kullan�lacak

        IF Phlthitem IS NULL
        THEN
            RETURN;
        END IF;

        IF Phlthitem.First IS NULL
        THEN
            RETURN;
        END IF;

        --Belirlenen s�raya g�re teminatlar i�inde uygun teminat� ar�yoruz
        --
        IF Phlthprovision IS NOT NULL
        THEN
            Findpreferredcoverforitem(Phlthdetail.Location_Code, Phlthdetail.Provision_Date, Phlthprovision, Phlthdetail, Vcovercode, Vispoolcover,
                                                                Visspecialcover, Vswiftcode, Vdayseance);

        END IF;

        --
        IF Vcovercode IS NOT NULL
        THEN
            --
            FOR i IN 1 .. Phlthitem.Count
            LOOP
                --
                IF Phlthitem(i).Cover_Code IS NULL
                THEN
                    Phlthitem(i).Cover_Code := Vcovercode;
                END IF;
            END LOOP;

            IF Iscoverexists(Phlthdetail.Claim_Id, Phlthdetail.Sf_No, 1, Phlthdetail.Location_Code, Vcovercode, Phlthprovision) = 0
            THEN
                Phlthprovision.Extend;
                Phlthprovision(Phlthprovision.Last) := Customer.Hlth_Provisions_Row_Type(Phlthdetail.Claim_Id, Phlthdetail.Sf_No, Phlthdetail.Location_Code,
                                                                                                                                                                 Vcovercode, Vswiftcode, NULL, Phlthdetail.Provision_User_Id, SYSDATE,
                                                                                                                                                                 NULL, NULL, 1, Vispoolcover, Visspecialcover, SYSDATE, Vdayseance,
                                                                                                                                                                 NULL, NULL);
            END IF;

        ELSE
            --��lem tablosu dolu ise ve hi�bir teminat se�ilememi� ise
            --29 ODN ile e�le�meyen i�lemler ekran�na d��er

            --Bu ekrandan i�lemler i�in se�ilen teminatlar aras�ndan �nceli�i y�ksek olan
            --malzemeler i�in atan�r.
            IF Phlthproc IS NOT NULL AND
                 Phlthproc.First IS NOT NULL
            THEN
                FOR i IN 1 .. Phlthitem.Count
                LOOP
                    --
                    IF Phlthitem(i).Cover_Code IS NULL
                    THEN
                        Phlthitem(i).Cover_Code := '0';
                    END IF;
                END LOOP;

                RETURN;
            END IF;

            --Talepte herhangi bir i�lem yok ise
            --Malzemeleri malzeme teminat�na y�nlendir
            Ritemcov := NULL;

            OPEN Critemcovers(Phlthdetail.Contract_Id, Phlthdetail.Oar_No, Phlthdetail.Provision_Date, Pinstituteinfo.Claim_Inst_Type,
                                                Pinstituteinfo.Claim_Inst_Loc, NULL,Phlthdetail.Iscomplementary);

            FETCH Critemcovers
                INTO Ritemcov;

            CLOSE Critemcovers;

            --
            IF Ritemcov.Cover_Code IS NOT NULL
            THEN
                FOR i IN 1 .. Phlthitem.Count
                LOOP
                    IF Phlthitem(i).Cover_Code IS NULL
                    THEN
                        Phlthitem(i).Cover_Code := Ritemcov.Cover_Code;
                    END IF;
                END LOOP;

                --
                IF Ritemcov.Cover_Code IS NOT NULL
                THEN
                    IF Iscoverexists(Phlthdetail.Claim_Id, Phlthdetail.Sf_No, 1, Phlthdetail.Location_Code, Ritemcov.Cover_Code, Phlthprovision) = 0
                    THEN
                        Phlthprovision.Extend;
                        Phlthprovision(Phlthprovision.Last) := Hlth_Provisions_Row_Type(Phlthdetail.Claim_Id, Phlthdetail.Sf_No, Phlthdetail.Location_Code,
                                                                                                                                                        Ritemcov.Cover_Code, Ritemcov.Swift_Code, NULL,
                                                                                                                                                        Phlthdetail.Provision_User_Id, SYSDATE, NULL, NULL, 1,
                                                                                                                                                        Ritemcov.Is_Pool_Cover, Ritemcov.Is_Special_Cover, SYSDATE,
                                                                                                                                                        Ritemcov.f_Day_Seance, NULL, NULL);
                    END IF;
                END IF;
            END IF;
        END IF;
    END;
 PROCEDURE Findpreferredcoverformed(Ploccode       NUMBER,
                                                                         Pdate          DATE,
                                                                         Phlthprovision Hlth_Provisions_Table_Type,
                                                                         piscomplementary NUMBER DEFAULT 0 ,
                                                                         Pcovercode     OUT VARCHAR2) IS
        CURSOR Crpolicycover IS
            SELECT DISTINCT A3.Cover_Code,
                                            A1.Pharmacy_Priority
                FROM Koc_Cc_Hlth_Loc_Cover_Priority A1,
                         Koc_Oc_Cover_Definitions A2,
                         TABLE(Phlthprovision) A3
             WHERE A1.Location_Code = Ploccode
                 AND A1.Validity_Start_Date <= Pdate
                 AND (A1.Validity_End_Date >= Pdate OR A1.Validity_End_Date IS NULL)
                 AND A1.Web_Cover_Grp_Code = A2.Web_Cover_Grp_Code
                 AND A2.Validity_Start_Date <= Pdate
                 AND (A2.Validity_End_Date >= Pdate OR A2.Validity_End_Date IS NULL)
                 AND A2.Cover_Code = A3.Cover_Code
                 AND A3.Location_Code = Ploccode
                 AND    ((piscomplementary = 1 AND A3.Cover_Code LIKE 'ST%') OR piscomplementary = 0) --TYH-60565
             ORDER BY A1.Pharmacy_Priority DESC; --A1.Priority;

        Rpolcover Crpolicycover%ROWTYPE;
    BEGIN
        --i�lemler ve ila�lar ile e�le�en teminatlar aras�nda prioritysi en y�ksek olan bulunur
        --poli�ede tan�ml� olan teminatlar�n web_cover_grp_code tan�mlar� koc_cc_hlth_loc_cover_item tan�m tablosunda priority e g�re �ekiliyor

        OPEN Crpolicycover;

        FETCH Crpolicycover
            INTO Rpolcover;

        CLOSE Crpolicycover;

        Pcovercode := Rpolcover.Cover_Code;
    END Findpreferredcoverformed;

     PROCEDURE Choosecoverformedicine(Phlthdetail    IN Customer.Hlth_Detail_Row_Type,
                                                                     Phlthmedicine  IN OUT Customer.Medicine_Indem_Det_Table_Type,
                                                                     Pinstituteinfo IN Koc_v_Clm_Suppliers%ROWTYPE,
                                                                     Phlthprovision IN OUT Customer.Hlth_Provisions_Table_Type) IS

       CURSOR crulakcovers (pPhlthprovision  Customer.Hlth_Provisions_Table_Type) IS
       SELECT a.cover_code FROM TABLE(pPhlthprovision) a
         WHERE a.cover_code LIKE 'ST%';

        CURSOR Crpolicycovers(Pcontractid    NUMBER,
                                                    Ppartitionno   NUMBER,
                                                    Pdate          DATE,
                                                    Pclaiminsttype VARCHAR2,
                                                    Pclaiminstloc  VARCHAR2,
                                                    Pcountrygroup  NUMBER,
                                                    Pbarcode       NUMBER) IS
            SELECT DISTINCT Nvl(d.Is_Pool_Cover, 0) Is_Pool_Cover,
                                            Nvl(d.Is_Special_Cover, 0) Is_Special_Cover,
                                            d.Swift_Code,
                                            d.f_Day_Seance,
                                            d.Cover_Code
                FROM Koc_Clm_Hlth_Indem_Totals d,
                         Koc_Oc_Cover_Definitions  r
             WHERE d.Contract_Id = Pcontractid
                 AND d.Partition_No = Ppartitionno
                 AND d.Claim_Inst_Type = Pclaiminsttype
                 AND d.Claim_Inst_Loc = Pclaiminstloc
                 AND ((Phlthdetail.Iscomplementary = 1 AND d.Cover_Code LIKE 'ST%') OR Phlthdetail.Iscomplementary = 0) --TYH-60565
                 AND d.Main_Or_Sub_Cov = 'ALT'
                 AND Nvl(d.Is_Valid, 0) = 1
                 AND d.Validity_Start_Date <= Pdate
                 AND d.Validity_End_Date >= Pdate
                 AND r.Cover_Code = d.Cover_Code
                 AND r.Validity_Start_Date <= Pdate
                 AND (r.Validity_End_Date >= Pdate OR r.Validity_End_Date IS NULL)
                 AND d.Country_Group = Nvl(Pcountrygroup, 0)
                 AND d.Cover_Code IN (SELECT c.Cover_Code
                                                                FROM Koc_Cc_Medicines          b,
                                                                         Koc_Cc_Medicine_Cover_Rel c
                                                             WHERE b.Barcode = Pbarcode
                                                                 AND b.Barcode = c.Barcode
                                                                 AND c.Validity_Start_Date <= Pdate
                                                                 AND (c.Validity_End_Date >= Pdate OR c.Validity_End_Date IS NULL)
                                                                 AND b.Validity_Date = (SELECT MAX(M1.Validity_Date)
                                                                                                                    FROM Koc_Cc_Medicines M1
                                                                                                                 WHERE M1.Barcode = b.Barcode
                                                                                                                     AND M1.Validity_Date <= Pdate));

        CURSOR Crmedcover(Pcontractid    NUMBER,
                                            Ppartitionno   NUMBER,
                                            Pdate          DATE,
                                            Pclaiminsttype VARCHAR2,
                                            Pclaiminstloc  VARCHAR2,
                                            Pcountrygroup  NUMBER,
                                            Plocationcode  NUMBER) IS
            SELECT d.Cover_Code
                FROM Koc_Clm_Hlth_Indem_Totals      d,
                         Koc_Oc_Cover_Definitions       r,
                         Koc_Cc_Hlth_Loc_Cover_Priority x
             WHERE d.Contract_Id = Pcontractid
                 AND d.Partition_No = Ppartitionno
                 AND d.Claim_Inst_Type = Pclaiminsttype
                 AND d.Claim_Inst_Loc = Pclaiminstloc
                 AND d.Main_Or_Sub_Cov = 'ALT'
                 AND Nvl(d.Is_Valid, 0) = 1
                 AND d.Validity_Start_Date <= Pdate
                 AND Nvl(d.Validity_End_Date, Pdate) >= Pdate
                 AND r.Cover_Code = d.Cover_Code
                 AND r.Validity_Start_Date <= Pdate
                 AND Nvl(r.Validity_End_Date, Pdate) >= Pdate
                 AND d.Country_Group = Nvl(Pcountrygroup, 0)
                 AND d.Is_Pharmacy_Cover = 1
                 AND r.Web_Cover_Grp_Code = x.Web_Cover_Grp_Code
                 AND x.Location_Code = Plocationcode
                 AND x.Validity_Start_Date <= Pdate
                 AND Nvl(x.Validity_End_Date, Pdate) >= Pdate
                 AND ((Phlthdetail.Iscomplementary = 1 AND d.Cover_Code LIKE 'ST%') OR Phlthdetail.Iscomplementary = 0) --TYH-60565
             ORDER BY x.Pharmacy_Priority DESC; --x.Priority;--MYALINKILIC PRIORITY TASK

        CURSOR Cranymedcover(Ploccode       Koc_Clm_Hlth_Detail.Web_Location_Code%TYPE,
                                                 Pdate          DATE,
                                                 Pclaiminsttype VARCHAR2,
                                                 Pcontractid    NUMBER,
                                                 Ppartitionno   NUMBER,
                                                 Pclaiminstloc  VARCHAR2) IS
        /*         SELECT Cover_Code
                              FROM (  SELECT DISTINCT a.Cover_Code, c.Priority
                                        FROM Koc_Cc_Medicine_Cover_Rel a,
                                             Koc_Oc_Cover_Definitions b,
                                             Koc_Cc_Hlth_Loc_Cover_Priority c
                                       WHERE     a.Cover_Code = b.Cover_Code
                                             AND a.Validity_Start_Date <= Pdate
                                             AND (   a.Validity_End_Date >= Pdate
                                                  OR a.Validity_End_Date IS NULL)
                                             AND b.Validity_Start_Date <= Pdate
                                             AND (   b.Validity_End_Date >= Pdate
                                                  OR b.Validity_End_Date IS NULL)
                                             AND NVL (b.Is_Pharmacy_Cover, 0) = 1
                                             AND b.Web_Cover_Grp_Code = c.Web_Cover_Grp_Code
                                             AND c.Location_Code = Ploccode
                                             AND b.Web_Cover_Grp_Code IS NOT NULL
                                    ORDER BY c.Priority);*/
          /*  SELECT Cover_Code
                FROM (SELECT Cover_Code
                                FROM (SELECT a.Cover_Code
                                                FROM Koc_Cc_Medicine_Cover_Rel a,
                                                         Koc_Oc_Cover_Definitions  b
                                             WHERE a.Cover_Code = b.Cover_Code
                                                 AND a.Validity_Start_Date <= Pdate
                                                 AND (a.Validity_End_Date >= Pdate OR a.Validity_End_Date IS NULL)
                                                 AND b.Validity_Start_Date <= Pdate
                                                 AND (b.Validity_End_Date >= Pdate OR b.Validity_End_Date IS NULL)
                                                 AND Nvl(b.Is_Pharmacy_Cover, 0) = 1
                                                        --  AND b.Web_Cover_Grp_Code = c.Web_Cover_Grp_Code
                                                        --  AND c.Location_Code = Ploccode
                                                 AND b.Web_Cover_Grp_Code IS NOT NULL
                                                 AND Phlthdetail.Iscomplementary = 0 --TYH-60565
                                            UNION --TYH-60565
                                            SELECT d.Cover_Code
                                            --, c.Priority
                                                FROM Koc_Oc_Cover_Definitions b,
                                                         --Koc_Cc_Hlth_Loc_Cover_Priority c,
                                                         Koc_Clm_Hlth_Indem_Totals d
                                             WHERE 1 = 1
                                                 AND d.Contract_Id = Pcontractid
                                                 AND d.Partition_No = Ppartitionno
                                                 AND d.Claim_Inst_Type = Pclaiminsttype
                                                 AND d.Claim_Inst_Loc = Pclaiminstloc
                                                 AND d.Main_Or_Sub_Cov = 'ALT'
                                                 AND Nvl(d.Is_Valid, 0) = 1
                                                 AND d.Validity_Start_Date <= Pdate
                                                 AND Nvl(d.Validity_End_Date, Pdate) >= Pdate
                                                 AND d.Cover_Code = b.Cover_Code
                                                 AND Phlthdetail.Iscomplementary = 1
                                                 AND b.Validity_Start_Date <= Pdate
                                                 AND (b.Validity_End_Date >= Pdate OR b.Validity_End_Date IS NULL)
                                                        -- AND b.Web_Cover_Grp_Code = c.Web_Cover_Grp_Code
                                                        -- AND c.Location_Code = Ploccode
                                                 AND b.Web_Cover_Grp_Code IS NOT NULL) --ORDER BY  Priority
                            ); */
      -- order by'daki teminatlar�n secilmesi icin cursor degistirildi,, oncesinde kemoterapiteminat� S188 geliyordu  SBH-78 omert
      SELECT d.Cover_Code
        FROM Koc_Oc_Cover_Definitions b,
             Koc_Clm_Hlth_Indem_Totals d
       WHERE 1 = 1
         AND d.Contract_Id = Pcontractid
         AND d.Partition_No = Ppartitionno
         AND d.Claim_Inst_Type = Pclaiminsttype
         AND d.Claim_Inst_Loc = Pclaiminstloc
         AND d.Main_Or_Sub_Cov = 'ALT'
         AND Nvl(d.Is_Valid, 0) = 1
         AND d.Validity_Start_Date <= Pdate
         AND Nvl(d.Validity_End_Date, Pdate) >= Pdate
         AND d.Cover_Code = b.Cover_Code
         AND b.Validity_Start_Date <= Pdate
         AND (b.Validity_End_Date >= Pdate OR b.Validity_End_Date IS NULL)
         AND b.Web_Cover_Grp_Code IS NOT NULL
        ORDER BY
       Case when Phlthdetail.request_system = 'ULAK' and Cover_Code = 'ST504' -- S660 koc grubu
             then 0
            when Phlthdetail.request_system = 'ULAK' and Cover_Code = 'ST534'
             then 1
            when Phlthdetail.request_system <> 'ULAK' and Cover_Code = 'S660'
             then 0
            when Phlthdetail.request_system <> 'ULAK' and Cover_Code = 'S762'
             then 1
            else
             2 end asc;

        Recpolcovers Crpolicycovers%ROWTYPE;
        --
        Vcnt                   NUMBER;
        Vcovercode             VARCHAR2(10);
        Vinsmedcover           VARCHAR2(10);
        Vanymedcover           VARCHAR2(10);
        Vismedicinecoverusable NUMBER;
        --
    BEGIN
        IF Phlthmedicine IS NULL
        THEN
            RETURN;
        END IF;

        IF Phlthmedicine.First IS NULL
        THEN
            RETURN;
        END IF;

        /*      --
          Select A.Is_Complementary Into V_Is_Complementary
            from koc_ocp_pol_contracts_ext a
           Where a.contract_id = Phlthdetail.Contract_Id;
          V_Is_Complementary := Nvl(V_Is_Complementary, 0);
          --
          --
          --ila� teminat� ile e�le�me olsa bile YT lerde i�lem teminatlar�na bak�yor
          --Raise_Application_error(-20110, Phlthdetail.REQUEST_SYSTEM||' - '||Phlthdetail.Contract_Id||' - '||Phlthdetail.Oar_No||' - '||Phlthdetail.ISCOMPLEMENTARY);
          If  Nvl (Phlthdetail.REQUEST_SYSTEM , '##requestsystem##') = 'PORTAL' And
              V_Is_Complementary = 2
          Then
               --
               vIsMedicineCoverUsable := IsMedicineCoverUsable(   Phlthdetail.Contract_Id
                                                               ,  Phlthdetail.Oar_No
                                                               ,  Phlthdetail.Provision_Date
                                                               ,  Null
                                                               ,  Null) ;

               If nvl(vIsMedicineCoverUsable,1) = -1
               Then
                  Return;
               End If;
          End If;
    */
        --
        IF Phlthdetail.Location_Code IN (920)
        THEN
            --
            IF Phlthprovision.First IS NOT NULL
            THEN
                Findpreferredcoverformed(Phlthdetail.Location_Code,
                                                                    --MYALINKILIC: PRIORITY TASK I ICIN YENI PROCEDURE EKLENDI
                                                                 Phlthdetail.Provision_Date, Phlthprovision, Phlthdetail.Iscomplementary,
                                                                 Vcovercode);

            END IF;

            --
            FOR i IN 1 .. Phlthmedicine.Count
            LOOP
                --
                IF Phlthmedicine(i).Cover_Code IS NULL
                THEN
                    --Kemoterapi ila�lar� kemoterapi teminatlar� ile e�le�ecek
                    --
                    IF Ischemoteraphymedicine(Phlthmedicine(i).Barcode, Phlthdetail.Provision_Date) = 1
                    THEN
                        Phlthmedicine(i).Cover_Code := Findmedicinecover(Phlthdetail.Contract_Id, Phlthdetail.Oar_No, Pinstituteinfo.Claim_Inst_Type,
                                                                                                                         Pinstituteinfo.Claim_Inst_Loc, NULL, Phlthdetail.Location_Code, Phlthmedicine(i).Barcode,
                                                                                                                         Phlthdetail.Provision_Date, Phlthprovision, Phlthdetail.Iscomplementary);
                    ELSE
                        Phlthmedicine(i).Cover_Code := Vcovercode;
                    END IF;

                    --E�le�meyen i�lem varsa (phlthprovision bo� ise yani en az bir teminat se�ilememi�se)
                    --provizyon ekran�nda se�ilecek olan teminata bu kay�tlar yap���r.
                    --
                    IF Phlthmedicine(i).Cover_Code IS NULL AND
                            Vcovercode IS NULL
                    THEN
                        Phlthmedicine(i).Cover_Code := '0';
                    END IF;
                END IF;
            END LOOP;
        ELSE
            FOR i IN 1 .. Phlthmedicine.Count
            LOOP
                Recpolcovers := NULL;

                --
                IF Phlthmedicine(i).Cover_Code IS NULL
                THEN
                    --sigortal�da ila� teminat� varsa
                    /*
          insert into hkarabas.test(barcode,covercode)
          values(phlthmedicine(i).barcode,phlthmedicine(i).cover_code);
          commit;
           */

                    OPEN Crpolicycovers(Phlthdetail.Contract_Id, Phlthdetail.Oar_No, Phlthdetail.Provision_Date, Pinstituteinfo.Claim_Inst_Type,
                                                            Pinstituteinfo.Claim_Inst_Loc, NULL, Phlthmedicine(i).Barcode);

                    FETCH Crpolicycovers
                        INTO Recpolcovers;

                    CLOSE Crpolicycovers;

                    Phlthmedicine(i).Cover_Code := Recpolcovers.Cover_Code;
                    /*
           insert into hkarabas.test(barcode,covercode)
           values(phlthmedicine(i).barcode,phlthmedicine(i).cover_code||'-');
           commit;
          */
                END IF;
            END LOOP;

            Vinsmedcover := NULL;

            --sigortal�da ila� teminat� varsa teminat tan�m� olmayan ila�lar�
            --BRE taraf�ndan RET verilece�i i�in bu teminat alt�nda g�sterebiliriz.

            SELECT COUNT(*)
                INTO Vcnt
                FROM TABLE(Phlthmedicine)
             WHERE Cover_Code IS NOT NULL
                 AND Cover_Status_Code = 'BRECOVER';

            IF Vcnt > 0
            THEN
                ---if vcnt=1 then
                SELECT Cover_Code
                    INTO Vinsmedcover
                    FROM TABLE(Phlthmedicine)
                 WHERE Cover_Code IS NOT NULL
                     AND Cover_Status_Code = 'BRECOVER'
                     AND Rownum < 2;
                --  elsif vcnt>1 then

                -- end if;

            ELSE
                BEGIN
                    SELECT Cover_Code
                        INTO Vinsmedcover
                        FROM TABLE(Phlthmedicine)
                     WHERE Cover_Code IS NOT NULL
                         AND Rownum < 2;
                EXCEPTION
                    WHEN OTHERS THEN
                        Vinsmedcover := NULL;
                END;
            END IF;

            --sigortal�da ila� teminat� var m�
            Vanymedcover := NULL;

            OPEN Crmedcover(Phlthdetail.Contract_Id, Phlthdetail.Oar_No, Phlthdetail.Provision_Date, Pinstituteinfo.Claim_Inst_Type,
                                            Pinstituteinfo.Claim_Inst_Loc, NULL, Phlthdetail.Location_Code);

            FETCH Crmedcover
                INTO Vanymedcover;

            --sbh dosyadaki st li teminat
            IF Phlthdetail.Iscomplementary = 1 AND
               Vanymedcover IS NULL
            THEN
              OPEN   crulakcovers ( Phlthprovision );
               FETCH crulakcovers
                    INTO Vanymedcover;
                    CLOSE crulakcovers;
            END IF;
            --
            --sigortal�da ila� teminat� yok ise herhangi bir ila� teminat� olsun sistemde tan�ml� olan
            IF Vanymedcover IS NULL
            THEN
                OPEN Cranymedcover(Phlthdetail.Location_Code, Phlthdetail.Provision_Date, Pinstituteinfo.Claim_Inst_Type, Phlthdetail.Contract_Id,
                                                     Phlthdetail.Oar_No, Pinstituteinfo.Claim_Inst_Loc);

                FETCH Cranymedcover
                    INTO Vanymedcover;

                CLOSE Cranymedcover;
            END IF;

            --sigortal�da ila� teminat� varsa ila� retleri bu teminat alt�nda g�sterilecek
            --sigortal�da ila� teminat� yoksa ilac�n tan�ml� oldu�u herhangi bir
            FOR i IN 1 .. Phlthmedicine.Count
            LOOP
                IF Phlthmedicine(i).Cover_Code IS NULL
                THEN
                    --
                    IF Vinsmedcover IS NOT NULL
                    THEN
                        Phlthmedicine(i).Cover_Code := Vinsmedcover;
                    ELSE
                        Phlthmedicine(i).Cover_Code := Vanymedcover;
                    END IF;
                END IF;
            END LOOP;
        END IF;

        --
        FOR Rec IN (SELECT DISTINCT Cover_Code FROM TABLE(Phlthmedicine) WHERE Nvl(Cover_Code, '0') <> '0')
        LOOP
            --
            IF Iscoverexists(Phlthdetail.Claim_Id, Phlthdetail.Sf_No, 1, Phlthdetail.Location_Code, Rec.Cover_Code, Phlthprovision) = 0
            THEN
                Phlthprovision.Extend;
                Phlthprovision(Phlthprovision.Last) := Customer.Hlth_Provisions_Row_Type(Phlthdetail.Claim_Id, Phlthdetail.Sf_No, Phlthdetail.Location_Code,
                                                                                                                                                                 Rec.Cover_Code, NULL, NULL, Phlthdetail.Provision_User_Id, SYSDATE,
                                                                                                                                                                 NULL, NULL, 1, NULL, NULL, SYSDATE, NULL, NULL, NULL);
            END IF;
        END LOOP;
    END;

  FUNCTION Findbreresultforproc(Pcodemain IN NUMBER,
                                                                Pcodesub1 IN NUMBER,
                                                                Pcodesub2 IN NUMBER,
                                                                Porderno  IN VARCHAR2,
                                                                Phlthbre  IN Customer.Hltprv_Bre_Provision_Typ) RETURN VARCHAR2 IS
    BEGIN
        IF Phlthbre.Healthprocesses IS NULL
        THEN
            RETURN 'X';
        END IF;

        FOR j IN 1 .. Phlthbre.Healthprocesses.Count
        LOOP
            --
            IF Phlthbre.Healthprocesses(j).Processcodemain = Pcodemain AND
                 Phlthbre.Healthprocesses(j).Processcodesub1 = Pcodesub1 AND
                 Phlthbre.Healthprocesses(j).Processcodesub2 = Pcodesub2 AND
                 Phlthbre.Healthprocesses(j).Orderno = Porderno
            THEN
                RETURN Phlthbre.Healthprocesses(j).Breresultcode;
            END IF;
        END LOOP;

        RETURN 'X';
    END;
   PROCEDURE Findcoverforproc(Pcontractid    IN NUMBER,
                                                         Ppartitionno   IN NUMBER,
                                                         Pclaiminsttype IN VARCHAR2,
                                                         Pclaiminstloc  IN VARCHAR2,
                                                         Pcountrygroup  IN NUMBER,
                                                         Ploccode       IN NUMBER,
                                                         Pcodemain      IN NUMBER,
                                                         Pcodesub1      IN NUMBER,
                                                         Pcodesub2      IN NUMBER,
                                                         Porderno       IN VARCHAR2,
                                                         Pdate          IN DATE,
                                                         Phlthbre       IN Customer.Hltprv_Bre_Provision_Typ,
                                                         Pcover         OUT Customer.Hltprv_Policycover_Typ) IS
        CURSOR Crpolicycover IS
        --mustafa g�l t�m pdate ler truncland�
            SELECT DISTINCT A3.Cover_Code,
                                            A3.Swift_Code,
                                            Nvl(A3.Is_Special_Cover, 0) Is_Special_Cover,
                                            Nvl(A3.Is_Pool_Cover, 0) Is_Pool_Cover,
                                            A3.f_Day_Seance,
                                            A3.Main_Or_Sub_Cov
                FROM Koc_Cc_Hlth_Loc_Cover_Proc A1,
                         Koc_Oc_Cover_Definitions   A2,
                         Koc_Clm_Hlth_Indem_Totals  A3,
                         Koc_Oc_Cover_Definitions   A4
             WHERE A1.Location_Code = Ploccode
                 AND A1.Process_Code_Main = Pcodemain
                 AND A1.Process_Code_Sub1 = Pcodesub1
                 AND A1.Process_Code_Sub2 = Pcodesub2
                 AND A1.Validity_Start_Date <= Trunc(Pdate)
                 AND (A1.Validity_End_Date >= Trunc(Pdate) OR A1.Validity_End_Date IS NULL)
                 AND A1.Cover_Code = A2.Cover_Code
                 AND A2.Validity_Start_Date <= Trunc(Pdate)
                 AND (A2.Validity_End_Date >= Trunc(Pdate) OR A2.Validity_End_Date IS NULL)
                 AND A3.Contract_Id = Pcontractid
                 AND A3.Partition_No = Ppartitionno
                 AND A3.Claim_Inst_Type = Pclaiminsttype
                 AND A3.Claim_Inst_Loc = Pclaiminstloc
                 AND Nvl(A3.Is_Valid, 0) = 1
                 AND A3.Cover_Code = A4.Cover_Code
                 AND A4.Web_Cover_Grp_Code = A2.Web_Cover_Grp_Code
                 AND A3.Country_Group = Nvl(Pcountrygroup, 0)
                 AND A3.Validity_Start_Date <= Trunc(Pdate)
                 AND (A3.Validity_End_Date >= Trunc(Pdate) OR A3.Validity_End_Date IS NULL)
                 AND A4.Validity_Start_Date <= Trunc(Pdate)
                 AND (A4.Validity_End_Date >= Trunc(Pdate) OR A4.Validity_End_Date IS NULL);

        CURSOR Crprocesscover IS
        /*mustafaku teminat bulunamad� durumlar�nda sigortal�da olmayan teminatlarla e�le�iyordu
                                otomatik ret olaca�� i�in kurum tip velokasyonu, temiant lokasyon ba��ms�z (Ayaktas� yada yatara�� olmayan poli�eler den dolay�)
                                sigortal�da bulunan teminatlardan birine priority tablosuna uygun olarak yap��s�n diye a�a��daki kodu kapat�p
                                 indem totals e ba�l� bir sorgu ekliyorum

                                 SELECT r.Cover_Code
                                    FROM Koc_Cc_Hlth_Loc_Cover_Proc r,
                                             Koc_Oc_Cover_Definitions   b
                                 WHERE r.Location_Code = Ploccode
                                     AND r.Process_Code_Main = Pcodemain
                                     AND r.Process_Code_Sub1 = Pcodesub1
                                     AND r.Process_Code_Sub2 = Pcodesub2
                                     AND r.Validity_Start_Date <= Pdate
                                     AND (r.Validity_End_Date >= Pdate OR r.Validity_End_Date IS NULL)
                                     AND b.Cover_Code = r.Cover_Code
                                     AND b.Validity_Start_Date <= Pdate
                                     AND (b.Validity_End_Date >= Pdate OR b.Validity_End_Date IS NULL);*/
            SELECT Cover_Code_i
                FROM (SELECT i.Cover_Code Cover_Code_i,
                                         x.Cover_Code Cover_Code_p,
                                         Nvl(x.Priority, 999) Priority,
                                         v.group_code
                                FROM Koc_Clm_Hlth_Indem_Totals i,
                                     koc_v_health_insured_info v,
                                     (SELECT p.Location_Code Location_Code,
                                                                 d.Cover_Code    Cover_Code,
                                                                 p.Priority      Priority
                                                        FROM Koc_Cc_Hlth_Loc_Cover_Priority p,
                                                                 Koc_Oc_Cover_Definitions       d
                                                     WHERE p.Web_Cover_Grp_Code = d.Web_Cover_Grp_Code
                                                         AND p.Location_Code = Ploccode
                                                         AND p.Validity_Start_Date <= Trunc(Pdate)
                                                         AND (p.Validity_End_Date >= Trunc(Pdate) OR p.Validity_End_Date IS NULL)
                                                         AND d.Validity_Start_Date <= Trunc(Pdate)
                                                         AND (d.Validity_End_Date >= Trunc(Pdate) OR d.Validity_End_Date IS NULL)) x
                             WHERE i.Cover_Code = x.Cover_Code(+)
                                 AND i.Contract_Id = Pcontractid
                                 AND i.Partition_No = Ppartitionno
                                 AND i.contract_id = v.contract_id(+)
                                 AND i.partition_no = v.partition_no(+))
             ORDER BY -- Priority  sadece priority idi , a�a��daki gibi de�i�ti  SBH-78
                       Case when Phlthbre.requestsystem = 'ULAK' and Cover_Code_i = 'ST504' -- S660 koc grubu
                             then 0
                            when Phlthbre.requestsystem = 'ULAK' and Cover_Code_i = 'ST534'
                             then 1
                            when Phlthbre.requestsystem <> 'ULAK' and Cover_Code_i = 'S660'
                             then 0
                            when Phlthbre.requestsystem <> 'ULAK' and Cover_Code_i = 'S762'
                             then 1
                            else
                             2 end asc, Priority;  -- SBH-78 omert

        Vcovertbl      CUSTOMER.Hltprv_Policycover_Tbl;
        Vsubcovercnt   NUMBER;
        Vmaincovercnt  NUMBER;
        Rpolcover      Crpolicycover%ROWTYPE;
        Vbreresultcode VARCHAR2(10);

        PROCEDURE Writelog IS
            Vreturn    CLOB; --VARCHAR2(32767); SBH-2749
            Hltprv_Log Hltprv_Log_Typ;
        BEGIN
            dbms_lob.createtemporary(Vreturn,true);
            Vreturn := '-->findcoverforproc' || Chr(10);

            Vreturn := Vreturn || 'pcontractid      : ' || Pcontractid || Chr(10);
            Vreturn := Vreturn || 'ppartitionno     : ' || Ppartitionno || Chr(10);
            Vreturn := Vreturn || 'pclaiminsttype   : ' || Pclaiminsttype || Chr(10);
            Vreturn := Vreturn || 'pclaiminstloc    : ' || Pclaiminstloc || Chr(10);
            Vreturn := Vreturn || 'pcountrygroup    : ' || Pcountrygroup || Chr(10);
            Vreturn := Vreturn || 'ploccode         : ' || Ploccode || Chr(10);
            Vreturn := Vreturn || 'pcodemain        : ' || Pcodemain || Chr(10);
            Vreturn := Vreturn || 'pcodesub1        : ' || Pcodesub1 || Chr(10);
            Vreturn := Vreturn || 'pcodesub2        : ' || Pcodesub2 || Chr(10);
            Vreturn := Vreturn || 'porderno         : ' || Porderno || Chr(10);
            Vreturn := Vreturn || 'pdate            : ' || Pdate || Chr(10);
            Vreturn := Vreturn || 'breresultcode    : ' || Vbreresultcode || Chr(10);

            IF Pcover IS NOT NULL
            THEN
                Vreturn := Vreturn || 'pcover : ' || Pcover.Covercode;
            ELSE
                Vreturn := Vreturn || 'pcover : ' || 'bulunamad�';
            END IF;

            Hltprv_Log := Hltprv_Log_Typ();

            Hltprv_Log.Log_Id      := Phlthbre.Logid;
            Hltprv_Log.Content     := Vreturn;
            Hltprv_Log.Processinfo := 'findcoverforproc';

            Hltprv_Log.Savelogwithpragma('YES');
            dbms_lob.freetemporary(Vreturn);
        Exception when others then null; -- SBH-2749 loga yazamama hatas� provizyonu durdurmamal�
        END;
    BEGIN
        DBMS_OUTPUT.PUT_LINE('findcoverforproc.ademo:'||Pdate);
        --poli�ede tan�ml� olan teminat i�in do�rudan teminat-lokasyon-i�lem tan�m� olmayabilir.
        --Bu nedenle teminatlar�n web_cover_grp_code tan�m� �zerinden gidilmelidir.
        Vcovertbl := CUSTOMER.Hltprv_Policycover_Tbl();

        OPEN Crpolicycover;

        LOOP
            Rpolcover := NULL;

            FETCH Crpolicycover
                INTO Rpolcover;

            EXIT WHEN Crpolicycover%NOTFOUND;

            Vcovertbl.Extend;
            Vcovertbl(Vcovertbl.Last) := CUSTOMER.Hltprv_Policycover_Typ();
            Vcovertbl(Vcovertbl.Last).Covercode := Rpolcover.Cover_Code;
            Vcovertbl(Vcovertbl.Last).Swiftcode := Rpolcover.Swift_Code;
            Vcovertbl(Vcovertbl.Last).Ispoolcover := Rpolcover.Is_Pool_Cover;
            Vcovertbl(Vcovertbl.Last).Isspecialcover := Rpolcover.Is_Special_Cover;
            Vcovertbl(Vcovertbl.Last).Fdayseance := Rpolcover.f_Day_Seance;
            Vcovertbl(Vcovertbl.Last).Mainorsubcov := Rpolcover.Main_Or_Sub_Cov;
            DBMS_OUTPUT.PUT_LINE('findcoverforproc:'||Rpolcover.Cover_Code);
        END LOOP;

        CLOSE Crpolicycover;

        --yukar�da instance olu�turuldu
        --�ncelik ALT teminatlar�n e�er 1 tane ALT teminat varsa cover code odur
        --
        IF Vcovertbl.First IS NOT NULL
        THEN
            SELECT COUNT(1) INTO Vsubcovercnt FROM TABLE(Vcovertbl) x WHERE x.Mainorsubcov = 'ALT';

            --
            IF Vsubcovercnt = 0
            THEN
                SELECT COUNT(1) INTO Vmaincovercnt FROM TABLE(Vcovertbl) x WHERE x.Mainorsubcov = 'ANA';
            END IF;

            IF Vsubcovercnt = 1
            THEN
                Pcover := CUSTOMER.Hltprv_Policycover_Typ();

                SELECT Covercode,
                             Swiftcode,
                             Ispoolcover,
                             Isspecialcover,
                             Fdayseance,
                             Mainorsubcov
                    INTO Pcover.Covercode,
                             Pcover.Swiftcode,
                             Pcover.Ispoolcover,
                             Pcover.Isspecialcover,
                             Pcover.Fdayseance,
                             Pcover.Mainorsubcov
                    FROM TABLE(Vcovertbl) x
                 WHERE x.Mainorsubcov = 'ALT';
            END IF;

            IF Vsubcovercnt = 0 AND
                 Vmaincovercnt = 1
            THEN
                Pcover := CUSTOMER.Hltprv_Policycover_Typ();

                SELECT Covercode,
                             Swiftcode,
                             Ispoolcover,
                             Isspecialcover,
                             Fdayseance,
                             Mainorsubcov
                    INTO Pcover.Covercode,
                             Pcover.Swiftcode,
                             Pcover.Ispoolcover,
                             Pcover.Isspecialcover,
                             Pcover.Fdayseance,
                             Pcover.Mainorsubcov
                    FROM TABLE(Vcovertbl) x
                 WHERE x.Mainorsubcov = 'ANA';
            END IF;

            --teminat var ama e�le�me yok ise
            --BRE ret verdi ise herhangi bir teminat ile e�le�tir
            Vbreresultcode := NULL;

            IF Pcover IS NULL
            THEN
                Vbreresultcode := Findbreresultforproc(Pcodemain, Pcodesub1, Pcodesub2, Porderno, Phlthbre);

                --
                IF Vbreresultcode IN ('R', 'PR')
                THEN
                    Pcover := CUSTOMER.Hltprv_Policycover_Typ();

                    BEGIN
                        -- mustafaku
                        SELECT i.Cover_Code,
                                     i.Swift_Code,
                                     i.Is_Pool_Cover,
                                     i.Is_Special_Cover,
                                     i.f_Day_Seance,
                                     i.Main_Or_Sub_Cov
                            INTO Pcover.Covercode,
                                     Pcover.Swiftcode,
                                     Pcover.Ispoolcover,
                                     Pcover.Isspecialcover,
                                     Pcover.Fdayseance,
                                     Pcover.Mainorsubcov
                            FROM Koc_Clm_Hlth_Indem_Totals i
                         WHERE i.Main_Or_Sub_Cov = 'ALT'
                             AND i.Contract_Id = Pcontractid
                             AND i.Partition_No = Ppartitionno
                             AND i.Claim_Inst_Type = Pclaiminsttype
                             AND i.Claim_Inst_Loc = Pclaiminstloc
                             AND Nvl(i.Is_Valid, 0) = 1
                             AND i.Country_Group = Nvl(Pcountrygroup, 0)
                             AND i.Validity_Start_Date <= Pdate
                             AND (i.Validity_End_Date >= Pdate OR i.Validity_End_Date IS NULL)
                             AND Rownum < 2;
                    EXCEPTION
                        WHEN OTHERS THEN
                            --mustafaku
                            BEGIN
                                SELECT Covercode,
                                             Swiftcode,
                                             Ispoolcover,
                                             Isspecialcover,
                                             Fdayseance,
                                             Mainorsubcov
                                    INTO Pcover.Covercode,
                                             Pcover.Swiftcode,
                                             Pcover.Ispoolcover,
                                             Pcover.Isspecialcover,
                                             Pcover.Fdayseance,
                                             Pcover.Mainorsubcov
                                    FROM TABLE(Vcovertbl) x
                                 WHERE x.Mainorsubcov = 'ALT'
                                     AND Rownum < 2;
                            EXCEPTION
                                WHEN OTHERS THEN
                                    --
                                    BEGIN
                                        SELECT Covercode,
                                                     Swiftcode,
                                                     Ispoolcover,
                                                     Isspecialcover,
                                                     Fdayseance,
                                                     Mainorsubcov
                                            INTO Pcover.Covercode,
                                                     Pcover.Swiftcode,
                                                     Pcover.Ispoolcover,
                                                     Pcover.Isspecialcover,
                                                     Pcover.Fdayseance,
                                                     Pcover.Mainorsubcov
                                            FROM TABLE(Vcovertbl) x
                                         WHERE x.Mainorsubcov = 'ANA'
                                             AND Rownum < 2;
                                    EXCEPTION
                                        WHEN OTHERS THEN
                                            Pcover := NULL;
                                    END;
                            END;
                    END;
                END IF;
            END IF;
        ELSE
            --sigortal�da teminat yok ise teminat bulunamad� ret maddesi �al��aca��ndan notmatch �al��mayacak
            --i�lemin lokasyon - teminat tan�mlar�ndan bir teminata yap��acak
            --
            IF Ploccode NOT IN (920)
            THEN
                Pcover := CUSTOMER.Hltprv_Policycover_Typ();

                OPEN Crprocesscover;

                FETCH Crprocesscover
                    INTO Pcover.Covercode;

                CLOSE Crprocesscover;
            END IF;
        END IF;

        Writelog;
    END;

  FUNCTION Isprocnotmatchinbre(Pprocesscodemain NUMBER,
                                                             Pprocesscodesub1 NUMBER,
                                                             Pprocesscodesub2 NUMBER,
                                                             Porderno         VARCHAR2,
                                                             Phlthbre         Customer.Hltprv_Bre_Provision_Typ) RETURN NUMBER IS
        Vreturn NUMBER;
    BEGIN
        Vreturn := 0;

        FOR i IN 1 .. Phlthbre.Healthprocesses.Count
        LOOP
            --
            IF Phlthbre.Healthprocesses(i).Processcodemain = Pprocesscodemain AND
                 Phlthbre.Healthprocesses(i).Processcodesub1 = Pprocesscodesub1 AND
                 Phlthbre.Healthprocesses(i).Processcodesub2 = Pprocesscodesub2 AND
                 Phlthbre.Healthprocesses(i).Orderno = Porderno
            THEN
                Vreturn := CASE
                                         WHEN Nvl(Phlthbre.Healthprocesses(i).Brenotmatchprocess, 0) = 0 THEN
                                            0
                                         ELSE
                                            1
                                     END;

                EXIT;
            END IF;
        END LOOP;

        RETURN Vreturn;
    END;
    
      PROCEDURE Findpreferredcover(Ploccode       NUMBER,
                                                             Pdate          DATE,
                                                             Phlthprovision Hlth_Provisions_Table_Type,
                                                             Pcovercode     OUT VARCHAR2) IS
        CURSOR Crpolicycover IS
            SELECT DISTINCT A3.Cover_Code,
                                            A1.Priority
                FROM Koc_Cc_Hlth_Loc_Cover_Priority A1,
                         Koc_Oc_Cover_Definitions A2,
                         TABLE(Phlthprovision) A3
             WHERE A1.Location_Code = Ploccode
                 AND A1.Validity_Start_Date <= Pdate
                 AND (A1.Validity_End_Date >= Pdate OR A1.Validity_End_Date IS NULL)
                 AND A1.Web_Cover_Grp_Code = A2.Web_Cover_Grp_Code
                 AND A2.Validity_Start_Date <= Pdate
                 AND (A2.Validity_End_Date >= Pdate OR A2.Validity_End_Date IS NULL)
                 AND A2.Cover_Code = A3.Cover_Code
                 AND A3.Location_Code = Ploccode
             ORDER BY A1.Priority; --A1.Priority;

        Rpolcover Crpolicycover%ROWTYPE;
    BEGIN
        --i�lemler ve ila�lar ile e�le�en teminatlar aras�nda prioritysi en y�ksek olan bulunur
        --poli�ede tan�ml� olan teminatlar�n web_cover_grp_code tan�mlar� koc_cc_hlth_loc_cover_item tan�m tablosunda priority e g�re �ekiliyor

        OPEN Crpolicycover;

        FETCH Crpolicycover
            INTO Rpolcover;

        CLOSE Crpolicycover;

        Pcovercode := Rpolcover.Cover_Code;
    END;


   PROCEDURE Choosecoverforproc(Phlthdetail    IN Customer.Hlth_Detail_Row_Type,
                                                             Phlthproc      IN OUT Customer.Hlth_Proc_Detail_Table_Type,
                                                             Pinstituteinfo IN Koc_v_Clm_Suppliers%ROWTYPE,
                                                             Phlthprovision IN OUT Customer.Hlth_Provisions_Table_Type,
                                                             Phlthbre       IN Customer.Hltprv_Bre_Provision_Typ) IS
        Vcnt             NUMBER;
        Vcovermatchcount NUMBER;
        Vcover           CUSTOMER.Hltprv_Policycover_Typ;
        Vcovercode       VARCHAR2(10);
        Vhlthproc        Customer.Hlth_Proc_Detail_Table_Type;
        Vprovisionrow    Koc_Clm_Hlth_Provisions%ROWTYPE;

        CURSOR Crcover IS
            SELECT a.Cover_Code
                FROM Koc_Clm_Hlth_Indem_Totals a
             WHERE a.Contract_Id = Phlthdetail.Contract_Id
                 AND a.Partition_No = Phlthdetail.Oar_No
                 AND a.Claim_Inst_Type = Pinstituteinfo.Claim_Inst_Type
                 AND a.Claim_Inst_Loc = Pinstituteinfo.Claim_Inst_Loc
                 AND a.Main_Or_Sub_Cov = 'ALT'
                 AND Nvl(a.Is_Valid, 0) = 1
                 AND a.Validity_Start_Date <= Nvl(Trunc(Phlthdetail.Provision_Date), Trunc(SYSDATE)) --mustafaku
                 AND (a.Validity_End_Date IS NULL OR Trunc(a.Validity_End_Date) >= Nvl(Trunc(Phlthdetail.Provision_Date), Trunc(SYSDATE))); --mustafaku

        Rcover Crcover%ROWTYPE;

        --
        PROCEDURE Writelog IS
            Vreturn    CLOB;--VARCHAR2(32767); SBH-2749 omert log hatas�
            Hltprv_Log Hltprv_Log_Typ;
        BEGIN
            dbms_lob.createtemporary(Vreturn,true);
            Vreturn := '-->se�ilen i�lemler (choosecoverforproc)' || Chr(10);

            --
            IF Phlthproc IS NOT NULL
            THEN
                --
                FOR i IN 1 .. Phlthproc.Count
                LOOP
                    Vreturn := Vreturn || 'hlth_proc_detail_table_type' || Chr(10);

                    Vreturn := Vreturn || 'claim_id          : ' || Phlthproc(i).Claim_Id || Chr(10);
                    Vreturn := Vreturn || 'sf_no             : ' || Phlthproc(i).Sf_No || Chr(10);
                    Vreturn := Vreturn || 'location_code     : ' || Phlthproc(i).Location_Code || Chr(10);
                    Vreturn := Vreturn || 'cover_code        : ' || Phlthproc(i).Cover_Code || Chr(10);
                    Vreturn := Vreturn || 'process_code_main : ' || Phlthproc(i).Process_Code_Main || Chr(10);
                    Vreturn := Vreturn || 'process_code_sub1 : ' || Phlthproc(i).Process_Code_Sub1 || Chr(10);
                    Vreturn := Vreturn || 'process_code_sub2 : ' || Phlthproc(i).Process_Code_Sub2 || Chr(10);
                    Vreturn := Vreturn || 'order_no          : ' || Phlthproc(i).Order_No || Chr(10);
                    Vreturn := Vreturn || 'bre result        : ' ||
                                         Findbreresultforproc(Phlthproc(i).Process_Code_Main, Phlthproc(i).Process_Code_Sub1, Phlthproc(i).Process_Code_Sub2,
                                                                                    Phlthproc(i).Order_No, Phlthbre);
                END LOOP;
            END IF;

            Hltprv_Log := Hltprv_Log_Typ();

            Hltprv_Log.Log_Id      := Phlthbre.Logid;
            Hltprv_Log.Content     := Vreturn;
            Hltprv_Log.Processinfo := 'hlth_proc_detail_table_type';

            Hltprv_Log.Savelogwithpragma('YES');
            dbms_lob.freetemporary(Vreturn);
        Exception when others then null; -- SBH-2749 loga yazamama hatas� provizyonu durdurmamal�
        END;
    BEGIN
        DELETE Koc_Clm_Web_Notmatch_Proc
         WHERE Claim_Id = Phlthdetail.Claim_Id
             AND Instance_Id = '999999';

        IF Phlthproc IS NULL
        THEN
            RETURN;
        END IF;

        --
        IF Phlthproc.First IS NULL
        THEN
            RETURN;
        END IF;

        OPEN Crcover;

        FETCH Crcover
            INTO Rcover;

        CLOSE Crcover;

        --
        FOR i IN 1 .. Phlthproc.Count
        LOOP
            --i�lem bre de notmatch olarak i�aretlenmemi� ise
            IF Isprocnotmatchinbre(Phlthproc(i).Process_Code_Main, Phlthproc(i).Process_Code_Sub1, Phlthproc(i).Process_Code_Sub2, Phlthproc(i).Order_No,
                                                         Phlthbre) = 0
            THEN
                --
                IF Phlthproc(i).Cover_Code IS NULL
                THEN
                    Vcover := NULL;

                    --Sistemde olmayan i�lem ise teminat tan�m� yok
                    IF Phlthproc(i).Process_Code_Main <> '9' AND
                         Phlthproc(i).Process_Code_Sub1 <> '9' AND
                         Phlthproc(i).Process_Code_Sub2 <> '9'
                    THEN
                        Findcoverforproc(Phlthdetail.Contract_Id, Phlthdetail.Oar_No, Pinstituteinfo.Claim_Inst_Type, Pinstituteinfo.Claim_Inst_Loc, NULL,
                                                         Phlthproc(i).Location_Code, Phlthproc(i).Process_Code_Main, Phlthproc(i).Process_Code_Sub1,
                                                         Phlthproc(i).Process_Code_Sub2, Phlthproc(i).Order_No, Phlthdetail.Provision_Date, Phlthbre, Vcover);

                        --
                        IF Vcover.Covercode IS NOT NULL
                        THEN
                            IF Iscoverexists(Phlthdetail.Claim_Id, Phlthdetail.Sf_No, 1, Phlthdetail.Location_Code, Vcover.Covercode, Phlthprovision) = 0
                            THEN
                                Phlthprovision.Extend;
                                Phlthprovision(Phlthprovision.Last) := Customer.Hlth_Provisions_Row_Type(Phlthdetail.Claim_Id, Phlthdetail.Sf_No,
                                                                                                                                                                                 Phlthdetail.Location_Code, Vcover.Covercode, Vcover.Swiftcode,
                                                                                                                                                                                 NULL, Phlthproc(i).Userid, SYSDATE, NULL, NULL, 1,
                                                                                                                                                                                 Vcover.Ispoolcover, Vcover.Isspecialcover, SYSDATE,
                                                                                                                                                                                 Vcover.Fdayseance, NULL, NULL);
                            END IF;

                            Phlthproc(i).Claim_Id := Phlthdetail.Claim_Id;
                            Phlthproc(i).Sf_No := Phlthdetail.Sf_No;
                            Phlthproc(i).Cover_Code := Vcover.Covercode;
                        END IF;
                    END IF;
                END IF;
            ELSE
                --i�lem bre de notmatch olarak i�aretlenmi� ise
                Phlthproc(i).Cover_Code := 'X';
            END IF;
        END LOOP;

        --
        IF Phlthdetail.Location_Code IN (920)
        THEN
            --i�lem bre de notmatch olarak i�aretlenmemi� ve teminat� yok ise
            --e�le�meyen kay�t var m�
            SELECT COUNT(1) INTO Vcnt FROM TABLE(Phlthproc) WHERE Cover_Code IS NULL;

            -- E�le�meyen kay�t varsa ve en az bir teminat set edildiyse
            --
            IF Vcnt > 0 AND
                 Phlthprovision IS NOT NULL AND
                 Phlthprovision.First IS NOT NULL
            THEN
                Findpreferredcover(Phlthdetail.Location_Code, Phlthdetail.Provision_Date, Phlthprovision, Vcovercode);

                --
                IF Vcovercode IS NOT NULL
                THEN
                    --
                    FOR i IN 1 .. Phlthproc.Count
                    LOOP
                        --
                        IF Phlthproc(i).Cover_Code IS NULL
                        THEN
                            --
                            Phlthproc(i).Claim_Id := Phlthdetail.Claim_Id;
                            Phlthproc(i).Sf_No := Phlthdetail.Sf_No;
                            Phlthproc(i).Cover_Code := Vcovercode;
                        END IF;
                    END LOOP;
                END IF;
            END IF;
        END IF;

        --
        FOR i IN 1 .. Phlthproc.Count
        LOOP
            --Sistemde olmayan i�lem ise teminat listesindeki ilk teminata y�nlendir
            --Dosya ret olacak ise
            IF (Phlthproc(i).Process_Code_Main = '9' AND Phlthproc(i).Process_Code_Sub1 = '9' AND Phlthproc(i).Process_Code_Sub2 = '9') OR
                 Nvl(Phlthbre.Breresultcode, 'PP') = 'R'
            THEN
                --
                IF Phlthproc(i).Cover_Code IS NULL
                THEN
                    Phlthproc(i).Claim_Id := Phlthdetail.Claim_Id;
                    Phlthproc(i).Sf_No := Phlthdetail.Sf_No;

                    --
                    IF Phlthprovision IS NOT NULL AND
                         Phlthprovision.First IS NOT NULL
                    THEN
                        Phlthproc(i).Cover_Code := Phlthprovision(1).Cover_Code;
                    END IF;

                    IF Phlthproc(i).Cover_Code IS NULL
                    THEN
                        Phlthproc(i).Cover_Code := Rcover.Cover_Code;

                        Phlthprovision.Extend;
                        Phlthprovision(Phlthprovision.Last) := Customer.Hlth_Provisions_Row_Type(Phlthdetail.Claim_Id, Phlthdetail.Sf_No,
                                                                                                                                                                         Phlthdetail.Location_Code, Rcover.Cover_Code, NULL, NULL,
                                                                                                                                                                         Phlthdetail.Provision_User_Id, SYSDATE, NULL, NULL, 1, NULL, NULL,
                                                                                                                                                                         SYSDATE, NULL, NULL, NULL);
                    END IF;
                    --

                END IF;
            END IF;
        END LOOP;

        Writelog;

        --
        FOR i IN 1 .. Phlthproc.Count
        LOOP
            --teminat olmayan kay�tlar notmatch tablosuna at�l�yor
            --bre den notmatch olarak i�aretlenenler notmatch tablosuna at�lacak
            IF Nvl(Phlthproc(i).Cover_Code, 'X') = 'X'
            THEN
                Phlthproc(i).Cover_Code := NULL;
                Phlthproc(i).Covermatchstatus := 'NOT_MATCHED';
                Insertnotmatch(Phlthdetail, Phlthproc(i));
            ELSE
                --
                IF Vhlthproc IS NULL
                THEN
                    Vhlthproc := Customer.Hlth_Proc_Detail_Table_Type();
                END IF;

                Vhlthproc.Extend;
                Vhlthproc(Vhlthproc.Last) := Customer.Hlth_Proc_Detail_Row_Type();
                Vhlthproc(Vhlthproc.Last) := Phlthproc(i);
            END IF;
        END LOOP;

        --teminat� bo� olan kay�tlar notmatch tablosuna yaz�ld���ndan dolay� listeden ��kar�l�yor.
        Phlthproc := Customer.Hlth_Proc_Detail_Table_Type();
        Phlthproc := Vhlthproc;
    END;

   
   


    
   
  

   PROCEDURE Choosecoverforpreapprove(Phlthdetail      IN Customer.Hlth_Detail_Row_Type,
                                                                         Pinstituteinfo   IN Koc_v_Clm_Suppliers%ROWTYPE,
                                                                         Phlthproc        IN OUT Customer.Hlth_Proc_Detail_Table_Type,
                                                                         Phlthmedicine    IN OUT Customer.Medicine_Indem_Det_Table_Type,
                                                                         Phlthitem        IN OUT Customer.Hltprv_Dml_Item_Tbl,
                                                                         Phlthprovision   IN OUT Customer.Hlth_Provisions_Table_Type,
                                                                         Phltbreprovision IN Customer.Hltprv_Bre_Provision_Typ) IS
        CURSOR Crcover(Cpclaimid  Koc_Clm_Hlth_Detail.Claim_Id%TYPE,
                                     Cpsfno     Koc_Clm_Hlth_Detail.Sf_No%TYPE,
                                     Cplocation Koc_Clm_Hlth_Detail.Web_Location_Code%TYPE) IS
            SELECT A3.Cover_Code,
                         A3.Swift_Code,
                         A3.User_Id,
                         A3.Country_Code,
                         A3.Exemption_Rate,
                         A3.Add_Order_No,
                         A3.Is_Pool_Cover,
                         A3.Is_Special_Cover,
                         A3.Day_Seance,
                         A3.Request_Amount
                FROM Koc_Clm_Hlth_Provisions A3
             WHERE A3.Claim_Id = Cpclaimid
                 AND A3.Sf_No = Cpsfno
                 AND A3.Add_Order_No = 1
                 AND A3.Location_Code = Cplocation;

        Rcover    Crcover%ROWTYPE;
        Vproccnt  NUMBER;
        Vmedcnt   NUMBER;
        Vitemcnt  NUMBER;
        Vhlthproc Customer.Hlth_Proc_Detail_Table_Type;
    BEGIN
        DBMS_OUTPUT.PUT_LINE('chose_cover_pre_approve_cover_code='||Phlthproc(1).Cover_Code||' bre_cover_code='||Phltbreprovision.Healthprocesses(1).Brecover.Code);
        OPEN Crcover(Phlthdetail.Claim_Id, Phlthdetail.Sf_No, Phlthdetail.Location_Code);

        FETCH Crcover
            INTO Rcover;

        CLOSE Crcover;

        --yt �n provizyonda teminat buldu
        IF Phlthproc IS NOT NULL
        THEN
            FOR i IN 1 .. Phlthproc.Count
            LOOP
                --
                IF Isprocnotmatchinbre(Phlthproc(i).Process_Code_Main, Phlthproc(i).Process_Code_Sub1, Phlthproc(i).Process_Code_Sub2, Phlthproc(i).Order_No,
                                                             Phltbreprovision) = 0
                THEN
                    --
                    IF Phlthproc(i).Cover_Code IS NULL
                    THEN
                        Phlthproc(i).Claim_Id := Phlthdetail.Claim_Id;
                        Phlthproc(i).Sf_No := Phlthdetail.Sf_No;
                        Phlthproc(i).Cover_Code := Rcover.Cover_Code;
                    END IF;
                ELSE
                    Phlthproc(i).Cover_Code := NULL;
                END IF;
            END LOOP;
        END IF;

        --
        IF Phlthmedicine IS NOT NULL
        THEN
            FOR i IN 1 .. Phlthmedicine.Count
            LOOP
                Phlthmedicine(i).Claim_Id := Phlthdetail.Claim_Id;
                Phlthmedicine(i).Sf_No := Phlthdetail.Sf_No;

                --
                IF Phlthmedicine(i).Cover_Code IS NULL
                THEN
                    --Kemoterapi ila�lar� kemoterapi teminatlar� ile e�le�ecek
                    --
                    IF Ischemoteraphymedicine(Phlthmedicine(i).Barcode, Phlthdetail.Provision_Date) = 1
                    THEN
                        Phlthmedicine(i).Cover_Code := Findmedicinecover(Phlthdetail.Contract_Id, Phlthdetail.Oar_No, Pinstituteinfo.Claim_Inst_Type,
                                                                                                                         Pinstituteinfo.Claim_Inst_Loc, NULL, Phlthdetail.Location_Code, Phlthmedicine(i).Barcode,
                                                                                                                         Phlthdetail.Provision_Date, Phlthprovision, Phlthdetail.Iscomplementary);

                        IF Phlthmedicine(i).Cover_Code IS NULL
                        THEN
                            Phlthmedicine(i).Cover_Code := Rcover.Cover_Code;
                        END IF;

                        --
                        IF Phlthmedicine(i).Cover_Code IS NOT NULL
                        THEN
                            IF Iscoverexists(Phlthdetail.Claim_Id, Phlthdetail.Sf_No, 1, Phlthdetail.Location_Code, Phlthmedicine(i).Cover_Code, Phlthprovision) = 0
                            THEN
                                Phlthprovision.Extend;
                                Phlthprovision(Phlthprovision.Last) := Customer.Hlth_Provisions_Row_Type(Phlthdetail.Claim_Id, Phlthdetail.Sf_No,
                                                                                                                                                                                 Phlthdetail.Location_Code, Phlthmedicine(i).Cover_Code, NULL,
                                                                                                                                                                                 NULL, Phlthdetail.Provision_User_Id, SYSDATE, NULL, NULL, 1,
                                                                                                                                                                                 NULL, NULL, SYSDATE, NULL, NULL, NULL);
                            END IF;
                        END IF;
                    ELSE
                        Phlthmedicine(i).Cover_Code := Rcover.Cover_Code;
                    END IF;
                END IF;
            END LOOP;
        END IF;

        --
        IF Phlthitem IS NOT NULL
        THEN
            FOR i IN 1 .. Phlthitem.Count
            LOOP
                Phlthitem(i).Claim_Id := Phlthdetail.Claim_Id;
                Phlthitem(i).Sf_No := Phlthdetail.Sf_No;

                --
                IF Phlthitem(i).Cover_Code IS NULL
                THEN
                    Phlthitem(i).Cover_Code := Rcover.Cover_Code;
                END IF;
            END LOOP;
        END IF;

        --
        IF Rcover.Cover_Code IS NOT NULL
        THEN
            SELECT COUNT(1) INTO Vproccnt FROM TABLE(Phlthproc) WHERE Cover_Code = Rcover.Cover_Code;

            SELECT COUNT(1) INTO Vmedcnt FROM TABLE(Phlthmedicine) WHERE Cover_Code = Rcover.Cover_Code;

            SELECT COUNT(1) INTO Vitemcnt FROM TABLE(Phlthitem) WHERE Cover_Code = Rcover.Cover_Code;

            --
            IF Vproccnt > 0 OR
                 Vmedcnt > 0 OR
                 Vitemcnt > 0
            THEN
                --
                IF Iscoverexists(Phlthdetail.Claim_Id, Phlthdetail.Sf_No, 1, Phlthdetail.Location_Code, Rcover.Cover_Code, Phlthprovision) = 0
                THEN
                    Phlthprovision.Extend;
                    Phlthprovision(Phlthprovision.Last) := Customer.Hlth_Provisions_Row_Type(Phlthdetail.Claim_Id, Phlthdetail.Sf_No, Phlthdetail.Location_Code,
                                                                                                                                                                     Rcover.Cover_Code, Rcover.Swift_Code, NULL, Rcover.User_Id, SYSDATE,
                                                                                                                                                                     Rcover.Country_Code, Rcover.Exemption_Rate, Rcover.Add_Order_No,
                                                                                                                                                                     Rcover.Is_Pool_Cover, Rcover.Is_Special_Cover, SYSDATE,
                                                                                                                                                                     Rcover.Day_Seance, Rcover.Request_Amount, NULL);
                END IF;
            END IF;
        END IF;

        IF Phlthproc IS NOT NULL
        THEN
            FOR i IN 1 .. Phlthproc.Count
            LOOP
                --
                IF Phlthproc(i).Cover_Code IS NULL
                THEN
                    Phlthproc(i).Covermatchstatus := 'NOT_MATCHED';
                    Insertnotmatch(Phlthdetail, Phlthproc(i));
                ELSE
                    --
                    IF Vhlthproc IS NULL
                    THEN
                        Vhlthproc := Customer.Hlth_Proc_Detail_Table_Type();
                    END IF;

                    Vhlthproc.Extend;
                    Vhlthproc(Vhlthproc.Last) := Customer.Hlth_Proc_Detail_Row_Type();
                    Vhlthproc(Vhlthproc.Last) := Phlthproc(i);
                END IF;
            END LOOP;
        END IF;

        --teminat� bo� olan kay�tlar notmatch tablosuna yaz�ld���ndan dolay� listeden ��kar�l�yor.
        Phlthproc := Customer.Hlth_Proc_Detail_Table_Type();
        Phlthproc := Vhlthproc;
    END;

    FUNCTION Inpatientpreapprove(Pclaimid      IN Koc_Clm_Hlth_Detail.Claim_Id%TYPE,
                                                             Psfno         IN Koc_Clm_Hlth_Detail.Sf_No%TYPE,
                                                             Plocationcode IN Koc_Clm_Hlth_Detail.Web_Location_Code%TYPE) RETURN NUMBER IS
        Vcount NUMBER;
    BEGIN
        --
        IF Nvl(Plocationcode, 0) <> 920
        THEN
            RETURN 0;
        END IF;

        SELECT COUNT(1)
            INTO Vcount
            FROM Koc_Clm_Hlth_Provisions a
         WHERE a.Claim_Id = Pclaimid
             AND a.Sf_No = Psfno
             AND a.Add_Order_No = 1
             AND a.Location_Code = Plocationcode;

        --
        IF Vcount = 0
        THEN
            RETURN 0;
        END IF;

        RETURN 1;
    EXCEPTION
        WHEN OTHERS THEN
            RETURN 0;
    END;

    

  PROCEDURE Choosecoverfrombre(Phlthdetail      IN Customer.Hlth_Detail_Row_Type,
                                                             Phltbreprovision IN Customer.Hltprv_Bre_Provision_Typ,
                                                             Phlthproc        IN OUT Customer.Hlth_Proc_Detail_Table_Type,
                                                             Phlthprovision   IN OUT Customer.Hlth_Provisions_Table_Type) IS
        --20141222--emre.elcik--
        --BRE Teminat Y�nlendirme i�in eklendi.
        --BRE den gelen i�lemlerin �zerinde teminat g�nderilmi�se o teminat al�nmal�
        --

        Vcnt NUMBER;
    BEGIN
        IF Phlthproc IS NULL
        THEN
            RETURN;
        END IF;

        IF Phltbreprovision.Healthprocesses IS NULL
        THEN
            RETURN;
        END IF;

        --

        FOR i IN 1 .. Phlthproc.Count
        LOOP
            FOR j IN 1 .. Phltbreprovision.Healthprocesses.Count
            LOOP
                IF Phltbreprovision.Healthprocesses(j).Processcodemain = Phlthproc(i).Process_Code_Main AND
                     Phltbreprovision.Healthprocesses(j).Processcodesub1 = Phlthproc(i).Process_Code_Sub1 AND
                     Phltbreprovision.Healthprocesses(j).Processcodesub2 = Phlthproc(i).Process_Code_Sub2 AND
                     Phltbreprovision.Healthprocesses(j).Orderno = Phlthproc(i).Order_No
                THEN
                    --
                    DBMS_OUTPUT.PUT_LINE('cover_code='||Phlthproc(i).Cover_Code||' bre_cover_code='||Phltbreprovision.Healthprocesses(j).Brecover.Code);
                    IF Phltbreprovision.Healthprocesses(j).Brecover.Code IS NOT NULL
                    THEN
                        
                        Phlthproc(i).Cover_Code := Phltbreprovision.Healthprocesses(j).Brecover.Code;

                        --
                        IF Iscoverexists(Phlthdetail.Claim_Id, Phlthdetail.Sf_No, 1, Phlthdetail.Location_Code, Phlthproc(i).Cover_Code, Phlthprovision) = 0
                        THEN
                            Phlthprovision.Extend;
                            Phlthprovision(Phlthprovision.Last) := Customer.Hlth_Provisions_Row_Type(Phlthdetail.Claim_Id, Phlthdetail.Sf_No,
                                                                                                                                                                             Phlthproc(i).Location_Code, Phlthproc(i).Cover_Code, NULL, NULL,
                                                                                                                                                                             Phlthproc(i).Userid, SYSDATE, NULL, NULL, 1, NULL, NULL, SYSDATE,
                                                                                                                                                                             NULL, NULL, NULL);
                        END IF;
                    END IF;
                END IF;
            END LOOP;
        END LOOP;
    END;

     PROCEDURE Getinstituteinfo(Pcontractid    IN NUMBER,
                                                         Ppartitionno   IN NUMBER,
                                                         Ppackageid     IN NUMBER,
                                                         Pinstitutecode IN NUMBER,
                                                         Pprovisiondate IN DATE,
                                                         Pinstituteinfo OUT Koc_v_Clm_Suppliers%ROWTYPE) IS
        Vclaiminsttype     VARCHAR2(10);
        Vclaiminsttypenew  VARCHAR2(10);
        Vclaiminsttypedesc VARCHAR2(100);
        Vinstcitycode      VARCHAR2(10);
        Vcur               KOC_CLM_HLTH_TRNX.Refcur;
    BEGIN
        --
        IF Vcur%ISOPEN
        THEN
            CLOSE Vcur;
        END IF;

        Koc_Clm_Hlth_Utils.Getinstitutinfobycode(Pinstitutecode, Pprovisiondate, Vcur);

        FETCH Vcur
            INTO Pinstituteinfo;

        CLOSE Vcur;

        Vclaiminsttype := Pinstituteinfo.Claim_Inst_Type;
        Getnetworkclaiminsttype(Pcontractid, Ppartitionno, Trunc(Pprovisiondate), Pinstitutecode, Vclaiminsttypenew, Vclaiminsttypedesc);

        IF Vclaiminsttypenew IS NOT NULL
        THEN
            Vclaiminsttype := Vclaiminsttypenew;
        END IF;

        Vinstcitycode := Koc_Clm_Hlth_Utils.Getcitycodebypartid(Pinstituteinfo.Part_Id);

        Getnewclaiminsttype(Ppackageid, Vclaiminsttype, Pinstitutecode, Vinstcitycode, Vclaiminsttypenew);

        IF Vclaiminsttypenew IS NOT NULL
        THEN
            Vclaiminsttype := Vclaiminsttypenew;
        END IF;

        Pinstituteinfo.Claim_Inst_Type := Vclaiminsttype;
    END;

     PROCEDURE Choosecover(Phlthdetail      IN Customer.Hlth_Detail_Row_Type,
                                                Phlthproc        IN OUT Customer.Hlth_Proc_Detail_Table_Type,
                                                Phlthmedicine    IN OUT Customer.Medicine_Indem_Det_Table_Type,
                                                Phlthitem        IN OUT Customer.Hltprv_Dml_Item_Tbl,
                                                Phlthprovision   IN OUT Customer.Hlth_Provisions_Table_Type,
                                                Phltbreprovision IN Customer.Hltprv_Bre_Provision_Typ) IS
        CURSOR Crinfo(Pcontractid    NUMBER,
                                    Ppartitionno   NUMBER,
                                    Pprovisiondate DATE,
                                    Pclaiminsttype VARCHAR2,
                                    Pclaiminstloc  VARCHAR2,
                                    Pcovercode     VARCHAR2,
                                    Pcountrygroup  NUMBER) IS
            SELECT f_Day_Seance,
                         Swift_Code,
                         Is_Pool_Cover,
                         Is_Special_Cover
                FROM Koc_Clm_Hlth_Indem_Totals a
             WHERE Contract_Id = Pcontractid
                 AND Partition_No = Ppartitionno
                 AND Claim_Inst_Type = Pclaiminsttype
                 AND Claim_Inst_Loc = Pclaiminstloc
                 AND Country_Group = Nvl(Pcountrygroup, 0)
                 AND Cover_Code = Pcovercode
                 AND Is_Valid = 1
                 AND Validity_Start_Date <= Pprovisiondate
                 AND Validity_End_Date >= Pprovisiondate;

        Recinfo        Crinfo%ROWTYPE;
        Vinstituteinfo Koc_v_Clm_Suppliers%ROWTYPE;
        Cur            KOC_CLM_HLTH_TRNX.Refcur;
        Vprovisionrow  Koc_Clm_Hlth_Provisions%ROWTYPE;
        Vcount         NUMBER;
        Vswiftcode     Koc_Clm_Hlth_Provisions.Swift_Code%TYPE;

        --
        FUNCTION Getprovisionstatus(Pclaimid   IN NUMBER,
                                                                Pcovercode IN VARCHAR2) RETURN VARCHAR2 IS
            Vstatuscode Koc_Clm_Hlth_Provisions.Status_Code%TYPE;
        BEGIN
            SELECT Status_Code
                INTO Vstatuscode
                FROM Koc_Clm_Hlth_Provisions
             WHERE Claim_Id = Pclaimid
                 AND Sf_No = 1
                 AND Add_Order_No = 1
                 AND Cover_Code = Pcovercode;

            RETURN Vstatuscode;
        EXCEPTION
            WHEN OTHERS THEN
                RETURN NULL;
        END;

        --
        PROCEDURE Writelog IS
            Vreturn    CLOB;--VARCHAR2(32767); SBH-2749
            Hltprv_Log Hltprv_Log_Typ;
        BEGIN
            dbms_lob.createtemporary(Vreturn,true);
            Vreturn := '-->se�ilen teminatlar' || Chr(10);

            --
            IF Phlthprovision IS NOT NULL
            THEN
                --
                FOR i IN 1 .. Phlthprovision.Count
                LOOP
                    Vreturn := Vreturn || 'HLTH_PROVISIONS_TABLE_TYPE' || Chr(10);

                    Vreturn := Vreturn || 'claim_id          : ' || Phlthprovision(i).Claim_Id || Chr(10);
                    Vreturn := Vreturn || 'sf_no             : ' || Phlthprovision(i).Sf_No || Chr(10);
                    Vreturn := Vreturn || 'location_code     : ' || Phlthprovision(i).Location_Code || Chr(10);
                    Vreturn := Vreturn || 'cover_code        : ' || Phlthprovision(i).Cover_Code || Chr(10);
                    Vreturn := Vreturn || 'swift_code        : ' || Phlthprovision(i).Swift_Code || Chr(10);
                    Vreturn := Vreturn || 'status_code       : ' || Phlthprovision(i).Status_Code || Chr(10);
                    Vreturn := Vreturn || 'user_id           : ' || Phlthprovision(i).User_Id || Chr(10);
                    Vreturn := Vreturn || 'entry_date        : ' || Phlthprovision(i).Entry_Date || Chr(10);
                    Vreturn := Vreturn || 'country_code      : ' || Phlthprovision(i).Country_Code || Chr(10);
                    Vreturn := Vreturn || 'exemption_rate    : ' || Phlthprovision(i).Exemption_Rate || Chr(10);
                    Vreturn := Vreturn || 'add_order_no      : ' || Phlthprovision(i).Add_Order_No || Chr(10);
                    Vreturn := Vreturn || 'is_pool_cover     : ' || Phlthprovision(i).Is_Pool_Cover || Chr(10);
                    Vreturn := Vreturn || 'is_special_cover  : ' || Phlthprovision(i).Is_Special_Cover || Chr(10);
                    Vreturn := Vreturn || 'prov_date_time    : ' || Phlthprovision(i).Prov_Date_Time || Chr(10);
                    Vreturn := Vreturn || 'f_day_seans       : ' || Phlthprovision(i).f_Day_Seans || Chr(10);
                    Vreturn := Vreturn || 'request_amount    : ' || Phlthprovision(i).Request_Amount || Chr(10);
                END LOOP;
            END IF;

            Hltprv_Log := Hltprv_Log_Typ();

            Hltprv_Log.Log_Id      := Phltbreprovision.Logid;
            Hltprv_Log.Content     := Vreturn;
            Hltprv_Log.Processinfo := 'HLTH_PROVISIONS_TABLE_TYPE';

            Hltprv_Log.Savelogwithpragma('YES');
            dbms_lob.freetemporary(Vreturn);
        Exception when others then null; -- SBH-2749 loga yazamama hatas� provizyonu durdurmamal�
        END;
    BEGIN
        DBMS_OUTPUT.PUT_LINE('chose_cover_start');
        Vswiftcode := Base_Swift_Code;

        Phlthprovision := Customer.Hlth_Provisions_Table_Type();

        Getinstituteinfo(Phlthdetail.Contract_Id, Phlthdetail.Oar_No, Phlthdetail.Package_Id, Phlthdetail.Institute_Code, Phlthdetail.Provision_Date,
                                         Vinstituteinfo);

        Choosecoverfrombre(Phlthdetail, Phltbreprovision, Phlthproc, Phlthprovision);
        
        --YT �n onay sonras� g�ncelleme
        --
        IF Inpatientpreapprove(Phlthdetail.Claim_Id, Phlthdetail.Sf_No, Phlthdetail.Location_Code) > 0
        THEN
            Choosecoverforpreapprove(Phlthdetail, Vinstituteinfo, Phlthproc, Phlthmedicine, Phlthitem, Phlthprovision, Phltbreprovision);
        ELSE
            Choosecoverforproc(Phlthdetail, Phlthproc, Vinstituteinfo, Phlthprovision, Phltbreprovision);

            Choosecoverforitem(Phlthdetail, Phlthitem, Phlthproc, Vinstituteinfo, Phlthprovision);

            Choosecoverformedicine(Phlthdetail, Phlthmedicine, Vinstituteinfo, Phlthprovision);
        END IF;

        FOR i IN 1 .. Phlthprovision.Count
        LOOP
            OPEN Crinfo(Phlthdetail.Contract_Id, Phlthdetail.Oar_No, Phlthdetail.Provision_Date, Vinstituteinfo.Claim_Inst_Type,
                                    Vinstituteinfo.Claim_Inst_Loc, Phlthprovision(i).Cover_Code, NULL);

            FETCH Crinfo
                INTO Recinfo;

            CLOSE Crinfo;

            Phlthprovision(i).f_Day_Seans := Recinfo.f_Day_Seance;
            Phlthprovision(i).Is_Special_Cover := Nvl(Recinfo.Is_Special_Cover, 0);
            Phlthprovision(i).Is_Pool_Cover := Nvl(Recinfo.Is_Pool_Cover, 0);
            Phlthprovision(i).Swift_Code := Nvl(Recinfo.Swift_Code, Vswiftcode);

            Phlthprovision(i).Status_Code := Getprovisionstatus(Phlthdetail.Claim_Id, Phlthprovision(i).Cover_Code);
        END LOOP;

        --se�ili teminatlar loglans�n
        Writelog;
    END;

    PROCEDURE Transclaimfile(Phlthdetail IN OUT Customer.Hlth_Detail_Row_Type) IS
        Cur              KOC_CLM_HLTH_TRNX.Refcur;
        Vfirstagentintid NUMBER;
        Vfirstsubagent   NUMBER;
        Vclmsfid         NUMBER;
        Policyinfo       Koc_v_Hlth_Insured_Info_Indem%ROWTYPE;
        Vprovisiondate   DATE;
        Vclmstatus       VARCHAR2(20);
    BEGIN
        /*
    clm_status open - cancelled - pending - closed
    manual_claim    - y - n
    */

        IF Phlthdetail.Status_Code = 'R'
        THEN
            Vprovisiondate := NULL;
        ELSE
            Vprovisiondate := Phlthdetail.Provision_Date;
        END IF;

        Koc_Clm_Hlth_Utils.Getpolinfoforindemnity(Phlthdetail.Contract_Id, Phlthdetail.Oar_No, Phlthdetail.Part_Id, Vprovisiondate, Cur);

        FETCH Cur
            INTO Policyinfo;

        CLOSE Cur;

        Vfirstagentintid := Koc_Clm_Hlth_Trnx.Getfirstagent(Policyinfo.Contract_Id);
        Vfirstsubagent   := Koc_Clm_Hlth_Trnx.Getfirstsubagent(Policyinfo.Contract_Id);

        Vclmstatus := 'OPEN';

        IF Phlthdetail.Status_Code = 'R'
        THEN
            Vclmstatus := 'CLOSED';
        END IF;

        INSERT INTO Clm_Bases
            (Claim_Id, Clm_Status, Clm_Line_Id, Manual_Claim, Date_Reported, Chargeable_Code)
        VALUES
            (Phlthdetail.Claim_Id, Vclmstatus, 20, 'N', SYSDATE, 0);

        INSERT INTO Clm_Pol_Bases
            (Claim_Id,
             Contract_Id,
             Product_Id,
             Prod_Version,
             Contract_Status,
             Term_Start_Date,
             Term_End_Date,
             Version_No,
             Date_Of_Loss,
             Policy_Ref,
             Agent_Role)
        VALUES
            (Phlthdetail.Claim_Id,
             Policyinfo.Contract_Id,
             Policyinfo.Product_Id,
             NULL,
             Policyinfo.Contract_Status,
             Policyinfo.Term_Start_Date,
             Policyinfo.Term_End_Date,
             Policyinfo.Version_No,
             Phlthdetail.Provision_Date,
             Policyinfo.Policy_Ref,
             Vfirstagentintid);

        INSERT INTO Clm_Pol_Oar
            (Claim_Id, Contract_Id, Oar_No, Version_No)
        VALUES
            (Phlthdetail.Claim_Id, Policyinfo.Contract_Id, Policyinfo.Partition_No, Phlthdetail.Version_No);

        SELECT Clm_Sf_Id_Seq.Nextval INTO Vclmsfid FROM Dual;

        INSERT INTO Clm_Subfiles
            (Claim_Id, Sf_No, Sf_Type, Clm_Status, Sf_Desc, Sf_Id, Ext_Reference)
        VALUES
            (Phlthdetail.Claim_Id, 1, 'HLT', Vclmstatus, '', Vclmsfid, Phlthdetail.Ext_Reference);

        INSERT INTO Koc_Clm_Subfiles_Ext
            (Claim_Id,
             Sf_No,
             Product_Id,
             Term_Start_Date,
             Term_End_Date,
             Date_Of_Loss,
             Policy_Ref,
             Oldsys_Policy_No,
             Manual_Claim,
             Convert_Flag,
             Partition_Type,
             Agent_Role,
             Sub_Agent)
        VALUES
            (Phlthdetail.Claim_Id,
             1,
             Policyinfo.Product_Id,
             Policyinfo.Term_Start_Date,
             Policyinfo.Term_End_Date,
             Phlthdetail.Provision_Date,
             Policyinfo.Policy_Ref,
             Policyinfo.Oldsys_Policy_No,
             'N',
             NULL,
             Policyinfo.Partition_Type,
             Vfirstagentintid,
             Vfirstsubagent);

        INSERT INTO Clm_Interested_Parties
            (Claim_Id, Ip_No, Object_Type, Part_Id, Ins_Obj_Uid, Ip_Type, Version_No, Object_Id, Claimant)
        VALUES
            (Phlthdetail.Claim_Id,
             Policyinfo.Ip_No,
             'CLM',
             Phlthdetail.Part_Id,
             Phlthdetail.Claim_Id,
             'INS',
             Policyinfo.Version_No,
             Phlthdetail.Part_Id,
             'N');
    END;

   PROCEDURE Transclaimtorecover(Pclaimid IN NUMBER) IS
    BEGIN
        Koc_Clm_Hlth_Hospt_Utils.Delete_Clm_From_Web(Pclaimid);

        --
        INSERT INTO Web_Clm_Hlth_Detail
            (Claim_Id,
             Sf_No,
             Process_Date,
             Communication_No,
             Close_Date,
             Group_Code,
             Provision_Fee_Charge_Date,
             Is_Patient_Visit_Made,
             Identitiy_Type,
             Identity_No,
             Institute_Code,
             Provision_Date,
             Provision_User_Id,
             Hospitalize_Date,
             Discharge_Date,
             Hospitalize_Appr_Form_Expl_1,
             Hospitalize_Appr_Form_Expl_2,
             Class_Disease_1,
             Class_Disease_2,
             Class_Disease_3,
             Claim_Inst_Type,
             Claim_Inst_Loc,
             Orig_Claim_Inst_Type,
             Orig_Claim_Inst_Loc,
             Specialty_Subject,
             Explanation,
             Status_Code,
             Part_Id,
             Ext_Reference,
             Dr_Name_Lastname,
             Prescription_Date,
             Prescription_No,
             Soc_Sec_Inst_App,
             e_Prescription_No,
             Add_Order_No,
             Invoice_Date,
             Invoice_No,
             Invoice_Total,
             Payment_Total,
             Invoice_Explanation,
             Country_Code,
             Deduction_Rate,
             Is_Urgent_Cure,
             Shipping_Date,
             Shipping_No,
             Is_Wrong_Provision,
             Inst_Tax_Number,
             Inst_Tax_Office,
             Final_Class_Disease_1,
             Final_Class_Disease_2,
             Final_Class_Disease_3,
             Swift_Code,
             Dr_Diploma_No,
             Realization_Date,
             Comm_Date,
             Contract_Message,
             Date_Of_Loss,
             Package_Id,
             Package_Date,
             Rel_Claim_Id,
             Prov_Demand_Date,
             Sgk_Total,
             Is_Sgk_Used,
             Prescription_Type,
             Poss_Hospitalize_Date,
             Poss_Discharge_Date,
             Exam_Date,
             Is_Ext_Doctor,
             Ext_Doctor_Amt,
             Hospital_Amt,
             Doctor_Code,
             Process_Exp,
             Is_Web,
             From_City_Code,
             From_District_Code,
             To_City_Code,
             To_District_Code,
             From_To_Place,
             Other_Country_City,
             Web_Location_Code,
             Patient_Complaint,
             Complaint_Start,
             Last_Menst_Date,
             Before_Complaint_Illness,
             Medical_Background,
             Consultation_Diagnosis,
             Examinations_Results,
             Prediagnosis_Diagnosis,
             Planned_Treatment_Proc,
             Other_Country,
             Time_Stamp,
             Is_Pregnant,
             Inst_Gln_Code,
             Surgery_Date,
             Is_Judicial,
             Nationality,
             Identity_Number,
             Communication_Exp1,
             Communication_Number1,
             Communication_Number2,
             Communication_Exp2,
             Yt_Type,
             Doctor_Type,
             Doctor_Status,
             Is_Referral,
             Referral_Institute_Name,
             Personal_Notes,
             Patient_Admittance_Date,
             Request_Amount,
             Hlth_Srv_Pay,
             Dh_Inst,
             Hospital_Ref_No,
             Request_System,
             Bre_Result_Code,
             Is_Complementary,
             Is_Ahek,
             Sgk_Ref_No,
             Affluent_Flag,
             Cpa_Status,
             Is_Original,
             Has_Unreadable_Doc,
             Visiting_Reason,
             Is_Only_Examination_Fee,
             Is_Ok,
             Is_Ex_Gratia,
             Ex_Gratia_Fee,
             Is_Automated,
             Is_Suspense,
             Suspense_Date,
             medula_date)
            SELECT Claim_Id,
                         Sf_No,
                         Process_Date,
                         Communication_No,
                         Close_Date,
                         Group_Code,
                         Provision_Fee_Charge_Date,
                         Is_Patient_Visit_Made,
                         Identitiy_Type,
                         Identity_No,
                         Institute_Code,
                         Provision_Date,
                         Provision_User_Id,
                         Hospitalize_Date,
                         Discharge_Date,
                         Hospitalize_Appr_Form_Expl_1,
                         Hospitalize_Appr_Form_Expl_2,
                         Class_Disease_1,
                         Class_Disease_2,
                         Class_Disease_3,
                         Claim_Inst_Type,
                         Claim_Inst_Loc,
                         Orig_Claim_Inst_Type,
                         Orig_Claim_Inst_Loc,
                         Specialty_Subject,
                         Explanation,
                         Status_Code,
                         Part_Id,
                         Ext_Reference,
                         Dr_Name_Lastname,
                         Prescription_Date,
                         Prescription_No,
                         Soc_Sec_Inst_App,
                         e_Prescription_No,
                         Add_Order_No,
                         Invoice_Date,
                         Invoice_No,
                         Invoice_Total,
                         Payment_Total,
                         Invoice_Explanation,
                         Country_Code,
                         Deduction_Rate,
                         Is_Urgent_Cure,
                         Shipping_Date,
                         Shipping_No,
                         Is_Wrong_Provision,
                         Inst_Tax_Number,
                         Inst_Tax_Office,
                         Final_Class_Disease_1,
                         Final_Class_Disease_2,
                         Final_Class_Disease_3,
                         Swift_Code,
                         Dr_Diploma_No,
                         Realization_Date,
                         Comm_Date,
                         Contract_Message,
                         Date_Of_Loss,
                         Package_Id,
                         Package_Date,
                         Rel_Claim_Id,
                         Prov_Demand_Date,
                         Sgk_Total,
                         Is_Sgk_Used,
                         Prescription_Type,
                         Poss_Hospitalize_Date,
                         Poss_Discharge_Date,
                         Exam_Date,
                         Is_Ext_Doctor,
                         Ext_Doctor_Amt,
                         Hospital_Amt,
                         Doctor_Code,
                         Process_Exp,
                         Is_Web,
                         From_City_Code,
                         From_District_Code,
                         To_City_Code,
                         To_District_Code,
                         From_To_Place,
                         Other_Country_City,
                         Web_Location_Code,
                         Patient_Complaint,
                         Complaint_Start,
                         Last_Menst_Date,
                         Before_Complaint_Illness,
                         Medical_Background,
                         Consultation_Diagnosis,
                         Examinations_Results,
                         Prediagnosis_Diagnosis,
                         Planned_Treatment_Proc,
                         Other_Country,
                         Time_Stamp,
                         Is_Pregnant,
                         Inst_Gln_Code,
                         Surgery_Date,
                         Is_Judicial,
                         Nationality,
                         Identity_Number,
                         Communication_Exp1,
                         Communication_Number1,
                         Communication_Number2,
                         Communication_Exp2,
                         Yt_Type,
                         Doctor_Type,
                         Doctor_Status,
                         Is_Referral,
                         Referral_Institute_Name,
                         Personal_Notes,
                         Patient_Admittance_Date,
                         Request_Amount,
                         Hlth_Srv_Pay,
                         Dh_Inst,
                         Hospital_Ref_No,
                         Request_System,
                         Bre_Result_Code,
                         Is_Complementary,
                         Is_Ahek,
                         Sgk_Ref_No,
                         Affluent_Flag,
                         Cpa_Status,
                         Is_Original,
                         Has_Unreadable_Doc,
                         Visiting_Reason,
                         Is_Only_Examination_Fee,
                         Is_Ok,
                         Is_Ex_Gratia,
                         Ex_Gratia_Fee,
                         Is_Automated,
                         Is_Suspense,
                         Suspense_Date,
                         medula_date
                FROM Koc_Clm_Hlth_Detail
             WHERE Claim_Id = Pclaimid
                 AND Sf_No = 1
                 AND Add_Order_No = 1;

        --
        INSERT INTO Web_Clm_Hlth_Proc_Detail
            (Claim_Id,
             Sf_No,
             Location_Code,
             Add_Order_No,
             Cover_Code,
             Group_No,
             Process_Code_Main,
             Process_Code_Sub1,
             Process_Code_Sub2,
             Discount_Group_Code,
             Indemnity_Amount,
             Process_Group,
             Userid,
             Entrance_Date,
             Process_Count,
             Status_Code,
             Swift_Code,
             Inst_Indemnity_Amount,
             Explanation,
             Time_Stamp,
             Drg_Code,
             Doctor_Code,
             Doctor_Status,
             Sgk_Amount,
             Order_No,
             Vat_Rate,
             Right_Left,
             Proc_Type,
             Physiotherapy_Session,
             Diagnosis_Id,
             Surgery_Id,
             Seq_No,
             Bre_Result_Code,
             Req_Process_Name,
             Req_Process_Code,
             Req_Process_List_Type,
             Related_Process,
             Related_Process_List_Type,
             process_date)
            SELECT Claim_Id,
                         Sf_No,
                         Location_Code,
                         Add_Order_No,
                         Cover_Code,
                         Group_No,
                         Process_Code_Main,
                         Process_Code_Sub1,
                         Process_Code_Sub2,
                         Discount_Group_Code,
                         Indemnity_Amount,
                         Process_Group,
                         Userid,
                         Entrance_Date,
                         Process_Count,
                         Status_Code,
                         Swift_Code,
                         Inst_Indemnity_Amount,
                         Explanation,
                         Time_Stamp,
                         Drg_Code,
                         Doctor_Code,
                         Doctor_Status,
                         Sgk_Amount,
                         Order_No,
                         Vat_Rate,
                         Right_Left,
                         Proc_Type,
                         Physiotherapy_Session,
                         Diagnosis_Id,
                         Surgery_Id,
                         Seq_No,
                         Bre_Result_Code,
                         Req_Process_Name,
                         Req_Process_Code,
                         Req_Process_List_Type,
                         Related_Process,
                         Related_Process_List_Type,
                         process_date
                FROM Koc_Clm_Hlth_Proc_Detail
             WHERE Claim_Id = Pclaimid
                 AND Sf_No = 1
                 AND Add_Order_No = 1;

        --
        INSERT INTO Web_Clm_Medicine_Indem_Det
            (Claim_Id,
             Sf_No,
             Location_Code,
             Add_Order_No,
             Cover_Code,
             Barcode,
             Unit,
             Dose_Period,
             Dose1,
             Dose2,
             Price,
             Class_Disease_4,
             Second_Barcode,
             Equ_Medicine_App,
             Dose3,
             Dose3_Period,
             Expiry_Date,
             Status_Code,
             Dose4,
             Dose4_Period,
             Reject_Uncheck,
             Reject_Unit,
             Reject_Explanation,
             Control_Expiry_Date,
             Second_Barc_Given,
             Note_Id,
             Time_Stamp,
             Item_Type,
             Drg_Code,
             Order_No,
             Surgery_Id,
             Vat_Rate,
             Explanation,
             Seq_No,
             Bre_Result_Code,
             Process_Code,
             Process_Code_List,
             Req_Medicine_Name,
             Req_Medicine_Barcode)
            SELECT Claim_Id,
                         Sf_No,
                         Location_Code,
                         Add_Order_No,
                         Cover_Code,
                         Barcode,
                         Unit,
                         Dose_Period,
                         Dose1,
                         Dose2,
                         Price,
                         Class_Disease_4,
                         Second_Barcode,
                         Equ_Medicine_App,
                         Dose3,
                         Dose3_Period,
                         Expiry_Date,
                         Status_Code,
                         Dose4,
                         Dose4_Period,
                         Reject_Uncheck,
                         Reject_Unit,
                         Reject_Explanation,
                         Control_Expiry_Date,
                         Second_Barc_Given,
                         Note_Id,
                         Time_Stamp,
                         Item_Type,
                         Drg_Code,
                         Order_No,
                         Surgery_Id,
                         Vat_Rate,
                         Explanation,
                         Seq_No,
                         Bre_Result_Code,
                         Process_Code,
                         Process_Code_List,
                         Req_Medicine_Name,
                         Req_Medicine_Barcode
                FROM Koc_Clm_Medicine_Indem_Det
             WHERE Claim_Id = Pclaimid
                 AND Sf_No = 1
                 AND Add_Order_No = 1;

        --
        INSERT INTO Web_Clm_Hlth_Item_Detail
            (Claim_Id,
             Sf_No,
             Location_Code,
             Add_Order_No,
             Cover_Code,
             Ubb_Code,
             Quantity,
             Price,
             Item_Type,
             Drg_Code,
             Order_No,
             Surgery_Id,
             Vat_Rate,
             Explanation,
             Status_Code,
             Time_Stamp,
             Seq_No,
             Bre_Result_Code,
             Process_Code,
             Process_Code_List,
             Req_Item_Name,
             Req_Item_Ubbcode)
            SELECT Claim_Id,
                         Sf_No,
                         Location_Code,
                         Add_Order_No,
                         Cover_Code,
                         Ubb_Code,
                         Quantity,
                         Price,
                         Item_Type,
                         Drg_Code,
                         Order_No,
                         Surgery_Id,
                         Vat_Rate,
                         Explanation,
                         Status_Code,
                         Time_Stamp,
                         Seq_No,
                         Bre_Result_Code,
                         Process_Code,
                         Process_Code_List,
                         Req_Item_Name,
                         Req_Item_Ubbcode
                FROM Koc_Clm_Hlth_Item_Detail
             WHERE Claim_Id = Pclaimid
                 AND Sf_No = 1
                 AND Add_Order_No = 1;

        --
        INSERT INTO Web_Clm_Hlth_Provisions
            (Claim_Id,
             Sf_No,
             Location_Code,
             Cover_Code,
             Provision_Total,
             Provision_Explanation,
             Day_Seance,
             Request_Amount,
             Refusal_Amount,
             Exemption_Amount,
             Swift_Code,
             Req_Cure_Day_Count,
             Status_Code,
             User_Id,
             Entry_Date,
             Country_Code,
             Exemption_Rate,
             Proc_Request_Amount,
             Proc_Refusal_Amount,
             Inst_Exemption_Amount,
             Add_Order_No,
             Is_Ex_Gratia,
             Is_Pool_Cover,
             Is_Special_Cover,
             Inst_Request_Amount,
             Sys_Request_Amount,
             r_Cover_Price,
             Prov_Date_Time,
             Sgk_Amount,
             Add_Proc_Amount,
             Time_Stamp,
             Order_No,
             Doctor_Code,
             Doctor_Status,
             Bre_Result_Code,
             Sub_Package_Id,
             Sub_Package_Date)
            SELECT Claim_Id,
                         Sf_No,
                         Location_Code,
                         Cover_Code,
                         Provision_Total,
                         Provision_Explanation,
                         Day_Seance,
                         Request_Amount,
                         Refusal_Amount,
                         Exemption_Amount,
                         Swift_Code,
                         Req_Cure_Day_Count,
                         Status_Code,
                         User_Id,
                         Entry_Date,
                         Country_Code,
                         Exemption_Rate,
                         Proc_Request_Amount,
                         Proc_Refusal_Amount,
                         Inst_Exemption_Amount,
                         Add_Order_No,
                         Is_Ex_Gratia,
                         Is_Pool_Cover,
                         Is_Special_Cover,
                         Inst_Request_Amount,
                         Sys_Request_Amount,
                         r_Cover_Price,
                         Prov_Date_Time,
                         Sgk_Amount,
                         Add_Proc_Amount,
                         Time_Stamp,
                         Order_No,
                         Doctor_Code,
                         Doctor_Status,
                         Bre_Result_Code,
                         Sub_Package_Id,
                         Sub_Package_Date
                FROM Koc_Clm_Hlth_Provisions
             WHERE Claim_Id = Pclaimid
                 AND Sf_No = 1
                 AND Add_Order_No = 1;

        --
        INSERT INTO Web_Clm_Hlth_Reject_Loss
            (Claim_Id,
             Sf_No,
             Location_Code,
             Add_Order_No,
             Cover_Code,
             Process_Code_Main,
             Process_Code_Sub1,
             Process_Code_Sub2,
             Main_Code,
             Item_Code,
             Sub_Item_Code,
             Refuse_Explanation,
             Refuse_Amount,
             Userid,
             Entry_Date,
             Barcode,
             Time_Stamp,
             Is_Bre_Decision,
             Seq_No,
             Ubb_Code)
            SELECT Claim_Id,
                         Sf_No,
                         Location_Code,
                         Add_Order_No,
                         Cover_Code,
                         Process_Code_Main,
                         Process_Code_Sub1,
                         Process_Code_Sub2,
                         Main_Code,
                         Item_Code,
                         Sub_Item_Code,
                         Refuse_Explanation,
                         Refuse_Amount,
                         Userid,
                         Entry_Date,
                         Barcode,
                         Time_Stamp,
                         Is_Bre_Decision,
                         Seq_No,
                         Ubb_Code
                FROM Koc_Clm_Hlth_Reject_Loss
             WHERE Claim_Id = Pclaimid
                 AND Sf_No = 1
                 AND Add_Order_No = 1;
    END;

  PROCEDURE Choosemondialprocess(Phlthdetail IN Customer.Hlth_Detail_Row_Type,
                                                                 Phlthproc   OUT Customer.Hlth_Proc_Detail_Table_Type) IS
        Vcalculatedprice NUMBER;
        Vprocesscodesub2 NUMBER;
        Vprocesscount    NUMBER;
    BEGIN
        IF Phlthdetail.Mondial_Type NOT IN (1, 2)
        THEN
            RETURN;
        END IF;

        Phlthproc := Customer.Hlth_Proc_Detail_Table_Type();
        Phlthproc.Extend;

        IF Phlthdetail.Mondial_Type = 1
        THEN
            --Ambulans Hizm.�stanbul i�i
            Vprocesscodesub2 := 101;
            Vprocesscount    := 1;
        ELSIF Phlthdetail.Mondial_Type = 2
        THEN
            IF Nvl(Phlthdetail.Process_Count, 0) > 0 -- gidilen kilometre
            THEN
                --Ambulans Hizm.�stanbul D���/Km Ba��
                Vprocesscodesub2 := 103;
                Vprocesscount    := Phlthdetail.Process_Count;
            ELSE
                --Ambulans Hizm.�stanbul D��� Genel fiyat
                Vprocesscodesub2 := 102;
                Vprocesscount    := 1;
            END IF;
        END IF;

        Koc_Clm_Hlth_Hospt_Utils.Gethlthprocessprice(Phlthdetail.Institute_Code, 75, 50, Vprocesscodesub2, Phlthdetail.Provision_Date, NULL, 0
                                                                                                    --phlthdetail.iscomplementary
                                                                                                , Phlthdetail.Isahek, Vcalculatedprice);

        Vcalculatedprice := Round(Vcalculatedprice, 2);

        Phlthproc(Phlthproc.Count) := Hlth_Proc_Detail_Row_Type(Phlthdetail.Claim_Id, Phlthdetail.Sf_No, Phlthdetail.Location_Code, NULL, NULL, NULL, 75,
                                                                                                                        50, Vprocesscodesub2, Vcalculatedprice, Phlthdetail.Provision_User_Id, 'PP',
                                                                                                                        Vcalculatedprice, Vprocesscount, NULL, NULL, 'I', NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                                                                                                                        NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                                                                                                                        NULL, NULL, NULL, NULL, NULL,NULL);
    END;
      PROCEDURE Transclaimdetail(Phlthdetail      IN OUT Customer.Hlth_Detail_Row_Type,
                                                         Phlthprovision   IN Customer.Hlth_Provisions_Table_Type,
                                                         Phlthbredecision IN Customer.Hltprv_Bre_Decision_Tbl DEFAULT NULL) IS
        Instituteinfo      Koc_v_Clm_Suppliers%ROWTYPE;
        Vorigclaiminsttype Koc_Clm_Hlth_Indem_Totals.Claim_Inst_Type%TYPE;
        Vorigclaiminstloc  Koc_Clm_Hlth_Indem_Totals.Claim_Inst_Loc%TYPE;

        Vclaiminsttype        Koc_Clm_Hlth_Indem_Totals.Claim_Inst_Type%TYPE;
        Vclaiminstloc         Koc_Clm_Hlth_Indem_Totals.Claim_Inst_Loc%TYPE;
        Vclaiminsttypenew     Koc_Clm_Hlth_Indem_Totals.Claim_Inst_Type%TYPE;
        Vspecialtysubject     Koc_Clm_Hlth_Detail.Specialty_Subject%TYPE;
        Vclaiminsttypenewdesc VARCHAR2(100);
        Vulakprovisiondate    date;

        Instituteref  KOC_CLM_HLTH_TRNX.Refcur;
        Vinstcitycode VARCHAR2(3);
        Vswiftcode    Koc_Clm_Hlth_Detail.Swift_Code%TYPE;

        l_Affluent_Flag            NUMBER; -- orhan topal
        x_Segment_Kodu             NUMBER; -- orhan topal
        x_Segment_Aciklamasi       VARCHAR2(200); -- orhan topal
        x_Segment_Ekran_Aciklamasi VARCHAR2(200); -- orhan topal
        l_Tckn                     VARCHAR2(20); -- orhan topal
        p_Result                   NUMBER; -- orhan topal
        x_Policy_Ref               VARCHAR2(30); -- orhan topal
    BEGIN
        IF Phlthprovision IS NOT NULL
        THEN
            IF Phlthprovision.First IS NOT NULL
            THEN
                Vswiftcode := Phlthprovision(Phlthprovision.First).Swift_Code;
            END IF;
        END IF;

        Vswiftcode := Nvl(Vswiftcode, Base_Swift_Code);

        --doktor varsa
        --
        IF Phlthdetail.Provisiondoctor IS NOT NULL
        THEN
            -- portalden gelen doktor sistemde zaten mevcut
            IF Phlthdetail.Request_System IN ('WS', 'ULAK')
            THEN
                DBMS_OUTPUT.PUT_LINE('Dotktor inserting');
                NULL;--Insertdoctorhst(Phlthdetail.Institute_Code, Phlthdetail.Provision_Date, Phlthdetail.Provisiondoctor);
            END IF;

            Phlthdetail.Doctor_Code := Phlthdetail.Provisiondoctor.Doctorcode;
        END IF;

        IF Phlthdetail.Action_Code = 'I'
        THEN
            Vspecialtysubject := Phlthdetail.Specialty_Subject;

            IF Vspecialtysubject IS NULL
            THEN
                IF Phlthdetail.Location_Code = 930
                THEN
                    Vspecialtysubject := '1470';
                ELSIF Phlthdetail.Location_Code = 940
                THEN
                    Vspecialtysubject := '1010';
                END IF;
            END IF;

            Koc_Clm_Hlth_Utils.Getinstitutinfobycode(Phlthdetail.Institute_Code, Phlthdetail.Provision_Date, Instituteref);

            FETCH Instituteref
                INTO Instituteinfo;

            CLOSE Instituteref;

            Vorigclaiminsttype := Instituteinfo.Claim_Inst_Type;
            Vorigclaiminstloc  := Instituteinfo.Claim_Inst_Loc;
            Vclaiminsttype     := Vorigclaiminsttype;
            Vclaiminstloc      := Vorigclaiminstloc;

            Getnetworkclaiminsttype(Phlthdetail.Contract_Id, Phlthdetail.Oar_No, Trunc(Phlthdetail.Provision_Date), Phlthdetail.Institute_Code,
                                                            Vclaiminsttypenew, Vclaiminsttypenewdesc);

            IF Vclaiminsttypenew IS NOT NULL
            THEN
                Vclaiminsttype := Vclaiminsttypenew;
            END IF;

            Vinstcitycode := Koc_Clm_Hlth_Utils.Getcitycodebypartid(Instituteinfo.Part_Id);

            Getnewclaiminsttype(Phlthdetail.Package_Id, Vclaiminsttype, Phlthdetail.Institute_Code, Vinstcitycode, Vclaiminsttypenew);

            IF Vclaiminsttypenew IS NOT NULL
            THEN
                Vclaiminsttype := Vclaiminsttypenew;
            END IF;

            --
            IF Phlthdetail.Breresultcode IS NULL
            THEN
                Phlthdetail.Status_Code := 'PP';
            ELSE
                Phlthdetail.Status_Code := Phlthdetail.Breresultcode;
            END IF;

            -- SBH-1885 ulak pp prov tarihi sysdate olsun
            IF Phlthdetail.Request_System = 'ULAK' then
               Vulakprovisiondate := sysdate;

            End if;

            -- orhan topal
            BEGIN
                SELECT Policy_Ref
                    INTO x_Policy_Ref
                    FROM Ocp_Policy_Bases
                 WHERE Contract_Id = Phlthdetail.Contract_Id
                     AND Rownum = 1;

                SELECT Identity_No
                    INTO l_Tckn
                    FROM Koc_Cp_Partners_Ext
                 WHERE Rownum = 1
                     AND Part_Id = Phlthdetail.Claim_Id;

                Customer.Alz_Affluent_Customer.Get_Policy_Customer_Value(x_Policy_Ref, l_Tckn, x_Segment_Kodu, x_Segment_Aciklamasi,
                                                                                                                                 x_Segment_Ekran_Aciklamasi);

                l_Affluent_Flag := x_Segment_Kodu;
            EXCEPTION
                WHEN OTHERS THEN
                    l_Affluent_Flag := NULL;
            END;

            -- orhan topal
/* INSERT INTO Meduladatelog
  (Claim_Id, Order_No, Medula_Date)
VALUES
  (Phlthdetail.Claim_Id,
   4,
   'Phlthdetail.Meduladate:' || Phlthdetail.Medula_Date  );*/

            INSERT INTO Koc_Clm_Hlth_Detail
                (Claim_Id,
                 Sf_No,
                 Add_Order_No,
                 Process_Date,
                 Group_Code,
                 Institute_Code,
                 Provision_Date,
                 Provision_User_Id,
                 Hospitalize_Date,
                 Specialty_Subject,
                 Status_Code,
                 Part_Id,
                 Ext_Reference,
                 Dr_Name_Lastname,
                 Country_Code,
                 Package_Id,
                 Package_Date,
                 Poss_Hospitalize_Date,
                 Poss_Discharge_Date,
                 Exam_Date,
                 Is_Ext_Doctor,
                 Ext_Doctor_Amt,
                 Hospital_Amt,
                 Doctor_Code,
                 Process_Exp,
                 From_City_Code,
                 From_District_Code,
                 To_City_Code,
                 To_District_Code,
                 From_To_Place,
                 Other_Country_City,
                 Is_Web,
                 Is_Sgk_Used,
                 Sgk_Total,
                 Web_Location_Code,
                 Patient_Complaint,
                 Complaint_Start,
                 Last_Menst_Date,
                 Before_Complaint_Illness,
                 Medical_Background,
                 Consultation_Diagnosis,
                 Examinations_Results,
                 Prediagnosis_Diagnosis,
                 Planned_Treatment_Proc,
                 Claim_Inst_Type,
                 Claim_Inst_Loc,
                 Orig_Claim_Inst_Type,
                 Orig_Claim_Inst_Loc,
                 Class_Disease_1,
                 Other_Country,
                 Swift_Code,
                 Is_Pregnant,
                 Is_Judicial,
                 Nationality,
                 Identity_Number,
                 Communication_Exp1,
                 Communication_Number1,
                 Communication_Exp2,
                 Communication_Number2,
                 Yt_Type,
                 Doctor_Type,
                 Time_Stamp,
                 Discharge_Date,
                 Class_Disease_2,
                 Class_Disease_3,
                 Explanation,
                 Final_Class_Disease_1,
                 Final_Class_Disease_2,
                 Final_Class_Disease_3,
                 Dr_Diploma_No,
                 Surgery_Date,
                 Doctor_Status,
                 Is_Referral,
                 Referral_Institute_Name,
                 Personal_Notes,
                 Patient_Admittance_Date,
                 Request_Amount,
                 Hospital_Ref_No,
                 Request_System,
                 Bre_Result_Code,
                 Is_Complementary, /*20150320 -- emre.elcik -- FOR TSS */
                 /*20150320-- emre.elcik-- Aile Hekimi - 20150424 emre.elcik SGK_TAKIP_NO tabloya yaz�l�yor*/
                 Is_Ahek,
                 Sgk_Ref_No,
                 Affluent_Flag, /*,
                                                   Cpa_Status,
                                                   Is_Original,
                                                   Has_Unreadable_Doc,
                                                   Visiting_Reason,
                                                   Is_Only_Examination_Fee,
                                                   Is_Ok,
                                                   Is_Ex_Gratia,
                                                   Ex_Gratia_Fee,
                                                   Is_Automated*/
                 Is_Suspense,
                 Suspense_Date,
                 medula_date,
         verifiedfrommedula)
            VALUES
                (Phlthdetail.Claim_Id,
                 Phlthdetail.Sf_No,
                 1,
                 Nvl(Vulakprovisiondate,Phlthdetail.Provision_Date),--SBH-1885 ulak ise prov date = sysdate
                 Phlthdetail.Group_Code,
                 Phlthdetail.Institute_Code,
                 Nvl(Trunc(Vulakprovisiondate),Trunc(Phlthdetail.Provision_Date)), --SBH-1885 ulak ise prov date = sysdate
                 Upper(Phlthdetail.Provision_User_Id),
                 Phlthdetail.Hospitalize_Date,
                 Vspecialtysubject,
                 Phlthdetail.Status_Code,
                 Phlthdetail.Part_Id,
                 Phlthdetail.Ext_Reference,
                 Phlthdetail.Dr_Name_Lastname,
                 Phlthdetail.Country_Code,
                 Phlthdetail.Package_Id,
                 Phlthdetail.Package_Date,
                 Phlthdetail.Poss_Hospitalize_Date,
                 Phlthdetail.Poss_Discharge_Date,
                 Phlthdetail.Exam_Date,
                 Phlthdetail.Is_Ext_Doctor,
                 Phlthdetail.Ext_Doctor_Amt,
                 Phlthdetail.Hospital_Amt,
                 Phlthdetail.Doctor_Code,
                 Phlthdetail.Process_Exp,
                 Phlthdetail.From_City_Code,
                 Phlthdetail.From_District_Code,
                 Phlthdetail.To_City_Code,
                 Phlthdetail.To_District_Code,
                 Phlthdetail.From_To_Place,
                 Phlthdetail.Other_Country_City,
                 Nvl(Phlthdetail.Is_Web, 1),
                 Phlthdetail.Is_Sgk_Used,
                 Phlthdetail.Sgk_Total,
                 Phlthdetail.Location_Code,
                 Phlthdetail.Patient_Complaint,
                 Phlthdetail.Complaint_Start,
                 Phlthdetail.Last_Menst_Date,
                 Phlthdetail.Before_Complaint_Illness,
                 Phlthdetail.Medical_Background,
                 Phlthdetail.Consultation_Diagnosis,
                 Phlthdetail.Examinations_Results,
                 Phlthdetail.Prediagnosis_Diagnosis,
                 Phlthdetail.Planned_Treatment_Proc,
                 Vclaiminsttype,
                 Vclaiminstloc,
                 Vorigclaiminsttype,
                 Vorigclaiminstloc,
                 Nvl(Phlthdetail.Class_Disease_1, 10099),
                 Phlthdetail.Other_Country,
                 Vswiftcode,
                 Phlthdetail.Is_Pregnant,
                 Phlthdetail.Is_Judicial,
                 Phlthdetail.Nationality,
                 Phlthdetail.Identity_Number,
                 Phlthdetail.Communication_Exp1,
                 Phlthdetail.Communication_Number1,
                 Phlthdetail.Communication_Exp2,
                 Phlthdetail.Communication_Number2,
                 Phlthdetail.Yt_Type,
                 Phlthdetail.Doctor_Type,
                 Phlthdetail.Time_Stamp,
                 Phlthdetail.Discharge_Date,
                 Phlthdetail.Class_Disease_2,
                 Phlthdetail.Class_Disease_3,
                 Phlthdetail.Explanation,
                 Phlthdetail.Final_Class_Disease_1,
                 Phlthdetail.Final_Class_Disease_2,
                 Phlthdetail.Final_Class_Disease_3,
                 Phlthdetail.Dr_Diploma_No,
                 Phlthdetail.Surgery_Date,
                 Phlthdetail.Doctor_Status,
                 Phlthdetail.Is_Referral,
                 Phlthdetail.Referral_Institute_Name,
                 Phlthdetail.Personal_Notes,
                 Phlthdetail.Patient_Admittance_Date,
                 Phlthdetail.Request_Amount,
                 Phlthdetail.Hospital_Ref_No,
                 Phlthdetail.Request_System,
                 Phlthdetail.Breresultcode,
                 Phlthdetail.Iscomplementary, /*20150320 -- emre.elcik -- FOR TSS */
                 /*20150320-- emre.elcik-- Aile Hekimi - 20150424 emre.elcik SGK_TAKIP_NO tabloya yaz�l�yor*/
                 Phlthdetail.Isahek,
                 Phlthdetail.Sgk_Ref_No,
                 l_Affluent_Flag,
                 /*,
         Phlthdetail.Cpa_Status,
         Phlthdetail.Is_Original,
         Phlthdetail.Has_Unreadable_Doc,
         Phlthdetail.Visiting_Reason,
         Phlthdetail.Is_Only_Examination_Fee,
         Phlthdetail.Is_Ok,
         Phlthdetail.Is_Ex_Gratia,
         Phlthdetail.Ex_Gratia_Fee,
         Phlthdetail.Is_Automated*/
                 Phlthdetail.Is_Suspense,
                 Phlthdetail.Suspense_Date,
                 Phlthdetail.medula_date,
         Phlthdetail.verifiedfrommedula);
        ELSIF Phlthdetail.Action_Code = 'U'
        THEN
            --
            IF Phlthdetail.Breresultcode IS NULL
            THEN
                Phlthdetail.Status_Code := 'CP';
            ELSIF Phlthdetail.Breresultcode = 'PP'
            THEN
                Phlthdetail.Status_Code := 'CP';
            ELSE
                Phlthdetail.Status_Code := Phlthdetail.Breresultcode;
            END IF;

            UPDATE Koc_Clm_Hlth_Detail
                 SET Status_Code              = Phlthdetail.Status_Code,
                         Institute_Code           = Phlthdetail.Institute_Code,
                         Provision_Date           = Phlthdetail.Provision_Date,
                         Web_Location_Code        = Phlthdetail.Location_Code,
                         Is_Pregnant              = Phlthdetail.Is_Pregnant,
                         Is_Judicial              = Phlthdetail.Is_Judicial,
                         Part_Id                  = Phlthdetail.Part_Id,
                         Package_Id               = Phlthdetail.Package_Id,
                         Package_Date             = Phlthdetail.Package_Date,
                         Group_Code               = Phlthdetail.Group_Code,
                         Is_Sgk_Used              = Phlthdetail.Is_Sgk_Used,
                         Sgk_Total                = Phlthdetail.Sgk_Total,
                         Provision_User_Id        = Phlthdetail.Provision_User_Id,
                         Request_Amount           = Phlthdetail.Request_Amount,
                         Personal_Notes           = Phlthdetail.Personal_Notes,
                         Yt_Type                  = Phlthdetail.Yt_Type,
                         Patient_Admittance_Date  = Phlthdetail.Patient_Admittance_Date,
                         Time_Stamp               = Phlthdetail.Time_Stamp,
                         Is_Referral              = Phlthdetail.Is_Referral,
                         Referral_Institute_Name  = Phlthdetail.Referral_Institute_Name,
                         Doctor_Code              = Phlthdetail.Doctor_Code,
                         Dr_Name_Lastname         = Phlthdetail.Dr_Name_Lastname,
                         Specialty_Subject        = Phlthdetail.Specialty_Subject,
                         Dr_Diploma_No            = Phlthdetail.Dr_Diploma_No,
                         Doctor_Type              = Phlthdetail.Doctor_Type,
                         Is_Ext_Doctor            = Phlthdetail.Is_Ext_Doctor,
                         Doctor_Status            = Phlthdetail.Doctor_Status,
                         Poss_Hospitalize_Date    = Phlthdetail.Poss_Hospitalize_Date,
                         Poss_Discharge_Date      = Phlthdetail.Poss_Discharge_Date,
                         Surgery_Date             = Phlthdetail.Surgery_Date,
                         Ext_Doctor_Amt           = Phlthdetail.Ext_Doctor_Amt,
                         Nationality              = Phlthdetail.Nationality,
                         Identity_Number          = Phlthdetail.Identity_Number,
                         Communication_Exp1       = Phlthdetail.Communication_Exp1,
                         Communication_Number1    = Phlthdetail.Communication_Number1,
                         Communication_Exp2       = Phlthdetail.Communication_Exp2,
                         Communication_Number2    = Phlthdetail.Communication_Number2,
                         Is_Web                   = Phlthdetail.Is_Web,
                         Exam_Date                = Phlthdetail.Exam_Date,
                         Process_Exp              = Phlthdetail.Process_Exp,
                         Patient_Complaint        = Phlthdetail.Patient_Complaint,
                         Complaint_Start          = Phlthdetail.Complaint_Start,
                         Last_Menst_Date          = Phlthdetail.Last_Menst_Date,
                         Before_Complaint_Illness = Phlthdetail.Before_Complaint_Illness,
                         Medical_Background       = Phlthdetail.Medical_Background,
                         Consultation_Diagnosis   = Phlthdetail.Consultation_Diagnosis,
                         Examinations_Results     = Phlthdetail.Examinations_Results,
                         Prediagnosis_Diagnosis   = Phlthdetail.Prediagnosis_Diagnosis,
                         Planned_Treatment_Proc   = Phlthdetail.Planned_Treatment_Proc,
                         From_To_Place            = Phlthdetail.From_To_Place,
                         From_City_Code           = Phlthdetail.From_City_Code,
                         From_District_Code       = Phlthdetail.From_District_Code,
                         To_City_Code             = Phlthdetail.To_City_Code,
                         To_District_Code         = Phlthdetail.To_District_Code,
                         Country_Code             = Phlthdetail.Country_Code,
                         Other_Country            = Phlthdetail.Other_Country,
                         Other_Country_City       = Phlthdetail.Other_Country_City,
                         Hospital_Ref_No          = Phlthdetail.Hospital_Ref_No,
                         Request_System           = Phlthdetail.Request_System,
                         Bre_Result_Code          = Phlthdetail.Breresultcode,
                         Swift_Code               = Vswiftcode,
                         Is_Complementary         = Phlthdetail.Iscomplementary, -- 20150320 -- emre.elcik -- FOR TSS
                         Is_Ahek                  = Phlthdetail.Isahek, -- 20150320 -- emre.elcik -- Aile Hekimi
                         Sgk_Ref_No               = Phlthdetail.Sgk_Ref_No, -- 20150424 emre.elcik SGK_TAKIP_NO tabloya yaz�l�yor
                         /* ,Cpa_Status               = Phlthdetail.Cpa_Status,
             Is_Original              = Phlthdetail.Is_Original,
             Has_Unreadable_Doc       = Phlthdetail.Has_Unreadable_Doc,
             Visiting_Reason          = Phlthdetail.Visiting_Reason,
             Is_Only_Examination_Fee  = Phlthdetail.Is_Only_Examination_Fee,
             Affluent_Flag            = Phlthdetail.Affluent_Flag,
             Is_Ok                    = Phlthdetail.Is_Ok,
             Is_Ex_Gratia             = Phlthdetail.Is_Ex_Gratia,
             Ex_Gratia_Fee            = Phlthdetail.Ex_Gratia_Fee,
             Is_Automated             = Phlthdetail.Is_Automated*/
                         Is_Suspense   = Phlthdetail.Is_Suspense,
                         Suspense_Date = Phlthdetail.Suspense_Date,
                         medula_date = Phlthdetail.medula_date,
             verifiedfrommedula = Phlthdetail.verifiedfrommedula
             WHERE Claim_Id = Phlthdetail.Claim_Id
                 AND Sf_No = Phlthdetail.Sf_No
                 AND Add_Order_No = 1;
        END IF;
    END;
      PROCEDURE Insertdiagnose(Pdiagnose IN OUT Customer.Hltprv_Dml_Diagnose_Typ) IS
    BEGIN
        IF Pdiagnose IS NULL
        THEN
            RETURN;
        END IF;

        IF Pdiagnose.Diagnosis_Id IS NULL
        THEN
            SELECT Koc_Clm_Hlth_Diagnosis_Seq.Nextval INTO Pdiagnose.Diagnosis_Id FROM Dual;
        END IF;

        INSERT INTO Koc_Clm_Hlth_Diagnosis
            (Diagnosis_Id, Claim_Id, Sf_No, Add_Order_No, Diagnosis_Code, Diagnosis_Desc, Diagnosis_Type, Diagnosis_Level)
        VALUES
            (Pdiagnose.Diagnosis_Id,
             Pdiagnose.Claim_Id,
             Pdiagnose.Sf_No,
             Pdiagnose.Add_Order_No,
             Pdiagnose.Diagnosis_Code,
             Pdiagnose.Diagnosis_Desc,
             Pdiagnose.Diagnosis_Type,
             Pdiagnose.Diagnosis_Level);
    END;

  PROCEDURE Transclaimdiagnose(Phlthdetail   IN OUT Customer.Hlth_Detail_Row_Type,
                                                             Phlthdiagnose IN OUT Customer.Hltprv_Dml_Diagnose_Tbl) IS
        Vclassdisease1      VARCHAR2(10);
        Vclassdisease2      VARCHAR2(10);
        Vclassdisease3      VARCHAR2(10);
        Vfinalclassdisease1 VARCHAR2(10);
        Vfinalclassdisease2 VARCHAR2(10);
        Vfinalclassdisease3 VARCHAR2(10);
    BEGIN
        DELETE Koc_Clm_Hlth_Diagnosis
         WHERE Claim_Id = Phlthdetail.Claim_Id
             AND Sf_No = Phlthdetail.Sf_No
             AND Add_Order_No = 1;

        IF Phlthdiagnose IS NOT NULL
        THEN
            FOR i IN 1 .. Phlthdiagnose.Count
            LOOP
                Phlthdiagnose(i).Claim_Id := Phlthdetail.Claim_Id;
                Phlthdiagnose(i).Sf_No := Phlthdetail.Sf_No;
                Phlthdiagnose(i).Add_Order_No := 1;

                Insertdiagnose(Phlthdiagnose(i));

                IF Phlthdiagnose(i).Diagnosis_Code_Allz IS NOT NULL
                THEN
                    IF Phlthdiagnose(i).Diagnosis_Type IN ('ON_TANI', 'KONSULTASYON_TANI')
                    THEN
                        IF Vclassdisease1 IS NULL
                        THEN
                            Vclassdisease1 := Phlthdiagnose(i).Diagnosis_Code_Allz;
                        ELSIF Vclassdisease2 IS NULL
                        THEN
                            Vclassdisease2 := Phlthdiagnose(i).Diagnosis_Code_Allz;
                        ELSIF Vclassdisease3 IS NULL
                        THEN
                            Vclassdisease3 := Phlthdiagnose(i).Diagnosis_Code_Allz;
                        END IF;
                    END IF;

                    IF Phlthdiagnose(i).Diagnosis_Type IN ('KESIN_TANI')
                    THEN
                        IF Vfinalclassdisease1 IS NULL
                        THEN
                            Vfinalclassdisease1 := Phlthdiagnose(i).Diagnosis_Code_Allz;
                        ELSIF Vfinalclassdisease2 IS NULL
                        THEN
                            Vfinalclassdisease2 := Phlthdiagnose(i).Diagnosis_Code_Allz;
                        ELSIF Vfinalclassdisease3 IS NULL
                        THEN
                            Vfinalclassdisease3 := Phlthdiagnose(i).Diagnosis_Code_Allz;
                        END IF;
                    END IF;
                END IF;
            END LOOP;

            --
            IF Vclassdisease1 IS NULL
            THEN
                IF Vfinalclassdisease1 IS NOT NULL
                THEN
                    Vclassdisease1 := Vfinalclassdisease1;
                END IF;
            END IF;

            UPDATE Koc_Clm_Hlth_Detail
                 SET Class_Disease_1       = Decode(Vclassdisease1, NULL, Class_Disease_1, Vclassdisease1),
                         Class_Disease_2       = Decode(Vclassdisease2, NULL, Class_Disease_2, Vclassdisease2),
                         Class_Disease_3       = Decode(Vclassdisease3, NULL, Class_Disease_3, Vclassdisease3),
                         Final_Class_Disease_1 = Decode(Vfinalclassdisease1, NULL, Final_Class_Disease_1, Vfinalclassdisease1),
                         Final_Class_Disease_2 = Decode(Vfinalclassdisease2, NULL, Final_Class_Disease_2, Vfinalclassdisease2),
                         Final_Class_Disease_3 = Decode(Vfinalclassdisease3, NULL, Final_Class_Disease_3, Vfinalclassdisease3)
             WHERE Claim_Id = Phlthdetail.Claim_Id
                 AND Sf_No = Phlthdetail.Sf_No
                 AND Add_Order_No = 1;
        END IF;
    END;
  PROCEDURE Transclaimrelationship(Phlthdetail   IN OUT Customer.Hlth_Detail_Row_Type,
                                                                     Phlthrelation IN OUT Customer.Hltprv_Relationshipinfo_Typ) IS
        Vinsuredno     VARCHAR2(50) := NULL; -- SigortaliNumarasi
        Vinsurednotype VARCHAR2(20) := NULL; -- SigortaliNumaraTipi
    BEGIN
        DELETE Alz_Hltprv_Relationship_Detail
         WHERE Claim_Id = Phlthdetail.Claim_Id
             AND Sf_No = Phlthdetail.Sf_No;

        IF Phlthrelation IS NULL
        THEN
            RETURN;
        END IF;

        IF Phlthrelation.Insuredno IS NOT NULL
        THEN
            Vinsurednotype := Phlthrelation.Insuredno(1).Insurednotype;
            Vinsuredno     := Phlthrelation.Insuredno(1).Insuredno;
        END IF;

        INSERT INTO Alz_Hltprv_Relationship_Detail
            (Claim_Id, Sf_No, Add_Order_No, Insurednotype, Insuredno, Firstname, Surname, Gender, Dateofbirth, Relationship, Mobilephone, Email)
        VALUES
            (Phlthdetail.Claim_Id,
             Phlthdetail.Sf_No,
             1,
             Vinsurednotype,
             Vinsuredno,
             Phlthrelation.Firstname,
             Phlthrelation.Surname,
             Phlthrelation.Sex,
             Phlthrelation.Dateofbirth,
             Phlthrelation.Relationship,
             Phlthrelation.Mobilephone,
             Phlthrelation.Email);
    END;
 PROCEDURE Transclaimpatientinfoform(Phlthdetail IN OUT Customer.Hlth_Detail_Row_Type,
                                                                            Pinfoform   IN OUT Customer.Hltprv_Dml_Patient_Form_Typ) IS
    BEGIN
        DELETE Koc_Clm_Hlth_Patient_Consl_Rep
         WHERE Form_Id IN (SELECT Form_Id
                                                 FROM Koc_Clm_Hlth_Patient_Info_Form
                                                WHERE Claim_Id = Phlthdetail.Claim_Id
                                                    AND Sf_No = Phlthdetail.Sf_No
                                                    AND Add_Order_No = 1);

        DELETE Koc_Clm_Hlth_Patient_Surg_Note
         WHERE Form_Id IN (SELECT Form_Id
                                                 FROM Koc_Clm_Hlth_Patient_Info_Form
                                                WHERE Claim_Id = Phlthdetail.Claim_Id
                                                    AND Sf_No = Phlthdetail.Sf_No
                                                    AND Add_Order_No = 1);

        DELETE Koc_Clm_Hlth_Patient_Exam_Info
         WHERE Form_Id IN (SELECT Form_Id
                                                 FROM Koc_Clm_Hlth_Patient_Info_Form
                                                WHERE Claim_Id = Phlthdetail.Claim_Id
                                                    AND Sf_No = Phlthdetail.Sf_No
                                                    AND Add_Order_No = 1);

        DELETE Koc_Clm_Hlth_Patient_Poly_Info
         WHERE Form_Id IN (SELECT Form_Id
                                                 FROM Koc_Clm_Hlth_Patient_Info_Form
                                                WHERE Claim_Id = Phlthdetail.Claim_Id
                                                    AND Sf_No = Phlthdetail.Sf_No
                                                    AND Add_Order_No = 1);

        DELETE Koc_Clm_Hlth_Patient_Info_Form
         WHERE Claim_Id = Phlthdetail.Claim_Id
             AND Sf_No = Phlthdetail.Sf_No
             AND Add_Order_No = 1;

        IF Pinfoform IS NULL
        THEN
            RETURN;
        END IF;

        IF Pinfoform.Form_Id IS NULL
        THEN
            SELECT Patient_Info_Form_Seq.Nextval INTO Pinfoform.Form_Id FROM Dual;
        END IF;

        IF Pinfoform.Claim_Id IS NULL
        THEN
            Pinfoform.Claim_Id     := Phlthdetail.Claim_Id;
            Pinfoform.Sf_No        := Phlthdetail.Sf_No;
            Pinfoform.Add_Order_No := 1;
        END IF;

        INSERT INTO Koc_Clm_Hlth_Patient_Info_Form
            (Form_Id,
             Claim_Id,
             Sf_No,
             Add_Order_No,
             Complaint,
             Complaint_Date,
             History,
             Is_Having_Old_Case,
             Surgery_History,
             Is_Blood_Bloodtrans,
             Is_Reg_Using_Med,
             History_Note,
             Is_Smoking,
             Is_Using_Of_Alcohol,
             Special_Case_Note,
             Is_Having_Allergy,
             Family_History,
             Physical_Exam_Findings,
             Story,
             Date_Of_Last_Menstrual,
             Is_Traffic_Accident,
             Is_Judicial,
             Is_Emergency,
             Type_Of_Admission,
             Occurring_Way_Of_Case,
             Is_Trauma_Case,
             Epicrisis_Note,
             Anesthesia_Note)
        VALUES
            (Pinfoform.Form_Id,
             Pinfoform.Claim_Id,
             Pinfoform.Sf_No,
             Pinfoform.Add_Order_No,
             Pinfoform.Complaint,
             Pinfoform.Complaint_Date,
             Pinfoform.History,
             Pinfoform.Is_Having_Old_Case,
             Pinfoform.Surgery_History,
             Pinfoform.Is_Blood_Bloodtrans,
             Pinfoform.Is_Reg_Using_Med,
             Pinfoform.History_Note,
             Pinfoform.Is_Smoking,
             Pinfoform.Is_Using_Of_Alcohol,
             Pinfoform.Special_Case_Note,
             Pinfoform.Is_Having_Allergy,
             Pinfoform.Family_History,
             Pinfoform.Physical_Exam_Findings,
             Pinfoform.Story,
             Pinfoform.Date_Of_Last_Menstrual,
             Pinfoform.Is_Traffic_Accident,
             Pinfoform.Is_Judicial,
             Pinfoform.Is_Emergency,
             Pinfoform.Type_Of_Admission,
             Pinfoform.Occurring_Way_Of_Case,
             Pinfoform.Is_Trauma_Case,
             Pinfoform.Epicrisis_Note,
             Pinfoform.Anesthesia_Note);

        --Poliklinik Kay�tlar�
        BEGIN
            IF Pinfoform.Poly_Records IS NOT NULL
            THEN
                IF Pinfoform.Poly_Records.First IS NOT NULL
                THEN
                    FOR i IN 1 .. Pinfoform.Poly_Records.Count
                    LOOP
                        IF Pinfoform.Poly_Records(i).Poly_Id IS NULL
                        THEN
                            SELECT Patient_Poly_Info_Seq.Nextval INTO Pinfoform.Poly_Records(i).Poly_Id FROM Dual;
                        END IF;

                        IF Pinfoform.Poly_Records(i).Form_Id IS NULL
                        THEN
                            Pinfoform.Poly_Records(i).Form_Id := Pinfoform.Form_Id;
                        END IF;

                        INSERT INTO Koc_Clm_Hlth_Patient_Poly_Info
                            (Poly_Id, Form_Id, Branch, Admission_Date, Content)
                        VALUES
                            (Pinfoform.Poly_Records(i).Poly_Id,
                             Pinfoform.Poly_Records(i).Form_Id,
                             Pinfoform.Poly_Records(i).Branch,
                             Pinfoform.Poly_Records(i).Admission_Date,
                             Substr(Pinfoform.Poly_Records(i).Content, 1, 4000));
                    END LOOP;
                END IF;
            END IF;
        END;

        --Tetkik Sonu�lar�
        BEGIN
            --
            IF Pinfoform.Exam_Results IS NOT NULL
            THEN
                IF Pinfoform.Exam_Results.First IS NOT NULL
                THEN
                    FOR i IN 1 .. Pinfoform.Exam_Results.Count
                    LOOP
                        IF Pinfoform.Exam_Results(i).Exam_Id IS NULL
                        THEN
                            SELECT Patient_Exam_Info_Seq.Nextval INTO Pinfoform.Exam_Results(i).Exam_Id FROM Dual;
                        END IF;

                        IF Pinfoform.Exam_Results(i).Form_Id IS NULL
                        THEN
                            Pinfoform.Exam_Results(i).Form_Id := Pinfoform.Form_Id;
                        END IF;

                        INSERT INTO Koc_Clm_Hlth_Patient_Exam_Info
                            (Exam_Id, Form_Id, Exam_Desc, Exam_Date, Content)
                        VALUES
                            (Pinfoform.Exam_Results(i).Exam_Id,
                             Pinfoform.Exam_Results(i).Form_Id,
                             Pinfoform.Exam_Results(i).Exam_Desc,
                             Pinfoform.Exam_Results(i).Exam_Date,
                             Substr(Pinfoform.Exam_Results(i).Content, 1, 4000));
                    END LOOP;
                END IF;
            END IF;
        END;

        --Ameliyat Notlar�
        --
        BEGIN
            --
            IF Pinfoform.Surgery_Note IS NOT NULL
            THEN
                IF Pinfoform.Surgery_Note.First IS NOT NULL
                THEN
                    FOR i IN 1 .. Pinfoform.Surgery_Note.Count
                    LOOP
                        IF Pinfoform.Surgery_Note(i).Form_Id IS NULL
                        THEN
                            Pinfoform.Surgery_Note(i).Form_Id := Pinfoform.Form_Id;
                        END IF;

                        INSERT INTO Koc_Clm_Hlth_Patient_Surg_Note
                            (Surgery_Note_Id, Note_Id, Form_Id, Note)
                        VALUES
                            (Pinfoform.Surgery_Note(i).Surgery_Note_Id,
                             Pinfoform.Surgery_Note(i).Note_Id,
                             Pinfoform.Surgery_Note(i).Form_Id,
                             Substr(Pinfoform.Surgery_Note(i).Note, 1, 4000));
                    END LOOP;
                END IF;
            END IF;
        END;

        --Konsultasyon Raporlar�
        --
        BEGIN
            IF Pinfoform.Consultation_Report IS NOT NULL
            THEN
                IF Pinfoform.Consultation_Report.First IS NOT NULL
                THEN
                    FOR i IN 1 .. Pinfoform.Consultation_Report.Count
                    LOOP
                        IF Pinfoform.Consultation_Report(i).Form_Id IS NULL
                        THEN
                            Pinfoform.Consultation_Report(i).Form_Id := Pinfoform.Form_Id;
                        END IF;

                        INSERT INTO Koc_Clm_Hlth_Patient_Consl_Rep
                            (Conslt_Rep_Id, Rep_Id, Form_Id, Report)
                        VALUES
                            (Pinfoform.Consultation_Report(i).Conslt_Rep_Id,
                             Pinfoform.Consultation_Report(i).Rep_Id,
                             Pinfoform.Consultation_Report(i).Form_Id,
                             Substr(Pinfoform.Consultation_Report(i).Report, 1, 4000));
                    END LOOP;
                END IF;
            END IF;
        END;
    END;
     PROCEDURE Transclaimprovision(Phlthdetail    IN Customer.Hlth_Detail_Row_Type,
                                                                Phlthproc      IN Customer.Hlth_Proc_Detail_Table_Type,
                                                                Phlthmedicine  IN Customer.Medicine_Indem_Det_Table_Type,
                                                                Phlthitem      IN Customer.Hltprv_Dml_Item_Tbl,
                                                                Phlthprovision IN OUT Customer.Hlth_Provisions_Table_Type) IS
        Vdayseance      NUMBER(3);
        Ventrydate      DATE;
        Vcovercode      VARCHAR2(10);
        Vispoolcover    NUMBER(1);
        Visspecialcover NUMBER(1);
        Vcntproc        NUMBER := 0;
        Vcntmed         NUMBER := 0;
        Vcntitem        NUMBER := 0;
    BEGIN
        DELETE Koc_Clm_Hlth_Provisions
         WHERE Claim_Id = Phlthdetail.Claim_Id
             AND Sf_No = Phlthdetail.Sf_No
             AND Add_Order_No = 1;

        --
        IF Phlthprovision IS NULL
        THEN
            RETURN;
        END IF;

        FOR i IN 1 .. Phlthprovision.Count
        LOOP
            --
            Vdayseance := Nvl(Phlthprovision(i).f_Day_Seans, 0);

            IF Vdayseance > 0
            THEN
                Vdayseance := 1;
            END IF;

            --
            Ventrydate := Phlthprovision(i).Entry_Date;

            IF Ventrydate IS NULL
            THEN
                Ventrydate := SYSDATE;
            END IF;

            --
            Vcovercode := Phlthprovision(i).Cover_Code;

            IF Vcovercode IS NULL
            THEN
                Vcovercode := '0';
            END IF;

            --
            Vispoolcover := Phlthprovision(i).Is_Pool_Cover;

            IF Vispoolcover IS NULL
            THEN
                Vispoolcover := 0;
            END IF;

            --
            Visspecialcover := Phlthprovision(i).Is_Special_Cover;

            IF Visspecialcover IS NULL
            THEN
                Visspecialcover := 0;
            END IF;

            --
            Vcntproc := 0;
            Vcntmed  := 0;
            Vcntitem := 0;

            --
            IF Phlthproc IS NOT NULL AND
                 Phlthproc.First IS NOT NULL
            THEN
                SELECT COUNT(1)
                    INTO Vcntproc
                    FROM TABLE(Phlthproc)
                 WHERE Location_Code = Phlthprovision(i).Location_Code
                     AND Cover_Code = Phlthprovision(i).Cover_Code;
            END IF;

            --
            IF Phlthmedicine IS NOT NULL AND
                 Phlthmedicine.First IS NOT NULL
            THEN
                SELECT COUNT(1)
                    INTO Vcntmed
                    FROM TABLE(Phlthmedicine)
                 WHERE Location_Code = Phlthprovision(i).Location_Code
                     AND Cover_Code = Phlthprovision(i).Cover_Code;
            END IF;

            --
            IF Phlthitem IS NOT NULL AND
                 Phlthitem.First IS NOT NULL
            THEN
                SELECT COUNT(1)
                    INTO Vcntitem
                    FROM TABLE(Phlthitem)
                 WHERE Location_Code = Phlthprovision(i).Location_Code
                     AND Cover_Code = Phlthprovision(i).Cover_Code;
            END IF;

            IF Vcntproc > 0 OR
                 Vcntmed > 0 OR
                 Vcntitem > 0
            THEN
                IF Phlthprovision(i).Status_Code IS NULL
                THEN
                    Phlthprovision(i).Status_Code := 'PP';
                ELSIF Phlthprovision(i).Status_Code = 'P'
                THEN
                    Phlthprovision(i).Status_Code := 'CP';
                ELSIF Phlthprovision(i).Status_Code = 'R'
                THEN
                    Phlthprovision(i).Status_Code := 'CP';
                ELSIF Phlthprovision(i).Status_Code = 'C'
                THEN
                    Phlthprovision(i).Status_Code := 'CP';
                END IF;
            ELSE
                Phlthprovision(i).Status_Code := 'PP';
            END IF;

            INSERT INTO Koc_Clm_Hlth_Provisions
                (Claim_Id,
                 Sf_No,
                 Add_Order_No,
                 Location_Code,
                 Cover_Code,
                 Swift_Code,
                 Status_Code,
                 User_Id,
                 Entry_Date,
                 Exemption_Rate,
                 Country_Code,
                 Is_Pool_Cover,
                 Is_Special_Cover,
                 Prov_Date_Time,
                 Day_Seance,
                 Req_Cure_Day_Count,
                 Inst_Request_Amount,
                 Sys_Request_Amount,
                 Provision_Explanation)
            VALUES
                (Phlthprovision(i).Claim_Id,
                 Phlthprovision(i).Sf_No,
                 1,
                 Phlthprovision(i).Location_Code,
                 Vcovercode,
                 Phlthprovision(i).Swift_Code,
                 Phlthprovision(i).Status_Code,
                 Phlthprovision(i).User_Id,
                 Ventrydate,
                 Phlthprovision(i).Exemption_Rate,
                 Phlthprovision(i).Country_Code,
                 Vispoolcover,
                 Visspecialcover,
                 Phlthprovision(i).Prov_Date_Time,
                 Vdayseance,
                 Vdayseance,
                 Phlthprovision(i).Request_Amount,
                 Phlthprovision(i).Request_Amount,
                 Phlthprovision(i).Provision_Explanation);
        END LOOP;
    END;
     PROCEDURE Transclaimprocess(Phlthdetail IN OUT Customer.Hlth_Detail_Row_Type,
                                                            Phlthproc   IN OUT Customer.Hlth_Proc_Detail_Table_Type) IS
    BEGIN
        IF Phlthdetail.Claim_Id IS NOT NULL
        THEN
            DELETE Koc_Clm_Hlth_Proc_Detail
             WHERE Claim_Id = Phlthdetail.Claim_Id
                 AND Sf_No = Phlthdetail.Sf_No
                 AND Add_Order_No = 1;
        END IF;

        IF Phlthproc IS NULL
        THEN
            RETURN;
        END IF;

        --
        FOR j IN 1 .. Phlthproc.Count
        LOOP
            --
            IF Phlthproc(j).Procdoctor IS NOT NULL
            THEN
                --
                IF Phlthproc(j).Procdoctor.Doctorcode IS NULL
                THEN
                    IF Phlthdetail.Provisiondoctor.Doctorcode IS NOT NULL
                    THEN
                        IF Phlthproc(j).Procdoctor.Identityno IS NOT NULL AND
                                Phlthdetail.Provisiondoctor.Identityno IS NOT NULL
                        THEN
                            IF TRIM(Phlthproc(j).Procdoctor.Identityno) = TRIM(Phlthdetail.Provisiondoctor.Identityno)
                            THEN
                                Phlthproc(j).Procdoctor.Doctorcode := Phlthdetail.Provisiondoctor.Doctorcode;
                            END IF;
                        ELSIF Phlthproc(j).Procdoctor.Diplomaregistrationno IS NOT NULL AND
                                     Phlthdetail.Provisiondoctor.Diplomaregistrationno IS NOT NULL
                        THEN
                            IF TRIM(Phlthproc(j).Procdoctor.Diplomaregistrationno) = TRIM(Phlthdetail.Provisiondoctor.Diplomaregistrationno)
                            THEN
                                Phlthproc(j).Procdoctor.Doctorcode := Phlthdetail.Provisiondoctor.Doctorcode;
                            END IF;
                        ELSIF Phlthproc(j).Procdoctor.Namesurname IS NOT NULL AND
                                     Phlthdetail.Provisiondoctor.Namesurname IS NOT NULL
                        THEN
                            IF TRIM(Phlthproc(j).Procdoctor.Namesurname) = TRIM(Phlthdetail.Provisiondoctor.Namesurname)
                            THEN
                                Phlthproc(j).Procdoctor.Doctorcode := Phlthdetail.Provisiondoctor.Doctorcode;
                            END IF;
                        END IF;
                    END IF;
                END IF;

                --kay�t var ise doktor kodu bo� ise doktor bulunamad� i�eri yeni kay�t olu�tur
                --phlthproc(j).procdoctor.doctor_code doluyor
                IF Phlthdetail.Request_System IN ('WS', 'ULAK')
                THEN
                    DBMS_OUTPUT.PUT_LINE('doktor inserting2');
                    --Insertdoctorhst(Phlthdetail.Institute_Code, Phlthdetail.Provision_Date, Phlthproc(j).Procdoctor);
                END IF;

                Phlthproc(j).Doctor_Code := Phlthproc(j).Procdoctor.Doctorcode;
            END IF;

            --
            IF Nvl(Phlthproc(j).Proc_Type, '.') = 'AMELIYAT'
            THEN
                IF Phlthproc(j).Procsurgery IS NOT NULL
                THEN
                    IF Phlthproc(j).Procsurgery.Action_Code = 'I'
                    THEN
                        ALZ_HLTPRV_UTILS.Insertsurgery(Phlthdetail, Phlthproc(j).Procsurgery);

                        IF Phlthproc(j).Procsurgery.Surgery_Id IS NULL
                        THEN
                            Raise_Application_Error(-20101, 'Ameliyat Detay� kaydedilemedi : ' || Phlthproc(j).Order_No);
                        END IF;

                        Phlthproc(j).Surgery_Id := Phlthproc(j).Procsurgery.Surgery_Id;
                    END IF;
                END IF;
            ELSIF Nvl(Phlthproc(j).Proc_Type, '.') IN ('MUAYENE', 'KONSULTASYON')
            THEN
                IF Phlthproc(j).Procdiagnose IS NOT NULL
                THEN
                    Phlthproc(j).Procdiagnose.Claim_Id := Phlthdetail.Claim_Id;
                    Phlthproc(j).Procdiagnose.Sf_No := Phlthdetail.Sf_No;
                    Phlthproc(j).Procdiagnose.Add_Order_No := 1;

                    Insertdiagnose(Phlthproc(j).Procdiagnose);

                    IF Phlthproc(j).Procdiagnose.Diagnosis_Id IS NULL
                    THEN
                        Raise_Application_Error(-20101, 'Tan� Detay� kaydedilemedi : ' || Phlthproc(j).Order_No);
                    END IF;

                    Phlthproc(j).Diagnosis_Id := Phlthproc(j).Procdiagnose.Diagnosis_Id;
                END IF;
            END IF;

            --seq_no pk alan�n�n tekrarlanan i�lemlerde artarak insert i�lemi i�in yap�ld�
            WHILE 1 = 1
            LOOP
                BEGIN
                    --
                    Phlthproc(j).Seq_No := Nvl(Phlthproc(j).Seq_No, 0) + 1;

                    --
                    IF Nvl(Phlthproc(j).Breresultcode, 'PP') = 'PP'
                    THEN
                        Phlthproc(j).Status_Code := 'PP';
                    ELSIF Nvl(Phlthproc(j).Breresultcode, 'PP') = 'R'
                    THEN
                        Phlthproc(j).Status_Code := 'PR';
                    ELSE
                        Phlthproc(j).Status_Code := Phlthproc(j).Breresultcode;
                    END IF;

                    --
                    INSERT INTO Koc_Clm_Hlth_Proc_Detail
                        (Claim_Id,
                         Sf_No,
                         Add_Order_No,
                         Location_Code,
                         Cover_Code,
                         Group_No,
                         Process_Code_Main,
                         Process_Code_Sub1,
                         Process_Code_Sub2,
                         Indemnity_Amount,
                         Userid,
                         Entrance_Date,
                         Process_Count,
                         Status_Code,
                         Swift_Code,
                         Inst_Indemnity_Amount,
                         Discount_Group_Code,
                         Process_Group,
                         Explanation,
                         Time_Stamp,
                         Drg_Code,
                         Doctor_Code,
                         Doctor_Status,
                         Sgk_Amount,
                         Order_No,
                         Vat_Rate,
                         Right_Left,
                         Proc_Type,
                         Physiotherapy_Session,
                         Diagnosis_Id,
                         Surgery_Id,
                         Seq_No,
                         Bre_Result_Code,
                         Req_Process_Name,
                         Req_Process_Code,
                         Req_Process_List_Type,
                         Related_Process,
                         Related_Process_List_Type,
                         process_date)
                    VALUES
                        (Phlthdetail.Claim_Id,
                         Phlthdetail.Sf_No,
                         1,
                         Phlthdetail.Location_Code,
                         Phlthproc(j).Cover_Code,
                         Nvl(Phlthproc(j).Group_No, 0),
                         Phlthproc(j).Process_Code_Main,
                         Phlthproc(j).Process_Code_Sub1,
                         Phlthproc(j).Process_Code_Sub2,
                         Round(Phlthproc(j).Indemnity_Amount, 2),
                         Upper(Phlthproc(j).Userid),
                         Nvl(Phlthproc(j).Entrance_Date, SYSDATE),
                         Phlthproc(j).Process_Count,
                         Phlthproc(j).Status_Code,
                         Phlthproc(j).Swift_Code,
                         Round(Phlthproc(j).Inst_Indemnity_Amount, 2),
                         Phlthproc(j).Discount_Group_Code,
                         Phlthproc(j).Process_Group,
                         Phlthproc(j).Explanation,
                         Phlthproc(j).Time_Stamp,
                         Phlthproc(j).Drg_Code,
                         Phlthproc(j).Doctor_Code,
                         Phlthproc(j).Doctor_Status,
                         Phlthproc(j).Sgk_Amount,
                         Phlthproc(j).Order_No,
                         Phlthproc(j).Vat_Rate,
                         Phlthproc(j).Right_Left,
                         Phlthproc(j).Proc_Type,
                         Phlthproc(j).Physiotherapy_Session,
                         Phlthproc(j).Diagnosis_Id,
                         Phlthproc(j).Surgery_Id,
                         Phlthproc(j).Seq_No,
                         Phlthproc(j).Breresultcode,
                         Phlthproc(j).Req_Process_Name,
                         Phlthproc(j).Req_Process_Code,
                         Phlthproc(j).Req_Process_List_Type,
                         Phlthproc(j).Related_Process,
                         Phlthproc(j).Related_Process_List_Type,
                         Phlthproc(j).process_date);

                    EXIT;
                EXCEPTION
                    WHEN Dup_Val_On_Index THEN
                        NULL;
                END;
            END LOOP;
        END LOOP;
    END;
     PROCEDURE Transclaimmedicine(Phlthdetail   IN OUT Customer.Hlth_Detail_Row_Type,
                                                             Phlthmedicine IN OUT Customer.Medicine_Indem_Det_Table_Type) IS
        CURSOR Vacc(Pbarcode NUMBER) IS
            SELECT Vaccine_Code FROM Koc_Cc_Vacc_Medicine_Rel WHERE Barcode = Pbarcode;

        CURSOR Vaccmaxorder(Pvaccinecode VARCHAR2,
                                                Ppartnerid   NUMBER) IS
            SELECT MAX(Order_No)
                FROM (SELECT MAX(Order_No) Order_No
                                FROM Rep_Clm_Vacc_Indem_Totals
                             WHERE Part_Id = Ppartnerid
                                 AND Vaccine_Code = Pvaccinecode
                            UNION
                            SELECT MAX(Order_No) Order_No
                                FROM Koc_Clm_Vacc_Indem_Totals
                             WHERE Part_Id = Ppartnerid
                                 AND Vaccine_Code = Pvaccinecode);

        Vaccrec       Vacc%ROWTYPE;
        Vvaccmaxorder NUMBER;
        Vcnt          NUMBER;
    BEGIN
        DELETE Koc_Clm_Medicine_Indem_Det
         WHERE Claim_Id = Phlthdetail.Claim_Id
             AND Sf_No = Phlthdetail.Sf_No;

        DELETE Koc_Clm_Vacc_Indem_Totals
         WHERE Claim_Id = Phlthdetail.Claim_Id
             AND Sf_No = Phlthdetail.Sf_No;

        --
        IF Phlthmedicine IS NULL
        THEN
            RETURN;
        END IF;

        --
        FOR j IN 1 .. Phlthmedicine.Count
        LOOP
            --
            WHILE 1 = 1
            LOOP
                BEGIN
                    --seq_no pk alan�n�n tekrarlanan i�lemlerde artarak insert i�lemi i�in yap�ld�
                    --
                    Phlthmedicine(j).Seq_No := Nvl(Phlthmedicine(j).Seq_No, 0) + 1;

                    --

                    --
                    IF Nvl(Phlthmedicine(j).Breresultcode, 'PP') = 'PP'
                    THEN
                        Phlthmedicine(j).Status_Code := 'PP';
                    ELSIF Nvl(Phlthmedicine(j).Breresultcode, 'PP') IN ('PR', 'R')
                    THEN
                        Phlthmedicine(j).Status_Code := 'PR';
                    ELSE
                        Phlthmedicine(j).Status_Code := Phlthmedicine(j).Breresultcode;
                    END IF;

                    INSERT INTO Koc_Clm_Medicine_Indem_Det
                        (Claim_Id,
                         Sf_No,
                         Add_Order_No,
                         Location_Code,
                         Cover_Code,
                         Barcode,
                         Price,
                         Unit,
                         Status_Code,
                         Barcode_2d,
                         Time_Stamp,
                         Item_Type,
                         Drg_Code,
                         Order_No,
                         Surgery_Id,
                         Vat_Rate,
                         Explanation,
                         Bre_Result_Code,
                         Seq_No,
                         Process_Code,
                         Process_Code_List,
                         Req_Medicine_Name,
                         Req_Medicine_Barcode)
                    VALUES
                        (Phlthdetail.Claim_Id,
                         Phlthdetail.Sf_No,
                         1,
                         Phlthdetail.Location_Code,
                         Phlthmedicine(j).Cover_Code,
                         Phlthmedicine(j).Barcode,
                         Phlthmedicine(j).Price,
                         Nvl(Phlthmedicine(j).Unit, 1),
                         Phlthmedicine(j).Status_Code,
                         0,
                         Phlthmedicine(j).Time_Stamp,
                         Phlthmedicine(j).Item_Type,
                         Phlthmedicine(j).Drg_Code,
                         Phlthmedicine(j).Order_No,
                         Phlthmedicine(j).Surgery_Id,
                         Phlthmedicine(j).Vat_Rate,
                         Phlthmedicine(j).Explanation,
                         Phlthmedicine(j).Breresultcode,
                         Phlthmedicine(j).Seq_No,
                         Phlthmedicine(j).Processcode,
                         Phlthmedicine(j).Processcodelist,
                         Phlthmedicine(j).Req_Medicine_Name,
                         Phlthmedicine(j).Req_Medicine_Barcode);

                    --
                    IF Phlthmedicine(j).Item_Type = 'ASI'
                    THEN
                        OPEN Vacc(Phlthmedicine(j).Barcode);

                        LOOP
                            FETCH Vacc
                                INTO Vaccrec;

                            EXIT WHEN Vacc%NOTFOUND;

                            Vvaccmaxorder := 0;

                            OPEN Vaccmaxorder(Vaccrec.Vaccine_Code, Phlthdetail.Part_Id);

                            FETCH Vaccmaxorder
                                INTO Vvaccmaxorder;

                            CLOSE Vaccmaxorder;

                            Vvaccmaxorder := Nvl(Vvaccmaxorder, 0) + 1;

                            BEGIN
                                INSERT INTO Koc_Clm_Vacc_Indem_Totals
                                    (Part_Id, Vaccine_Code, Order_No, Userid, Vaccine_Date, Status_Code, Entry_Date, Claim_Id, Sf_No, Add_Order_No, Barcode)
                                VALUES
                                    (Phlthdetail.Part_Id,
                                     Vaccrec.Vaccine_Code,
                                     Vvaccmaxorder,
                                     Phlthmedicine(j).User_Id,
                                     Phlthdetail.Provision_Date,
                                     Phlthmedicine(j).Status_Code,
                                     SYSDATE,
                                     Phlthdetail.Claim_Id,
                                     Phlthdetail.Sf_No,
                                     1,
                                     Phlthmedicine(j).Barcode);
                            END;
                        END LOOP;

                        CLOSE Vacc;
                    END IF;

                    EXIT;
                EXCEPTION
                    WHEN Dup_Val_On_Index THEN
                        NULL;
                END;
            END LOOP;
        END LOOP;
    END;
PROCEDURE Transclaimitem(Phlthdetail IN OUT Customer.Hlth_Detail_Row_Type,
                                                     Phlthitem   IN OUT Customer.Hltprv_Dml_Item_Tbl) IS
    BEGIN
        DELETE Koc_Clm_Hlth_Item_Detail
         WHERE Claim_Id = Phlthdetail.Claim_Id
             AND Sf_No = Phlthdetail.Sf_No;

        IF Phlthitem IS NULL
        THEN
            RETURN;
        END IF;

        --
        FOR j IN 1 .. Phlthitem.Count
        LOOP
            --
            WHILE 1 = 1
            LOOP
                BEGIN
                    --
                    Phlthitem(j).Seq_No := Nvl(Phlthitem(j).Seq_No, 0) + 1;

                    --
                    IF Nvl(Phlthitem(j).Breresultcode, 'PP') = 'PP'
                    THEN
                        Phlthitem(j).Status_Code := 'PP';
                    ELSIF Nvl(Phlthitem(j).Breresultcode, 'PP') = 'R'
                    THEN
                        Phlthitem(j).Status_Code := 'PR';
                    ELSE
                        Phlthitem(j).Status_Code := Phlthitem(j).Breresultcode;
                    END IF;

                    INSERT INTO Koc_Clm_Hlth_Item_Detail
                        (Claim_Id,
                         Sf_No,
                         Location_Code,
                         Add_Order_No,
                         Cover_Code,
                         Ubb_Code,
                         Quantity,
                         Price,
                         Item_Type,
                         Drg_Code,
                         Order_No,
                         Surgery_Id,
                         Vat_Rate,
                         Explanation,
                         Status_Code,
                         Time_Stamp,
                         Seq_No,
                         Bre_Result_Code,
                         Process_Code,
                         Process_Code_List,
                         Req_Item_Name,
                         Req_Item_Ubbcode)
                    VALUES
                        (Phlthdetail.Claim_Id,
                         Phlthdetail.Sf_No,
                         Phlthdetail.Location_Code,
                         1,
                         Phlthitem(j).Cover_Code,
                         Phlthitem(j).Ubb_Code,
                         Phlthitem(j).Quantity,
                         Phlthitem(j).Price,
                         Phlthitem(j).Item_Type,
                         Phlthitem(j).Drg_Code,
                         Phlthitem(j).Order_No,
                         Phlthitem(j).Surgery_Id,
                         Phlthitem(j).Vat_Rate,
                         Phlthitem(j).Explanation,
                         Phlthitem(j).Status_Code,
                         Phlthitem(j).Time_Stamp,
                         Phlthitem(j).Seq_No,
                         Phlthitem(j).Breresultcode,
                         Phlthitem(j).Processcode,
                         Phlthitem(j).Processcodelist,
                         Phlthitem(j).Req_Item_Name,
                         Phlthitem(j).Req_Item_Ubbcode);

                    EXIT;
                EXCEPTION
                    WHEN Dup_Val_On_Index THEN
                        NULL;
                END;
            END LOOP;
        END LOOP;
    END;
    FUNCTION Convertbranchcode(Psource        IN VARCHAR2,
                                                         Pprovisiondate IN DATE,
                                                         Pbranchcode    IN VARCHAR2) RETURN NUMBER IS
        Vrv Alz_Branch_Code_Cgm_Rel.Branchcodeallz%TYPE := NULL;

        CURSOR Crbranchcode(Pc_Provisiondate IN DATE,
                                                Pc_Branchcodecgm IN VARCHAR2) IS
            SELECT b.Branchcodeallz
                FROM Koc_Oc_Specialty_Subj_Ref a,
                         Alz_Branch_Code_Cgm_Rel   b
             WHERE b.Branchcodecgm = Pc_Branchcodecgm
                 AND a.Specialty_Subject = b.Branchcodeallz
                 AND Nvl(a.Business_Line_Type, 0) IN (0, 1)
                 AND a.Validity_Start_Date <= Trunc(Pc_Provisiondate)
                 AND (a.Validity_End_Date IS NULL OR a.Validity_End_Date >= Trunc(Pc_Provisiondate));
    BEGIN
        IF Psource IN ('WS', 'ULAK')
        THEN
            OPEN Crbranchcode(Pprovisiondate, Pbranchcode);

            FETCH Crbranchcode
                INTO Vrv;

            CLOSE Crbranchcode;
        ELSIF Psource IN ('OPUS', 'PORTAL')
        THEN
            Vrv := Pbranchcode;
        ELSE
            Raise_Application_Error(-20110, 'Bilinmeyen kaynak kodu!');
        END IF;

        IF Vrv IS NULL
        THEN
            Raise_Application_Error(-20110,
                                                            'Tan�ml� olmayan bran� kodu : ' || Psource || '-' || Pbranchcode || '-' || To_Char(Pprovisiondate, 'dd.mm.yyyy'));
        END IF;

        RETURN(Vrv);
    END;

    FUNCTION Convertbranchcode2(Psource        IN VARCHAR2,
                                                            Pprovisiondate IN DATE,
                                                            Pbranchcode    IN VARCHAR2) RETURN NUMBER IS
        Vrv Alz_Branch_Code_Cgm_Rel.Branchcodecgm%TYPE := NULL;

        CURSOR Crbranchcode(Pc_Provisiondate  IN DATE,
                                                Pc_Branchcodeallz IN VARCHAR2) IS
            SELECT b.Branchcodecgm
                FROM Koc_Oc_Specialty_Subj_Ref a,
                         Alz_Branch_Code_Cgm_Rel   b
             WHERE b.Branchcodeallz = Pc_Branchcodeallz
                 AND a.Specialty_Subject = b.Branchcodeallz
                 AND Nvl(a.Business_Line_Type, 0) IN (0, 1)
                 AND a.Validity_Start_Date <= Trunc(Pc_Provisiondate)
                 AND (a.Validity_End_Date IS NULL OR a.Validity_End_Date >= Trunc(Pc_Provisiondate))
                 AND Rownum < 2;
    BEGIN
        IF Psource IN ('WS', 'ULAK')
        THEN
            OPEN Crbranchcode(Pprovisiondate, Pbranchcode);

            FETCH Crbranchcode
                INTO Vrv;

            CLOSE Crbranchcode;
        ELSIF Psource IN ('OPUS', 'PORTAL')
        THEN
            Vrv := Pbranchcode;
        ELSE
            Raise_Application_Error(-20110, 'Bilinmeyen kaynak kodu!');
        END IF;

        IF Vrv IS NULL
        THEN
            Raise_Application_Error(-20110, 'Tan�ml� olmayan bran� kodu : ' || Pbranchcode);
        END IF;

        RETURN(Vrv);
    END;
PROCEDURE Transclaimhosptpreapprove(Phlthdetail      IN Customer.Hlth_Detail_Row_Type,
                                                                            Pprovisionreq    IN Customer.Hltprv_Provision_Req_Typ,
                                                                            Phltbreprovision IN Customer.Hltprv_Bre_Provision_Typ) IS
        Vdocbranch NUMBER;
        Vdoctor    Koc_Cc_Web_Inst_Doctor%ROWTYPE;
        Vhltprvdr  CUSTOMER.Hltprv_Dr_Typ;
        Vdate      DATE;
        Vtime      VARCHAR2(10);
        Vexpl      VARCHAR2(5000);
        Vdoctoramt NUMBER;
        Vhosptamt  NUMBER;
    BEGIN
        --
        IF Phltbreprovision.Claimid IS NULL AND
             Phltbreprovision.Locationcode IN (920) AND
             Pprovisionreq.Medicalinfo.Serviceinformation IS NOT NULL AND
             Pprovisionreq.Medicalinfo.Serviceinformation.Count > 0 AND
             Pprovisionreq.Medicalinfo.Serviceinformation(1).Lumpsumprcss IS NOT NULL
        THEN
            --
            FOR i IN 1 .. Pprovisionreq.Medicalinfo.Serviceinformation.Count
            LOOP
                --
                IF Pprovisionreq.Medicalinfo.Serviceinformation(i).Lumpsumprcss IS NOT NULL
                THEN
                    --
                    Vhltprvdr := CUSTOMER.Hltprv_Dr_Typ();

                    IF Pprovisionreq.Medicalinfo.Serviceinformation(i).Lumpsumprcss.Dr IS NOT NULL
                    THEN
                        Vhltprvdr := Pprovisionreq.Medicalinfo.Serviceinformation(i).Lumpsumprcss.Dr;

                        --
                        IF Phlthdetail.Provisiondoctor.Doctorcode IS NOT NULL
                        THEN
                            IF Pprovisionreq.Medicalinfo.Serviceinformation(i).Lumpsumprcss.Dr.Identityno IS NOT NULL AND
                                    Phlthdetail.Provisiondoctor.Identityno IS NOT NULL
                            THEN
                                IF TRIM(Pprovisionreq.Medicalinfo.Serviceinformation(i).Lumpsumprcss.Dr.Identityno) = TRIM(Phlthdetail.Provisiondoctor.Identityno)
                                THEN
                                    Vhltprvdr.Doctorcode := Phlthdetail.Provisiondoctor.Doctorcode;
                                END IF;
                            ELSIF Pprovisionreq.Medicalinfo.Serviceinformation(i).Lumpsumprcss.Dr.Diplomaregistrationno IS NOT NULL AND
                                         Phlthdetail.Provisiondoctor.Diplomaregistrationno IS NOT NULL
                            THEN
                                IF TRIM(Pprovisionreq.Medicalinfo.Serviceinformation(i).Lumpsumprcss.Dr.Diplomaregistrationno) =
                                     TRIM(Phlthdetail.Provisiondoctor.Diplomaregistrationno)
                                THEN
                                    Vhltprvdr.Doctorcode := Phlthdetail.Provisiondoctor.Doctorcode;
                                END IF;
                            ELSIF Pprovisionreq.Medicalinfo.Serviceinformation(i).Lumpsumprcss.Dr.Namesurname IS NOT NULL AND
                                         Phlthdetail.Provisiondoctor.Namesurname IS NOT NULL
                            THEN
                                IF TRIM(Pprovisionreq.Medicalinfo.Serviceinformation(i).Lumpsumprcss.Dr.Namesurname) = TRIM(Phlthdetail.Provisiondoctor.Namesurname)
                                THEN
                                    Vhltprvdr.Doctorcode := Phlthdetail.Provisiondoctor.Doctorcode;
                                END IF;
                            END IF;
                        END IF;

                        --
                        IF Vhltprvdr.Doctorcode IS NULL
                        THEN
                            Vdocbranch := NULL;
                            Vdocbranch := Convertbranchcode(Pprovisionreq.Requestsystem, Pprovisionreq.Provisiondate, Vhltprvdr.Branch);

                            Finddoctor(Phltbreprovision.Institutecode,
                                       Vdocbranch,
                                       Vhltprvdr.Namesurname,
                                       Vhltprvdr.Identityno,
                                       Phlthdetail.Request_System,
                                       Vdoctor);

                            Vhltprvdr.Doctorcode := Vdoctor.Doctor_Code;
                            Vhltprvdr.Sourcetype := Pprovisionreq.Requestsystem;
                        END IF;

                        --
                        IF Phlthdetail.Request_System IN ('WS', 'ULAK')
                        THEN
                            DBMS_OUTPUT.PUT_LINE('doktor inserting3');
                            --Insertdoctorhst(Phlthdetail.Institute_Code, Phlthdetail.Provision_Date, Vhltprvdr);
                        END IF;
                    END IF;

                    Vdate := NULL;
                    Vtime := NULL;
                    Vexpl := NULL;

                    --
                    IF Pprovisionreq.Medicalinfo.Serviceinformation(i).Lumpsumprcss.Processdatetime IS NOT NULL
                    THEN
                        Vdate := Trunc(Pprovisionreq.Medicalinfo.Serviceinformation(i).Lumpsumprcss.Processdatetime.Processdate);
                        Vtime := Pprovisionreq.Medicalinfo.Serviceinformation(i).Lumpsumprcss.Processdatetime.Processtime;
                    END IF;

                    --
                    IF Pprovisionreq.Medicalinfo.Serviceinformation(i).Lumpsumprcss.Explanation IS NOT NULL
                    THEN
                        Vexpl := Substr(Pprovisionreq.Medicalinfo.Serviceinformation(i).Lumpsumprcss.Explanation.Text, 1, 4000);
                    END IF;

                    --
                    IF Vhltprvdr IS NOT NULL AND
                         Vhltprvdr.Staffstatus IN ('KADROSUZ', 'DIS_DOKTOR')
                    THEN
                        Vdoctoramt := Pprovisionreq.Medicalinfo.Serviceinformation(i).Lumpsumprcss.Amountrequest;
                    ELSE
                        Vhosptamt := Pprovisionreq.Medicalinfo.Serviceinformation(i).Lumpsumprcss.Amountrequest;
                    END IF;

                    INSERT INTO Koc_Clm_Hlth_Preapprove_Detail
                        (Claim_Id,
                         Sf_No,
                         Add_Order_No,
                         Cover_Type,
                         Request_Amount,
                         Sgk_Amount,
                         Process_Date,
                         Process_Time,
                         Order_No,
                         Explanation,
                         Doctor_Code,
                         Doctor_Type,
                         Time_Stamp)
                    VALUES
                        (Phlthdetail.Claim_Id,
                         Phlthdetail.Sf_No,
                         1,
                         Pprovisionreq.Medicalinfo.Serviceinformation(i).Lumpsumprcss.Insuredcovertype,
                         Pprovisionreq.Medicalinfo.Serviceinformation(i).Lumpsumprcss.Amountrequest,
                         Pprovisionreq.Medicalinfo.Serviceinformation(i).Lumpsumprcss.Amountsgk,
                         Vdate,
                         Vtime,
                         Pprovisionreq.Medicalinfo.Serviceinformation(i).Lumpsumprcss.Orderno,
                         Vexpl,
                         Vhltprvdr.Doctorcode,
                         Vhltprvdr.Drtype,
                         SYSDATE);

                    UPDATE Koc_Clm_Hlth_Detail
                         SET Explanation    = Substr(Nvl(Vexpl, ''), 1, 99),
                                 Ext_Doctor_Amt = Vdoctoramt,
                                 Hospital_Amt   = Vhosptamt
                     WHERE Claim_Id = Phlthdetail.Claim_Id
                         AND Sf_No = Phlthdetail.Sf_No;
                END IF;
            END LOOP;
        END IF;
    END;


   PROCEDURE Createclaimfile(Pprovisionreq    IN Customer.Hltprv_Provision_Req_Typ,
                                                        Phltbreprovision IN Customer.Hltprv_Bre_Provision_Typ,
                                                        Phlthdetail      IN OUT Customer.Hlth_Detail_Row_Type,
                                                        Phlthproc        IN OUT Customer.Hlth_Proc_Detail_Table_Type,
                                                        Phlthmedicine    IN OUT Customer.Medicine_Indem_Det_Table_Type,
                                                        Phlthitem        IN OUT Customer.Hltprv_Dml_Item_Tbl,
                                                        Phlthdiagnosis   IN OUT Customer.Hltprv_Dml_Diagnose_Tbl,
                                                        Phlthpatient     IN OUT Customer.Hltprv_Dml_Patient_Form_Typ,
                                                        Phlthrelation    IN OUT Customer.Hltprv_Relationshipinfo_Typ) IS
        Vtranstype     NUMBER(1);
        Vhlthprovision Customer.Hlth_Provisions_Table_Type;
        --
        v_Request_System VARCHAR2(50);
        v_Provision_Date DATE; --provisiondate mustafaku
    BEGIN
        IF Phlthdetail.Claim_Id IS NULL
        THEN
            Vtranstype := 1; --yeni dosya
        ELSE
            Vtranstype := 2; --dosya g�ncelle
        END IF;

        IF Vtranstype = 1
        THEN
            Phlthdetail.Claim_Id := Koc_Clm_Hlth_Trnx.Genclaimid;
            Phlthdetail.Sf_No    := 1;

            IF Phlthdetail.Ext_Reference IS NULL
            THEN
                SELECT Clm_Subfiles_Seq.Nextval INTO Phlthdetail.Ext_Reference FROM Dual;
            END IF;
        END IF;

        --20150320 -- emre.elcik -- FOR TSS
        Phlthdetail.Iscomplementary := Phltbreprovision.Policy.Iscomplementary;
        --20150320 -- emre.elcik -- Aile Hekimi
        Phlthdetail.Isahek := Phltbreprovision.Isahek;

        --

        --mondial i�lemleri
        --sadece yeni dosya
        IF Phlthdetail.Location_Code IN (940) AND
             Vtranstype = 1 AND
             Phlthdetail.Request_System = 'PORTAL'
        THEN
            --
            IF Phlthdetail.Mondial_Type IN (1, 2)
            THEN
                --mondial_type 3 i�in otr �al���r.
                Choosemondialprocess(Phlthdetail, Phlthproc);
            END IF;
        END IF;

        IF Vtranstype = 2
        THEN
            Transclaimtorecover(Phlthdetail.Claim_Id);
        END IF;

        IF Vtranstype = 1
        THEN
            Transclaimfile(Phlthdetail);
        END IF;

        Choosecover(Phlthdetail, Phlthproc, Phlthmedicine, Phlthitem, Vhlthprovision, Phltbreprovision);

        IF Vtranstype = 2
        THEN
            BEGIN
                SELECT d.Request_System,
                             d.Provision_Date --provisiondate mustafaku
                    INTO v_Request_System,
                             v_Provision_Date --provisiondate mustafaku
                    FROM Koc_Clm_Hlth_Detail d
                 WHERE d.Claim_Id = Phlthdetail.Claim_Id
                     AND d.Sf_No = Phlthdetail.Sf_No
                     AND d.Add_Order_No = 1;

                Phlthdetail.Provision_Date := Nvl(v_Provision_Date, Phlthdetail.Provision_Date); --provisiondate mustafaku

            EXCEPTION
                WHEN OTHERS THEN
                    NULL;
            END;

            Phlthdetail.Request_System := Nvl(v_Request_System, Phlthdetail.Request_System);
        END IF;

        Transclaimdetail(Phlthdetail, Vhlthprovision, Phltbreprovision.Bredecisions);

        Transclaimdiagnose(Phlthdetail, Phlthdiagnosis);

        Transclaimrelationship(Phlthdetail, Phlthrelation);

        Transclaimpatientinfoform(Phlthdetail, Phlthpatient);
        DBMS_OUTPUT.PUT_LINE('pre_trans_claim_prov');
        Transclaimprovision(Phlthdetail, Phlthproc, Phlthmedicine, Phlthitem, Vhlthprovision);
         DBMS_OUTPUT.PUT_LINE('pre_trans_claim_process'); 
        Transclaimprocess(Phlthdetail, Phlthproc);

        Transclaimmedicine(Phlthdetail, Phlthmedicine);

        Transclaimitem(Phlthdetail, Phlthitem);

        Transclaimhosptpreapprove(Phlthdetail, Pprovisionreq, Phltbreprovision);
    END;

   PROCEDURE Setclaimpatientinfoform(Pprovisionreq    IN Customer.Hltprv_Provision_Req_Typ,
                                                                        Ppatientinfoform IN OUT Customer.Hltprv_Dml_Patient_Form_Typ) IS
        Vlast NUMBER;
    BEGIN
        Ppatientinfoform := Customer.Hltprv_Dml_Patient_Form_Typ();

        SELECT Patient_Info_Form_Seq.Nextval INTO Ppatientinfoform.Form_Id FROM Dual;

        Ppatientinfoform.Claim_Id     := NULL;
        Ppatientinfoform.Sf_No        := NULL;
        Ppatientinfoform.Add_Order_No := NULL;

        Ppatientinfoform.Date_Of_Last_Menstrual := Pprovisionreq.Medicalinfo.Patientinfoform.Dateoflastmenstrual;
        Ppatientinfoform.Is_Judicial            := Pprovisionreq.Medicalinfo.Patientinfoform.Isjudical;

        --
        IF Pprovisionreq.Requestsystem IN ('WS', 'ULAK')
        THEN
            Ppatientinfoform.Complaint      := Pprovisionreq.Medicalinfo.Patientinfoform.Complaint;
            Ppatientinfoform.Complaint_Date := Pprovisionreq.Medicalinfo.Patientinfoform.Complaintstartdate;
            Ppatientinfoform.History        := Pprovisionreq.Medicalinfo.Patientinfoform.History;

            IF Pprovisionreq.Medicalinfo.Patientinfoform.Historydetailinfos IS NOT NULL
            THEN
                Ppatientinfoform.Is_Having_Old_Case  := Pprovisionreq.Medicalinfo.Patientinfoform.Historydetailinfos.Ishavingoldcase;
                Ppatientinfoform.Surgery_History     := Pprovisionreq.Medicalinfo.Patientinfoform.Historydetailinfos.Surgeryhistory;
                Ppatientinfoform.Is_Blood_Bloodtrans := Pprovisionreq.Medicalinfo.Patientinfoform.Historydetailinfos.Isbloodandbloodtransfusion;
                Ppatientinfoform.Is_Reg_Using_Med    := Pprovisionreq.Medicalinfo.Patientinfoform.Historydetailinfos.Isregularlyusingmedicines;
                Ppatientinfoform.History_Note        := Pprovisionreq.Medicalinfo.Patientinfoform.Historydetailinfos.Anamnesisnote;
                Ppatientinfoform.Is_Smoking          := Pprovisionreq.Medicalinfo.Patientinfoform.Historydetailinfos.Issmoking;
                Ppatientinfoform.Is_Using_Of_Alcohol := Pprovisionreq.Medicalinfo.Patientinfoform.Historydetailinfos.Isusingofalcohol;
                Ppatientinfoform.Special_Case_Note   := Pprovisionreq.Medicalinfo.Patientinfoform.Historydetailinfos.Specialcasenote;
                Ppatientinfoform.Is_Having_Allergy   := Pprovisionreq.Medicalinfo.Patientinfoform.Historydetailinfos.Ishavingallergy;
            END IF;

            Ppatientinfoform.Family_History         := Pprovisionreq.Medicalinfo.Patientinfoform.Familyhistory;
            Ppatientinfoform.Physical_Exam_Findings := Pprovisionreq.Medicalinfo.Patientinfoform.Physicalexaminationfindings;
            Ppatientinfoform.Story                  := Pprovisionreq.Medicalinfo.Patientinfoform.Anamnesis;
            Ppatientinfoform.Is_Traffic_Accident    := Pprovisionreq.Medicalinfo.Patientinfoform.Istrafficaccident;
            Ppatientinfoform.Is_Emergency           := Pprovisionreq.Medicalinfo.Patientinfoform.Isemergency;
            Ppatientinfoform.Type_Of_Admission      := Pprovisionreq.Medicalinfo.Patientinfoform.Typeofadmission;
            Ppatientinfoform.Occurring_Way_Of_Case  := Pprovisionreq.Medicalinfo.Patientinfoform.Occurringwayofcase;
            Ppatientinfoform.Is_Trauma_Case         := Pprovisionreq.Medicalinfo.Patientinfoform.Istraumacase;
            Ppatientinfoform.Epicrisis_Note         := Pprovisionreq.Medicalinfo.Patientinfoform.Epicrisisnote;
            Ppatientinfoform.Anesthesia_Note        := Pprovisionreq.Medicalinfo.Patientinfoform.Anesthesianote;

            --Poliklinik Kay�tlar�
            IF Pprovisionreq.Medicalinfo.Patientinfoform.Polyclinic IS NOT NULL
            THEN
                FOR i IN 1 .. Pprovisionreq.Medicalinfo.Patientinfoform.Polyclinic.Count
                LOOP
                    IF Ppatientinfoform.Poly_Records IS NULL
                    THEN
                        Ppatientinfoform.Poly_Records := Customer.Hltprv_Dml_Polyclinic_Tbl();
                    END IF;

                    Ppatientinfoform.Poly_Records.Extend;
                    Vlast := Ppatientinfoform.Poly_Records.Last;
                    Ppatientinfoform.Poly_Records(Vlast) := Customer.Hltprv_Dml_Polyclinic_Typ();

                    SELECT Patient_Poly_Info_Seq.Nextval INTO Ppatientinfoform.Poly_Records(Vlast).Poly_Id FROM Dual;

                    Ppatientinfoform.Poly_Records(Vlast).Form_Id := Ppatientinfoform.Form_Id;

                    IF Pprovisionreq.Medicalinfo.Patientinfoform.Polyclinic(i).Polyclinicinfos IS NOT NULL
                    THEN
                        Ppatientinfoform.Poly_Records(Vlast).Branch := Pprovisionreq.Medicalinfo.Patientinfoform.Polyclinic(i).Polyclinicinfos.Branch;
                        Ppatientinfoform.Poly_Records(Vlast).Admission_Date := Pprovisionreq.Medicalinfo.Patientinfoform.Polyclinic(i)
                                                                                                                                     .Polyclinicinfos.Registrationdate;
                    END IF;

                    IF Pprovisionreq.Medicalinfo.Patientinfoform.Polyclinic(i).Contentinfos IS NOT NULL
                    THEN
                        Ppatientinfoform.Poly_Records(Vlast).Content := Pprovisionreq.Medicalinfo.Patientinfoform.Polyclinic(i).Contentinfos.Content;
                    END IF;
                END LOOP;
            END IF;

            --Tetkik Sonu�lar�
            IF Pprovisionreq.Medicalinfo.Patientinfoform.Examinationresult IS NOT NULL
            THEN
                FOR i IN 1 .. Pprovisionreq.Medicalinfo.Patientinfoform.Examinationresult.Count
                LOOP
                    IF Ppatientinfoform.Exam_Results IS NULL
                    THEN
                        Ppatientinfoform.Exam_Results := Customer.Hltprv_Dml_Examination_Tbl();
                    END IF;

                    Ppatientinfoform.Exam_Results.Extend;
                    Vlast := Ppatientinfoform.Exam_Results.Last;
                    Ppatientinfoform.Exam_Results(Vlast) := Customer.Hltprv_Dml_Examination_Typ();

                    SELECT Patient_Exam_Info_Seq.Nextval INTO Ppatientinfoform.Exam_Results(Vlast).Exam_Id FROM Dual;

                    Ppatientinfoform.Exam_Results(Vlast).Form_Id := Ppatientinfoform.Form_Id;

                    IF Pprovisionreq.Medicalinfo.Patientinfoform.Examinationresult(i).Examinationinfo IS NOT NULL
                    THEN
                        Ppatientinfoform.Exam_Results(Vlast).Exam_Desc := Pprovisionreq.Medicalinfo.Patientinfoform.Examinationresult(i)
                                                                                                                            .Examinationinfo.Examinationname;
                        Ppatientinfoform.Exam_Results(Vlast).Exam_Date := Pprovisionreq.Medicalinfo.Patientinfoform.Examinationresult(i)
                                                                                                                            .Examinationinfo.Examinationdate;
                    END IF;

                    IF Pprovisionreq.Medicalinfo.Patientinfoform.Examinationresult(i).Contentinfos IS NOT NULL
                    THEN
                        Ppatientinfoform.Exam_Results(Vlast).Content := Pprovisionreq.Medicalinfo.Patientinfoform.Examinationresult(i).Contentinfos.Content;
                    END IF;
                END LOOP;
            END IF;

            --Ameliyat Notlar�
            IF Pprovisionreq.Medicalinfo.Patientinfoform.Surgerynote IS NOT NULL
            THEN
                FOR i IN 1 .. Pprovisionreq.Medicalinfo.Patientinfoform.Surgerynote.Count
                LOOP
                    IF Ppatientinfoform.Surgery_Note IS NULL
                    THEN
                        Ppatientinfoform.Surgery_Note := Customer.Hltprv_Dml_Surgery_Note_Tbl();
                    END IF;

                    Ppatientinfoform.Surgery_Note.Extend;
                    Vlast := Ppatientinfoform.Surgery_Note.Last;
                    Ppatientinfoform.Surgery_Note(Vlast) := Customer.Hltprv_Dml_Surgery_Note_Typ();

                    SELECT Patient_Surgery_Note_Seq.Nextval INTO Ppatientinfoform.Surgery_Note(Vlast).Surgery_Note_Id FROM Dual;

                    Ppatientinfoform.Surgery_Note(Vlast).Form_Id := Ppatientinfoform.Form_Id;

                    SELECT Patient_Note_Seq.Nextval INTO Ppatientinfoform.Surgery_Note(Vlast).Note_Id FROM Dual;

                    Ppatientinfoform.Surgery_Note(Vlast).Note := Pprovisionreq.Medicalinfo.Patientinfoform.Surgerynote(i).Text;
                END LOOP;
            END IF;

            --Konsultasyon Raporlar�
            IF Pprovisionreq.Medicalinfo.Patientinfoform.Consultationreport IS NOT NULL
            THEN
                FOR i IN 1 .. Pprovisionreq.Medicalinfo.Patientinfoform.Consultationreport.Count
                LOOP
                    IF Ppatientinfoform.Consultation_Report IS NULL
                    THEN
                        Ppatientinfoform.Consultation_Report := Customer.Hltprv_Dml_Consult_Report_Tbl();
                    END IF;

                    Ppatientinfoform.Consultation_Report.Extend;
                    Vlast := Ppatientinfoform.Consultation_Report.Last;
                    Ppatientinfoform.Consultation_Report(Vlast) := Customer.Hltprv_Dml_Consult_Report_Typ;

                    SELECT Patient_Consultation_Rep_Seq.Nextval INTO Ppatientinfoform.Consultation_Report(Vlast).Conslt_Rep_Id FROM Dual;

                    Ppatientinfoform.Consultation_Report(Vlast).Form_Id := Ppatientinfoform.Form_Id;

                    SELECT Patient_Rep_Seq.Nextval INTO Ppatientinfoform.Consultation_Report(Vlast).Rep_Id FROM Dual;

                    Ppatientinfoform.Consultation_Report(Vlast).Report := Pprovisionreq.Medicalinfo.Patientinfoform.Consultationreport(i).Text;
                END LOOP;
            END IF;
        END IF;
    END;

  FUNCTION Isitemvalid(Pubbcode IN VARCHAR2) RETURN NUMBER IS
        Vcnt NUMBER;
    BEGIN
        SELECT COUNT(1) INTO Vcnt FROM Koc_Hlth_Gmdn_Ubb_List a WHERE a.Ubb_Code = Pubbcode;

        IF Vcnt = 0
        THEN
            RETURN 0;
        ELSE
            RETURN 1;
        END IF;
    END;
   PROCEDURE Setclaimitem(Pprovisionreq    IN Customer.Hltprv_Provision_Req_Typ,
                                                 Phltbreprovision IN Customer.Hltprv_Bre_Provision_Typ,
                                                 Pitemdetail      IN OUT Customer.Hltprv_Dml_Item_Tbl) IS
        Vlast NUMBER;
    BEGIN
        --Malzeme talebi sadece WS den yap�l�yor
        IF Pprovisionreq.Requestsystem IN ('WS', 'ULAK')
        THEN
            --
            IF Pprovisionreq.Medicalinfo.Consumables IS NOT NULL
            THEN
                FOR i IN 1 .. Pprovisionreq.Medicalinfo.Consumables.Count
                LOOP
                    IF Pitemdetail IS NULL
                    THEN
                        Pitemdetail := Customer.Hltprv_Dml_Item_Tbl();
                    END IF;

                    IF Pprovisionreq.Medicalinfo.Consumables(i).Type IN ('MALZEME', 'YARDIMCI_TIBBI_MALZEME', 'OZELLIKLI_MALZEME')
                    THEN
                        Pitemdetail.Extend;
                        Vlast := Pitemdetail.Last;

                        Pitemdetail(Vlast) := Customer.Hltprv_Dml_Item_Typ();

                        Pitemdetail(Vlast).Claim_Id := Phltbreprovision.Claimid;
                        Pitemdetail(Vlast).Sf_No := Phltbreprovision.Sfno;
                        Pitemdetail(Vlast).Location_Code := Phltbreprovision.Locationcode;
                        Pitemdetail(Vlast).Cover_Code := NULL;

                        --
                        IF Pprovisionreq.Medicalinfo.Consumables(i).Barcode IS NULL
                        THEN
                            Pitemdetail(Vlast).Ubb_Code := 'KODSUZ';
                        ELSE
                            IF Isitemvalid(Pprovisionreq.Medicalinfo.Consumables(i).Barcode) = 0
                            THEN
                                Pitemdetail(Vlast).Ubb_Code := '9999999999999';
                            ELSE
                                Pitemdetail(Vlast).Ubb_Code := Pprovisionreq.Medicalinfo.Consumables(i).Barcode;
                            END IF;
                        END IF;

                        Pitemdetail(Vlast).Req_Item_Name := Pprovisionreq.Medicalinfo.Consumables(i).Name;
                        Pitemdetail(Vlast).Req_Item_Ubbcode := Pprovisionreq.Medicalinfo.Consumables(i).Barcode;
                        Pitemdetail(Vlast).Quantity := Nvl(Pprovisionreq.Medicalinfo.Consumables(i).Count, 1);
                        Pitemdetail(Vlast).Price := Pprovisionreq.Medicalinfo.Consumables(i).Price;
                        Pitemdetail(Vlast).Item_Type := Pprovisionreq.Medicalinfo.Consumables(i).Type;
                        Pitemdetail(Vlast).Drg_Code := Pprovisionreq.Medicalinfo.Consumables(i).Drgcode;

                        IF Pprovisionreq.Medicalinfo.Consumables(i).Processcode IS NOT NULL
                        THEN
                            Pitemdetail(Vlast).Processcode := Pprovisionreq.Medicalinfo.Consumables(i).Processcode.Processcodevalue;
                            Pitemdetail(Vlast).Processcodelist := Pprovisionreq.Medicalinfo.Consumables(i).Processcode.Processcodelist;
                        END IF;

                        Pitemdetail(Vlast).Order_No := Pprovisionreq.Medicalinfo.Consumables(i).Orderno;
                        Pitemdetail(Vlast).Surgery_Id := NULL; --???? �u anda CGM taraf�ndan bu bilgi gelmiyor
                        Pitemdetail(Vlast).Vat_Rate := Pprovisionreq.Medicalinfo.Consumables(i).Ratevat;

                        Pitemdetail(Vlast).Breresultcode := NULL;
                        Pitemdetail(Vlast).Status_Code := NULL;

                        Pitemdetail(Vlast).Time_Stamp := SYSDATE;

                        IF Pitemdetail(Vlast).Claim_Id IS NULL
                        THEN
                            Pitemdetail(Vlast).Action_Code := 'I';
                        ELSE
                            Pitemdetail(Vlast).Action_Code := 'U';
                        END IF;

                        IF Pprovisionreq.Medicalinfo.Consumables(i).Explanation IS NOT NULL
                        THEN
                            Pitemdetail(Vlast).Explanation := Pprovisionreq.Medicalinfo.Consumables(i).Explanation.Text;
                        END IF;
                    END IF;
                END LOOP;
            END IF;
        END IF;
    END;

    PROCEDURE Setclaimmedicine(Pprovisionreq    IN Customer.Hltprv_Provision_Req_Typ,
                                                         Phltbreprovision IN Customer.Hltprv_Bre_Provision_Typ,
                                                         Pmedicine        IN OUT Customer.Medicine_Indem_Det_Table_Type) IS
        Vlast         NUMBER;
        Vlast_Barcode VARCHAR2(15);
    BEGIN
        IF Pprovisionreq.Medicalinfo.Consumables IS NOT NULL
        THEN
            FOR i IN 1 .. Pprovisionreq.Medicalinfo.Consumables.Count
            LOOP
                IF Pmedicine IS NULL
                THEN
                    Pmedicine := Customer.Medicine_Indem_Det_Table_Type();
                END IF;

                --
                IF Pprovisionreq.Medicalinfo.Consumables(i).Type IN ('ILAC', 'ASI')
                THEN
                    Pmedicine.Extend;

                    Vlast := Pmedicine.Last;

                    Pmedicine(Vlast) := Customer.Medicine_Indem_Det_Row_Type();

                    Pmedicine(Vlast).Claim_Id := Phltbreprovision.Claimid;
                    Pmedicine(Vlast).Sf_No := Phltbreprovision.Sfno;
                    Pmedicine(Vlast).Location_Code := Phltbreprovision.Locationcode;
                    Pmedicine(Vlast).Cover_Code := NULL;
                    Pmedicine(Vlast).Cover_Status_Code := NULL;

                    Pmedicine(Vlast).Price := Pprovisionreq.Medicalinfo.Consumables(i).Price;
                    Pmedicine(Vlast).User_Id := Pprovisionreq.Institute.Instituteusercode;
                    Pmedicine(Vlast).Unit := Nvl(Pprovisionreq.Medicalinfo.Consumables(i).Count, 1);
                    Pmedicine(Vlast).Time_Stamp := SYSDATE;
                    Pmedicine(Vlast).Order_No := Pprovisionreq.Medicalinfo.Consumables(i).Orderno;
                    Pmedicine(Vlast).Item_Type := Pprovisionreq.Medicalinfo.Consumables(i).Type;
                    Pmedicine(Vlast).Status_Code := NULL;
                    Pmedicine(Vlast).Breresultcode := NULL;
                    Pmedicine(Vlast).Req_Medicine_Name := Pprovisionreq.Medicalinfo.Consumables(i).Name;
                    Pmedicine(Vlast).Req_Medicine_Barcode := Pprovisionreq.Medicalinfo.Consumables(i).Barcode;

                    IF Pmedicine(Vlast).Claim_Id IS NULL
                    THEN
                        Pmedicine(Vlast).Action_Code := 'I';
                    ELSE
                        Pmedicine(Vlast).Action_Code := 'U';
                    END IF;

                    IF Pprovisionreq.Requestsystem IN ('WS', 'ULAK')
                    THEN
                        Pmedicine(Vlast).Dose_Period := Pprovisionreq.Medicalinfo.Consumables(i).Usagetime;
                        Pmedicine(Vlast).Dose1 := Pprovisionreq.Medicalinfo.Consumables(i).Dozinfos.Dosage1;
                        Pmedicine(Vlast).Dose2 := Pprovisionreq.Medicalinfo.Consumables(i).Dozinfos.Dosage2;
                        Pmedicine(Vlast).Drg_Code := Pprovisionreq.Medicalinfo.Consumables(i).Drgcode;
                        Pmedicine(Vlast).Vat_Rate := Pprovisionreq.Medicalinfo.Consumables(i).Ratevat;
                        Pmedicine(Vlast).Surgery_Id := NULL; --???? �u anda CGM taraf�ndan bu bilgi gelmiyor

                        --
                        IF Pprovisionreq.Medicalinfo.Consumables(i).Processcode IS NOT NULL
                        THEN
                            Pmedicine(Vlast).Processcode := Pprovisionreq.Medicalinfo.Consumables(i).Processcode.Processcodevalue;
                            Pmedicine(Vlast).Processcodelist := Pprovisionreq.Medicalinfo.Consumables(i).Processcode.Processcodelist;
                        END IF;

                        --
                        IF Pprovisionreq.Medicalinfo.Consumables(i).Explanation IS NOT NULL
                        THEN
                            Pmedicine(Vlast).Explanation := Pprovisionreq.Medicalinfo.Consumables(i).Explanation.Text;
                        END IF;
                    END IF;

                    --
                    IF Phltbreprovision.Medicine IS NOT NULL
                    THEN
                        FOR k IN 1 .. Phltbreprovision.Medicine.Count
                        LOOP
                            IF Phltbreprovision.Medicine(k).Orderno = Pmedicine(Vlast).Order_No
                            THEN
                                Pmedicine(Vlast).Barcode := Phltbreprovision.Medicine(k).Barcode;

                                IF Nvl(Phltbreprovision.Medicine(k).Breresultcode, 'PP') = 'R'
                                THEN
                                    Pmedicine(Vlast).Breresultcode := 'PR';
                                END IF;

                                IF Phltbreprovision.Medicine(k).Brecover IS NOT NULL
                                THEN
                                    IF Phltbreprovision.Medicine(k).Brecover.Code IS NOT NULL
                                    THEN
                                        Pmedicine(Vlast).Cover_Code := Phltbreprovision.Medicine(k).Brecover.Code;
                                        Pmedicine(Vlast).Cover_Status_Code := 'BRECOVER'; ---bre teminat y�nlendirme
                                        /*
                    insert into hkarabas.test(barcode,covercode)
                     values(phltbreprovision.medicine(k).barcode,phltbreprovision.medicine(k).breCover.code);
                     commit;
                     */

                                    END IF;
                                ELSE
                                    Pmedicine(Vlast).Cover_Code := NULL;
                                END IF;
                            END IF;
                        END LOOP;
                    END IF;
                END IF;
            END LOOP;

            /*begin SBH-2819, MURATK, B�t�n atamalar bittikten sonra Pmedicine obje tipinde art�k  Pmedicine(i).Cover_Code is null olan kay�t silinsin*/
            IF(Pmedicine IS NOT NULL) THEN
               FOR i IN Pmedicine.FIRST..Pmedicine.LAST LOOP
                   IF(Pmedicine(i).cover_code IS NULL) THEN
                      Pmedicine.DELETE(i);
                   END IF;
               END LOOP;
            END IF;
           /*end SBH-2819, MURATK, B�t�n atamalar bittikten sonra Pmedicine obje tipinde art�k  Pmedicine(i).Cover_Code is null olan kay�t silinsin*/

        END IF;
    END;

   FUNCTION Converticdcode(Psource  IN VARCHAR2,
                                                    Picdcode IN VARCHAR2) RETURN VARCHAR2 IS
        Vrv VARCHAR2(10) := NULL;

        CURSOR Cricdcode(Pcicdcode IN VARCHAR2) IS
            SELECT a.Class_Disease_Child_Code Icdcode
                FROM Koc_Oc_Icd_Levels a
             WHERE To_Number(Substr(a.Class_Disease_Child_Code, 1, 1)) >= 3
                 AND a.Class_Disease_Child_Code = CASE
                             WHEN Length(Pcicdcode) = 3 THEN
                                To_Char(Length(Pcicdcode)) || '0' || Pcicdcode
                             ELSE
                                To_Char(Length(Pcicdcode)) || Pcicdcode
                         END;

        CURSOR Cricdexists(Pcicdcode IN VARCHAR2) IS
            SELECT 1 FROM Koc_Oc_Icd_Levels a WHERE a.Class_Disease_Child_Code = Pcicdcode;

        Vicdcode VARCHAR2(20);
        Vcnt     NUMBER(1);
    BEGIN
        --Portal g�ncellemede tan� kodu d�n��t�r�lm�� �eklini g�nderiyor
        --
        IF Psource IN ('PORTAL')
        THEN
            OPEN Cricdexists(Picdcode);

            FETCH Cricdexists
                INTO Vcnt;

            IF Cricdexists%FOUND
            THEN
                Vrv := Picdcode;

                CLOSE Cricdexists;

                RETURN Vrv;
            END IF;

            CLOSE Cricdexists;
        END IF;

        Vicdcode := Picdcode;
        Vicdcode := REPLACE(Vicdcode, '.', '');

        --4.seviyeden y�ksek olan icd kodlar� 4.seviyeden e�lenecek
        --bre tan� kodu kurallar� 3 ve 4.seviyeler i�in yaz�ld�
        IF Length(Vicdcode) > 4
        THEN
            Vicdcode := Substr(Vicdcode, 1, 4);
        END IF;

        IF Psource IN ('WS', 'ULAK', 'PORTAL')
        THEN
            --
            FOR i IN REVERSE 3 .. Length(Vicdcode)
            LOOP
                --min ���nc� seviye kontrol edilir...
                IF Vrv IS NOT NULL
                THEN
                    EXIT;
                END IF;

                FOR c IN Cricdcode(Substr(Vicdcode, 1, i))
                LOOP
                    --ilk de�eri al ve ��k
                    Vrv := c.Icdcode;
                    EXIT;
                END LOOP;
            END LOOP;
        ELSIF Psource IN ('OPUS')
        THEN
            Vrv := Nvl(Picdcode, '10099');
        ELSE
            Raise_Application_Error(-20110, 'Bilinmeyen kaynak kodu!');
        END IF;

        IF Vrv IS NULL
        THEN
            Raise_Application_Error(-20110, 'Tan�ml� olmayan ICD kodu!');
        END IF;

        RETURN(Vrv);
    END;


   FUNCTION isexaminationproc (p_discount_group_code VARCHAR2, p_date DATE ) RETURN BOOLEAN
    IS
    v_count NUMBER ;
    BEGIN
      SELECT COUNT(1)
        INTO v_count
        FROM alz_hlth_mnw_ignored_disc a
       WHERE a.discount_group_code = p_discount_group_code
         AND nvl(p_date, trunc(SYSDATE) ) > a.validity_start_date
         AND nvl(p_date, trunc(SYSDATE) ) <= a.validity_end_date ;

         IF v_count > 0
         THEN
           RETURN TRUE;
         ELSE
           RETURN FALSE;
         END IF;
    EXCEPTION WHEN OTHERS THEN
      RETURN FALSE;
    END isexaminationproc;
  
   


   PROCEDURE Setclaimprocess(Pprovisionreq    IN Customer.Hltprv_Provision_Req_Typ,
                                                        Phltbreprovision IN Customer.Hltprv_Bre_Provision_Typ,
                                                        Pprocessdetail   IN OUT Customer.Hlth_Proc_Detail_Table_Type) IS
        Vlast          NUMBER;
        Vdate          DATE;
        Vtime          VARCHAR2(20);
        Vdoctor        Koc_Cc_Web_Inst_Doctor%ROWTYPE;
        Vdocbranch     NUMBER;
        v_ulakdrbranch NUMBER ;
        v_Errmsg       VARCHAR2(1000);
        /*Bran� bazl� discount bulunmas� i�in kapat�ld� HLNWM-1413
         CURSOR Crprocess(Cpcodemain      IN NUMBER,
                                         Cpcodesub1      IN NUMBER,
                                         Cpcodesub2      IN NUMBER,
                                         Cpprovisiondate IN DATE) IS
            SELECT Discount_Group_Code,
                         Is_Unit_Enter
                FROM Koc_Cc_Hlth_Tda_Proc_List
             WHERE Process_Code_Main = Cpcodemain
                 AND Process_Code_Sub1 = Cpcodesub1
                 AND Process_Code_Sub2 = Cpcodesub2
                 AND Validity_Start_Date <= Cpprovisiondate
                 AND (Validity_End_Date IS NULL OR Validity_End_Date >= Cpprovisiondate);*/
  CURSOR Crprocess(Cpcodemain      IN NUMBER,
                   Cpcodesub1      IN NUMBER,
                   Cpcodesub2      IN NUMBER,
                   Cpprovisiondate IN DATE,
                   Cpdoctorbranch  IN NUMBER) IS
    SELECT CASE
             WHEN nvl(a.Is_Multiple_Branches,0) = 1 THEN
              Nvl(Koc_Clm_Hlth_Trnx.Getmultiprocessdiscount(Cpdoctorbranch, Trunc(Cpprovisiondate)),
                  a.Discount_Group_Code)
             WHEN nvl(a.Is_Multiple_Branches,0) = 0 THEN
              a.Discount_Group_Code
           END Discount_Group_Code,
           a.Is_Unit_Enter
      FROM Koc_Cc_Hlth_Tda_Proc_List a
     WHERE a.Process_Code_Main = Cpcodemain
       AND a.Process_Code_Sub1 = Cpcodesub1
       AND a.Process_Code_Sub2 = Cpcodesub2
       AND a.Validity_Start_Date <= Cpprovisiondate
       AND (a.Validity_End_Date IS NULL OR
           a.Validity_End_Date >= Trunc(Cpprovisiondate));

    BEGIN
        IF Phltbreprovision.Healthprocesses IS NULL
        THEN
            RETURN;
        END IF;

        IF Pprovisionreq.Medicalinfo.Serviceinformation IS NULL
        THEN
            RETURN;
        END IF;

        FOR i IN 1 .. Phltbreprovision.Healthprocesses.Count
        LOOP
            IF Pprocessdetail IS NULL
            THEN
                Pprocessdetail := Customer.Hlth_Proc_Detail_Table_Type();
            END IF;

            Pprocessdetail.Extend;

            Pprocessdetail(i) := Customer.Hlth_Proc_Detail_Row_Type();

            Pprocessdetail(i).Claim_Id := Phltbreprovision.Claimid;
            Pprocessdetail(i).Sf_No := Phltbreprovision.Sfno;
            Pprocessdetail(i).Location_Code := Phltbreprovision.Locationcode;
            Pprocessdetail(i).Cover_Code := NULL;
            Pprocessdetail(i).Cover_Status_Code := NULL;
            Pprocessdetail(i).Group_No := 0;
            Pprocessdetail(i).Order_No := Phltbreprovision.Healthprocesses(i).Orderno;
            Pprocessdetail(i).Process_Code_Main := Phltbreprovision.Healthprocesses(i).Processcodemain;
            Pprocessdetail(i).Process_Code_Sub1 := Phltbreprovision.Healthprocesses(i).Processcodesub1;
            Pprocessdetail(i).Process_Code_Sub2 := Phltbreprovision.Healthprocesses(i).Processcodesub2;

            Pprocessdetail(i).Indemnity_Amount := Phltbreprovision.Healthprocesses(i).Indemnityamount;
            Pprocessdetail(i).Inst_Indemnity_Amount := Phltbreprovision.Healthprocesses(i).Insindemnityamount;
            Pprocessdetail(i).Process_Group := Phltbreprovision.Healthprocesses(i).Webproceduregroup;
            Pprocessdetail(i).Status_Code := NULL;
            Pprocessdetail(i).Breresultcode := Phltbreprovision.Healthprocesses(i).Breresultcode;

            Pprocessdetail(i).Userid := Pprovisionreq.Institute.Instituteusercode;
            Pprocessdetail(i).Time_Stamp := SYSDATE;

            /*Bran� bazl� discount bulunmas� i�in kapat�ld� HLNWM-1413
            FOR Recprocess IN Crprocess(Pprocessdetail(i).Process_Code_Main, Pprocessdetail(i).Process_Code_Sub1, Pprocessdetail(i).Process_Code_Sub2,
                                                                    Phltbreprovision.Provisiondate)
            LOOP*/

            IF Pprovisionreq.Requestsystem IN ('ULAK')
            THEN
              v_ulakdrbranch := Convertbranchcode2(Pprovisionreq.Requestsystem, Phltbreprovision.Provisiondate,nvl(Phltbreprovision.Healthprocesses(i).specialtysubject,Phltbreprovision.specialtysubject));
            END IF ;


            FOR Recprocess IN Crprocess(Pprocessdetail(i).Process_Code_Main,
                                        Pprocessdetail(i).Process_Code_Sub1,
                                        Pprocessdetail(i).Process_Code_Sub2,
                                        Phltbreprovision.Provisiondate,
                                        v_ulakdrbranch)
            LOOP
                Pprocessdetail(i).Is_Unit_Enter := Recprocess.Is_Unit_Enter;
                Pprocessdetail(i).Discount_Group_Code := Recprocess.Discount_Group_Code;
            END LOOP;

            FOR k IN 1 .. Pprovisionreq.Medicalinfo.Serviceinformation.Count
            LOOP
                IF Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess IS NOT NULL
                THEN
                    IF Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Orderno = Pprocessdetail(i).Order_No
                    THEN
                        IF Pprocessdetail(i).Claim_Id IS NULL
                        THEN
                            Pprocessdetail(i).Action_Code := 'I';
                        ELSE
                            Pprocessdetail(i).Action_Code := 'U';
                        END IF;

                        Vdate := NULL;
                        Vtime := NULL;

                        Vdate := Trunc(Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Processdatetime.Processdate);
                        Vtime := Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Processdatetime.Processtime;

                        Pprocessdetail(i).Entrance_Date := To_Date(To_Char(Vdate, 'dd.mm.yyyy') || ' ' || Vtime, 'dd.mm.yyyy hh24:mi:ss');
                        Pprocessdetail(i).process_Date := To_Date(To_Char(Vdate, 'dd.mm.yyyy') || ' ' || Vtime, 'dd.mm.yyyy hh24:mi:ss');
                        Pprocessdetail(i).Process_Count := Nvl(Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Count, 1);
                        Pprocessdetail(i).Swift_Code := Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Swiftcode;

                        --
                        IF Pprovisionreq.Requestsystem IN ('WS', 'ULAK')
                        THEN
                            Pprocessdetail(i).Drg_Code := Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Drgcode;
                            Pprocessdetail(i).Sgk_Amount := Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Amountsgk;
                            Pprocessdetail(i).Vat_Rate := Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Ratevat;
                            Pprocessdetail(i).Right_Left := Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Rightleft;

                            Pprocessdetail(i).Req_Process_Name := Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Name;
                            Pprocessdetail(i).Req_Process_Code := Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Processcode.Processcodevalue;
                            Pprocessdetail(i).Req_Process_List_Type := Pprovisionreq.Medicalinfo.Serviceinformation(k)
                                                                                                                 .Servicebasedprocess.Processcode.Processcodelist;

                            --
                            IF Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Explanation IS NOT NULL
                            THEN
                                Pprocessdetail(i).Explanation := Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Explanation.Text;
                            END IF;

                            --Doktor bilgisi g�nderilmi� ise
                            IF Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Dr IS NOT NULL
                            THEN
                                Vdocbranch := NULL;
                                Vdocbranch := Convertbranchcode(Pprovisionreq.Requestsystem, Pprovisionreq.Provisiondate,
                                                                                                Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Dr.Branch);

                                Finddoctor(Phltbreprovision.Institutecode,
                                           Vdocbranch,
                                           Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Dr.Namesurname,
                                           Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Dr.Identityno,
                                           Pprovisionreq.Requestsystem,
                                           Vdoctor);

                                --i�lem doktor muayne i�lemi ise ve web servis kaynakl� dosya ise doktor tan�ml� olmal�
                                IF Vdoctor.Doctor_Code IS NULL AND
                                   Pprovisionreq.Requestsystem = 'WS' AND
                                   isexaminationproc (Pprocessdetail(i).Discount_Group_Code, Pprocessdetail(i).process_Date )
                                THEN
                                  v_Errmsg := 'G�ndermi� oldu�unuz doktor bilgilerini Allianz Sisteminde tan�mlatman�z gerekmektedir. Doktor Kimlik No:'||
                                  Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Dr.Identityno||
                                  ' Doktor Ad Soyad:'|| Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Dr.Namesurname;
                                  Raise_Application_Error(-20210, 'Hatali provizyon iste�i:'||v_Errmsg);
                                 RETURN;
                                END IF ;


                                Pprocessdetail(i).Procdoctor := Customer.Hltprv_Dr_Typ();

                                Pprocessdetail(i).Doctor_Code := Vdoctor.Doctor_Code;
                                Pprocessdetail(i).Doctor_Status := Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Dr.Drtype;
                                Pprocessdetail(i).Procdoctor.Doctorcode := Vdoctor.Doctor_Code;
                                Pprocessdetail(i).Procdoctor.Namesurname := Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Dr.Namesurname;
                                Pprocessdetail(i).Procdoctor.Title := Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Dr.Title;
                                Pprocessdetail(i).Procdoctor.Branch := Vdocbranch;
                                Pprocessdetail(i).Procdoctor.Staffstatus := Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Dr.Staffstatus;
                                Pprocessdetail(i).Procdoctor.Identityno := Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Dr.Identityno;
                                Pprocessdetail(i).Procdoctor.Sourcetype := Pprovisionreq.Requestsystem;
                                Pprocessdetail(i).Procdoctor.Diplomaregistrationno := Pprovisionreq.Medicalinfo.Serviceinformation(k)
                                                                                                                                            .Servicebasedprocess.Dr.Diplomaregistrationno;
                            END IF;

                            IF Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Detail IS NOT NULL
                            THEN
                                IF Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Detail.Surgery IS NOT NULL
                                THEN
                                    Pprocessdetail(i).Proc_Type := 'AMELIYAT';

                                    Pprocessdetail(i).Procsurgery := Customer.Hltprv_Dml_Surgery_Typ();

                                    Pprocessdetail(i).Procsurgery.Surgery_Id := NULL;
                                    Pprocessdetail(i).Procsurgery.Claim_Id := NULL;
                                    Pprocessdetail(i).Procsurgery.Sf_No := NULL;
                                    Pprocessdetail(i).Procsurgery.Add_Order_No := NULL;
                                    Pprocessdetail(i).Procsurgery.Cut_No := Pprovisionreq.Medicalinfo.Serviceinformation(k)
                                                                                                                    .Servicebasedprocess.Detail.Surgery.Incisionno;
                                    Pprocessdetail(i).Procsurgery.Recurrence := Pprovisionreq.Medicalinfo.Serviceinformation(k)
                                                                                                                            .Servicebasedprocess.Detail.Surgery.Relapse;
                                    Pprocessdetail(i).Procsurgery.Is_Revision := Pprovisionreq.Medicalinfo.Serviceinformation(k)
                                                                                                                             .Servicebasedprocess.Detail.Surgery.Revision;
                                    Pprocessdetail(i).Procsurgery.Right_Left := Pprovisionreq.Medicalinfo.Serviceinformation(k)
                                                                                                                            .Servicebasedprocess.Detail.Surgery.Rightleft;
                                    Pprocessdetail(i).Procsurgery.Process_Score := Pprovisionreq.Medicalinfo.Serviceinformation(k)
                                                                                                                                 .Servicebasedprocess.Detail.Surgery.Processpoints;
                                    Pprocessdetail(i).Procsurgery.Is_Laparoscopic_Surgery := Pprovisionreq.Medicalinfo.Serviceinformation(k)
                                                                                                                                                     .Servicebasedprocess.Detail.Surgery.Laparoscopicsurgery;
                                    Pprocessdetail(i).Procsurgery.Is_Robotic_Surgery := Pprovisionreq.Medicalinfo.Serviceinformation(k)
                                                                                                                                            .Servicebasedprocess.Detail.Surgery.Roboticssurgery;

                                    IF Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Detail.Surgery.Surgerypackage IS NOT NULL
                                    THEN
                                        Pprocessdetail(i).Procsurgery.Package_Type := Pprovisionreq.Medicalinfo.Serviceinformation(k)
                                                                                                                                    .Servicebasedprocess.Detail.Surgery.Surgerypackage.Packagetype;
                                        Pprocessdetail(i).Procsurgery.Surgery_Package_No := Pprovisionreq.Medicalinfo.Serviceinformation(k)
                                                                                                                                                .Servicebasedprocess.Detail.Surgery.Surgerypackage.Packageno;
                                    END IF;

                                    Pprocessdetail(i).Procsurgery.Time_Stamp := SYSDATE;
                                    Pprocessdetail(i).Procsurgery.Action_Code := 'I';
                                ELSIF Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Detail.Physiotherapy IS NOT NULL
                                THEN
                                    Pprocessdetail(i).Proc_Type := 'FIZIK_TEDAVI';
                                    Pprocessdetail(i).Physiotherapy_Session := Pprovisionreq.Medicalinfo.Serviceinformation(k)
                                                                                                                         .Servicebasedprocess.Detail.Physiotherapy.Seance;

                                    IF Nvl(Pprocessdetail(i).Physiotherapy_Session, 0) > 0
                                    THEN
                                        Pprocessdetail(i).Process_Count := Pprocessdetail(i).Physiotherapy_Session;
                                    END IF;
                                ELSIF Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Detail.Consultation IS NOT NULL
                                THEN
                                    Pprocessdetail(i).Proc_Type := 'KONSULTASYON';

                                    Pprocessdetail(i).Procdiagnose := Customer.Hltprv_Dml_Diagnose_Typ();

                                    Pprocessdetail(i).Procdiagnose.Diagnosis_Id := NULL;
                                    Pprocessdetail(i).Procdiagnose.Claim_Id := NULL;
                                    Pprocessdetail(i).Procdiagnose.Sf_No := NULL;
                                    Pprocessdetail(i).Procdiagnose.Add_Order_No := NULL;
                                    Pprocessdetail(i).Procdiagnose.Diagnosis_Code := Pprovisionreq.Medicalinfo.Serviceinformation(k)
                                                                                                                                     .Servicebasedprocess.Detail.Consultation.Disease.Code;
                                    Pprocessdetail(i).Procdiagnose.Diagnosis_Desc := Pprovisionreq.Medicalinfo.Serviceinformation(k)
                                                                                                                                     .Servicebasedprocess.Detail.Consultation.Disease.Name;
                                    Pprocessdetail(i).Procdiagnose.Diagnosis_Type := Pprovisionreq.Medicalinfo.Serviceinformation(k)
                                                                                                                                     .Servicebasedprocess.Detail.Consultation.Disease.Type;
                                    Pprocessdetail(i).Procdiagnose.Diagnosis_Level := 'KONSULTASYON';
                                    Pprocessdetail(i).Procdiagnose.Diagnosis_Code_Allz := Converticdcode(Pprovisionreq.Requestsystem,
                                                                                                                                                                             Pprovisionreq.Medicalinfo.Serviceinformation(k)
                                                                                                                                                                                .Servicebasedprocess.Detail.Consultation.Disease.Code);
                                ELSIF Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Detail.Examination IS NOT NULL
                                THEN
                                    Pprocessdetail(i).Proc_Type := 'MUAYENE';

                                    Pprocessdetail(i).Procdiagnose := Customer.Hltprv_Dml_Diagnose_Typ();

                                    Pprocessdetail(i).Procdiagnose.Diagnosis_Id := NULL;
                                    Pprocessdetail(i).Procdiagnose.Claim_Id := NULL;
                                    Pprocessdetail(i).Procdiagnose.Sf_No := NULL;
                                    Pprocessdetail(i).Procdiagnose.Add_Order_No := NULL;
                                    Pprocessdetail(i).Procdiagnose.Diagnosis_Code := Pprovisionreq.Medicalinfo.Serviceinformation(k)
                                                                                                                                     .Servicebasedprocess.Detail.Examination.Disease.Code;
                                    Pprocessdetail(i).Procdiagnose.Diagnosis_Desc := Pprovisionreq.Medicalinfo.Serviceinformation(k)
                                                                                                                                     .Servicebasedprocess.Detail.Examination.Disease.Name;
                                    Pprocessdetail(i).Procdiagnose.Diagnosis_Type := Pprovisionreq.Medicalinfo.Serviceinformation(k)
                                                                                                                                     .Servicebasedprocess.Detail.Examination.Disease.Type;
                                    Pprocessdetail(i).Procdiagnose.Diagnosis_Level := 'MUAYENE';
                                    Pprocessdetail(i).Procdiagnose.Diagnosis_Code_Allz := Converticdcode(Pprovisionreq.Requestsystem,
                                                                                                                                                                             Pprovisionreq.Medicalinfo.Serviceinformation(k)
                                                                                                                                                                                .Servicebasedprocess.Detail.Examination.Disease.Code);
                                END IF;
                            END IF;

                            --
                            IF Pprovisionreq.Medicalinfo.Serviceinformation(k).Servicebasedprocess.Relatedprocesscode IS NOT NULL
                            THEN
                                Pprocessdetail(i).Related_Process := Pprovisionreq.Medicalinfo.Serviceinformation(k)
                                                                                                         .Servicebasedprocess.Relatedprocesscode.Processcodevalue;
                                Pprocessdetail(i).Related_Process_List_Type := Pprovisionreq.Medicalinfo.Serviceinformation(k)
                                                                                                                             .Servicebasedprocess.Relatedprocesscode.Processcodelist;
                            END IF;
                        END IF;
                    END IF;
                END IF;
            END LOOP;
        END LOOP;
    END Setclaimprocess;


   PROCEDURE Setclaimdiagnose(Phltbreprovision IN Customer.Hltprv_Bre_Provision_Typ,
                                                         Pdiagnosedetail  IN OUT Customer.Hltprv_Dml_Diagnose_Tbl) IS
        Vlast NUMBER;
    BEGIN
        IF Phltbreprovision.Diseases IS NOT NULL
        THEN
            FOR i IN 1 .. Phltbreprovision.Diseases.Count
            LOOP
                IF Pdiagnosedetail IS NULL
                THEN
                    Pdiagnosedetail := Customer.Hltprv_Dml_Diagnose_Tbl();
                END IF;

                Pdiagnosedetail.Extend;

                Vlast := Pdiagnosedetail.Last;
                Pdiagnosedetail(Vlast) := Customer.Hltprv_Dml_Diagnose_Typ();

                Pdiagnosedetail(Vlast).Diagnosis_Id := NULL;
                Pdiagnosedetail(Vlast).Claim_Id := Phltbreprovision.Claimid;
                Pdiagnosedetail(Vlast).Sf_No := Phltbreprovision.Sfno;
                Pdiagnosedetail(Vlast).Add_Order_No := 1;
                Pdiagnosedetail(Vlast).Diagnosis_Code := Phltbreprovision.Diseases(i).Codecgm;
                Pdiagnosedetail(Vlast).Diagnosis_Desc := Phltbreprovision.Diseases(i).Name;
                Pdiagnosedetail(Vlast).Diagnosis_Type := Phltbreprovision.Diseases(i).Type;
                Pdiagnosedetail(Vlast).Diagnosis_Level := 'MEDIKAL';
                Pdiagnosedetail(Vlast).Diagnosis_Code_Allz := Phltbreprovision.Diseases(i).Codeallz;
            END LOOP;
        END IF;
    END Setclaimdiagnose;

     PROCEDURE Rejectclaimfile(Pclaimid IN Clm_Subfiles.Claim_Id%TYPE,
                                                        Psfno    IN Clm_Subfiles.Sf_No%TYPE) IS
    BEGIN
        UPDATE Koc_Clm_Hlth_Detail
             SET Status_Code = 'R'
         WHERE Claim_Id = Pclaimid
             AND Sf_No = Psfno;

        UPDATE Koc_Clm_Hlth_Provisions
             SET Status_Code = 'R'
         WHERE Claim_Id = Pclaimid
             AND Sf_No = Psfno;

        UPDATE Koc_Clm_Hlth_Proc_Detail
             SET Status_Code = 'R'
         WHERE Claim_Id = Pclaimid
             AND Sf_No = Psfno;

        UPDATE Koc_Clm_Medicine_Indem_Det
             SET Status_Code = 'R'
         WHERE Claim_Id = Pclaimid
             AND Sf_No = Psfno;

        UPDATE Koc_Clm_Vacc_Indem_Totals
             SET Status_Code = 'R'
         WHERE Claim_Id = Pclaimid
             AND Sf_No = Psfno;

        UPDATE Koc_Clm_Hlth_Item_Detail
             SET Status_Code = 'R'
         WHERE Claim_Id = Pclaimid
             AND Sf_No = Psfno;
    END;

   PROCEDURE Setclaimdetail(Pprovisionreq    IN Customer.Hltprv_Provision_Req_Typ,
                                                     Phltbreprovision IN Customer.Hltprv_Bre_Provision_Typ,
                                                     Pclaimdetail     IN OUT Customer.Hlth_Detail_Row_Type) IS
        Vdoctor Koc_Cc_Web_Inst_Doctor%ROWTYPE;
        --
    BEGIN
        Pclaimdetail := Customer.Hlth_Detail_Row_Type();

        IF Phltbreprovision.Claimid IS NULL
        THEN
            Pclaimdetail.Action_Code   := 'I';
            Pclaimdetail.Claim_Id      := NULL;
            Pclaimdetail.Sf_No         := NULL;
            Pclaimdetail.Ext_Reference := NULL;
            Pclaimdetail.Status_Code   := NULL;
        ELSE
            Pclaimdetail.Action_Code := 'U';
            Pclaimdetail.Claim_Id    := Phltbreprovision.Claimid;
            Pclaimdetail.Sf_No       := Phltbreprovision.Sfno;

            BEGIN
                SELECT a.Ext_Reference,
                             b.Status_Code
                    INTO Pclaimdetail.Ext_Reference,
                             Pclaimdetail.Status_Code
                    FROM Clm_Subfiles        a,
                             Koc_Clm_Hlth_Detail b
                 WHERE a.Claim_Id = Pclaimdetail.Claim_Id
                     AND a.Sf_No = Pclaimdetail.Sf_No
                     AND a.Claim_Id = b.Claim_Id
                     AND a.Sf_No = b.Sf_No;
            EXCEPTION
                WHEN OTHERS THEN
                    Pclaimdetail.Ext_Reference := NULL;
                    Pclaimdetail.Status_Code   := NULL;
            END;
        END IF;

        Pclaimdetail.Breresultcode  := Phltbreprovision.Breresultcode;
        Pclaimdetail.Institute_Code := Phltbreprovision.Institutecode;

        IF Pprovisionreq.Reference IS NOT NULL
        THEN
            Pclaimdetail.Hospital_Ref_No := Pprovisionreq.Getreferenceid('HASTANE_REFERANS_NUMARASI');
            --emre.elcik-- 20150424 -- SGKTAKIPNO objeye yaz�l�yor..
            Pclaimdetail.Sgk_Ref_No := Pprovisionreq.Getreferenceid('SGK_TAKIP_NO');
      --muratk --Tss Medula Takip No Meduladan check olmadan geliyorsa bilgisi al�n�yor.
      Pclaimdetail.VERIFIEDFROMMEDULA := Pprovisionreq.getSgkRefNoVerifiedFromMedula('SGK_TAKIP_NO');
        END IF;

        Pclaimdetail.Provision_Date := Phltbreprovision.Provisiondate;
        Pclaimdetail.Medula_Date    := Phltbreprovision.Meduladate;
        Pclaimdetail.Location_Code  := Phltbreprovision.Locationcode;
        Pclaimdetail.Is_Pregnant    := Phltbreprovision.Insured.Ispregnant;
        Pclaimdetail.Is_Judicial    := Phltbreprovision.Isjudicial;
        Pclaimdetail.Contract_Id    := Phltbreprovision.Policy.Contractid;
        Pclaimdetail.Oar_No         := Phltbreprovision.Policy.Partitionno;
        Pclaimdetail.Part_Id        := Phltbreprovision.Policy.Partid;
        Pclaimdetail.Package_Id     := Phltbreprovision.Policy.Packageid;
        Pclaimdetail.Package_Date   := Phltbreprovision.Policy.Packagedate;
        Pclaimdetail.Group_Code     := Phltbreprovision.Policy.Groupcode;

        --20150320 -- emre.elcik -- FOR TSS
        Pclaimdetail.Iscomplementary := Phltbreprovision.Policy.Iscomplementary;
        --20150320 -- emre.elcik -- Aile Hekimi
        Pclaimdetail.Isahek := Phltbreprovision.Isahek;
        --

        Pclaimdetail.Is_Sgk_Used       := Pprovisionreq.Sgkinfo.Sgkusedstatus;
        Pclaimdetail.Sgk_Total         := Pprovisionreq.Sgkinfo.Amountsgk;
        Pclaimdetail.Provision_User_Id := Pprovisionreq.Institute.Instituteusercode;
        Pclaimdetail.Request_Amount    := Pprovisionreq.Amountrequest;
        Pclaimdetail.Personal_Notes    := Pprovisionreq.Personalnotes;

        Pclaimdetail.Yt_Type                 := Pprovisionreq.Medicalinfo.Applicationtype;
        Pclaimdetail.Patient_Admittance_Date := Pprovisionreq.Medicalinfo.Dateofpatientadmission;
        Pclaimdetail.Time_Stamp              := SYSDATE;

        Pclaimdetail.Request_System := Pprovisionreq.Requestsystem;

        IF Pprovisionreq.Referralinfo IS NOT NULL
        THEN
            Pclaimdetail.Is_Referral             := Pprovisionreq.Referralinfo.Isreferral;
            Pclaimdetail.Referral_Institute_Name := Pprovisionreq.Referralinfo.Referralinstitutename;
        END IF;

        --Doktor var
        IF Pprovisionreq.Dr IS NOT NULL
        THEN
            --Portal ve opus da doktor listeden se�ildi�i i�in doktor var m� kontrol�ne gerek yok
            IF Pprovisionreq.Requestsystem IN ('PORTAL', 'OPUS')
            THEN
                --
                Pclaimdetail.Doctor_Code       := Pprovisionreq.Dr.Doctorcode;
                Pclaimdetail.Dr_Name_Lastname  := Pprovisionreq.Dr.Namesurname;
                Pclaimdetail.Specialty_Subject := Pprovisionreq.Dr.Branch;
                Pclaimdetail.Dr_Diploma_No     := Pprovisionreq.Dr.Diplomaregistrationno;
            ELSIF Pprovisionreq.Requestsystem IN ('WS', 'ULAK')
            THEN

                Finddoctor(Pclaimdetail.Institute_Code,
                           Phltbreprovision.Specialtysubject,
                           Pprovisionreq.Dr.Namesurname,
                           Pprovisionreq.Dr.Identityno,
                           Pprovisionreq.Requestsystem,
                           Vdoctor);


                Pclaimdetail.Provisiondoctor                       := Customer.Hltprv_Dr_Typ();
                Pclaimdetail.Provisiondoctor.Doctorcode            := Vdoctor.Doctor_Code;
                Pclaimdetail.Provisiondoctor.Namesurname           := Pprovisionreq.Dr.Namesurname;
                Pclaimdetail.Provisiondoctor.Title                 := Pprovisionreq.Dr.Title;
                Pclaimdetail.Provisiondoctor.Branch                := Phltbreprovision.Specialtysubject; --convert edilmi� branch code
                Pclaimdetail.Provisiondoctor.Staffstatus           := Pprovisionreq.Dr.Staffstatus;
                Pclaimdetail.Provisiondoctor.Identityno            := Pprovisionreq.Dr.Identityno;
                Pclaimdetail.Provisiondoctor.Diplomaregistrationno := Pprovisionreq.Dr.Diplomaregistrationno;
                Pclaimdetail.Provisiondoctor.Sourcetype            := Pprovisionreq.Requestsystem;

                --Fill doctor type
                IF Vdoctor.Doctor_Code IS NOT NULL
                THEN
                    Pclaimdetail.Doctor_Code       := Vdoctor.Doctor_Code;
                    Pclaimdetail.Dr_Name_Lastname  := Vdoctor.Doctor_Name || ' ' || Vdoctor.Doctor_Surname; -- pprovisionreq.dr.namesurname;
                    Pclaimdetail.Specialty_Subject := Vdoctor.Specialty_Subject;
                    Pclaimdetail.Doctor_Status     := Pprovisionreq.Dr.Drtype;
                    Pclaimdetail.Dr_Diploma_No     := Pprovisionreq.Dr.Diplomaregistrationno;
                ELSE
                    Pclaimdetail.Doctor_Code       := NULL;
                    Pclaimdetail.Dr_Name_Lastname  := Pprovisionreq.Dr.Namesurname;
                    Pclaimdetail.Specialty_Subject := Phltbreprovision.Specialtysubject;
                    Pclaimdetail.Doctor_Status     := Pprovisionreq.Dr.Drtype;
                    Pclaimdetail.Dr_Diploma_No     := Pprovisionreq.Dr.Diplomaregistrationno;
                END IF;
            END IF;

            --
            IF Pprovisionreq.Dr.Staffstatus = 'KADROLU'
            THEN
                Pclaimdetail.Doctor_Type := 'Anla�mal� Doktor';
            ELSIF Pprovisionreq.Dr.Staffstatus = 'KADROSUZ'
            THEN
                Pclaimdetail.Doctor_Type   := 'ALZ Anla�mas�z Doktor';
                Pclaimdetail.Is_Ext_Doctor := 1;
            ELSIF Pprovisionreq.Dr.Staffstatus = 'DIS_DOKTOR'
            THEN
                Pclaimdetail.Doctor_Type   := 'D�� Doktor';
                Pclaimdetail.Is_Ext_Doctor := 1;
            END IF;
        END IF;

        IF Phltbreprovision.Locationcode = 920
        THEN
            IF Pprovisionreq.Requestsystem IN ('PORTAL', 'OPUS')
            THEN
                Pclaimdetail.Poss_Hospitalize_Date := Pprovisionreq.Medicalinfo.Treatmenttype.Hospitalizationinfo.Dateofposshospitalizations;
                Pclaimdetail.Poss_Discharge_Date   := Pprovisionreq.Medicalinfo.Treatmenttype.Hospitalizationinfo.Dateofpossdischarge;
                Pclaimdetail.Hospitalize_Date      := Pprovisionreq.Medicalinfo.Treatmenttype.Hospitalizationinfo.Dateofhospitalizations;
                Pclaimdetail.Discharge_Date        := Pprovisionreq.Medicalinfo.Treatmenttype.Hospitalizationinfo.Dateofdischargefromhospital;
                Pclaimdetail.Surgery_Date          := NULL;

                Pclaimdetail.Ext_Doctor_Amt        := Pprovisionreq.Medicalinfo.Treatmenttype.Hospitalizationinfo.Extdoctoramt;
                Pclaimdetail.Hospital_Amt          := Pprovisionreq.Medicalinfo.Treatmenttype.Hospitalizationinfo.Hospitalamt;
                Pclaimdetail.Nationality           := Pprovisionreq.Medicalinfo.Treatmenttype.Hospitalizationinfo.Nationality;
                Pclaimdetail.Identity_Number       := Pprovisionreq.Medicalinfo.Treatmenttype.Hospitalizationinfo.Identitynumber;
                Pclaimdetail.Communication_Exp1    := Pprovisionreq.Medicalinfo.Treatmenttype.Hospitalizationinfo.Communicationexp1;
                Pclaimdetail.Communication_Number1 := Pprovisionreq.Medicalinfo.Treatmenttype.Hospitalizationinfo.Communicationnumber1;
                Pclaimdetail.Communication_Exp2    := Pprovisionreq.Medicalinfo.Treatmenttype.Hospitalizationinfo.Communicationexp2;
                Pclaimdetail.Communication_Number2 := Pprovisionreq.Medicalinfo.Treatmenttype.Hospitalizationinfo.Communicationnumber2;
                Pclaimdetail.Yt_Type               := Pprovisionreq.Medicalinfo.Treatmenttype.Hospitalizationinfo.Yttype;
            ELSIF Pprovisionreq.Requestsystem IN ('WS', 'ULAK')
            THEN
                Pclaimdetail.Poss_Hospitalize_Date := Pprovisionreq.Medicalinfo.Treatmenttype.Hospitalizationinfo.Dateofhospitalizations;
                Pclaimdetail.Poss_Discharge_Date   := Pprovisionreq.Medicalinfo.Treatmenttype.Hospitalizationinfo.Dateofdischargefromhospital;
                Pclaimdetail.Surgery_Date          := Pprovisionreq.Medicalinfo.Treatmenttype.Hospitalizationinfo.Dateofsurgery;
                --20150415-- emre.elcik-- G�lser Han�m' �n iste�i ile ULAK i�in eklendi..
                Pclaimdetail.Communication_Number1 := Pprovisionreq.Medicalinfo.Treatmenttype.Hospitalizationinfo.Communicationnumber1;
            END IF;
        ELSE
            Pclaimdetail.Poss_Hospitalize_Date := NULL;
            Pclaimdetail.Poss_Discharge_Date   := NULL;
            Pclaimdetail.Hospitalize_Date      := NULL;
            Pclaimdetail.Surgery_Date          := NULL;
            Pclaimdetail.Discharge_Date        := NULL;
            Pclaimdetail.Ext_Doctor_Amt        := NULL;
            Pclaimdetail.Hospital_Amt          := NULL;
            Pclaimdetail.Nationality           := NULL;
            Pclaimdetail.Identity_Number       := NULL;
            Pclaimdetail.Communication_Exp1    := NULL;
            Pclaimdetail.Communication_Number1 := NULL;
            Pclaimdetail.Communication_Exp2    := NULL;
            Pclaimdetail.Communication_Number2 := NULL;
        END IF;

        IF Pprovisionreq.Requestsystem IN ('OPUS')
        THEN
            Pclaimdetail.Is_Web := NULL;
        ELSIF Pprovisionreq.Requestsystem IN ('PORTAL', 'WS', 'ULAK')
        THEN
            Pclaimdetail.Is_Web := 1;
        END IF;

        IF Pprovisionreq.Requestsystem IN ('PORTAL', 'OPUS')
        THEN
            Pclaimdetail.Exam_Date                := Pprovisionreq.Medicalinfo.Examdate;
            Pclaimdetail.Process_Exp              := Pprovisionreq.Medicalinfo.Processexp;
            Pclaimdetail.Patient_Complaint        := Pprovisionreq.Medicalinfo.Patientcomplaint;
            Pclaimdetail.Complaint_Start          := Pprovisionreq.Medicalinfo.Complaintstart;
            Pclaimdetail.Last_Menst_Date          := Pprovisionreq.Medicalinfo.Lastmenstdate;
            Pclaimdetail.Before_Complaint_Illness := Pprovisionreq.Medicalinfo.Beforecomplaintillness;
            Pclaimdetail.Medical_Background       := Pprovisionreq.Medicalinfo.Medicalbackground;
            Pclaimdetail.Consultation_Diagnosis   := Pprovisionreq.Medicalinfo.Consultationdiagnosis;
            Pclaimdetail.Examinations_Results     := Pprovisionreq.Medicalinfo.Examinationsresults;
            Pclaimdetail.Prediagnosis_Diagnosis   := Pprovisionreq.Medicalinfo.Prediagnosisdiagnosis;
            Pclaimdetail.Planned_Treatment_Proc   := Pprovisionreq.Medicalinfo.Plannedtreatmentproc;

            --mondial
            IF Pclaimdetail.Location_Code = 940
            THEN
                Pclaimdetail.Mondial_Type          := Pprovisionreq.Mondial.Mondialtype;
                Pclaimdetail.From_To_Place         := Pprovisionreq.Mondial.Fromtoplace;
                Pclaimdetail.From_City_Code        := Pprovisionreq.Mondial.Fromcitycode;
                Pclaimdetail.From_District_Code    := Pprovisionreq.Mondial.Fromdistrictcode;
                Pclaimdetail.To_City_Code          := Pprovisionreq.Mondial.Tocitycode;
                Pclaimdetail.To_District_Code      := Pprovisionreq.Mondial.Todistrictcode;
                Pclaimdetail.Process_Count         := Pprovisionreq.Mondial.Processcount;
                Pclaimdetail.Country_Code          := Pprovisionreq.Mondial.Countrycode;
                Pclaimdetail.Other_Country         := Pprovisionreq.Mondial.Othercountry;
                Pclaimdetail.Other_Country_City    := Pprovisionreq.Mondial.Othercountrycity;
                Pclaimdetail.Poss_Hospitalize_Date := Pprovisionreq.Medicalinfo.Treatmenttype.Hospitalizationinfo.Dateofposshospitalizations;
                Pclaimdetail.Poss_Discharge_Date   := Pprovisionreq.Medicalinfo.Treatmenttype.Hospitalizationinfo.Dateofpossdischarge;
            END IF;
        END IF;

    --otomuallak mustafaku
    Pclaimdetail.IS_SUSPENSE :=  0;--issuspense(Null,Pclaimdetail.HOSPITALIZE_DATE,Pclaimdetail.DISCHARGE_DATE);


    END Setclaimdetail;
    PROCEDURE Updateprovisionstatus(Phltbreprovision IN Customer.Hltprv_Bre_Provision_Typ) IS
        CURSOR Crdetail(Cpclaimid IN NUMBER,
                                        Cpsfno    IN NUMBER) IS
            SELECT Status_Code
                FROM Koc_Clm_Hlth_Detail
             WHERE Claim_Id = Cpclaimid
                 AND Sf_No = Cpsfno;

        Vdetailstatus  Koc_Clm_Hlth_Detail.Status_Code%TYPE;
        Vnotmatchcount NUMBER;
        Vcntreject     NUMBER;
        Vcnt           NUMBER;
    BEGIN
        --BRE de �ncelik Redde oldu�u i�in e�le�meyen i�lemlerde otorizasyona d��memesi gerekir
        IF Nvl(Phltbreprovision.Breresultcode, 'PP') = 'R'
        THEN
            Rejectclaimfile(Phltbreprovision.Claimid, Phltbreprovision.Sfno);
        ELSE
            --1 not mach varsa dosya durum kodu yeni i�in  PP 2.cil i�in CP olmali
            SELECT COUNT(1)
                INTO Vnotmatchcount
                FROM Koc_Clm_Web_Notmatch_Proc
             WHERE Claim_Id = Phltbreprovision.Claimid
                 AND Instance_Id = '999999'
                 AND Nvl(Is_Aborted, 0) = 0
                 AND Nvl(Is_Completed, 0) = 0;

            --
            IF Vnotmatchcount > 0
            THEN
                OPEN Crdetail(Phltbreprovision.Claimid, Phltbreprovision.Sfno);

                FETCH Crdetail
                    INTO Vdetailstatus;

                CLOSE Crdetail;

                IF Vdetailstatus = 'PP'
                THEN
                    NULL;
                ELSIF Vdetailstatus <> 'PP'
                THEN
                    UPDATE Koc_Clm_Hlth_Detail
                         SET Status_Code = 'CP'
                     WHERE Claim_Id = Phltbreprovision.Claimid
                         AND Sf_No = Phltbreprovision.Sfno;
                END IF;
            END IF;
            /*
      --��lem bulamad�m se�ilmi� ise her zaman otr olmal�
      --
      if vnotmatchcount = 0 and nvl(phltbreprovision.isunlistedprocess, 0) = 0
      then

          select sum(cnt)
            into vcnt
            from (
                  select count(1) cnt
                    from koc_clm_hlth_proc_detail
                   where claim_id = phltbreprovision.claimid
                     and sf_no    = phltbreprovision.sfno
                   union all
                  select count(1) cnt
                    from koc_clm_medicine_indem_det
                   where claim_id = phltbreprovision.claimid
                     and sf_no    = phltbreprovision.sfno
                   union all
                  select count(1) cnt
                    from koc_clm_hlth_item_detail
                   where claim_id = phltbreprovision.claimid
                     and sf_no    = phltbreprovision.sfno
                 );


          select sum(cntreject)
            into vcntreject
            from (
                  select count(1) cntreject
                    from koc_clm_hlth_proc_detail
                   where claim_id = phltbreprovision.claimid
                     and sf_no    = phltbreprovision.sfno
                     and status_code in ('PR','R')
                   union all
                  select count(1) cntreject
                    from koc_clm_medicine_indem_det
                   where claim_id = phltbreprovision.claimid
                     and sf_no    = phltbreprovision.sfno
                     and status_code in ('PR','R')
                   union all
                  select count(1) cntreject
                    from koc_clm_hlth_item_detail
                   where claim_id = phltbreprovision.claimid
                     and sf_no    = phltbreprovision.sfno
                     and status_code in ('PR','R')
                 );

          if vcnt> 0 and vcnt = vcntreject
          then
              rejectclaimfile (phltbreprovision.claimid
                              ,phltbreprovision.sfno
                              );
          end if;
      end if;
      */
        END IF;
    END;
     PROCEDURE Updatecoverstatus(Pclaimid    NUMBER,
                                                            Psfno       NUMBER,
                                                            Paddorderno NUMBER) IS
        CURSOR Crprovcovers IS
            SELECT Location_Code,
                         Cover_Code,
                         Status_Code
                FROM Koc_Clm_Hlth_Provisions
             WHERE Claim_Id = Pclaimid
                 AND Sf_No = Psfno;

        Rcover     Crprovcovers%ROWTYPE;
        Vcnt       NUMBER;
        Vcntreject NUMBER;
    BEGIN
        OPEN Crprovcovers;

        LOOP
            FETCH Crprovcovers
                INTO Rcover;

            EXIT WHEN Crprovcovers%NOTFOUND;

            --
            IF Rcover.Status_Code IN ('PP', 'CP')
            THEN
                SELECT SUM(Cnt)
                    INTO Vcnt
                    FROM (SELECT COUNT(1) Cnt
                                    FROM Koc_Clm_Hlth_Proc_Detail
                                 WHERE Claim_Id = Pclaimid
                                     AND Sf_No = Psfno
                                     AND Add_Order_No = Paddorderno
                                     AND Location_Code = Rcover.Location_Code
                                     AND Cover_Code = Rcover.Cover_Code
                                UNION ALL
                                SELECT COUNT(1) Cnt
                                    FROM Koc_Clm_Medicine_Indem_Det
                                 WHERE Claim_Id = Pclaimid
                                     AND Sf_No = Psfno
                                     AND Add_Order_No = Paddorderno
                                     AND Location_Code = Rcover.Location_Code
                                     AND Cover_Code = Rcover.Cover_Code
                                UNION ALL
                                SELECT COUNT(1) Cnt
                                    FROM Koc_Clm_Hlth_Item_Detail
                                 WHERE Claim_Id = Pclaimid
                                     AND Sf_No = Psfno
                                     AND Add_Order_No = Paddorderno
                                     AND Location_Code = Rcover.Location_Code
                                     AND Cover_Code = Rcover.Cover_Code);

                SELECT SUM(Cnt)
                    INTO Vcntreject
                    FROM (SELECT COUNT(1) Cnt
                                    FROM Koc_Clm_Hlth_Proc_Detail
                                 WHERE Claim_Id = Pclaimid
                                     AND Sf_No = Psfno
                                     AND Add_Order_No = Paddorderno
                                     AND Location_Code = Rcover.Location_Code
                                     AND Cover_Code = Rcover.Cover_Code
                                     AND Status_Code IN ('PR', 'R')
                                UNION ALL
                                SELECT COUNT(1) Cnt
                                    FROM Koc_Clm_Medicine_Indem_Det
                                 WHERE Claim_Id = Pclaimid
                                     AND Sf_No = Psfno
                                     AND Add_Order_No = Paddorderno
                                     AND Location_Code = Rcover.Location_Code
                                     AND Cover_Code = Rcover.Cover_Code
                                     AND Status_Code IN ('PR', 'R')
                                UNION ALL
                                SELECT COUNT(1) Cnt
                                    FROM Koc_Clm_Hlth_Item_Detail
                                 WHERE Claim_Id = Pclaimid
                                     AND Sf_No = Psfno
                                     AND Add_Order_No = Paddorderno
                                     AND Location_Code = Rcover.Location_Code
                                     AND Cover_Code = Rcover.Cover_Code
                                     AND Status_Code IN ('PR', 'R'));

                IF Vcnt > 0 AND
                     Vcnt = Vcntreject
                THEN
                    UPDATE Koc_Clm_Hlth_Provisions
                         SET Status_Code = 'PR'
                     WHERE Claim_Id = Pclaimid
                         AND Sf_No = Psfno
                         AND Add_Order_No = Paddorderno
                         AND Location_Code = Rcover.Location_Code
                         AND Cover_Code = Rcover.Cover_Code;
                END IF;
            END IF;
        END LOOP;
    END;
      PROCEDURE Updaterejectamounts(Phltbreprovision IN Customer.Hltprv_Bre_Provision_Typ) IS
        CURSOR Crsprocess(Cpclaimid IN NUMBER,
                                            Cpsfno    IN NUMBER) IS
            SELECT Process_Code_Main,
                         Process_Code_Sub1,
                         Process_Code_Sub2,
                         Location_Code,
                         Cover_Code,
                         Seq_No,
                         (CASE
                             WHEN Decode(Nvl(Indemnity_Amount, 0), 0, 9999999999, Nvl(Indemnity_Amount, 0)) <
                                        Decode(Nvl(Inst_Indemnity_Amount, 0), 0, 9999999999, Nvl(Inst_Indemnity_Amount, 0)) THEN
                                Nvl(Indemnity_Amount, 0)
                             WHEN Decode(Nvl(Inst_Indemnity_Amount, 0), 0, 9999999999, Nvl(Inst_Indemnity_Amount, 0)) <
                                        Decode(Nvl(Indemnity_Amount, 0), 0, 9999999999, Nvl(Indemnity_Amount, 0)) THEN
                                Nvl(Inst_Indemnity_Amount, 0)
                             ELSE
                                Nvl(Indemnity_Amount, 0)
                         END) * Nvl(Process_Count, 1) Rjctamt
                FROM Koc_Clm_Hlth_Proc_Detail
             WHERE Claim_Id = Cpclaimid
                 AND Sf_No = Cpsfno
                 AND Status_Code IN ('PR', 'R');

        CURSOR Crsmedicine(Cpclaimid IN NUMBER,
                                             Cpsfno    IN NUMBER) IS
            SELECT Barcode,
                         Location_Code,
                         Cover_Code,
                         Seq_No,
                         Price * Unit Rjctamt
                FROM Koc_Clm_Medicine_Indem_Det
             WHERE Claim_Id = Cpclaimid
                 AND Sf_No = Cpsfno
                 AND Status_Code IN ('PR', 'R');

        CURSOR Crsreject(Cpclaimid  IN Koc_Clm_Hlth_Reject_Loss.Claim_Id%TYPE,
                                         Cpsfno     IN Koc_Clm_Hlth_Reject_Loss.Sf_No%TYPE,
                                         Cpcodemain IN Koc_Clm_Hlth_Reject_Loss.Process_Code_Main%TYPE,
                                         Cpcodesub1 IN Koc_Clm_Hlth_Reject_Loss.Process_Code_Sub1%TYPE,
                                         Cpcodesub2 IN Koc_Clm_Hlth_Reject_Loss.Process_Code_Sub2%TYPE,
                                         Cpbarcode  IN Koc_Clm_Hlth_Reject_Loss.Barcode%TYPE,
                                         Cpseqno    IN Koc_Clm_Hlth_Reject_Loss.Seq_No%TYPE) IS
            SELECT x.Rowid Row_Id,
                         x.*
                FROM Koc_Clm_Hlth_Reject_Loss x
             WHERE Claim_Id = Cpclaimid
                 AND Sf_No = Cpsfno
                 AND Add_Order_No = 1
                 AND Process_Code_Main = Cpcodemain
                 AND Process_Code_Sub1 = Cpcodesub1
                 AND Process_Code_Sub2 = Cpcodesub2
                 AND Barcode = Cpbarcode
                 AND Seq_No = Nvl(Cpseqno, 1);

        Recreject Crsreject%ROWTYPE;
        Vcnt      NUMBER;
    BEGIN
        UPDATE Koc_Clm_Hlth_Reject_Loss
             SET Refuse_Amount = 0,
                     Cover_Code    = '0'
         WHERE Claim_Id = Phltbreprovision.Claimid
             AND Sf_No = Phltbreprovision.Sfno
             AND (Process_Code_Main <> 0 OR Barcode <> 0 OR Ubb_Code <> '0')
             AND Is_Bre_Decision = 1;

        --sadece buldu�u ilk kayd�n ret tutar�n� g�ncelliyor
        FOR Rproc IN Crsprocess(Phltbreprovision.Claimid, Phltbreprovision.Sfno)
        LOOP
            FOR Rreject IN Crsreject(Phltbreprovision.Claimid, Phltbreprovision.Sfno, Rproc.Process_Code_Main, Rproc.Process_Code_Sub1,
                                                             Rproc.Process_Code_Sub2, 0, Nvl(Rproc.Seq_No, 1))
            LOOP
                UPDATE Koc_Clm_Hlth_Reject_Loss x
                     SET Location_Code = Rproc.Location_Code,
                             Cover_Code    = Rproc.Cover_Code
                 WHERE x.Rowid = Rreject.Row_Id;

                --��lem tutar� daha �nce bir redde girilmi� mi
                SELECT COUNT(1)
                    INTO Vcnt
                    FROM Koc_Clm_Hlth_Reject_Loss
                 WHERE Claim_Id = Phltbreprovision.Claimid
                     AND Sf_No = Phltbreprovision.Sfno
                     AND Add_Order_No = 1
                     AND Process_Code_Main = Rproc.Process_Code_Main
                     AND Process_Code_Sub1 = Rproc.Process_Code_Sub1
                     AND Process_Code_Sub2 = Rproc.Process_Code_Sub2
                     AND Barcode = 0
                     AND Seq_No = Rproc.Seq_No
                     AND Refuse_Amount > 0;

                IF Vcnt = 0
                THEN
                    UPDATE Koc_Clm_Hlth_Reject_Loss x SET Refuse_Amount = Nvl(Rproc.Rjctamt, 0) WHERE x.Rowid = Rreject.Row_Id;
                END IF;
            END LOOP;
        END LOOP;

        FOR Rmed IN Crsmedicine(Phltbreprovision.Claimid, Phltbreprovision.Sfno)
        LOOP
            FOR Rreject IN Crsreject(Phltbreprovision.Claimid, Phltbreprovision.Sfno, 0, 0, 0, Rmed.Barcode, Nvl(Rmed.Seq_No, 1))
            LOOP
                UPDATE Koc_Clm_Hlth_Reject_Loss x
                     SET Location_Code = Rmed.Location_Code,
                             Cover_Code    = Rmed.Cover_Code
                 WHERE x.Rowid = Rreject.Row_Id;

                --��lem tutar� daha �nce bir redde girilmi�mi
                SELECT COUNT(1)
                    INTO Vcnt
                    FROM Koc_Clm_Hlth_Reject_Loss
                 WHERE Claim_Id = Phltbreprovision.Claimid
                     AND Sf_No = Phltbreprovision.Sfno
                     AND Add_Order_No = 1
                     AND Process_Code_Main = 0
                     AND Ubb_Code = '0'
                     AND Barcode = Rmed.Barcode
                     AND Seq_No = Rmed.Seq_No
                     AND Refuse_Amount > 0;

                IF Vcnt = 0
                THEN
                    UPDATE Koc_Clm_Hlth_Reject_Loss x SET Refuse_Amount = Nvl(Rmed.Rjctamt, 0) WHERE x.Rowid = Rreject.Row_Id;
                END IF;
            END LOOP;
        END LOOP;
    END;

     PROCEDURE Setbredecision(Pprovisionreq    IN OUT Customer.Hltprv_Provision_Req_Typ,
                                                     Phltbreprovision IN OUT Customer.Hltprv_Bre_Provision_Typ) IS
        Rejectdecisions CUSTOMER.Hltprv_Bre_Decision_Tbl;
        Odndecisions    CUSTOMER.Hltprv_Bre_Decision_Tbl;
        Isrejectfound   BOOLEAN := FALSE;

        Vloccode   Koc_Clm_Hlth_Reject_Loss.Location_Code%TYPE;
        Vcovcode   Koc_Clm_Hlth_Reject_Loss.Cover_Code%TYPE;
        Vcodemain  Koc_Clm_Hlth_Reject_Loss.Process_Code_Main%TYPE;
        Vcodesub1  Koc_Clm_Hlth_Reject_Loss.Process_Code_Sub1%TYPE;
        Vcodesub2  Koc_Clm_Hlth_Reject_Loss.Process_Code_Sub2%TYPE;
        Vbarcode   Koc_Clm_Hlth_Reject_Loss.Barcode%TYPE;
        Vubbcode   Koc_Clm_Hlth_Reject_Loss.Ubb_Code%TYPE;
        Vrejectamt Koc_Clm_Hlth_Reject_Loss.Refuse_Amount%TYPE;
        Vcount     NUMBER;
        Vseqno     NUMBER;

        CURSOR Crslocation(Cpclaimid IN NUMBER,
                                             Cpsfno    IN NUMBER) IS
            SELECT Web_Location_Code Loccode
                FROM Koc_Clm_Hlth_Detail
             WHERE Claim_Id = Cpclaimid
                 AND Sf_No = Cpsfno;

        Rloc Crslocation%ROWTYPE;

        CURSOR Codndecisions IS
            SELECT DISTINCT Claimid,
                                            Odncode,
                                            Message
                FROM TABLE(Odndecisions);
    BEGIN
        --yeni provizyon ve g�ncellemede redler g�ncelleniyor
        DELETE Koc_Clm_Hlth_Reject_Loss
         WHERE Claim_Id = Phltbreprovision.Claimid
             AND Sf_No = Phltbreprovision.Sfno
             AND Add_Order_No = 1;

        ALZ_HLTPRV_UTILS.Insertbredecisionlog(Phltbreprovision.Claimid, Phltbreprovision.Provisiondate, Phltbreprovision.Policy.Groupcode, Phltbreprovision.Bredecisions,
                                                 Rejectdecisions, Odndecisions);

        IF Phltbreprovision.Healthprocesses IS NOT NULL
        THEN
            FOR i IN 1 .. Phltbreprovision.Healthprocesses.Count
            LOOP
                ALZ_HLTPRV_UTILS.Insertbredecisionlog(Phltbreprovision.Claimid, Phltbreprovision.Provisiondate, Phltbreprovision.Policy.Groupcode,
                                                         Phltbreprovision.Healthprocesses(i).Bredecisions, Rejectdecisions, Odndecisions);
            END LOOP;
        END IF;

        IF Phltbreprovision.Medicine IS NOT NULL
        THEN
            FOR i IN 1 .. Phltbreprovision.Medicine.Count
            LOOP
                ALZ_HLTPRV_UTILS.Insertbredecisionlog(Phltbreprovision.Claimid, Phltbreprovision.Provisiondate, Phltbreprovision.Policy.Groupcode,
                                                         Phltbreprovision.Medicine(i).Bredecisions, Rejectdecisions, Odndecisions);
            END LOOP;
        END IF;

        IF Phltbreprovision.Policy.Covers IS NOT NULL
        THEN
            FOR i IN 1 .. Phltbreprovision.Policy.Covers.Count
            LOOP
                ALZ_HLTPRV_UTILS.Insertbredecisionlog(Phltbreprovision.Claimid, Phltbreprovision.Provisiondate, Phltbreprovision.Policy.Groupcode,
                                                         Phltbreprovision.Policy.Covers(i).Bredecisions, Rejectdecisions, Odndecisions);
            END LOOP;
        END IF;

        IF Rejectdecisions IS NOT NULL
        THEN
            OPEN Crslocation(Phltbreprovision.Claimid, 1);

            FETCH Crslocation
                INTO Rloc;

            CLOSE Crslocation;

            FOR i IN 1 .. Rejectdecisions.Count
            LOOP
                Isrejectfound := FALSE;

                --Dosya ise
                IF Nvl(Rejectdecisions(i).Processcodemain, 0) = 0 AND
                     Nvl(Rejectdecisions(i).Processcodesub1, 0) = 0 AND
                     Nvl(Rejectdecisions(i).Processcodesub2, 0) = 0 AND
                     Nvl(Rejectdecisions(i).Barcode, 0) = 0 AND
                     Nvl(Rejectdecisions(i).Covercode, '0') = '0'
                THEN
                    Vloccode      := 0;
                    Vcovcode      := '0';
                    Vcodemain     := 0;
                    Vcodesub1     := 0;
                    Vcodesub2     := 0;
                    Vbarcode      := 0;
                    Vubbcode      := '0';
                    Vrejectamt    := 0;
                    Isrejectfound := TRUE;
                END IF;

                --Cover ise
                IF Nvl(Rejectdecisions(i).Processcodemain, 0) = 0 AND
                     Nvl(Rejectdecisions(i).Barcode, 0) = 0 AND
                     Nvl(Rejectdecisions(i).Covercode, '0') <> '0'
                THEN
                    Vloccode   := Nvl(Rloc.Loccode, 0);
                    Vcovcode   := Rejectdecisions(i).Covercode;
                    Vcodemain  := 0;
                    Vcodesub1  := 0;
                    Vcodesub2  := 0;
                    Vbarcode   := 0;
                    Vubbcode   := '0';
                    Vrejectamt := 0;

                    Isrejectfound := TRUE;
                END IF;

                --Process ise
                IF Nvl(Rejectdecisions(i).Processcodemain, 0) <> 0 AND
                     Nvl(Rejectdecisions(i).Processcodesub1, 0) <> 0 AND
                     Nvl(Rejectdecisions(i).Processcodesub2, 0) <> 0
                THEN
                    Vloccode   := Nvl(Rloc.Loccode, 0);
                    Vcovcode   := Nvl(Rejectdecisions(i).Covercode, '0');
                    Vcodemain  := Rejectdecisions(i).Processcodemain;
                    Vcodesub1  := Rejectdecisions(i).Processcodesub1;
                    Vcodesub2  := Rejectdecisions(i).Processcodesub2;
                    Vbarcode   := 0;
                    Vubbcode   := '0';
                    Vrejectamt := 0;

                    Isrejectfound := TRUE;
                END IF;

                --Medicine ise
                IF Nvl(Rejectdecisions(i).Barcode, 0) <> 0 AND
                     Nvl(Rejectdecisions(i).Processcodemain, 0) = 0
                THEN
                    Vloccode   := Nvl(Rloc.Loccode, 0);
                    Vcovcode   := Nvl(Rejectdecisions(i).Covercode, '0');
                    Vcodemain  := 0;
                    Vcodesub1  := 0;
                    Vcodesub2  := 0;
                    Vbarcode   := Rejectdecisions(i).Barcode;
                    Vubbcode   := '0';
                    Vrejectamt := 0;

                    Isrejectfound := TRUE;
                END IF;

                IF Isrejectfound
                THEN
                    Vseqno := 0;

                    --seq_no pk alan�n�n tekrarlanan i�lemlerde artarak insert i�lemi i�in yap�ld�
                    WHILE 1 = 1
                    LOOP
                        BEGIN
                            Vseqno := Nvl(Vseqno, 0) + 1;

                            INSERT INTO Koc_Clm_Hlth_Reject_Loss
                                (Claim_Id,
                                 Sf_No,
                                 Add_Order_No,
                                 Location_Code,
                                 Cover_Code,
                                 Process_Code_Main,
                                 Process_Code_Sub1,
                                 Process_Code_Sub2,
                                 Main_Code,
                                 Item_Code,
                                 Sub_Item_Code,
                                 Barcode,
                                 Refuse_Explanation,
                                 Refuse_Amount,
                                 Userid,
                                 Entry_Date,
                                 Is_Bre_Decision,
                                 Ubb_Code,
                                 Seq_No)
                            VALUES
                                (Phltbreprovision.Claimid,
                                 Phltbreprovision.Sfno,
                                 1,
                                 Vloccode,
                                 Vcovcode,
                                 Vcodemain,
                                 Vcodesub1,
                                 Vcodesub2,
                                 Rejectdecisions(i).Maincode,
                                 Rejectdecisions(i).Itemcode,
                                 Rejectdecisions(i).Subitemcode,
                                 Vbarcode,
                                 Rejectdecisions(i).Message,
                                 Vrejectamt,
                                 Pprovisionreq.Institute.Instituteusercode,
                                 SYSDATE,
                                 1,
                                 Vubbcode,
                                 Vseqno);

                            EXIT;
                        EXCEPTION
                            WHEN Dup_Val_On_Index THEN
                                NULL;
                        END;
                    END LOOP;
                END IF;
            END LOOP;

            Updaterejectamounts(Phltbreprovision);
        END IF;

        --yeni provizyon ve g�ncellemede odn ler g�ncelleniyor
        DELETE Koc_Clm_Web_Authorization WHERE Claim_Id = Phltbreprovision.Claimid;

        IF Odndecisions IS NOT NULL
        THEN
            FOR Codndecisionsrec IN Codndecisions
            LOOP
                --
                Koc_Clm_Hlth_Bpm_Utils.Insertauthorization(Codndecisionsrec.Claimid, '0', Codndecisionsrec.Odncode, Codndecisionsrec.Message);
                --
            END LOOP;
        END IF;
    END;
PROCEDURE Setpregnantdecision(Pclaimid                IN NUMBER,
                                                                Psfno                   IN NUMBER,
                                                                Paddorderno             IN NUMBER,
                                                                Psatdate                IN DATE,
                                                                Pispregnant             IN NUMBER,
                                                                Pspecialtysubject       IN VARCHAR2,
                                                                Pcontractid             IN NUMBER,
                                                                Ppartitionno            IN NUMBER,
                                                                Ppackageid              IN NUMBER,
                                                                Ppackagedate            IN DATE,
                                                                Podnpregnantrestriction IN NUMBER,
                                                                Ppregnantreject         IN NUMBER) IS
        Vreturn NUMBER;
    BEGIN
        --
        IF Nvl(Podnpregnantrestriction, 0) <> 0
        THEN
            Vreturn := Koc_Clm_Hlth_Bpm_Auth_Function.Pregnantrestriction(Pclaimid, Pspecialtysubject, Pispregnant, Pcontractid, Ppartitionno, Ppackageid,
                                                                                                                                        Ppackagedate, Psatdate);
        END IF;

        --
        IF Nvl(Ppregnantreject, 0) <> 0
        THEN
            Koc_Clm_Hlth_Utils3.Pregdecisioninsertreject(Pclaimid, Psfno, Paddorderno, Psatdate);
        END IF;
    END;
      PROCEDURE Updatehealthprovisions(Pclaimid    NUMBER,
                                                                     Psfno       NUMBER,
                                                                     Paddorderno NUMBER) IS
        CURSOR Crprovisioninfo IS
            SELECT
             /*+ Leading (A B C D) index(d.d KOC_OCP_RISK_PACKAGES_IDX2)*/
             b.Contract_Id,
             b.Oar_No,
             c.Part_Id,
             c.Ip_No,
             a.Package_Id,
             a.Package_Date,
             a.Status_Code,
             a.Class_Disease_1,
             a.Class_Disease_2,
             a.Class_Disease_3,
             a.Specialty_Subject,
             a.Institute_Code,
             a.Claim_Inst_Type,
             a.Claim_Inst_Loc,
             a.Date_Of_Loss,
             a.Provision_Date,
             d.Product_Id,
             d.Partition_Type,
             d.Term_End_Date,
             d.Group_Code,
             a.Sgk_Total,
             a.Is_Complementary
                FROM Koc_Clm_Hlth_Detail       a,
                         Clm_Pol_Oar               b,
                         Clm_Interested_Parties    c,
                         Koc_v_Health_Insured_Info d
             WHERE a.Claim_Id = Pclaimid
                 AND a.Sf_No = Psfno
                 AND a.Add_Order_No = Paddorderno
                 AND a.Claim_Id = b.Claim_Id
                 AND a.Claim_Id = c.Claim_Id
                 AND d.Contract_Id = b.Contract_Id
                 AND d.Partition_No = b.Oar_No
                 AND d.Partner_Id = c.Part_Id
                 AND d.Ip_No = c.Ip_No
                 AND d.Package_Id = a.Package_Id
                 AND d.Package_Date = a.Package_Date;

        CURSOR Crrefusalamount IS
            SELECT SUM(CASE
                                     WHEN Status_Code IN ('PR', 'R') THEN
                                        Request_Amount
                                     ELSE
                                        Refusal_Amount
                                 END) Sumrefusalamt
                FROM Koc_Clm_Hlth_Provisions
             WHERE Claim_Id = Pclaimid
                 AND Sf_No = Psfno
                 AND Add_Order_No = Paddorderno;

        CURSOR Cr1612reject(Pclaimid      IN NUMBER,
                                                Psfno         IN NUMBER,
                                                Paddorderno   IN NUMBER,
                                                Pcovercode    IN VARCHAR2,
                                                Plocationcode IN NUMBER) IS
            SELECT Nvl(SUM(Refuse_Amount), 0) Refuseamt
                FROM Koc_Clm_Hlth_Reject_Loss
             WHERE Claim_Id = Pclaimid
                 AND Sf_No = Psfno
                 AND Add_Order_No = Paddorderno
                 AND Cover_Code = Pcovercode
                 AND Location_Code = Plocationcode
                 AND Main_Code = 16
                 AND Item_Code = 12;

        CURSOR Crcovers IS
            SELECT a.Rowid,
                         a.*
                FROM Koc_Clm_Hlth_Provisions a
             WHERE Claim_Id = Pclaimid
                 AND Sf_No = Psfno
                 AND Add_Order_No = Paddorderno;

        CURSOR Price(Cpclaimid    IN NUMBER,
                                 Cpsfno       IN NUMBER,
                                 Cpaddorderno IN NUMBER,
                                 Cpcovercode  IN VARCHAR2,
                                 Cploccode    IN NUMBER) IS
            SELECT SUM(Sys_Amt) Sys_Amt,
                         SUM(Inst_Amt) Inst_Amt,
                         SUM(Request_Amt) Request_Amt,
                         SUM(Refusal_Amt) Refusal_Amt
                FROM (SELECT SUM(CASE
                                                     WHEN Indemnity_Amount IS NULL THEN
                                                        Inst_Indemnity_Amount * Nvl(Process_Count, 1)
                                                     ELSE
                                                        Indemnity_Amount * Nvl(Process_Count, 1)
                                                 END) Sys_Amt,
                                         SUM(CASE
                                                     WHEN Inst_Indemnity_Amount IS NULL THEN
                                                        Indemnity_Amount * Nvl(Process_Count, 1)
                                                     ELSE
                                                        Inst_Indemnity_Amount * Nvl(Process_Count, 1)
                                                 END) Inst_Amt,
                                         SUM(CASE
                                                     WHEN Inst_Indemnity_Amount IS NOT NULL AND
                                                                Indemnity_Amount IS NOT NULL THEN
                                                        CASE
                                                            WHEN Inst_Indemnity_Amount < Indemnity_Amount THEN
                                                             Inst_Indemnity_Amount
                                                            ELSE
                                                             Indemnity_Amount
                                                        END
                                                     WHEN Inst_Indemnity_Amount IS NOT NULL AND
                                                                Indemnity_Amount IS NULL THEN
                                                        Inst_Indemnity_Amount
                                                     WHEN Indemnity_Amount IS NOT NULL AND
                                                                Inst_Indemnity_Amount IS NULL THEN
                                                        Indemnity_Amount
                                                 END * Nvl(Process_Count, 1)) Request_Amt,
                                         SUM(CASE
                                                     WHEN Status_Code IN ('PR', 'R') THEN
                                                        CASE
                                                            WHEN Inst_Indemnity_Amount IS NOT NULL AND
                                                                     Indemnity_Amount IS NOT NULL THEN
                                                             CASE
                                                                 WHEN Inst_Indemnity_Amount < Indemnity_Amount THEN
                                                                    Inst_Indemnity_Amount
                                                                 ELSE
                                                                    Indemnity_Amount
                                                             END
                                                            WHEN Inst_Indemnity_Amount IS NOT NULL AND
                                                                     Indemnity_Amount IS NULL THEN
                                                             Inst_Indemnity_Amount
                                                            WHEN Indemnity_Amount IS NOT NULL AND
                                                                     Inst_Indemnity_Amount IS NULL THEN
                                                             Indemnity_Amount
                                                        END * Nvl(Process_Count, 1)
                                                     ELSE
                                                        0
                                                 END) Refusal_Amt
                                FROM Koc_Clm_Hlth_Proc_Detail
                             WHERE Claim_Id = Cpclaimid
                                 AND Sf_No = Cpsfno
                                 AND Add_Order_No = Cpaddorderno
                                 AND Cover_Code = Cpcovercode
                                 AND Location_Code = Cploccode
                            UNION ALL
                            SELECT SUM(a.Price * Nvl(a.Unit, 1)) Sys_Amt,
                                         SUM(a.Price * Nvl(a.Unit, 1)) Inst_Amt,
                                         SUM(a.Price * Nvl(a.Unit, 1)) Request_Amt,
                                         SUM(CASE
                                                     WHEN a.Status_Code IN ('R', 'PR') THEN
                                                        a.Price * Nvl(a.Unit, 1)
                                                     ELSE
                                                        0
                                                 END) Refusal_Amt
                                FROM Koc_Clm_Medicine_Indem_Det a
                             WHERE Claim_Id = Cpclaimid
                                 AND Sf_No = Cpsfno
                                 AND Add_Order_No = Cpaddorderno
                                 AND Cover_Code = Cpcovercode
                                 AND Location_Code = Cploccode
                            UNION ALL
                            SELECT SUM(a.Price * Nvl(a.Quantity, 1)) Sys_Amt,
                                         SUM(a.Price * Nvl(a.Quantity, 1)) Inst_Amt,
                                         SUM(a.Price * Nvl(a.Quantity, 1)) Request_Amt,
                                         SUM(CASE
                                                     WHEN a.Status_Code IN ('R', 'PR') THEN
                                                        a.Price * Nvl(a.Quantity, 1)
                                                     ELSE
                                                        0
                                                 END) Refusal_Amt
                                FROM Koc_Clm_Hlth_Item_Detail a
                             WHERE Claim_Id = Cpclaimid
                                 AND Sf_No = Cpsfno
                                 AND Add_Order_No = Cpaddorderno
                                 AND Cover_Code = Cpcovercode
                                 AND Location_Code = Cploccode);

        Rinfo           Crprovisioninfo%ROWTYPE;
        Rrejamt         Crrefusalamount%ROWTYPE;
        Rcovers         Crcovers%ROWTYPE;
        Vissgkused      BOOLEAN;
        Vsysreqamount   NUMBER;
        Vinstreqamount  NUMBER;
        Vrequestamount  NUMBER;
        Vsumprocsysamt  NUMBER;
        Vsumprocinstamt NUMBER;
        Vsgktotal       NUMBER;

        Vsumprocrequest NUMBER;

        Vsumprocreject            NUMBER;
        Vsgkusedforcover          NUMBER;
        Vsgktotalused             NUMBER := 0;
        Vsumclaimamount           NUMBER;
        Voutprovisionamount       NUMBER;
        Voutdayseance             NUMBER;
        Voutexemptionrate         NUMBER;
        Voutrexemptionsum         NUMBER;
        Voutinstexemptionsum      NUMBER;
        Voutrdayseance            NUMBER;
        Voutrcoverprice           NUMBER;
        Voutinstprovisionavalcode VARCHAR2(3);
        Voutinstiscoverval        NUMBER;
        Voutoverprice             VARCHAR2(200);
        Vcover1612rejectamt       NUMBER;

        Viscomplementary NUMBER DEFAULT 0;

        v_Complex_Enable VARCHAR(1) := 0; --complex cover mustafaku
        -- Hltprv_Log1                  Hltprv_Log_Typ := Hltprv_Log_Typ (); --- log test i�in hasan
    BEGIN
        OPEN Crprovisioninfo;

        FETCH Crprovisioninfo
            INTO Rinfo;

        CLOSE Crprovisioninfo;

        Vsgktotal := Nvl(Rinfo.Sgk_Total, 0);

        IF Vsgktotal = 0
        THEN
            SELECT SUM(Sgkamount)
                INTO Vsgktotal
                FROM (SELECT SUM(Sgk_Amount) Sgkamount
                                FROM Koc_Clm_Hlth_Proc_Detail
                             WHERE Claim_Id = Pclaimid
                                 AND Sf_No = Psfno
                                 AND Add_Order_No = Paddorderno
                            UNION ALL
                            SELECT SUM(Sgk_Amount) Sgkamount FROM Koc_Clm_Web_Notmatch_Proc WHERE Claim_Id = Pclaimid);

            UPDATE Koc_Clm_Hlth_Detail
                 SET Sgk_Total = Vsgktotal
             WHERE Claim_Id = Pclaimid
                 AND Sf_No = Psfno
                 AND Add_Order_No = Paddorderno;
        END IF;

        --
        IF Vsgktotal > 0
        THEN
            OPEN Crrefusalamount;

            FETCH Crrefusalamount
                INTO Rrejamt;

            CLOSE Crrefusalamount;

            IF Vsgktotal > Nvl(Rrejamt.Sumrefusalamt, 0)
            THEN
                Vissgkused := TRUE;
            END IF;

            UPDATE Koc_Clm_Hlth_Provisions
                 SET Sgk_Amount  = NULL,
                         Status_Code = Decode(Status_Code, 'P', 'CP', Status_Code)
             WHERE Claim_Id = Pclaimid
                 AND Sf_No = Psfno
                 AND Add_Order_No = Paddorderno;
        END IF;

        --complex cover distribution mustafaku
        SELECT Parameter INTO v_Complex_Enable FROM Koc_v_Cp_Health_Look_Up WHERE Look_Up_Code = 'CALCRULE_E';

        IF v_Complex_Enable = '1'
        THEN
            Koc_Clm_Hlth_Trnx.Set_Tmp_Indem_Totals(Rinfo.Contract_Id, Rinfo.Oar_No);
        END IF;

        OPEN Crcovers;

        LOOP
            FETCH Crcovers
                INTO Rcovers;

            EXIT WHEN Crcovers%NOTFOUND;

            Vrequestamount      := 0;
            Vsumprocsysamt      := 0;
            Vsumprocinstamt     := 0;
            Vsumprocrequest     := 0;
            Vsumprocreject      := 0;
            Vsgkusedforcover    := 0;
            Vsumclaimamount     := 0;
            Vcover1612rejectamt := 0;

            IF Rcovers.Sys_Request_Amount IS NULL
            THEN
                Rcovers.Sys_Request_Amount := Rcovers.Inst_Request_Amount;
            END IF;

            Vrequestamount := Nvl(Rcovers.Sys_Request_Amount, 0);

            IF Nvl(Rcovers.Inst_Request_Amount, 0) < Nvl(Rcovers.Sys_Request_Amount, 0)
            THEN
                Vrequestamount := Nvl(Rcovers.Inst_Request_Amount, 0);
            END IF;

            OPEN Price(Pclaimid, Psfno, Paddorderno, Rcovers.Cover_Code, Rcovers.Location_Code);

            FETCH Price
                INTO Vsumprocsysamt,
                         Vsumprocinstamt,
                         Vsumprocrequest,
                         Vsumprocreject;

            CLOSE Price;

            OPEN Cr1612reject(Pclaimid, Psfno, Paddorderno, Rcovers.Cover_Code, Rcovers.Location_Code);

            FETCH Cr1612reject
                INTO Vcover1612rejectamt;

            CLOSE Cr1612reject;

            Vsumprocreject := Nvl(Vsumprocreject, 0) - Nvl(Vcover1612rejectamt, 0);

            IF Vissgkused
            THEN
                Vsgkusedforcover := 0;

                IF Vsgktotalused < Vsgktotal
                THEN
                    IF Nvl(Vsumprocrequest, 0) >= Vsgktotal - Vsgktotalused
                    THEN
                        Vsgkusedforcover := Vsgktotal - Vsgktotalused;
                    ELSE
                        Vsgkusedforcover := Vsumprocrequest;
                    END IF;

                    Vsgktotalused := Vsgktotalused + Vsgkusedforcover;
                END IF;
            END IF;

            /* mustafaku TSS de SGK da��lmamal� �irket pay� bozulmas�n
      if vissgkused
      then
          vsumclaimamount := nvl(vsumprocrequest, 0) - nvl(vsgkusedforcover, 0);
      else
          vsumclaimamount := nvl(vsumprocrequest, 0) - (nvl(vsumprocreject,0) + nvl(vcover1612rejectamt, 0));
      end if;    */

            IF Vissgkused
            THEN
                IF Viscomplementary = 1
                THEN
                    Vsumclaimamount := Nvl(Vsumprocrequest, 0);
                ELSE
                    Vsumclaimamount := Nvl(Vsumprocrequest, 0) - Nvl(Vsgkusedforcover, 0);
                END IF;
            ELSE
                Vsumclaimamount := Nvl(Vsumprocrequest, 0) - (Nvl(Vsumprocreject, 0) + Nvl(Vcover1612rejectamt, 0));
            END IF;

            IF Vsumclaimamount < 0
            THEN
                Vsumclaimamount := 0;
            END IF;

            --
            IF Nvl(Rcovers.Status_Code, 'PP') IN ('PR', 'R')
            THEN
                Vsumclaimamount := 0;
            END IF;

            /*
         Hltprv_Log1.Servicename := 'PROVIZYON';
         Hltprv_Log1.Processinfo := 'Updatehealthprovisions';
         Hltprv_Log1.Insurednotype := 'POLICYNO';
         Hltprv_Log1.Note := NULL;
         Hltprv_Log1.Content := 'Rinfo.Provision_Date _' || to_char(Rinfo.Provision_Date);
         Hltprv_Log1.Savelogwithpragma ('YES');
      */

            IF v_Complex_Enable = '1'
            THEN
                Koc_Clm_Hlth_Trnx.Computeremaning(Rinfo.Contract_Id, Rinfo.Oar_No, Rinfo.Part_Id, Pclaimid, Psfno, Rinfo.Institute_Code,
                                                                                    Rinfo.Claim_Inst_Type, Rinfo.Claim_Inst_Loc, 0, Rcovers.Location_Code, Rcovers.Cover_Code,
                                                                                    Nvl(Rcovers.Swift_Code, Base_Swift_Code),
                                                                                    To_Date(To_Char(Rinfo.Provision_Date, 'dd/mm/yyyy') || ' ' || To_Char(SYSDATE, 'hh24:mi:ss'),
                                                                                                     'dd/mm/yyyy hh24:mi:ss'), Nvl(Rinfo.Date_Of_Loss, Rinfo.Provision_Date), Rinfo.Provision_Date,
                                                                                    Rinfo.Provision_Date, Vsumclaimamount, Rcovers.Req_Cure_Day_Count, Rcovers.User_Id,
                                                                                    Nvl(Rcovers.Is_Pool_Cover, 0), Nvl(Rcovers.Is_Special_Cover, 0), 3, Voutprovisionamount, Voutdayseance,
                                                                                    Voutexemptionrate, Voutrexemptionsum, Voutinstexemptionsum, Voutrdayseance, Voutrcoverprice,
                                                                                    Voutinstprovisionavalcode, Voutinstiscoverval, Voutoverprice, NULL,
                                                                                    Alz_Hlth_Karma_Utils.Get_Clm_Is_Referral(Pclaimid, Psfno, Paddorderno));
            ELSE
                Koc_Clm_Hlth_Trnx.Computeremaning(Rinfo.Contract_Id, Rinfo.Oar_No, Rinfo.Part_Id, Pclaimid, Psfno, Rinfo.Institute_Code,
                                                                                    Rinfo.Claim_Inst_Type, Rinfo.Claim_Inst_Loc, 0, Rcovers.Location_Code, Rcovers.Cover_Code,
                                                                                    Nvl(Rcovers.Swift_Code, Base_Swift_Code),
                                                                                    To_Date(To_Char(Rinfo.Provision_Date, 'dd/mm/yyyy') || ' ' || To_Char(SYSDATE, 'hh24:mi:ss'),
                                                                                                     'dd/mm/yyyy hh24:mi:ss'), Nvl(Rinfo.Date_Of_Loss, Rinfo.Provision_Date), Rinfo.Provision_Date,
                                                                                    Rinfo.Provision_Date, Vsumclaimamount, Rcovers.Req_Cure_Day_Count, Rcovers.User_Id,
                                                                                    Nvl(Rcovers.Is_Pool_Cover, 0), Nvl(Rcovers.Is_Special_Cover, 0), 0, Voutprovisionamount, Voutdayseance,
                                                                                    Voutexemptionrate, Voutrexemptionsum, Voutinstexemptionsum, Voutrdayseance, Voutrcoverprice,
                                                                                    Voutinstprovisionavalcode, Voutinstiscoverval, Voutoverprice, NULL,
                                                                                    Alz_Hlth_Karma_Utils.Get_Clm_Is_Referral(Pclaimid, Psfno, Paddorderno));
            END IF;

            UPDATE Koc_Clm_Hlth_Provisions
                 SET Inst_Request_Amount = Vsumprocinstamt,
                         Sys_Request_Amount  = Vsumprocsysamt,
                         Proc_Request_Amount = Vsumprocrequest,
                         Request_Amount      = Vsumprocrequest,
                         Refusal_Amount      = Vsumprocreject,
                         Provision_Total     = Voutprovisionamount * (1 - Nvl(Voutexemptionrate, 0)),
                         Exemption_Amount    = Voutrexemptionsum,
                         Exemption_Rate      = Voutexemptionrate,
                         Sgk_Amount          = Vsgkusedforcover,
                         Proc_Refusal_Amount = Vsumprocreject
             WHERE ROWID = Rcovers.Rowid;
        END LOOP;

        CLOSE Crcovers;
    END;

     PROCEDURE Updateprovisionamounts(Pclaimid    IN NUMBER,
                                                                     Psfno       IN NUMBER,
                                                                     Paddorderno IN NUMBER,
                                                                     Puserid     IN VARCHAR2) IS
    BEGIN
        Updatehealthprovisions(Pclaimid, Psfno, Paddorderno);

        Koc_Clm_Hlth_Hospt_Utils.Settransamounts(Pclaimid, Paddorderno, Psfno, Puserid);
    END;
   PROCEDURE Saveclaimfile(Pprovisionreq    IN OUT Customer.Hltprv_Provision_Req_Typ,
                                                    Phltbreprovision IN OUT Customer.Hltprv_Bre_Provision_Typ) IS
        Vclaimdetailtyp     Customer.Hlth_Detail_Row_Type;
        Vdiagnosedetailtbl  Customer.Hltprv_Dml_Diagnose_Tbl;
        Vprocessdetailtbl   Customer.Hlth_Proc_Detail_Table_Type;
        Vmedicinedetailtbl  Customer.Medicine_Indem_Det_Table_Type;
        Vitemdetailtbl      Customer.Hltprv_Dml_Item_Tbl;
        Vpatientinfoformtyp Customer.Hltprv_Dml_Patient_Form_Typ;
        Vmessage            VARCHAR2(1000);

        Vprovisiontotal  NUMBER;
        Vrequestamount   NUMBER;
        Vrefusalamount   NUMBER;
        Voutexemptionsum NUMBER;
        v_Old_Status     VARCHAR2(100);
        v_New_Status     VARCHAR2(100);
        l_Tckn           VARCHAR2(30); -- orhan topal
        Hltprv_Log       Hltprv_Log_Typ := Hltprv_Log_Typ(); -- orhan topal
        v_Request_System VARCHAR2(50);
        v_is_csuite      NUMBER;
    BEGIN
        BEGIN
            SELECT Status_Code,
                         Request_System
                INTO v_Old_Status,
                         v_Request_System
                FROM Koc_Clm_Hlth_Detail
             WHERE Claim_Id = Vclaimdetailtyp.Claim_Id
                 AND Sf_No = Vclaimdetailtyp.Sf_No;
        EXCEPTION
            WHEN OTHERS THEN
                v_Old_Status     := 'PP';
                v_Request_System := NULL;
        END;

        --g�ncelleme �ncesi versiyon yedekleme yap�l�yor
        IF Phltbreprovision.Claimid IS NOT NULL
        THEN
            --Transclaimtohist(Phltbreprovision.Claimid, Phltbreprovision.Sfno);
            Pprovisionreq.Requestsystem := Nvl(v_Request_System, Pprovisionreq.Requestsystem);
            --
        END IF;

        --Dosya ve provizyon i�in tablolara bilgileri yaz
        Setclaimdetail(Pprovisionreq, Phltbreprovision, Vclaimdetailtyp);

/*INSERT INTO Meduladatelog
  (Claim_Id, Order_No, Medula_Date)
VALUES
  (Pprovisionreq.Logid,
   3,
   'Pprovisionreq.Meduladate:' || Pprovisionreq.Meduladate ||
   'Phltbreprovision.Meduladate:' || Phltbreprovision.Meduladate||
   'Vclaimdetailtyp.Meduladate:' || Vclaimdetailtyp.Medula_Date);

*/


        Setclaimdiagnose(Phltbreprovision, Vdiagnosedetailtbl);

        Setclaimprocess(Pprovisionreq, Phltbreprovision, Vprocessdetailtbl);

        Setclaimmedicine(Pprovisionreq, Phltbreprovision, Vmedicinedetailtbl);

        Setclaimitem(Pprovisionreq, Phltbreprovision, Vitemdetailtbl);

        Setclaimpatientinfoform(Pprovisionreq, Vpatientinfoformtyp);

        Createclaimfile(Pprovisionreq, Phltbreprovision, Vclaimdetailtyp, Vprocessdetailtbl, Vmedicinedetailtbl, Vitemdetailtbl, Vdiagnosedetailtbl,
                                        Vpatientinfoformtyp, Pprovisionreq.Relationshipinfo);

        IF Phltbreprovision.Claimid IS NULL
        THEN
            Phltbreprovision.Claimid := Vclaimdetailtyp.Claim_Id;
            Phltbreprovision.Sfno    := Vclaimdetailtyp.Sf_No;
        END IF;

        IF Phltbreprovision.Claimid IS NULL
        THEN
            ROLLBACK;
            Raise_Application_Error(-20100, 'Hasar dosyas� olu�turulamad�!');
        END IF;

        Updateprovisionstatus(Phltbreprovision);

        Updatecoverstatus(Vclaimdetailtyp.Claim_Id, Vclaimdetailtyp.Sf_No, 1);

        --RET ve OTR kararlar�n� ilgili tablolara yaz
        Setbredecision(Pprovisionreq, Phltbreprovision);

        Setpregnantdecision(Vclaimdetailtyp.Claim_Id, Vclaimdetailtyp.Sf_No, 1, Pprovisionreq.Medicalinfo.Patientinfoform.Dateoflastmenstrual,
                                                Vclaimdetailtyp.Is_Pregnant, Vclaimdetailtyp.Specialty_Subject, Vclaimdetailtyp.Contract_Id, Vclaimdetailtyp.Oar_No,
                                                Vclaimdetailtyp.Package_Id, Vclaimdetailtyp.Package_Date, Phltbreprovision.Odnpregnantrestriction,
                                                Phltbreprovision.Pregnantrestriction);

        Updateprovisionamounts(Vclaimdetailtyp.Claim_Id, Vclaimdetailtyp.Sf_No, 1, Pprovisionreq.Institute.Instituteusercode);

        /*

    INSERT INTO customer.policy_status_log (LOG_ID,
                                            OLD_STATUS,
                                            NEW_STATUS,
                                            PLATFORM,
                                            ATTRIBUTE1,
                                            LOG_DATE)
         VALUES (CUSTOMER.LOG_ID_S.NEXTVAL,
                 v_old_status,
                 v_new_status,
                 'WEB - PORT ALL',
                 vclaimdetailtyp.claim_id,
                 SYSDATE);
                 */

        /*orhan topal affluent  */
        DECLARE
            p_Result     NUMBER;
            x_Policy_Ref VARCHAR(30);
            Mail_Count   NUMBER;
        BEGIN
            SELECT Policy_Ref
                INTO x_Policy_Ref
                FROM Ocp_Policy_Bases
             WHERE Contract_Id = Vclaimdetailtyp.Contract_Id
                 AND Rownum = 1;

            BEGIN
                SELECT Status_Code
                    INTO v_New_Status
                    FROM Koc_Clm_Hlth_Detail
                 WHERE Claim_Id = Vclaimdetailtyp.Claim_Id
                     AND Sf_No = Vclaimdetailtyp.Sf_No;
            EXCEPTION
                WHEN OTHERS THEN
                    v_New_Status := 'PP';
            END;

            SELECT Identity_No
                INTO l_Tckn
                FROM Koc_Cp_Partners_Ext
             WHERE Rownum = 1
                 AND Part_Id = Vclaimdetailtyp.Part_Id;

            Customer.Alz_Affluent_Customer.Get_Policy_Customer(x_Policy_Ref, l_Tckn, p_Result);

            SELECT COUNT(1)
              INTO v_is_csuite
              FROM alz_ghlth_csuite b
             WHERE b.contract_id = Phltbreprovision.Policy.Contractid
               AND b.partition_no = Phltbreprovision.Policy.Partitionno
               AND TRUNC(SYSDATE) BETWEEN b.validity_start_date AND NVL(b.validity_end_date,TRUNC(SYSDATE));

            ----KALDIR LOG CUNKU
      /*declare
         hltprv_log            hltprv_log_typ := hltprv_log_typ ();
      begin

          hltprv_log.servicename := 'PROVIZYON';
          hltprv_log.processinfo := 'GETPROVIZYON';
          hltprv_log.insuredno := x_policy_ref;
          hltprv_log.insurednotype := 'AFFLUENT_MAIL_SEND';
          hltprv_log.note := 'v_old_status ' || v_old_status || ' v_new_status: ' || v_new_status || ' p_result: ' || p_result||
                             ' Vclaimdetailtyp.Part_Id: ' || Vclaimdetailtyp.Part_Id ||
                             ' Vclaimdetailtyp.Location_Code: ' || Vclaimdetailtyp.Location_Code ||
                             ' Vclaimdetailtyp.Claim_Id: ' || Vclaimdetailtyp.Claim_Id ||
                             ' Contract id: ' || Phltbreprovision.Policy.Contractid ||
                             ' Partition no: ' || Phltbreprovision.Policy.Partitionno ||
                             ' p_is_affluent: ' || p_result ||
                             ' p_is_csuite: ' || v_is_csuite;
          hltprv_log.Content :=
                DBMS_UTILITY.format_error_backtrace
             || CHR (10)
             || ' < ERR:'
             || SQLERRM
             || ' >';

          hltprv_log.savelogwithpragma ('YES');
      end;*/
            ----KALDIR LOG CUNKU

            alz_affluent_customer.control_status(
              p_claim_id            => Vclaimdetailtyp.Claim_Id,
              p_old_status_code     => NVL(v_Old_Status,'PP'),
              p_new_status_code     => v_New_Status,
              p_web_location_code   => Vclaimdetailtyp.Location_Code,
              p_is_affluent         => p_result,
              p_is_csuite           => v_is_csuite);

            -- affluent ve yatis talebi olmasi kontrol edildi
            /*
            IF (p_Result > 0 AND Vclaimdetailtyp.Location_Code = 920)
            THEN
                IF (Nvl(v_Old_Status, 'PP') = 'PP' AND v_New_Status <> 'R')
                THEN
                    SELECT COUNT(*)
                        INTO Mail_Count
                        FROM Customer.Alz_Affluent_Mail_Log
                     WHERE Claim_Id = Vclaimdetailtyp.Claim_Id
                         AND Mail_Type = 'AFFLUENT_YATIS_TALEBI';

                    IF (Mail_Count < 1)
                    THEN
                        Customer.Alz_Affluent_Customer.Send_Mail_Hospitalization_Appl(Vclaimdetailtyp.Claim_Id);
                    END IF;
                END IF;

                IF (Nvl(v_Old_Status, 'PP') IN ('PP', 'PR') AND v_New_Status IN ('P', 'R'))
                THEN
                    SELECT COUNT(*)
                        INTO Mail_Count
                        FROM Customer.Alz_Affluent_Mail_Log
                     WHERE Claim_Id = Vclaimdetailtyp.Claim_Id
                         AND Mail_Type = 'AFFLUENT_YATIS_POZISYONU';

                    IF (Mail_Count < 1)
                    THEN
                        Customer.Alz_Affluent_Customer.Send_Mail_Hospitalization(Vclaimdetailtyp.Claim_Id);
                    END IF;
                END IF;

                IF (Nvl(v_Old_Status, 'PP') = 'P' AND v_New_Status = 'CP')
                THEN
                    SELECT COUNT(*)
                        INTO Mail_Count
                        FROM Customer.Alz_Affluent_Mail_Log
                     WHERE Claim_Id = Vclaimdetailtyp.Claim_Id
                         AND Mail_Type = 'AFFLUENT_TABURCULUK_TALEBI';

                    IF (Mail_Count < 1)
                    THEN
                        Customer.Alz_Affluent_Customer.Send_Mail_Discharge_Appl(Vclaimdetailtyp.Claim_Id);
                    END IF;
                END IF;

                IF (v_Old_Status IN ('CP', 'CPR') AND v_New_Status IN ('P', 'R'))
                THEN
                    SELECT COUNT(*)
                        INTO Mail_Count
                        FROM Customer.Alz_Affluent_Mail_Log
                     WHERE Claim_Id = Vclaimdetailtyp.Claim_Id
                         AND Mail_Type = 'AFFLUENT_TABURCULUK_PROVIZYONU';

                    IF (Mail_Count < 1)
                    THEN
                        Customer.Alz_Affluent_Customer.Send_Mail_Discharge(Vclaimdetailtyp.Claim_Id);
                    END IF;
                END IF;
            END IF;*/
        EXCEPTION
            WHEN OTHERS THEN
                Hltprv_Log.Servicename   := 'PROVIZYON';
                Hltprv_Log.Processinfo   := 'SAVECLAIMFILE';
                Hltprv_Log.Insuredno     := Phltbreprovision.Policy.Policyref;
                Hltprv_Log.Insurednotype := 'POLICYNO';
                Hltprv_Log.Note          := 'ERROR(' || SQLCODE || ')';
                Hltprv_Log.Content       := Dbms_Utility.Format_Error_Backtrace || Chr(10) || ' < ERR:' || SQLERRM || ' >';

                Hltprv_Log.Savelogwithpragma('YES');
        END;
        /*orhan topal affluent  */

    END Saveclaimfile;
  PROCEDURE Getclaimfile(Pclaimid           IN NUMBER,
                                                 Pclaimfiledetail   IN OUT Koc_Clm_Hlth_Trnx.Clmdetailtype,
                                                 Pclaimfileprocess  IN OUT Koc_Clm_Hlth_Trnx.Clmprocdetailtyp,
                                                 Pclaimfilemedicine IN OUT Koc_Clm_Hlth_Trnx.Clmmedicineindemtype,
                                                 Pclaimfilevaccine  IN OUT Koc_Clm_Hlth_Trnx.Clmvaccindemtype,
                                                 Pclaimfileitem     IN OUT Koc_Clm_Hlth_Trnx.Clmitemindemtype,
                                                 Pclaimfilecover    IN OUT Koc_Clm_Hlth_Trnx.Clmprovisiontype,
                                                 Pclaimfilereject   IN OUT Koc_Clm_Hlth_Trnx.Clmrejectiontype) IS
        --
        PROCEDURE Getclaimfiledetail IS
            CURSOR Crdetail IS
                SELECT *
                    FROM Koc_Clm_Hlth_Detail
                 WHERE Claim_Id = Pclaimid
                     AND Sf_No = 1
                     AND Add_Order_No = 1;

            Recdetail Crdetail%ROWTYPE;
        BEGIN
            OPEN Crdetail;

            FETCH Crdetail
                INTO Recdetail;

            CLOSE Crdetail;

            Pclaimfiledetail(1).Claim_Id := Recdetail.Claim_Id;
            Pclaimfiledetail(1).Sf_No := 1;
            Pclaimfiledetail(1).Process_Date := Nvl(Recdetail.Process_Date, SYSDATE);
            Pclaimfiledetail(1).Communication_No := Recdetail.Communication_No;
            Pclaimfiledetail(1).Close_Date := Recdetail.Close_Date;
            Pclaimfiledetail(1).Group_Code := Recdetail.Group_Code;
            Pclaimfiledetail(1).Provision_Fee_Charge_Date := Recdetail.Provision_Fee_Charge_Date;
            Pclaimfiledetail(1).Is_Patient_Visit_Made := Recdetail.Is_Patient_Visit_Made;
            Pclaimfiledetail(1).Identitiy_Type := Recdetail.Identitiy_Type;
            Pclaimfiledetail(1).Identity_No := Recdetail.Identity_No;
            Pclaimfiledetail(1).Institute_Code := Recdetail.Institute_Code;
            Pclaimfiledetail(1).Provision_Date := Recdetail.Provision_Date;
            Pclaimfiledetail(1).Provision_User_Id := Recdetail.Provision_User_Id;
            Pclaimfiledetail(1).Hospitalize_Date := Recdetail.Hospitalize_Date;
            Pclaimfiledetail(1).Discharge_Date := Recdetail.Discharge_Date;
            Pclaimfiledetail(1).Hospitalize_Appr_Form_Expl_1 := Recdetail.Hospitalize_Appr_Form_Expl_1;
            Pclaimfiledetail(1).Hospitalize_Appr_Form_Expl_2 := Recdetail.Hospitalize_Appr_Form_Expl_2;
            Pclaimfiledetail(1).Class_Disease_1 := Recdetail.Class_Disease_1;
            Pclaimfiledetail(1).Class_Disease_2 := Recdetail.Class_Disease_2;
            Pclaimfiledetail(1).Class_Disease_3 := Recdetail.Class_Disease_3;
            Pclaimfiledetail(1).Claim_Inst_Type := Recdetail.Claim_Inst_Type;
            Pclaimfiledetail(1).Claim_Inst_Loc := Recdetail.Claim_Inst_Loc;
            Pclaimfiledetail(1).Orig_Claim_Inst_Type := Recdetail.Orig_Claim_Inst_Type;
            Pclaimfiledetail(1).Orig_Claim_Inst_Loc := Recdetail.Orig_Claim_Inst_Loc;
            Pclaimfiledetail(1).Specialty_Subject := Recdetail.Specialty_Subject;
            Pclaimfiledetail(1).Explanation := Recdetail.Explanation;
            Pclaimfiledetail(1).Status_Code := Recdetail.Status_Code;
            Pclaimfiledetail(1).Part_Id := Recdetail.Part_Id;
            Pclaimfiledetail(1).Ext_Reference := Recdetail.Ext_Reference;
            Pclaimfiledetail(1).Dr_Name_Lastname := Recdetail.Dr_Name_Lastname;
            Pclaimfiledetail(1).Prescription_Date := Recdetail.Prescription_Date;
            Pclaimfiledetail(1).Prescription_No := Recdetail.Prescription_No;
            Pclaimfiledetail(1).Soc_Sec_Inst_App := Recdetail.Soc_Sec_Inst_App;
            Pclaimfiledetail(1).e_Prescription_No := Recdetail.e_Prescription_No;
            Pclaimfiledetail(1).Add_Order_No := Recdetail.Add_Order_No;
            Pclaimfiledetail(1).Invoice_Date := Recdetail.Invoice_Date;
            Pclaimfiledetail(1).Invoice_No := Recdetail.Invoice_No;
            Pclaimfiledetail(1).Invoice_Total := Recdetail.Invoice_Total;
            Pclaimfiledetail(1).Payment_Total := Recdetail.Payment_Total;
            Pclaimfiledetail(1).Invoice_Explanation := Recdetail.Invoice_Explanation;
            Pclaimfiledetail(1).Country_Code := Recdetail.Country_Code;
            Pclaimfiledetail(1).Deduction_Rate := Recdetail.Deduction_Rate;
            Pclaimfiledetail(1).Is_Urgent_Cure := Recdetail.Is_Urgent_Cure;
            Pclaimfiledetail(1).Shipping_Date := Recdetail.Shipping_Date;
            Pclaimfiledetail(1).Shipping_No := Recdetail.Shipping_No;
            Pclaimfiledetail(1).Is_Wrong_Provision := Recdetail.Is_Wrong_Provision;
            Pclaimfiledetail(1).Inst_Tax_Number := Recdetail.Inst_Tax_Number;
            Pclaimfiledetail(1).Inst_Tax_Office := Recdetail.Inst_Tax_Office;
            Pclaimfiledetail(1).Final_Class_Disease_1 := Recdetail.Final_Class_Disease_1;
            Pclaimfiledetail(1).Final_Class_Disease_2 := Recdetail.Final_Class_Disease_2;
            Pclaimfiledetail(1).Final_Class_Disease_3 := Recdetail.Final_Class_Disease_3;
            Pclaimfiledetail(1).Swift_Code := Recdetail.Swift_Code;
            Pclaimfiledetail(1).Dr_Diploma_No := Recdetail.Dr_Diploma_No;
            Pclaimfiledetail(1).Realization_Date := Recdetail.Realization_Date;
            Pclaimfiledetail(1).Comm_Date := Recdetail.Comm_Date;
            Pclaimfiledetail(1).Contract_Message := Recdetail.Contract_Message;
            Pclaimfiledetail(1).Date_Of_Loss := Nvl(Recdetail.Date_Of_Loss, Recdetail.Provision_Date);
            Pclaimfiledetail(1).Package_Id := Recdetail.Package_Id;
            Pclaimfiledetail(1).Package_Date := Recdetail.Package_Date;
            Pclaimfiledetail(1).Rel_Claim_Id := Recdetail.Rel_Claim_Id;
            Pclaimfiledetail(1).Prov_Demand_Date := Recdetail.Prov_Demand_Date;
            Pclaimfiledetail(1).Sgk_Total := Recdetail.Sgk_Total;
            Pclaimfiledetail(1).Is_Sgk_Used := Recdetail.Is_Sgk_Used;
            Pclaimfiledetail(1).Prescription_Type := Recdetail.Prescription_Type;
            Pclaimfiledetail(1).Poss_Hospitalize_Date := Recdetail.Poss_Hospitalize_Date;
            Pclaimfiledetail(1).Poss_Discharge_Date := Recdetail.Poss_Discharge_Date;
            Pclaimfiledetail(1).Exam_Date := Recdetail.Exam_Date;
            Pclaimfiledetail(1).Is_Ext_Doctor := Recdetail.Is_Ext_Doctor;
            Pclaimfiledetail(1).Ext_Doctor_Amt := Recdetail.Ext_Doctor_Amt;
            Pclaimfiledetail(1).Hospital_Amt := Recdetail.Hospital_Amt;
            Pclaimfiledetail(1).Doctor_Code := Recdetail.Doctor_Code;
            Pclaimfiledetail(1).Process_Exp := Recdetail.Process_Exp;
            Pclaimfiledetail(1).Is_Web := Recdetail.Is_Web;
            Pclaimfiledetail(1).From_City_Code := Recdetail.From_City_Code;
            Pclaimfiledetail(1).From_District_Code := Recdetail.From_District_Code;
            Pclaimfiledetail(1).To_City_Code := Recdetail.To_City_Code;
            Pclaimfiledetail(1).To_District_Code := Recdetail.To_District_Code;
            Pclaimfiledetail(1).From_To_Place := Recdetail.From_To_Place;
            Pclaimfiledetail(1).Other_Country_City := Recdetail.Other_Country_City;
            Pclaimfiledetail(1).Web_Location_Code := Recdetail.Web_Location_Code;
            Pclaimfiledetail(1).Patient_Complaint := Recdetail.Patient_Complaint;
            Pclaimfiledetail(1).Complaint_Start := Recdetail.Complaint_Start;
            Pclaimfiledetail(1).Last_Menst_Date := Recdetail.Last_Menst_Date;
            Pclaimfiledetail(1).Before_Complaint_Illness := Recdetail.Before_Complaint_Illness;
            Pclaimfiledetail(1).Medical_Background := Recdetail.Medical_Background;
            Pclaimfiledetail(1).Consultation_Diagnosis := Recdetail.Consultation_Diagnosis;
            Pclaimfiledetail(1).Examinations_Results := Recdetail.Examinations_Results;
            Pclaimfiledetail(1).Prediagnosis_Diagnosis := Recdetail.Prediagnosis_Diagnosis;
            Pclaimfiledetail(1).Planned_Treatment_Proc := Recdetail.Planned_Treatment_Proc;
            Pclaimfiledetail(1).Other_Country := Recdetail.Other_Country;
            Pclaimfiledetail(1).Time_Stamp := Recdetail.Time_Stamp;
            Pclaimfiledetail(1).Is_Pregnant := Recdetail.Is_Pregnant;
            Pclaimfiledetail(1).Inst_Gln_Code := Recdetail.Inst_Gln_Code;
            Pclaimfiledetail(1).Surgery_Date := Recdetail.Surgery_Date;
            Pclaimfiledetail(1).Is_Judicial := Recdetail.Is_Judicial;
            Pclaimfiledetail(1).Nationality := Recdetail.Nationality;
            Pclaimfiledetail(1).Identity_Number := Recdetail.Identity_Number;
            Pclaimfiledetail(1).Communication_Exp1 := Recdetail.Communication_Exp1;
            Pclaimfiledetail(1).Communication_Number1 := Recdetail.Communication_Number1;
            Pclaimfiledetail(1).Communication_Number2 := Recdetail.Communication_Number2;
            Pclaimfiledetail(1).Communication_Exp2 := Recdetail.Communication_Exp2;
            Pclaimfiledetail(1).Yt_Type := Recdetail.Yt_Type;
            Pclaimfiledetail(1).Doctor_Type := Recdetail.Doctor_Type;
            Pclaimfiledetail(1).Doctor_Status := Recdetail.Doctor_Status;
            Pclaimfiledetail(1).Is_Referral := Recdetail.Is_Referral;
            Pclaimfiledetail(1).Referral_Institute_Name := Recdetail.Referral_Institute_Name;
            Pclaimfiledetail(1).Personal_Notes := Recdetail.Personal_Notes;
            Pclaimfiledetail(1).Patient_Admittance_Date := Recdetail.Patient_Admittance_Date;
            Pclaimfiledetail(1).Request_Amount := Recdetail.Request_Amount;
            Pclaimfiledetail(1).Hlth_Srv_Pay := Recdetail.Hlth_Srv_Pay;
            Pclaimfiledetail(1).Dh_Inst := Recdetail.Dh_Inst;
            Pclaimfiledetail(1).Hospital_Ref_No := Recdetail.Hospital_Ref_No;
            Pclaimfiledetail(1).Request_System := Recdetail.Request_System;
            Pclaimfiledetail(1).Bre_Result_Code := Recdetail.Bre_Result_Code;
            /*20150424 emre.elcik SGK_TAKIP_NO tabloya yaz�l�yor*/
            Pclaimfiledetail(1).Is_Complementary := Recdetail.Is_Complementary;
            Pclaimfiledetail(1).Sgk_Ref_No := Recdetail.Sgk_Ref_No;
            Pclaimfiledetail(1).Is_Ahek := Recdetail.Is_Ahek;
            Pclaimfiledetail(1).medula_date := Recdetail.medula_date;
            Pclaimfiledetail(1).verifiedfrommedula := Recdetail.verifiedfrommedula;
        END;

        --
        PROCEDURE Getclaimfileprocess IS
            CURSOR Crprocess IS
                SELECT *
                    FROM Koc_Clm_Hlth_Proc_Detail
                 WHERE Claim_Id = Pclaimid
                     AND Sf_No = 1
                     AND Add_Order_No = 1;

            Recprocess Crprocess%ROWTYPE;
            Indx       NUMBER;
        BEGIN
            Indx := 0;

            OPEN Crprocess;

            LOOP
                FETCH Crprocess
                    INTO Recprocess;

                EXIT WHEN Crprocess%NOTFOUND;

                IF Recprocess.Process_Code_Main IS NOT NULL OR
                     Recprocess.Process_Code_Sub1 IS NOT NULL OR
                     Recprocess.Process_Code_Sub2 IS NOT NULL
                THEN
                    Indx := Indx + 1;

                    Pclaimfileprocess(Indx).Claim_Id := Recprocess.Claim_Id;
                    Pclaimfileprocess(Indx).Sf_No := Recprocess.Sf_No;
                    Pclaimfileprocess(Indx).Location_Code := Recprocess.Location_Code;
                    Pclaimfileprocess(Indx).Add_Order_No := Recprocess.Add_Order_No;
                    Pclaimfileprocess(Indx).Cover_Code := Recprocess.Cover_Code;
                    Pclaimfileprocess(Indx).Group_No := Recprocess.Group_No;
                    Pclaimfileprocess(Indx).Process_Code_Main := Recprocess.Process_Code_Main;
                    Pclaimfileprocess(Indx).Process_Code_Sub1 := Recprocess.Process_Code_Sub1;
                    Pclaimfileprocess(Indx).Process_Code_Sub2 := Recprocess.Process_Code_Sub2;
                    Pclaimfileprocess(Indx).Discount_Group_Code := Recprocess.Discount_Group_Code;
                    Pclaimfileprocess(Indx).Indemnity_Amount := Recprocess.Indemnity_Amount;
                    Pclaimfileprocess(Indx).Process_Group := Recprocess.Process_Group;
                    Pclaimfileprocess(Indx).Userid := Recprocess.Userid;
                    Pclaimfileprocess(Indx).Entrance_Date := Recprocess.Entrance_Date;
                    Pclaimfileprocess(Indx).Process_Count := Recprocess.Process_Count;
                    Pclaimfileprocess(Indx).Status_Code := Recprocess.Status_Code;
                    Pclaimfileprocess(Indx).Swift_Code := Recprocess.Swift_Code;
                    Pclaimfileprocess(Indx).Inst_Indemnity_Amount := Recprocess.Inst_Indemnity_Amount;
                    Pclaimfileprocess(Indx).Explanation := Recprocess.Explanation;
                    Pclaimfileprocess(Indx).Time_Stamp := Recprocess.Time_Stamp;
                    Pclaimfileprocess(Indx).Drg_Code := Recprocess.Drg_Code;
                    Pclaimfileprocess(Indx).Doctor_Code := Recprocess.Doctor_Code;
                    Pclaimfileprocess(Indx).Doctor_Status := Recprocess.Doctor_Status;
                    Pclaimfileprocess(Indx).Sgk_Amount := Recprocess.Sgk_Amount;
                    Pclaimfileprocess(Indx).Order_No := Recprocess.Order_No;
                    Pclaimfileprocess(Indx).Vat_Rate := Recprocess.Vat_Rate;
                    Pclaimfileprocess(Indx).Right_Left := Recprocess.Right_Left;
                    Pclaimfileprocess(Indx).Proc_Type := Recprocess.Proc_Type;
                    Pclaimfileprocess(Indx).Physiotherapy_Session := Recprocess.Physiotherapy_Session;
                    Pclaimfileprocess(Indx).Diagnosis_Id := Recprocess.Diagnosis_Id;
                    Pclaimfileprocess(Indx).Surgery_Id := Recprocess.Surgery_Id;
                    Pclaimfileprocess(Indx).Seq_No := Recprocess.Seq_No;
                    Pclaimfileprocess(Indx).Bre_Result_Code := Recprocess.Bre_Result_Code;
                    Pclaimfileprocess(Indx).Req_Process_Name := Recprocess.Req_Process_Name;
                    Pclaimfileprocess(Indx).Req_Process_Code := Recprocess.Req_Process_Code;
                    Pclaimfileprocess(Indx).Req_Process_List_Type := Recprocess.Req_Process_List_Type;
                    Pclaimfileprocess(Indx).Related_Process := Recprocess.Related_Process;
                    Pclaimfileprocess(Indx).Related_Process_List_Type := Recprocess.Related_Process_List_Type;
                    Pclaimfileprocess(Indx).process_date := Recprocess.process_date;
                END IF;
            END LOOP;

            CLOSE Crprocess;
        END;

        --
        PROCEDURE Getclaimfilemedicine IS
            CURSOR Crmedicine IS
                SELECT *
                    FROM Koc_Clm_Medicine_Indem_Det
                 WHERE Claim_Id = Pclaimid
                     AND Sf_No = 1
                     AND Add_Order_No = 1;

            Recmedicine Crmedicine%ROWTYPE;
            Vindx       NUMBER;
        BEGIN
            Vindx := 0;

            OPEN Crmedicine;

            LOOP
                FETCH Crmedicine
                    INTO Recmedicine;

                EXIT WHEN Crmedicine%NOTFOUND;

                Vindx := Vindx + 1;

                Pclaimfilemedicine(Vindx).Claim_Id := Recmedicine.Claim_Id;
                Pclaimfilemedicine(Vindx).Sf_No := Recmedicine.Sf_No;
                Pclaimfilemedicine(Vindx).Location_Code := Recmedicine.Location_Code;
                Pclaimfilemedicine(Vindx).Add_Order_No := Recmedicine.Add_Order_No;
                Pclaimfilemedicine(Vindx).Cover_Code := Recmedicine.Cover_Code;
                Pclaimfilemedicine(Vindx).Barcode := Recmedicine.Barcode;
                Pclaimfilemedicine(Vindx).Unit := Recmedicine.Unit;
                Pclaimfilemedicine(Vindx).Dose_Period := Recmedicine.Dose_Period;
                Pclaimfilemedicine(Vindx).Dose1 := Recmedicine.Dose1;
                Pclaimfilemedicine(Vindx).Dose2 := Recmedicine.Dose2;
                Pclaimfilemedicine(Vindx).Price := Recmedicine.Price;
                Pclaimfilemedicine(Vindx).Class_Disease_4 := Recmedicine.Class_Disease_4;
                Pclaimfilemedicine(Vindx).Second_Barcode := Recmedicine.Second_Barcode;
                Pclaimfilemedicine(Vindx).Equ_Medicine_App := Recmedicine.Equ_Medicine_App;
                Pclaimfilemedicine(Vindx).Dose3 := Recmedicine.Dose3;
                Pclaimfilemedicine(Vindx).Dose3_Period := Recmedicine.Dose3_Period;
                Pclaimfilemedicine(Vindx).Expiry_Date := Recmedicine.Expiry_Date;
                Pclaimfilemedicine(Vindx).Status_Code := Recmedicine.Status_Code;
                Pclaimfilemedicine(Vindx).Dose4 := Recmedicine.Dose4;
                Pclaimfilemedicine(Vindx).Dose4_Period := Recmedicine.Dose4_Period;
                Pclaimfilemedicine(Vindx).Reject_Uncheck := Recmedicine.Reject_Uncheck;
                Pclaimfilemedicine(Vindx).Reject_Unit := Recmedicine.Reject_Unit;
                Pclaimfilemedicine(Vindx).Reject_Explanation := Recmedicine.Reject_Explanation;
                Pclaimfilemedicine(Vindx).Control_Expiry_Date := Recmedicine.Control_Expiry_Date;
                Pclaimfilemedicine(Vindx).Second_Barc_Given := Recmedicine.Second_Barc_Given;
                Pclaimfilemedicine(Vindx).Note_Id := Recmedicine.Note_Id;
                Pclaimfilemedicine(Vindx).Barcode_2d := Recmedicine.Barcode_2d;
                Pclaimfilemedicine(Vindx).Barcode_Serial_Num := Recmedicine.Barcode_Serial_Num;
                Pclaimfilemedicine(Vindx).Barcode_Expiry_Date := Recmedicine.Barcode_Expiry_Date;
                Pclaimfilemedicine(Vindx).Barcode_Lot_Num := Recmedicine.Barcode_Lot_Num;
                Pclaimfilemedicine(Vindx).Time_Stamp := Recmedicine.Time_Stamp;
                Pclaimfilemedicine(Vindx).Item_Type := Recmedicine.Item_Type;
                Pclaimfilemedicine(Vindx).Drg_Code := Recmedicine.Drg_Code;
                Pclaimfilemedicine(Vindx).Order_No := Recmedicine.Order_No;
                Pclaimfilemedicine(Vindx).Surgery_Id := Recmedicine.Surgery_Id;
                Pclaimfilemedicine(Vindx).Vat_Rate := Recmedicine.Vat_Rate;
                Pclaimfilemedicine(Vindx).Explanation := Recmedicine.Explanation;
                Pclaimfilemedicine(Vindx).Seq_No := Recmedicine.Seq_No;
                Pclaimfilemedicine(Vindx).Bre_Result_Code := Recmedicine.Bre_Result_Code;
                Pclaimfilemedicine(Vindx).Process_Code := Recmedicine.Process_Code;
                Pclaimfilemedicine(Vindx).Process_Code_List := Recmedicine.Process_Code_List;
                Pclaimfilemedicine(Vindx).Req_Medicine_Name := Recmedicine.Req_Medicine_Name;
                Pclaimfilemedicine(Vindx).Req_Medicine_Barcode := Recmedicine.Req_Medicine_Barcode;
            END LOOP;

            CLOSE Crmedicine;
        END;

        --
        PROCEDURE Getclaimfileitem IS
            CURSOR Critem IS
                SELECT *
                    FROM Koc_Clm_Hlth_Item_Detail
                 WHERE Claim_Id = Pclaimid
                     AND Sf_No = 1
                     AND Add_Order_No = 1;

            Recitem Critem%ROWTYPE;
            Vindx   NUMBER;
        BEGIN
            Vindx := 0;

            OPEN Critem;

            LOOP
                FETCH Critem
                    INTO Recitem;

                EXIT WHEN Critem%NOTFOUND;

                Vindx := Vindx + 1;

                Pclaimfileitem(Vindx).Claim_Id := Recitem.Claim_Id;
                Pclaimfileitem(Vindx).Sf_No := Recitem.Sf_No;
                Pclaimfileitem(Vindx).Location_Code := Recitem.Location_Code;
                Pclaimfileitem(Vindx).Add_Order_No := Recitem.Add_Order_No;
                Pclaimfileitem(Vindx).Cover_Code := Recitem.Cover_Code;
                Pclaimfileitem(Vindx).Ubb_Code := Recitem.Ubb_Code;
                Pclaimfileitem(Vindx).Quantity := Recitem.Quantity;
                Pclaimfileitem(Vindx).Price := Recitem.Price;
                Pclaimfileitem(Vindx).Item_Type := Recitem.Item_Type;
                Pclaimfileitem(Vindx).Drg_Code := Recitem.Drg_Code;
                Pclaimfileitem(Vindx).Order_No := Recitem.Order_No;
                Pclaimfileitem(Vindx).Surgery_Id := Recitem.Surgery_Id;
                Pclaimfileitem(Vindx).Vat_Rate := Recitem.Vat_Rate;
                Pclaimfileitem(Vindx).Explanation := Recitem.Explanation;
                Pclaimfileitem(Vindx).Status_Code := Recitem.Status_Code;
                Pclaimfileitem(Vindx).Time_Stamp := Recitem.Time_Stamp;
                Pclaimfileitem(Vindx).Seq_No := Recitem.Seq_No;
                Pclaimfileitem(Vindx).Bre_Result_Code := Recitem.Bre_Result_Code;
                Pclaimfileitem(Vindx).Process_Code := Recitem.Process_Code;
                Pclaimfileitem(Vindx).Process_Code_List := Recitem.Process_Code_List;
                Pclaimfileitem(Vindx).Req_Item_Name := Recitem.Req_Item_Name;
                Pclaimfileitem(Vindx).Req_Item_Ubbcode := Recitem.Req_Item_Ubbcode;
            END LOOP;

            CLOSE Critem;
        END;

        --
        PROCEDURE Getclaimfilereject IS
            CURSOR Crreject IS
                SELECT *
                    FROM Koc_Clm_Hlth_Reject_Loss
                 WHERE Claim_Id = Pclaimid
                     AND Sf_No = 1
                     AND Add_Order_No = 1;

            Recreject Crreject%ROWTYPE;
            Vindx     NUMBER;
        BEGIN
            Vindx := 0;

            OPEN Crreject;

            LOOP
                FETCH Crreject
                    INTO Recreject;

                EXIT WHEN Crreject%NOTFOUND;

                Vindx := Vindx + 1;

                Pclaimfilereject(Vindx).Claim_Id := Recreject.Claim_Id;
                Pclaimfilereject(Vindx).Sf_No := Recreject.Sf_No;
                Pclaimfilereject(Vindx).Location_Code := Recreject.Location_Code;
                Pclaimfilereject(Vindx).Add_Order_No := Recreject.Add_Order_No;
                Pclaimfilereject(Vindx).Cover_Code := Recreject.Cover_Code;
                Pclaimfilereject(Vindx).Process_Code_Main := Recreject.Process_Code_Main;
                Pclaimfilereject(Vindx).Process_Code_Sub1 := Recreject.Process_Code_Sub1;
                Pclaimfilereject(Vindx).Process_Code_Sub2 := Recreject.Process_Code_Sub2;
                Pclaimfilereject(Vindx).Main_Code := Recreject.Main_Code;
                Pclaimfilereject(Vindx).Item_Code := Recreject.Item_Code;
                Pclaimfilereject(Vindx).Sub_Item_Code := Recreject.Sub_Item_Code;
                Pclaimfilereject(Vindx).Refuse_Explanation := Recreject.Refuse_Explanation;
                Pclaimfilereject(Vindx).Refuse_Amount := Recreject.Refuse_Amount;
                Pclaimfilereject(Vindx).Userid := Recreject.Userid;
                Pclaimfilereject(Vindx).Entry_Date := Recreject.Entry_Date;
                Pclaimfilereject(Vindx).Barcode := Recreject.Barcode;
                Pclaimfilereject(Vindx).Time_Stamp := Recreject.Time_Stamp;
                Pclaimfilereject(Vindx).Seq_No := Recreject.Seq_No;
                Pclaimfilereject(Vindx).Is_Bre_Decision := Recreject.Is_Bre_Decision;
                Pclaimfilereject(Vindx).Ubb_Code := Recreject.Ubb_Code;
            END LOOP;

            CLOSE Crreject;
        END;

        --
        PROCEDURE Getclaimfilecover IS
            CURSOR Crcover IS
                SELECT *
                    FROM Koc_Clm_Hlth_Provisions
                 WHERE Claim_Id = Pclaimid
                     AND Sf_No = 1
                     AND Add_Order_No = 1;

            Reccover Crcover%ROWTYPE;
            Indx     NUMBER;
        BEGIN
            Indx := 0;

            OPEN Crcover;

            LOOP
                FETCH Crcover
                    INTO Reccover;

                EXIT WHEN Crcover%NOTFOUND;

                Indx := Indx + 1;

                Pclaimfilecover(Indx).Claim_Id := Reccover.Claim_Id;
                Pclaimfilecover(Indx).Sf_No := Reccover.Sf_No;
                Pclaimfilecover(Indx).Location_Code := Reccover.Location_Code;
                Pclaimfilecover(Indx).Cover_Code := Reccover.Cover_Code;
                Pclaimfilecover(Indx).Provision_Total := Reccover.Provision_Total;
                Pclaimfilecover(Indx).Provision_Explanation := Reccover.Provision_Explanation;
                Pclaimfilecover(Indx).Day_Seance := Reccover.Day_Seance;
                Pclaimfilecover(Indx).Request_Amount := Reccover.Request_Amount;
                Pclaimfilecover(Indx).Refusal_Amount := Reccover.Refusal_Amount;
                Pclaimfilecover(Indx).Exemption_Amount := Reccover.Exemption_Amount;
                Pclaimfilecover(Indx).Swift_Code := Nvl(Reccover.Swift_Code, Base_Swift_Code);
                Pclaimfilecover(Indx).Req_Cure_Day_Count := Reccover.Req_Cure_Day_Count;
                Pclaimfilecover(Indx).Status_Code := Reccover.Status_Code;
                Pclaimfilecover(Indx).User_Id := Reccover.User_Id;
                Pclaimfilecover(Indx).Entry_Date := Reccover.Entry_Date;
                Pclaimfilecover(Indx).Country_Code := Reccover.Country_Code;
                Pclaimfilecover(Indx).Exemption_Rate := Reccover.Exemption_Rate;
                Pclaimfilecover(Indx).Proc_Request_Amount := Reccover.Proc_Request_Amount;
                Pclaimfilecover(Indx).Proc_Refusal_Amount := Reccover.Proc_Refusal_Amount;
                Pclaimfilecover(Indx).Inst_Exemption_Amount := Reccover.Inst_Exemption_Amount;
                Pclaimfilecover(Indx).Add_Order_No := Reccover.Add_Order_No;
                Pclaimfilecover(Indx).Is_Ex_Gratia := Reccover.Is_Ex_Gratia;
                Pclaimfilecover(Indx).Is_Pool_Cover := Reccover.Is_Pool_Cover;
                Pclaimfilecover(Indx).Is_Special_Cover := Reccover.Is_Special_Cover;
                Pclaimfilecover(Indx).Inst_Request_Amount := Reccover.Inst_Request_Amount;
                Pclaimfilecover(Indx).Sys_Request_Amount := Reccover.Sys_Request_Amount;
                Pclaimfilecover(Indx).r_Cover_Price := Reccover.r_Cover_Price;
                Pclaimfilecover(Indx).Prov_Date_Time := Reccover.Prov_Date_Time;
                Pclaimfilecover(Indx).Sgk_Amount := Reccover.Sgk_Amount;
                Pclaimfilecover(Indx).Add_Proc_Amount := Reccover.Add_Proc_Amount;
                Pclaimfilecover(Indx).Time_Stamp := Reccover.Time_Stamp;
                Pclaimfilecover(Indx).Order_No := Reccover.Order_No;
                Pclaimfilecover(Indx).Doctor_Code := Reccover.Doctor_Code;
                Pclaimfilecover(Indx).Doctor_Status := Reccover.Doctor_Status;
                Pclaimfilecover(Indx).Bre_Result_Code := Reccover.Bre_Result_Code;
                Pclaimfilecover(Indx).Sub_Package_Id := Reccover.Sub_Package_Id;
                Pclaimfilecover(Indx).Sub_Package_Date := Reccover.Sub_Package_Date;
            END LOOP;

            CLOSE Crcover;
        END;
    BEGIN
        Getclaimfiledetail;
        Getclaimfileprocess;
        Getclaimfilemedicine;
        Getclaimfileitem;
        Getclaimfilereject;
        Getclaimfilecover;
    END;
    PROCEDURE set_aso_prov_table(p_claim_id koc_clm_hlth_detail.claim_id%TYPE ) IS
   v_sf_no koc_clm_hlth_detail.sf_no%TYPE := 1 ;
   v_add_order_no koc_clm_hlth_detail.add_order_no%TYPE := 1 ;
   v_recsay number:=0;
   BEGIN

   -- omert - delete kapat�ld� , count kontrol eklendi SBH-2653
    select count(*) into v_recsay
      from KOC_CLM_HLTH_ASO_PROV
     WHERE CLAIM_ID       = p_claim_id
       AND SF_NO           = v_sf_no
       AND ADD_ORDER_NO   = v_add_order_no ;

   /* DELETE FROM KOC_CLM_HLTH_ASO_PROV
     WHERE CLAIM_ID       = p_claim_id
       AND SF_NO           = v_sf_no
       AND ADD_ORDER_NO   = v_add_order_no ;*/

    if v_recsay = 0 then
      INSERT INTO Koc_Clm_Hlth_Aso_Prov
        SELECT p.Claim_Id,
               p.Sf_No,
               p.Add_Order_No,
               p.Location_Code,
               p.Cover_Code,
               12, --p.aso_code,
               0, --p.aso_sub_code,
               p.Provision_Total,
               'Otomasyon ile yans�t�lm��t�r.',
               p.Cover_Code --p.associated_cover_code
          FROM Koc_Clm_Hlth_Provisions p
         WHERE Claim_Id = p_Claim_Id
           --AND Sf_No = v_Sf_No
           --AND Add_Order_No = v_Add_Order_No
           AND p.Cover_Code IN ('S767', 'S768')
           AND p.Provision_Total > 0;
   end if;
   END set_aso_prov_table;


  PROCEDURE Getprovision(Pprovisionreq    IN OUT Customer.Hltprv_Provision_Req_Typ,
                                                 Phltbreprovision IN OUT Customer.Hltprv_Bre_Provision_Typ) IS
        Vclaimfiledetail   Koc_Clm_Hlth_Trnx.Clmdetailtype;
        Vclaimfileprocess  Koc_Clm_Hlth_Trnx.Clmprocdetailtyp;
        Vclaimfilemedicine Koc_Clm_Hlth_Trnx.Clmmedicineindemtype;
        Vclaimfilevaccine  Koc_Clm_Hlth_Trnx.Clmvaccindemtype;
        Vclaimfileitem     Koc_Clm_Hlth_Trnx.Clmitemindemtype;
        Vclaimfilecover    Koc_Clm_Hlth_Trnx.Clmprovisiontype;
        Vclaimfilereject   Koc_Clm_Hlth_Trnx.Clmrejectiontype;
        Voutoverprice      VARCHAR2(1000);
    BEGIN
        /*IF ALZ_HLTPRV_UTILS.Check_Prov_Raise_Err(USER)
        THEN
            Raise_Application_Error(-20101, USER || ' isimli kullan�c� provizyonlar�nda bilgi sistem taraf�ndan hata ald�r�ld�. Bilgi Sisteme ba�vurun.');
        END IF;*/


/*INSERT INTO Meduladatelog
  (Claim_Id, Order_No, Medula_Date)
VALUES
  (Pprovisionreq.Logid,
   2,
   'Pprovisionreq.Meduladate:' || Pprovisionreq.Meduladate ||
   'Phltbreprovision.Meduladate:' || Phltbreprovision.Meduladate);

*/

        --Lastvalidationbeforeprovision(Pprovisionreq, Phltbreprovision);

        /*validasyon olarak eklendi red dosyas� olu�mayacak*/
        --deniedclaimfilecontrol (pprovisionreq, phltbreprovision);

       Saveclaimfile(Pprovisionreq, Phltbreprovision);

        --mustafaku sbingol limit problemleri 11.04.2016

        Koc_Clm_Hlth_Trnx.Reverse_Remaining_For_Web(Phltbreprovision.Claimid, 1,
                                                                                                --Phltbreprovision.Add_Order_No  ,
                                                                                                Phltbreprovision.Sfno, Phltbreprovision.Policy.Contractid, Phltbreprovision.Policy.Partitionno, USER);

        --complex cover
        IF Alz_Hltprv_Calc_Rule_Utils.Check_Ccd(Phltbreprovision.Claimid, Phltbreprovision.Sfno, 1) <> 0
        THEN
            Getclaimfile(Phltbreprovision.Claimid, Vclaimfiledetail, Vclaimfileprocess, Vclaimfilemedicine, Vclaimfilevaccine, Vclaimfileitem,
                                     Vclaimfilecover, Vclaimfilereject);

            Alz_Hltprv_Calc_Rule_Utils.Get_Calculation_Result(Vclaimfiledetail, Vclaimfilecover, Vclaimfilereject, Vclaimfiledetail(1).Provision_Date,
                                                                                                                'BRE_JEST', 'AK',
                                                                                                                --Vclaiminsttype,
                                                                                                                0, Vclaimfiledetail(1).Provision_Date, SYSDATE);
        END IF;

        --otorizasyon ve red s�re�lerinde provizyon al �al��mayacak
        IF Phltbreprovision.Breresultcode IS NULL
        THEN
            Getclaimfile(Phltbreprovision.Claimid, Vclaimfiledetail, Vclaimfileprocess, Vclaimfilemedicine, Vclaimfilevaccine, Vclaimfileitem,
                                     Vclaimfilecover, Vclaimfilereject);

            --provizyon olu�tur

/*INSERT INTO Meduladatelog
  (Claim_Id, Order_No, Medula_Date)
VALUES
  (Pprovisionreq.Logid,
   5,
   'Vclaimfiledetail(1).Meduladate:' || Vclaimfiledetail(1).medula_date ||
   'Phltbreprovision.Meduladate:' || Phltbreprovision.Meduladate);
*/
            Koc_Clm_Hlth_Trnx.Get_Provisions(Phltbreprovision.Policy.Contractid, Phltbreprovision.Policy.Partitionno, Vclaimfiledetail(1).Provision_Date,
                                                                             Pprovisionreq.Institute.Instituteusercode, Vclaimfiledetail, Vclaimfilecover, Vclaimfileprocess,
                                                                             Vclaimfilereject, Vclaimfilemedicine, Vclaimfileitem, Vclaimfilevaccine, Voutoverprice);

            set_aso_prov_table(Phltbreprovision.Claimid);--mustafa

            Koc_Clm_Hlth_Hospt_Utils.Delete_Clm_From_Web(Phltbreprovision.Claimid);

            Koc_Clm_Hlth_Hospt_Utils.Resetsyt0(Phltbreprovision.Claimid, Phltbreprovision.Sfno);
        ELSE
            --20150422 emre.elcik -- RET cevab� d�nd���nde sms g�nderir..
            --

            IF Phltbreprovision.Breresultcode = 'R'
            THEN
                IF Alz_Sms_Exceptions_Pkg.Check_Denied_Sms --MYALINKILIC: 213397 NO LU TASK ICIN GELISTIRME YAPILDI
                     (p_Claim_Id => Phltbreprovision.Claimid, p_Product_Id => Phltbreprovision.Policy.Productid,
                        p_Group_Code => Phltbreprovision.Policy.Groupcode, p_Package_Id => Phltbreprovision.Policy.Packageid,
                        p_Contract_Id => Phltbreprovision.Policy.Contractid, p_Part_Id => Phltbreprovision.Insured.Partid, p_Claim_Type => 'PROV�ZYON',
                        p_Institute_Type => Alz_Sms_Exceptions_Pkg.Get_Inst_Type(Phltbreprovision.Institutecode), p_Prov_Type => 'OTOMASYON',
                        p_Prov_Status => Phltbreprovision.Breresultcode, p_Sms_Type => 'PROV�ZYON')
                THEN
                    Koc_Clm_Hlth_Trnx.Send_Provision_Sms(Phltbreprovision.Claimid, Phltbreprovision.Sfno, 1, Phltbreprovision.Policy.Contractid,
                                                                                             Phltbreprovision.Policy.Partitionno, Phltbreprovision.Institutecode);
                END IF;
            END IF;
        END IF;
    END Getprovision;

    PROCEDURE Modifytssrequestmedicalinfo(Pprovisionreq IN OUT Customer.Hltprv_Provision_Req_Typ) IS
        -- 20150417 -- emre.elcik
        -- ULAK/TSS i�indir -
        -- On Onay Talebi geldi�inde Hizmet bazl� i�lemler silinerek, yekun bazl� i�leme �evrilir

        v_Index   PLS_INTEGER := 1;
        v_Ononay  VARCHAR2(1000) := NULL;
        v_Sikayet VARCHAR2(4000) := NULL;
    BEGIN
        IF Instr(Pprovisionreq.Medicalinfo.Patientinfoform.Complaint, '##') = 0 OR
             Substr(Pprovisionreq.Medicalinfo.Patientinfoform.Complaint, 1, 1) <> '#'
        THEN
            SELECT Pprovisionreq.Medicalinfo.Patientinfoform.Complaint INTO v_Sikayet FROM Dual;
        ELSE
            SELECT Substr(Pprovisionreq.Medicalinfo.Patientinfoform.Complaint, Instr(Pprovisionreq.Medicalinfo.Patientinfoform.Complaint, '##') + 2,
                                        Instr(Pprovisionreq.Medicalinfo.Patientinfoform.Complaint, '##', 2) -
                                         Instr(Pprovisionreq.Medicalinfo.Patientinfoform.Complaint, '##') - 2),
                         Substr(Pprovisionreq.Medicalinfo.Patientinfoform.Complaint, Instr(Pprovisionreq.Medicalinfo.Patientinfoform.Complaint, '##', 2) + 2)
                INTO v_Ononay,
                         v_Sikayet
                FROM Dual;
        END IF;

        Pprovisionreq.Medicalinfo.Patientinfoform.Complaint := v_Sikayet;

        --ULAK i�in Yek�nBazliIslemBilgileri yaz�lmas� i�in kontroller yap�l�yor..
        IF v_Ononay IS NULL
        THEN
            RETURN;
        END IF;

        IF Pprovisionreq.Medicalinfo.Serviceinformation IS NULL
        THEN
            Raise_Application_Error(-20210, 'Hatali provizyon iste�i!');
        END IF;

        IF Pprovisionreq.Medicalinfo.Serviceinformation.Count < 1
        THEN
            Raise_Application_Error(-20210, 'Hatali provizyon iste�i!');
        END IF;

        --ULAK i�in Yek�nBazliIslemBilgileri yaz�l�yor..
        v_Index := Pprovisionreq.Medicalinfo.Serviceinformation.First;

        IF Pprovisionreq.Medicalinfo.Serviceinformation(v_Index).Lumpsumprcss IS NOT NULL
        THEN
            RETURN;
        END IF;

        Pprovisionreq.Medicalinfo.Serviceinformation := NULL; -- Hizmet bazl� i�lemler silinmesi i�in servis bilgileri silinip yekun bazl� i�lemler dolduruluyor
        Pprovisionreq.Medicalinfo.Consumables        := NULL; -- Sarflar siliniyor

        Pprovisionreq.Medicalinfo.Serviceinformation := CUSTOMER.Hltprv_Serviceinfos_Tbl();
        Pprovisionreq.Medicalinfo.Serviceinformation.Extend;
        v_Index := Pprovisionreq.Medicalinfo.Serviceinformation.First;
        Pprovisionreq.Medicalinfo.Serviceinformation(v_Index) := CUSTOMER.Hltprv_Serviceinfos_Typ();

        Pprovisionreq.Medicalinfo.Serviceinformation(v_Index).Lumpsumprcss := CUSTOMER.Hltprv_Lumpsumprcss_Typ();

        Pprovisionreq.Medicalinfo.Serviceinformation(v_Index).Lumpsumprcss.Insuredcovertype := 'ULAK TEM�NAT';
        Pprovisionreq.Medicalinfo.Serviceinformation(v_Index).Lumpsumprcss.Orderno := '1';
        Pprovisionreq.Medicalinfo.Serviceinformation(v_Index).Lumpsumprcss.Amountrequest := Pprovisionreq.Amountrequest;

        IF Pprovisionreq.Sgkinfo IS NOT NULL
        THEN
            IF Nvl(Pprovisionreq.Sgkinfo.Sgkusedstatus, 0) = 1 AND
                 Nvl(Pprovisionreq.Sgkinfo.Amountsgk, 0) > 0
            THEN
                Pprovisionreq.Medicalinfo.Serviceinformation(v_Index).Lumpsumprcss.Amountsgk := Pprovisionreq.Sgkinfo.Amountsgk;
            END IF;
        END IF;

        --DR
        IF Pprovisionreq.Dr IS NOT NULL
        THEN
            Pprovisionreq.Medicalinfo.Serviceinformation(v_Index).Lumpsumprcss.Dr := CUSTOMER.Hltprv_Dr_Typ();
            Pprovisionreq.Medicalinfo.Serviceinformation(v_Index).Lumpsumprcss.Dr := Pprovisionreq.Dr;
        END IF;

        --EXPLANATION
        Pprovisionreq.Medicalinfo.Serviceinformation(v_Index).Lumpsumprcss.Explanation := CUSTOMER.Hltprv_Note_Typ();

        Pprovisionreq.Medicalinfo.Serviceinformation(v_Index).Lumpsumprcss.Explanation.Text := v_Ononay;
        --

        --PROCESSDATETIME
        Pprovisionreq.Medicalinfo.Serviceinformation(v_Index).Lumpsumprcss.Processdatetime := CUSTOMER.Hltprv_Processdatetime_Typ();

        Pprovisionreq.Medicalinfo.Serviceinformation(v_Index).Lumpsumprcss.Processdatetime.Processdate := Trunc(Pprovisionreq.Provisiondate);
        Pprovisionreq.Medicalinfo.Serviceinformation(v_Index).Lumpsumprcss.Processdatetime.Processtime := To_Char(Pprovisionreq.Provisiondate,
                                                                                                                                                                                                                            'hh24:mi:ss');

        --
        --

        --ULAK i�in HizmetBazliIslemBilgileri siliniyor..
        WHILE v_Index IS NOT NULL
        LOOP
            Pprovisionreq.Medicalinfo.Serviceinformation(v_Index).Servicebasedprocess := NULL;

            v_Index := Pprovisionreq.Medicalinfo.Serviceinformation.Next(v_Index);
        END LOOP;
        --

    END Modifytssrequestmedicalinfo;
      PROCEDURE Setglobalvariables(Pclaimid IN Koc_Clm_Hlth_Detail.Claim_Id%TYPE,
                                                             Psfno    IN Koc_Clm_Hlth_Detail.Sf_No%TYPE) IS
        Cur    Koc_Clm_Hlth_Utils.Refcur;
        Reccur Koc_v_Health_Insured_Info%ROWTYPE;
    BEGIN
        Glbaseswiftcode       := NULL;
        Glprovisiondate       := NULL;
        Glinvoicedate         := NULL;
        Glrealizationdate     := NULL;
        Gldateofloss          := NULL;
        Glclaimswf            := NULL;
        Glproductid           := NULL;
        Glpartitiontype       := NULL;
        Gltermstartdate       := NULL;
        Gltermenddate         := NULL;
        Glclaimid             := NULL;
        Glsfno                := NULL;
        Glpayclearingsystemid := NULL;
        Glpayswfclearsysid    := NULL;
        Glpaycurrgettype      := NULL;
        Glpayswfcurrgettype   := NULL;
        Glpayexchdates        := NULL;
        Glpayswfexchdates     := NULL;

        Glbaseswiftcode := Base_Swift_Code;

        Koc_Clm_Hlth_Utils.Getpolicyinfobyclaimid(Pclaimid, NULL, Cur);

        FETCH Cur
            INTO Reccur;

        CLOSE Cur;

        Glproductid     := Reccur.Product_Id;
        Glpartitiontype := Reccur.Partition_Type;
        Gltermstartdate := Reccur.Term_Start_Date;
        Gltermenddate   := Reccur.Term_End_Date;
        Glclaimid       := Pclaimid;
        Glsfno          := Psfno;

        SELECT Swift_Code,
                     Provision_Date,
                     Invoice_Date,
                     Realization_Date,
                     Date_Of_Loss
            INTO Glclaimswf,
                     Glprovisiondate,
                     Glinvoicedate,
                     Glrealizationdate,
                     Gldateofloss
            FROM (SELECT b.Swift_Code,
                                     COUNT(1) Swf_Adet,
                                     d.Provision_Date,
                                     d.Invoice_Date,
                                     d.Realization_Date,
                                     d.Date_Of_Loss
                            FROM Koc_Clm_Hlth_Detail       d,
                                     Clm_Pol_Oar               a,
                                     Koc_Clm_Hlth_Indem_Totals b
                         WHERE d.Claim_Id = Pclaimid
                             AND d.Sf_No = Psfno
                             AND d.Add_Order_No = 1
                             AND a.Claim_Id = d.Claim_Id
                             AND a.Contract_Id = b.Contract_Id
                             AND a.Oar_No = b.Partition_No
                             AND b.Claim_Inst_Type = d.Claim_Inst_Type
                             AND b.Claim_Inst_Loc = d.Claim_Inst_Loc
                             AND b.Package_Id = d.Package_Id
                             AND b.Package_Date = d.Package_Date
                         GROUP BY b.Swift_Code,
                                            d.Provision_Date,
                                            d.Invoice_Date,
                                            d.Realization_Date,
                                            d.Date_Of_Loss
                         ORDER BY 2 DESC)
         WHERE Rownum < 2;

        --23051818-1
        --raise_application_error(-20101, 'glproductid:'||glproductid||chr(10)||'glpartitiontype:'||glpartitiontype||chr(10)||'gltermstartdate:'||gltermstartdate||chr(10)||'gltermenddate:'||gltermenddate);

        SELECT Pay_Clearing_System_Id,
                     Pay_Swf_Clear_Sys_Id,
                     Pay_Curr_Get_Type,
                     Pay_Swf_Curr_Get_Type,
                     Pay_Exch_Dates,
                     Pay_Swf_Exch_Dates
            INTO Glpayclearingsystemid,
                     Glpayswfclearsysid,
                     Glpaycurrgettype,
                     Glpayswfcurrgettype,
                     Glpayexchdates,
                     Glpayswfexchdates
            FROM Koc_Oc_Prod_Partition_Rel
         WHERE Product_Id = Glproductid
             AND Partition_Type = Glpartitiontype
             AND Validity_Start_Date <= Gltermstartdate
             AND (Validity_End_Date IS NULL OR Validity_End_Date >= Gltermenddate);
    END;
     FUNCTION Convertprovisionstatuscode(Pclaimid    IN NUMBER,
                                                                            Psfno       IN NUMBER,
                                                                            Paddorderno IN NUMBER,
                                                                            Pstatuscode IN VARCHAR2,
                                                                            Ispool      IN NUMBER DEFAULT NULL) RETURN VARCHAR2 IS
        CURSOR Crabsentdoc(Cpclaimid IN NUMBER) IS
            SELECT 1
                FROM Koc_Clm_Web_Auth_Pool
             WHERE Claim_Id = Cpclaimid
                 AND Nvl(Status_Code, 'U') = 'AD';

        CURSOR Crrefusal(Cpclaimid    IN NUMBER,
                                         Cpsfno       IN NUMBER,
                                         Cpaddorderno IN NUMBER) IS
            SELECT Nvl(SUM(Refusal_Amount), 0) Refusalamt
                FROM Koc_Clm_Hlth_Provisions
             WHERE Claim_Id = Cpclaimid
                 AND Sf_No = Cpsfno
                 AND Add_Order_No = Cpaddorderno;

        Vstatus VARCHAR2(20);
    BEGIN
        IF Nvl(Pstatuscode, 'PP') = 'P'
        THEN
            Vstatus := 'ONAY';

            FOR Recrefusal IN Crrefusal(Pclaimid, Psfno, Paddorderno)
            LOOP
                IF Recrefusal.Refusalamt > 0
                THEN
                    Vstatus := 'KISMI_ONAY';
                END IF;
            END LOOP;
        ELSIF Nvl(Pstatuscode, 'PP') IN ('PR', 'R')
        THEN
            Vstatus := 'RED';
        ELSIF Nvl(Pstatuscode, 'PP') IN ('C')
        THEN
            IF Nvl(Ispool, 0) = 0
            THEN
                -- alz_hltprv_utils.gethltprvtssdetailqueryrespobj metodunda resonse decision_type kodu i�in i�leniyor ve iptal edildi enumu olmda��� i�in bu �ekilde yap�ld�
                Vstatus := 'IPTAL_EDILDI';
            ELSE
                Vstatus := NULL;
            END IF;
        ELSIF Nvl(Pstatuscode, 'PP') IN ('PP', 'CP')
        THEN
            IF Nvl(Ispool, 0) = 0
            THEN
                Vstatus := 'ISLENIYOR';
            ELSE
                Vstatus := 'ISTEK'; --null;
            END IF;

            FOR Recabsent IN Crabsentdoc(Pclaimid)
            LOOP
                Vstatus := 'BELGE_BEKLENIYOR';
            END LOOP;
        ELSIF Nvl(Pstatuscode, 'PP') IN ('I', 'MI', 'TI', 'TMI')
        THEN
            Vstatus := 'ARASTIRMA';
        END IF;

        RETURN Vstatus;
    END;
     PROCEDURE Getabsentdoclist(Pclaimid    IN Koc_Clm_Hlth_Detail.Claim_Id%TYPE,
                                                         Psfno       IN Koc_Clm_Hlth_Detail.Sf_No%TYPE,
                                                         Paddorderno IN Koc_Clm_Hlth_Detail.Add_Order_No%TYPE,
                                                         Cur         IN OUT KOC_CLM_HLTH_TRNX.Refcur) IS
    BEGIN
        --
        IF Cur%ISOPEN
        THEN
            CLOSE Cur;
        END IF;

        OPEN Cur FOR
            SELECT DISTINCT Nvl(x.Status_Code, 'X') Statuscode,
                                            y.Explanation || ' ' || y.Explanation2 Explanation,
                                            y.Letter_No Letterno
                FROM Koc_Clm_Hlth_Incomp_Papers x,
                         (SELECT Absentdoc_Id,
                                         Letter_Content
                                FROM Koc_Cc_Incomp_Paper_Ref a,
                                         Cur_Translations        b,
                                         Koc_Cp_Health_Look_Up   c
                             WHERE c.Desc_Int_Id = b.Desc_Int_Id
                                 AND a.Sub_Kod = c.Parameter
                                 AND b.Sula_Ora_Nls_Code = 'TR') Lt,
                         Koc_Clm_Ltr_Doc_Process y
             WHERE x.Claim_Id = Pclaimid
                 AND x.Sf_No = Psfno
                 AND x.Add_Order_No = Paddorderno
                 AND x.Absent_Doc_Code = Lt.Absentdoc_Id
                 AND y.Claim_Id = x.Claim_Id
                 AND y.Sf_No = x.Sf_No
                 AND y.Add_Order_No = x.Add_Order_No
                 AND REPLACE(y.Explanation, Chr(10), '') = Rtrim(Lt.Letter_Content)
                 AND Nvl(x.Status_Code, 'X') <> 'C'
             ORDER BY y.Letter_No DESC;
    END;


     PROCEDURE Fillprovisionreqstatus(Pclaimid IN Koc_Clm_Hlth_Detail.Claim_Id%TYPE,
                                                                     Psfno    IN Koc_Clm_Hlth_Detail.Sf_No%TYPE,
                                                                     Presp    IN OUT Customer.Hltprv_Provision_Resp_Typ) IS
        CURSOR Crdetail(Cpclaimid IN NUMBER,
                                        Cpsfno    IN NUMBER) IS
            SELECT Status_Code,
                         Provision_Date
                FROM Koc_Clm_Hlth_Detail
             WHERE Claim_Id = Cpclaimid
                 AND Sf_No = Cpsfno
                 AND Add_Order_No = 1;

        CURSOR Crcancelexp(Cpclaimid IN NUMBER,
                                             Cpsfno    IN NUMBER) IS
            SELECT Explanation Expl
                FROM Koc_Clm_Hlth_Indem_Dec
             WHERE Claim_Id = Cpclaimid
                 AND Sf_No = Cpsfno
                 AND Add_Order_No = 1
                 AND File_Agreement_Code = 'C';

        CURSOR Crodnexpl(Cpclaimid IN NUMBER) IS
            SELECT a.Explanation Expl FROM Koc_Clm_Web_Authorization a WHERE a.Claim_Id = Cpclaimid;

        Vlast     NUMBER;
        Recdetail Crdetail%ROWTYPE;
        Cur       KOC_CLM_HLTH_TRNX.Refcur;

        Vadstatuscode  VARCHAR2(10);
        Vadexplanation VARCHAR2(4000);
        Vadletterno    NUMBER(2);
        Vcnt           NUMBER;

        Hltprv_Log Hltprv_Log_Typ;
    BEGIN
        OPEN Crdetail(Pclaimid, Psfno);

        FETCH Crdetail
            INTO Recdetail;

        IF Crdetail%NOTFOUND
        THEN
            CLOSE Crdetail;

            Raise_Application_Error(-20101, 'Provizyon hasar dosyas� bulunamad�!');
        END IF;

        CLOSE Crdetail;

        --Talep Durumu sadece otorizasyon ve iptallerde dolmal�d�r.
        IF Nvl(Recdetail.Status_Code, 'PP') IN ('PP', 'CP', 'C')
        THEN
            IF Presp.Resultinfo IS NULL
            THEN
                Presp.Resultinfo := CUSTOMER.Hltprv_Result_Typ();
            END IF;

            IF Presp.Resultinfo.Requeststatus IS NULL
            THEN
                Presp.Resultinfo.Requeststatus := CUSTOMER.Hltprv_Requeststatus_Typ();
            END IF;

            Presp.Resultinfo.Requeststatus.Statuscode := Convertprovisionstatuscode(Pclaimid, Psfno, 1, Recdetail.Status_Code);

            IF Presp.Resultinfo.Requeststatus.Statuscode = 'IPTAL_EDILDI'
            THEN
                Presp.Resultinfo.Requeststatus.Explanation := Customer.Hltprv_Note_Tbl();
                Presp.Resultinfo.Requeststatus.Explanation.Extend;
                Presp.Resultinfo.Requeststatus.Explanation(1) := Customer.Hltprv_Note_Typ();

                FOR Rec IN Crcancelexp(Pclaimid, Psfno)
                LOOP
                    Presp.Resultinfo.Requeststatus.Explanation(1).Text := Rec.Expl;
                END LOOP;
            ELSIF Presp.Resultinfo.Requeststatus.Statuscode IN ('ISLENIYOR', 'BELGE_BEKLENIYOR')
            THEN
                Presp.Resultinfo.Requeststatus.Explanation := Customer.Hltprv_Note_Tbl();

                FOR Rec IN Crodnexpl(Pclaimid)
                LOOP
                    Presp.Resultinfo.Requeststatus.Explanation.Extend;
                    Vlast := Presp.Resultinfo.Requeststatus.Explanation.Last;

                    Presp.Resultinfo.Requeststatus.Explanation(Vlast) := Customer.Hltprv_Note_Typ();
                    Presp.Resultinfo.Requeststatus.Explanation(Vlast).Text := Rec.Expl;
                END LOOP;

                --BPM s�reci hen�z tetiklenmedi�inden havuz tablolar�ndan eksik evrak dafault yaz�s� okunam�yor

                IF Presp.Resultinfo.Requeststatus.Statuscode IN ('ISLENIYOR')
                THEN
                    Presp.Resultinfo.Requeststatus.Explanation.Extend;
                    Vlast := Presp.Resultinfo.Requeststatus.Explanation.Last;

                    Presp.Resultinfo.Requeststatus.Explanation(Vlast) := Customer.Hltprv_Note_Typ();

                    BEGIN
                        SELECT Substr(r.Letter_Content, 1, 75)
                            INTO Presp.Resultinfo.Requeststatus.Explanation(Vlast).Text
                            FROM Koc_Cc_Incomp_Paper_Ref r
                         WHERE Sub_Kod = '0536'
                             AND Rownum < 2;
                    EXCEPTION
                        WHEN OTHERS THEN
                            NULL;
                    END;

                    Presp.Resultinfo.Requeststatus.Explanation(Vlast).Text := Presp.Resultinfo.Requeststatus.Explanation(Vlast)
                                                                                                                                        .Text || Chr(10) ||
                                                                                                                                         '- AYAKTA TEDAVI TALEPLERINIZ I�IN "HASTA BILGI FORMU", "TETKIK ISTEM FORMU" VE VARSA TETKIK SONU�LARINI, "EKSIK EVRAK FORMU" VEYA "FAX G�NDERIM FORMU" ESLIGINDE TARAFIMIZA G�NDERINIZ.' ||
                                                                                                                                         Chr(10) ||
                                                                                                                                         '- YATARAK TEDAVI TALEPLERINIZ I�IN "HASTA BILGI FORMU", "TETKIK ISTEM FORMU" VE VARSA TETKIK SONU�LARI ILE TEDAVI PROTOKOL� VE DOKTOR RAPORLARINI "EKSIK EVRAK FORMU" VEYA "FAX G�NDERIM FORMU" ESLIGINDE TARAFIMIZA G�NDERINIZ.' ||
                                                                                                                                         Chr(10) ||
                                                                                                                                         '- TRAFIK KAZASI VEYA DIGER ADLI VAKALARDA, T�M MATBU ADLI EVRAKLARI G�NDERMEYI UNUTMAYINIZ.';
                END IF;

                --
                IF Presp.Resultinfo.Requeststatus.Statuscode IN ('BELGE_BEKLENIYOR')
                THEN
                    Getabsentdoclist(Pclaimid, Psfno, 1, Cur);

                    Vcnt := 0;

                    LOOP
                        Vadstatuscode  := NULL;
                        Vadexplanation := NULL;
                        Vadletterno    := NULL;

                        FETCH Cur
                            INTO Vadstatuscode,
                                     Vadexplanation,
                                     Vadletterno;

                        EXIT WHEN Cur%NOTFOUND;

                        IF Vcnt = 0
                        THEN
                            IF Vadexplanation IS NOT NULL
                            THEN
                                Presp.Resultinfo.Requeststatus.Explanation.Extend;
                                Vlast := Presp.Resultinfo.Requeststatus.Explanation.Last;

                                Presp.Resultinfo.Requeststatus.Explanation(Vlast) := Customer.Hltprv_Note_Typ();
                                Presp.Resultinfo.Requeststatus.Explanation(Vlast).Text := 'Provizyon talebiniz a�a��da belirtilen eksik bilgi / belgeler tamamland�ktan sonra de�erlendirmeye al�nacakt�r.';
                            END IF;
                        END IF;

                        --
                        IF Vadexplanation IS NOT NULL
                        THEN
                            Presp.Resultinfo.Requeststatus.Explanation.Extend;
                            Vlast := Presp.Resultinfo.Requeststatus.Explanation.Last;

                            Presp.Resultinfo.Requeststatus.Explanation(Vlast) := Customer.Hltprv_Note_Typ();
                            Presp.Resultinfo.Requeststatus.Explanation(Vlast).Text := Vadexplanation;
                        END IF;

                        Vcnt := Vcnt + 1;
                    END LOOP;
                END IF;

                Presp.Resultinfo.Requeststatus.Statuscode := 'ISLENIYOR';
            ELSE
                Presp.Resultinfo.Requeststatus.Statuscode := NULL;
            END IF;
        END IF;
    END;
       PROCEDURE Gethltprvinsuredobj(Phltprvinsuredreq IN OUT Customer.Hltprv_Iq_Insured_Req_Typ,
                                                                Phltprvinsured    OUT Customer.Hltprv_Iq_Insured_Typ,
                                                                Pprocessresults   IN OUT Customer.Process_Result_Table) IS
    BEGIN
        Phltprvinsuredreq.Writeobjecttolog(Phltprvinsuredreq.Logid);

        Phltprvinsured := Customer.Hltprv_Iq_Insured_Typ();

        Phltprvinsured.Logid         := Phltprvinsuredreq.Logid;
        Phltprvinsured.Origindate    := Phltprvinsuredreq.Origindate;
        Phltprvinsured.Requestsystem := Phltprvinsuredreq.Requestsystem;

        IF Nvl(Phltprvinsuredreq.Requestsystem, '##requestsystem##') NOT IN ('PORTAL', 'OPUS')
        THEN
            Phltprvinsuredreq.Validateattributes;
        END IF;

        Phltprvinsured := Customer.Hltprv_Iq_Insured_Typ(Phltprvinsuredreq, Pprocessresults);

        IF Phltprvinsured.Partid IS NULL
        THEN
            Phltprvinsured := NULL;
        ELSE
            Phltprvinsured.Writeobjecttolog(Phltprvinsured.Logid);

            IF Nvl(Phltprvinsured.Requestsystem, '##requestsystem##') NOT IN ('PORTAL', 'OPUS')
            THEN
                Phltprvinsured.Validateattributes;
            END IF;
        END IF;

        Alz_Hltprv_Control_Utils.Insured_Query(Phltprvinsuredreq, Phltprvinsured, Pprocessresults);
    END;

     PROCEDURE Fillprovisioninsured(Pclaimid    IN NUMBER,
                                                                 Psfno       IN NUMBER,
                                                                 Preqsys     IN VARCHAR2,
                                                                 Plogid      IN NUMBER,
                                                                 Porigindate IN DATE,
                                                                 Pinst       IN CUSTOMER.Hltprv_Institute_Typ,
                                                                 Pinstpass   IN CUSTOMER.Hltprv_Institutepass_Typ,
                                                                 Presp       IN OUT Customer.Hltprv_Provision_Resp_Typ) IS
        CURSOR Crcardno(Cpclaimid IN NUMBER,
                                        Cpsfno    IN NUMBER) IS
            SELECT /*+rule*/ Card_No, -- neslihank T2869361 �a�r�s� ile yap�lm��t�r. ileriki tarihli ��k��larda poli�e bilgileri d�nm�yordu.
                         Ext_Reference,
                         Type_Of_Interest Relationship,
                         Policy_Ref
                FROM Koc_v_Health_Insured_Info  a,
                         Koc_Hlth_Customer_Id_Cards b,
                         Koc_Clm_Hlth_Detail        h
             WHERE a.Partner_Id = b.Part_Id
                 AND a.Partner_Id = h.Part_Id
                 AND Claim_Id = Cpclaimid
                 AND Sf_No = Cpsfno
                 AND a.Term_Start_Date <= Nvl(Trunc(h.Provision_Date), a.Term_Start_Date)
                 AND a.Term_End_Date >= Nvl(Trunc(h.Provision_Date), a.Term_End_Date)
                 AND (Decode(Term_Start_Date, NULL, SYSDATE, Term_Start_Date_Time) <= h.Provision_Date)
                 AND (Decode(Term_End_Date, NULL, SYSDATE, Term_End_Date_Time) >= h.Provision_Date)
                 AND ((a.Action_Code != 'D' AND a.Package_Status != 'D') OR a.Action_Code = 'D')
                 AND Rownum < 2;

        /*
    SELECT d.Card_No,
           s.Ext_Reference,
           b.Type_Of_Interest Relationship,
           e.Policy_Ref                                 --eelcik 20150310
      FROM Clm_Pol_Oar a,
           Clm_Subfiles s,
           Ocp_Ip_Links b,
           Ocp_Interested_Parties c,
           Koc_Hlth_Customer_Id_Cards d,
           Koc_Clm_Hlth_Detail h,
           Clm_Pol_Bases e
     WHERE     a.Claim_Id = Cpclaimid
           AND s.Claim_Id = a.Claim_Id
           AND s.Sf_No = Cpsfno
           AND s.Sf_Type = 'HLT'
           AND a.Contract_Id = b.Contract_Id
           AND a.Oar_No = b.Partition_No
           AND b.Top_Indicator = 'Y'
           AND b.Action_Code <> 'D'
           AND b.Contract_Id = c.Contract_Id
           AND b.Ip_No = c.Ip_No
           AND c.Top_Indicator = 'Y'
           AND c.Action_Code <> 'D'
           AND c.Partner_Id = d.Part_Id
           AND h.Claim_Id = s.Claim_Id
           AND h.Sf_No = s.Sf_No
           AND (   d.Validity_End_Date IS NULL
                OR d.Validity_End_Date >= TRUNC (h.Provision_Date))
           AND a.Claim_Id = e.Claim_Id
           AND a.Contract_Id = e.Contract_Id
           AND ROWNUM < 2;*/

        Vhltprvinsuredreq Customer.Hltprv_Iq_Insured_Req_Typ;
        Vhltprvinsured    Customer.Hltprv_Iq_Insured_Typ;
        Vlast             NUMBER;
        Vextreference     Clm_Subfiles.Ext_Reference%TYPE;
        Vprocessresults   Customer.Process_Result_Table := Customer.Process_Result_Table();
        Vrelationship     VARCHAR2(10);
        Vpolicyref        Clm_Pol_Bases.Policy_Ref%TYPE;
    BEGIN
        Vhltprvinsuredreq := Customer.Hltprv_Iq_Insured_Req_Typ();

        Vhltprvinsuredreq.Sourcetype    := Preqsys;
        Vhltprvinsuredreq.Institute     := Pinst;
        Vhltprvinsuredreq.Institutepass := Pinstpass;

        FOR Rec IN Crcardno(Pclaimid, Psfno)
        LOOP
            Vhltprvinsuredreq.Origindate    := Porigindate;
            Vhltprvinsuredreq.Requestsystem := Preqsys;
            Vhltprvinsuredreq.Logid         := Plogid;

            Vhltprvinsuredreq.Search            := CUSTOMER.Hltprv_Iq_Search_Typ();
            Vhltprvinsuredreq.Search.Searchtype := 'SigortaliKartNo';
            Vhltprvinsuredreq.Search.Searchid   := Rec.Card_No;
            Vextreference                       := Rec.Ext_Reference;
            Vrelationship                       := Rec.Relationship;
            Vpolicyref                          := Rec.Policy_Ref;
        END LOOP;

        Gethltprvinsuredobj(Vhltprvinsuredreq, Vhltprvinsured, Vprocessresults);

        IF Vprocessresults IS NOT NULL
        THEN
            IF Vprocessresults.Count > 0
            THEN
                RETURN;
                --raise_application_error(-20210, 'Sigortal� bilgileri okunurken hata ile kar��la��ld�.HataNo :'||vprocessresults(1).error_no||' - Hata:'||vprocessresults(1).reason||'-'||vprocessresults(1).action);
            END IF;
        END IF;

        IF Presp.Resultinfo IS NULL
        THEN
            Presp.Resultinfo := CUSTOMER.Hltprv_Result_Typ();
        END IF;

        IF Presp.Resultinfo.Resultreturning IS NULL
        THEN
            Presp.Resultinfo.Resultreturning := CUSTOMER.Hltprv_Resultreturning_Typ();
        END IF;

        Presp.Resultinfo.Resultreturning.Insured_Resp := CUSTOMER.Hltprv_Pinsured_Resp_Typ();

        --Id
        Presp.Resultinfo.Resultreturning.Insured_Resp.Id := NULL;

        Presp.Resultinfo.Resultreturning.Insured_Resp.Insuredno := CUSTOMER.Hltprv_Insuredno_Tbl();

        --SigortaliNumaraListesi
        --MusteriNo
        IF Vhltprvinsured.Partid IS NOT NULL
        THEN
            Presp.Resultinfo.Resultreturning.Insured_Resp.Insuredno.Extend;
            Vlast := Presp.Resultinfo.Resultreturning.Insured_Resp.Insuredno.Last;
            Presp.Resultinfo.Resultreturning.Insured_Resp.Insuredno(Vlast) := Customer.Hltprv_Insuredno_Typ();

            Presp.Resultinfo.Resultreturning.Insured_Resp.Insuredno(Vlast).Insurednotype := 'MUSTERI_NO';
            Presp.Resultinfo.Resultreturning.Insured_Resp.Insuredno(Vlast).Insuredno := Vhltprvinsured.Partid;
        END IF;

        --SigortaliNumaraListesi
        --TCKimlikNo
        --YabanciKimlikNo
        IF Vhltprvinsured.Identityno IS NOT NULL
        THEN
            Presp.Resultinfo.Resultreturning.Insured_Resp.Insuredno.Extend;
            Vlast := Presp.Resultinfo.Resultreturning.Insured_Resp.Insuredno.Last;
            Presp.Resultinfo.Resultreturning.Insured_Resp.Insuredno(Vlast) := Customer.Hltprv_Insuredno_Typ();

            IF Substr(Vhltprvinsured.Identityno, 1, 1) = '9'
            THEN
                Presp.Resultinfo.Resultreturning.Insured_Resp.Insuredno(Vlast).Insurednotype := 'YABANCI_KIMLIK_NO';
                Presp.Resultinfo.Resultreturning.Insured_Resp.Insuredno(Vlast).Insuredno := Vhltprvinsured.Identityno;
            ELSE
                Presp.Resultinfo.Resultreturning.Insured_Resp.Insuredno(Vlast).Insurednotype := 'TC_KIMLIK_NO';
                Presp.Resultinfo.Resultreturning.Insured_Resp.Insuredno(Vlast).Insuredno := Vhltprvinsured.Identityno;
            END IF;
        END IF;

        --SigortaliNumaraListesi
        --SigortaliKartNo
        IF Vhltprvinsured.Cardno IS NOT NULL
        THEN
            Presp.Resultinfo.Resultreturning.Insured_Resp.Insuredno.Extend;
            Vlast := Presp.Resultinfo.Resultreturning.Insured_Resp.Insuredno.Last;
            Presp.Resultinfo.Resultreturning.Insured_Resp.Insuredno(Vlast) := Customer.Hltprv_Insuredno_Typ();

            Presp.Resultinfo.Resultreturning.Insured_Resp.Insuredno(Vlast).Insurednotype := 'SIGORTALI_KART_NO';
            Presp.Resultinfo.Resultreturning.Insured_Resp.Insuredno(Vlast).Insuredno := Vhltprvinsured.Cardno;
        END IF;

        Presp.Resultinfo.Resultreturning.Insured_Resp.Firstname        := Vhltprvinsured.Firstname;
        Presp.Resultinfo.Resultreturning.Insured_Resp.Surname          := Vhltprvinsured.Surname;
        Presp.Resultinfo.Resultreturning.Insured_Resp.Sex              := Lower(Vhltprvinsured.Sex);
        Presp.Resultinfo.Resultreturning.Insured_Resp.Dateofbirth      := Vhltprvinsured.Dateofbirth;
        Presp.Resultinfo.Resultreturning.Insured_Resp.Fathername       := Vhltprvinsured.Fathername;
        Presp.Resultinfo.Resultreturning.Insured_Resp.Mothername       := Vhltprvinsured.Mothername;
        Presp.Resultinfo.Resultreturning.Insured_Resp.Mobilephone      := Vhltprvinsured.Mobilephone;
        Presp.Resultinfo.Resultreturning.Insured_Resp.Phone            := Vhltprvinsured.Phonenumber;
        Presp.Resultinfo.Resultreturning.Insured_Resp.Beneficiarygroup := Vhltprvinsured.Beneficiarygroup;

        --
        IF Vrelationship = 'K'
        THEN
            Presp.Resultinfo.Resultreturning.Insured_Resp.Relationship := 'FERT';
        ELSIF Vrelationship = 'E'
        THEN
            Presp.Resultinfo.Resultreturning.Insured_Resp.Relationship := 'ES';
        ELSIF Vrelationship IN ('KZ', '�', 'O')
        THEN
            Presp.Resultinfo.Resultreturning.Insured_Resp.Relationship := 'COCUK';
        ELSE
            Presp.Resultinfo.Resultreturning.Insured_Resp.Relationship := 'DIGER';
        END IF;

        --Aciklama ???? Gerekli alanlara bak
        IF Vhltprvinsured.Policymessage IS NOT NULL
        THEN
            NULL;
            --presp.resultinfo.resultreturning.insured_resp.explanation := customer.hltprv_note_tbl();
            --presp.resultinfo.resultreturning.insured_resp.explanation.extend;
            --presp.resultinfo.resultreturning.insured_resp.explanation(1) := customer.hltprv_note_typ();
            --presp.resultinfo.resultreturning.insured_resp.explanation(1).notes := hltprv_explanation_tbl();
            --presp.resultinfo.resultreturning.insured_resp.explanation(1).notes.extend;
            --presp.resultinfo.resultreturning.insured_resp.explanation(1).notes(1) := customer.hltprv_explanation_typ();
            --presp.resultinfo.resultreturning.insured_resp.explanation(1).notes(1).text := vhltprvinsured.policymessage;
        END IF;

        Presp.Resultinfo.Resultreturning.Insured_Resp.Productinfo := CUSTOMER.Hltprv_Productinfo_Typ();
        --eelcik -- 20150310 -- FOR TSS
        Presp.Resultinfo.Resultreturning.Insured_Resp.Productinfo.Iscomplementary := 0;

        FOR i IN 1 .. Vhltprvinsured.Policies.Count
        LOOP
            IF Vhltprvinsured.Policies(i).Policyref = Vpolicyref
            THEN
                --VipBilgileri
                Presp.Resultinfo.Resultreturning.Insured_Resp.Vipinfo            := CUSTOMER.Hltprv_Vipinfo_Typ();
                Presp.Resultinfo.Resultreturning.Insured_Resp.Vipinfo.Vipinfo    := Vhltprvinsured.Policies(i).Vipinfo;
                Presp.Resultinfo.Resultreturning.Insured_Resp.Vipinfo.Vipmessage := Vhltprvinsured.Policies(i).Vipmessage;

                --Yakinlik
                Presp.Resultinfo.Resultreturning.Insured_Resp.Relationship := Vhltprvinsured.Policies(i).Relationship;

                --UrunBilgileri/TssBilgisi -- eelcik -- 20150310 -- FOR TSS
                Presp.Resultinfo.Resultreturning.Insured_Resp.Productinfo.Iscomplementary := Vhltprvinsured.Policies(i).Iscomplementary;

                Presp.Resultinfo.Resultreturning.Insured_Resp.Productinfo.Insuredadditionalinfo := Customer.Hltprv_Insuredadditional_Tbl();
                Presp.Resultinfo.Resultreturning.Insured_Resp.Productinfo.Insuredadditionalinfo.Extend;
                Vlast := Presp.Resultinfo.Resultreturning.Insured_Resp.Productinfo.Insuredadditionalinfo.Last;
                Presp.Resultinfo.Resultreturning.Insured_Resp.Productinfo.Insuredadditionalinfo(Vlast) := Customer.Hltprv_Insuredadditional_Typ();

                Presp.Resultinfo.Resultreturning.Insured_Resp.Productinfo.Insuredadditionalinfo(Vlast).Infotype := 'GRUP_ADI';
                Presp.Resultinfo.Resultreturning.Insured_Resp.Productinfo.Insuredadditionalinfo(Vlast).Infoceode := Vhltprvinsured.Policies(i).Productname;

                --GRUP SA�LIK
                IF Vhltprvinsured.Policies(i).Productid = 64
                THEN
                    Presp.Resultinfo.Resultreturning.Insured_Resp.Productinfo.Insuredadditionalinfo.Extend;
                    Vlast := Presp.Resultinfo.Resultreturning.Insured_Resp.Productinfo.Insuredadditionalinfo.Last;
                    Presp.Resultinfo.Resultreturning.Insured_Resp.Productinfo.Insuredadditionalinfo(Vlast) := Customer.Hltprv_Insuredadditional_Typ();

                    Presp.Resultinfo.Resultreturning.Insured_Resp.Productinfo.Insuredadditionalinfo(Vlast).Infotype := 'ALT_GRUP_ADI';
                    Presp.Resultinfo.Resultreturning.Insured_Resp.Productinfo.Insuredadditionalinfo(Vlast).Infoceode := Vhltprvinsured.Policies(i).Phname;
                END IF;
            END IF;

            -- eelcik -- 20150310 -- FOR TSS
            IF Vhltprvinsured.Policies(i).Iscomplementary = 1
            THEN
                Presp.Resultinfo.Resultreturning.Insured_Resp.Productinfo.Iscomplementary := Vhltprvinsured.Policies(i).Iscomplementary;
            END IF;
        END LOOP;
    END;
  FUNCTION Calcsgkamount(Pclaimid IN NUMBER,
                                                 Psfno    IN NUMBER) RETURN NUMBER IS
        Vsgkamount NUMBER;
    BEGIN
        SELECT Nvl(Sgk_Total, 0) * ALZ_HLTPRV_UTILS.Findswfcurrency(Swift_Code) Sgk_Tutar
            INTO Vsgkamount
            FROM Koc_Clm_Hlth_Detail
         WHERE Claim_Id = Pclaimid
             AND Sf_No = Psfno
             AND Add_Order_No = 1;

        RETURN Nvl(Vsgkamount, 0);
    END;

  PROCEDURE Fillprovisionsgk(Psgkamount IN NUMBER,
                                                         Presp      IN OUT Customer.Hltprv_Provision_Resp_Typ) IS
    BEGIN
        IF Presp.Resultinfo IS NULL
        THEN
            Presp.Resultinfo := CUSTOMER.Hltprv_Result_Typ();
        END IF;

        IF Presp.Resultinfo.Resultreturning IS NULL
        THEN
            Presp.Resultinfo.Resultreturning := CUSTOMER.Hltprv_Resultreturning_Typ();
        END IF;

        Presp.Resultinfo.Resultreturning.Amountsgk := CUSTOMER.Hltprv_Sgkinfo_Typ();

        IF Psgkamount > 0
        THEN
            Presp.Resultinfo.Resultreturning.Amountsgk.Sgkusedstatus := 1;
            Presp.Resultinfo.Resultreturning.Amountsgk.Amountsgk     := Psgkamount;
        ELSE
            Presp.Resultinfo.Resultreturning.Amountsgk.Sgkusedstatus := 0;
            Presp.Resultinfo.Resultreturning.Amountsgk.Amountsgk     := 0;
        END IF;
    END;
      FUNCTION Ishosptpreapprove(Pclaimid IN Koc_Clm_Hlth_Detail.Claim_Id%TYPE,
                                                         Psfno    IN Koc_Clm_Hlth_Detail.Sf_No%TYPE) RETURN NUMBER IS
        CURSOR Crlocation(Cpclaimid IN NUMBER,
                                            Cpsfno    IN NUMBER) IS
            SELECT Web_Location_Code Locationcode
                FROM Koc_Clm_Hlth_Detail
             WHERE Claim_Id = Cpclaimid
                 AND Sf_No = Cpsfno;

        Vcntproc       NUMBER;
        Vcntmed        NUMBER;
        Vcntitem       NUMBER;
        Vcntpreapprove NUMBER;
        Vlocation      Koc_Clm_Hlth_Detail.Web_Location_Code%TYPE;
        --
    BEGIN
        OPEN Crlocation(Pclaimid, Psfno);

        FETCH Crlocation
            INTO Vlocation;

        CLOSE Crlocation;

        IF Vlocation <> 920
        THEN
            RETURN 0;
        END IF;

        --�n onayda provizyon ekibi taraf�ndan dosya onaylan�rken
        --tutar i�ermeyen baz� i�lemler ekleniyor
        SELECT COUNT(1)
            INTO Vcntproc
            FROM Koc_Clm_Hlth_Proc_Detail
         WHERE Claim_Id = Pclaimid
             AND Sf_No = Psfno
             AND Nvl(Inst_Indemnity_Amount, 0) > 0;

        SELECT COUNT(1)
            INTO Vcntmed
            FROM Koc_Clm_Medicine_Indem_Det
         WHERE Claim_Id = Pclaimid
             AND Sf_No = Psfno;

        SELECT COUNT(1)
            INTO Vcntitem
            FROM Koc_Clm_Hlth_Item_Detail
         WHERE Claim_Id = Pclaimid
             AND Sf_No = Psfno;

        SELECT COUNT(1)
            INTO Vcntpreapprove
            FROM Koc_Clm_Hlth_Preapprove_Detail
         WHERE Claim_Id = Pclaimid
             AND Sf_No = Psfno;

        IF Vcntpreapprove > 0 AND
             Vcntproc = 0 AND
             Vcntmed = 0 AND
             Vcntitem = 0 AND
             Vlocation = 920
        THEN
            RETURN 1;
        END IF;

        RETURN 0;
    END;
      FUNCTION Findrejectexplanation(Pmaincode    IN Koc_Cc_Hlth_Out_Pr_Types.Main_Code%TYPE,
                                                                 Pitemcode    IN Koc_Cc_Hlth_Out_Pr_Types.Item_Code%TYPE,
                                                                 Psubitemcode IN Koc_Cc_Hlth_Out_Pr_Types.Sub_Item_Code%TYPE,
                                                                 Preasgrpcode IN Koc_Cc_Hlth_Out_Gr_Let.Out_Reas_Group_Code%TYPE,
                                                                 Pgroupcode   IN Koc_Cc_Hlth_Out_Gr_Let.Group_Code%TYPE,
                                                                 Pdate        IN DATE) RETURN VARCHAR2 IS
        CURSOR Crsexpgroup(Pcdate IN DATE) IS
            SELECT c.Long_Name Expl
                FROM Koc_Cc_Hlth_Out_Pr_Types t,
                         Koc_Cc_Hlth_Out_Gr_Let   l,
                         Cur_Translations         c
             WHERE t.Main_Code = Pmaincode
                 AND t.Item_Code = Pitemcode
                 AND t.Sub_Item_Code = Psubitemcode
                 AND t.Letter_Type = l.Letter_Type
                 AND l.Out_Reas_Group_Code = Preasgrpcode
                 AND t.Desc_Int_Id = c.Desc_Int_Id
                 AND c.Sula_Ora_Nls_Code = Userenv('LANG')
                 AND t.Validity_Start_Date <= Pcdate
                 AND (t.Validity_End_Date >= Pcdate OR t.Validity_End_Date IS NULL)
                 AND (Pgroupcode IS NULL OR (l.Group_Code = Pgroupcode AND Pgroupcode IS NOT NULL));

        CURSOR Crsexpl(Pcdate IN DATE) IS
            SELECT c.Long_Name Expl
                FROM Koc_Cc_Hlth_Out_Pr_Types t,
                         Koc_Cc_Hlth_Out_Gr_Let   l,
                         Cur_Translations         c
             WHERE t.Main_Code = Pmaincode
                 AND t.Item_Code = Pitemcode
                 AND t.Sub_Item_Code = Psubitemcode
                 AND t.Letter_Type = l.Letter_Type
                 AND l.Out_Reas_Group_Code = Preasgrpcode
                 AND t.Desc_Int_Id = c.Desc_Int_Id
                 AND c.Sula_Ora_Nls_Code = Userenv('LANG')
                 AND t.Validity_Start_Date <= Pcdate
                 AND (t.Validity_End_Date >= Pcdate OR t.Validity_End_Date IS NULL);

        Vrejectexpl Cur_Translations.Long_Name%TYPE;
    BEGIN
        OPEN Crsexpgroup(Trunc(Pdate));

        FETCH Crsexpgroup
            INTO Vrejectexpl;

        IF Crsexpgroup%NOTFOUND
        THEN
            OPEN Crsexpl(Trunc(Pdate));

            FETCH Crsexpl
                INTO Vrejectexpl;

            CLOSE Crsexpl;
        END IF;

        CLOSE Crsexpgroup;

        RETURN Vrejectexpl;
    END;

  PROCEDURE Fillprovisionpreapprove(Pclaimid IN Koc_Clm_Hlth_Detail.Claim_Id%TYPE,
                                                                        Psfno    IN Koc_Clm_Hlth_Detail.Sf_No%TYPE,
                                                                        Presp    IN OUT Customer.Hltprv_Provision_Resp_Typ) IS
        CURSOR Crpreapprove(Cpclaimid IN Koc_Clm_Hlth_Detail.Claim_Id%TYPE,
                                                Cpsfno    IN Koc_Clm_Hlth_Detail.Sf_No%TYPE) IS
            SELECT P1.Cover_Type,
                         P1.Request_Amount,
                         P1.Sgk_Amount,
                         P1.Process_Date,
                         P1.Process_Time,
                         P1.Order_No,
                         P1.Explanation,
                         P1.Doctor_Code,
                         P1.Doctor_Type,
                         P2.Status_Code,
                         P2.Provision_Date,
                         P2.Hospitalize_Appr_Form_Expl_1,
                         P2.Hospitalize_Appr_Form_Expl_2,
                         P2.Group_Code,
                         P2.Request_System
                FROM Koc_Clm_Hlth_Preapprove_Detail P1,
                         Koc_Clm_Hlth_Detail            P2
             WHERE P1.Claim_Id = Cpclaimid
                 AND P1.Sf_No = Cpsfno
                 AND P1.Add_Order_No = 1
                 AND P1.Claim_Id = P2.Claim_Id
                 AND P1.Sf_No = P2.Sf_No
                 AND P1.Add_Order_No = P2.Add_Order_No;

       /* CURSOR Crdoctor(Cpdoctorcode Hst_Cc_Web_Inst_Doctor.Doctor_Code%TYPE) IS
              SELECT Doctor_Name,
                     Doctor_Surname,
                     Specialty_Subject,
                     Title,
                     Doctor_Identity_No,
                     Doctor_Staff,
                     Doctor_Certificate_Number
                FROM Hst_Cc_Web_Inst_Doctor
             WHERE Doctor_Code = Cpdoctorcode
                 AND Specialty_Subject IS NOT NULL;*/ -- mustafaku 04.01.2015 doktor bran� kodu olmayan kay�tlar gelmesin.

        --�ncelikle medikal network onayl� kay�t bak�lacak, cursor a��ld���nda loop d�nm�� gerek yok.
        --kodda fazla de�i�iklik olmamas� i�in CURSOR ROWNUM<2 yap�ld�.
        CURSOR Crdoctor(Cpdoctorcode Hst_Cc_Web_Inst_Doctor.Doctor_Code%TYPE) IS
        SELECT *
          FROM (SELECT Doctor_Name,
                       Doctor_Surname,
                       Specialty_Subject,
                       Title,
                       Doctor_Identity_No,
                       Doctor_Staff,
                       Doctor_Certificate_Number
                  FROM (SELECT 1 Table_Order,
                               Doctor_Name,
                               Doctor_Surname,
                               Specialty_Subject,
                               Title,
                               Doctor_Identity_No,
                               Doctor_Staff,
                               Doctor_Certificate_Number
                          FROM Koc_Cc_Web_Inst_Doctor
                         WHERE Doctor_Code =  Cpdoctorcode
                        UNION
                        SELECT 2 Table_Order,
                               Doctor_Name,
                               Doctor_Surname,
                               Specialty_Subject,
                               Title,
                               Doctor_Identity_No,
                               Doctor_Staff,
                               Doctor_Certificate_Number
                          FROM Hst_Cc_Web_Inst_Doctor
                         WHERE Doctor_Code =  Cpdoctorcode
                        )
                 ORDER BY Table_Order)
         WHERE Rownum < 2;

        CURSOR Crrejects(Cpclaimid IN NUMBER,
                                         Cpsfno    IN NUMBER) IS
            SELECT DISTINCT Main_Code,
                                            Item_Code,
                                            Sub_Item_Code
                FROM Koc_Clm_Hlth_Reject_Loss
             WHERE Claim_Id = Cpclaimid
                 AND Sf_No = Cpsfno
                 AND Add_Order_No = 1
                 AND Cover_Code <> '0'
                 AND Nvl(Process_Code_Main, 0) = 0
                 AND Nvl(Barcode, 0) = 0
                 AND Nvl(Ubb_Code, '0') = '0'
            UNION
            SELECT DISTINCT Main_Code,
                                            Item_Code,
                                            Sub_Item_Code
                FROM Koc_Clm_Hlth_Reject_Loss
             WHERE Claim_Id = Cpclaimid
                 AND Sf_No = Cpsfno
                 AND Add_Order_No = 1
                 AND Location_Code = 0
                 AND Cover_Code = '0'
                 AND Nvl(Process_Code_Main, 0) = 0
                 AND Nvl(Barcode, 0) = 0
                 AND Nvl(Ubb_Code, '0') = '0';

        Vrejexpl VARCHAR2(1000);
        Vcount   NUMBER;
        Vlast    NUMBER;
    BEGIN
        FOR Rec IN Crpreapprove(Pclaimid, Psfno)
        LOOP
            /*HizmetBilgileri*/
            IF Presp.Resultinfo IS NULL
            THEN
                Presp.Resultinfo := CUSTOMER.Hltprv_Result_Typ();
            END IF;

            IF Presp.Resultinfo.Resultreturning IS NULL
            THEN
                Presp.Resultinfo.Resultreturning := CUSTOMER.Hltprv_Resultreturning_Typ();
            END IF;

            IF Presp.Resultinfo.Resultreturning.Serviceinfosreturning IS NULL
            THEN
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning := CUSTOMER.Hltprv_Serviceinfreturning_Tbl();
            END IF;

            Presp.Resultinfo.Resultreturning.Serviceinfosreturning.Extend;
            Vlast := Presp.Resultinfo.Resultreturning.Serviceinfosreturning.Last;
            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast) := CUSTOMER.Hltprv_Serviceinfreturning_Typ();

            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation := CUSTOMER.Hltprv_Serviceinfos_Typ();
            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Lumpsumprcss := CUSTOMER.Hltprv_Lumpsumprcss_Typ();
            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Lumpsumprcss.Insuredcovertype := Rec.Cover_Type;
            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Lumpsumprcss.Amountrequest := Rec.Request_Amount;
            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Lumpsumprcss.Amountsgk := Rec.Sgk_Amount;
            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Lumpsumprcss.Orderno := Rec.Order_No;

            IF Rec.Process_Date IS NOT NULL
            THEN
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Lumpsumprcss.Processdatetime := CUSTOMER.Hltprv_Processdatetime_Typ();
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Lumpsumprcss.Processdatetime.Processdate := Trunc(Rec.Process_Date);
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Lumpsumprcss.Processdatetime.Processtime := Rec.Process_Time;
            END IF;

            IF Rec.Doctor_Code IS NOT NULL
            THEN
                FOR Recdoctor IN Crdoctor(Rec.Doctor_Code)
                LOOP
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Lumpsumprcss.Dr := CUSTOMER.Hltprv_Dr_Typ();
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Lumpsumprcss.Dr.Namesurname := Recdoctor.Doctor_Name || ' ' ||
                                                                                                                                                                                                                                                    Recdoctor.Doctor_Surname;

                    IF Recdoctor.Title = 'Prof.'
                    THEN
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Lumpsumprcss.Dr.Title := 'PROF';
                    ELSIF Recdoctor.Title = 'Do�.'
                    THEN
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Lumpsumprcss.Dr.Title := 'DOC';
                    ELSIF Recdoctor.Title IN ('Yard. Do�', 'Yard. Do�.')
                    THEN
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Lumpsumprcss.Dr.Title := 'YRD_DOC';
                    ELSIF Recdoctor.Title = 'Uzman'
                    THEN
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Lumpsumprcss.Dr.Title := 'UZM';
                    ELSIF Recdoctor.Title = 'Pratisyen'
                    THEN
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Lumpsumprcss.Dr.Title := 'PRTS';
                    ELSE
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Lumpsumprcss.Dr.Title := NULL;
                    END IF;

                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Lumpsumprcss.Dr.Branch := Convertbranchcode2(Rec.Request_System,
                                                                                                                                                                                                                                                                                Rec.Provision_Date,
                                                                                                                                                                                                                                                                                Recdoctor.Specialty_Subject);
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Lumpsumprcss.Dr.Staffstatus := Recdoctor.Doctor_Staff;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Lumpsumprcss.Dr.Identityno := Recdoctor.Doctor_Identity_No;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Lumpsumprcss.Dr.Diplomaregistrationno := Recdoctor.Doctor_Certificate_Number;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Lumpsumprcss.Dr.Drtype := Rec.Doctor_Type;
                END LOOP;
            END IF;

            IF Rec.Explanation IS NOT NULL
            THEN
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Lumpsumprcss.Explanation := CUSTOMER.Hltprv_Note_Typ();
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Lumpsumprcss.Explanation.Text := Rec.Explanation;
            END IF;

            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult := CUSTOMER.Hltprv_Decisionresult_Typ();
            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Decisiontypecode := Convertprovisionstatuscode(Pclaimid, Psfno, 1,
                                                                                                                                                                                                                                                                    Rec.Status_Code);

            --
            IF Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Decisiontypecode IN ('ONAY', 'KISMI_ONAY')
            THEN
                IF Rec.Hospitalize_Appr_Form_Expl_1 IS NOT NULL OR
                     Rec.Hospitalize_Appr_Form_Expl_2 IS NOT NULL
                THEN
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation := Customer.Hltprv_Note_Tbl();

                    --
                    IF Rec.Hospitalize_Appr_Form_Expl_1 IS NOT NULL
                    THEN
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation.Extend;
                        Vcount := Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation.Last;

                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation(Vcount) := Customer.Hltprv_Note_Typ();
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation(Vcount).Text := Rec.Hospitalize_Appr_Form_Expl_1;
                    END IF;

                    --
                    IF Rec.Hospitalize_Appr_Form_Expl_2 IS NOT NULL
                    THEN
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation.Extend;
                        Vcount := Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation.Last;

                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation(Vcount) := Customer.Hltprv_Note_Typ();
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation(Vcount).Text := Rec.Hospitalize_Appr_Form_Expl_2;
                    END IF;
                END IF;
            END IF;

            IF Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Decisiontypecode = 'RED'
            THEN
                FOR r IN Crrejects(Pclaimid, Psfno)
                LOOP
                    Vrejexpl := Findrejectexplanation(r.Main_Code, r.Item_Code, r.Sub_Item_Code, '5', Rec.Group_Code, Rec.Provision_Date);

                    --
                    IF Vrejexpl IS NOT NULL
                    THEN
                        --
                        IF Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation IS NULL
                        THEN
                            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation := Customer.Hltprv_Note_Tbl();
                        END IF;

                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation.Extend;
                        Vcount := Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation.Last;

                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation(Vcount) := Customer.Hltprv_Note_Typ();
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation(Vcount).Text := Vrejexpl;
                    END IF;
                END LOOP;
            END IF;
        END LOOP;
    END;
      FUNCTION Convertstatuscode(Pstatuscode IN VARCHAR2,
                                                         Prejectamt  IN NUMBER) RETURN VARCHAR2 IS
        Vstatus VARCHAR2(20);
    BEGIN
        IF Nvl(Pstatuscode, 'PP') = 'P'
        THEN
            Vstatus := 'ONAY';

            IF Nvl(Prejectamt, 0) > 0
            THEN
                Vstatus := 'KISMI_ONAY';
            END IF;
        ELSIF Nvl(Pstatuscode, 'PP') IN ('PR', 'R')
        THEN
            Vstatus := 'RED';
        ELSIF Nvl(Pstatuscode, 'PP') IN ('C')
        THEN
            Vstatus := 'IPTAL_EDILDI';
        ELSIF Nvl(Pstatuscode, 'PP') IN ('PP', 'CP')
        THEN
            Vstatus := 'ISLENIYOR';
        ELSIF Nvl(Pstatuscode, 'PP') IN ('I', 'MI', 'TI', 'TMI')
        THEN
            Vstatus := 'ARASTIRMA';
        END IF;

        RETURN Vstatus;
    END;

  PROCEDURE Fillprovisionservices(Pclaimid  IN Koc_Clm_Hlth_Detail.Claim_Id%TYPE,
                                                                    Psfno     IN Koc_Clm_Hlth_Detail.Sf_No%TYPE,
                                                                    Presp     IN OUT Customer.Hltprv_Provision_Resp_Typ,
                                                                    Pprovdist IN OUT Customer.Hltprv_Prov_Dist_Claim_Typ) IS
        CURSOR Crprocess(Cpclaimid IN Koc_Clm_Hlth_Detail.Claim_Id%TYPE,
                                         Cpsfno    IN Koc_Clm_Hlth_Detail.Sf_No%TYPE) IS
            SELECT P1.Process_Code_Main,
                         P1.Process_Code_Sub1,
                         P1.Process_Code_Sub2,
                         P1.Indemnity_Amount,
                         P1.Inst_Indemnity_Amount,
                         P1.Process_Count,
                         P1.Status_Code,
                         P1.Explanation,
                         P1.Entrance_Date,
                         P1.Drg_Code,
                         P1.Doctor_Code,
                         P1.Doctor_Status,
                         P1.Sgk_Amount,
                         P1.Order_No,
                         P1.Vat_Rate,
                         P1.Right_Left,
                         P1.Proc_Type,
                         P1.Physiotherapy_Session,
                         P1.Diagnosis_Id,
                         P1.Surgery_Id,
                         P2.Provision_Date,
                         P2.Group_Code,
                         P2.Status_Code               Claim_Status,
                         P1.Group_No,
                         P1.Seq_No,
                         P1.Req_Process_Name,
                         P1.Req_Process_Code,
                         P1.Req_Process_List_Type,
                         P1.Related_Process,
                         P1.Related_Process_List_Type,
                         P3.Cover_Code,
                         P3.Add_Order_No,
                         P3.Location_Code,
                         P3.Swift_Code,
                         P3.Provision_Total,
                         P3.Request_Amount,
                         P3.Refusal_Amount,
                         P3.Exemption_Amount,
                         P3.Exemption_Rate,
                         P3.Sgk_Amount                Cover_Sgk_Amount,
                         P3.Add_Proc_Amount,
                         P2.Request_System
                FROM Koc_Clm_Hlth_Proc_Detail P1,
                         Koc_Clm_Hlth_Detail      P2,
                         Koc_Clm_Hlth_Provisions  P3
             WHERE P1.Claim_Id = Cpclaimid
                 AND P1.Sf_No = Cpsfno
                 AND P1.Add_Order_No = 1
                 AND P1.Claim_Id = P2.Claim_Id
                 AND P1.Sf_No = P2.Sf_No
                 AND P1.Add_Order_No = P2.Add_Order_No
                 AND P3.Claim_Id = P1.Claim_Id
                 AND P3.Sf_No = P1.Sf_No
                 AND P3.Add_Order_No = P1.Add_Order_No
                 AND P3.Location_Code = P1.Location_Code
                 AND P3.Cover_Code = P1.Cover_Code;

        CURSOR Crdoctor(Cpdoctorcode Hst_Cc_Web_Inst_Doctor.Doctor_Code%TYPE) IS
           WITH Doktor_Sb AS
            (SELECT Table_Order,
                    Doctor_Name,
                    Doctor_Surname,
                    Specialty_Subject,
                    Title,
                    Doctor_Identity_No,
                    Doctor_Staff,
                    Doctor_Certificate_Number,
                    Validity_End_Date,
                    Rank() Over(PARTITION BY Doctor_Identity_No ORDER BY Table_Order ASC, Validity_End_Date DESC NULLS FIRST) AS Rnk
               FROM (SELECT 1 Table_Order,
                            Doctor_Name,
                            Doctor_Surname,
                            Specialty_Subject,
                            Title,
                            Doctor_Identity_No,
                            Doctor_Staff,
                            Doctor_Certificate_Number,
                            a.Validity_End_Date
                       FROM Koc_Cc_Web_Inst_Doctor a
                      WHERE Doctor_Code = Cpdoctorcode
                     UNION
                     SELECT 2 Table_Order,
                            Doctor_Name,
                         Doctor_Surname,
                         Specialty_Subject,
                         Title,
                         Doctor_Identity_No,
                         Doctor_Staff,
                            Doctor_Certificate_Number,
                            a.Validity_End_Date
                       FROM Hst_Cc_Web_Inst_Doctor a
                      WHERE Doctor_Code = Cpdoctorcode))
               SELECT * FROM Doktor_Sb WHERE Rnk = 1;

        CURSOR Crsurgery(Cpsurgeryid IN Koc_Clm_Hlth_Surgery_Detail.Surgery_Id%TYPE) IS
            SELECT Cut_No,
                         Recurrence,
                         Is_Revision,
                         Right_Left,
                         Process_Score,
                         Is_Laparoscopic_Surgery,
                         Is_Robotic_Surgery,
                         Package_Type,
                         Surgery_Package_No
                FROM Koc_Clm_Hlth_Surgery_Detail
             WHERE Surgery_Id = Cpsurgeryid;

        CURSOR Crdiagnose(Cpdiagnoseid IN Koc_Clm_Hlth_Diagnosis.Diagnosis_Id%TYPE) IS
            SELECT Diagnosis_Code,
                         Diagnosis_Desc,
                         Diagnosis_Type
                FROM Koc_Clm_Hlth_Diagnosis
             WHERE Diagnosis_Id = Cpdiagnoseid;

        --��lem teminat� ve i�lem redleri
        CURSOR Crrejects(Cpclaimid IN NUMBER,
                                         Cpsfno    IN NUMBER,
                                         Cploccode IN NUMBER,
                                         Cpmain    IN NUMBER,
                                         Cpsub1    IN NUMBER,
                                         Cpsub2    IN NUMBER,
                                         Cpseqno   IN NUMBER) IS
            SELECT DISTINCT Main_Code,
                                            Item_Code,
                                            Sub_Item_Code
                FROM Koc_Clm_Hlth_Reject_Loss
             WHERE Claim_Id = Cpclaimid
                 AND Sf_No = Cpsfno
                 AND Add_Order_No = 1
                 AND Process_Code_Main = Cpmain
                 AND Process_Code_Sub1 = Cpsub1
                 AND Process_Code_Sub2 = Cpsub2
                 AND Seq_No = Cpseqno;

        CURSOR Crrejects2(Cpclaimid IN NUMBER,
                                            Cpsfno    IN NUMBER) IS
            SELECT DISTINCT Main_Code,
                                            Item_Code,
                                            Sub_Item_Code
                FROM Koc_Clm_Hlth_Reject_Loss
             WHERE Claim_Id = Cpclaimid
                 AND Sf_No = Cpsfno
                 AND Add_Order_No = 1
                 AND Location_Code = 0
                 AND Cover_Code = '0'
                 AND Nvl(Process_Code_Main, 0) = 0
                 AND Nvl(Process_Code_Sub1, 0) = 0
                 AND Nvl(Process_Code_Sub2, 0) = 0
                 AND Nvl(Barcode, 0) = 0
                 AND Nvl(Ubb_Code, '0') = '0';

        Vrejexpl VARCHAR2(1000);
        v_Ind    NUMBER;
        Vlast    NUMBER;
        --vlast2      number;
        Vcount         NUMBER;
        Vbaseswiftcode VARCHAR2(4) := Base_Swift_Code;
    BEGIN
        FOR Rec IN Crprocess(Pclaimid, Psfno)
        LOOP
            /*HizmetBilgileri*/
            IF Presp.Resultinfo IS NULL
            THEN
                Presp.Resultinfo := CUSTOMER.Hltprv_Result_Typ();
            END IF;

            IF Presp.Resultinfo.Resultreturning IS NULL
            THEN
                Presp.Resultinfo.Resultreturning := CUSTOMER.Hltprv_Resultreturning_Typ();
            END IF;

            IF Presp.Resultinfo.Resultreturning.Serviceinfosreturning IS NULL
            THEN
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning := CUSTOMER.Hltprv_Serviceinfreturning_Tbl();
            END IF;

            Presp.Resultinfo.Resultreturning.Serviceinfosreturning.Extend;
            Vlast := Presp.Resultinfo.Resultreturning.Serviceinfosreturning.Last;
            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast) := CUSTOMER.Hltprv_Serviceinfreturning_Typ();

            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation := CUSTOMER.Hltprv_Serviceinfos_Typ();
            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess := CUSTOMER.Hltprv_Srvcbsdprcss_Typ();

            IF Rec.Req_Process_Name IS NOT NULL
            THEN
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Name := Rec.Req_Process_Name;
            ELSE
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Name := Koc_Clm_Hlth_Utils.Getprocessdesc(Rec.Process_Code_Main,
                                                                                                                                                                                                                                                                                                             Rec.Process_Code_Sub1,
                                                                                                                                                                                                                                                                                                             Rec.Process_Code_Sub2,
                                                                                                                                                                                                                                                                                                             Rec.Provision_Date);
            END IF;

            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Processcode := CUSTOMER.Hltprv_Processcode_Typ();
            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Processcode.Processcodelist := Rec.Req_Process_List_Type;
            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Processcode.Processcodevalue := Rec.Req_Process_Code;

            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Drgcode := Rec.Drg_Code;

            IF Rec.Related_Process IS NOT NULL
            THEN
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Relatedprocesscode := CUSTOMER.Hltprv_Processcode_Typ();
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Relatedprocesscode.Processcodelist := Rec.Related_Process_List_Type;
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Relatedprocesscode.Processcodevalue := Rec.Related_Process;
            END IF;

            IF Rec.Doctor_Code IS NOT NULL
            THEN
                FOR Recdoctor IN Crdoctor(Rec.Doctor_Code)
                LOOP
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr := CUSTOMER.Hltprv_Dr_Typ();
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Namesurname := Recdoctor.Doctor_Name || ' ' ||
                                                                                                                                                                                                                                                                 Recdoctor.Doctor_Surname;

                    IF Recdoctor.Title = 'Prof.'
                    THEN
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Title := 'PROF';
                    ELSIF Recdoctor.Title = 'Do�.'
                    THEN
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Title := 'DOC';
                    ELSIF Recdoctor.Title IN ('Yard. Do�', 'Yard. Do�.')
                    THEN
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Title := 'YRD_DOC';
                    ELSIF Recdoctor.Title = 'Uzman'
                    THEN
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Title := 'UZM';
                    ELSIF Recdoctor.Title = 'Pratisyen'
                    THEN
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Title := 'PRTS';
                    ELSE
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Title := NULL;
                    END IF;

                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Branch := Convertbranchcode2(Rec.Request_System,
                                                                                                                                                                                                                                                                                             Rec.Provision_Date,
                                                                                                                                                                                                                                                                                             Recdoctor.Specialty_Subject);
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Staffstatus := Recdoctor.Doctor_Staff;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Identityno := Recdoctor.Doctor_Identity_No;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Diplomaregistrationno := Recdoctor.Doctor_Certificate_Number;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Drtype := Rec.Doctor_Status;
                END LOOP;
            END IF;

            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Amountrequest := Rec.Inst_Indemnity_Amount;
            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Amountsgk := Rec.Sgk_Amount;

            IF Rec.Entrance_Date IS NOT NULL
            THEN
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Processdatetime := CUSTOMER.Hltprv_Processdatetime_Typ();
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Processdatetime.Processdate := Trunc(Rec.Entrance_Date);
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Processdatetime.Processtime := To_Char(Rec.Entrance_Date,
                                                                                                                                                                                                                                                                                                        'hh24:mi:ss');
            END IF;

            IF Rec.Proc_Type = 'AMELIYAT' AND
                 Rec.Surgery_Id IS NOT NULL
            THEN
                FOR Recsurgery IN Crsurgery(Rec.Surgery_Id)
                LOOP
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail := CUSTOMER.Hltprv_Detail_Typ();
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Surgery := CUSTOMER.Hltprv_Surgery_Typ();

                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Surgery.Incisionno := Recsurgery.Cut_No;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Surgery.Relapse := Recsurgery.Recurrence;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Surgery.Revision := Recsurgery.Is_Revision;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Surgery.Rightleft := Recsurgery.Right_Left;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Surgery.Processpoints := Recsurgery.Process_Score;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Surgery.Laparoscopicsurgery := Recsurgery.Is_Laparoscopic_Surgery;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Surgery.Roboticssurgery := Recsurgery.Is_Robotic_Surgery;

                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Surgery.Surgerypackage := CUSTOMER.Hltprv_Surgerypackage_Typ();
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Surgery.Surgerypackage.Packagetype := Recsurgery.Package_Type;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Surgery.Surgerypackage.Packageno := Recsurgery.Surgery_Package_No;
                    --surgerypackage.consumables  ???? kullan�lm�yor
                --presp.resultinfo.resultreturning.serviceinfosreturning(vLast).serviceinformation.servicebasedprocess.detail.surgery.surgerypackage.consumables
                END LOOP;
            ELSIF Rec.Proc_Type = 'FIZIK_TEDAVI' AND
                        Rec.Physiotherapy_Session IS NOT NULL
            THEN
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail := CUSTOMER.Hltprv_Detail_Typ();
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Physiotherapy := CUSTOMER.Hltprv_Physiotherapy_Typ();
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Physiotherapy.Seance := Rec.Physiotherapy_Session;
            ELSIF Rec.Proc_Type = 'MUAYENE' AND
                        Rec.Diagnosis_Id IS NOT NULL
            THEN
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail := CUSTOMER.Hltprv_Detail_Typ();
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Examination := CUSTOMER.Hltprv_Examination_Typ();
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Examination.Disease := CUSTOMER.Hltprv_Disease_Typ();

                FOR Recdiagnose IN Crdiagnose(Rec.Diagnosis_Id)
                LOOP
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Examination.Disease.Name := Recdiagnose.Diagnosis_Desc;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Examination.Disease.Code := Recdiagnose.Diagnosis_Code;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Examination.Disease.Type := Recdiagnose.Diagnosis_Type;
                END LOOP;
            ELSIF Rec.Proc_Type = 'KONSULTASYON' AND
                        Rec.Diagnosis_Id IS NOT NULL
            THEN
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail := CUSTOMER.Hltprv_Detail_Typ();
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Consultation := CUSTOMER.Hltprv_Consultation_Typ();
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Consultation.Disease := CUSTOMER.Hltprv_Disease_Typ();

                FOR Recdiagnose IN Crdiagnose(Rec.Diagnosis_Id)
                LOOP
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Consultation.Disease.Name := Recdiagnose.Diagnosis_Desc;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Consultation.Disease.Code := Recdiagnose.Diagnosis_Code;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Consultation.Disease.Type := Recdiagnose.Diagnosis_Type;
                END LOOP;
            END IF;

            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Orderno := Rec.Order_No;
            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Ratevat := Rec.Vat_Rate;
            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Rightleft := Rec.Right_Left;

            IF Rec.Explanation IS NOT NULL
            THEN
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Explanation := CUSTOMER.Hltprv_Note_Typ();
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Explanation.Text := Rec.Explanation;
            END IF;

            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult := CUSTOMER.Hltprv_Decisionresult_Typ();
            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Decisiontypecode := Convertstatuscode(Rec.Status_Code, 0
                                                                                                                                                                                                                                                    --rec.refusal_amount
                                                                                                                                                                                                                                                 );

            IF Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Decisiontypecode = 'RED'
            THEN
                FOR r IN Crrejects(Pclaimid, Psfno, Rec.Location_Code, Rec.Process_Code_Main, Rec.Process_Code_Sub1, Rec.Process_Code_Sub2, Rec.Seq_No)
                LOOP
                    Vrejexpl := Findrejectexplanation(r.Main_Code, r.Item_Code, r.Sub_Item_Code, '5', Rec.Group_Code, Rec.Provision_Date);

                    IF Vrejexpl IS NOT NULL
                    THEN
                        --
                        IF Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation IS NULL
                        THEN
                            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation := Customer.Hltprv_Note_Tbl();
                        END IF;

                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation.Extend;
                        Vcount := Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation.Last;

                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation(Vcount) := Customer.Hltprv_Note_Typ();
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation(Vcount).Text := Vrejexpl;
                    END IF;
                END LOOP;

                IF Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation IS NULL
                THEN
                    FOR r IN Crrejects2(Pclaimid, Psfno)
                    LOOP
                        Vrejexpl := Findrejectexplanation(r.Main_Code, r.Item_Code, r.Sub_Item_Code, '5', Rec.Group_Code, Rec.Provision_Date);

                        IF Vrejexpl IS NOT NULL
                        THEN
                            --
                            IF Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation IS NULL
                            THEN
                                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation := Customer.Hltprv_Note_Tbl();
                            END IF;

                            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation.Extend;
                            Vcount := Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation.Last;

                            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation(Vcount) := Customer.Hltprv_Note_Typ();
                            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation(Vcount).Text := Vrejexpl;
                        END IF;
                    END LOOP;
                END IF;
            END IF;

            --
            -- Teminat tutarlar�n� i�lem/malzeme/ ila� detaylar�na da��tmak i�in ilgili objeye y�kle
            DBMS_OUTPUT.PUT_LINE('Set Cover Details - Consumable:'||Rec.Provision_Total||':'||Rec.Indemnity_Amount||':'||Rec.Inst_Indemnity_Amount||':'||Rec.Request_Amount);
            Pprovdist.Setcoverdetails(Rec.Cover_Code, Rec.Add_Order_No, Rec.Location_Code, Rec.Provision_Total, Rec.Request_Amount, Rec.Refusal_Amount,
                                                                Rec.Exemption_Amount, Rec.Exemption_Rate, Rec.Cover_Sgk_Amount, Rec.Add_Proc_Amount, v_Ind);

            --
            -- Hizmetleri ilgili teminata ekle
            IF v_Ind > 0
            THEN
                Pprovdist.Cover_Details(v_Ind).Setprocessdetail(Rec.Process_Code_Main, Rec.Process_Code_Sub1, Rec.Process_Code_Sub2, Rec.Seq_No, Rec.Group_No,
                                                                                                                Rec.Order_No, Rec.Status_Code, Nvl(Rec.Swift_Code, Vbaseswiftcode), Rec.Indemnity_Amount,
                                                                                                                Rec.Inst_Indemnity_Amount, Rec.Sgk_Amount, Rec.Process_Count, Vlast);
            END IF;
            --

        END LOOP;
    END;
 PROCEDURE Fillprovisionconsumables(Pclaimid  IN Koc_Clm_Hlth_Detail.Claim_Id%TYPE,
                                                                         Psfno     IN Koc_Clm_Hlth_Detail.Sf_No%TYPE,
                                                                         Presp     IN OUT Customer.Hltprv_Provision_Resp_Typ,
                                                                         Pprovdist IN OUT Customer.Hltprv_Prov_Dist_Claim_Typ) IS
        CURSOR Crconsumable(Cpclaimid IN Koc_Clm_Hlth_Detail.Claim_Id%TYPE,
                                                Cpsfno    IN Koc_Clm_Hlth_Detail.Sf_No%TYPE) IS
            SELECT To_Char(P1.Barcode) Barcode,
                         P1.Unit,
                         P1.Price,
                         P1.Item_Type,
                         P1.Drg_Code,
                         P1.Explanation,
                         P1.Status_Code,
                         P1.Dose1,
                         P1.Dose2,
                         P1.Dose_Period,
                         P1.Order_No,
                         P1.Time_Stamp,
                         P1.Vat_Rate,
                         P1.Process_Code,
                         P1.Process_Code_List,
                         P2.Provision_Date,
                         P2.Group_Code,
                         P1.Seq_No,
                         P3.Cover_Code,
                         P3.Add_Order_No,
                         P3.Location_Code,
                         P3.Swift_Code,
                         P3.Provision_Total,
                         P3.Request_Amount,
                         P3.Refusal_Amount,
                         P3.Exemption_Amount,
                         P3.Exemption_Rate,
                         P3.Sgk_Amount,
                         P3.Add_Proc_Amount,
                         P1.Req_Medicine_Name Req_Name,
                         To_Char(P1.Req_Medicine_Barcode) Req_Code
                FROM Koc_Clm_Medicine_Indem_Det P1,
                         Koc_Clm_Hlth_Detail        P2,
                         Koc_Clm_Hlth_Provisions    P3
             WHERE P1.Claim_Id = Cpclaimid
                 AND P1.Sf_No = Cpsfno
                 AND P1.Add_Order_No = 1
                 AND P1.Claim_Id = P2.Claim_Id
                 AND P1.Sf_No = P2.Sf_No
                 AND P1.Add_Order_No = P2.Add_Order_No
                 AND P3.Claim_Id = P1.Claim_Id
                 AND P3.Sf_No = P1.Sf_No
                 AND P3.Add_Order_No = P1.Add_Order_No
                 AND P3.Location_Code = P1.Location_Code
                 AND P3.Cover_Code = P1.Cover_Code
            UNION ALL
            SELECT P1.Ubb_Code          Barcode,
                         P1.Quantity          Unit,
                         P1.Price,
                         P1.Item_Type,
                         P1.Drg_Code,
                         P1.Explanation,
                         P1.Status_Code,
                         NULL                 Dose1,
                         NULL                 Dose2,
                         NULL                 Dose_Period,
                         P1.Order_No,
                         P1.Time_Stamp,
                         P1.Vat_Rate,
                         P1.Process_Code,
                         P1.Process_Code_List,
                         P2.Provision_Date,
                         P2.Group_Code,
                         P1.Seq_No,
                         P3.Cover_Code,
                         P3.Add_Order_No,
                         P3.Location_Code,
                         P3.Swift_Code,
                         P3.Provision_Total,
                         P3.Request_Amount,
                         P3.Refusal_Amount,
                         P3.Exemption_Amount,
                         P3.Exemption_Rate,
                         P3.Sgk_Amount,
                         P3.Add_Proc_Amount,
                         P1.Req_Item_Name     Req_Name,
                         P1.Req_Item_Ubbcode  Req_Code
                FROM Koc_Clm_Hlth_Item_Detail P1,
                         Koc_Clm_Hlth_Detail      P2,
                         Koc_Clm_Hlth_Provisions  P3
             WHERE P1.Claim_Id = Cpclaimid
                 AND P1.Sf_No = Cpsfno
                 AND P1.Add_Order_No = 1
                 AND P1.Claim_Id = P2.Claim_Id
                 AND P1.Sf_No = P2.Sf_No
                 AND P1.Add_Order_No = P2.Add_Order_No
                 AND P3.Claim_Id = P1.Claim_Id
                 AND P3.Sf_No = P1.Sf_No
                 AND P3.Add_Order_No = P1.Add_Order_No
                 AND P3.Location_Code = P1.Location_Code
                 AND P3.Cover_Code = P1.Cover_Code;

        --��lem teminat� ve i�lem redleri
        CURSOR Crrejects(Cpclaimid IN NUMBER,
                                         Cpsfno    IN NUMBER,
                                         Cploccode IN NUMBER,
                                         Cpbarcode IN VARCHAR2,
                                         Cpseqno   IN NUMBER,
                                         Cptype    IN VARCHAR2) IS
            SELECT DISTINCT Main_Code,
                                            Item_Code,
                                            Sub_Item_Code
                FROM Koc_Clm_Hlth_Reject_Loss
             WHERE Claim_Id = Cpclaimid
                 AND Sf_No = Cpsfno
                 AND Add_Order_No = 1
                 AND ((Cptype IN ('ILAC', 'ASI') AND Barcode = To_Number(Cpbarcode)) OR (Cptype NOT IN ('ILAC', 'ASI') AND Ubb_Code = Cpbarcode))
                 AND Seq_No = Cpseqno;

        CURSOR Crrejects2(Cpclaimid IN NUMBER,
                                            Cpsfno    IN NUMBER) IS
            SELECT DISTINCT Main_Code,
                                            Item_Code,
                                            Sub_Item_Code
                FROM Koc_Clm_Hlth_Reject_Loss
             WHERE Claim_Id = Cpclaimid
                 AND Sf_No = Cpsfno
                 AND Add_Order_No = 1
                 AND Location_Code = 0
                 AND Cover_Code = '0'
                 AND Nvl(Process_Code_Main, 0) = 0
                 AND Nvl(Process_Code_Sub1, 0) = 0
                 AND Nvl(Process_Code_Sub2, 0) = 0
                 AND Nvl(Barcode, 0) = 0
                 AND Nvl(Ubb_Code, '0') = '0';

        Vrejexpl       VARCHAR2(1000);
        v_Ind          PLS_INTEGER;
        Vlast          PLS_INTEGER;
        Vcount         NUMBER;
        Vbaseswiftcode VARCHAR2(4) := Base_Swift_Code;
        --
    BEGIN
        FOR Rec IN Crconsumable(Pclaimid, Psfno)
        LOOP
            /*SarfBilgileri*/
            IF Presp.Resultinfo IS NULL
            THEN
                Presp.Resultinfo := CUSTOMER.Hltprv_Result_Typ();
            END IF;

            IF Presp.Resultinfo.Resultreturning IS NULL
            THEN
                Presp.Resultinfo.Resultreturning := CUSTOMER.Hltprv_Resultreturning_Typ();
            END IF;

            IF Presp.Resultinfo.Resultreturning.Consumablesreturning IS NULL
            THEN
                Presp.Resultinfo.Resultreturning.Consumablesreturning := CUSTOMER.Hltprv_Consumablereturning_Tbl();
            END IF;

            Presp.Resultinfo.Resultreturning.Consumablesreturning.Extend;
            Vlast := Presp.Resultinfo.Resultreturning.Consumablesreturning.Last;
            Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast) := CUSTOMER.Hltprv_Consumablereturning_Typ();

            Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Consumable := CUSTOMER.Hltprv_Consumables_Typ();

            --presp.resultinfo.resultreturning.consumablesreturning(vLast).consumable.name        := koc_clm_hlth_pharmacy_utils.getmedicinename (rec.barcode);
            --presp.resultinfo.resultreturning.consumablesreturning(vLast).consumable.name        := getitemname (rec.barcode);
            Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Consumable.Name := Rec.Req_Name;
            Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Consumable.Barcode := Rec.Req_Code;
            Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Consumable.Count := Rec.Unit;
            Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Consumable.Price := Rec.Price;
            Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Consumable.Type := Rec.Item_Type;
            Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Consumable.Drgcode := Rec.Drg_Code;
            Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Consumable.Usagetime := Rec.Dose_Period;
            Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Consumable.Orderno := Rec.Order_No;
            Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Consumable.Ratevat := Rec.Vat_Rate;

            IF Rec.Dose1 IS NOT NULL OR
                 Rec.Dose2 IS NOT NULL
            THEN
                Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Consumable.Dozinfos := CUSTOMER.Hltprv_Dosageinfos_Typ();
                Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Consumable.Dozinfos.Dosage1 := Rec.Dose1;
                Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Consumable.Dozinfos.Dosage2 := Rec.Dose2;
            END IF;

            IF Rec.Process_Code IS NOT NULL
            THEN
                Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Consumable.Processcode := CUSTOMER.Hltprv_Processcode_Typ();
                Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Consumable.Processcode.Processcodelist := Rec.Process_Code_List;
                Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Consumable.Processcode.Processcodevalue := Rec.Process_Code;
            END IF;

            IF Rec.Time_Stamp IS NOT NULL
            THEN
                Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Consumable.Processdatetime := CUSTOMER.Hltprv_Processdatetime_Typ();
                Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Consumable.Processdatetime.Processdate := Trunc(Rec.Time_Stamp);
                Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Consumable.Processdatetime.Processtime := To_Char(Rec.Time_Stamp, 'hh24:mi:ss');
            END IF;

            IF Rec.Explanation IS NOT NULL
            THEN
                Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Consumable.Explanation := CUSTOMER.Hltprv_Note_Typ();
                Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Consumable.Explanation.Text := Rec.Explanation;
            END IF;

            Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Decisionresultconsumable := CUSTOMER.Hltprv_Decisionresult_Typ();
            Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Decisionresultconsumable.Decisiontypecode := Convertstatuscode(Rec.Status_Code, 0
                                                                                                                                                                                                                                                                     --rec.refusal_amount
                                                                                                                                                                                                                                                                    );

            IF Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Decisionresultconsumable.Decisiontypecode = 'RED'
            THEN
                FOR r IN Crrejects(Pclaimid, Psfno, Rec.Location_Code, Rec.Barcode, Rec.Seq_No, Rec.Item_Type)
                LOOP
                    Vrejexpl := Findrejectexplanation(r.Main_Code, r.Item_Code, r.Sub_Item_Code, '5', Rec.Group_Code, Rec.Provision_Date);

                    IF Vrejexpl IS NOT NULL
                    THEN
                        --
                        IF Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Decisionresultconsumable.Explanation IS NULL
                        THEN
                            Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Decisionresultconsumable.Explanation := Customer.Hltprv_Note_Tbl();
                        END IF;

                        Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Decisionresultconsumable.Explanation.Extend;
                        Vcount := Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Decisionresultconsumable.Explanation.Last;

                        Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Decisionresultconsumable.Explanation(Vcount) := Customer.Hltprv_Note_Typ();
                        Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Decisionresultconsumable.Explanation(Vcount).Text := Vrejexpl;
                    END IF;
                END LOOP;

                IF Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Decisionresultconsumable.Explanation IS NULL
                THEN
                    FOR r IN Crrejects2(Pclaimid, Psfno)
                    LOOP
                        Vrejexpl := Findrejectexplanation(r.Main_Code, r.Item_Code, r.Sub_Item_Code, '5', Rec.Group_Code, Rec.Provision_Date);

                        IF Vrejexpl IS NOT NULL
                        THEN
                            --
                            IF Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Decisionresultconsumable.Explanation IS NULL
                            THEN
                                Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Decisionresultconsumable.Explanation := Customer.Hltprv_Note_Tbl();
                            END IF;

                            Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Decisionresultconsumable.Explanation.Extend;
                            Vcount := Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Decisionresultconsumable.Explanation.Last;

                            Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Decisionresultconsumable.Explanation(Vcount) := Customer.Hltprv_Note_Typ();
                            Presp.Resultinfo.Resultreturning.Consumablesreturning(Vlast).Decisionresultconsumable.Explanation(Vcount).Text := Vrejexpl;
                        END IF;
                    END LOOP;
                END IF;
            END IF;
            DBMS_OUTPUT.PUT_LINE('Consumable:'|| Rec.Provision_Total);
            --
            -- Teminat tutarlar�n� i�lem/malzeme/ ila� detaylar�na da��tmak i�in ilgili objeye y�kle
            Pprovdist.Setcoverdetails(Rec.Cover_Code, Rec.Add_Order_No, Rec.Location_Code, Rec.Provision_Total, Rec.Request_Amount, Rec.Refusal_Amount,
                                                                Rec.Exemption_Amount, Rec.Exemption_Rate, Rec.Sgk_Amount, Rec.Add_Proc_Amount, v_Ind);

            --
            -- Hizmetleri ilgili teminata ekle

            IF v_Ind > 0
            THEN
                --
                IF Rec.Item_Type IN ('ILAC', 'ASI')
                THEN
                    Pprovdist.Cover_Details(v_Ind).Setmedicinedetail(Rec.Barcode, Rec.Seq_No, Rec.Order_No, Rec.Status_Code,
                                                                                                                     Nvl(Rec.Swift_Code, Vbaseswiftcode), Rec.Unit, Rec.Price, Vlast);
                ELSE
                    Pprovdist.Cover_Details(v_Ind).Setitemdetail(Rec.Barcode, Rec.Seq_No, Rec.Order_No, Rec.Status_Code, Nvl(Rec.Swift_Code, Vbaseswiftcode),
                                                                                                             Rec.Unit, Rec.Price, Vlast);
                END IF;
                --
            END IF;
            --
        END LOOP;
    END;
     FUNCTION Calcsumrefusualamount(Pclaimid IN NUMBER,
                                                                 Psfno    IN NUMBER) RETURN NUMBER IS
        Vrefusualamount NUMBER;
    BEGIN
        SELECT Round(SUM(Nvl(Refusal_Amount, 0) * ALZ_HLTPRV_UTILS.Findswfcurrency(Swift_Code)), 2) Refusal_Amount
            INTO Vrefusualamount
            FROM Koc_Clm_Hlth_Provisions
         WHERE Claim_Id = Pclaimid
             AND Sf_No = Psfno
             AND Add_Order_No = 1
             AND Nvl(Status_Code, 'X') <> 'C';

        RETURN Nvl(Vrefusualamount, 0);
    END;
FUNCTION Calcnotberequestedamount(Pclaimid IN NUMBER,
                                                                        Psfno    IN NUMBER) RETURN NUMBER IS
        Vnotberequestedamount NUMBER;
    BEGIN
        SELECT Round(SUM(Nvl(a.Refuse_Amount, 0) * ALZ_HLTPRV_UTILS.Findswfcurrency(b.Swift_Code)), 2) Not_Be_Requested_Amount
            INTO Vnotberequestedamount
            FROM Koc_Clm_Hlth_Reject_Loss a,
                     Koc_Clm_Hlth_Detail      b
         WHERE a.Claim_Id = Pclaimid
             AND a.Sf_No = Psfno
             AND b.Claim_Id = a.Claim_Id
             AND b.Sf_No = a.Sf_No
             AND (a.Main_Code = 16 AND a.Item_Code = 12);

        RETURN Nvl(Vnotberequestedamount, 0);
    END;

FUNCTION Calcrequestamount(Pclaimid IN NUMBER,
                                                         Psfno    IN NUMBER) RETURN NUMBER IS
        Vrequestamount NUMBER;
    BEGIN
        --TL d�n���m� yap�l�yor
        SELECT Round(SUM(Nvl(Inst_Request_Amount, 0) * ALZ_HLTPRV_UTILS.Findswfcurrency(Swift_Code)), 2)
            INTO Vrequestamount
            FROM Koc_Clm_Hlth_Provisions
         WHERE Claim_Id = Pclaimid
             AND Sf_No = Psfno
             AND Add_Order_No = 1;

        RETURN Nvl(Vrequestamount, 0);
    END;
FUNCTION Calcprovisionamount(Pclaimid IN NUMBER,
                                                             Psfno    IN NUMBER) RETURN NUMBER IS
        Vprovisionamount NUMBER;
    BEGIN
        SELECT Round(SUM(Nvl(Provision_Total, 0) * ALZ_HLTPRV_UTILS.Findswfcurrency(Swift_Code)), 2)
            INTO Vprovisionamount
            FROM Koc_Clm_Hlth_Provisions a
         WHERE a.Claim_Id = Pclaimid
             AND a.Sf_No = Psfno
             AND a.Add_Order_No = 1
             AND a.Status_Code NOT IN ('R', 'C');

        RETURN Nvl(Vprovisionamount, 0);
    END;
      FUNCTION Calclimitexcessamount(Pclaimid              IN NUMBER,
                                                                 Psfno                 IN NUMBER,
                                                                 Pnotberequestedamount IN NUMBER,
                                                                 Psgkamount            IN NUMBER,
                                                                 Psumrefusualamount    IN NUMBER) RETURN NUMBER IS
        Vlimitexcessamount NUMBER;
        v_Is_Tss_Oss       NUMBER;
    BEGIN
        SELECT Decode(Nvl(d.Is_Complementary, 0), 1, 0, 1)
            INTO v_Is_Tss_Oss
            FROM Koc_Clm_Hlth_Detail d
         WHERE d.Claim_Id = Pclaimid
             AND d.Sf_No = Psfno
             AND d.Add_Order_No = 1;

        --AND Nvl(d.Status_Code, 'X') <> 'C'; -- bdemir . bugfix , tss provizyon sorguyu etkiliyor.

        SELECT Round(SUM((Nvl(Request_Amount, 0) - Nvl(Exemption_Amount, 0) -
                                         Nvl(Decode(Exemption_Rate, 1, 0, (Provision_Total / (1 - Exemption_Rate))) * Exemption_Rate, 0) - Nvl(Provision_Total, 0) -
                                         Nvl(Refusal_Amount, 0) * Decode(Sign(Nvl(Psgkamount * v_Is_Tss_Oss, 0) - Nvl(Psumrefusualamount, 0)), 1, 0, 1) -
                                         Nvl(Sgk_Amount, 0) * Decode(Sign(Nvl(Psgkamount * v_Is_Tss_Oss, 0) - Nvl(Psumrefusualamount, 0)), 1, 1, 0)) *
                                         ALZ_HLTPRV_UTILS.Findswfcurrency(Swift_Code)) - Nvl(Pnotberequestedamount, 0), 2) Limit_Asimi
            INTO Vlimitexcessamount
            FROM Koc_Clm_Hlth_Provisions p
         WHERE p.Claim_Id = Pclaimid
             AND p.Sf_No = Psfno
             AND p.Add_Order_No = 1
             AND Nvl(p.Status_Code, 'X') <> 'C';

        /*
    SELECT ROUND (
                SUM (
                     (  NVL (Request_Amount, 0)
                      - NVL (Exemption_Amount, 0)
                      - NVL (
                             DECODE (
                                Exemption_Rate,
                                1, 0,
                                (Provision_Total / (1 - Exemption_Rate)))
                           * Exemption_Rate,
                           0)
                      - NVL (Provision_Total, 0)
                      -   NVL (Refusal_Amount, 0)
                        * DECODE (
                             SIGN (
                                  NVL (Psgkamount, 0)
                                - NVL (Psumrefusualamount, 0)),
                             1, 0,
                             1)
                      -   NVL (Sgk_Amount, 0)
                        * DECODE (
                             SIGN (
                                  NVL (Psgkamount, 0)
                                - NVL (Psumrefusualamount, 0)),
                             1, 1,
                             0))
                   * Findswfcurrency (Swift_Code))
              - NVL (Pnotberequestedamount, 0),
              2)
              Limit_Asimi
      INTO Vlimitexcessamount
      FROM Koc_Clm_Hlth_Provisions p
     WHERE     p.Claim_Id = Pclaimid
           AND p.Sf_No = Psfno
           AND p.Add_Order_No = 1
           AND NVL (p.Status_Code, 'X') <> 'C';*/

        RETURN Nvl(Vlimitexcessamount, 0);
    END;
    FUNCTION Calcpatientamount(Pclaimid IN NUMBER,
                                                         Psfno    IN NUMBER) RETURN NUMBER IS
        Vpatientamount NUMBER;
    BEGIN
        SELECT Round(SUM(Nvl(Decode(Exemption_Rate, 1, 0, (Provision_Total / (1 - Exemption_Rate))) * Exemption_Rate, 0) * ALZ_HLTPRV_UTILS.Findswfcurrency(Swift_Code)), 2) Katilim_Tutar
            INTO Vpatientamount
            FROM Koc_Clm_Hlth_Provisions p
         WHERE p.Claim_Id = Pclaimid
             AND p.Sf_No = Psfno
             AND p.Add_Order_No = 1
             AND Nvl(p.Status_Code, 'X') <> 'C';

        RETURN Nvl(Vpatientamount, 0);
    END;
    FUNCTION Calcsumexemptionamount(Pclaimid IN NUMBER,
                                                                    Psfno    IN NUMBER) RETURN NUMBER IS
        Vexemptionamount NUMBER;
    BEGIN
        SELECT Round(SUM(Nvl(Exemption_Amount, 0) * ALZ_HLTPRV_UTILS.Findswfcurrency(Swift_Code)), 2) Exemption_Amount
            INTO Vexemptionamount
            FROM Koc_Clm_Hlth_Provisions
         WHERE Claim_Id = Pclaimid
             AND Sf_No = Psfno
             AND Add_Order_No = 1
             AND Nvl(Status_Code, 'X') <> 'C';

        RETURN Nvl(Vexemptionamount, 0);
    END;
 FUNCTION Calcoutofagreementamount(Pclaimid IN NUMBER,
                                                                        Psfno    IN NUMBER) RETURN NUMBER IS
        Voutofagreementamount NUMBER;
    BEGIN
        SELECT Round(SUM((Nvl(Inst_Request_Amount, 0) - Nvl(Sys_Request_Amount, 0)) * ALZ_HLTPRV_UTILS.Findswfcurrency(Swift_Code)), 2) Anlasma_Harici_Tutar
            INTO Voutofagreementamount
            FROM Koc_Clm_Hlth_Provisions
         WHERE Claim_Id = Pclaimid
             AND Sf_No = Psfno
             AND Round(Nvl(Inst_Request_Amount, 0) - Nvl(Sys_Request_Amount, 0), 2) > 0;

        RETURN Nvl(Voutofagreementamount, 0);
    END;
     PROCEDURE Fillprovisionsumamount(Prequestamount        IN NUMBER,
                                                                     Pprovisionamount      IN NUMBER,
                                                                     Plimitexcessamount    IN NUMBER,
                                                                     Ppatientamount        IN NUMBER,
                                                                     Pexemptionamount      IN NUMBER,
                                                                     Pnotberequestedamount IN NUMBER,
                                                                     Poutofagreementamount IN NUMBER,
                                                                     Psgkamount            IN NUMBER,
                                                                     Prefusualamount       IN NUMBER,
                                                                     Presp                 IN OUT Customer.Hltprv_Provision_Resp_Typ) IS
    BEGIN
        IF Presp.Resultinfo IS NULL
        THEN
            Presp.Resultinfo := CUSTOMER.Hltprv_Result_Typ();
        END IF;

        IF Presp.Resultinfo.Resultreturning IS NULL
        THEN
            Presp.Resultinfo.Resultreturning := CUSTOMER.Hltprv_Resultreturning_Typ();
        END IF;

        Presp.Resultinfo.Resultreturning.Amountsum := CUSTOMER.Hltprv_Amountprocess_Typ();

        Presp.Resultinfo.Resultreturning.Amountsum.Amountpatient                     := CUSTOMER.Hltprv_Amountpatient_Typ();
        Presp.Resultinfo.Resultreturning.Amountsum.Amountpatient.Amountexceeding     := Plimitexcessamount;
        Presp.Resultinfo.Resultreturning.Amountsum.Amountpatient.Amountparticipation := Ppatientamount;
        Presp.Resultinfo.Resultreturning.Amountsum.Amountpatient.Amountoutofscope    := Prefusualamount;
        Presp.Resultinfo.Resultreturning.Amountsum.Amountpatient.Amountexemption     := Pexemptionamount;
        --????pResp.resultinfo.resultreturning.amountsum.amountpatient.explanation

        Presp.Resultinfo.Resultreturning.Amountsum.Amounthospitalpay                               := CUSTOMER.Hltprv_Amounthospitalpay_Typ();
        Presp.Resultinfo.Resultreturning.Amountsum.Amounthospitalpay.Amountnotbilledforcontract    := Pnotberequestedamount;
        Presp.Resultinfo.Resultreturning.Amountsum.Amounthospitalpay.Amountincompatibleforcontract := Poutofagreementamount;

        --????pResp.resultinfo.resultreturning.amountsum.stoppage
        --????pResp.resultinfo.resultreturning.amountsum.ratevat

        Presp.Resultinfo.Resultreturning.Amountsum.Amountsgk       := Psgkamount;
        Presp.Resultinfo.Resultreturning.Amountsum.Amountrequest   := Prequestamount;
        Presp.Resultinfo.Resultreturning.Amountsum.Amountprovision := Pprovisionamount;
    END;
  PROCEDURE Fillprovisionamounts(Pclaimid  IN Koc_Clm_Hlth_Detail.Claim_Id%TYPE,
                                                                 Psfno     IN Koc_Clm_Hlth_Detail.Sf_No%TYPE,
                                                                 Pprovdist IN OUT Customer.Hltprv_Prov_Dist_Claim_Typ,
                                                                 Presp     IN OUT Customer.Hltprv_Provision_Resp_Typ) IS
        v_Cvr_Ind PLS_INTEGER;
        v_Dtl_Ind PLS_INTEGER;
        v_Ind     PLS_INTEGER;
        v_step    VARCHAR2(100);
    BEGIN
        v_step := '4.19.1';
        
        --Teminatlara ba�l� i�lem/ila�/malzemelere teminat �zerindeki fiyatlar da��t�l�yor
        --Pprovdist.Distcoversamountstodetails;
        v_Claim_Id := Pclaimid;
        v_Sf_No    := psfno;
        FOR ndx IN 1..Pprovdist.Cover_Details.Count LOOP
            DBMS_OUTPUT.PUT_LINE('Distributing..Cover_Code='||Pprovdist.Cover_Details(ndx).Cover_Code);
            v_Prov_details := Pprovdist.Cover_Details(ndx).prov_details;
            Distcoveramountstodetails(Pprovdist.Cover_Details(ndx).Provision_Total, Pprovdist.Cover_Details(ndx).NotBilledRejectAmount, Pprovdist.Cover_Details(ndx).PatientRejectAmount, Pprovdist.Cover_Details(ndx).Exemption_rate);
        END LOOP; 
        v_step := '4.19.2';
        --
        IF Pprovdist.Cover_Details IS NULL
        THEN
            RETURN;
        END IF;
         
        v_Cvr_Ind := Pprovdist.Cover_Details.First;

        WHILE v_Cvr_Ind IS NOT NULL
        LOOP
            v_Dtl_Ind := Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details.First;

            WHILE v_Dtl_Ind IS NOT NULL
            LOOP
                --i�lem tutar� at�lacak olan cevaptaki process indeksi bulunuyor
                v_Ind := Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind).Index_On_Type;

                IF Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind).Detail_Type = 'PROCESS'
                THEN
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(v_Ind).Amountprocess := CUSTOMER.Hltprv_Amountprocess_Typ();

                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(v_Ind).Amountprocess.Amountpatient := CUSTOMER.Hltprv_Amountpatient_Typ();
                    -- Limitasimindankaynaklananhastapayi
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(v_Ind).Amountprocess.Amountpatient.Amountexceeding := Round(Nvl(Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind)
                                                                                                                                                                                                                                                                 .Amount_Exceeding, 0),
                                                                                                                                                                                                                                                         2);

                    -- Istiraktenkaynaklananhastapayi
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(v_Ind).Amountprocess.Amountpatient.Amountparticipation := Round(Nvl(Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind)
                                                                                                                                                                                                                                                                         .Amount_Participation,
                                                                                                                                                                                                                                                                         0), 2);

                    -- Kapsamdisitutar
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(v_Ind).Amountprocess.Amountpatient.Amountoutofscope := Round(Nvl(Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind)
                                                                                                                                                                                                                                                                    .Amount_Out_Of_Scope,
                                                                                                                                                                                                                                                                    0), 2);

                    -- TutarMuafiyettenKaynaklananHastaPayi
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(v_Ind).Amountprocess.Amountpatient.Amountexemption := Round(Nvl(Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind)
                                                                                                                                                                                                                                                                 .Amount_Exemption, 0),
                                                                                                                                                                                                                                                         2);

                    --presp.resultinfo.resultreturning.serviceinfosreturning(i).amountprocess.amountpatient.explanation.text          -- aciklama

                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(v_Ind).Amountprocess.Amounthospitalpay := CUSTOMER.Hltprv_Amounthospitalpay_Typ();

                    -- SozlesmeGeregiFaturaEdilmemesiGerekenTutari
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(v_Ind).Amountprocess.Amounthospitalpay.Amountnotbilledforcontract := Round(Nvl(Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind)
                                                                                                                                                                                                                                                                                                .Amount_Not_Billed,
                                                                                                                                                                                                                                                                                                0), 2);

                    -- SozlesmeGeregiOlusanUyumsuzTutar
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(v_Ind).Amountprocess.Amounthospitalpay.Amountincompatibleforcontract := Round(Nvl(Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind)
                                                                                                                                                                                                                                                                                                     .Amount_Incompatible,
                                                                                                                                                                                                                                                                                                     0),
                                                                                                                                                                                                                                                                                             2);

                    -- SgkTutari
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(v_Ind).Amountprocess.Amountsgk := Round(Nvl(Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind)
                                                                                                                                                                                                                         .Amount_Sgk, 0), 2);

                    -- TalepEdilenTutar
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(v_Ind).Amountprocess.Amountrequest := Round(Nvl(Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind)
                                                                                                                                                                                                                                 .Amount_Request, 0), 2);

                    -- Sigortasirketininodeyecegitutar
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(v_Ind).Amountprocess.Amountprovision := Round(Nvl(Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind)
                                                                                                                                                                                                                                     .Amount_Provision, 0), 2);

                    --limitexceedingstatus = 2 B�t�n limit dolmu�, hasta b�t�n pay� �d�yor
                    --limitexceedingstatus = 1 Hasta bpay�n bir k�sm�n� �d�yor bir k�sm� limit a��m�na tak�l�yor
                    IF Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind).Limitexceedingstatus = 2
                    THEN
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(v_Ind).Decisionresult.Decisiontypecode := 'RED';
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(v_Ind).Decisionresult.Explanation := Customer.Hltprv_Note_Tbl();
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(v_Ind).Decisionresult.Explanation.Extend;
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(v_Ind).Decisionresult.Explanation(1) := Customer.Hltprv_Note_Typ();
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(v_Ind).Decisionresult.Explanation(1).Text := 'Limit a��m� veya teminat retti nedeniyle talep tutar� reddedilmi�tir.';
                    ELSIF Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind).Limitexceedingstatus = 1
                    THEN
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(v_Ind).Decisionresult.Decisiontypecode := 'KISMI_ONAY';
                    END IF;
                ELSE
                    Presp.Resultinfo.Resultreturning.Consumablesreturning(v_Ind).Amountconsumable := CUSTOMER.Hltprv_Amountprocess_Typ();

                    Presp.Resultinfo.Resultreturning.Consumablesreturning(v_Ind).Amountconsumable.Amountpatient := CUSTOMER.Hltprv_Amountpatient_Typ();

                    -- Limitasimindankaynaklananhastapayi
                    Presp.Resultinfo.Resultreturning.Consumablesreturning(v_Ind).Amountconsumable.Amountpatient.Amountexceeding := Round(Nvl(Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind)
                                                                                                                                                                                                                                                                     .Amount_Exceeding, 0),
                                                                                                                                                                                                                                                             2);

                    -- Istiraktenkaynaklananhastapayi
                    Presp.Resultinfo.Resultreturning.Consumablesreturning(v_Ind).Amountconsumable.Amountpatient.Amountparticipation := Round(Nvl(Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind)
                                                                                                                                                                                                                                                                             .Amount_Participation,
                                                                                                                                                                                                                                                                             0), 2);

                    -- Kapsamdisitutar
                    Presp.Resultinfo.Resultreturning.Consumablesreturning(v_Ind).Amountconsumable.Amountpatient.Amountoutofscope := Round(Nvl(Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind)
                                                                                                                                                                                                                                                                        .Amount_Out_Of_Scope,
                                                                                                                                                                                                                                                                        0), 2);

                    -- TutarMuafiyettenKaynaklananHastaPayi
                    Presp.Resultinfo.Resultreturning.Consumablesreturning(v_Ind).Amountconsumable.Amountpatient.Amountexemption := Round(Nvl(Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind)
                                                                                                                                                                                                                                                                     .Amount_Exemption, 0),
                                                                                                                                                                                                                                                             2);

                    --presp.resultinfo.resultreturning.serviceinfosreturning(i).amountconsumable.amountpatient.explanation.text          -- aciklama

                    Presp.Resultinfo.Resultreturning.Consumablesreturning(v_Ind).Amountconsumable.Amounthospitalpay := CUSTOMER.Hltprv_Amounthospitalpay_Typ();

                    -- SozlesmeGeregiFaturaEdilmemesiGerekenTutari
                    Presp.Resultinfo.Resultreturning.Consumablesreturning(v_Ind).Amountconsumable.Amounthospitalpay.Amountnotbilledforcontract := Round(Nvl(Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind)
                                                                                                                                                                                                                                                                                                    .Amount_Not_Billed,
                                                                                                                                                                                                                                                                                                    0), 2);

                    -- SozlesmeGeregiOlusanUyumsuzTutar
                    Presp.Resultinfo.Resultreturning.Consumablesreturning(v_Ind).Amountconsumable.Amounthospitalpay.Amountincompatibleforcontract := Round(Nvl(Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind)
                                                                                                                                                                                                                                                                                                         .Amount_Incompatible,
                                                                                                                                                                                                                                                                                                         0),
                                                                                                                                                                                                                                                                                                 2);

                    -- SgkTutari
                    Presp.Resultinfo.Resultreturning.Consumablesreturning(v_Ind).Amountconsumable.Amountsgk := Round(Nvl(Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind)
                                                                                                                                                                                                                             .Amount_Sgk, 0), 2);

                    -- TalepEdilenTutar
                    Presp.Resultinfo.Resultreturning.Consumablesreturning(v_Ind).Amountconsumable.Amountrequest := Round(Nvl(Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind)
                                                                                                                                                                                                                                     .Amount_Request, 0), 2);

                    -- Sigortasirketininodeyecegitutar
                    Presp.Resultinfo.Resultreturning.Consumablesreturning(v_Ind).Amountconsumable.Amountprovision := Round(Nvl(Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind)
                                                                                                                                                                                                                                         .Amount_Provision, 0), 2);

                    --limitexceedingstatus = 2 B�t�n limit dolmu�, hasta b�t�n pay� �d�yor
                    --limitexceedingstatus = 1 Hasta bpay�n bir k�sm�n� �d�yor bir k�sm� limit a��m�na tak�l�yor
                    IF Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind).Limitexceedingstatus = 2
                    THEN
                        Presp.Resultinfo.Resultreturning.Consumablesreturning(v_Ind).Decisionresultconsumable.Decisiontypecode := 'RED';
                        Presp.Resultinfo.Resultreturning.Consumablesreturning(v_Ind).Decisionresultconsumable.Explanation := Customer.Hltprv_Note_Tbl();
                        Presp.Resultinfo.Resultreturning.Consumablesreturning(v_Ind).Decisionresultconsumable.Explanation.Extend;
                        Presp.Resultinfo.Resultreturning.Consumablesreturning(v_Ind).Decisionresultconsumable.Explanation(1) := Customer.Hltprv_Note_Typ();
                        Presp.Resultinfo.Resultreturning.Consumablesreturning(v_Ind).Decisionresultconsumable.Explanation(1).Text := 'Limit a��m� veya teminat retti nedeniyle talep tutar� reddedilmi�tir.';
                    ELSIF Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details(v_Dtl_Ind).Limitexceedingstatus = 1
                    THEN
                        Presp.Resultinfo.Resultreturning.Consumablesreturning(v_Ind).Decisionresultconsumable.Decisiontypecode := 'KISMI_ONAY';
                    END IF;
                END IF;
                     
                v_Dtl_Ind := Pprovdist.Cover_Details(v_Cvr_Ind).Prov_Details.Next(v_Dtl_Ind);
            END LOOP;
            v_step := '4.19.3';    
            v_Cvr_Ind := Pprovdist.Cover_Details.Next(v_Cvr_Ind);
        END LOOP;
    EXCEPTION
    WHEN OTHERS THEN
       DBMS_OUTPUT.PUT_LINE('Hata:'||SQLERRM||' step='||v_step);    
    END;
      PROCEDURE Fillprovisiondecision(Pclaimid IN Koc_Clm_Hlth_Detail.Claim_Id%TYPE,
                                                                    Psfno    IN Koc_Clm_Hlth_Detail.Sf_No%TYPE,
                                                                    Presp    IN OUT Customer.Hltprv_Provision_Resp_Typ) IS
        CURSOR Crstatus(Cpclaimid IN NUMBER,
                                        Cpsfno    IN NUMBER) IS
            SELECT Claim_Id,
                         Sf_No,
                         Status_Code,
                         Provision_Date,
                         Group_Code,
                         Web_Location_Code
                FROM Koc_Clm_Hlth_Detail
             WHERE Claim_Id = Cpclaimid
                 AND Sf_No = Cpsfno
                 AND Add_Order_No = 1;

        CURSOR Crrejects(Cpclaimid IN NUMBER,
                                         Cpsfno    IN NUMBER) IS
            SELECT DISTINCT Main_Code,
                                            Item_Code,
                                            Sub_Item_Code
                FROM Koc_Clm_Hlth_Reject_Loss
             WHERE Claim_Id = Cpclaimid
                 AND Sf_No = Cpsfno
                 AND Add_Order_No = 1
                 AND Nvl(Cover_Code, '0') = '0'
                 AND Nvl(Process_Code_Main, 0) = 0
                 AND Nvl(Process_Code_Sub1, 0) = 0
                 AND Nvl(Process_Code_Sub2, 0) = 0
                 AND Nvl(Barcode, 0) = 0
                 AND Nvl(Ubb_Code, '0') = '0';

        CURSOR Crrejects2(Cpclaimid IN NUMBER,
                                            Cpsfno    IN NUMBER,
                                            Cploccode IN NUMBER) IS
            SELECT DISTINCT Main_Code,
                                            Item_Code,
                                            Sub_Item_Code
                FROM Koc_Clm_Hlth_Reject_Loss
             WHERE Claim_Id = Cpclaimid
                 AND Sf_No = Cpsfno
                 AND Add_Order_No = 1
                 AND Location_Code = Cploccode
                 AND ((Nvl(Process_Code_Main, 0) <> 0 AND Nvl(Process_Code_Sub1, 0) <> 0 AND Nvl(Process_Code_Sub2, 0) <> 0) OR Nvl(Barcode, 0) <> 0 OR
                         Nvl(Ubb_Code, '0') <> '0');

        Recstat       Crstatus%ROWTYPE;
        Vrejexpl      VARCHAR2(1000);
        Vlast         NUMBER;
        Vcountreject  NUMBER;
        Vcountservice NUMBER;
        Vcountconsume NUMBER;
    BEGIN
        OPEN Crstatus(Pclaimid, Psfno);

        FETCH Crstatus
            INTO Recstat;

        IF Crstatus%NOTFOUND
        THEN
            CLOSE Crstatus;

            Raise_Application_Error(-20101, 'Hasar dosyas� bulunamad�!');
        END IF;

        CLOSE Crstatus;

        IF Presp.Resultinfo IS NULL
        THEN
            Presp.Resultinfo := CUSTOMER.Hltprv_Result_Typ();
        END IF;

        IF Presp.Resultinfo.Resultreturning IS NULL
        THEN
            Presp.Resultinfo.Resultreturning := CUSTOMER.Hltprv_Resultreturning_Typ();
        END IF;

        Presp.Resultinfo.Resultreturning.Decisionresult                  := CUSTOMER.Hltprv_Decisionresult_Typ();
        Presp.Resultinfo.Resultreturning.Decisionresult.Decisiontypecode := Convertprovisionstatuscode(Pclaimid, Psfno, 1, Recstat.Status_Code);

        --
        IF Presp.Resultinfo.Resultreturning.Decisionresult.Decisiontypecode = 'RED'
        THEN
            FOR r IN Crrejects(Pclaimid, Psfno)
            LOOP
                Vrejexpl := NULL;

                Vrejexpl := Findrejectexplanation(r.Main_Code, r.Item_Code, r.Sub_Item_Code, '5', Recstat.Group_Code, Recstat.Provision_Date);

                --
                IF Vrejexpl IS NOT NULL
                THEN
                    --
                    IF Presp.Resultinfo.Resultreturning.Decisionresult.Explanation IS NULL
                    THEN
                        Presp.Resultinfo.Resultreturning.Decisionresult.Explanation := Customer.Hltprv_Note_Tbl();
                    END IF;

                    Presp.Resultinfo.Resultreturning.Decisionresult.Explanation.Extend;
                    Vlast := Presp.Resultinfo.Resultreturning.Decisionresult.Explanation.Last;

                    Presp.Resultinfo.Resultreturning.Decisionresult.Explanation(Vlast) := Customer.Hltprv_Note_Typ();
                    Presp.Resultinfo.Resultreturning.Decisionresult.Explanation(Vlast).Text := Vrejexpl;
                END IF;
            END LOOP;

            --dosyan�n reddi yok ise i�lemlerin reddine bak
            IF Presp.Resultinfo.Resultreturning.Decisionresult.Explanation IS NULL
            THEN
                FOR r IN Crrejects2(Recstat.Claim_Id, Recstat.Sf_No, Recstat.Web_Location_Code)
                LOOP
                    Vrejexpl := NULL;

                    Vrejexpl := Findrejectexplanation(r.Main_Code, r.Item_Code, r.Sub_Item_Code, '5', Recstat.Group_Code, Recstat.Provision_Date);

                    IF Vrejexpl IS NOT NULL
                    THEN
                        --
                        IF Presp.Resultinfo.Resultreturning.Decisionresult.Explanation IS NULL
                        THEN
                            Presp.Resultinfo.Resultreturning.Decisionresult.Explanation := Customer.Hltprv_Note_Tbl();
                        END IF;

                        Presp.Resultinfo.Resultreturning.Decisionresult.Explanation.Extend;
                        Vlast := Presp.Resultinfo.Resultreturning.Decisionresult.Explanation.Last;

                        Presp.Resultinfo.Resultreturning.Decisionresult.Explanation(Vlast) := Customer.Hltprv_Note_Typ();
                        Presp.Resultinfo.Resultreturning.Decisionresult.Explanation(Vlast).Text := Vrejexpl;
                    END IF;
                END LOOP;
            END IF;
        ELSIF Presp.Resultinfo.Resultreturning.Decisionresult.Decisiontypecode = 'ONAY'
        THEN
            Vcountreject  := 0;
            Vcountservice := 0;
            Vcountconsume := 0;

            --
            IF Presp.Resultinfo.Resultreturning.Serviceinfosreturning IS NOT NULL
            THEN
                Vcountservice := Presp.Resultinfo.Resultreturning.Serviceinfosreturning.Count;

                FOR i IN 1 .. Presp.Resultinfo.Resultreturning.Serviceinfosreturning.Count
                LOOP
                    IF Presp.Resultinfo.Resultreturning.Serviceinfosreturning(i).Decisionresult.Decisiontypecode IN ('RED')
                    THEN
                        Vcountreject := Vcountreject + 1;
                    END IF;
                END LOOP;
            END IF;

            --
            IF Presp.Resultinfo.Resultreturning.Consumablesreturning IS NOT NULL
            THEN
                Vcountconsume := Presp.Resultinfo.Resultreturning.Consumablesreturning.Count;

                FOR i IN 1 .. Presp.Resultinfo.Resultreturning.Consumablesreturning.Count
                LOOP
                    IF Presp.Resultinfo.Resultreturning.Consumablesreturning(i).Decisionresultconsumable.Decisiontypecode IN ('RED')
                    THEN
                        Vcountreject := Vcountreject + 1;
                    END IF;
                END LOOP;
            END IF;

            --
            IF Vcountservice > 0 OR
                 Vcountconsume > 0
            THEN
                IF Vcountservice + Vcountconsume = Vcountreject
                THEN
                    Presp.Resultinfo.Resultreturning.Decisionresult.Decisiontypecode := 'RED';

                    Presp.Resultinfo.Resultreturning.Decisionresult.Explanation := Customer.Hltprv_Note_Tbl();
                    Presp.Resultinfo.Resultreturning.Decisionresult.Explanation.Extend;
                    Vlast := Presp.Resultinfo.Resultreturning.Decisionresult.Explanation.Last;

                    Presp.Resultinfo.Resultreturning.Decisionresult.Explanation(Vlast) := Customer.Hltprv_Note_Typ();

                    --
                    IF Vcountservice > 0 AND
                         Vcountconsume > 0
                    THEN
                        Presp.Resultinfo.Resultreturning.Decisionresult.Explanation(Vlast).Text := 'T�m hizmetler ve sarf malzemeler reddedildi�inden dosya reddedilmi�tir.';
                    ELSIF Vcountservice > 0 AND
                                Vcountconsume = 0
                    THEN
                        Presp.Resultinfo.Resultreturning.Decisionresult.Explanation(Vlast).Text := 'T�m hizmetler reddedildi�inden dosya reddedilmi�tir.';
                    ELSIF Vcountservice = 0 AND
                                Vcountconsume > 0
                    THEN
                        Presp.Resultinfo.Resultreturning.Decisionresult.Explanation(Vlast).Text := 'T�m sarf malzemeler reddedildi�inden dosya reddedilmi�tir.';
                    END IF;
                ELSIF Vcountreject > 0
                THEN
                    Presp.Resultinfo.Resultreturning.Decisionresult.Decisiontypecode := 'KISMI_ONAY';
                END IF;
            END IF;
        END IF;
    END;


      PROCEDURE Setprovision(Pclaimid       IN Koc_Clm_Hlth_Detail.Claim_Id%TYPE,
                                                 Psfno          IN Koc_Clm_Hlth_Detail.Sf_No%TYPE,
                                                 Prequestsystem IN VARCHAR2,
                                                 Plogid         IN NUMBER,
                                                 Porigindate    IN DATE,
                                                 Pinstitute     IN CUSTOMER.Hltprv_Institute_Typ,
                                                 Pinstitutepass IN CUSTOMER.Hltprv_Institutepass_Typ,
                                                 Presp          OUT Customer.Hltprv_Provision_Resp_Typ) IS
        CURSOR Crmaxprocess(Cpclaimid IN NUMBER,
                                                Cpsfno    IN NUMBER) IS
            SELECT MAX(Process_Date) Processdate
                FROM Koc_Clm_Hlth_Indem_Dec
             WHERE Claim_Id = Cpclaimid
                 AND Sf_No = Cpsfno
                 AND Add_Order_No = 1
                 AND File_Agreement_Code IN ('P', 'R', 'C');

        CURSOR Crdetail(Cpclaimid IN NUMBER,
                                        Cpsfno    IN NUMBER) IS
            SELECT a.Provision_Date    Provisiondate,
                         b.Ext_Reference     Extreference,
                         a.Hospital_Ref_No   Hospitalrefno,
                         a.Status_Code       Statuscode,
                         a.Web_Location_Code Locationcode
                FROM Koc_Clm_Hlth_Detail a,
                         Clm_Subfiles        b
             WHERE a.Claim_Id = Cpclaimid
                 AND a.Sf_No = Cpsfno
                 AND a.Add_Order_No = 1
                 AND b.Claim_Id = a.Claim_Id
                 AND b.Sf_No = a.Sf_No
                 AND b.Sf_Type = 'HLT';

        Vsgkamount            NUMBER;
        Vrefusualamount       NUMBER;
        Vnotberequestedamount NUMBER;
        Vrequestamount        NUMBER;
        Vprovisionamount      NUMBER;
        Vlimitexcessamount    NUMBER;
        Vpatientamount        NUMBER;
        Voutofcoversamount    NUMBER;
        Vexemptionamount      NUMBER;
        Voutofagreementamount NUMBER;
        Vlastindx             NUMBER;
        Vprovdist             Customer.Hltprv_Prov_Dist_Claim_Typ;
        Vlocationcode         NUMBER;
        v_step VARCHAR2(400);
    BEGIN
        v_step := '1';
        Presp := Customer.Hltprv_Provision_Resp_Typ();

        Presp.Logid         := Plogid;
        Presp.Requestsystem := Prequestsystem;

        FOR Recdate IN Crmaxprocess(Pclaimid, Psfno)
        LOOP
            Presp.Provisiondatecompletiondate := Recdate.Processdate;
        END LOOP;
        v_step := '2';
        FOR Recdetail IN Crdetail(Pclaimid, Psfno)
        LOOP
            Presp.Provisiondate := Recdetail.Provisiondate;
            Presp.Reference     := CUSTOMER.Hltprv_Reference_Tbl();

            IF Recdetail.Extreference IS NOT NULL
            THEN
                Presp.Reference.Extend;
                Vlastindx := Presp.Reference.Last;
                Presp.Reference(Vlastindx) := CUSTOMER.Hltprv_Reference_Typ();
                Presp.Reference(Vlastindx).Type := 'PROVIZYON_NUMARASI';
                Presp.Reference(Vlastindx).Referenceno := Recdetail.Extreference;
            END IF;

            IF Recdetail.Hospitalrefno IS NOT NULL
            THEN
                Presp.Reference.Extend;
                Vlastindx := Presp.Reference.Last;
                Presp.Reference(Vlastindx) := CUSTOMER.Hltprv_Reference_Typ();
                Presp.Reference(Vlastindx).Type := 'HASTANE_REFERANS_NUMARASI';
                Presp.Reference(Vlastindx).Referenceno := Recdetail.Hospitalrefno;
            END IF;

            Vlocationcode := Recdetail.Locationcode;
        END LOOP;
        v_step := '3'; 
        Fillprovisionreqstatus(Pclaimid, Psfno, Presp);
        v_step := '4';
        --dosya e�er otorizasyon, red, iptal de�ilse detay� g�nder
        IF Presp.Resultinfo.Requeststatus.Statuscode IS NULL
        THEN
            v_step := '4.1';
            Fillprovisioninsured(Pclaimid, Psfno, Prequestsystem, Plogid, Porigindate, Pinstitute, Pinstitutepass, Presp);
            v_step := '4.2';
            Vsgkamount := Calcsgkamount(Pclaimid, Psfno);
            v_step := '4.3';
            Fillprovisionsgk(Vsgkamount, Presp);
            v_step := '4.4';  
            --YT �n onay ise detay g�sterme
            IF Ishosptpreapprove(Pclaimid, Psfno) = 1
            THEN
                v_step := '4.5';
                Fillprovisionpreapprove(Pclaimid, Psfno, Presp);
                v_step := '4.6';
            ELSE
                v_step := '4.7';
                --��lem ve Sarf i�lem tutarlar�n�n bulunabilmesi i�in kullan�lan rec
                DBMS_OUTPUT.PUT_LINE('4.7 claim_id='||Pclaimid);
                
                Vprovdist          := Customer.Hltprv_Prov_Dist_Claim_Typ();
                
                Vprovdist.Claim_Id := Pclaimid;
                Vprovdist.Sf_No    := Psfno;
                v_step := '4.8'; 
                --vprovdist i�erisindeki i�lem teminatlar� doluyor
                --response i�erisindeki hizmetler olu�turuluyor
                Fillprovisionservices(Pclaimid, Psfno, Presp, Vprovdist);
                v_step := '4.9';
                --vprovdist i�erisindeki ila�/malzeme teminatlar� doluyor
                --response i�erisindeki ila�/malzeme olu�turuluyor
                Fillprovisionconsumables(Pclaimid, Psfno, Presp, Vprovdist);
                v_step := '4.10';
                Vrefusualamount       := Calcsumrefusualamount(Pclaimid, Psfno);
                v_step := '4.11';
                Vnotberequestedamount := Calcnotberequestedamount(Pclaimid, Psfno);
                v_step := '4.12';
                Vrequestamount        := Calcrequestamount(Pclaimid, Psfno);
                v_step := '4.13';
                Vprovisionamount      := Calcprovisionamount(Pclaimid, Psfno);
                v_step := '4.14';
                Vlimitexcessamount    := Calclimitexcessamount(Pclaimid, Psfno, Vnotberequestedamount, Vsgkamount, Vrefusualamount);
                v_step := '4.15';
                Vpatientamount        := Calcpatientamount(Pclaimid, Psfno);
                v_step := '4.16';
                Vexemptionamount      := Calcsumexemptionamount(Pclaimid, Psfno);
                v_step := '4.17';
                Voutofagreementamount := Calcoutofagreementamount(Pclaimid, Psfno);
                v_step := '4.18';
                Fillprovisionsumamount(Vrequestamount, Vprovisionamount, Vlimitexcessamount, Vpatientamount, Vexemptionamount, Vnotberequestedamount,
                                                             Voutofagreementamount, Vsgkamount, Vrefusualamount, Presp);
                v_step := '4.19';
                Fillprovisionamounts(Pclaimid, Psfno, Vprovdist, Presp);
                v_step := '4.20';
            END IF;
 
            Fillprovisiondecision(Pclaimid, Psfno, Presp);
            v_step := '4.21';
        ELSE
            Presp.Resultinfo.Resultreturning := NULL;
        END IF;
        v_step := '5';
    EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Hata:'||SQLERRM||' step='||v_step);
    END;

    PROCEDURE Getprovisionresponse(Pprovisionreq        IN OUT Customer.Hltprv_Provision_Req_Typ,
                                                                 Phltbreprovision     IN OUT Customer.Hltprv_Bre_Provision_Typ,
                                                                 Phltprvrespprovision OUT Customer.Hltprv_Provision_Resp_Typ) IS
    BEGIN
        Setglobalvariables(Phltbreprovision.Claimid, Phltbreprovision.Sfno);
        DBMS_OUTPUT.PUT_LINE('set_provision_before'); 
        Setprovision(Phltbreprovision.Claimid, Phltbreprovision.Sfno, Pprovisionreq.Requestsystem, Pprovisionreq.Logid, Pprovisionreq.Origindate,
                                 Pprovisionreq.Institute, Pprovisionreq.Institutepass, Phltprvrespprovision);
         DBMS_OUTPUT.PUT_LINE('set_provision_after'); 
    END;
    PROCEDURE Gethltprvrespobj(Phltprvreqprovision  IN OUT Customer.Hltprv_Provision_Req_Typ,
                                                         Phltbreprovision     IN OUT Customer.Hltprv_Bre_Provision_Typ,
                                                         Phltprvrespprovision OUT Customer.Hltprv_Provision_Resp_Typ,
                                                         Pprocessresults      IN OUT Customer.Process_Result_Table) IS
        Hltprv_Log        Hltprv_Log_Typ;
        Hltprv_Log1       Hltprv_Log_Typ;
        v_Opus_Bre_Minsat DATE;
        v_Step VARCHAR2(100);
    BEGIN
        v_Step := '1';
        IF Phltprvreqprovision IS NULL
        THEN
            RETURN;
        END IF;

        IF Phltbreprovision IS NULL
        THEN
            RETURN;
        END IF;

/*INSERT INTO Meduladatelog
  (Claim_Id, Order_No, Medula_Date)
VALUES
  (Phltprvreqprovision.Logid,
   1,
   'Phltprvreqprovision.Meduladate:' || Phltprvreqprovision.Meduladate ||
   'Phltbreprovision.Meduladate:' || Phltbreprovision.Meduladate);
*/

        --
        IF Phltbreprovision.Minsat IS NOT NULL AND
             Phltbreprovision.Breminsat IS NOT NULL
        THEN
            IF Phltbreprovision.Breminsat <> Phltbreprovision.Minsat
            THEN
                UPDATE Koc_Hlth_Birth_Rights
                     SET Right_Date     = Phltbreprovision.Breminsat,
                             Process_Type   = 'U',
                             Username       = 'BRE',
                             Bre_Right_Date = Phltbreprovision.Breminsat
                 WHERE Contract_Id = Phltbreprovision.Policy.Contractid
                     AND Partition_No = Phltbreprovision.Policy.Partitionno;

                COMMIT;
            END IF;
        END IF;
        v_Step := '2';
        IF Phltbreprovision.Breminsat IS NOT NULL AND
             Phltbreprovision.Minsat IS NULL
        THEN
            INSERT INTO Koc_Hlth_Birth_Rights
                (Contract_Id, Partition_No, Right_Date, Username, Entry_Date, Process_Type, Bre_Right_Date)
            VALUES
                (Phltbreprovision.Policy.Contractid,
                 Phltbreprovision.Policy.Partitionno,
                 Phltbreprovision.Breminsat,
                 'BRE',
                 SYSDATE,
                 'I',
                 Phltbreprovision.Breminsat);

            COMMIT;
        END IF;

        IF Nvl(Phltbreprovision.Isbreminsat, '0') = 1 AND
             Nvl(Phltbreprovision.Breminsatdeleted, '0') = 1
        THEN
            DELETE FROM Koc_Hlth_Birth_Rights
             WHERE Contract_Id = Phltbreprovision.Policy.Contractid
                 AND Partition_No = Phltbreprovision.Policy.Partitionno;

            COMMIT;
        END IF;

        IF Nvl(Phltbreprovision.Isbreminsat, '0') = 1 AND
             Nvl(Phltbreprovision.Breminsatupdated, '0') = 1
        THEN
            UPDATE Koc_Hlth_Birth_Rights
                 SET Right_Date     = NULL,
                         Bre_Right_Date = NULL
             WHERE Contract_Id = Phltbreprovision.Policy.Contractid
                 AND Partition_No = Phltbreprovision.Policy.Partitionno;

            COMMIT;
        END IF;

        Hltprv_Log1               := Hltprv_Log_Typ();
        Hltprv_Log1.Log_Id        := Phltprvreqprovision.Logid;
        Hltprv_Log1.Servicename   := 'PROVIZYON';
        Hltprv_Log1.Processinfo   := 'BEGINRESPOBJ';
        Hltprv_Log1.Institutecode := Phltprvreqprovision.Institute.Institutecodeallz;
        Hltprv_Log1.Insuredno     := Phltbreprovision.Policy.Policyref;
        Hltprv_Log1.Insurednotype := 'POLICYNO';

        Hltprv_Log1.Content := NULL;
        Hltprv_Log1.Savelogwithpragma('YES');

        -- 20150427 --eelcik --For TSS Yek�nBazl�Islemler icin eklenmi�tir.
        --
        IF Nvl(Phltprvreqprovision.Requestsystem, '##requestsystem##') = 'ULAK'
        THEN
            Modifytssrequestmedicalinfo(Phltprvreqprovision);
        END IF;
         v_Step := '3'; 
        -- Elde sadece hastane ref no varsa a��lm�� claim_id i�erde varm�? varsa oku ve objeye ekle
        ALZ_HLTPRV_UTILS.Findandaddrefstoreflist(Phltprvreqprovision.Reference, Phltprvreqprovision.Institute.Institutecodeallz);
        v_Step := '3.1';
        --
        Getprovision(Phltprvreqprovision, Phltbreprovision);
        v_Step := '3.2'; 
        IF Pprocessresults.Count = 0
        THEN
            Getprovisionresponse(Phltprvreqprovision, Phltbreprovision, Phltprvrespprovision);
        END IF;
         v_Step := '3.3';
        Phltprvrespprovision.Writeobjecttolog(Phltprvreqprovision.Logid);

        IF Nvl(Phltprvrespprovision.Requestsystem, '##requestsystem##') NOT IN ('PORTAL', 'OPUS')
        THEN
            Phltprvrespprovision.Validateattributes;
        END IF;
   
        Hltprv_Log               := Hltprv_Log_Typ();
        Hltprv_Log.Log_Id        := Phltprvreqprovision.Logid;
        Hltprv_Log.Servicename   := 'PROVIZYON';
        Hltprv_Log.Processinfo   := 'ENDRESPOBJ';
        Hltprv_Log.Institutecode := Phltprvreqprovision.Institute.Institutecodeallz;
        Hltprv_Log.Insuredno     := Phltbreprovision.Policy.Policyref;
        Hltprv_Log.Insurednotype := 'POLICYNO';

        Hltprv_Log.Content := NULL;
        Hltprv_Log.Savelogwithpragma('YES');
    EXCEPTION
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('Hata:'||v_Step);
            ROLLBACK;

            BEGIN
                Hltprv_Log := Hltprv_Log_Typ();

                Hltprv_Log.Log_Id := Phltprvreqprovision.Logid;

                Hltprv_Log.Servicename   := 'PROVIZYON';
                Hltprv_Log.Processinfo   := 'GETHLTPRVRESPOBJ';
                Hltprv_Log.Institutecode := Phltprvreqprovision.Institute.Institutecodeallz;
                Hltprv_Log.Insuredno     := Phltbreprovision.Policy.Policyref;
                Hltprv_Log.Insurednotype := 'POLICYNO';
                Hltprv_Log.Note          := 'ERROR(' || SQLCODE || ')';
                Hltprv_Log.Content       := Dbms_Utility.Format_Error_Backtrace || Chr(10) || ' < ERR:' || SQLERRM || ' >';
                Hltprv_Log.Savelogwithpragma('YES');
            EXCEPTION
                WHEN OTHERS THEN
                    Hltprv_Log := Hltprv_Log_Typ();

                    Hltprv_Log.Log_Id := Phltprvreqprovision.Logid;

                    Hltprv_Log.Servicename   := 'PROVIZYON';
                    Hltprv_Log.Processinfo   := 'GETHLTPRVRESPOBJ';
                    Hltprv_Log.Institutecode := Phltprvreqprovision.Institute.Institutecodeallz;
                    Hltprv_Log.Insuredno     := Phltbreprovision.Policy.Policyref;
                    Hltprv_Log.Insurednotype := 'POLICYNO';
                    Hltprv_Log.Note          := 'ERROR(' || SQLCODE || ')';
                    Hltprv_Log.Content       := NULL;
                    Hltprv_Log.Savelogwithpragma('YES');
            END;

            IF SQLCODE BETWEEN - 20999 AND - 20000
            THEN
                Alz_Web_Process_Utils.Process_Result(0, 'ORACLE_EXCEPTION', 'Provizyon al�namad�:' || Substr(SQLERRM, Instr(SQLERRM, ':') + 1), NULL,
                                                                                         Pprocessresults);
            ELSE
                Alz_Web_Process_Utils.Process_Result(-1, 'ORACLE_EXCEPTION',
                                                                                         'Provizyon alma esnas�nda beklenmedik bir hata olu�tu!' || Chr(10) || 'Hata takip numaras�:<EN' ||
                                                                                            Phltprvreqprovision.Logid || '>', NULL, Pprocessresults);
            END IF;
    END Gethltprvrespobj;
    
BEGIN
  provisionReqTyp := CUSTOMER.HLTPRV_PROVISION_REQ_TYP();
  breProvisionTyp := CUSTOMER.HLTPRV_BRE_PROVISION_TYP();
  provisionRespTyp := CUSTOMER.HLTPRV_PROVISION_RESP_TYP();
  processResultTable := CUSTOMER.PROCESS_RESULT_TABLE();
  provisionReqTyp.ORIGINDATE := to_date('13/09/2019','dd/mm/yyyy');

  provisionReqTyp.INSTITUTE := CUSTOMER.HLTPRV_INSTITUTE_TYP();
  provisionReqTyp.INSTITUTE.INSTITUTECODESKRS := '538148';
  provisionReqTyp.INSTITUTE.INSTITUTECODEALLZ := 3201;
  provisionReqTyp.INSTITUTE.INSTITUTEUSERCODE := 'SKR538148';
  provisionReqTyp.INSTITUTE.OPERATIONPERSONAL := 'SKR538148';
  provisionReqTyp.INSTITUTE.INSURANCECOMPANYCODE := 'allianz';

  provisionReqTyp.INSTITUTEPASS := CUSTOMER.HLTPRV_INSTITUTEPASS_TYP();
  provisionReqTyp.INSTITUTEPASS.INSTITUTEPASS := '12345678';

  provisionReqTyp.REFERENCE := CUSTOMER.HLTPRV_REFERENCE_TBL();

  provisionReqTyp.REFERENCE.extend;
  provisionReqTyp.REFERENCE(provisionReqTyp.REFERENCE.Last) := CUSTOMER.HLTPRV_REFERENCE_TYP();
  provisionReqTyp.REFERENCE(provisionReqTyp.REFERENCE.Last).TYPE := 'SGK_TAKIP_NO';
  provisionReqTyp.REFERENCE(provisionReqTyp.REFERENCE.Last).REFERENCENO := '2Z1TQFG';
  provisionReqTyp.REFERENCE(provisionReqTyp.REFERENCE.Last).VERIFIEDFROMMEDULA := '1';

  provisionReqTyp.INSURED := CUSTOMER.HLTPRV_PINSURED_TYP();

  provisionReqTyp.INSURED.INSUREDNO := CUSTOMER.HLTPRV_INSUREDNO_TBL();

  provisionReqTyp.INSURED.INSUREDNO.extend;
  provisionReqTyp.INSURED.INSUREDNO(provisionReqTyp.INSURED.INSUREDNO.Last) := CUSTOMER.HLTPRV_INSUREDNO_TYP();
  provisionReqTyp.INSURED.INSUREDNO(provisionReqTyp.INSURED.INSUREDNO.Last).INSUREDNO := '0001171006128916-1543';
  provisionReqTyp.INSURED.INSUREDNO(provisionReqTyp.INSURED.INSUREDNO.Last).INSUREDNOTYPE := 'POLICE_NO';

  provisionReqTyp.INSURED.INSUREDNO.extend;
  provisionReqTyp.INSURED.INSUREDNO(provisionReqTyp.INSURED.INSUREDNO.Last) := CUSTOMER.HLTPRV_INSUREDNO_TYP();
  provisionReqTyp.INSURED.INSUREDNO(provisionReqTyp.INSURED.INSUREDNO.Last).INSUREDNO := '8401207';
  provisionReqTyp.INSURED.INSUREDNO(provisionReqTyp.INSURED.INSUREDNO.Last).INSUREDNOTYPE := 'SIGORTALI_KART_NO';

  provisionReqTyp.INSURED.INSUREDNO.extend;
  provisionReqTyp.INSURED.INSUREDNO(provisionReqTyp.INSURED.INSUREDNO.Last) := CUSTOMER.HLTPRV_INSUREDNO_TYP();
  provisionReqTyp.INSURED.INSUREDNO(provisionReqTyp.INSURED.INSUREDNO.Last).INSUREDNO := '19039031916';
  provisionReqTyp.INSURED.INSUREDNO(provisionReqTyp.INSURED.INSUREDNO.Last).INSUREDNOTYPE := 'TC_KIMLIK_NO';
  provisionReqTyp.INSURED.FIRSTNAME := 'G�ROL';
  provisionReqTyp.INSURED.SURNAME := 'EMRE';
  provisionReqTyp.INSURED.SEX := 'M';
  provisionReqTyp.INSURED.DATEOFBIRTH := to_date('18/09/1983','dd/mm/yyyy');
  provisionReqTyp.INSURED.RELATIONSHIP := 'FERT';
  provisionReqTyp.INSURED.MOBILEPHONE := '5304809616';
  provisionReqTyp.INSURED.FATHERNAME := 'SELATT�N';


  provisionReqTyp.DR := CUSTOMER.HLTPRV_DR_TYP();
  provisionReqTyp.DR.NAMESURNAME := 'EM�NE Y�KSEL KARS';
  provisionReqTyp.DR.TITLE := 'UZM';
  provisionReqTyp.DR.BRANCH := '1800';
  provisionReqTyp.DR.STAFFSTATUS := 'KADROLU';
  provisionReqTyp.DR.IDENTITYNO := '68266175450';
  provisionReqTyp.DR.DIPLOMAREGISTRATIONNO := '124289';
  provisionReqTyp.DR.DRTYPE := 'TT_FORMUNU_DOLDURAN';


  provisionReqTyp.MEDICALINFO := CUSTOMER.HLTPRV_MEDICALINFO_TYP();
  provisionReqTyp.MEDICALINFO.APPLICATIONTYPE := 'DIGER';
  provisionReqTyp.MEDICALINFO.DATEOFPATIENTADMISSION := to_date('31/07/2019','dd/mm/yyyy');

  provisionReqTyp.MEDICALINFO.TREATMENTTYPE := CUSTOMER.HLTPRV_TREATMENTTYPE_TYP();
  provisionReqTyp.MEDICALINFO.TREATMENTTYPE.HOSPITALIZATIONSTATUS := 'YATISSIZ';


  provisionReqTyp.MEDICALINFO.DISEASE := CUSTOMER.HLTPRV_DISEASE_TBL();

  provisionReqTyp.MEDICALINFO.DISEASE.extend;
  provisionReqTyp.MEDICALINFO.DISEASE(provisionReqTyp.MEDICALINFO.DISEASE.Last) := CUSTOMER.HLTPRV_DISEASE_TYP();
  provisionReqTyp.MEDICALINFO.DISEASE(provisionReqTyp.MEDICALINFO.DISEASE.Last).NAME := 'Lateral epikondilit';
  provisionReqTyp.MEDICALINFO.DISEASE(provisionReqTyp.MEDICALINFO.DISEASE.Last).CODE := 'M77.1';
  provisionReqTyp.MEDICALINFO.DISEASE(provisionReqTyp.MEDICALINFO.DISEASE.Last).TYPE := 'KESIN_TANI';

  provisionReqTyp.MEDICALINFO.SERVICEINFORMATION := CUSTOMER.HLTPRV_SERVICEINFOS_TBL();

  provisionReqTyp.MEDICALINFO.SERVICEINFORMATION.extend;
  provisionReqTyp.MEDICALINFO.SERVICEINFORMATION(provisionReqTyp.MEDICALINFO.SERVICEINFORMATION.Last) := CUSTOMER.HLTPRV_SERVICEINFOS_TYP();

  provisionReqTyp.MEDICALINFO.SERVICEINFORMATION(provisionReqTyp.MEDICALINFO.SERVICEINFORMATION.Last).SERVICEBASEDPROCESS := CUSTOMER.HLTPRV_SRVCBSDPRCSS_TYP();
  provisionReqTyp.MEDICALINFO.SERVICEINFORMATION(provisionReqTyp.MEDICALINFO.SERVICEINFORMATION.Last).SERVICEBASEDPROCESS.NAME := 'ESWT';

  provisionReqTyp.MEDICALINFO.SERVICEINFORMATION(provisionReqTyp.MEDICALINFO.SERVICEINFORMATION.Last).SERVICEBASEDPROCESS.PROCESSCODE := CUSTOMER.HLTPRV_PROCESSCODE_TYP();
  provisionReqTyp.MEDICALINFO.SERVICEINFORMATION(provisionReqTyp.MEDICALINFO.SERVICEINFORMATION.Last).SERVICEBASEDPROCESS.PROCESSCODE.PROCESSCODELIST := 'SUT_LISTESI';
  provisionReqTyp.MEDICALINFO.SERVICEINFORMATION(provisionReqTyp.MEDICALINFO.SERVICEINFORMATION.Last).SERVICEBASEDPROCESS.PROCESSCODE.PROCESSCODEVALUE := 'P610820';
  provisionReqTyp.MEDICALINFO.SERVICEINFORMATION(provisionReqTyp.MEDICALINFO.SERVICEINFORMATION.Last).SERVICEBASEDPROCESS.PROCESSCODE.PROCESSCODEMAIN := '92';
  provisionReqTyp.MEDICALINFO.SERVICEINFORMATION(provisionReqTyp.MEDICALINFO.SERVICEINFORMATION.Last).SERVICEBASEDPROCESS.PROCESSCODE.PROCESSCODESUB1 := '70';
  provisionReqTyp.MEDICALINFO.SERVICEINFORMATION(provisionReqTyp.MEDICALINFO.SERVICEINFORMATION.Last).SERVICEBASEDPROCESS.PROCESSCODE.PROCESSCODESUB2 := '105';
  provisionReqTyp.MEDICALINFO.SERVICEINFORMATION(provisionReqTyp.MEDICALINFO.SERVICEINFORMATION.Last).SERVICEBASEDPROCESS.PROCESSCODE.PULAKDOCTORBRANCH := '1800';


  provisionReqTyp.MEDICALINFO.SERVICEINFORMATION(provisionReqTyp.MEDICALINFO.SERVICEINFORMATION.Last).SERVICEBASEDPROCESS.AMOUNTREQUEST := -76689;
  provisionReqTyp.MEDICALINFO.SERVICEINFORMATION(provisionReqTyp.MEDICALINFO.SERVICEINFORMATION.Last).SERVICEBASEDPROCESS.AMOUNTSGK := 27;

  provisionReqTyp.MEDICALINFO.SERVICEINFORMATION(provisionReqTyp.MEDICALINFO.SERVICEINFORMATION.Last).SERVICEBASEDPROCESS.PROCESSDATETIME := CUSTOMER.HLTPRV_PROCESSDATETIME_TYP();
  provisionReqTyp.MEDICALINFO.SERVICEINFORMATION(provisionReqTyp.MEDICALINFO.SERVICEINFORMATION.Last).SERVICEBASEDPROCESS.PROCESSDATETIME.PROCESSDATE := to_date('31/07/2019','dd/mm/yyyy');

  provisionReqTyp.MEDICALINFO.SERVICEINFORMATION(provisionReqTyp.MEDICALINFO.SERVICEINFORMATION.Last).SERVICEBASEDPROCESS.ORDERNO := '56030611549';




  provisionReqTyp.MEDICALINFO.PATIENTINFOFORM := CUSTOMER.HLTPRV_PATIENTINFOFORM_TYP();
  provisionReqTyp.MEDICALINFO.PATIENTINFOFORM.COMPLAINT := 'Sol dirsek a�r�s�';
  provisionReqTyp.MEDICALINFO.PATIENTINFOFORM.COMPLAINTSTARTDATE := to_date('20/05/2019','dd/mm/yyyy');



  provisionReqTyp.MEDICALINFO.PATIENTINFOFORM.ISTRAFFICACCIDENT := 0;
  provisionReqTyp.MEDICALINFO.PATIENTINFOFORM.ISEMERGENCY := 0;
  provisionReqTyp.MEDICALINFO.PATIENTINFOFORM.TYPEOFADMISSION := 'POLIKLINIK';
  provisionReqTyp.MEDICALINFO.PATIENTINFOFORM.ISJUDICAL := 0;



  provisionReqTyp.SGKINFO := CUSTOMER.HLTPRV_SGKINFO_TYP();
  provisionReqTyp.SGKINFO.SGKUSEDSTATUS := 1;
  provisionReqTyp.SGKINFO.AMOUNTSGK := 135;

  provisionReqTyp.AMOUNTREQUEST := 135;
  provisionReqTyp.PROVISIONDATE := to_date('31/07/2019','dd/mm/yyyy');
  provisionReqTyp.REQUESTSYSTEM := 'ULAK';
  provisionReqTyp.LOGID := 132483407;
  provisionReqTyp.MEDULADATE := to_date('31/07/2019','dd/mm/yyyy');
  breProvisionTyp.LOGID := 132483407;
  breProvisionTyp.REQUESTSYSTEM := 'ULAK';
  breProvisionTyp.PROVISIONDATE := to_date('31/07/2019','dd/mm/yyyy');
  breProvisionTyp.PROVISIONSTATUSCODE := 'PP';
  breProvisionTyp.INSTITUTECODE := 3201;
  breProvisionTyp.INSTITUTEGROUPCODE := 2;
  breProvisionTyp.INSTITUTEGROUPCODE2 := 5;
  breProvisionTyp.LOCATIONCODE := 910;
  breProvisionTyp.SPECIALTYSUBJECT := '1350';
  breProvisionTyp.ISUNLISTEDPROCESS := 0;

  breProvisionTyp.POLICY := CUSTOMER.HLTPRV_BRE_POLICY_TYP();
  breProvisionTyp.POLICY.POLICYREF := '0001171006128916-1543';
  breProvisionTyp.POLICY.PARTID := 54724076;
  breProvisionTyp.POLICY.PACKAGEID := 262530;
  breProvisionTyp.POLICY.PARTITIONTYPE := 'GRUP';
  breProvisionTyp.POLICY.PARTITIONNO := 1543;
  breProvisionTyp.POLICY.GROUPCODE := 'S16673';
  breProvisionTyp.POLICY.PRODUCTID := 64;
  breProvisionTyp.POLICY.TERMSTARTDATE := to_date('24/04/2019','dd/mm/yyyy');
  breProvisionTyp.POLICY.TERMENDDATE := to_date('24/04/2020','dd/mm/yyyy');
  breProvisionTyp.POLICY.PACKAGEDATE := to_date('24/04/2019','dd/mm/yyyy');
  breProvisionTyp.POLICY.CONTRACTID := 469386319;
  breProvisionTyp.POLICY.AGENTREF := '1';
  breProvisionTyp.POLICY.COMPANY := 'AZ';
  breProvisionTyp.POLICY.OBYG := 0;

  breProvisionTyp.POLICY.COVERS := CUSTOMER.HLTPRV_BRE_COVER_TBL();

  breProvisionTyp.POLICY.COVERS.extend;
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last) := CUSTOMER.HLTPRV_BRE_COVER_TYP();
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).TYPE := 'ALT';
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).MAINCODE := 'ST685';
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).CODE := 'ST685';

  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).ISUNLIMITED := 0;

  breProvisionTyp.POLICY.COVERS.extend;
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last) := CUSTOMER.HLTPRV_BRE_COVER_TYP();
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).TYPE := 'ALT';
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).MAINCODE := 'ST353';
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).CODE := 'ST353';

  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).ISUNLIMITED := 1;

  breProvisionTyp.POLICY.COVERS.extend;
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last) := CUSTOMER.HLTPRV_BRE_COVER_TYP();
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).TYPE := 'ALT';
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).MAINCODE := 'ST503';
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).CODE := 'ST503';

  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).ISUNLIMITED := 0;

  breProvisionTyp.POLICY.COVERS.extend;
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last) := CUSTOMER.HLTPRV_BRE_COVER_TYP();
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).TYPE := 'ALT';
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).MAINCODE := 'ST504';
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).CODE := 'ST504';

  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).ISUNLIMITED := 1;

  breProvisionTyp.POLICY.COVERS.extend;
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last) := CUSTOMER.HLTPRV_BRE_COVER_TYP();
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).TYPE := 'ALT';
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).MAINCODE := 'ST507';
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).CODE := 'ST507';

  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).ISUNLIMITED := 0;

  breProvisionTyp.POLICY.COVERS.extend;
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last) := CUSTOMER.HLTPRV_BRE_COVER_TYP();
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).TYPE := 'ALT';
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).MAINCODE := 'ST526';
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).CODE := 'ST526';

  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).ISUNLIMITED := 0;

  breProvisionTyp.POLICY.COVERS.extend;
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last) := CUSTOMER.HLTPRV_BRE_COVER_TYP();
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).TYPE := 'ALT';
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).MAINCODE := 'ST534';
  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).CODE := 'ST534';

  breProvisionTyp.POLICY.COVERS(breProvisionTyp.POLICY.COVERS.Last).ISUNLIMITED := 1;

  breProvisionTyp.POLICY.SUBCOMPANYCODE := 'S16673-239';
  breProvisionTyp.POLICY.ISCOMPLEMENTARY := 1;
  breProvisionTyp.POLICY.PREVBIRTHRIGHT := 1;
  breProvisionTyp.POLICY.TPACOMPANYCODE := '045';
  breProvisionTyp.POLICY.ISAZTRCARE := 0;
  breProvisionTyp.POLICY.PACKAGETYPE := '1';

  breProvisionTyp.INSURED := CUSTOMER.HLTPRV_BRE_PARTNER_TYP();
  breProvisionTyp.INSURED.PARTID := 54724076;
  breProvisionTyp.INSURED.IDENTITYNUMBER := '19039031916';
  breProvisionTyp.INSURED.HEALTHCARDNUMBER := 8401207;
  breProvisionTyp.INSURED.NAME := 'G�ROL';
  breProvisionTyp.INSURED.SURNAME := 'EMRE';
  breProvisionTyp.INSURED.BIRTHDATE := to_date('18/09/1983','dd/mm/yyyy');
  breProvisionTyp.INSURED.SEX := 'M';
  breProvisionTyp.INSURED.FAMILYCODE := 24392;
  breProvisionTyp.INSURED.WAITINGTIME := 4;
  breProvisionTyp.INSURED.ISPREGNANT := 0;
  breProvisionTyp.INSURED.PREVPOLPREGNANTCOVEXISTS := 0;
  breProvisionTyp.INSURED.TYPEOFINTEREST := 'K';
  breProvisionTyp.INSURED.OSSWAITINGTIME := 6;
  breProvisionTyp.INSURED.FIRSTENTRYDATE := to_date('24/04/2019','dd/mm/yyyy');
  breProvisionTyp.INSURED.FIRSTENTRYDATEPOLICYHOLDER := to_date('24/04/2019','dd/mm/yyyy');
  breProvisionTyp.INSURED.OSSENTRYDATEPOLICYHOLDER := to_date('21/02/2019','dd/mm/yyyy');
  breProvisionTyp.INSURED.OSSENTRYDATE := to_date('21/02/2019','dd/mm/yyyy');

  breProvisionTyp.INSURED.REJECTS := CUSTOMER.HLTPRV_BRE_REJECT_TBL();

  breProvisionTyp.INSURED.REJECTS.extend;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last) := CUSTOMER.HLTPRV_BRE_REJECT_TYP();
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).MAINCODE := 17;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).ITEMCODE := 12;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).SUBITEMCODE := 21;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).SPECIALTYSUBJECT := '1350';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).POLICYREF := '0001171006125171';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).CLAIMID := 32284644;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).REFUSEAMOUNT := 0;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).COVERCODE := '0';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).ENTRYDATE := to_date('03/07/2017','dd/mm/yyyy');

  breProvisionTyp.INSURED.REJECTS.extend;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last) := CUSTOMER.HLTPRV_BRE_REJECT_TYP();
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).MAINCODE := 16;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).ITEMCODE := 12;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).SUBITEMCODE := 21;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).SPECIALTYSUBJECT := '1350';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).POLICYREF := '0001171006125171';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).CLAIMID := 32286049;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).REFUSEAMOUNT := 0;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).COVERCODE := '0';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).ENTRYDATE := to_date('28/07/2017','dd/mm/yyyy');

  breProvisionTyp.INSURED.REJECTS.extend;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last) := CUSTOMER.HLTPRV_BRE_REJECT_TYP();
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).MAINCODE := 13;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).ITEMCODE := 12;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).SUBITEMCODE := 14;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).SPECIALTYSUBJECT := '1350';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).POLICYREF := '0001171006126617';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).CLAIMID := 34496188;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).REFUSEAMOUNT := 0;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).COVERCODE := '0';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).ENTRYDATE := to_date('11/01/2018','dd/mm/yyyy');

  breProvisionTyp.INSURED.REJECTS.extend;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last) := CUSTOMER.HLTPRV_BRE_REJECT_TYP();
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).MAINCODE := 13;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).ITEMCODE := 12;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).SUBITEMCODE := 13;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).SPECIALTYSUBJECT := '1350';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).POLICYREF := '0001171006126617';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).CLAIMID := 34496188;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).REFUSEAMOUNT := 54;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).COVERCODE := 'ST534';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).ENTRYDATE := to_date('11/01/2018','dd/mm/yyyy');

  breProvisionTyp.INSURED.REJECTS.extend;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last) := CUSTOMER.HLTPRV_BRE_REJECT_TYP();
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).MAINCODE := 13;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).ITEMCODE := 12;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).SUBITEMCODE := 13;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).SPECIALTYSUBJECT := '1350';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).POLICYREF := '0001171006126617';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).CLAIMID := 34496188;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).REFUSEAMOUNT := 54;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).COVERCODE := 'ST534';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).ENTRYDATE := to_date('11/01/2018','dd/mm/yyyy');

  breProvisionTyp.INSURED.REJECTS.extend;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last) := CUSTOMER.HLTPRV_BRE_REJECT_TYP();
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).MAINCODE := 13;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).ITEMCODE := 12;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).SUBITEMCODE := 13;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).SPECIALTYSUBJECT := '1350';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).POLICYREF := '0001171006126617';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).CLAIMID := 34496188;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).REFUSEAMOUNT := 54;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).COVERCODE := 'ST534';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).ENTRYDATE := to_date('11/01/2018','dd/mm/yyyy');

  breProvisionTyp.INSURED.REJECTS.extend;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last) := CUSTOMER.HLTPRV_BRE_REJECT_TYP();
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).MAINCODE := 13;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).ITEMCODE := 12;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).SUBITEMCODE := 13;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).SPECIALTYSUBJECT := '1350';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).POLICYREF := '0001171006126617';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).CLAIMID := 34496188;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).REFUSEAMOUNT := 54;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).COVERCODE := 'ST534';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).ENTRYDATE := to_date('11/01/2018','dd/mm/yyyy');

  breProvisionTyp.INSURED.REJECTS.extend;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last) := CUSTOMER.HLTPRV_BRE_REJECT_TYP();
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).MAINCODE := 13;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).ITEMCODE := 12;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).SUBITEMCODE := 13;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).SPECIALTYSUBJECT := '1350';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).POLICYREF := '0001171006126617';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).CLAIMID := 34496188;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).REFUSEAMOUNT := 54;
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).COVERCODE := 'ST534';
  breProvisionTyp.INSURED.REJECTS(breProvisionTyp.INSURED.REJECTS.Last).ENTRYDATE := to_date('11/01/2018','dd/mm/yyyy');

  breProvisionTyp.INSURED.H_P_CURRENT := 0;
  breProvisionTyp.INSURED.H_P_OLD := 0;
  breProvisionTyp.INSURED.CUSTOMER_SEGMENT_TYPE := -1;

  breProvisionTyp.HEALTHPROCESSES := CUSTOMER.HLTPRV_BRE_HEALTHPROCESSES_TBL();

  breProvisionTyp.HEALTHPROCESSES.extend;
  breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last) := CUSTOMER.HLTPRV_BRE_HEALTHPROCESSES_TYP();
  breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).PROCESSCODEMAIN := 92;
  breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).PROCESSCODESUB1 := 70;
  breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).PROCESSCODESUB2 := 105;
  breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).WEBPROCEDUREGROUP := 'YATT';
  breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).AMOUNTSGK := 27;
  breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).COEFFICIENT := 42.16;

  breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).BRECOVER := CUSTOMER.HLTPRV_BRE_COVER_TYP();
  breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).BRECOVER.TYPE := '';
  breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).BRECOVER.CODE := '';
  breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).BRECOVER.ISCOVERLIMITEXCEED := 0;

  breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).ISSPECIALPRICE := 0;
  breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).PRESTATUSCODE := 'PP';
  breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).NOTMATCHPROCESS := 0;
  breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).BRENOTMATCHPROCESS := 0;

  breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).COVERS := CUSTOMER.HLTPRV_BRE_COVER_TBL();

  breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).COVERS.extend;
  breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).COVERS(breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).COVERS.Last) := CUSTOMER.HLTPRV_BRE_COVER_TYP();
  breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).COVERS(breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).COVERS.Last).TYPE := 'ALT';
  breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).COVERS(breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).COVERS.Last).CODE := 'ST534';




  breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).ORDERNO := '56030611549';



  breProvisionTyp.HEALTHPROCESSES(breProvisionTyp.HEALTHPROCESSES.Last).PROCESSDOCTORVALID := 1;

  breProvisionTyp.DISEASES := CUSTOMER.HLTPRV_BRE_DISEASES_TBL();

  breProvisionTyp.DISEASES.extend;
  breProvisionTyp.DISEASES(breProvisionTyp.DISEASES.Last) := CUSTOMER.HLTPRV_BRE_DISEASES_TYP();
  breProvisionTyp.DISEASES(breProvisionTyp.DISEASES.Last).TYPE := 'KESIN_TANI';
  breProvisionTyp.DISEASES(breProvisionTyp.DISEASES.Last).CODECGM := 'M77.1';
  breProvisionTyp.DISEASES(breProvisionTyp.DISEASES.Last).CODEALLZ := '4M771';

  breProvisionTyp.DISEASES(breProvisionTyp.DISEASES.Last).CODELVL2 := CUSTOMER.HLTPRV_BRE_DISEASESLEVEL_TYP();
  breProvisionTyp.DISEASES(breProvisionTyp.DISEASES.Last).CODELVL2.CODE := '20243';
  breProvisionTyp.DISEASES(breProvisionTyp.DISEASES.Last).CODELVL2.ISORG := 0;

  breProvisionTyp.DISEASES(breProvisionTyp.DISEASES.Last).CODELVL3 := CUSTOMER.HLTPRV_BRE_DISEASESLEVEL_TYP();
  breProvisionTyp.DISEASES(breProvisionTyp.DISEASES.Last).CODELVL3.CODE := '30M77';
  breProvisionTyp.DISEASES(breProvisionTyp.DISEASES.Last).CODELVL3.ISORG := 0;

  breProvisionTyp.DISEASES(breProvisionTyp.DISEASES.Last).CODELVL4 := CUSTOMER.HLTPRV_BRE_DISEASESLEVEL_TYP();
  breProvisionTyp.DISEASES(breProvisionTyp.DISEASES.Last).CODELVL4.CODE := '4M771';
  breProvisionTyp.DISEASES(breProvisionTyp.DISEASES.Last).CODELVL4.CODEGROUP := '101024';
  breProvisionTyp.DISEASES(breProvisionTyp.DISEASES.Last).CODELVL4.ISORG := 1;
  breProvisionTyp.DISEASES(breProvisionTyp.DISEASES.Last).CODELVL4.IS_DISEASE_EMERGENY := 0;


  breProvisionTyp.INSTITUTELIMIT := CUSTOMER.HLTPRV_BRE_INSTCONSUMEDLMT_TYP();
  breProvisionTyp.INSTITUTELIMIT.DAYTOTALQUANTITY := 0;
  breProvisionTyp.INSTITUTELIMIT.MONTHTOTALQUANTITY := 0;
  breProvisionTyp.INSTITUTELIMIT.DAYTOTALAMOUNT := 0;
  breProvisionTyp.INSTITUTELIMIT.MONTHTOTALAMOUNT := 0;

  breProvisionTyp.CURRENTLOCATIONLIMIT := CUSTOMER.HLTPRV_BRE_INSTCONSUMEDLMT_TYP();
  breProvisionTyp.CURRENTLOCATIONLIMIT.DAYTOTALQUANTITY := 0;
  breProvisionTyp.CURRENTLOCATIONLIMIT.MONTHTOTALQUANTITY := 0;
  breProvisionTyp.CURRENTLOCATIONLIMIT.DAYTOTALAMOUNT := 0;
  breProvisionTyp.CURRENTLOCATIONLIMIT.MONTHTOTALAMOUNT := 0;

  breProvisionTyp.CURRENTLOCSPECLIMIT := CUSTOMER.HLTPRV_BRE_INSTCONSUMEDLMT_TYP();
  breProvisionTyp.CURRENTLOCSPECLIMIT.DAYTOTALQUANTITY := 0;
  breProvisionTyp.CURRENTLOCSPECLIMIT.MONTHTOTALQUANTITY := 0;
  breProvisionTyp.CURRENTLOCSPECLIMIT.DAYTOTALAMOUNT := 0;
  breProvisionTyp.CURRENTLOCSPECLIMIT.MONTHTOTALAMOUNT := 0;
  breProvisionTyp.REQUESTAMOUNT := 135;
  breProvisionTyp.INDEMNITYAMOUNT := 0;

  breProvisionTyp.COVERCATEGORYGROUP := 1;
  breProvisionTyp.PREGNANTRESTRICTION := 0;
  breProvisionTyp.ODNPREGNANTRESTRICTION := 0;





  breProvisionTyp.COMPLAINTSTARTDATE := to_date('20/05/2019','dd/mm/yyyy');

  breProvisionTyp.DRCOMPLETENAME := 'EMINE YUKSEL KARS';
  breProvisionTyp.ISSGKINCLUDE := 1;

  breProvisionTyp.DAILY_CLAIMS_COUNT := 0;
  breProvisionTyp.MONTHLY_CLAIMS_COUNT := 0;
  breProvisionTyp.YEARLY_CLAIMS_COUNT := 0;

  breProvisionTyp.INSTITUTE_NETWORKS := CUSTOMER.HLTPRV_INST_NETWORK_TBL();

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 1;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 2;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 3;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 4;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 5;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 7;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 8;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 9;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 12;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 13;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 14;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 15;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 16;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 17;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 18;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 19;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 20;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 21;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 22;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 23;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 24;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 25;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 26;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 27;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 28;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 29;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 30;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 31;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 32;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 33;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 34;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 35;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 36;

  breProvisionTyp.INSTITUTE_NETWORKS.extend;
  breProvisionTyp.INSTITUTE_NETWORKS(breProvisionTyp.INSTITUTE_NETWORKS.Last) := 37;
  breProvisionTyp.MEDULADATE := to_date('31/07/2019','dd/mm/yyyy');
  breProvisionTyp.SGKREFNO := '2Z1TQFG';


  -- call provision
  --customer.WEB_HLTPRV_UTILS.
  Gethltprvrespobj(provisionReqTyp,breProvisionTyp,provisionRespTyp,processResultTable);
  -- check errors
  if processResultTable is not null then
    if processResultTable.count > 0 then
      raise_application_error(-20210, 'Hata Numarasi : '|| processResultTable(1).error_no||' - Hata : '||processResultTable(1).reason||' - Action : '||processResultTable(1).action);
      return;
    end if;
  end if;

  -- print logid
  dbms_output.put_line('log id=' || provisionRespTyp.logid);

  -- print reference numbers
  if provisionRespTyp.reference is not null then
    if provisionRespTyp.reference.count > 0 then
      dbms_output.put_line(provisionRespTyp.reference(1).type || ' = ' || provisionRespTyp.reference(1).referenceno);
      return;
    end if;
  end if;

END;



/*SELECT P1.Process_Code_Main,
                         P1.Process_Code_Sub1,
                         P1.Process_Code_Sub2,
                         P1.Indemnity_Amount,
                         P1.Inst_Indemnity_Amount,
                         P1.Process_Count,
                         P1.Status_Code,
                         P1.Explanation,
                         P1.Entrance_Date,
                         P1.Drg_Code,
                         P1.Doctor_Code,
                         P1.Doctor_Status,
                         P1.Sgk_Amount,
                         P1.Order_No,
                         P1.Vat_Rate,
                         P1.Right_Left,
                         P1.Proc_Type,
                         P1.Physiotherapy_Session,
                         P1.Diagnosis_Id,
                         P1.Surgery_Id,
                         P2.Provision_Date,
                         P2.Group_Code,
                         P2.Status_Code               Claim_Status,
                         P1.Group_No,
                         P1.Seq_No,
                         P1.Req_Process_Name,
                         P1.Req_Process_Code,
                         P1.Req_Process_List_Type,
                         P1.Related_Process,
                         P1.Related_Process_List_Type,
                         P3.Cover_Code,
                         P3.Add_Order_No,
                         P3.Location_Code,
                         P3.Swift_Code,
                         P3.Provision_Total,
                         P3.Request_Amount,
                         P3.Refusal_Amount,
                         P3.Exemption_Amount,
                         P3.Exemption_Rate,
                         P3.Sgk_Amount                Cover_Sgk_Amount,
                         P3.Add_Proc_Amount,
                         P2.Request_System
                FROM Koc_Clm_Hlth_Proc_Detail P1,
                         Koc_Clm_Hlth_Detail      P2,
                         Koc_Clm_Hlth_Provisions  P3
             WHERE P1.Claim_Id = 41907786
                 AND P1.Sf_No = 1
                 AND P1.Add_Order_No = 1
                 AND P1.Claim_Id = P2.Claim_Id
                 AND P1.Sf_No = P2.Sf_No
                 AND P1.Add_Order_No = P2.Add_Order_No
                 AND P3.Claim_Id = P1.Claim_Id
                 AND P3.Sf_No = P1.Sf_No
                 AND P3.Add_Order_No = P1.Add_Order_No
                 AND P3.Location_Code = P1.Location_Code
                 AND P3.Cover_Code = P1.Cover_Code;

--41907775
select * from clm_subfiles where ext_reference='58112421'*/
