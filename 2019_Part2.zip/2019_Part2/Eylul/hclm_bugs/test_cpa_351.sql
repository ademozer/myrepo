SELECT DISTINCT c1.partition_no,
                nvl(cpe.identity_no, c1.part_id_identity_no) part_id_identity_no,
                nvl(cp.first_name || ' ' || cp.name, c1.ins_name) ins_name,
                c1.claim_id_ext_reference,
                c1.comm_no,
                (CASE
                  WHEN c2.cpa_status = 'ET' THEN
                   0
                  ELSE
                   1
                END) cpa_status_order,
                c1.claim_id,
                c1.contract_id,
                c1.institute_code,
                c2.group_code,
                ii.Policy_Ref,
                ii.sub_company_code,
                ii.sub_company_name,
                ii.group_name,
                c2.request_system,
                ii.product_id,
                c1.comm_doc_type,
                c1.statement_no,
                ii.pack_name,
                nvl(c2.affluent_flag, 0) affluent_flag,
                c2.part_id,
                ALZ_HLTH_CPA.Isinsuredvip_New(c2.part_id, 'ADEMO') vip_flag,
                c2.package_id,
                c2.package_date
  FROM KOC_CLM_HLTH_COMM         c1,
       KOC_CLM_HLTH_DETAIL       c2,
       KOC_V_HEALTH_INSURED_INFO ii,
       koc_cp_partners_ext       cpe,
       cp_partners               cp
 WHERE 1 = 1
   AND nvl(c1.partition_no, 0) <> 0
   AND nvl(c1.claim_id, 0) <> 0
   AND cpe.part_id = cp.part_id
   AND c1.comm_no = c2.communication_no
   AND c1.claim_id = c2.claim_id
   AND c2.part_id = cp.part_id
   AND c2.sf_no = 1
   AND c1.contract_id = ii.contract_id
   AND c1.partition_no = ii.partition_no
   AND ii.partner_id = c2.part_id
   AND ii.package_id = c2.package_id
   AND ii.package_date = c2.package_date
   AND c1.validity_start_date =
       (SELECT MAX(co.validity_start_date)
          FROM KOC_CLM_HLTH_COMM co
         WHERE co.comm_no = c1.comm_no)
   --AND ((1 = 1) or :p_status is null)
   AND nvl(c2.cpa_status, 'X') not in
       ('TAH', 'R', 'C', 'I', 'OB', 'RL', 'TAH_BT')
   /*AND nvl(c2.is_automated, 0) = :p_is_automated
   AND ((1 = 1) or :p_hold_user is null)
   AND ((1 = 1) or :p_group_code is null)
   AND ((1 = 1) or :p_sub_company_code is null)
   AND ((1 = 1) or :p_part_id_identity_no is null)
   AND ((1 = 1) or :p_policy_ref is null)
   AND ((1 = 1) or :p_partition_no is null)*/
   AND c2.ext_reference = '58648657'
   /*AND ((1 = 1) or :p_comm_no is null)
   AND ((1 = 1) or :p_comm_date_start is null)
   AND ((1 = 1) or :p_comm_date_end is null)
   AND ((1 = 1) or :p_realization_date is null)
   AND ((1 = 1) or :p_partaj is null)
   AND ((1 = 1) or :p_agen_int_id is null)
   AND ((1 = 1) or :p_region is null)
   AND c1.taz_user = :p_taz_user
   AND ((1 = 1) or :p_card_no is null)
   AND ((1 = 1) or :p_request_system is null)
   AND ((1 = 1) or :p_product_type is null)
   AND ((1 = 1) or :p_statement_no is null)
   AND ((1 = 1) or :p_approval_status is null or :p_approval_date is null)*/
 ORDER BY nvl(c2.affluent_flag, 0) desc,
          vip_flag desc,
          cpa_status_order,
          c1.comm_no

--select * from koc_clm_hlth_detail@opusdev where ext_reference='58648657'
