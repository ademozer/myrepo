DECLARE 
   v_desc_int_id NUMBER;
BEGIN
  
select max(int_id) + 1
INTO v_desc_int_id
from  DESCRIPTIONS;

insert into DESCRIPTIONS (INT_ID, JOIN_TABLE)
values (v_desc_int_id, 'KOC_CP_HEALTH_LOOK_UP');

insert into cur_translations (SULA_ORA_NLS_CODE, DESC_INT_ID, SHORT_CODE, LONG_NAME, COMMENTS)
values ('TR', v_desc_int_id, 'PHRM_CLMID', '0-claim_id_ext_reference,1-claim_id_change_claim_id', null);

insert into cur_translations (SULA_ORA_NLS_CODE, DESC_INT_ID, SHORT_CODE, LONG_NAME, COMMENTS)
values ('US', v_desc_int_id, 'PHRM_CLMID', '0-claim_id_ext_reference,1-claim_id_change_claim_id', null);

insert into koc_cp_health_look_up (LOOK_UP_CODE, PARAMETER, DESC_INT_ID, VALIDITY_START, VALIDITY_END, USERID, ENTRY_DATE, DETAIL_EXPLANATION)
values ('PHRM_CLMID', '0', v_desc_int_id, sysdate, null, 'ADEMO', null, '');

COMMIT;

END;
/
