SELECT  n.note_id,
        n.text explanation, 
        n.creation_date,
        h.note_type,
        h.medicine_note_type,
        decode(NVL (h.is_valid, 0),1,'Ge�erli','Ge�ersiz') durum
        FROM koc_notes n,
             koc_notes_authorization h
          WHERE h.ins_obj_uid = '485359680'--TO_CHAR (:parameter.contract_id)
               AND h.sub_level1 = '6118'--TO_CHAR (:parameter.oar_no)
               AND h.note_id = n.note_id
               AND (h.TO_DATE IS NULL or to_date>=trunc(sysdate))
              AND ( ( h.note_type = 'ILAC' and NVL(h.medicine_note_type,'STD_ILAC') = 'STD_ILAC' and exists (select 1 from koc_cc_medicines m where barcode = '8699676950164' and nvl(m.is_special_medicine3,0) = 0 and validity_date = (select max(validity_date) from koc_cc_medicines mm where m.barcode = mm.barcode)))  OR 
                    ( h.note_type = 'ILAC' and NVL(h.medicine_note_type,'STD_ILAC') = 'SPC_ILAC' and exists (select 1 from koc_cc_medicines m where barcode = '8699676950164' and nvl(m.is_special_medicine3,0) = 1 and validity_date = (select max(validity_date) from koc_cc_medicines mm where m.barcode = mm.barcode)))  
                   );
                   
                  -- select * from clm_pol_oar where claim_id= 41908015
                 
    select * from koc_cc_medicines where  validity_date>trunc(sysdate)--barcode = '8699676950164' --for update
                select *  from koc_notes_authorization where note_id='36006444' for update
                
                
                select * from koc_cc_medicines m where barcode = '8699676950164' and nvl(m.is_special_medicine3,0) = 0 and validity_date = (select max(validity_date) from koc_cc_medicines mm where m.barcode = mm.barcode))
