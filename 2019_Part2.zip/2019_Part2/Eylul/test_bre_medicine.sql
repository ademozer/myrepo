DECLARE
  --418780159-94-42859325
  p_Claim_Id       NUMBER := 42877810;--42761147;
  p_Contract_Id    NUMBER := 448602486;--485359680;
  p_Partition_No  NUMBER  := 1;--6118;
  p_Provision_Date DATE   := SYSDATE;
  p_Branch_Code    NUMBER := 1530;
  v_Bre_Cover_Code VARCHAR2(100);
  Io_Cursor        SYS_REFCURSOR;
  p_Barcodeinfos   Customer.Hltprv_Bre_Medicine_Tbl;
  v_Last           NUMBER;
  p_Cover_Code     VARCHAR2(100) := 'S355';
  
  CURSOR Medbarcodedet(p_cover_code varchar2, p_barcode IN VARCHAR2)
      IS
         SELECT Barcode, Price, Unit
           FROM Rep_Clm_Medicine_Indem_Det a
          WHERE a.Claim_Id = p_Claim_Id and a.cover_code = p_cover_code
            --AND a.barcode = p_barcode
         UNION
         SELECT Barcode, Price, Unit
           FROM Koc_Clm_Medicine_Indem_Det a
          WHERE a.Claim_Id = p_Claim_Id
            AND a.cover_code = p_cover_code;
           -- AND a.barcode = p_barcode;
   PROCEDURE Callbremedicineservice (
      p_Claim_Id             IN     NUMBER,
      p_Contract_Id          IN     NUMBER,
      p_Barcodeinfos         IN     Customer.Hltprv_Bre_Medicine_Tbl,
      p_Partition_No         IN     NUMBER,
      p_Provision_Date       IN     DATE,
      p_Speciality_Subject   IN     VARCHAR2,
      p_Medicine_Flow        IN     VARCHAR2,
      p_Prescription         IN     NUMBER,
      p_Bre_Cover_Code          OUT VARCHAR2,
      Io_Cursor                 OUT SYS_REFCURSOR)
   IS
      v_Request           VARCHAR2 (32767);
      Request             VARCHAR2 (32767);
      Response            VARCHAR2 (32767);
      Http_Req            UTL_HTTP.Req;
      Http_Resp           UTL_HTTP.Resp;
      v_Rspmsg            VARCHAR2 (32767);
      v_Resp_Xml          XMLTYPE;
      v_String_Request    VARCHAR2 (512);
      v_Line              VARCHAR2 (128);

      v_Substring_Msg     VARCHAR2 (512);

      v_Raw_Data          RAW (512);
      v_Clob_Response     CLOB;
      v_Result_Xml_Node   VARCHAR2 (128);
      v_Namespace_Soap    VARCHAR2 (128)
         := 'xmlns="http://schemas.xmlsoap.org/soap/envelope/"';
      v_Buffer_Size       NUMBER (10) := 512;
      v_Med_Size          NUMBER := 0;
      v_Cover_Size        NUMBER := 0;
      Hltprv_Log          Hltprv_Log_Typ := Hltprv_Log_Typ ();
   BEGIN
      v_Request :=
            v_Request
         || '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="http://service.ws.provision.health.allianz.com/">';
      v_Request := v_Request || '<soapenv:Header/>';
      v_Request := v_Request || '<soapenv:Body>';
      v_Request := v_Request || '<ser:getHltMedBreObj><arg0>';
      v_Request := v_Request || '<claimid>' || p_Claim_Id || '</claimid>';
      v_Request :=
         v_Request || '<contractid>' || p_Contract_Id || '</contractid>';
      v_Request :=
            v_Request
         || '<medicineFlow>'
         || p_Medicine_Flow
         || '</medicineFlow>';
      DBMS_OUTPUT.PUT_LINE(v_Request);
      IF p_Barcodeinfos IS NOT NULL
      THEN
         v_Med_Size := p_Barcodeinfos.FIRST;

         WHILE v_Med_Size IS NOT NULL
         LOOP
            v_Request := v_Request || '<medicineList>';
            v_Request :=
                  v_Request
               || '<barcode>'
               || p_Barcodeinfos (v_Med_Size).Barcode
               || '</barcode>';
            v_Request :=
                  v_Request
               || '<price>'
               || p_Barcodeinfos (v_Med_Size).Price
               || '</price>';
            v_Request :=
                  v_Request
               || '<unit>'
               || p_Barcodeinfos (v_Med_Size).Unit
               || '</unit>';

            IF p_Barcodeinfos (v_Med_Size).Covers IS NOT NULL
            THEN
               v_Cover_Size := p_Barcodeinfos (v_Med_Size).Covers.FIRST;

               WHILE v_Cover_Size IS NOT NULL
               LOOP
                  v_Request :=
                        v_Request
                     || '<coverCode>'
                     || p_Barcodeinfos (v_Med_Size).Covers (v_Cover_Size).Code
                     || '</coverCode>';

                  v_Cover_Size :=
                     p_Barcodeinfos (v_Med_Size).Covers.NEXT (v_Cover_Size);
               END LOOP;
            END IF;

            v_Request := v_Request || '</medicineList>';

            v_Med_Size := p_Barcodeinfos.NEXT (v_Med_Size);
         END LOOP;
      END IF;

      v_Request :=
         v_Request || '<partitionno>' || p_Partition_No || '</partitionno>';

      v_Request :=
         v_Request || '<prescription>' || p_Prescription || '</prescription>';

      v_Request :=
            v_Request
         || '<provisiondate>'
         || TO_CHAR (p_Provision_Date, 'yyyy-mm-dd')
         || 'T'
         || TO_CHAR (p_Provision_Date, 'hh24:mi:ss')
         || '</provisiondate>';
      v_Request :=
            v_Request
         || '<specialitySubject>'
         || p_Speciality_Subject
         || '</specialitySubject>';

      v_Request := v_Request || '</arg0></ser:getHltMedBreObj>';
      v_Request := v_Request || '</soapenv:Body> ';
      v_Request := v_Request || '</soapenv:Envelope> ';

      Hltprv_Log.Log_Id := 0;

      Hltprv_Log.Servicename := 'PHARMACY';
      Hltprv_Log.Processinfo := 'CALLBREMED';
      Hltprv_Log.Content := TO_CLOB (v_Request);

      Hltprv_Log.Savelogwithpragma;
      DBMS_OUTPUT.PUT_LINE('Log_Id='||Hltprv_Log.Log_Id);
      UTL_HTTP.Set_Transfer_Timeout (300);              -- Timeout suresi 5 dk
      ---  Http_Req := Utl_Http.Begin_Request('http://10.70.2.63:17101/healthProvisionWS/BreServicesService?WSDL', 'POST', Utl_Http.Http_Version_1_1);
      Http_Req :=
         UTL_HTTP.Begin_Request (
            Get_Url_Link (
               'http://eprovesb.allianz.com.tr:12000/healthProvisionWS/ProxyServices/BreServices?WSDL'),
            'POST',
            UTL_HTTP.Http_Version_1_1);
      UTL_HTTP.Set_Header (Http_Req,
                           'Content-Type',
                           'text/xml; charset=UTF-8');
      UTL_HTTP.Set_Header (Http_Req, 'Content-Length', LENGTH (v_Request));
      UTL_HTTP.Set_Header (Http_Req, 'SOAPAction', '""');
      UTL_HTTP.Write_Text (Http_Req, v_Request);
      Http_Resp := UTL_HTTP.Get_Response (Http_Req);

      BEGIN
        <<response_Loop>>
         LOOP
            UTL_HTTP.Read_Raw (Http_Resp, v_Raw_Data, v_Buffer_Size);
            v_Clob_Response :=
               v_Clob_Response || UTL_RAW.Cast_To_Varchar2 (v_Raw_Data);
         END LOOP Response_Loop;
      EXCEPTION
         WHEN UTL_HTTP.End_Of_Body
         THEN
            UTL_HTTP.End_Response (Http_Resp);
      END;

      IF (Http_Resp.Status_Code <> 200)
      THEN
         Raise_Application_Error (
            -20110,
            'Servis hatasi!Http statu kodu : ' || Http_Resp.Status_Code);
      END IF;

      Hltprv_Log.Log_Id := 0;

      Hltprv_Log.Servicename := 'PHARMACY';
      Hltprv_Log.Processinfo := 'CALLBREMEDRESP';
      Hltprv_Log.Content := v_Clob_Response;

      Hltprv_Log.Savelogwithpragma;
      DBMS_OUTPUT.PUT_LINE('Log_Id='||Hltprv_Log.Log_Id);
      -- Create XML type from response text
      v_Clob_Response :=
         REPLACE (
            REPLACE (
               REPLACE (
                  REPLACE (
                     REPLACE (
                        REPLACE (
                           REPLACE (
                              REPLACE (
                                 REPLACE (
                                    REPLACE (
                                       REPLACE (v_Clob_Response, 'ı', 'i'),
                                       '�Y',
                                       's'),
                                    'ç',
                                    '�'),
                                 '�Y',
                                 'g'),
                              'ü',
                              '�'),
                           'ö',
                           '�'),
                        '�?',
                        'S'),
                     '�?',
                     '�'),
                  '�?',
                  'G'),
               '�?',
               '�'),
            '�?',
            '�');
      v_Resp_Xml := Xmltype.Createxml (v_Clob_Response);

      SELECT EXTRACT (v_Resp_Xml, 'Envelope/Body/node()', v_Namespace_Soap)
        INTO v_Resp_Xml
        FROM DUAL;

      OPEN Io_Cursor FOR
         SELECT EXTRACTVALUE (COLUMN_VALUE, '//barcode') AS Barcode,
                EXTRACTVALUE (COLUMN_VALUE, '//maincode') AS Maincode,
                EXTRACTVALUE (COLUMN_VALUE, '//itemcode') AS Itemcode,
                EXTRACTVALUE (COLUMN_VALUE, '//subitemcode') AS Subitemcode,
                EXTRACTVALUE (COLUMN_VALUE, '//screenmessage')
                   AS Screenmessage,
                EXTRACTVALUE (COLUMN_VALUE, '//message') AS Printmessage
           FROM TABLE (
                   XMLSEQUENCE (
                      v_Resp_Xml.EXTRACT (
                         'n2:getHltMedBreObjResponse/return/rejectdecisions/breDecisionType',
                         'xmlns:n2="http://service.ws.provision.health.allianz.com/"'))) F1;

      BEGIN
         SELECT EXTRACTVALUE (COLUMN_VALUE, '//covercode') AS Covercode
           INTO p_Bre_Cover_Code
           FROM TABLE (
                   XMLSEQUENCE (
                      v_Resp_Xml.EXTRACT (
                         'n2:getHltMedBreObjResponse/return/teminatdecisions/breDecisionType',
                         'xmlns:n2="http://service.ws.provision.health.allianz.com/"'))) F1;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            p_Bre_Cover_Code := NULL;
      END;
   EXCEPTION
      WHEN UTL_HTTP.Too_Many_Requests
      THEN
         UTL_HTTP.End_Response (Http_Resp);
         Raise_Application_Error (-20110, ' Too Many Connection');
      WHEN UTL_HTTP.Request_Failed
      THEN
         UTL_HTTP.End_Response (Http_Resp);
         Raise_Application_Error (-20110, ' Request Failed');
      WHEN OTHERS
      THEN
         Raise_Application_Error (-20110, SQLERRM);
   END Callbremedicineservice;
 
  procedure print_data(cur_ IN SYS_REFCURSOR) IS 
    v_data_msg CLOB;
    v_keys_data VARCHAR2(4000);
    v_ndx number := 0;
    BEGIN
    v_data_msg := '[';
  FOR rec_1 IN (SELECT ROWNUM ROW_NO, 
                                      t1.column_value.getStringVal() ROW_DATA
                                 FROM (SELECT * FROM TABLE (XMLSEQUENCE(cur_))) t1)    
                 LOOP                   
                     IF rec_1.ROW_NO>1 THEN
                         v_data_msg := v_data_msg || ',';
                     END IF;
                     v_data_msg := v_data_msg || '{';
                     v_ndx := 0;
                     FOR rec_2 IN (SELECT EXTRACTVALUE (t.COLUMN_VALUE, '/*') AS NODE_VALUE,
                                                        t.COLUMN_VALUE.getrootelement () AS NODE_NAME
                                     FROM TABLE (XMLSEQUENCE (EXTRACT(EXTRACT(XMLTYPE(rec_1.ROW_DATA), '//*'), '/ROW/*'))) t)
                     LOOP
                        IF v_ndx>0 THEN
                           v_data_msg := v_data_msg || ',';
               IF rec_1.ROW_NO = 1 THEN
                v_keys_data := v_keys_data || ',';
               END IF;
                        END IF;
            IF rec_1.ROW_NO = 1 THEN
              v_keys_data := v_keys_data || LOWER(rec_2.NODE_NAME);
            END IF;
                        v_data_msg := v_data_msg || '"' || LOWER(rec_2.NODE_NAME) || '":"' || TRIM(rec_2.Node_Value) || '"';
                        v_ndx := v_ndx + 1;                         
                     END LOOP;
                     v_data_msg := v_data_msg || '}';
                 END LOOP;     
    --DBMS_OUTPUT.PUT_LINE(v_keys_data);
    v_data_msg := v_data_msg || ']';
    DBMS_OUTPUT.PUT_LINE(v_data_msg);
  END print_data;
BEGIN
  
  p_Barcodeinfos := Customer.Hltprv_Bre_Medicine_Tbl ();

  FOR Recbarcodedet IN Medbarcodedet(p_Cover_Code, '8699625960428')
  LOOP
    p_Barcodeinfos.EXTEND;
    v_Last := p_Barcodeinfos.LAST;
    p_Barcodeinfos (v_Last) := Customer.Hltprv_Bre_Medicine_Typ ();
    p_Barcodeinfos (v_Last).Barcode := Recbarcodedet.Barcode;
    p_Barcodeinfos (v_Last).Price := Recbarcodedet.Price;
    p_Barcodeinfos (v_Last).Unit := Recbarcodedet.Unit;
  END LOOP;

   
  DBMS_OUTPUT.PUT_LINE('bre_start');
  --koc_clm_hlth_pharmacy_utils.
  Callbremedicineservice (p_Claim_Id,
                                                      p_Contract_Id,
                                                      p_Barcodeinfos,
                                                      p_Partition_No,
                                                      p_Provision_Date,
                                                      p_Branch_Code,
                                                      'ILAC_KONTROL',
                                                      NULL,
                                                      v_Bre_Cover_Code,
                                                      Io_Cursor);
    DBMS_OUTPUT.PUT_LINE('bre_stop');                                  
  DBMS_OUTPUT.PUT_LINE('Bre_Cover_Code='||v_Bre_Cover_Code);
  print_data(Io_Cursor);

END;                                      
