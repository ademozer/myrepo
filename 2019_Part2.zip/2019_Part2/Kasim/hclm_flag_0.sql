insert into alz_hclm_institute_info (INSTITUTE_CODE, HCLM_USAGE)
values (0, 1);

COMMIT;



