select * from web_sec_system_users where user_name like 'WMARSH%_5072' AND END_DATE IS NULL
and user_name not like '%BORUSAN%'
and user_name not like '%H2Q%'
select * from web_sec_system_users where user_name like 'WYAKUT%_5069' AND END_DATE IS NULL
select * from web_sec_system_users where user_name like 'WCANSIG%5065' AND END_DATE IS NULL
select * from web_sec_system_users where user_name like 'WOYAK%5147' AND END_DATE IS NULL
5072 (HEPS�) --34 adet
5069 (HEPS�) --1 adet
5065 (HEPS�) --8 adet 1 tanesinde �ifre var
5147 (HEPS�) --2 adet
