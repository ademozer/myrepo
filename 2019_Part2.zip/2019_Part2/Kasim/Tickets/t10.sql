select * from koc_clm_hlth_detail where ext_reference='59363763';
select * from hst_cc_web_inst_doctor where doctor_code=311453;

select * from alz_hltprv_process_convert_map where institute_code='6498'

select * from customer.alz_duplicate_provision where ext_reference='59363763';

select * from alz_hltprv_log where log_id = 145353155
--311453

select * from koc_clm_suppliers_ext where institute_code='6498' for update --'576585'
