select * from clm_subfiles where ext_reference='58979193'--'58941517';
select * from alz_hclm_version_info where claim_id=43022215--42973837;

select * from alz_hltprv_log where log_id = 147978529;
select * from koc_mv_skrm_suppliers where institute_skrs_code='576585';
select * from koc_clm_suppliers_ext where institute_code='6498' for update
select * from alz_hclm_institute_info where institute_code='6498' for update   --148443078

--2600
select * from alz_hltprv_process_convert_map where institute_code='6498';
select * from Alz_Branch_Code_Cgm_Rel where branchcodecgm=2600;

--148444334 Provizyon validasyon:Hizmet kurumda tan�ms�z Muayene-G�nd�z (Normal �� Veya Tatil G�nlerinde 
--148444370: Fiyat hesaplamas� i�in uygun olmayan de�er(ler) ile kar��la��ld�!
