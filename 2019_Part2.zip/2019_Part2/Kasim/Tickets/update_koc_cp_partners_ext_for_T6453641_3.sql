update koc_cp_partners_ext 
   set tax_office = 'KAVAKLIDERE',
       tax_number = '9820041182'
 where part_id = 11109944;
 
update koc_cp_partners_ext 
   set tax_office = 'ESK��EH�R',
       tax_number = '6850498355'
 where part_id = 14634934;
 
update koc_cp_partners_ext 
   set tax_office = 'KAVAKLIDERE',
       tax_number = '3560049107'
 where part_id = 11563445;
 
update koc_cp_partners_ext 
   set tax_office = 'ERENK�Y',
       tax_number = '1460130596'
 where part_id = 7549417;
 
 update koc_cp_partners_ext 
   set tax_office = '���L�',
       tax_number = '4840492004'
 where part_id = 34965137;
 
 COMMIT;
 
 
 
