select * from customer.alz_duplicate_provision where ext_reference='59544605';
select * from alz_hltprv_log where log_id=142177966--148734270;


select * from customer.alz_duplicate_provision where ext_reference='59099511';

select * from Koc_Clm_Hlth_Prov_Statemnt
--   Set status_code = 'P'
 Where claim_id=43095562;
 
 select * from Koc_Clm_Hlth_Detail
--   Set status_code = 'P'
 Where claim_id=43095562;
 
 
 select * from alz_hltprv_log where log_id=148728534--148861073--148728534
  delete alz_hltprv_log where log_id=148728534 and order_no>4
 
 
 select * from clm_subfiles where ext_reference='59467386';
 select * from clm_pol_oar where claim_id=43650308;
 select * from alz_hclm_version_info where claim_id= 43663951;
  select * from clm_subfiles where claim_id=43650308
 43663951 --y   59477830
41287916
43246850 -- x   59152325
43650308 -- y   59467386
41631400
41527266
41910966
41813988
42212618
42432520
select * from alz_hclm_institute_info where institute_code=6278 for update
 
 select * from koc_clm_hlth_indem_dec where claim_id=43178115;
 select * from clm_pol_oar where contract_id=469381190 and oar_no=2030
 
  select * from clm_subfiles where ext_reference='59099511';
  select * from koc_clm_hlth_detail  where ext_reference='59099511';
  
  select * from alz_hltprv_log where log_id=145749399;
  
  select * from koc_clm_suppliers_ext where institute_code=6278 for update;
  
  select * from koc_clm_hlth_detail where ext_reference = ;
  --koc_clm_hlth_trnx
  
  select * from Koc_v_Hlth_Insured_Info_Indem where contract_id = 459580917 and partition_no=1
  
  select * from Koc_Cc_Hlth_Tda_Inst_Val where institute_code=6498 and discount_group_code='DR��'
  
 select * from ocp_policy_bases where policy_ref='0001071003393888'
 select * from koc_ocp_pol_contracts_ext where contract_id = 459580917 
 select * from 
 select * from koc_clm_close_to_indemnity where contract_id = 459580917 and partition_no = 1
