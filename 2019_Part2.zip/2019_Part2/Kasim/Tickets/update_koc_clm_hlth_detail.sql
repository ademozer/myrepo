update koc_clm_hlth_detail
   set status_code = 'C'
 where ext_reference ='58855751';

COMMIT;
