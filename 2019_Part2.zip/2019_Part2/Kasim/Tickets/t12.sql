select * from clm_Subfiles where ext_reference in ('58363217','59363217');
--43516295
select * from koc_clm_hlth_reject_loss where claim_id in(42235913,
43516295)
select * from alz_hclm_Version_info where claim_id=43455642--42235913
select * from koc_clm_hlth_indem_dec where claim_id=43455642--42235913--43516295

select * from koc_clm_hlth_indem_dec where claim_id=43516295;

select * from koc_clm_hlth_detail where ext_reference in ('59363217','59363217');
select * from koc_mv_skrm_suppliers where institute_code='3656'
select * from clm_subfiles where ext_reference='59316260'

select * from koc_clm_hlth_detail where ext_reference='59316260'

update koc_clm_hlth_detail 
   set status_code = 'C'  
 where ext_reference ='59316260'

SELECT * FROM ALZ_HLTPRV_LOG WHERE SERVICENAME='ProvisionInquaryServiceCtrlImpl' AND LOG_DATE>TRUNC(SYSDATE-1)
