update koc_cp_partners_ext 
   set tax_office = 'YEN�BOSNA',
       tax_number = '0580016099'
 where part_id = 7259244;
 
commit;
