DELETE Koc_Clm_Hlth_Prov_Statemnt a 
 WHERE a.Claim_Id = 42172725
   AND a.STATEMENT_NO = 4066053
/       
UPDATE Koc_Clm_Hlth_Detail t SET t.Cpa_Status = NULL WHERE t.Claim_Id = 42172725
/
COMMIT
/
