select INSTITUTE_CODE,
                       r.DOCTOR_CODE,
                       r.VALIDITY_START_DATE,
                       DOCTOR_NAME || ' ' || DOCTOR_surname doctor_name,
                       r.doctor_type doctor_type_code,
                       CASE r.doctor_type
                         WHEN 1 THEN 'Anla�mal� Doktor'
                         WHEN 2 THEN 'Anla�mas�z Doktor'
                         WHEN 3 THEN 'D�� Doktor'
                         WHEN 4 THEN 'Uzman Doktor Network�'
                       END doctor_type 
                  from koc_cc_web_inst_doctor r
                 where validity_end_date is null
                   and INSTITUTE_CODE = 6030
                   and r.Specialty_Subject = 1470
                 /*  AND (r.doctor_type = CASE 'D�� Doktor'
                        WHEN 'Anla�mal� Doktor' THEN  1
                        WHEN 'Anla�mas�z Doktor' THEN 2
                        WHEN 'D�� Doktor' THEN 3
                        WHEN 'Uzman Doktor Network�' THEN 4
                      END OR 'D�� Doktor' = 'Hepsi')*/
              --  ORDER BY 5,4
     UNION        
     SELECT INSTITUTE_CODE,DOCTOR_CODE,NULL VALIDITY_START_DATE, DR_NAME_LASTNAME DOCTOR_NAME, CASE DOCTOR_TYPE                                               
                                                                                    WHEN 'Anla�mas�z Doktor' THEN 2 
                                                                                    WHEN 'ALZ Anla�mas�z Doktor' THEN 2
                                                                                    WHEN 'D�� Doktor' THEN 3
                                                                                    WHEN 'Uzman Doktor Network�' THEN 4
                                                                                   END DOCTOR_TYPE_CODE,   
                                                                                   DOCTOR_TYPE/*INSTITUTE_CODE, DOCTOR_CODE, PROVISION_DATE VALIDITY_START_DATE, DOCTOR_NAME, DOCTOR_LASTNAME, 
       WHEN 'Anla�mal� Doktor' THEN  1
       WHEN 'Anla�mas�z Doktor' THEN 2
       WHEN 'ALZ Anla�mas�z Doktor' THEN 2
       WHEN 'D�� Doktor' THEN 3
       WHEN 'Uzman Doktor Network�' THEN 4*/
     FROM koc_clm_hlth_detail
    WHERE ext_reference = 59488556 ;
     
     --59488556     ;
     ALZ_HLCM_CONVERTER_UTILS; --Anla�mas�z Doktor, ALZ Anla�mas�z Doktor
     
     select * from customer.alz_duplicate_provision  WHERE ext_reference = 59488556 ;
     select * from alz_hltprv_log where log_id=147376235--147388724
     
