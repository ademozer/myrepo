    WITH Koc_v_Health_Insured_Info_Sub AS
       (SELECT /*+rule materialize*/
         a.*
          FROM Koc_v_Health_Insured_Info a
         WHERE a.Partner_Id = 105039510
           AND a.Term_Start_Date <= Nvl(TRUNC(SYSDATE), a.Term_Start_Date)
           AND a.Term_End_Date >= Nvl(TRUNC(SYSDATE), a.Term_End_Date)
           AND (Decode(Term_Start_Date,
                       NULL,
                       SYSDATE,
                       --TO_DATE (   TO_CHAR (term_start_date,'dd/mm/yyyy')|| ' 12:00:00','dd/mm/yyyy hh24:mi:ss') -- selcenk task 186996 grup saglik KFS saat degisikligi
                       Term_Start_Date_Time) <= SYSDATE OR SYSDATE IS NULL)
           AND (Decode(Term_End_Date,
                       NULL,
                       SYSDATE,
                       -- TO_DATE (TO_CHAR (term_end_date, 'dd/mm/yyyy')|| ' 11:59:59','dd/mm/yyyy hh24:mi:ss') -- selcenk task 186996 grup saglik KFS saat degisikligi
                       Term_End_Date_Time) >= SYSDATE OR SYSDATE IS NULL)
              --         AND a.contract_status = 'I'
           AND EXISTS (SELECT /*+NL_SJ*/  --neslihank 31072017 plan de�i�ikli�i g�rm�� planlar i�in bu kontrol eklenmi�tir.
                            1
                        FROM Koc_Clm_Hlth_Indem_Totals i
                       WHERE i.Contract_Id = a.Contract_Id
                         AND i.Partition_No = a.Partition_No
                         AND a.Package_Id = i.Package_Id
                         AND a.Package_Date = i.Package_Date
                         AND Nvl(TRUNC(SYSDATE), i.Validity_Start_Date) BETWEEN i.Validity_Start_Date AND i.Validity_End_Date
                         AND i.Is_Valid = 1)
        )
      ,Koc_v_Health_Insured_Info_s AS
       (SELECT /*+no_merge(a)*/
         a.*,
         COUNT(*) Over(PARTITION BY a.Contract_Id, a.Partition_No) AS Record_Counter,
         Dense_Rank() Over(PARTITION BY Contract_Id, Partition_No ORDER BY(CASE
           WHEN a.Product_Id = 64 AND a.Package_Status != 'D' THEN
            0
           ELSE
            1
         END) ASC) Rnk
          FROM Koc_v_Health_Insured_Info_Sub a)
      SELECT /*+no_merge(a b)*/
         b.*
       FROM Koc_v_Health_Insured_Info_s a, Koc_v_Health_Insured_Info_Sub b
      WHERE 1 = 1
        AND (CASE
              WHEN a.Record_Counter > 1 THEN
               a.Rnk --istedi�imiz kay�t package_status = 'A' olan kay�tt�r. Bu �ekilde al�n�yor.
              ELSE
               1
            END) = 1
         AND a.Partner_Id = b.Partner_Id
         AND a.Contract_Id = b.Contract_Id
         AND a.Partition_No = b.Partition_No
         AND nvl(a.Package_Id, 0) = nvl(b.Package_Id, 0)
         AND nvl(a.pack_name, 'X') = nvl(b.pack_name, 'X');
