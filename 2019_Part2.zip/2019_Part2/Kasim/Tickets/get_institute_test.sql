DECLARE
  v_inst_code NUMBER := 918;
  v_date      DATE   := TO_DATE('23/10/2019','DD/MM/YYYY');
  v_cur       KOC_CLM_HLTH_UTILS.Refcur;
  procedure print_data(cur_ IN SYS_REFCURSOR) IS 
    v_data_msg CLOB;
    v_keys_data VARCHAR2(4000);
    v_ndx number := 0;
    BEGIN
    v_data_msg := '[';
  FOR rec_1 IN (SELECT ROWNUM ROW_NO, 
                                      t1.column_value.getStringVal() ROW_DATA
                                 FROM (SELECT * FROM TABLE (XMLSEQUENCE(cur_))) t1)    
                 LOOP                   
                     IF rec_1.ROW_NO>1 THEN
                         v_data_msg := v_data_msg || ',';
                     END IF;
                     v_data_msg := v_data_msg || '{';
                     v_ndx := 0;
                     FOR rec_2 IN (SELECT EXTRACTVALUE (t.COLUMN_VALUE, '/*') AS NODE_VALUE,
                                                        t.COLUMN_VALUE.getrootelement () AS NODE_NAME
                                     FROM TABLE (XMLSEQUENCE (EXTRACT(EXTRACT(XMLTYPE(rec_1.ROW_DATA), '//*'), '/ROW/*'))) t)
                     LOOP
                        IF v_ndx>0 THEN
                           v_data_msg := v_data_msg || ',';
               IF rec_1.ROW_NO = 1 THEN
                v_keys_data := v_keys_data || ',';
               END IF;
                        END IF;
            IF rec_1.ROW_NO = 1 THEN
              v_keys_data := v_keys_data || LOWER(rec_2.NODE_NAME);
            END IF;
                        v_data_msg := v_data_msg || '"' || LOWER(rec_2.NODE_NAME) || '":"' || TRIM(rec_2.Node_Value) || '"';
                        v_ndx := v_ndx + 1;                         
                     END LOOP;
                     v_data_msg := v_data_msg || '}';
                 END LOOP;     
    --DBMS_OUTPUT.PUT_LINE(v_keys_data);
    v_data_msg := v_data_msg || ']';
    DBMS_OUTPUT.PUT_LINE(v_data_msg);
  END print_data;
BEGIN
    Koc_Clm_Hlth_Utils.Getinstitutinfobycode(v_inst_code, v_date, v_cur);
    print_data(v_cur);
END;
