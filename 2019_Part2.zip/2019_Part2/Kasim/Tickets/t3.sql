select * from clm_subfiles where ext_reference='58855751'

select * from alz_hclm_version_info where claim_id=42862069;
select * from koc_clm_hlth_detail where claim_id=42862069;
