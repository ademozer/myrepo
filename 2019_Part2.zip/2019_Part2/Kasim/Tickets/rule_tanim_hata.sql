select * from ocp_policy_bases where policy_ref='0001171006128591';
select claim_id, alz_hclm_converter_utils.getHclmUsage(null, claim_id, null, null, null, null) 
from clm_pol_oar where contract_id=459429839 and oar_no=133

select * from koc_clm_hlth_indem_totals where contract_id=459429839 and partition_no=133 and cover_code='S512';

select * from alz_hltprv_log where log_id = 146873537;

koc_clm_hlth_trnx 


SELECT *--COUNT(*)
        --INTO v_Cnt
        FROM Koc_Clm_Indem_Total_Rules
       WHERE Package_Id = 316683
         AND Trunc(Package_Date) = '01/10/2019'--Trunc(p_Package_Date)
         AND Child_Cover_Code = 'ST736'
         AND Validity_Start_Date <= SYSDATE
         AND Nvl(Validity_End_Date,  SYSDATE) >=  SYSDATE;
         
         
         select * from customer.alz_duplicate_provision where ext_reference='59461570'
         
         
         sqlerrm              : ORA-20200: ORA-20200: Plan Rule Tanimlarinda Hata Var.(316683-01.10.2019-ST736-12.11.2019) -
p_contract_id        : 515514950
p_partition_no       : 281
p_claim_inst_type    : AK
p_claim_inst_loc     : YI
p_country_group      : 0
p_cover_code         : ST736
package_id           : 316683
package_date         : 01/10/2019
p_date               : 12/11/2019
p_user_id            : MEDISER135
p_is_pool_cover      : 
p_is_special_cover   : 
mod�ler saglik mi    : 1
sub_package_id       : 
sub_package_date     : 
