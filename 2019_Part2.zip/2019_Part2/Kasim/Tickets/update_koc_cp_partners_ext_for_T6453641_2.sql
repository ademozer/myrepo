update koc_cp_partners_ext 
   set tax_office = 'MEC�D�YEK�Y',
       tax_number = '6080332971'
 where part_id = 11285809;
 
 update koc_cp_partners_ext
    set identity_no = '16942119632'
  where part_id = 76438682;
  
update koc_cp_partners_ext 
   set tax_office = 'SEYHAN',
       tax_number = '6130556592'
 where part_id = 30961785;
 
update koc_cp_partners_ext 
   set tax_office = 'KOZYATA�I',
       tax_number = '5360202006'
 where part_id = 73876267;   
 
update koc_cp_partners_ext
   set identity_no = '11111111111'
 where part_id = 121457822;

commit;
