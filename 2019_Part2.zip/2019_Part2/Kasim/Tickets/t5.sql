select * from clm_subfiles where ext_reference='59199707';  --43306832
select * from clm_pol_oar where claim_id=43306832;
select * from clm_pol_oar where contract_id=469381724 and oar_no=13;
select * from alz_hclm_version_info where claim_id in(
43518733,
42760659,
43037847,
43184956,
43187519,
43306832,
41806020,
41804913,
42019318,
42347580)
and version_no=1;

SELECT * FROM KOC_CLM_HLTH_INDEM_TOTALS WHERE contract_id = 469381724 and partition_no=13 and cover_code='ST353' 

select * from koc_clm_hlth_provisions where claim_id in(
43518733,
42760659,
43037847,
43184956,
43187519,
43306832,
41806020,
41804913,
42019318,
42347580)
--and cover_code='ST353'
and req_cure_day_count>0
and status_Code !='C'
