alz_hclm_converter_utils;

select * from alz_hclm_version_info v where v.version_no=1 and v.hclm_usage=0 
and v.approved_status = 'CP' and entry_date>TO_DATE('05/11/2019','DD/MM/YYYY')
and exists(select 1 from koc_clm_hlth_detail where claim_id=v.claim_id and status_code='CP')

select * from clm_subfiles where claim_id=43273696


  SELECT COUNT(*) 
                                                --INTO v_hclm_usage
                                                FROM CUSTOMER.alz_hclm_version_info
                                               WHERE claim_id = 4284331
                                                 AND version_no = 1;
