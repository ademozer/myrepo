SELECT *
  FROM (SELECT IS_COVER_VAL
           FROM koc_oc_hlth_expack_cov_rel
          WHERE /*rownum <2  and*/
          main_rule_code = '3'
       and sub_rule_code = '30'
       AND CHILD_COVER_CODE = 'S501'
       AND CLAIM_INST_LOC = 'YI'
       AND CLAIM_INST_TYPE = 'AK'
       AND CONTRACT_ID = TO_NUMBER('0')
       AND COUNTRY_GROUP = TO_NUMBER('0')
       AND COVER_CAT_GROUP = '0'
       AND INSTITUTE_TYPE = '0'
       AND INST_COV_TYPE = '0'
       AND INST_VALIDITY_TYPE = '0'
       AND IS_POOL_COVER = TO_NUMBER('0')
       AND IS_SPECIAL_COVER = TO_NUMBER('0')
       AND PACKAGE_DATE = TO_DATE('31/12/2018', 'DD/MM/YYYY')
       AND PACKAGE_ID = TO_NUMBER('260561')
       AND PARTITION_NO = TO_NUMBER('0')
       AND PARTITION_TYPE = '0'
       AND PART_ID = TO_NUMBER('0')
       AND PRODUCT_ID = TO_NUMBER('0')
       AND ((CITY_CODE = '34') OR (SPEC_GROUP_CODE = TO_NUMBER('0')) OR
          (INSTITUDE_GROUP_CODE = TO_NUMBER('')) OR
          (INSTITUTE_CODE = TO_NUMBER('1533')))
          ORDER BY nvl(column_priority, 0) DESC)
 WHERE rownum < 2
