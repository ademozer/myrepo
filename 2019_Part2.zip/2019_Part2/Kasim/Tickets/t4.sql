 Select B.Profileid, B.Invoiceid, B.Taxinclusiveamount Taxinclusiveamount, B.Documentcurrencycode, A.Hasta_Ad_Soyad
           , A.Hasta_Pasaport_No, A.Hasta_Tckn, A.Hasta_Yabanci_Kimlik, A.Hastane_Skrs_No
           , B.issuedate issuedate, B.Idx, B.Taxexclusiveamount Taxexclusiveamount
           , B.Taxamount Taxamount
        From Alz_Invoice_Claim_Files C
           , Alz_Invoice_Master_Ext A
           , Alz_Invoice_Master B
       Where C.Ext_Reference IN(
        select sf.ext_reference from koc_clm_hlth_prov_statemnt st, clm_subfiles sf 
    where st.statement_no=4065563
      and st.claim_id = sf.claim_id
       
       )-- '59248796'--'57876881'         
         And A.Idx = C.Idx
       --  And A.Source_Type = 'GELEN'
         And B.Idx = A.Idx
    Order By To_Date(to_char(B.Issuedate, 'dd.mm.yyyy')||' '||to_char(B.Issuetime, 'hh24:mi:Ss'), 'dd.mm.yyyy hh24:mi:Ss') Desc, B.INVOICEID Desc;
    
    select distinct PROFILEID from Alz_Invoice_Master;
    
    select * from clm_subfiles where ext_reference='57876881';
    select * from koc_clm_hlth_detail where ext_reference='57876881';
    select * from koc_clm_hlth_prov_statemnt where claim_id=41610678;
    select * from clm_subfiles where claim_id=43323070--43370429
    
     select st.invoice_total,(select sum(provision_total) 
                                from koc_clm_hlth_provisions 
                               where claim_id=st.claim_id
                                 and status_code NOT IN('R','C')
                               ) provision_total
       from koc_clm_hlth_prov_statemnt st                               
      where st.statement_no=4065563
       
      
      select sum(provision_total) 
      from koc_clm_hlth_provisions where claim_id=43370429 and status_code NOT IN('R','C')
    
     Select Alz_Inv_Utils.Get_Look_Up_Value('INVSTATUS', A.Invoice_Status, A.Document_Date) Inv_Gib_Status
        From Alz_Invoice_Status A
       Where A.Idx = pc_Idx;
       
       Select *
                          From Alz_Invoice_Look_Up A
                         Where A.Code = 'INVSTATUS'
                         
                         SELECT LENGTH('Health Reengineering Provizyon1 projesinde fark edilen bir bug�n ��z�m� i�in') FROM DUAL;
                         
                         
                         SELECT * FROM koc_clm_suppliers_ext a WHERE a.institute_code =  1533 ;
                         SELECT * FROM koc_clm_supp_ext_his  a WHERE a.institute_code =  1533 ORDER BY validity_start_date DESC ;
