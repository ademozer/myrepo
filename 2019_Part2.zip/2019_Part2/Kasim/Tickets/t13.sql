  select count(*), SUM(amount) 
    from koc_clm_hlth_aso_prov
   where claim_id       = :Koc_clm_hlth_detail.Claim_id
     and sf_no          = :Koc_clm_hlth_detail.Sf_no
     and add_order_no   = :Koc_clm_hlth_detail.Add_order_no
     and location_code  = :Koc_clm_hlth_provisions.Location_code
     and cover_code     = :Koc_clm_hlth_provisions.Cover_code; 
     
     select * from  koc_clm_hlth_aso_prov where claim_id=43445862--43210643
     select * from clm_subfiles where ext_reference='59124578'
     
     select * from koc_clm_hlth_provisions where claim_id=43445862;
     select * from koc_clm_hlth_reject_loss where claim_id=43445862;
     --43210643;
     
     select * from clm_subfiles where ext_reference='59437508';
     
     
     select find_round_digit from dual;
     
     koc_Clm_hlth_trnx
     
     select * from customer.alz_duplicate_provision where ext_reference='59411088'--'59437508';
     
     select * from alz_hltprv_log where log_id=146093251--146493112--146469938
     
     select * from alz_hltprv_log where log_date>trunc(sysdate) and SERVICENAME='ALZ_HCLM_CONVERTER_UTILS' 
     AND NOTE='COMPUTE_REMAINING_REQUEST' order by log_date desc;
     
     
     select * from clm_subfiles where ext_reference='59309351'--'59439677';
     select * from alz_hclm_version_info where claim_id=43614168 FOR UPDATE
     
