update alz_hclm_version_info 
   set hclm_usage = 1
 where claim_id = 43509616;
 
COMMIT; 
