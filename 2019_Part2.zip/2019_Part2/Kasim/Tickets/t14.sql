select * from customer.alz_duplicate_provision where ext_reference='59355080';

select * from alz_hltprv_log where log_id=145613092--145220072

--59382661
--59381667

--59382661 
select * from clm_subfiles where ext_reference='59380652'  --43538943
select * from clm_subfiles where ext_reference='59380661'--'59382661'  --43538958
select * from alz_hclm_version_info where claim_id=43440001--43538958 for update;

select * from koc_clm_hlth_proc_detail where claim_id IN (43538943,43538958) and status_code='R'  FOR UPDATE

select * from koc_clm_hlth_reject_loss where claim_id IN(43538962) FOR UPDATE;

select * from koc_clm_hlth_tmp_reject_loss where claim_id IN(43538962)

alz_hclm_converter_utils;

Alz_Hltprv_Form_Utils.Getrejectloss


	Alz_Hltprv_Form_Utils.Getrejectloss
select * from clm_subfiles where ext_reference='59304398'
