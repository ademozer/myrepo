select INSTITUTE_CODE,
                       r.DOCTOR_CODE,
                       r.VALIDITY_START_DATE,
                       DOCTOR_NAME || ' ' || DOCTOR_surname doctor_name,
                       r.doctor_type doctor_type_code,
                       CASE r.doctor_type
                         WHEN 1 THEN 'Anla�mal� Doktor'
                         WHEN 2 THEN 'Anla�mas�z Doktor'
                         WHEN 3 THEN 'D�� Doktor'
                         WHEN 4 THEN 'Uzman Doktor Network�'
                       END doctor_type 
                  from koc_cc_web_inst_doctor r
                 where validity_end_date is null
                   and INSTITUTE_CODE =6030
                   and r.Specialty_Subject = 1470
                   AND (r.doctor_type = CASE 'Anla�mas�z Doktor'
                        WHEN 'Anla�mal� Doktor' THEN  1
                        WHEN 'Anla�mas�z Doktor' THEN 2
                        WHEN 'D�� Doktor' THEN 3
                        WHEN 'Uzman Doktor Network�' THEN 4
                      END OR 'ALZ Anla�mas�z Doktor' = 'Hepsi')
                ORDER BY 5,4
                
                
                
                select INSTITUTE_CODE,
                       r.DOCTOR_CODE,
                       r.VALIDITY_START_DATE,
                       DOCTOR_NAME || ' ' || DOCTOR_surname doctor_name,
                       r.doctor_type doctor_type_code,
                       CASE r.doctor_type
                         WHEN 1 THEN 'Anla�mal� Doktor'
                         WHEN 2 THEN 'Anla�mas�z Doktor'
                         WHEN 3 THEN 'D�� Doktor'
                         WHEN 4 THEN 'Uzman Doktor Network�'
                       END doctor_type 
                  from koc_cc_web_inst_doctor r
                 where validity_end_date is null
                   and INSTITUTE_CODE =6030
                   and r.Specialty_Subject = 1470
                   
                   
