--select * from ocp_policy_bases where policy_ref='0001171006129457'  --and partition_no=31402
select * from koc_clm_hlth_indem_totals where contract_id=443086403 and partition_no=31402 and cover_code='ST504' FOR UPDATE

select claim_id, alz_hclm_converter_utils.getHclmUsage(null, claim_id, null, null, null, null) 
from clm_pol_oar where contract_id=443086403 and oar_no=31402;

select * from koc_clm_hlth_provisions where claim_id in(
42692659,
43509616,
42147917,
42242415,
42142744,
42494196
)

--3899
select * from alz_hclm_institute_info where institute_code=6464 for update

select * from alz_hclm_version_info where claim_id = 43509616 for update;

SELECT * FROM Koc_Clm_Hlth_Prov_Statemnt where statement_no=4052114;
select * from koc_clm_hlth_detail where claim_id=42577582


   SELECT count(hclm_usage) 
               FROM alz_hclm_version_info
              WHERE claim_id =  43509616
                AND version_no = 1;
                
                
                
                
                
                select * from alz_hclm_version_info where add_order_no=2--claim_id = 43509616 
                
                select alz_hclm_converter_utils.getHclmUsage(null, 42944046, null, null, null, null) from dual
