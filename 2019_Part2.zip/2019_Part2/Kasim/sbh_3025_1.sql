SELECT d.status_code, CASE WHEN d.status_code IN ('PP', 'CP', 'P') THEN 'PROVISION' 
            WHEN d.status_code IN ('TI', 'I', 'H')  THEN 'REIMBURSEMENT' 
       END CLAIM_TYPE,d.claim_id, d.sf_no, d.add_order_no
  FROM koc_clm_hlth_detail d
 WHERE ((d.provision_date BETWEEN ADD_MONTHS (SYSDATE, -30)
                            AND ADD_MONTHS (SYSDATE, -24)
         AND d.status_code IN ('PP', 'CP', 'P')
         AND NOT EXISTS (
            SELECT 1
              FROM koc_clm_hlth_indem_dec dd
             WHERE dd.claim_id = d.claim_id
               AND dd.sf_no = d.sf_no
               AND dd.file_agreement_code = 'KI'))
         OR (d.COMM_DATE BETWEEN ADD_MONTHS (SYSDATE, -18) AND ADD_MONTHS (SYSDATE, -6)
             AND d.status_code IN ('TI', 'I', 'H')))
   
UNION ALL
 SELECT d.claim_id, d.sf_no, d.add_order_no, 2 query_id
   FROM koc_clm_hlth_detail d
  WHERE d.COMM_DATE 
BETWEEN ADD_MONTHS (SYSDATE, -18) AND ADD_MONTHS (SYSDATE, -6)
   AND d.status_code IN ('TI', 'I', 'H')
   
   
   
