select ext_reference, MIN(log_id) LOG_ID,  MAX(service_name) service_name
from hclm_log_takip where trunc(log_date) = trunc(sysdate-1)
group by ext_reference
