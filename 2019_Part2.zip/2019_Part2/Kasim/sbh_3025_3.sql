SELECT CASE
         WHEN d.status_code IN ('PP', 'CP', 'P') THEN
          '10'
         WHEN d.status_code IN ('TI', 'I', 'H') THEN
          '2'
       END TIME_EXP,
       d.*
  FROM koc_clm_hlth_detail d
 WHERE ((d.provision_date BETWEEN ADD_MONTHS(SYSDATE, -126) AND
       ADD_MONTHS(SYSDATE, -120) AND d.status_code IN ('PP', 'CP', 'P') AND
       NOT EXISTS (SELECT 1
                      FROM koc_clm_hlth_indem_dec dd
                     WHERE dd.claim_id = d.claim_id
                       AND dd.sf_no = d.sf_no
                       AND dd.file_agreement_code = 'KI')
       AND EXISTS (SELECT 1 FROM KOC_CLM_HLTH_PROV_STATEMNT WHERE CLAIM_ID=d.claim_id)                
        ) OR
       (d.COMM_DATE BETWEEN ADD_MONTHS(SYSDATE, -18) AND
       ADD_MONTHS(SYSDATE, -6) AND d.status_code IN ('TI', 'I', 'H')))
UNION   
SELECT '2' TIME_EXP,
       d.*
  FROM koc_clm_hlth_detail d
 WHERE d.provision_date BETWEEN ADD_MONTHS(SYSDATE, -23) AND
       ADD_MONTHS(SYSDATE, -22) AND d.status_code IN ('PP', 'CP', 'P') AND
       NOT EXISTS (SELECT 1
                      FROM koc_clm_hlth_indem_dec dd
                     WHERE dd.claim_id = d.claim_id
                       AND dd.sf_no = d.sf_no
                       AND dd.file_agreement_code = 'KI')
       AND NOT EXISTS (SELECT 1 FROM KOC_CLM_HLTH_PROV_STATEMNT WHERE CLAIM_ID=d.claim_id)
