--  SELECT ADD_MONTHS(SYSDATE, -120) FROM DUAL
SELECT d.status_code,
       CASE
         WHEN d.status_code IN ('PP', 'CP', 'P') THEN
          'PROVISION_WITH_ICMAL'
         WHEN d.status_code IN ('TI', 'I', 'H') THEN
          'REIMBURSEMENT'
       END CLAIM_TYPE,
      -- (SELECT COUNT(1) FROM KOC_CLM_HLTH_PROV_STATEMNT WHERE CLAIM_ID=d.claim_id) ICMAL_ADET, 
       d.claim_id,
       d.sf_no,
       d.add_order_no
  FROM koc_clm_hlth_detail d
 WHERE ((d.provision_date BETWEEN ADD_MONTHS(SYSDATE, -126) AND
       ADD_MONTHS(SYSDATE, -120) AND d.status_code IN ('PP', 'CP', 'P') AND
       NOT EXISTS (SELECT 1
                      FROM koc_clm_hlth_indem_dec dd
                     WHERE dd.claim_id = d.claim_id
                       AND dd.sf_no = d.sf_no
                       AND dd.file_agreement_code = 'KI')
       AND EXISTS (SELECT 1 FROM KOC_CLM_HLTH_PROV_STATEMNT WHERE CLAIM_ID=d.claim_id)                
        ) OR
       (d.COMM_DATE BETWEEN ADD_MONTHS(SYSDATE, -18) AND
       ADD_MONTHS(SYSDATE, -6) AND d.status_code IN ('TI', 'I', 'H')))
UNION   
SELECT d.status_code,
       'PROVISION_WITHOUT_ICMAL' CLAIM_TYPE,
      -- (SELECT COUNT(1) FROM KOC_CLM_HLTH_PROV_STATEMNT WHERE CLAIM_ID=d.claim_id) ICMAL_ADET, 
       d.claim_id,
       d.sf_no,
       d.add_order_no
  FROM koc_clm_hlth_detail d
 WHERE d.provision_date BETWEEN ADD_MONTHS(SYSDATE, -23) AND
       ADD_MONTHS(SYSDATE, -22) AND d.status_code IN ('PP', 'CP', 'P') AND
       NOT EXISTS (SELECT 1
                      FROM koc_clm_hlth_indem_dec dd
                     WHERE dd.claim_id = d.claim_id
                       AND dd.sf_no = d.sf_no
                       AND dd.file_agreement_code = 'KI')
       AND NOT EXISTS (SELECT 1 FROM KOC_CLM_HLTH_PROV_STATEMNT WHERE CLAIM_ID=d.claim_id)     
      -- AND EXISTS (SELECT 1 FROM KOC_CLM_HLTH_PROV_STATEMNT WHERE CLAIM_ID=d.claim_id)
       
       --SELECT * FROM KOC_CLM_HLTH_PROV_STATEMNT WHERE CLAIM_ID=34310646
