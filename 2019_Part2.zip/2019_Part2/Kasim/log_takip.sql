select * from hclm_log_takip where trunc(log_date) = trunc(sysdate-2);

