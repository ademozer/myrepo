select * from koc_oc_hlth_ex_pack_rul_gr order by 1;
select * from koc_oc_hlth_ex_pack_rules where sub_rule_code=35
select * from koc_clm_hlth_status_his;
koc_clm_hlth_detail

select * from Alz_Hlth_Prv_Pending_Period
