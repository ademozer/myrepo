DECLARE
  CURSOR Mainrulecur IS
      SELECT DISTINCT b.Priority, Main_Rule_Code, Sub_Rule_Code
        FROM Koc_Oc_Hlth_Ex_Pack_Rules a, Koc_Oc_Hlth_Ex_Pack_Rul_Gr b
       WHERE Table_Field_Name = 'IS_COVER_VAL'
         AND One_Must = 1
         AND a.Sub_Rule_Code = b.Rule_Code
         AND b.Rule_Group_Code IN (3, 1)
       ORDER BY b.Priority;
  Mainrulerec    Mainrulecur%ROWTYPE;     
 BEGIN
    OPEN Mainrulecur;

    LOOP
      FETCH Mainrulecur
        INTO Mainrulerec;

      EXIT WHEN Mainrulecur%NOTFOUND;
      DBMS_OUTPUT.PUT_LINE(Mainrulerec.sub_rule_code); 
    END LOOP;
    CLOSE Mainrulecur;
 /*FOR rec IN (SELECT DISTINCT b.Priority, Main_Rule_Code, Sub_Rule_Code
        FROM Koc_Oc_Hlth_Ex_Pack_Rules a, Koc_Oc_Hlth_Ex_Pack_Rul_Gr b
       WHERE Table_Field_Name = 'IS_COVER_VAL'
         AND One_Must = 1
         AND a.Sub_Rule_Code = b.Rule_Code
         AND b.Rule_Group_Code IN (3, 1)) LOOP
      DBMS_OUTPUT.PUT_LINE(rec.sub_rule_code);   
  END LOOP;*/
  
  END;
      
