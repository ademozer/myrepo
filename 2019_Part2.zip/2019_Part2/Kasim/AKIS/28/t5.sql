select * from clm_subfiles where ext_reference='59609276';
select * from alz_hclm_version_info where claim_id=43832893 for update;

select * from koc_clm_hlth_detail where ext_reference='59609276' for update

26364, 4/27/2019, 918
select package_id, child_cover_code, institute_code, exemption_rate, main_rule_code, sub_rule_code 
from koc_oc_hlth_expack_cov_rel where package_id=263645 and child_cover_code='S500' and institute_code=918  


select *
from koc_oc_hlth_expack_cov_rel where package_id=263645 and child_cover_code='S500' and institute_code=918  for update

263645

select * from koc_clm_hlth_indem_totals where contract_id=472116522 and partition_no=627
--S349-662
