update alz_hlth_provisions_hist
   set status_code = 'P',
       provision_explanation = provision_explanation || '// T6433153 nolu �a�r�ya istinaden status_code = P olarak g�ncellendi. (C idi)' 
 where claim_id = 43800112
   and transaction_no = 3
   and cover_code='S513';
   
commit;
