SELECT *
  FROM (SELECT PROVISION_AVAL_CODE
           FROM koc_oc_hlth_expack_cov_rel
          WHERE /*rownum <2  and*/
          main_rule_code = '3'
       and sub_rule_code = '35'
       AND CHILD_COVER_CODE = '0'
       AND CLAIM_INST_LOC = '0'
       AND CLAIM_INST_TYPE = '0'
       AND CONTRACT_ID = TO_NUMBER('0')
       AND COUNTRY_GROUP = TO_NUMBER('0')
       AND COVER_CAT_GROUP = '0'
       AND INSTITUTE_TYPE = '0'
       AND INST_COV_TYPE = '0'
       AND INST_VALIDITY_TYPE = '0'
       AND IS_POOL_COVER = TO_NUMBER('0')
       AND IS_SPECIAL_COVER = TO_NUMBER('0')
       AND PACKAGE_DATE = TO_DATE('27/04/2019', 'DD/MM/YYYY')
       AND PACKAGE_ID = TO_NUMBER('263642')
       AND PARTITION_NO = TO_NUMBER('0')
       AND PARTITION_TYPE = '0'
       AND PART_ID = TO_NUMBER('0')
       AND PRODUCT_ID = TO_NUMBER('0')
       AND ((CITY_CODE = '34') OR (SPEC_GROUP_CODE = TO_NUMBER('1')) OR
          (INSTITUDE_GROUP_CODE = TO_NUMBER('20')) OR
          (INSTITUTE_CODE = TO_NUMBER('918')))
          ORDER BY nvl(column_priority, 0) DESC)
 WHERE rownum < 2




SELECT *
           FROM koc_oc_hlth_expack_cov_rel
          WHERE /*rownum <2  and*/
          main_rule_code = '3'
       and sub_rule_code = '35'
       AND CHILD_COVER_CODE = 'S502'
      -- AND CLAIM_INST_LOC = '0'
      -- AND CLAIM_INST_TYPE = '0'
      -- AND CONTRACT_ID = TO_NUMBER('0')
       --AND COUNTRY_GROUP = TO_NUMBER('0')
      -- AND COVER_CAT_GROUP = '0'
      -- AND INSTITUTE_TYPE = '0'
     ---  AND INST_COV_TYPE = '0'
     --  AND INST_VALIDITY_TYPE = '0'
       AND IS_POOL_COVER = TO_NUMBER('0')
       AND IS_SPECIAL_COVER = TO_NUMBER('0')
       AND PACKAGE_DATE = TO_DATE('27/04/2019', 'DD/MM/YYYY')
       AND PACKAGE_ID = TO_NUMBER('263642')
       AND PARTITION_NO = TO_NUMBER('0')
        AND ((CITY_CODE = '34') OR (SPEC_GROUP_CODE = TO_NUMBER('1')) OR
          (INSTITUDE_GROUP_CODE = TO_NUMBER('20')) OR
          (INSTITUTE_CODE = TO_NUMBER('918')))
          ORDER BY nvl(column_priority, 0) DESC;
          
          
          
          SELECT *
           FROM koc_oc_hlth_expack_cov_rel
          WHERE /*rownum <2  and*/
               main_rule_code = '3'
           and sub_rule_code IN('35','13')
       --AND CHILD_COVER_CODE = 'S502'
       AND institute_code in ('0','918');
       
SELECT * FROM ( SELECT IS_UNLIMITED FROM koc_oc_hlth_expack_cov_rel  WHERE  /*rownum <2  and*/  main_rule_code = '3' and  sub_rule_code = '13' AND  COVER_CAT_GROUP= '0'AND CHILD_COVER_CODE= 'S502'AND CLAIM_INST_LOC= '0'AND CLAIM_INST_TYPE= '0'AND CONTRACT_ID= TO_NUMBER('472116522')AND COUNTRY_GROUP= TO_NUMBER('0')AND INSTITUTE_CODE= TO_NUMBER('918')AND INSTITUTE_TYPE= '0'AND INST_COV_TYPE= '0'AND INST_VALIDITY_TYPE= '0'AND IS_POOL_COVER= TO_NUMBER('0')AND IS_SPECIAL_COVER= TO_NUMBER('0')AND PACKAGE_DATE= TO_DATE('27/04/2019','DD/MM/YYYY')AND PACKAGE_ID= TO_NUMBER('263642')AND PARTITION_NO= TO_NUMBER('55')AND PARTITION_TYPE= '0'AND PART_ID= TO_NUMBER('0')AND PRODUCT_ID= TO_NUMBER('0') ORDER BY nvl(column_priority,0) DESC) WHERE rownum <2 
SELECT * FROM ( SELECT COVER_PRICE FROM koc_oc_hlth_expack_cov_rel  WHERE  /*rownum <2  and*/  main_rule_code = '3' and  sub_rule_code = '13' AND  COVER_CAT_GROUP= '0'AND CHILD_COVER_CODE= 'S502'AND CLAIM_INST_LOC= '0'AND CLAIM_INST_TYPE= '0'AND CONTRACT_ID= TO_NUMBER('472116522')AND COUNTRY_GROUP= TO_NUMBER('0')AND INSTITUTE_CODE= TO_NUMBER('918')AND INSTITUTE_TYPE= '0'AND INST_COV_TYPE= '0'AND INST_VALIDITY_TYPE= '0'AND IS_POOL_COVER= TO_NUMBER('0')AND IS_SPECIAL_COVER= TO_NUMBER('0')AND PACKAGE_DATE= TO_DATE('27/04/2019','DD/MM/YYYY')AND PACKAGE_ID= TO_NUMBER('263642')AND PARTITION_NO= TO_NUMBER('55')AND PARTITION_TYPE= '0'AND PART_ID= TO_NUMBER('0')AND PRODUCT_ID= TO_NUMBER('0') ORDER BY nvl(column_priority,0) DESC) WHERE rownum <2        
SELECT * FROM ( SELECT EXEMPTION_RATE2 FROM koc_oc_hlth_expack_cov_rel  WHERE  /*rownum <2  and*/  main_rule_code = '3' and  sub_rule_code = '30' AND CHILD_COVER_CODE= 'S502'AND CLAIM_INST_LOC= 'YI'AND CLAIM_INST_TYPE= 'AK'AND CONTRACT_ID= TO_NUMBER('0')AND COUNTRY_GROUP= TO_NUMBER('0')AND COVER_CAT_GROUP= '0'AND INSTITUTE_TYPE= '0'AND INST_COV_TYPE= '0'AND INST_VALIDITY_TYPE= '0'AND IS_POOL_COVER= TO_NUMBER('0')AND IS_SPECIAL_COVER= TO_NUMBER('0')AND PACKAGE_DATE= TO_DATE('27/04/2019','DD/MM/YYYY')AND PACKAGE_ID= TO_NUMBER('263642')AND PARTITION_NO= TO_NUMBER('0')AND PARTITION_TYPE= '0'AND PART_ID= TO_NUMBER('0')AND PRODUCT_ID= TO_NUMBER('0') AND (  ( CITY_CODE= '34')  OR  ( SPEC_GROUP_CODE= TO_NUMBER('1')) OR  ( INSTITUDE_GROUP_CODE= TO_NUMBER('20')) OR  ( INSTITUTE_CODE= TO_NUMBER('918'))) ORDER BY nvl(column_priority,0) DESC) WHERE rownum <2        
SELECT * FROM ( SELECT PROVISION_AVAL_CODE FROM koc_oc_hlth_expack_cov_rel  WHERE  /*rownum <2  and*/  main_rule_code = '3' and  sub_rule_code = '35' AND CHILD_COVER_CODE= '0'AND CLAIM_INST_LOC= '0'AND CLAIM_INST_TYPE= '0'AND CONTRACT_ID= TO_NUMBER('0')AND COUNTRY_GROUP= TO_NUMBER('0')AND COVER_CAT_GROUP= '0'AND INSTITUTE_TYPE= '0'AND INST_COV_TYPE= '0'AND INST_VALIDITY_TYPE= '0'AND IS_POOL_COVER= TO_NUMBER('0')AND IS_SPECIAL_COVER= TO_NUMBER('0')AND PACKAGE_DATE= TO_DATE('27/04/2019','DD/MM/YYYY')AND PACKAGE_ID= TO_NUMBER('263642')AND PARTITION_NO= TO_NUMBER('0')AND PARTITION_TYPE= '0'AND PART_ID= TO_NUMBER('0')AND PRODUCT_ID= TO_NUMBER('0') AND (  ( CITY_CODE= '34')  OR  ( SPEC_GROUP_CODE= TO_NUMBER('1')) OR  ( INSTITUDE_GROUP_CODE= TO_NUMBER('20')) OR  ( INSTITUTE_CODE= TO_NUMBER('918'))) ORDER BY nvl(column_priority,0) DESC) WHERE rownum <2 
       select * from koc_oc_hlth_ex_pack_rul_gr 

       --select * from  koc_oc_hlth_ex_pack_rules where sub_rule_code IN(35) 
       select * from koc_oc_hlth_ex_pack_rules where sub_rule_code IN(35) ;
       
         select * from  koc_oc_hlth_ex_pack_rul_gr where rule_code IN(35) for update
       
       delete koc_oc_hlth_ex_pack_rules where sub_rule_code IN(35) 
                                                  and TABLE_FIELD_NAME NOT IN('IS_UNLIMITED', 
                                                                              'COVER_PRICE',
                                                                              'CHILD_COVER_CODE',
                                                                              'CLAIM_INST_LOC',
                                                                              'CLAIM_INST_TYPE',
                                                                              'CONTRACT_ID',
                                                                              'COUNTRY_GROUP',
                                                                              'COVER_CAT_GROUP',
                                                                              'INSTITUTE_TYPE',
                                                                              'INST_COV_TYPE',
                                                                              'INST_VALIDITY_TYPE',
                                                                              'IS_POOL_COVER', 
                                                                              'IS_SPECIAL_COVER',
                                                                              'PACKAGE_DATE',
                                                                              'PACKAGE_ID',
                                                                              'PARTITION_NO',
                                                                              'PARTITION_TYPE',
                                                                              'PART_ID',
                                                                              'PRODUCT_ID',
                                                                              'CITY_CODE',
                                                                              'SPEC_GROUP_CODE',
                                                                              'MAIN_RULE_CODE',
                                                                              'SUB_RULE_CODE',
                                                                              'INSTITUDE_GROUP_CODE',
                                                                              'INSTITUTE_CODE')



       select * from  koc_oc_hlth_ex_pack_rules where sub_rule_code IN(30,33,35) 
                                                  and TABLE_FIELD_NAME IN('IS_UNLIMITED', 
                                                                              'COVER_PRICE',
                                                                              'IS_COVER_VAL'
                                                                            ) FOR UPDATE
                                                                            
                                                                            
                                                                            
                                                                            
     SELECT DISTINCT b.Priority, Main_Rule_Code, Sub_Rule_Code
        FROM Koc_Oc_Hlth_Ex_Pack_Rules a, Koc_Oc_Hlth_Ex_Pack_Rul_Gr b
       WHERE TABLE_FIELD_NAME IN('IS_COVER_VAL')
         AND One_Must = 1
         AND a.Sub_Rule_Code = b.Rule_Code
         AND b.Rule_Group_Code IN (3, 1)
       ORDER BY b.Priority;

    CURSOR Rulecur(p_Main_Rule_Code VARCHAR2, p_Sub_Rule_Code VARCHAR2) IS
      SELECT /*+ index(a KOC_OC_HLTH_EX_PACK_RULES_PK) */
       a.*
        FROM Koc_Oc_Hlth_Ex_Pack_Rules a
       WHERE Nvl(a.One_Must, 0) = 0
         AND a.Main_Rule_Code = 3
         AND a.Sub_Rule_Code = 35
         AND a.Column_Group IS NULL /*Karma kp 08.11.2016*/
      ;

    /*Karma kp 08.11.2016*/
    CURSOR Rulecuror(p_Main_Rule_Code VARCHAR2, p_Sub_Rule_Code VARCHAR2) IS
      SELECT /*+ index(a KOC_OC_HLTH_EX_PACK_RULES_PK) */
       a.*
        FROM Koc_Oc_Hlth_Ex_Pack_Rules a
       WHERE Nvl(a.One_Must, 0) = 0
         AND a.Main_Rule_Code = 3
         AND a.Sub_Rule_Code = 35
         AND a.Column_Group IS NOT NULL
       ORDER BY a.Column_Group, a.Column_Priority;                                                                            
