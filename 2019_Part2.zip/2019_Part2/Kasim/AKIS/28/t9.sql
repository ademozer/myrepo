select * from koc_clm_hlth_detail where ext_reference='59584195';
select * from alz_hlth_provisions_hist where claim_id=43800112
select * from koc_clm_hlth_provisions where claim_id=43800112
select * from alz_hclm_version_info where claim_id=43800112;
select * from koc_clm_hlth_indem_dec where claim_id=43800112;

--select * from koc_clm_hlth_reject_loss  where claim_id=43800112;
149705253
149717077
149747925
149748006


    select * from alz_hltprv_log where servicename='ALZ_HCLM_CONVERTER_UTILS'  
  and insuredno='59584195' order by log_date desc;
