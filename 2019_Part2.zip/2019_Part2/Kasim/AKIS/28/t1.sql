SELECT *
  FROM (SELECT IS_COVER_VAL
           FROM koc_oc_hlth_expack_cov_rel
          WHERE /*rownum <2  and*/
          main_rule_code = '3'
       and sub_rule_code = '30'
       AND CHILD_COVER_CODE = 'S500'
       AND CLAIM_INST_LOC = 'YI'
       AND CLAIM_INST_TYPE = 'AK'
       AND CONTRACT_ID = TO_NUMBER('0')
       AND COUNTRY_GROUP = TO_NUMBER('0')
       AND COVER_CAT_GROUP = '0'
       AND INSTITUTE_TYPE = '0'
       AND INST_COV_TYPE = '0'
       AND INST_VALIDITY_TYPE = '0'
       AND IS_POOL_COVER = TO_NUMBER('0')
       AND IS_SPECIAL_COVER = TO_NUMBER('0')
       AND PACKAGE_DATE = TO_DATE('27/04/2019', 'DD/MM/YYYY')
       AND PACKAGE_ID = TO_NUMBER('263645')
       AND PARTITION_NO = TO_NUMBER('0')
       AND PARTITION_TYPE = '0'
       AND PART_ID = TO_NUMBER('0')
       AND PRODUCT_ID = TO_NUMBER('0')
       AND ((CITY_CODE = '34') OR (SPEC_GROUP_CODE = TO_NUMBER('1')) OR
          (INSTITUDE_GROUP_CODE = TO_NUMBER('20')) OR
          (INSTITUTE_CODE = TO_NUMBER('918')))
          ORDER BY nvl(column_priority, 0) DESC)
 WHERE rownum < 2
 
  SELECT /*+ index (a.b KOC_CLM_SUPPLIERS_EXT_IDX1) */
       a.*
        FROM Koc_v_Clm_Suppliers_Main a
       WHERE a.Institute_Code = 918
         AND a.Eff_Date <= SYSDATE
         AND Nvl(a.Exp_Date, v_Date) >= v_Date
      UNION ALL
      SELECT a.*
        FROM Koc_v_Clm_Suppliers_His a
       WHERE a.Institute_Code = p_Institute_Code
         AND a.Eff_Date <= v_Date
         AND Nvl(a.Exp_Date, v_Date) >= v_Date;
         
         select * from koc_oc_hlth_expack_cov_rel where package_id=263645 and child_cover_code IN ('S500','S501') and claim_inst_type='AK' 
         and sub_rule_code='30' and INSTITUDE_GROUP_CODE = 20
         
        
         
         select * from clm_subfiles where ext_reference='58119082';
         select * from koc_clm_hlth_detail where ext_reference='58119082';
         select * from alz_hclm_version_info where claim_id=41911150 for update
 
