select * from clm_subfiles where ext_reference = '59370321';
select * from clm_pol_oar where claim_id = 43525229;
select * from clm_pol_oar where contract_id = 469390572 and oar_no=4648;

select * from alz_hclm_version_info where claim_id in (43525229,
43683965,
42805174,
41276268,
41583688,
43494879,
43494886,
43752235,
41728153,
41940236
)
and version_no=1
;
select * from koc_clm_hlth_indem_dec where claim_id=43525229

select * from koc_clm_hlth_provisions where claim_id in (43525229,
43683965,
42805174,
41276268,
41583688,
43494879,
43494886,
43752235,
41728153,
41940236
)
and cover_code='ST504'
and status_code!='R'

469390572 -- 4648

select * from 

update koc_clm_hlth_indem_totals 
   set r_day_seance = 7,
       s_spend_day_deance = 7
 where contract_id=469390572 
   and partition_no=4648 and cover_code='ST504';
   
   
   
select * from koc_clm_hlth_indem_totals 
 where contract_id=469390572 
   and partition_no=4648 and cover_code='ST504'
   and claim_inst_type='AK'
   
   59546702
   select * from clm_subfiles where ext_reference='59546702';
   select * from alz_hclm_version_info where claim_id=43752235 for update;
     select * from alz_hclm_version_info where claim_id=43525229;
     
     select * from alz_hltprv_log where insured
     select * from alz_hltprv_log where servicename='ALZ_HCLM_CONVERTER_UTILS'  
     and institutecode='1342' and note='COMPUTE_REMAINING_REQUEST' and log_date>trunc(sysdate) order by log_date desc;
     
     select * from alz_hltprv_log where log_id=150948973;
     select * from koc_clm_hlth_detail where claim_id=43868565;
     
     
     
     select * from alz_hltprv_log where log_id=151064387 ;
     
     select * from alz_hlth_provisions_hist where claim_id=43752235
     select * from clm_subfiles where claim_id=43752235
       SELECT Partner_Id, Policy_Start_Date, Group_Code
             FROM CUSTOMER.Koc_v_Hlth_Insured_Info_Indem
            where contract_id = 473839174 
              and partition_no = 2;
