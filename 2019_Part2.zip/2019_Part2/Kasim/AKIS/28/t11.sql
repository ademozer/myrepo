select * from ocp_policy_bases where policy_ref='0001071003343983';

select * from ocp_policy_bases where policy_ref='0001071003526393';

select * from clm_pol_oar where contract_id=473839174--452620843;

43441893
43631372
43022789
43194112;

select * from koc_clm_hlth_detail where claim_id in(
43441893,
43631372,
43022789,
43194112
)

58979738
59112173
37697161
59452902



select * from koc_clm_hlth_indem_totals where contract_id=452620843 and partition_no=4;
select * from koc_ocp_pol_contracts_ext  where contract_id=452620843;

select * from alz_v_hclm_insured_info where contract_id=452620843;
select * from koc_ocp_risk_packages where contract_id=452620843;

--473839174 - 2
