ALZ_HCLM_CONVERTER_UTILS
select * from alz_hclm_version_info where claim_id=43359339--43186677--43091309;
select * from koc_clm_hlth_indem_dec where claim_id=43359339--43359339--43186677--43091309;
--59564254",              "claimId" : "43774313"
"extReference" : "59291684",              "claimId" : "43422036"
59565361",              "claimId" : "43776299"
select * from alz_hclm_version_info where claim_id=43422036--43776299--43441833
select * from koc_clm_hlth_detail where claim_id=43774313--43441833;
select * from alz_hltprv_log where log_id=150210331 --149239665
select * from alz_hltprv_log where servicename='ALZ_HCLM_CONVERTER_UTILS'   and insuredno='59580158'  and note='UPDATE_PROVISION_REQUEST'
select * from koc_clm_hlth_reject_loss where claim_id=43798123
select * from koc_clm_hlth_provisions where claim_id=43798123
select * from alz_hclm_version_info where log_id=149238725;

150274586
150274827
150277725

149973646
150210331;

select * from alz_hltprv_log where log_id=147978529





select * from clm_subfiles where claim_id in(43776299,43422036) ;

select * from alz_hclm_version_info where claim_id in(43422036) 

150051599
150051972
150038502
150038665
150318710
150674078
150674080
150674148
