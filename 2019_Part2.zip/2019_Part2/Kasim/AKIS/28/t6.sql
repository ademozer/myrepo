select * from clm_subfiles where ext_reference='58115773';

select * from koc_clm_hlth_reject_loss where claim_id=41909393 for update

select * from koc_clm_hlth_provisions where claim_id=41909393;

Koc_Pk_Hlth_Provision.Getprovisiondata
