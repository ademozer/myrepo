   update alz_hlth_provisions_hist 
       set day_seance = 1,
           provision_explanation = provision_explanation || ' // T6427837 nolu �a�r� kapsam�nda day_seance = 1 olarak g�ncellenmi�tir.'
     where claim_id=43752235 
       and transaction_no=2;
       
    COMMIT;
