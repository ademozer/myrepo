SELECT * FROM dba_tab_privs where table_name = 'ALZ_TPA_COMPANIES'
MINUS
SELECT GRANTEE FROM dba_tab_privs where table_name = 'ALZ_HLTH_ANNOUNCEMENT_INST';

select * from dba_role_privs where granted_role='ROLE_RAPOR';

ALZ_HLTH_ANNOUNCEMENT
