select * from koc_clm_hlth_detail where ext_reference='58785514';
select * from alz_hclm_version_info where claim_id=42771048;
select * from koc_clm_hlth_indem_dec where claim_id=42771048;
select * from koc_clm_hlth_prov_statemnt where claim_id=42771048;
select SUM(PROVISION_TOTAL) from alz_hlth_provisions_hist where claim_id=42771048

select * from alz_hltprv_log where log_id=140372245--140372245;

 select * from alz_hltprv_log where servicename='ALZ_HCLM_CONVERTER_UTILS'  and insuredno='58785514' order by log_date desc;
 59487845
 --208.206    --208.206
 --167.31     --167.31
 --697.113    --680.751
 --1115.37    --557.685;
 
 140372245
140372245
138847501
138847498
;
KOC_CLM_HLTH_TRNX;
KOC_CLM_HLTH_PHARMACY_UTILS

SELECT Koc_Clm_Hlth_Utils.Getsumprvforstatement(42771048,
                                                               1,
                                                               1) FROM DUAL;
                                                               
select * from koc_clm_trans_ext where claim_id=42771048   
select * from clm_trans where claim_id=42771048 
select * from koc_clm_hlth_inst_trans where claim_id=42771048    ;

select * from koc_clm_hlth_prov_statemnt s where entry_date>to_date('20/11/2019','DD/MM/YYYY')  
and exists(select 1 from  alz_hclm_version_info where claim_id=s.claim_id)
select * from alz_hclm_version_info where claim_id=43677266;
select * from clm_subfiles where claim_id=43677266
select * from koc_clm_hlth_prov_statemnt where claim_id=43677266
SELECT Koc_Clm_Hlth_Utils.Getsumprvforstatement(43677266,
                                                               1,
                                                               1) FROM DUAL;
 select * from alz_hltprv_log where servicename='ALZ_HCLM_CONVERTER_UTILS'  and insuredno='59487845' order by log_date desc;     
 
 select * from alz_hltprv_log where log_id=151068049                                            
