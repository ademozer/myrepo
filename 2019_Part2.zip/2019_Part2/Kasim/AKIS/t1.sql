select * from 
(select rule_code, rule_name, rule_explanation
from koc_oc_hlth_ex_pack_rul_gr
where rule_type in( '1','3')
 -- and :PARAMETER.P_PRODUCT_ID  = 63
  and rule_code in('11','30','31','32','33','34')
union all
select rule_code, rule_name, rule_explanation
from koc_oc_hlth_ex_pack_rul_gr
where rule_type in( '1','3')
  --and nvl(:PARAMETER.P_PRODUCT_ID,0) in (64,0)
  and rule_code in('11','30','31','32','33', '35'))
order by to_number(rule_code) 
  

select rule_code, rule_name, rule_explanation
from koc_oc_hlth_ex_pack_rul_gr
where rule_type in( '1','3')

select * from koc_oc_hlth_expack_cov_rel where sub_rule_code='35'
select * from koc_oc_hlth_expack_cov_rel where sub_rule_code='35';

select * from koc_mv_skrm_suppliers v
where not exists(select 1 from alz_hclm_institute_info where institute_code=v.institute_code)
and institute_type != '2'
and tss_agreement_status = 1
and exp_date is null

select * from alz_hclm_institute_info where institute_code=3393;

select * from clm_subfiles where ext_reference='59505813'
select * from alz_hclm_version_info where claim_id = 43698904

delete koc_oc_hlth_expack_cov_rel where sub_rule_code='35'

SELECT DISTINCT b.package_id, a.cover_code, a.cover_name, b.claim_inst_type, b.claim_inst_loc
                         FROM cfg_v_prod_covers_api a, koc_oc_hlth_pack_cov_rel b 
                        WHERE a.product_id IN (63,64)
                          AND b.package_id = 263642
                          AND b.child_cover_code = a.cover_code
                          AND a.cover_code = 'S500'
                          AND claim_inst_type NOT IN('AK-IS','AHK-IS')
                          --:TEMINAT.child_cover_code
                          
                          
                          select * from clm_subfiles where ext_reference='59493836';
                          select * from clm_pol_oar where claim_id=43684674;
                          select * from koc_clm_hlth_detail where claim_id=43684674;
                          select * from koc_clm_hlth_provisions where claim_id=43684674;
                          select * from alz_hclm_version_info where claim_id=43684674;
                          
                          select * from clm_pol_oar where 
                          
                          select * from koc_clm_hlth_indem_totals where contract_id=505975263 and partition_no=1 and child_cover_code=''
                          
                          
