select * from koc_clm_hlth_status_his where claim_id=41912474

select * from clm_subfiles where ext_reference='58121308';

select * from koc_oc_hlth_expack_cov_rel where sub_rule_code=35;
select * from clm_subfiles where ext_reference='59827706';
select * from koc_clm_hlth_detail where ext_reference='59827706';
select * from clm_pol_oar where claim_id=44115456

   select distinct b.package_id, b.child_cover_code, b.claim_inst_type, b.claim_inst_loc
              from koc_oc_hlth_pack_cov_rel b 
             where b.package_id = 263642             
             --  and a.cover_code = 'S510'
               AND b.claim_inst_type NOT IN('AK-IS','AHK-IS')
          ORDER BY b.claim_inst_type, b.claim_inst_loc; 
          
          PR_CLM_HLTH_SET_REMAINING;
