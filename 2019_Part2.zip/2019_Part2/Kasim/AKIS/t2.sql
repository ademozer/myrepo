
insert into koc_oc_hlth_ex_pack_rules
select MAIN_RULE_CODE,'35' ,  TABLE_FIELD_NAME , IS_VISIBLE,
       IS_MANDATORY, IS_DEFAULT_ZERO, ONE_MUST,IS_PARAMETER_MUST, IS_INPUT
  from koc_oc_hlth_ex_pack_rules where  sub_rule_code = '33';
  
  
  
  select * from koc_oc_hlth_ex_pack_rules where sub_rule_code=35;
  
  --select * from alz_hclm_institute_info where institute_code=8 for update
  
  select * from koc_oc_hlth_ex_pack_rul_gr;
  
  
  select * from clm_subfiles where ext_reference = '37473887'
  
  SELECT * FROM Koc_Clm_Hlth_Prov_Statemnt a WHERE a.Claim_Id = 42172725;
  SELECT * FROM Koc_Clm_Hlth_Detail WHERE claim_id= 42172725
  
  DELETE Koc_Clm_Hlth_Prov_Statemnt a 
   WHERE a.Claim_Id = 42172725
     AND STATEMENT_NO = 4066053;
     
��
����UPDATE Koc_Clm_Hlth_Detail t SET t.Cpa_Status = NULL WHERE t.Claim_Id = 42172725; 
