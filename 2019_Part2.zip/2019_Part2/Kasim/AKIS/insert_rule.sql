insert into koc_oc_hlth_ex_pack_rul_gr
select  35, 'Kurumda Teminat Limitsiz Mi', RULE_GROUP_CODE, PRIORITY, RULE_TYPE,RULE_EXPLANATION
  from koc_oc_hlth_ex_pack_rul_gr
where rule_code = '33'
/
insert into koc_oc_hlth_ex_pack_rules
select MAIN_RULE_CODE,'35' ,  TABLE_FIELD_NAME , IS_VISIBLE,
       IS_MANDATORY, IS_DEFAULT_ZERO, ONE_MUST,IS_PARAMETER_MUST, IS_INPUT,COLUMN_GROUP,COLUMN_PRIORITY
  from koc_oc_hlth_ex_pack_rules where  sub_rule_code = '33'
/
COMMIT
/
