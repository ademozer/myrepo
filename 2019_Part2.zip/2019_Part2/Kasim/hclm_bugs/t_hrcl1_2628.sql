 SELECT /*+rule*/
     a.*
      FROM Koc_v_Health_Insured_Info a
     WHERE a.Contract_Id =523686958 --IN (523686958, 522827673)
       AND a.Partition_No = 1
       AND a.Partner_Id = 82422907  
       AND a.Ip_No = 1
       AND a.Package_Id = 114682
       AND a.Package_Date = TO_DATE('03/03/2015','DD/MM/YYYY');
       
        SELECT /*+rule*/
     a.*
      FROM Koc_v_Health_Insured_Info a
     WHERE a.Contract_Id =522827673 --523686958 yeni contract
       AND a.Partition_No = 1
       AND a.Partner_Id = 82422907  
       AND a.Ip_No = 1
       AND a.Package_Id = 114682
       AND a.Package_Date = TO_DATE('03/03/2015','DD/MM/YYYY');
       
       select * from koc_ocp_risk_packages where contract_id= 522827673 and partition_no=1
       
       select * from  koc_ocp_partitions_ext where contract_id= 522827673 and partition_no=1
       
       SELECT b.Contract_Id,
             b.Oar_No,
             c.Part_Id,
             c.Ip_No,
             Package_Id,
             Package_Date
       
        FROM Koc_Clm_Hlth_Detail a, Clm_Pol_Oar b, Clm_Interested_Parties c
       WHERE a.Claim_Id = b.Claim_Id
        -- AND a.Claim_Id = p_Claim_Id
         AND a.Claim_Id = c.Claim_Id
         AND a.ext_reference = '59293212';
         
         select * from koc_clm_hlth_indem_totals where contract_id= 522827673 and partition_no=1;
         
         SELECT * FROM customer.ALZ_DUPLICATE_PROVISION WHERE EXT_REFERENCE='59293212';
         SELECT * FROM ALZ_HLTPRV_LOG WHERE LOG_ID = 144757060;
         
         SELECT * FROM alz_hclm_institute_info WHERE INSTITUTE_CODE='175' FOR UPDATE
         
         
         select * from all_source where lower(text) like '%aktif poli�esi bulunmamaktad�r%';
         
         ALZ_HLTPRV_UTILS
