select * from ocp_policy_bases where policy_ref='0001071003733900'--'0001071003693137' 

 select package_id, package_date
    from koc_ocp_risk_packages p
   where p.contract_id       = 508264414
    -- and (p.partition_no     = :control.old_partition_no or :control.old_partition_no is null)
     /*and (:control.sub_company_code is null or 
          (:control.sub_company_code is not null and 
           exists (select 1
                     from koc_ocp_partitions_ext x
                    where x.contract_id      = p.contract_id
                      and x.partition_no     = p.partition_no
                      and x.sub_company_code = :control.sub_company_code
                  )
          )
         )*/
     and not exists (select 1
                       from koc_ocp_risk_packages_sub x
                      where x.contract_id   = p.contract_id
                        and x.partition_no  = p.partition_no
                    )
   group by package_id, package_date
   union
  select sub_package_id package_id, sub_package_date package_date
    from koc_ocp_risk_packages_sub p
   where p.contract_id   = 508264414
     --and (p.partition_no = :control.old_partition_no or :control.old_partition_no is null)
     and exists (select 1
                   from koc_clm_hlth_provisions a
                      , clm_pol_oar b
                  where b.contract_id      = 508264414
                   -- and (b.oar_no          = :control.old_partition_no or :control.old_partition_no is null)
                    and a.claim_id         = b.claim_id
                    and a.sub_package_id   = p.sub_package_id
                    and a.sub_package_date = p.sub_package_date
                )
    /* and (:control.sub_company_code is null or 
          (:control.sub_company_code is not null and 
           exists (select 1
                     from koc_ocp_partitions_ext x
                    where x.contract_id      = p.contract_id
                      and x.partition_no     = p.partition_no
                      and x.sub_company_code = :control.sub_company_code
                  )
          )
         )  */   
         
         114684  4/16/2019 S511
         
         
   group by sub_package_id, sub_package_date;
   
   select * from koc_clm_hlth_indem_totals where contract_id=508264414 and partition_no=1 and cover_code='S357'
   
   
   select package_id, package_date
    from koc_ocp_risk_packages p
   where p.contract_id   = 519906051
     and p.partition_no = 1 
     and p.object_id     = (select max(pp.object_id)
                              from koc_ocp_risk_packages pp
                             where pp.contract_id  = p.contract_id
                               and pp.partition_no = p.partition_no
                               and pp.package_id   = p.package_id
                           )
     and not exists (select 1
                       from koc_ocp_risk_packages_sub x
                      where x.contract_id   = p.contract_id
                        and x.partition_no  = p.partition_no
                    )   
	 group by package_id, package_date
   union
  select sub_package_id package_id, sub_package_date package_date
    from koc_ocp_risk_packages_sub p
   where p.contract_id   =  519906051
     and p.partition_no = 1 
     and p.object_id     = (select max(pp.object_id)
                              from koc_ocp_risk_packages_sub pp
                             where pp.contract_id    = p.contract_id
                               and pp.partition_no   = p.partition_no
                               and pp.sub_package_id = p.sub_package_id
                           )
   group by sub_package_id , sub_package_date;
