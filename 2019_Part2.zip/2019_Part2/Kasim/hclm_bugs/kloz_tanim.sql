select CLAUSE_ID,MAIN_CLAUSE_ID,COUNT(*) from KOC_OC_HLTH_CLAUSES WHERE VALIDITY_END_DATE IS NULL GROUP BY CLAUSE_ID,MAIN_CLAUSE_ID HAVING COUNT(*)>1;

select count(*) from koc_oc_hlth_clauses where clause_type=1 and clause_sub_group_id is null --clause_id=7700
111 -- 2 bir birininin devam�
141 -- 2 devam
208 -- 3 devam
805 -- 2 bir tanesi silinebilir. 
3946 --2 bir tnesi �SS di�eri TSS
57  -- 3 devam
205  -- 2 devam
112  -- 2 devam
98 -- 2 devam
62 -- 2 devam
94  -- 2 devam
207 -- 2 devam
96  -- 2 devam
9081 -- 2 farkl� clauselar ayn� clause id
select * from koc_oc_hlth_clauses where clause_type=2 and clause_sub_group_id is null 
