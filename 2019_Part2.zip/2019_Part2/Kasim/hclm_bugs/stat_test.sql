DECLARE
  v_stat_id  NUMBER := null;
  v_claim_id NUMBER := 43539942;--43538944;
  v_tab      CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Trans_Tab_Type;
  
  PROCEDURE Get_Covers(In_Claim_Id     IN Koc_Clm_Hlth_Provisions.Claim_Id%TYPE,
                       In_Sf_No        IN Koc_Clm_Hlth_Provisions.Sf_No%TYPE,
                       In_Add_Order_No IN Koc_Clm_Hlth_Provisions.Add_Order_No%TYPE,
                       Out_Resultset   OUT CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Cover_Tab_Type) IS
    /*****************************************************************************

    Name:       get_covers
    Purpose:    Gets the cover codes + names

    By:         Selcuk Isnik
    Date:       2014-08-12

    Revisions:
    Date        By                       Error ID  Description
    ----------  -----------------------  --------  -------------------------------
    2014-08-12  Selcuk Isnik                       Procedure created
    ******************************************************************************/

    -- Declarations of local variables
    i NUMBER := 0;

    -- Gets the cover codes for a claim
    CURSOR c_Covers(Cin_Claim_Id     IN Koc_Clm_Hlth_Provisions.Claim_Id%TYPE,
                    Cin_Sf_No        IN Koc_Clm_Hlth_Provisions.Sf_No%TYPE,
                    Cin_Add_Order_No IN Koc_Clm_Hlth_Provisions.Add_Order_No%TYPE) IS
      SELECT DISTINCT (Prov.Cover_Code) Cover_Code,
                      Prov.Location_Code Location_Code,
                      Prov.Cover_Code || ' - ' || Substr(Tr.Long_Name, 1, 200) Cover_Name,
                      Prov.Status_Code
        FROM Koc_Clm_Hlth_Provisions Prov,
             Oc_Cover_Definitions        Def,
             Inf_v_Lang_Trans_Api_Tr     Tr
       WHERE Prov.Claim_Id = Cin_Claim_Id
         AND Prov.Sf_No = Cin_Sf_No
         AND Prov.Add_Order_No = Cin_Add_Order_No
         AND Prov.Cover_Code = Def.Cover_Code
         AND Def.Desc_Int_Id = Tr.Desc_Int_Id
       ORDER BY Prov.Cover_Code;

  BEGIN
    --------------------
    -- Fill PL-table
    --------------------
    OPEN c_Covers(In_Claim_Id, In_Sf_No, In_Add_Order_No);

    LOOP
      i := i + 1;
      FETCH c_Covers
        INTO Out_Resultset(i);
      EXIT WHEN c_Covers%NOTFOUND;
    END LOOP;

    CLOSE c_Covers;

  END;
  
  FUNCTION Getitemname(p_Ubb_Code VARCHAR2) RETURN VARCHAR2 IS
    /*****************************************************************************
    Name:       getItemName
    Purpose:    Returns the   item name
    By:         Mustafa Kucuk
    Date:       2014-10-20

    Revisions:
    Date        By                       Error ID  Description
    ----------  -----------------------  --------  -------------------------------
    2014-10-20  Mustafa Kucuk                      Procedure created
    ******************************************************************************/
    v_Process_Desc Koc_Hlth_Gmdn_Ubb_List.Material_Name%TYPE;
  BEGIN
    BEGIN
      SELECT Material_Name INTO v_Process_Desc FROM Koc_Hlth_Gmdn_Ubb_List WHERE Ubb_Code = p_Ubb_Code;
    EXCEPTION
      WHEN No_Data_Found THEN
        RETURN NULL;
      WHEN Too_Many_Rows THEN
        SELECT Material_Name
          INTO v_Process_Desc
          FROM Koc_Hlth_Gmdn_Ubb_List
         WHERE Ubb_Code = p_Ubb_Code
           AND Rownum = 1;
      WHEN OTHERS THEN
        RETURN NULL;
    END;

    RETURN v_Process_Desc;

  END;
  
  FUNCTION Getmedicinename(p_Barcode Koc_Cc_Medicines.Barcode%TYPE) RETURN VARCHAR2 IS
    /*****************************************************************************
    Name:       getMedicineName
    Purpose:    Returns the   item name
    By:         Mustafa Kucuk
    Date:       2014-10-20

    Revisions:
    Date        By                       Error ID  Description
    ----------  -----------------------  --------  -------------------------------
    2014-10-20  Mustafa Kucuk                      Procedure created
    ******************************************************************************/
    v_Medicine_Name Koc_Cc_Medicines.Medicine_Name%TYPE;
  BEGIN

    BEGIN
      SELECT Medicine_Name
        INTO v_Medicine_Name
        FROM Koc_Cc_Medicines
       WHERE Barcode = p_Barcode
         AND Validity_Date = (SELECT MAX(Validity_Date) FROM Koc_Cc_Medicines WHERE Barcode = p_Barcode);
    EXCEPTION
      WHEN No_Data_Found THEN
        RETURN NULL;
      WHEN Too_Many_Rows THEN
        SELECT Medicine_Name
          INTO v_Medicine_Name
          FROM Koc_Cc_Medicines
         WHERE Barcode = p_Barcode
           AND Validity_Date = (SELECT MAX(Validity_Date) FROM Koc_Cc_Medicines WHERE Barcode = p_Barcode)
           AND Rownum = 1;
      WHEN OTHERS THEN
        RETURN NULL;
    END;

    RETURN v_Medicine_Name;

  END;

  PROCEDURE Get_Trans(In_Stat_Id        IN NUMBER,
                      In_Filter_Rec     IN Alz_Hltprv_Sort_Filter.Cs_Filter_Rec_Type,
                      In_Sort_Rec       IN Alz_Hltprv_Sort_Filter.Cs_Sort_Rec_Type,
                      In_Claim_Id       IN Koc_Clm_Hlth_Provisions.Claim_Id%TYPE,
                      In_Sf_No          IN Koc_Clm_Hlth_Provisions.Sf_No%TYPE,
                      In_Add_Order_No   IN Koc_Clm_Hlth_Provisions.Add_Order_No%TYPE,
                      In_Provision_Date IN DATE DEFAULT SYSDATE,
                      Out_Resultset     OUT CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Trans_Tab_Type) IS
    /*****************************************************************************

    Name:       get_trans
    Purpose:    Gets statement transactions for stat_id
                filter_rec and sort_rec is implemented so that the procedure can be used with
                filtering and sorting functionaliry for ther projects.

    By:         Mustafa KUCUK
    Date:       2014-08-06

    Revisions:
    Date        By                       Error ID  Description
    ----------  -----------------------  --------  -------------------------------
    2014-08-06  Mustafa KUCUK                      Procedure created
    ******************************************************************************/

    -- Declarations of local variables
    i                 NUMBER := 0;
    v_Empty_Trans_Tab CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Trans_Tab_Type;
    -- Get exception columns for exceptin_id

    CURSOR c_Process(Cp_Claim_Id     Koc_Clm_Hlth_Tmp_Proc_Detail.Claim_Id%TYPE,
                     Cp_Sf_No        Koc_Clm_Hlth_Tmp_Proc_Detail.Sf_No%TYPE,
                     Cp_Add_Order_No Koc_Clm_Hlth_Tmp_Proc_Detail.Add_Order_No%TYPE,
                     Cp_Cover_Code   Koc_Clm_Hlth_Tmp_Proc_Detail.Cover_Code%TYPE) IS
      SELECT *
        FROM Koc_Clm_Hlth_Tmp_Proc_Detail
       WHERE 1 = 1
         AND Claim_Id = Cp_Claim_Id
         AND Sf_No = Cp_Sf_No
         AND Add_Order_No = Cp_Add_Order_No
         AND Cover_Code = Cp_Cover_Code;

    CURSOR c_Items(Cp_Claim_Id     Koc_Clm_Hlth_Tmp_Item_Detail.Claim_Id%TYPE,
                   Cp_Sf_No        Koc_Clm_Hlth_Tmp_Item_Detail.Sf_No%TYPE,
                   Cp_Add_Order_No Koc_Clm_Hlth_Tmp_Item_Detail.Add_Order_No%TYPE,
                   Cp_Cover_Code   Koc_Clm_Hlth_Tmp_Item_Detail.Cover_Code%TYPE) IS
      SELECT *
        FROM Koc_Clm_Hlth_Tmp_Item_Detail
       WHERE 1 = 1
         AND Claim_Id = Cp_Claim_Id
         AND Sf_No = Cp_Sf_No
         AND Add_Order_No = Cp_Add_Order_No
         AND Cover_Code = Cp_Cover_Code;

    CURSOR c_Medicine(Cp_Claim_Id     Koc_Clm_Tmp_Medicine_Indem_Det.Claim_Id%TYPE,
                      Cp_Sf_No        Koc_Clm_Tmp_Medicine_Indem_Det.Sf_No%TYPE,
                      Cp_Add_Order_No Koc_Clm_Tmp_Medicine_Indem_Det.Add_Order_No%TYPE,
                      Cp_Cover_Code   Koc_Clm_Tmp_Medicine_Indem_Det.Cover_Code%TYPE) IS
      SELECT *
        FROM Koc_Clm_Tmp_Medicine_Indem_Det
       WHERE 1 = 1
         AND Claim_Id = Cp_Claim_Id
         AND Sf_No = Cp_Sf_No
         AND Add_Order_No = Cp_Add_Order_No
         AND Cover_Code = Cp_Cover_Code;

    --
    CURSOR c_Reject_Loss(Cp_Claim_Id     Koc_Clm_Hlth_Tmp_Reject_Loss.Claim_Id%TYPE,
                         Cp_Sf_No        Koc_Clm_Hlth_Tmp_Reject_Loss.Sf_No%TYPE,
                         Cp_Add_Order_No Koc_Clm_Hlth_Tmp_Reject_Loss.Add_Order_No%TYPE) IS
      SELECT Refuse_Amount,
             Nvl(Main_Code, 0) || '.' || Nvl(Item_Code, 0) || '.' || Nvl(Sub_Item_Code, 0) Refuse_Code,
             Refuse_Explanation,
             Is_Bre_Decision,
             Cover_Code,
             (CASE
               WHEN Ubb_Code <> '0' AND
                    Barcode = 0 AND
                    Process_Code_Main = 0 THEN
                Ubb_Code
               WHEN Ubb_Code = '0' AND
                    Barcode <> 0 AND
                    Process_Code_Main = 0 THEN
                To_Char(Barcode)
               WHEN Ubb_Code = '0' AND
                    Barcode = 0 AND
                    Process_Code_Main <> 0 THEN
                Process_Code_Main || '.' || Process_Code_Sub1 || '.' || Process_Code_Sub2
               WHEN Ubb_Code = '0' AND
                    Barcode = 0 AND
                    Process_Code_Main = 0 THEN
                '0'
             END) AS Ubb_Code,
             Seq_No
        FROM Koc_Clm_Hlth_Tmp_Reject_Loss
       WHERE 1 = 1
         AND Claim_Id = Cp_Claim_Id
         AND Sf_No = Cp_Sf_No
         AND Add_Order_No = Cp_Add_Order_No;

    c_Processrow    c_Process%ROWTYPE;
    c_Itemsrow      c_Items%ROWTYPE;
    c_Medicinerow   c_Medicine%ROWTYPE;
    c_Rejectlossrow c_Reject_Loss%ROWTYPE;

    --
    v_Coverrow CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Cover_Tab_Type;

    --
    Rec_Num_Proc        NUMBER := 0;
    v_Doctor_Name       VARCHAR2(500);
    v_Specialty_Subject VARCHAR2(500);
    v_Process_Desc      VARCHAR2(500);
    v_Proc_Code         VARCHAR2(30);

    v_Process_Price NUMBER := 0;
    v_step              VARCHAR2(1000);
  BEGIN
    --------------------
    -- Fill PL-table
    --------------------
    v_step := '1';
    --Get claims' covers for looping claim data
    --CUSTOMER.ALZ_HLTPRV_FORM_UTILS.
    Get_Covers(In_Claim_Id, In_Sf_No, In_Add_Order_No, v_Coverrow);
    DBMS_OUTPUT.PUT_LINE('Teminat Say�s�:'||TO_CHAR(NVL(v_Coverrow.Count,0))); 
    --Level 1 Find Cover Data
    IF v_Coverrow.Count > 0
    THEN
      v_step := v_step||':2_adet='||TO_CHAR(v_Coverrow.Count);
      FOR i IN 1 .. v_Coverrow.Count
      LOOP

        --Level 2 Find Process Data
        FOR c_Processrow IN c_Process(In_Claim_Id, In_Sf_No, In_Add_Order_No, v_Coverrow(i).Cover_Code)
        LOOP
          v_step := v_step||':3';
          Rec_Num_Proc := Rec_Num_Proc + 1;

          --mustafaku T3435415
          IF Nvl(c_Processrow.Indemnity_Amount, 0) <= Nvl(c_Processrow.Inst_Indemnity_Amount, 0)
          THEN
            v_Process_Price := Nvl(c_Processrow.Indemnity_Amount, 0);
          ELSE
            v_Process_Price := Nvl(c_Processrow.Inst_Indemnity_Amount, 0);
          END IF;

          Out_Resultset(Rec_Num_Proc).Trans_Surgery_Id := Nvl(c_Processrow.Surgery_Id, 0);
          IF Out_Resultset(Rec_Num_Proc).Trans_Surgery_Id <> 0
          THEN
            CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Get_Surgery_Type(c_Processrow.Claim_Id, c_Processrow.Sf_No, c_Processrow.Add_Order_No, c_Processrow.Surgery_Id,
                             Out_Resultset(Rec_Num_Proc).Trans_Is_Robotic_Surgery, Out_Resultset(Rec_Num_Proc).Trans_Is_Laparoscopic_Surgery);
          END IF;
          v_step := v_step||':4'; 
          CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Getdoctorinfo(In_Claim_Id, c_Processrow.Doctor_Code, In_Provision_Date, v_Doctor_Name, v_Specialty_Subject);
       
          v_Process_Desc := Koc_Clm_Hlth_Utils.Getprocessdesc(c_Processrow.Process_Code_Main, c_Processrow.Process_Code_Sub1,
                                                              c_Processrow.Process_Code_Sub2, In_Provision_Date);
          v_Proc_Code    := c_Processrow.Process_Code_Main || '.' || c_Processrow.Process_Code_Sub1 || '.' || c_Processrow.Process_Code_Sub2;
          v_step := v_step||':5';
          Out_Resultset(Rec_Num_Proc).Trans_Id := Rec_Num_Proc;
          Out_Resultset(Rec_Num_Proc).Transcat_Code := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Transcat_Code_Operation;
          Out_Resultset(Rec_Num_Proc).Trans_Date := Trunc(c_Processrow.Entrance_Date);
          Out_Resultset(Rec_Num_Proc).Trans_Location_Code := c_Processrow.Location_Code;
          Out_Resultset(Rec_Num_Proc).Trans_Ubb_Code := v_Proc_Code;
          Out_Resultset(Rec_Num_Proc).Transtyp_Stamsge := v_Process_Desc;
          Out_Resultset(Rec_Num_Proc).Trans_Qty := Nvl(c_Processrow.Process_Count, 1);

          --1.10.102 de kurum talebi ge�erlidir anlasmali fiyat yok.

          /*    --mustafaku T3435415                  IF v_Proc_Code = '1.10.102'
          THEN
              Out_Resultset(Rec_Num_Proc).Trans_Qty_Amo :=   Nvl(c_Processrow.Inst_Indemnity_Amount, 0);
              Out_Resultset(Rec_Num_Proc).Trans_Amo := Out_Resultset(Rec_Num_Proc).Trans_Qty * Out_Resultset(Rec_Num_Proc).Trans_Qty_Amo;
          ELSE
              Out_Resultset(Rec_Num_Proc).Trans_Qty_Amo :=  Nvl(c_Processrow.Indemnity_Amount, 0);
              Out_Resultset(Rec_Num_Proc).Trans_Amo := Nvl(c_Processrow.Process_Count, 1) *  Nvl(c_Processrow.Inst_Indemnity_Amount, 0);
          END IF;*/

          IF v_Proc_Code = '1.10.102'
          THEN
            Out_Resultset(Rec_Num_Proc).Trans_Qty_Amo := v_Process_Price;
            Out_Resultset(Rec_Num_Proc).Trans_Amo := Out_Resultset(Rec_Num_Proc).Trans_Qty * v_Process_Price;
          ELSE
            Out_Resultset(Rec_Num_Proc).Trans_Qty_Amo := Nvl(c_Processrow.Indemnity_Amount, 0);
            Out_Resultset(Rec_Num_Proc).Trans_Amo := Nvl(c_Processrow.Process_Count, 1) * v_Process_Price;
          END IF;
          v_step := v_step||':6';
          IF c_Processrow.Status_Code IN (CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_r, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_Pr, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_Cpr)
          THEN
            IF Nvl(c_Processrow.Bre_Result_Code, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control) <> CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control
            THEN
              Out_Resultset(Rec_Num_Proc).Trans_Result_Code := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Aut_Reject;
              Out_Resultset(Rec_Num_Proc).Trans_Result_Name := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Aut_Reject_Name;
            ELSIF Nvl(c_Processrow.Bre_Result_Code, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control) = CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control
            THEN
              Out_Resultset(Rec_Num_Proc).Trans_Result_Code := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Man_Reject;
              Out_Resultset(Rec_Num_Proc).Trans_Result_Name := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Man_Reject_Name;
            END IF;

            c_Rejectlossrow.Refuse_Code := NULL;
          ELSIF c_Processrow.Status_Code IN (CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_p, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_Cp, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_Pp)
          THEN
            IF Nvl(c_Processrow.Bre_Result_Code, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control) <> CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control
            THEN
              Out_Resultset(Rec_Num_Proc).Trans_Result_Code := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Aut_Appove;
              Out_Resultset(Rec_Num_Proc).Trans_Result_Name := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Aut_Appove_Name;
            ELSIF Nvl(c_Processrow.Bre_Result_Code, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control) = CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control
            THEN
              Out_Resultset(Rec_Num_Proc).Trans_Result_Code := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Man_Approve;
              Out_Resultset(Rec_Num_Proc).Trans_Result_Name := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Man_Approve_Name;
            END IF;

            --mustafaku T3435415 Out_Resultset(Rec_Num_Proc).Trans_Amo_Approved := c_Processrow.Process_Count * c_Processrow.Inst_Indemnity_Amount; --c_ProcessRow.process_count * c_ProcessRow.indemnity_amount ;
            Out_Resultset(Rec_Num_Proc).Trans_Amo_Approved := c_Processrow.Process_Count * v_Process_Price;

          ELSIF c_Processrow.Status_Code IN (CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_c)
          THEN
            Out_Resultset(Rec_Num_Proc).Trans_Result_Code := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_c;
            Out_Resultset(Rec_Num_Proc).Trans_Result_Name := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_Desc_c;
            Out_Resultset(Rec_Num_Proc).Trans_Amo_Approved := 0;
          END IF;
          v_step := v_step||':7';  
          Out_Resultset(Rec_Num_Proc).Trans_Charge_Desc := NULL; --c_ProcessRow.    ;
          Out_Resultset(Rec_Num_Proc).Trans_Dr_Branch := v_Specialty_Subject;
          Out_Resultset(Rec_Num_Proc).Trans_Dr_Name := v_Doctor_Name;
          Out_Resultset(Rec_Num_Proc).Trans_Ttb_Unit := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Get_Tda_Coefficient(c_Processrow.Process_Code_Main, c_Processrow.Process_Code_Sub1,
                                                                            c_Processrow.Process_Code_Sub2);
          Out_Resultset(Rec_Num_Proc).Trans_Result_Rep := NULL; --c_ProcessRow.    ;
          Out_Resultset(Rec_Num_Proc).Trans_Assurance_Code := v_Coverrow(i).Cover_Code;
          Out_Resultset(Rec_Num_Proc).Trans_Org_Ass_Code := v_Coverrow(i).Cover_Code;
          Out_Resultset(Rec_Num_Proc).Trans_Location_Code := v_Coverrow(i).Location_Code;
          Out_Resultset(Rec_Num_Proc).Trans_Assurance_Name := v_Coverrow(i).Cover_Name;
          Out_Resultset(Rec_Num_Proc).Trans_Note := c_Processrow.Explanation; --c_ProcessRow.    ;
          Out_Resultset(Rec_Num_Proc).Trans_Price_Level := NULL; --c_ProcessRow.    ;
          Out_Resultset(Rec_Num_Proc).Trans_Notice_Text := c_Processrow.Explanation;
          Out_Resultset(Rec_Num_Proc).Trans_Result_Upd := NULL;
          Out_Resultset(Rec_Num_Proc).Trans_Assurance_Upd := NULL;
          CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Gettransalerts(Out_Resultset(Rec_Num_Proc).Transcat_Code, Out_Resultset(Rec_Num_Proc).Trans_Ubb_Code,
                         Out_Resultset(Rec_Num_Proc).Trans_Alerts);
          Out_Resultset(Rec_Num_Proc).Trans_Seq_No := c_Processrow.Seq_No;
        END LOOP;
        v_step := v_step||':8'; 
        --Level 3  Find Items Data
        FOR c_Itemsrow IN c_Items(In_Claim_Id, In_Sf_No, In_Add_Order_No, v_Coverrow(i).Cover_Code)
        LOOP

          Rec_Num_Proc   := Rec_Num_Proc + 1;
          v_Process_Desc := Getitemname(c_Itemsrow.Ubb_Code);

          Out_Resultset(Rec_Num_Proc).Trans_Id := Rec_Num_Proc; --c_ProcessRow.    ;
          Out_Resultset(Rec_Num_Proc).Transcat_Code := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Transcat_Code_Item;
          Out_Resultset(Rec_Num_Proc).Trans_Location_Code := c_Itemsrow.Location_Code;
          Out_Resultset(Rec_Num_Proc).Trans_Date := Trunc(c_Itemsrow.Time_Stamp);
          Out_Resultset(Rec_Num_Proc).Trans_Ubb_Code := c_Itemsrow.Ubb_Code;
          Out_Resultset(Rec_Num_Proc).Transtyp_Stamsge := v_Process_Desc;
          Out_Resultset(Rec_Num_Proc).Trans_Qty := Nvl(c_Itemsrow.Quantity, 1);
          Out_Resultset(Rec_Num_Proc).Trans_Qty_Amo := Nvl(c_Itemsrow.Price, 0);
          Out_Resultset(Rec_Num_Proc).Trans_Amo := Out_Resultset(Rec_Num_Proc).Trans_Qty * Out_Resultset(Rec_Num_Proc).Trans_Qty_Amo;
          --
          IF c_Itemsrow.Status_Code IN (CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_r, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_Pr, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_Cpr)
          THEN
            IF Nvl(c_Itemsrow.Bre_Result_Code, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control) <> CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control
            THEN
              Out_Resultset(Rec_Num_Proc).Trans_Result_Code := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Aut_Reject;
              Out_Resultset(Rec_Num_Proc).Trans_Result_Name := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Aut_Reject_Name;
            ELSIF Nvl(c_Itemsrow.Bre_Result_Code, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control) = CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control
            THEN
              Out_Resultset(Rec_Num_Proc).Trans_Result_Code := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Man_Reject;
              Out_Resultset(Rec_Num_Proc).Trans_Result_Name := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Man_Reject_Name;
            END IF;
            c_Rejectlossrow.Refuse_Code := NULL;
          ELSIF c_Itemsrow.Status_Code IN (CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_p, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_Cp, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_Pp)
          THEN
            IF Nvl(c_Itemsrow.Bre_Result_Code, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control) <> CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control
            THEN
              Out_Resultset(Rec_Num_Proc).Trans_Result_Code := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Aut_Appove;
              Out_Resultset(Rec_Num_Proc).Trans_Result_Name := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Aut_Appove_Name;
            ELSIF Nvl(c_Itemsrow.Bre_Result_Code, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control) = CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control
            THEN
              Out_Resultset(Rec_Num_Proc).Trans_Result_Code := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Man_Approve;
              Out_Resultset(Rec_Num_Proc).Trans_Result_Name := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Man_Approve_Name;
            END IF;
            Out_Resultset(Rec_Num_Proc).Trans_Amo_Approved := c_Itemsrow.Quantity * c_Itemsrow.Price;
          ELSIF c_Itemsrow.Status_Code IN (CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_c)
          THEN
            Out_Resultset(Rec_Num_Proc).Trans_Result_Code := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_c;
            Out_Resultset(Rec_Num_Proc).Trans_Result_Name := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_Desc_c;
            Out_Resultset(Rec_Num_Proc).Trans_Amo_Approved := 0;
          END IF;
          v_step := v_step||':9';
          Out_Resultset(Rec_Num_Proc).Trans_Seq_No := c_Itemsrow.Seq_No;
          Out_Resultset(Rec_Num_Proc).Trans_Charge_Desc := NULL; --c_ProcessRow.    ;
          Out_Resultset(Rec_Num_Proc).Trans_Dr_Branch := NULL; --v_specialty_subject    ;
          Out_Resultset(Rec_Num_Proc).Trans_Dr_Name := NULL; --v_doctor_name    ;
          Out_Resultset(Rec_Num_Proc).Trans_Ttb_Unit := NULL; --c_ProcessRow.    ;
          Out_Resultset(Rec_Num_Proc).Trans_Result_Rep := NULL; --c_ProcessRow.    ;
          Out_Resultset(Rec_Num_Proc).Trans_Assurance_Code := v_Coverrow(i).Cover_Code;
          Out_Resultset(Rec_Num_Proc).Trans_Org_Ass_Code := v_Coverrow(i).Cover_Code;
          Out_Resultset(Rec_Num_Proc).Trans_Location_Code := v_Coverrow(i).Location_Code;
          Out_Resultset(Rec_Num_Proc).Trans_Assurance_Name := v_Coverrow(i).Cover_Name;
          Out_Resultset(Rec_Num_Proc).Trans_Note := c_Itemsrow.Explanation;
          Out_Resultset(Rec_Num_Proc).Trans_Price_Level := NULL; --c_ProcessRow.    ;
          Out_Resultset(Rec_Num_Proc).Trans_Notice_Text := c_Itemsrow.Explanation;
          Out_Resultset(Rec_Num_Proc).Trans_Result_Upd := NULL; --c_ProcessRow.    ;
          Out_Resultset(Rec_Num_Proc).Trans_Assurance_Upd := NULL; --c_ProcessRow.    ;
          CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Gettransalerts(Out_Resultset(Rec_Num_Proc).Transcat_Code, Out_Resultset(Rec_Num_Proc).Trans_Ubb_Code,
                         Out_Resultset(Rec_Num_Proc).Trans_Alerts);
        END LOOP;
        v_step := v_step||':10';  
        --Level 4  Find Medicine Data
        FOR c_Medicinerow IN c_Medicine(In_Claim_Id, In_Sf_No, In_Add_Order_No, v_Coverrow(i).Cover_Code)
        LOOP
          --
          Rec_Num_Proc := Rec_Num_Proc + 1;
          v_Process_Desc := Getmedicinename(c_Medicinerow.Barcode);
          Out_Resultset(Rec_Num_Proc).Trans_Id := Rec_Num_Proc; --c_ProcessRow.    ;
          Out_Resultset(Rec_Num_Proc).Transcat_Code := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Transcat_Code_Medicine;
          Out_Resultset(Rec_Num_Proc).Trans_Location_Code := c_Medicinerow.Location_Code;
          Out_Resultset(Rec_Num_Proc).Trans_Date := Trunc(c_Medicinerow.Time_Stamp);
          Out_Resultset(Rec_Num_Proc).Trans_Ubb_Code := c_Medicinerow.Barcode;
          Out_Resultset(Rec_Num_Proc).Transtyp_Stamsge := v_Process_Desc;
          Out_Resultset(Rec_Num_Proc).Trans_Qty := Nvl(c_Medicinerow.Unit, 1);
          Out_Resultset(Rec_Num_Proc).Trans_Qty_Amo := Nvl(c_Medicinerow.Price, 0);
          Out_Resultset(Rec_Num_Proc).Trans_Amo := Out_Resultset(Rec_Num_Proc).Trans_Qty * Out_Resultset(Rec_Num_Proc).Trans_Qty_Amo;
          --
          IF c_Medicinerow.Status_Code IN (CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_r, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_Pr, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_Cpr)
          THEN
            IF Nvl(c_Medicinerow.Bre_Result_Code, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control) <> CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control
            THEN
              Out_Resultset(Rec_Num_Proc).Trans_Result_Code := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Aut_Reject;
              Out_Resultset(Rec_Num_Proc).Trans_Result_Name := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Aut_Reject_Name;
            ELSIF Nvl(c_Medicinerow.Bre_Result_Code, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control) = CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control
            THEN
              Out_Resultset(Rec_Num_Proc).Trans_Result_Code := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Man_Reject;
              Out_Resultset(Rec_Num_Proc).Trans_Result_Name := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Man_Reject_Name;
            END IF;

            c_Rejectlossrow.Refuse_Code := NULL;
          ELSIF c_Medicinerow.Status_Code IN (CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_p, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_Cp, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_Pp)
          THEN
            IF Nvl(c_Medicinerow.Bre_Result_Code, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control) <> CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control
            THEN
              Out_Resultset(Rec_Num_Proc).Trans_Result_Code := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Aut_Appove;
              Out_Resultset(Rec_Num_Proc).Trans_Result_Name := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Aut_Appove_Name;
            ELSIF Nvl(c_Medicinerow.Bre_Result_Code, CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control) = CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Null_Control
            THEN
              Out_Resultset(Rec_Num_Proc).Trans_Result_Code := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Man_Approve;
              Out_Resultset(Rec_Num_Proc).Trans_Result_Name := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Man_Approve_Name;
            END IF;

            Out_Resultset(Rec_Num_Proc).Trans_Amo_Approved := (c_Medicinerow.Unit - Nvl(c_Medicinerow.Reject_Unit, 0)) * c_Medicinerow.Price;
          ELSIF c_Medicinerow.Status_Code IN (CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_c)
          THEN
            Out_Resultset(Rec_Num_Proc).Trans_Result_Code := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_c;
            Out_Resultset(Rec_Num_Proc).Trans_Result_Name := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Status_Code_Desc_c;
            Out_Resultset(Rec_Num_Proc).Trans_Amo_Approved := 0;

          END IF;
          v_step := v_step||':11';
          Out_Resultset(Rec_Num_Proc).Trans_Seq_No := c_Medicinerow.Seq_No;
          Out_Resultset(Rec_Num_Proc).Trans_Charge_Desc := NULL; --c_ProcessRow.    ;
          Out_Resultset(Rec_Num_Proc).Trans_Dr_Branch := NULL; -- v_specialty_subject    ;
          Out_Resultset(Rec_Num_Proc).Trans_Dr_Name := NULL; -- v_doctor_name    ;
          Out_Resultset(Rec_Num_Proc).Trans_Ttb_Unit := NULL; --c_ProcessRow.    ;
          Out_Resultset(Rec_Num_Proc).Trans_Result_Rep := NULL; --c_ProcessRow.    ;
          Out_Resultset(Rec_Num_Proc).Trans_Assurance_Code := v_Coverrow(i).Cover_Code;
          Out_Resultset(Rec_Num_Proc).Trans_Org_Ass_Code := v_Coverrow(i).Cover_Code;
          Out_Resultset(Rec_Num_Proc).Trans_Location_Code := v_Coverrow(i).Location_Code;
          Out_Resultset(Rec_Num_Proc).Trans_Assurance_Name := v_Coverrow(i).Cover_Name;
          Out_Resultset(Rec_Num_Proc).Trans_Note := c_Medicinerow.Reject_Explanation;
          Out_Resultset(Rec_Num_Proc).Trans_Price_Level := NULL; --c_ProcessRow.    ;
          Out_Resultset(Rec_Num_Proc).Trans_Notice_Text := c_Medicinerow.Explanation;
          Out_Resultset(Rec_Num_Proc).Trans_Result_Upd := NULL; --c_ProcessRow.    ;
          Out_Resultset(Rec_Num_Proc).Trans_Assurance_Upd := NULL; --c_ProcessRow.    ;
          CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Gettransalerts(Out_Resultset(Rec_Num_Proc).Transcat_Code, Out_Resultset(Rec_Num_Proc).Trans_Ubb_Code,
                         Out_Resultset(Rec_Num_Proc).Trans_Alerts);
        END LOOP;
        --
      END LOOP;
      v_step := v_step||':12';    
      --RejectLossData
      FOR c_Rejectlossrow IN c_Reject_Loss(In_Claim_Id, In_Sf_No, In_Add_Order_No)
      LOOP

        IF Nvl(c_Rejectlossrow.Ubb_Code, 0) <> '0'
        THEN

          FOR Rec_Num_Proc IN 1 .. Out_Resultset.Count
          LOOP

            IF Out_Resultset(Rec_Num_Proc).Trans_Assurance_Code = c_Rejectlossrow.Cover_Code AND
               Out_Resultset(Rec_Num_Proc).Trans_Ubb_Code = c_Rejectlossrow.Ubb_Code AND
                Nvl(Out_Resultset(Rec_Num_Proc).Trans_Seq_No, 1) = Nvl(c_Rejectlossrow.Seq_No, 1)
            THEN
              -- red edilenler

              Out_Resultset(Rec_Num_Proc).Trans_Reject_Reason := c_Rejectlossrow.Refuse_Code;
              Out_Resultset(Rec_Num_Proc).Trans_Reject_Desc := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Getrejectcodedesc(c_Rejectlossrow.Refuse_Code);

              IF Nvl(c_Rejectlossrow.Is_Bre_Decision, 0) = CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Man_Bre_Reject
              THEN
                Out_Resultset(Rec_Num_Proc).Trans_Result_Code := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Aut_Reject;
                Out_Resultset(Rec_Num_Proc).Trans_Result_Name := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Aut_Reject_Name;
              ELSE
                Out_Resultset(Rec_Num_Proc).Trans_Result_Code := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Man_Reject;
                Out_Resultset(Rec_Num_Proc).Trans_Result_Name := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Man_Reject_Name;
              END IF;

              IF Out_Resultset(Rec_Num_Proc).Trans_Reject_Reason LIKE '16.12.%'
              THEN

                Out_Resultset(Rec_Num_Proc).Trans_Amo_Reject_Inst := c_Rejectlossrow.Refuse_Amount;
                Out_Resultset(Rec_Num_Proc).Trans_Amo_Rejected := 0;
              ELSE
                Out_Resultset(Rec_Num_Proc).Trans_Amo_Reject_Inst := 0;
                Out_Resultset(Rec_Num_Proc).Trans_Amo_Rejected := c_Rejectlossrow.Refuse_Amount;
              END IF;

            END IF;
          END LOOP;
        ELSIF Nvl(c_Rejectlossrow.Ubb_Code, 0) = '0'
        THEN
          --Teminata bagli olarak red etme
          v_step := v_step||':13';   
          FOR Rec_Num_Proc IN 1 .. Out_Resultset.Count
          LOOP
            NULL;
            /* if out_resultset (rec_num_proc).trans_assurance_code  = c_rejectlossrow.cover_code  then -- red edilenler
              out_resultset (rec_num_proc).trans_reject_reason   := c_rejectlossrow.refuse_code;
              out_resultset (rec_num_proc).trans_reject_desc     := getRejectCodeDesc(c_rejectlossrow.refuse_code);

              if  nvl(c_rejectlossrow.is_bre_decision,0)  =  ct_man_bre_reject  then
                  out_resultset (rec_num_proc).trans_result_code     := ct_aut_reject ;
                  out_resultset (rec_num_proc).trans_result_name     := ct_aut_reject_name;
              else
                  out_resultset (rec_num_proc).trans_result_code     := ct_man_reject ;
                  out_resultset (rec_num_proc).trans_result_name     := ct_man_reject_name;
              end if;

            end if;

            if out_resultset (rec_num_proc).trans_reject_reason like '16.12.%' then
               out_resultset (rec_num_proc).trans_amo_reject_inst := c_rejectlossrow.refuse_amount;
               out_resultset (rec_num_proc).trans_amo_rejected      := 0;
            else
               out_resultset (rec_num_proc).trans_amo_rejected      := c_rejectlossrow.refuse_amount;
               out_resultset (rec_num_proc).trans_amo_reject_inst := 0;
            end if;*/

          END LOOP;
        ELSIF Nvl(c_Rejectlossrow.Cover_Code, 0) = '0' AND
              Nvl(c_Rejectlossrow.Ubb_Code, 0) = '0'
        THEN
          --Dosyadan red etme
          v_step := v_step||':14'; 
          FOR Rec_Num_Proc IN 1 .. Out_Resultset.Count
          LOOP
            Out_Resultset(Rec_Num_Proc).Trans_Reject_Reason := c_Rejectlossrow.Refuse_Code;
            Out_Resultset(Rec_Num_Proc).Trans_Reject_Desc := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Getrejectcodedesc(c_Rejectlossrow.Refuse_Code);

            IF Nvl(c_Rejectlossrow.Is_Bre_Decision, 0) = CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Man_Bre_Reject
            THEN
              Out_Resultset(Rec_Num_Proc).Trans_Result_Code := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Aut_Reject;
              Out_Resultset(Rec_Num_Proc).Trans_Result_Name := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Aut_Reject_Name;
            ELSE
              Out_Resultset(Rec_Num_Proc).Trans_Result_Code := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Man_Reject;
              Out_Resultset(Rec_Num_Proc).Trans_Result_Name := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Ct_Man_Reject_Name;
            END IF;

            IF Out_Resultset(Rec_Num_Proc).Trans_Reject_Reason LIKE '16.12.%'
            THEN
              Out_Resultset(Rec_Num_Proc).Trans_Amo_Reject_Inst := c_Rejectlossrow.Refuse_Amount;
              Out_Resultset(Rec_Num_Proc).Trans_Amo_Rejected := 0;
            ELSE
              Out_Resultset(Rec_Num_Proc).Trans_Amo_Rejected := c_Rejectlossrow.Refuse_Amount;
              Out_Resultset(Rec_Num_Proc).Trans_Amo_Reject_Inst := 0;
            END IF;

          END LOOP;
        END IF;

      END LOOP;
      ---RejectLossData-

    END IF;
    v_step := v_step||':15';
    /* Should the data be filtered */
    IF In_Filter_Rec.Filter_Column IS NOT NULL
    THEN
      CUSTOMER.ALZ_HLTPRV_FORM_UTILS.g_Trans_Tab_1 := Out_Resultset;
      CUSTOMER.ALZ_HLTPRV_FORM_UTILS.g_Trans_Tab_2 := v_Empty_Trans_Tab;
      -- Filtering the input table
      Alz_Hltprv_Sort_Filter.Filter_Table('alz_hltprv_form_utils.g_trans_tab_1', 'alz_hltprv_form_utils.g_trans_tab_2', In_Filter_Rec);
      Out_Resultset := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.g_Trans_Tab_2;
    END IF;
    v_step := v_step||':16';
    /* Should the data be sorted */
    IF In_Sort_Rec.Sort_Column IS NOT NULL
    THEN
      CUSTOMER.ALZ_HLTPRV_FORM_UTILS.g_Trans_Tab_1 := Out_Resultset;
      -- Sort the incoming table
      Alz_Hltprv_Sort_Filter.Sort_Table('alz_hltprv_form_utils.g_trans_tab_1', 'alz_hltprv_form_utils.trans_tab_type', In_Sort_Rec);
      Out_Resultset := CUSTOMER.ALZ_HLTPRV_FORM_UTILS.g_Trans_Tab_1;
    END IF;
    v_step := v_step||':17';
    DBMS_OUTPUT.PUT_LINE(v_step);
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE(v_step);
      Raise_Application_Error(-20101, 'Data getirilmesi esnasinda hata :' || SQLERRM);
  END;

  PROCEDURE print_table(p_tab IN CUSTOMER.ALZ_HLTPRV_FORM_UTILS.Trans_Tab_Type) IS
    v_data_msg CLOB;
    v_keys_data VARCHAR2(4000);
    v_ndx number := 0;
    BEGIN
    v_data_msg := '[';
    FOR ndx IN 1..p_tab.Count LOOP
      DBMS_OUTPUT.PUT_LINE('record.'||ndx);    
    END LOOP;
  /*FOR rec_1 IN (SELECT * FROM TABLE(p_tab))    
                 LOOP        
                   DBMS_OUTPUT.PUT_LINE('record');           
                     /*IF rec_1.ROW_NO>1 THEN
                         v_data_msg := v_data_msg || ',';
                     END IF;
                     v_data_msg := v_data_msg || '{';
                     v_ndx := 0;
                     FOR rec_2 IN (SELECT EXTRACTVALUE (t.COLUMN_VALUE, '/*') AS NODE_VALUE,
                                                        t.COLUMN_VALUE.getrootelement () AS NODE_NAME
                                     FROM TABLE (XMLSEQUENCE (EXTRACT(EXTRACT(XMLTYPE(rec_1.ROW_DATA), '//*'), '/ROW/*'))) t)
                     LOOP
                        IF v_ndx>0 THEN
                           v_data_msg := v_data_msg || ',';
               IF rec_1.ROW_NO = 1 THEN
                v_keys_data := v_keys_data || ',';
               END IF;
                        END IF;
            IF rec_1.ROW_NO = 1 THEN
              v_keys_data := v_keys_data || LOWER(rec_2.NODE_NAME);
            END IF;
                        v_data_msg := v_data_msg || '"' || LOWER(rec_2.NODE_NAME) || '":"' || TRIM(rec_2.Node_Value) || '"';
                        v_ndx := v_ndx + 1;                         
                     END LOOP;
                     v_data_msg := v_data_msg || '}';*/
                 --END LOOP;     
    --DBMS_OUTPUT.PUT_LINE(v_keys_data);
    v_data_msg := v_data_msg || ']';
    DBMS_OUTPUT.PUT_LINE(v_data_msg);
  END print_table;
BEGIN
   --alz_hltprv_form_utils.
   get_trans ( v_stat_id,
                                       NULL,
                                       NULL,
                                       v_claim_id,
                                       1  ,
                                       1 ,
                                       TRUNC(SYSDATE),
                                       v_tab);
  print_table(v_tab);                                       
                                       
END;
