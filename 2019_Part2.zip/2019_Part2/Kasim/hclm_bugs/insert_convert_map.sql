insert into alz_hltprv_process_convert_map (INSTITUTE_CODE, DOCTOR_TITLE, PROCESS_CODE_FROM, PROCESS_CODE_TO)
values (6498, 'Doc', '10_10_101', '10_10_108');

insert into alz_hltprv_process_convert_map (INSTITUTE_CODE, DOCTOR_TITLE, PROCESS_CODE_FROM, PROCESS_CODE_TO)
values (6498, 'Prof', '10_10_101', '10_10_108');

COMMIT;

