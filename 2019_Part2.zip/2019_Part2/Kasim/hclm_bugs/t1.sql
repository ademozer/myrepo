﻿DECLARE 
v_contract_id NUMBER := 459580917;
PROCEDURE Is_Complementary  IS
  v_Return       NUMBER := 0;
  v_Alert_Button NUMBER;
  v_rtn          number;
  v_hosp_type    koc_clm_suppliers_ext.hospital_type%type;
  v_is_comp      NUMBER := -1;
  v_tss number;
  v_oss number;
BEGIN
 
  SELECT Nvl(Is_Complementary, 0) INTO v_Return FROM Koc_Ocp_Pol_Contracts_Ext WHERE Contract_Id = v_contract_id; --:Koc_Clm_Hlth_Detail.Contract_Id;
 -- :Koc_Clm_Hlth_Detail.hibrit := v_Return;
  
  DBMS_OUTPUT.PUT_LINE('is_complementary='||v_Return);
  
  /*
  IF :Koc_Clm_Hlth_Detail.Is_Complementary IS NULL -- neslihank CP ve PP statüsündeki durumlarda hibrit alanýný doldurmuyordu ve bu nedenle provizyon alma aþamasýnda S li ve ST li teminatlarý seçip hatasýz provizyon alabiliyordu.
  THEN
    IF v_Return = 1
    THEN
      
      :Koc_Clm_Hlth_Detail.Is_Complementary := 1;  
      
    ELSIF v_Return = 2
    THEN
      --v_Alert_Button := Show_Alert('ALERT_HIBRIT_TSS_OSS');
      IF v_Alert_Button = Alert_Button1
      THEN
        :Koc_Clm_Hlth_Detail.Is_Complementary := 1; --mustafaku TSS Flag 
        :Koc_Clm_Hlth_Detail.hibrit := 1;
      ELSIF v_Alert_Button = Alert_Button2
      THEN
        :Koc_Clm_Hlth_Detail.Is_Complementary := 0; --mustafaku TSS Flag 
      ELSE
        NULL;
      END IF;
    ELSE
    null;
    END IF;
    
  
    
  If :Koc_Clm_Hlth_Detail.Is_Complementary = 1 
    Then
      SET_ITEM_INSTANCE_PROPERTY('Koc_Clm_Hlth_Detail.Is_Complementary',CURRENT_RECORD,  VISUAL_ATTRIBUTE ,'VA_ALERT') ;  
    End If;
    
  ELSIF :Koc_Clm_Hlth_Detail.Is_Complementary = 1 AND v_Return = 2 -- neslihank hibrit poliçe ise ve ilk giriþte Hibrit butonuna basýlmýþsa üstteki kontrol gibi hibrit= 1 yapýldý. Yukardaki koþul deðiþirse bu da deðiþmeli.
  THEN
      :Koc_Clm_Hlth_Detail.hibrit := 1;
  END IF;*/
 -- IF nvl(:Koc_Clm_Hlth_Detail.Is_Complementary,0)= 0 
 IF NVL(v_Return,0) = 0 
  Then
    select customer.ALZ_HLTH_KARMA_UTILS.Tss_oss_tem_sec(63,
                                              customer.ALZ_HLTH_KARMA_UTILS.is_police_Complementary (v_contract_id),
                                              decode('TSS', 'KARMA', 2, 'TSS', 1, 'ÖSS', 0, null,0,0),
                                              918,
                                              'Tam',
                                              'ST**',
                                              v_contract_id)
       into v_rtn
       from dual;
      v_is_comp := v_rtn;
    /*if nvl(v_rtn,0) = 0 then
      :Koc_Clm_Hlth_Detail.Is_Complementary := 0;    
    else
      :Koc_Clm_Hlth_Detail.Is_Complementary := 1; --mustafaku TSS Flag 
      :Koc_Clm_Hlth_Detail.hibrit := 1;
    end if; */  
  End If;
  
  
  /*If :Koc_Clm_Hlth_Detail.Is_Complementary = 1 
    Then
      SET_ITEM_INSTANCE_PROPERTY('Koc_Clm_Hlth_Detail.Is_Complementary',CURRENT_RECORD,  VISUAL_ATTRIBUTE ,'VA_ALERT') ;  
  End If;*/
  
  customer.ALZ_HLTH_KARMA_UTILS.get_inst_anlasma (918, v_tss, v_oss );
  
  
  customer.ALZ_HLTH_KARMA_UTILS.get_inst_type (918, v_hosp_type);
  
  if v_is_comp = 1 and v_tss = 0 and v_hosp_type not in (9,10,11,14,15,16) then
    --Message('TSS Sigortalýsý ÖSS kurumda iþlem yapamaz!');
   -- Raise form_trigger_failure;
     DBMS_OUTPUT.PUT_LINE('TSS Sigortalýsý ÖSS kurumda iþlem yapamaz!');
  end if;
  
  if v_is_comp = 0 and v_oss = 0 then --ibrahimk
    --Message('Sigortalý TSS kurumda iþlem yapamaz!');
    --Raise form_trigger_failure;
    DBMS_OUTPUT.PUT_LINE('TSS Sigortalýsý ÖSS kurumda iþlem yapamaz!');
  end if;
  
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('TSS Poliçesi kontrolleri tamamlanamadý, dosya ÖSS Poliçesi olarak baþlatýlacak');
    --Opu001.Msg(999999, 'W', NULL, NULL, NULL, 'TSS Poliçesi kontrolleri tamamlanamadý, dosya ÖSS Poliçesi olarak baþlatýlacak');
END;

BEGIN
  Is_Complementary;
END;
