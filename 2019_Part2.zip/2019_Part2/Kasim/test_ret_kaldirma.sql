select * from alz_hltprv_log where log_id=145256925

SELECT * FROM koc_mv_skrm_suppliers where institute_skrs_code='532061';
--SPUABR65
--SPUABR65
--SPUABR65
SELECT ALZ_HCLM_CONVERTER_UTILS.getHclmUsage(null, null, null, 'WHBEKMEZ', null, null) FROM DUAL;

select * from koc_cp_health_look_up where look_up_code = 'HCLM_USAGE' FOR UPDATE;

select * from clm_subfiles where ext_reference='59380652'--'59381651'--'59380651'

select * from alz_hltprv_log where institutecode='532061' and content like '%IslemYapanKisi>esra.yilmaz%' 
and log_date BETWEEN TO_DATE('04/11/2019','DD/MM/YYYY') AND TO_DATE('06/11/2019','DD/MM/YYYY');

select * from koc_clm_hlth_proc_detail where claim_id IN (43538943,43504995) and status_code='R' FOR UPDATE
select * from alz_hclm_version_info where claim_id=43538943 for update
select * from koc_clm_hlth_reject_loss where claim_id IN(43538943,43504995) FOR UPDATE
select * from alz_hltprv_log where log_id=145613053;
select * from koc_clm_hlth_provisions where claim_id IN(43538943,43504995);

select * from koc_clm_hlth_reject_loss where claim_id = 43504736;

select * from alz_hclm_institute_info where institute_code=3953 for update

select * from koc_clm_hlth_detail d where d.provision_date>TO_DATE('03/11/2019','DD/MM/YYYY')
and exists (select 1 from koc_clm_hlth_reject_loss where claim_id=d.claim_id and NVL(process_code_main,0) not in (0,9) and is_bre_decision=1)
and not exists(select 1 from alz_hclm_version_info where claim_id=d.claim_id)
and exists(select 1 from koc_clm_hlth_provisions where claim_id=d.claim_id and sub_package_id is null)
and exists(select 1 from koc_clm_hlth_proc_detail where claim_id=d.claim_id and req_process_code IS NULL and status_code='R')
and status_code='P'
and REQUEST_SYSTEM IN ('WS','PORTAL')

alz_hclm_converter_utils;

alz_receipt_forms_utils.Get_FormList

     alz_hltprv_form_utils.get_trans ( :stat_head.stat_id,
                                       NULL,
                                       NULL,
                                       :claim.claim_id,
                                       :claim.sf_no   ,
                                       :claim.add_order_no ,
                                       :claim.provision_date,
                                       v_tab) ;
