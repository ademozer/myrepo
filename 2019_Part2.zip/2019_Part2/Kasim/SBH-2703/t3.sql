select * from koc_clm_suppliers_ext where claim_inst_type='AHK';

--
select *--institute_code, KOC_CLM_HLTH_UTILS.Getinstitutenamebasic(institute_code) insitute_name 
from --koc_clm_suppliers_ext 
      koc_v_clm_suppliers
where institute_code IN (
20291,
52812,
67929,
67958,
23428,
23832,
56412,
80714,
70894,
72113,
75273,
81999,
82493,
99878,
107956,
109656,
109874)

SELECT f.*--count(*) 
  FROM koc_cp_partners_ext  e,
       koc_v_clm_suppliers  f
 WHERE e.part_id = f.part_id                                               
  -- AND (e.identity_no IS NOT NULL OR e.tax_number IS NOT NULL)
   AND (e.identity_no IS NULL AND e.tax_number IS NULL)
   AND f.Claim_Inst_Type = 'AHK'
   AND f.Supp_Type = 'SKRM'
   AND exp_date is null
   AND f.Institute_Code = 23428
   ---AND exists (select 1 from koc_clm_hlth_detail where institute_code=f.Institute_Code and time_stamp>TO_DATE('01/01/2019','DD/MM/YYYY'))
                          
   
   
   select * from koc_cp_partners_ext where part_id = ---   
     koc_v_clm_suppliers 
   -- 30459
   -- 12035
                   
   -- 14931
                                               
                                              -- AND f.iinstitute_code
                                              
                                              
                                              select distinct institute_code from koc_clm_hlth_detail 
                                              where time_stamp>TO_DATE('10/11/2019','DD/MM/YYYY')
                                              and institute_code IN(
                                              SELECT f.institute_code 
  FROM koc_cp_partners_ext  e,
       koc_v_clm_suppliers  f
 WHERE e.part_id = f.part_id                                               
  -- AND (e.identity_no IS NOT NULL OR e.tax_number IS NOT NULL)
   AND (e.identity_no IS NULL AND e.tax_number IS NULL)
   AND f.Claim_Inst_Type = 'AHK'
   AND f.Supp_Type = 'SKRM'
   AND exp_date is null)
   AND close_date IS NULL;
   
   
   select * from KOC_CLM_SUPP_EXT_AHK_HIS_DTL where institute_code=23428
   select * from koc_clm_suppliers_ext where institute_code=133946
   
   select * from koc_clm_hlth_detail where ext_reference='51759255';
   select * from koc_clm_hlth_indem_dec where claim_id=33222232;
   
   select * from all_source where lower(text) like '%koc_clm_hlth_bordro_insert%';
   SAGLIK_AYKAPAMA
   
   KOC_CLM_BORDRO
                                              --AND EXISTS (select 1 from koc_clm_suppliers_ext where claim_inst_type='AHK' AND institute_code = f.institute_code)
