SELECT v.institute_code institute_code,  KOC_CLM_HLTH_UTILS.Getinstitutenamebasic(v.institute_code) institute_name,v.Instypname institute_type, v.part_id, v.supp_id,v.institute_skrs_code, v.hospital_type, v.Eff_Date, v.exp_date 
FROM koc_v_clm_suppliers v WHERE claim_inst_type='AHK' AND v.Supp_Type = 'SKRM' AND exp_date is null
AND exists (select 1 from koc_cp_partners_ext where part_id = v.part_id and identity_no is null and tax_number is null)
AND exists (select 1 from koc_clm_hlth_detail where institute_code=v.Institute_Code and time_stamp>TO_DATE('21/11/2018','DD/MM/YYYY'))
