SELECT COUNT(*) FROM koc_v_clm_suppliers_main where claim_inst_type='AHK' and exp_date IS NULL

CREATE TABLE close_ahk_institutes AS
SELECT v.institute_code institute_code,  KOC_CLM_HLTH_UTILS.Getinstitutenamebasic(v.institute_code) institute_name,v.Instypname institute_type, v.part_id, v.supp_id,v.institute_skrs_code, v.hospital_type, v.Eff_Date, v.exp_date 
FROM koc_v_clm_suppliers@opusprep v WHERE claim_inst_type='AHK' AND v.Supp_Type = 'SKRM' AND exp_date is null
AND exists (select 1 from koc_cp_partners_ext@opusprep where part_id = v.part_id and identity_no is null and tax_number is null)
AND not exists (select 1 from koc_clm_hlth_detail@opusprep where institute_code=v.Institute_Code and time_stamp>TO_DATE('21/11/2018','DD/MM/YYYY'))

 --select * from KOC_CLM_SUPP_EXT_AHK_HIS_DTL where institute_code=133946--23428
 select  from koc_clm_suppliers_ext where institute_code in(
 select institute_code from close_ahk_institutes)
 
 select * from koc_v_clm_suppliers where supp_id=5246099
 select * from clm_suppliers where supp_id=5246099 for update;
 
 --select count(*) from close_ahk_institutes
 
 update clm_suppliers s
    set s.exp_date = trunc(sysdate),
        s.comments = 'SBH-2703 task� kapsam�nda kapat�lm��t�r'
 where exists (select 1 from close_ahk_institutes where supp_id = s.supp_id);
 
 
 
CREATE TABLE open_ahk_institutes AS
SELECT v.institute_code institute_code,  KOC_CLM_HLTH_UTILS.Getinstitutenamebasic(v.institute_code) institute_name,v.Instypname institute_type, v.part_id, v.supp_id,v.institute_skrs_code, v.hospital_type, v.Eff_Date, v.exp_date 
FROM koc_v_clm_suppliers@opusprep v WHERE claim_inst_type='AHK' AND v.Supp_Type = 'SKRM' AND exp_date is null
AND exists (select 1 from koc_cp_partners_ext@opusprep where part_id = v.part_id and identity_no is not null or tax_number is not null)
--AND not exists (select 1 from koc_clm_hlth_detail@opusprep where institute_code=v.Institute_Code and time_stamp>TO_DATE('21/11/2018','DD/MM/YYYY'))
 
select count(*) from close_ahk_institutes_2;

select * from all_source where lower(text) like '%tahakkuk%slem%ba%ar%yla%sonu%'
