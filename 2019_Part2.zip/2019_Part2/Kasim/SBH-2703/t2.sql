SELECT /*+ index (a.b KOC_CLM_SUPPLIERS_EXT_IDX1) */
       a.*
        FROM Koc_v_Clm_Suppliers_Main a
       WHERE a.Institute_Code = 1533
         AND a.Eff_Date <= TO_DATE('21/11/2019','DD/MM/YYYY')
         AND Nvl(a.Exp_Date, TO_DATE('21/11/2019','DD/MM/YYYY')) >=TO_DATE('21/11/2019','DD/MM/YYYY')
      UNION ALL
      SELECT a.*
        FROM Koc_v_Clm_Suppliers_His a
       WHERE a.Institute_Code = 1533
         AND a.Eff_Date <=TO_DATE('21/11/2019','DD/MM/YYYY')
         AND Nvl(a.Exp_Date, TO_DATE('21/11/2019','DD/MM/YYYY')) >= TO_DATE('21/11/2019','DD/MM/YYYY');
         
         
         SELECT * FROM koc_clm_suppliers_ext a WHERE a.institute_code =  1533 ;
SELECT * FROM koc_clm_supp_ext_his  a WHERE a.institute_code =  1533 ORDER BY validity_end_date DESC ;
SELECT * FROM koc_v_clm_suppliers_his a WHERE a.institute_code =  1533 ORDER BY exp_date desc--validity_start_date DESC ;
SELECT * FROM koc_v_clm_suppliers_main a WHERE a.institute_code =  1533 ;
 Koc_Clm_Supp_Ext_His
 
 
 SELECT * FROM koc_v_clm_suppliers_main a WHERE a.institute_code =  1533 ;
 SELECT * FROM koc_v_clm_suppliers WHERE institute_code =  1533 and exp_date is null;
 
 GRANT SELECT ON ADEMO.close_ahk_institutes_2 TO PUBLIC;
