 SELECT s.INSTITUTE_CODE  KURUM_KODU,
        s.NAME            KURUM_ADI,
        s.INSTYPNAME      KURUM_TURU,
        s.CLAIM_INST_TYPE KURUM_ANLASMA_TIPI,
        e.tax_office      VERGI_DAIRESI,
        e.tax_number      VERGI_NO,
        e.identity_no     IDENTITY_NO,
        adres.city_name KURUM_IL,
        adres.district_name KURUM_ILCE
   FROM koc_v_clm_suppliers_main s, koc_cp_partners_ext e, (select a.part_id, b.city_code, b.district_code, 
       (SELECT MAX(CITY_NAME) FROM koc_cp_cities_ref where city_code = b.city_code and country_code = 'TR') city_name,
       (SELECT MAX(DISTRICT_NAME) FROM koc_cp_districts_ref where city_code = b.city_code and district_code = b.district_code and country_code = 'TR') district_name
from koc_cp_address_links a, koc_cp_address_ext b
where a.add_id = b.add_id
and a.TO_DATE IS NULL) adres
  WHERE s.EXP_DATE IS NULL
    AND s.Institute_Code IS NOT NULL
    AND s.CLAIM_INST_TYPE = 'AHK'
    AND s.Part_Id = e.part_id
    AND adres.part_id = s.Part_Id
    AND NOT EXISTS (SELECT 1
           FROM close_ahk_institutes
          WHERE institute_code = s.Institute_Code)
    AND NOT EXISTS (SELECT 1
           FROM close_ahk_institutes_2
          WHERE institute_code = s.Institute_Code)
 
SELECT * FROM  koc_v_clm_suppliers_main WHERE institute_code=1533;
select * from koc_cp_partners_ext where part_id=8633603

select * from KOC_CP_ADDRESS_EXT where add_id = 33103669
select * from koc_cp_address_links where part_id=8633603 AND TO_DATE IS NULL

select * from koc_cp_cities_ref where city_code = 34 and country_code = 'TR'
select * from koc_cp_districts_ref where district_code = 3434 and country_code = 'TR'

select b.city_code, b.district_code, 
       (SELECT CITY_NAME FROM koc_cp_cities_ref where city_code = b.city_code and country_code = 'TR') city_name,
       (SELECT DISTRICT_NAME FROM koc_cp_districts_ref where city_code = b.city_code and district_code = b.district_code and country_code = 'TR') district_name
from koc_cp_address_links a, koc_cp_address_ext b
where a.add_id = b.add_id
and a.part_id = 8633603 AND a.TO_DATE IS NULL
