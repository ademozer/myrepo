select * from alz_hltprv_log where log_id in(
148384142,
148384310,
148405382,
148386619
)
order by log_id


SELECT * FROM Koc_v_Cp_Health_Look_Up Where look_up_code='CPA_STAT';

SELECT * FROM ALZ_HLTH_CPA_LOG;

select * from Koc_Clm_Hlth_Prov_Statemnt where claim_id=43095562
select * from clm_subfiles where ext_reference='59035087'


KOC_CLM_HLTH_TRNX3

select * from clm_subfiles where ext_reference='59488556';
select * from koc_clm_hlth_detail  where ext_reference='59488556';
select * from alz_hclm_version_info where claim_id=43678200

select * from Koc_Clm_Hlth_Aso_Prov where claim_id=43497281
select SUM(provision_total) 
  from koc_clm_hlth_provisions  
 where claim_id=43497281
 
WITH provision AS (SELECT COVER_CODE,SUM(provision_total) prov_amount
                     FROM koc_clm_hlth_provisions  
                    WHERE claim_id=43497281
                 GROUP BY COVER_CODE),
     aso AS  (SELECT COVER_CODE, SUM(AMOUNT) aso_amount 
                FROM Koc_Clm_Hlth_Aso_Prov 
               WHERE claim_id=43497281
               GROUP BY COVER_CODE)
 SELECT provision.cover_code, provision.prov_amount,aso.aso_amount 
   FROM provision, aso
  WHERE provision.cover_code = aso.cover_code;
  
  select * from alz_hclm_version_info where claim_id=39531690;
  
  select count(*), SUM(amount) 
    from koc_clm_hlth_aso_prov
   where claim_id       = 25581286--:Koc_clm_hlth_detail.Claim_id
     and sf_no          = 1--:Koc_clm_hlth_detail.Sf_no
     and add_order_no   = 1--:Koc_clm_hlth_detail.Add_order_no
     and location_code  = 920--:Koc_clm_hlth_provisions.Location_code
     and cover_code     = 'S768' --:Koc_clm_hlth_provisions.Cover_code;  
 
 
   select * 
    from koc_clm_hlth_aso_prov
    
    select * from koc_clm_hlth_reject_loss  
    where claim_id       =2279664--:Koc_clm_hlth_detail.Claim_id
     and sf_no          = 1--:Koc_clm_hlth_detail.Sf_no
     and add_order_no   = 2--:Koc_clm_hlth_detail.Add_order_no
     --and location_code  = 910 --:Koc_clm_hlth_provisions.Location_code
     --and cover_code = 'S356'--:Koc_clm_hlth_provisions.Cover_code;
     
select * from alz_hclm_institute_info where institute_code=6411 for update;
     
SELECT ALZ_HCLM_CONVERTER_UTILS.getHclmUsage(6411, null, null, null, null, 'CENTRAL_PROVISION') FROM DUAL
        
select * from alz_hclm_institute_info where institute_code=0 for update;

ALZ Anla�mas�z Doktor

select * from alz_hltprv_log where log_id=147376235

