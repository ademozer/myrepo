select * from clm_subfiles where claim_id=43336083--ext_reference='59293212'--'59290664'; --59290663

SELECT * FROM ALZ_HCLM_VERSION_INFO WHERE CLAIM_ID=43420344 FOR UPDATE;

select * from koc_clm_hlth_proc_detail where claim_id IN(43420345,43420344) for update;;

CREATE TABLE ALZ_HLTH_ANNOUNCEMENT_INST AS SELECT * FROM KOC_ANNOUNCEMENT_INST@KASCV@EPROVIZYON

select * from KOC_CLM_HLTH_TMP_PROC_DETAIL

Select * From CUSTOMER.TMP_CLM_HLTH_PROC_DETAIL;

	Koc_Clm_Hlth_Trnx2.Insertsessionprocs

   koc_clm_hlth_trnx.setProcRec(p_procrec);
   
   Koc_Pk_Hlth_Provision.Getdetaildata;
   KOC_CLM_HLTH_TRNX
