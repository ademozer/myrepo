insert into koc_oc_hlth_ex_pack_rul_gr
select  27, 'Kurum-Teminat Ge�erli', RULE_GROUP_CODE, PRIORITY, RULE_TYPE,RULE_EXPLANATION
  from koc_oc_hlth_ex_pack_rul_gr
where rule_code = '4';
/
insert into koc_oc_hlth_ex_pack_rules
select MAIN_RULE_CODE,'27' ,  TABLE_FIELD_NAME , IS_VISIBLE,
       IS_MANDATORY, IS_DEFAULT_ZERO, ONE_MUST,IS_PARAMETER_MUST, IS_INPUT
  from koc_oc_hlth_ex_pack_rules where  sub_rule_code = '4';