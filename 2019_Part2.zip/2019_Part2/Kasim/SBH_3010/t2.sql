select * from koc_clm_hlth_prov_statemnt where statement_no=4132495 for update;

select * from koc_clm_hlth_provisions where claim_id=43511280 for update;
--43371814 for update;

select * from clm_subfiles where ext_reference = '59359798'--'59249278' 
