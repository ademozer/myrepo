SELECT */*+NL_SJ*/  --neslihank 31072017 plan de�i�ikli�i g�rm�� planlar i�in bu kontrol eklenmi�tir.
                           
                        FROM Koc_Clm_Hlth_Indem_Totals i
                       WHERE i.Contract_Id = 459580917
                         AND i.Partition_No = 1
                       --  AND i.Package_Id = 459580917
                         --AND i.Package_Date = i.Package_Date
                         AND Nvl(TRUNC(SYSDATE), i.Validity_Start_Date) BETWEEN i.Validity_Start_Date AND i.Validity_End_Date
                         AND i.Is_Valid = 1
                         
                         
                         SELECT *                           
                        FROM Koc_Clm_Hlth_Indem_Totals i
                       WHERE i.Contract_Id = 442787105--459580917
                         AND i.Partition_No = 82858
                         AND cover_code='S501'
                       --  for update;
                         
select * from KOC_OC_HLTH_EXPACK_COV_REL  WHERE PACKAGE_ID=260561 AND CHILD_COVER_CODE='S501' -- 1533

select * from koc_mv_skrm_suppliers where institute_code=1533;

    SELECT a.*
        FROM Koc_v_Clm_Suppliers_Main a
       WHERE a.Institute_Code = 1533
       
       select * from koc_clm_suppliers_ext where institute_code=1533;
       
       
       select * from alz_invoice_master where claim_id=4065563;
       select * from 
   UNION
        SELECT a.*
        FROM Koc_v_Clm_Suppliers_His a
       WHERE a.Institute_Code = 1533
         AND a.Eff_Date <= TO_DATE('11/10/2019','DD/MM/YYYY')
         AND Nvl(a.Exp_Date, TO_DATE('11/10/2019','DD/MM/YYYY')) >=TO_DATE('11/10/2019','DD/MM/YYYY');

koc_clm_hlth_trnx
                           
--select  Pme_Public.Opus_Date, sysdate from dual           
SELECT * FROM Koc_v_Hlth_Insured_Info_Indem   
WHERE Contract_Id = 442787105--459580917
  AND Partition_No = 82858;
  
  ALZ_HLTPRV_UTILS          
   
