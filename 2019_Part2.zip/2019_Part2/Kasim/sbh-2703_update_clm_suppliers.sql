DECLARE
  v_adet NUMBER := 0;
BEGIN
  
FOR rec IN (SELECT s.SUPP_ID FROM ADEMO.CLOSE_AHK_INSTITUTES@opusdev a, clm_suppliers s where a.supp_id=s.supp_id AND s.EXP_DATE IS NULL)  LOOP
  
 update clm_suppliers s
    set s.exp_date = trunc(sysdate),
        s.comments = 'SBH-2703 task� kapsam�nda kapat�lm��t�r'
  where s.supp_id = rec.supp_id;
  
 v_adet := v_adet + SQL%ROWCOUNT;
 
 IF MOD(v_adet, 400) = 0 THEN 
    COMMIT;
 END IF;
 
END LOOP;

COMMIT;
DBMS_OUTPUT.PUT_LINE(v_adet|| ' adet kay�t g�ncellendi');

EXCEPTION
WHEN OTHERS THEN
  DBMS_OUTPUT.PUT_LINE(v_adet|| '. kay�t g�ncellenirken hata olu�tu '||SQLERRM); 
  ROLLBACK;
END;  
/   
