DECLARE
v_Contract_Id              NUMBER := 472116522;
v_Partition_No             NUMBER := 55;
v_Part_Id                  NUMBER := 38198944;
v_Claim_Id                 NUMBER := NULL;
v_Sf_No                    NUMBER := NULL;
v_Institute_Code           NUMBER := 918;
v_Claim_Inst_Type          VARCHAR2(10) := 'AK';
v_Claim_Inst_Loc           VARCHAR2(10) := 'YI';
v_Country_Group            NUMBER := 0;
v_Location_Code            NUMBER := NULL;
v_Cover_Code               VARCHAR2(10) := 'S502';
v_Swift_Code               VARCHAR2(10) := 'TL';
v_Date                     DATE := SYSDATE;
v_Invoice_Date             DATE := SYSDATE;
v_Realization_Date         DATE := SYSDATE;
v_Prov_Date_Time           DATE := SYSDATE;
v_Provision_Amount         NUMBER := 200000;
v_Day_Seance               NUMBER := 0;
v_Policyinfo               Koc_v_Hlth_Insured_Info_Indem%ROWTYPE;
v_Institutinfo             Koc_v_Clm_Suppliers%ROWTYPE;
v_User_Id                  VARCHAR2(20) := 'MEDISER28';
v_Is_Pool_Cover            NUMBER := 0;
v_Is_Special_Cover         NUMBER := 0;
v_Process_Type             NUMBER := 0;
v_Out_Provision_Amount     NUMBER;
v_Out_Day_Seance           NUMBER;
v_Out_Exemption_Rate       NUMBER;
v_Out_Exemption_Sum        NUMBER;
v_Out_Inst_Exemp_Sum       NUMBER;
v_r_Day_Seance             NUMBER;
v_r_Cover_Price            NUMBER;
v_Inst_Provision_Aval_Code VARCHAR2(20);
v_Inst_Is_Cover_Val        NUMBER;
v_Out_Over_Price           VARCHAR2(20);
v_Exemption_Ovr_Amount     NUMBER := NULL; -- Muafiyet tutarini d�zenleme
v_Is_Referral              NUMBER := NULL;
PROCEDURE Getoldpolicy(p_Contract_Id      NUMBER,
                         p_Partition_No     NUMBER,
                         p_Partner_Id       NUMBER,
                         p_Old_Contract_Id  OUT NUMBER,
                         p_Old_Partition_No OUT NUMBER,
                         p_Term_End_Date    OUT DATE) IS
    v_Old_Policy_Contract_Id NUMBER;
    v_Max_Ver                NUMBER;
    v_Query_Version          NUMBER;
  BEGIN
    SELECT Old_Policy_Contract_Id
      INTO v_Old_Policy_Contract_Id
      FROM Koc_Ocp_Health a
     WHERE a.Contract_Id = p_Contract_Id
       AND a.Partition_No = p_Partition_No
       AND Rownum < 2;

    SELECT MAX(Version_No)
      INTO v_Max_Ver
      FROM Ocp_Interested_Parties a
     WHERE a.Contract_Id = v_Old_Policy_Contract_Id
       AND Partner_Id = p_Partner_Id;

    v_Query_Version := v_Max_Ver;

    SELECT Contract_Id, Partition_No, Term_End_Date
      INTO p_Old_Contract_Id, p_Old_Partition_No, p_Term_End_Date
      FROM (SELECT DISTINCT a.Contract_Id, b.Partition_No, d.Term_End_Date
              FROM Ocp_Interested_Parties a,
                   Ocp_Ip_Links           b,
                   Koc_Ocp_Partitions_Ext d
             WHERE a.Version_No =
                   (SELECT MAX(z.Version_No)
                      FROM Ocp_Interested_Parties z
                     WHERE a.Contract_Id = z.Contract_Id
                       AND a.Object_Id = z.Object_Id
                       AND z.Version_No <= v_Query_Version
                       AND z.Reversing_Version IS NULL)
               AND a.Action_Code <> 'D'
               AND b.Version_No =
                   (SELECT MAX(x.Version_No)
                      FROM Ocp_Ip_Links x
                     WHERE b.Contract_Id = x.Contract_Id
                       AND b.Object_Id = x.Object_Id
                       AND x.Version_No <= v_Query_Version
                       AND x.Reversing_Version IS NULL)
               AND b.Action_Code <> 'D'
               AND d.Version_No =
                   (SELECT MAX(y.Version_No)
                      FROM Koc_Ocp_Partitions_Ext y
                     WHERE d.Contract_Id = y.Contract_Id
                       AND d.Object_Id = y.Object_Id
                       AND y.Version_No <= v_Query_Version
                       AND y.Reversing_Version IS NULL)
               AND d.Action_Code <> 'D'
               AND a.Contract_Id = b.Contract_Id
               AND a.Ip_No = b.Ip_No
               AND d.Partition_No = b.Partition_No
               AND d.Contract_Id = a.Contract_Id
               AND b.Role_Type = 'INS'
               AND a.Top_Indicator = 'Y'
               AND a.Contract_Id = v_Old_Policy_Contract_Id
               AND a.Partner_Id = p_Partner_Id
             ORDER BY d.Term_End_Date DESC)
     WHERE Rownum < 2;
  EXCEPTION
    WHEN OTHERS THEN
      p_Old_Contract_Id  := NULL;
      p_Old_Partition_No := NULL;
      p_Term_End_Date    := NULL;
  END Getoldpolicy;                            
PROCEDURE Computeremaning(p_Contract_Id              NUMBER,
                            p_Partition_No             NUMBER,
                            p_Part_Id                  NUMBER,
                            p_Claim_Id                 NUMBER,
                            p_Sf_No                    NUMBER,
                            p_Institute_Code           NUMBER,
                            p_Claim_Inst_Type          VARCHAR2,
                            p_Claim_Inst_Loc           VARCHAR2,
                            p_Country_Group            NUMBER,
                            p_Location_Code            NUMBER,
                            p_Cover_Code               VARCHAR2,
                            p_Swift_Code               VARCHAR2,
                            p_Date                     DATE,
                            p_Invoice_Date             DATE,
                            p_Realization_Date         DATE,
                            p_Prov_Date_Time           DATE,
                            p_Provision_Amount         NUMBER,
                            p_Day_Seance               NUMBER,
                            p_Policyinfo               Koc_v_Hlth_Insured_Info_Indem%ROWTYPE,
                            p_Institutinfo             Koc_v_Clm_Suppliers%ROWTYPE,
                            p_User_Id                  VARCHAR2,
                            p_Is_Pool_Cover            NUMBER,
                            p_Is_Special_Cover         NUMBER,
                            p_Process_Type             NUMBER DEFAULT 0,
                            p_Out_Provision_Amount     OUT NUMBER,
                            p_Out_Day_Seance           OUT NUMBER,
                            p_Out_Exemption_Rate       OUT NUMBER,
                            p_Out_Exemption_Sum        OUT NUMBER,
                            p_Out_Inst_Exemp_Sum       OUT NUMBER,
                            p_r_Day_Seance             OUT NUMBER,
                            p_r_Cover_Price            OUT NUMBER,
                            p_Inst_Provision_Aval_Code OUT VARCHAR2,
                            p_Inst_Is_Cover_Val        OUT NUMBER,
                            p_Out_Over_Price           OUT VARCHAR2,
                            p_Exemption_Ovr_Amount     IN NUMBER DEFAULT NULL, -- Muafiyet tutarini d�zenleme
                            p_Is_Referral              IN NUMBER DEFAULT NULL) IS
    v_Network_Prov_Aval_Code NUMBER := 0;
    j                        NUMBER;
    v_Trans_Insured          KOC_CLM_HLTH_TRNX.Transinsuredtyp;
    Cur                      KOC_CLM_HLTH_TRNX.Refcur;
    Indeminfo                Koc_Clm_Hlth_Indem_Totals%ROWTYPE;
    Indeminfoparent          Koc_Clm_Hlth_Indem_Totals%ROWTYPE;
    Indeminforep             Rep_Clm_Hlth_Indem_Totals%ROWTYPE;
    Indeminfopool            Koc_Clm_Hlth_Indem_Totals%ROWTYPE;
    Oldindeminfo             Koc_Clm_Hlth_Indem_Totals%ROWTYPE;
    Policyinfo               Koc_v_Hlth_Insured_Info_Indem%ROWTYPE;
    Institutinfo             Koc_v_Clm_Suppliers%ROWTYPE;
    v_Clmprovision           Koc_Clm_Hlth_Provisions%ROWTYPE;
    u_r_Cover_Price          NUMBER;
    u_r_Day_Seance           NUMBER;
    u_r_Exemption_Sum        NUMBER;
    u_s_Provision_Amount     NUMBER;
    u_s_Spend_Total          NUMBER;
    u_s_Spend_Day_Seance     NUMBER;
    u_s_Exemption_Sum        NUMBER;

    v_Policy_Start_Date          DATE;
    v_Old_Contract_Id            NUMBER;
    v_Old_Partition_No           NUMBER;
    v_Term_End_Date              DATE;
    v_Max_Inc_Clearing_System_Id NUMBER;
    v_Max_Inc_Curr_Get_Type      VARCHAR2(10);
    v_Max_Inc_Swift_Code         VARCHAR2(4);

    Expackrsltbl         KOC_CLM_HLTH_TRNX.Expackrsltbltyp;
    c_Inst_Is_Cover_Val2 NUMBER := NULL;

    c_Max_Increase      NUMBER;
    c_Provision_Amount  NUMBER;
    c_Exemption_Rate    NUMBER;
    c_Day_Seance        NUMBER;
    c_Exemption_Sum     NUMBER;
    c_Day_Seance_Amount NUMBER;
    c_Is_Unlimited      NUMBER;

    c_r_Cover_Price NUMBER;
    c_r_Day_Seance  NUMBER;

    c_f_Cover_Price NUMBER;
    c_f_Day_Seance  NUMBER;

    c_Inst_Cover_Price         NUMBER := NULL;
    c_Inst_r_Day_Seance        NUMBER := NULL;
    c_Inst_Exemption_Sum       NUMBER := NULL;
    c_Inst_Exemption_Rate      NUMBER := NULL;
    c_Inst_Is_Unlimited        NUMBER := NULL;
    c_Inst_Provision_Aval_Code VARCHAR2(4) := NULL;
    c_Inst_Is_Cover_Val        NUMBER := NULL;
    c_Inst_Is_Not_Valid_Exemp  NUMBER := NULL;

    c_Parent_Indemnity_Type   VARCHAR2(20);
    c_Parent_Provision_Amount NUMBER;
    c_Parent_r_Cover_Price    NUMBER;
    c_Parent_Is_Unlimited     NUMBER;

    p_Rsl_Number             NUMBER;
    p_Rsl_Date               DATE;
    p_Rsl_Char               VARCHAR2(2000);
    Expackrow                Koc_Oc_Hlth_Expack_Cov_Rel%ROWTYPE;
    v_Pay_Clearing_System_Id NUMBER;
    v_Pay_Curr_Get_Type      VARCHAR2(4);

    v_Parite         NUMBER := 1;
    v_Cover_Swf      VARCHAR2(20);
    v_Exch_Date      VARCHAR2(20);
    v_Curr_Date      DATE;
    v_Exit           BOOLEAN;
    Vv_Date          DATE;
    Vv_Partittion_No NUMBER;
    i                NUMBER;
    v_Networkid      Koc_v_Hlth_Insured_Info_Indem.Network_Id%TYPE;

    Hltprv_Log                  Hltprv_Log_Typ;
    Vprodpartmdlr               VARCHAR2(10);
    Vcoverpackageid             NUMBER;
    Vcoverpackagedate           DATE;
    v_Network_21_Prov_Aval_Code NUMBER;

    --PRAGMA AUTONOMOUS_TRANSACTION;
    v_City_Code    VARCHAR2(3);
    v_Country_Code VARCHAR2(3) := 'TR';
    v_Is_Refferal  NUMBER;

    -- engine 18052017 TPA
    v_Company_Code   Alz_Tpa_Companies.Company_Code%TYPE;
    v_Message        Customer.Alz_Tpa_Message_Definitions.Message_Template%TYPE;
    v_Message_Fields VARCHAR2(1000);
    -- engine 18052017 TPA
  BEGIN
    --p_process_type :0 deger al
    --p_process_type :1 limit g�nceller
    --p_process_type :2 islem iptal
    --p_process_type :3 Limit bloklayarak deger alir

   
      KOC_CLM_HLTH_TRNX.Getindemtotalsmdf(p_Contract_Id,
                        p_Partition_No,
                        p_Claim_Inst_Type,
                        p_Claim_Inst_Loc,
                        p_Country_Group,
                        p_Cover_Code,
                        p_Policyinfo.Package_Id,
                        p_Policyinfo.Package_Date,
                        Trunc(p_Date),
                        p_User_Id,
                        p_Is_Pool_Cover,
                        p_Is_Special_Cover,
                        Cur);
      FETCH Cur
        INTO Indeminfo;
      CLOSE Cur;

   

    IF Indeminfo.Contract_Id IS NULL AND p_Process_Type = 1 THEN
      Raise_Application_Error(-20222, 'Teminat, Planda Bulunamad�.'); --20222 errcode u ba�ka yerde kullanma !
    END IF;

    --aaktas
    --02052014
    --1KEZ teminat �deme tipi NORM gibi davranacak
    IF Indeminfo.Indemnity_Payment_Type NOT IN
       ('DEFA', 'GUN', 'NORM', '2YIL', '1KEZ') THEN
      Raise_Application_Error(-20200,
                              '�deme Tipi Hatasi.' ||
                              Indeminfo.Indemnity_Payment_Type);
    END IF;


    c_Provision_Amount := Nvl(p_Provision_Amount, 0);

    -- talep tutarinin d�viz cinsi teminatin d�viz cinsinden farkli ise
    -- talep tutarinin teminat d�viz cinsi karsiligini bulunur
    -- ve limitler bu tutar ile g�ncellenir.
    IF p_Swift_Code != Indeminfo.Swift_Code THEN
      v_Cover_Swf := Indeminfo.Swift_Code;

      SELECT Decode(v_Cover_Swf,
                    Base_Swift_Code,
                    Pay_Clearing_System_Id,
                    Pay_Swf_Clear_Sys_Id),
             Decode(v_Cover_Swf,
                    Base_Swift_Code,
                    Pay_Curr_Get_Type,
                    Pay_Swf_Curr_Get_Type),
             Decode(v_Cover_Swf,
                    Base_Swift_Code,
                    Pay_Exch_Dates,
                    Pay_Swf_Exch_Dates)
        INTO v_Pay_Clearing_System_Id, v_Pay_Curr_Get_Type, v_Exch_Date
        FROM Koc_Oc_Prod_Partition_Rel
       WHERE Product_Id = p_Policyinfo.Product_Id
         AND Partition_Type = p_Policyinfo.Partition_Type
         AND Validity_Start_Date <= p_Policyinfo.Term_Start_Date
         AND Nvl(Validity_End_Date, p_Policyinfo.Term_Start_Date) >=
             p_Policyinfo.Term_Start_Date;

      IF v_Exch_Date = 'FAT' THEN
        v_Curr_Date := p_Invoice_Date;
      ELSIF v_Exch_Date = 'OLAY' THEN
        v_Curr_Date := p_Date;
      ELSIF v_Exch_Date = 'TAH' THEN
        v_Curr_Date := p_Realization_Date;
      ELSE
        v_Curr_Date := p_Date;
      END IF;

      v_Parite           := Koc_Curr_Utils.Retrieve_Currency_Rate(p_Swift_Code,
                                                                  v_Pay_Curr_Get_Type,
                                                                  Trunc(v_Curr_Date),
                                                                  v_Pay_Clearing_System_Id,
                                                                  TRUE) /
                            Koc_Curr_Utils.Retrieve_Currency_Rate(Indeminfo.Swift_Code,
                                                                  v_Pay_Curr_Get_Type,
                                                                  Trunc(v_Curr_Date),
                                                                  v_Pay_Clearing_System_Id,
                                                                  TRUE);
      c_Provision_Amount := v_Parite * c_Provision_Amount;
    END IF;

    -- provizyon almis hasar dosya--------------------------------------------
    -- provizyon almis lokasyon �zerinde degisiklik yapildiginda dogru provizyon tutarini g�stere bilmesi i�in
    -- �nce provizyon almis lokasyon reverse ediliyor.
    --IF p_Process_Type = 0
    IF p_Process_Type IN (0, 3) THEN
      BEGIN
        SELECT *
          INTO v_Clmprovision
          FROM Koc_Clm_Hlth_Provisions
         WHERE Claim_Id = p_Claim_Id
           AND Sf_No = p_Sf_No
           AND Location_Code = p_Location_Code
           AND Cover_Code = p_Cover_Code
           AND Status_Code in( 'P','CP');

        IF p_Policyinfo.Partition_Type = 'KEKS' THEN
          v_Clmprovision.Exemption_Amount := 0;
        END IF;

        Indeminfo.s_Provision_Amount := Indeminfo.s_Provision_Amount -
                                        v_Parite * Nvl(v_Clmprovision.Provision_Total,
                                                       0);
        Indeminfo.s_Spend_Total      := Indeminfo.s_Spend_Total -
                                        v_Parite *
                                        (Nvl(v_Clmprovision.Request_Amount,
                                             0) - Nvl(v_Clmprovision.Refusal_Amount,
                                                       0));
        Indeminfo.s_Spend_Day_Seance := Indeminfo.s_Spend_Day_Seance -
                                        Nvl(v_Clmprovision.Req_Cure_Day_Count,
                                            0);
        Indeminfo.s_Exemption_Sum    := Indeminfo.s_Exemption_Sum -
                                        v_Parite * Nvl(v_Clmprovision.Exemption_Amount,
                                                       0);
        Indeminfo.r_Exemption_Sum    := Indeminfo.r_Exemption_Sum +
                                        v_Parite * Nvl(v_Clmprovision.Exemption_Amount,
                                                       0);

        IF Indeminfo.Indemnity_Payment_Type IN ('NORM', '1KEZ') AND
           Nvl(Indeminfo.Is_Unlimited, 0) != 1 THEN
          IF v_Clmprovision.Exemption_Rate != 1 THEN
            --yasemin
            Indeminfo.r_Cover_Price := Indeminfo.r_Cover_Price +
                                       v_Parite *
                                       ((v_Clmprovision.Provision_Total /
                                       (1 - v_Clmprovision.Exemption_Rate)) +
                                       v_Clmprovision.Exemption_Amount);
          ELSE
            --yasemin
            Indeminfo.r_Cover_Price := Indeminfo.r_Cover_Price +
                                       v_Parite *
                                       v_Clmprovision.Exemption_Amount;
          END IF;
        END IF;

        IF Indeminfo.Indemnity_Payment_Type IN
           ('DEFA', 'GUN', 'NORM', '1KEZ') THEN
          Indeminfo.r_Day_Seance := Indeminfo.r_Day_Seance +
                                    v_Clmprovision.Day_Seance;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
    END IF;

    -----------------------------------------------------------
    Policyinfo   := p_Policyinfo;
    Institutinfo := p_Institutinfo;

    --aaktas
    --21012015
    --Poli�e mod�ler saglik �r�n� m�?
    Vprodpartmdlr := Koc_Health_Policy_Utils5.Get_Prod_Part_Mdlr(Policyinfo.Product_Id,
                                                                 Policyinfo.Partition_Type,
                                                                 Trunc(p_Date));

    --abdullah aktas
    --21012015
    --mdlr tipinde ise partition_type teminatin sub_package_id sini al
    --mdlr poli�esindeki teminatlarin planlari farkli olabilir.
    IF Nvl(Vprodpartmdlr, 'X') = 'MDLR' THEN
      Vcoverpackageid   := Indeminfo.Sub_Package_Id;
      Vcoverpackagedate := Indeminfo.Sub_Package_Date;
    ELSE
      Vcoverpackageid   := Policyinfo.Package_Id;
      Vcoverpackagedate := Policyinfo.Package_Date;
    END IF;

    --ibrahimk
    --expack cov rel de yeni kural i�in kullan�lacak alanlar
    IF p_Institute_Code IS NOT NULL THEN
      Alz_Hlth_Karma_Utils.Get_Inst_City_Code(Institutinfo.Institute_Code,
                                              v_City_Code,
                                              v_Country_Code);
    ELSE
      v_City_Code    := NULL;
      v_Country_Code := NULL;
    END IF;

    --ibrahimk + kenanp 25012017 karma projesi
    BEGIN
      SELECT Network_Id
        INTO v_Networkid
        FROM (SELECT a.Package_Id,
                     a.Contract_Id,
                     a.Partition_No,
                     a.Network_Id,
                     Decode(a.Package_Status, 'D', 0, 1) Sira
                FROM Koc_v_Hlth_Insured_Info_Indem a
               WHERE a.Contract_Id = p_Contract_Id
                 AND a.Partition_No = p_Partition_No
                 AND p_Date BETWEEN a.Term_Start_Date AND
                     (a.Term_End_Date + 0.5) /*��len 12:00 den sonra provizyon alamas�n*/
               ORDER BY 5 DESC)
       WHERE Rownum < 2;
    EXCEPTION
      WHEN OTHERS THEN
        v_Networkid := NULL;
    END;

    --sonras�nda parametre olarak eklendi.
    IF p_Claim_Id IS NOT NULL AND p_Is_Referral IS NULL THEN
      v_Is_Refferal := Alz_Hlth_Karma_Utils.Get_Clm_Is_Referral(p_Claim_Id     => v_Clmprovision.Claim_Id,
                                                                p_Sf_No        => v_Clmprovision.Sf_No,
                                                                p_Add_Order_No => v_Clmprovision.Add_Order_No);
    ELSE
      v_Is_Refferal := p_Is_Referral;
    END IF;

    --IF p_Process_Type IN (0, 1)
    IF p_Process_Type IN (0, 1, 3) THEN
      --kurum i�in tanimlanmis limit, muafiyet tutari yada hasta payi var mi?----
      Expackrow.Product_Id           := Policyinfo.Product_Id;
      Expackrow.Partition_Type       := Policyinfo.Partition_Type;
      Expackrow.Contract_Id          := Policyinfo.Contract_Id;
      Expackrow.Partition_No         := Policyinfo.Partition_No;
      Expackrow.Validity_Start_Date  := Nvl(Indeminfo.Validity_Start_Date,
                                            To_Date('01/01/1000',
                                                    'DD/MM/YYYY'));
      Expackrow.Part_Id              := Policyinfo.Partner_Id;
      Expackrow.Package_Id           := Vcoverpackageid;
      Expackrow.Package_Date         := Vcoverpackagedate;
      Expackrow.Claim_Inst_Type      := Nvl(p_Claim_Inst_Type,
                                            Institutinfo.Claim_Inst_Type);
      Expackrow.Claim_Inst_Loc       := Nvl(p_Claim_Inst_Loc,
                                            Institutinfo.Claim_Inst_Loc);
      Expackrow.Institute_Code       := Institutinfo.Institute_Code;
      Expackrow.Inst_Cov_Type        := Institutinfo.Inst_Cov_Type;
      Expackrow.Inst_Validity_Type   := Institutinfo.Inst_Validity_Type;
      Expackrow.Institute_Type       := Institutinfo.Institute_Type;
      Expackrow.Country_Group        := p_Country_Group;
      Expackrow.Child_Cover_Code     := Indeminfo.Cover_Code;
      Expackrow.Is_Pool_Cover        := Indeminfo.Is_Pool_Cover;
      Expackrow.Is_Special_Cover     := Indeminfo.Is_Special_Cover;
      Expackrow.Cover_Cat_Group      := Indeminfo.Cover_Cat_Group;
      Expackrow.Institude_Group_Code := Institutinfo.Institute_Group_Code_Type_2; -- selcenk TSS 03/03/2015
      Expackrow.Spec_Group_Code      := Institutinfo.Institute_Group_Code_Type_s; -- selcenk TSS 03/03/2015
      -- Expackrow.City_Code            := v_City_Code; --ibrahimk karma 21/09/2016
      Expackrow.City_Code            := lpad(SUBSTR(v_City_Code,-2 ),2,'0');--sbh-2213

      if Expackrow.City_Code = '00' then
         Expackrow.City_Code := '';-- sbh-2704 if eklendi '0' -> '00' oluyordu , '00' olan kay�tlar var hatal� �al���yor
      end if;

      Expackrow.Network_Id           := v_Networkid; --ibrahimk + kenanp 25012017 karma projesi

      KOC_CLM_HLTH_TRNX.Getinstexpackresult(Expackrow,
                          'IS_UNLIMITED',
                          p_Rsl_Number,
                          p_Rsl_Date,
                          p_Rsl_Char);
      Expackrsltbl(1).Is_Unlimited := p_Rsl_Number;

      KOC_CLM_HLTH_TRNX.Getinstexpackresult(Expackrow,
                          'COVER_PRICE',
                          p_Rsl_Number,
                          p_Rsl_Date,
                          p_Rsl_Char);
      Expackrsltbl(1).Cover_Price := p_Rsl_Number;

      KOC_CLM_HLTH_TRNX.Getinstexpackresult(Expackrow,
                          'EXEMPTION_RATE',
                          p_Rsl_Number,
                          p_Rsl_Date,
                          p_Rsl_Char);
      Expackrsltbl(1).Exemption_Rate := p_Rsl_Number;

      --ibrahimk karma 21/09/2106
      KOC_CLM_HLTH_TRNX.Getinstexpackresult(Expackrow,
                          'EXEMPTION_RATE2',
                          p_Rsl_Number,
                          p_Rsl_Date,
                          p_Rsl_Char);
      Expackrsltbl(1).Exemption_Rate2 := p_Rsl_Number;

      IF Nvl(v_Is_Refferal, 0) = 1 AND Expackrsltbl(1)
        .Exemption_Rate2 IS NOT NULL THEN
        Expackrsltbl(1).Exemption_Rate := Expackrsltbl(1).Exemption_Rate2;
      END IF;
      ------------------------------------------------
      KOC_CLM_HLTH_TRNX.Getinstexpackresult(Expackrow,
                          'EXEMPTION_SUM',
                          p_Rsl_Number,
                          p_Rsl_Date,
                          p_Rsl_Char);
      Expackrsltbl(1).Exemption_Sum := p_Rsl_Number;

      KOC_CLM_HLTH_TRNX.Getinstexpackresult(Expackrow,
                          'SPECIAL_COVER_CODE',
                          p_Rsl_Char,
                          p_Rsl_Date,
                          p_Rsl_Char);
      Expackrsltbl(1).Special_Cover_Code := p_Rsl_Char;

      KOC_CLM_HLTH_TRNX.Getinstexpackresult(Expackrow,
                          'MAX_DAY_SEANCE',
                          p_Rsl_Number,
                          p_Rsl_Date,
                          p_Rsl_Char);
      Expackrsltbl(1).Max_Day_Seance := p_Rsl_Number;

      --27032014
      --aaktas
      KOC_CLM_HLTH_TRNX.Getinstexpackresult(Expackrow,
                          'IS_NOT_VALID_EXEMP',
                          p_Rsl_Number,
                          p_Rsl_Date,
                          p_Rsl_Char);
      Expackrsltbl(1).Is_Not_Valid_Exemp := p_Rsl_Number;
      --

      p_Rsl_Char   := NULL;
      p_Rsl_Number := NULL;

   
        KOC_CLM_HLTH_TRNX.Getinstexpackresult(Expackrow,
                            'PROVISION_AVAL_CODE',
                            p_Rsl_Char,
                            p_Rsl_Date,
                            p_Rsl_Char);
        Expackrsltbl(1).Provision_Aval_Code := p_Rsl_Char;

        KOC_CLM_HLTH_TRNX.Getinstexpackresult(Expackrow,
                            'IS_COVER_VAL',
                            p_Rsl_Number,
                            p_Rsl_Date,
                            p_Rsl_Char);
        Expackrsltbl(1).Is_Cover_Val := p_Rsl_Number;

        KOC_CLM_HLTH_TRNX.Getinstexpackresult(Expackrow,
                            'IS_COVER_VAL2',
                            p_Rsl_Number,
                            p_Rsl_Date,
                            p_Rsl_Char);
        Expackrsltbl(1).Is_Cover_Val2 := p_Rsl_Number;

      

      v_Network_Prov_Aval_Code := 0;
      v_Network_Prov_Aval_Code := KOC_CLM_HLTH_TRNX.Isnetworkavailableforinst(Policyinfo.Contract_Id,
                                                            Policyinfo.Partition_No,
                                                            Institutinfo.Institute_Code,
                                                            Trunc(p_Date),
                                                            p_User_Id);

      --selcenk 26/03/2015
      IF Nvl(v_Network_Prov_Aval_Code, 0) = 0 AND
         Nvl(p_Cover_Code, 'X') <> 'X' THEN
        v_Network_21_Prov_Aval_Code := KOC_CLM_HLTH_TRNX.Isnetworkavailableforinst(Policyinfo.Contract_Id,
                                                                 Policyinfo.Partition_No,
                                                                 Institutinfo.Institute_Code,
                                                                 Trunc(p_Date),
                                                                 p_User_Id,
                                                                 p_Cover_Code
                                                                 -- ,indeminfo.cover_code -- selcenk 26/03/2015
                                                                 );

        IF v_Network_21_Prov_Aval_Code = 1 THEN
          --expackrsltbl (1).is_cover_val := 1;
          Expackrsltbl(1).Provision_Aval_Code := 1;
        END IF;
      END IF;

      --selcenk 26/03/2015

      IF v_Network_Prov_Aval_Code = 1 THEN
        Expackrsltbl(1).Provision_Aval_Code := v_Network_Prov_Aval_Code;
      END IF;

      i := 0;

      LOOP
        i := i + 1;
        EXIT WHEN i > Expackrsltbl.Count;

        IF Expackrsltbl(i).Is_Unlimited IS NOT NULL THEN
          c_Inst_Is_Unlimited := Expackrsltbl(i).Is_Unlimited;
        END IF;

        IF Expackrsltbl(i).Cover_Price IS NOT NULL THEN
          c_Inst_Cover_Price := Nvl(Expackrsltbl(i).Cover_Price, 0);
        END IF;

        IF Expackrsltbl(i).Max_Day_Seance IS NOT NULL THEN
          c_Inst_r_Day_Seance := Nvl(Expackrsltbl(i).Max_Day_Seance, 0);
        END IF;

        IF Expackrsltbl(i).Exemption_Sum IS NOT NULL THEN
          c_Inst_Exemption_Sum := Nvl(Expackrsltbl(i).Exemption_Sum, 0);
        END IF;

        IF Expackrsltbl(i).Exemption_Rate IS NOT NULL THEN
          c_Inst_Exemption_Rate := Nvl(Expackrsltbl(i).Exemption_Rate, 0);
        END IF;

        IF Expackrsltbl(i).Provision_Aval_Code IS NOT NULL THEN
          c_Inst_Provision_Aval_Code := Expackrsltbl(i).Provision_Aval_Code;
        END IF;

        IF Expackrsltbl(i).Is_Cover_Val IS NOT NULL THEN
          c_Inst_Is_Cover_Val := Expackrsltbl(i).Is_Cover_Val;
        END IF;

        --ibrahim kapa a�
        IF Nvl(Indeminfo.Is_Valid_By_Rule, 0) = 1 AND
           Nvl(Expackrsltbl(i).Is_Cover_Val2, 0) <> 1 THEN
          c_Inst_Is_Cover_Val2 := 1;
          c_Provision_Amount   := 0;

          --tutar s�f�rland���nda logluyoruz. kontrol i�in sonradan kapat�lacak
          Hltprv_Log        := Hltprv_Log_Typ();
          Hltprv_Log.Log_Id := NULL;

          Hltprv_Log.Servicename := 'KOC_CLM_HLTH_TRNX';
          Hltprv_Log.Processinfo := 'COMPUTEREMANING';
          Hltprv_Log.Note        := 'Teminat ge�erli kural� �al��t�';
          Hltprv_Log.Content     := 'sqlerrm              : ' || SQLERRM ||
                                    Chr(10) || 'p_contract_id        : ' ||
                                    p_Contract_Id || Chr(10) ||
                                    'p_partition_no       : ' ||
                                    p_Partition_No || Chr(10) ||
                                    'p_claim_inst_type    : ' ||
                                    p_Claim_Inst_Type || Chr(10) ||
                                    'p_claim_inst_loc     : ' ||
                                    p_Claim_Inst_Loc || Chr(10) ||
                                    'p_country_group      : ' ||
                                    p_Country_Group || Chr(10) ||
                                    'p_cover_code         : ' ||
                                    p_Cover_Code || Chr(10) ||
                                    'package_id           : ' ||
                                    p_Policyinfo.Package_Id || Chr(10) ||
                                    'package_date         : ' ||
                                    p_Policyinfo.Package_Date || Chr(10) ||
                                    'p_date               : ' || p_Date ||
                                    Chr(10) || 'p_user_id            : ' ||
                                    p_User_Id || Chr(10) ||
                                    'p_is_pool_cover      : ' ||
                                    p_Is_Pool_Cover || Chr(10) ||
                                    'p_is_special_cover   : ' ||
                                    p_Is_Special_Cover || Chr(10) ||
                                    'mod�ler saglik mi    : ' ||
                                    Vprodpartmdlr || Chr(10) ||
                                    'sub_package_id       : ' ||
                                    Indeminfo.Sub_Package_Id || Chr(10) ||
                                    'sub_package_date     : ' ||
                                    Indeminfo.Sub_Package_Date || Chr(10) ||
                                    'nvl(indeminfo.is_valid_by_rule, 0) : ' ||
                                    Nvl(Indeminfo.Is_Valid_By_Rule, 0) ||
                                    Chr(10) ||
                                    'nvl(Expackrsltbl(i).Is_Cover_Val2, 0) : ' ||
                                    Nvl(Expackrsltbl(i).Is_Cover_Val2, 0);

          Hltprv_Log.Savelogwithpragma;

        END IF;
        --ibrahim kapa a�

        IF Expackrsltbl(i).Is_Not_Valid_Exemp IS NOT NULL THEN
          c_Inst_Is_Not_Valid_Exemp := Expackrsltbl(i).Is_Not_Valid_Exemp;
        END IF;
      END LOOP;

      ----kuruma bagli degisenler--------------------
      DBMS_OUTPUT.PUT_LINE('is_unlimited.1='|| c_Is_Unlimited ||':'||c_Inst_Is_Unlimited);
      IF c_Inst_Is_Unlimited IS NOT NULL 
      --AND c_Inst_Is_Unlimited = 0 --ademo.AKIS 35 nolu kural testi
      THEN
        c_Is_Unlimited := c_Inst_Is_Unlimited;
      ELSE
        c_Is_Unlimited := Indeminfo.Is_Unlimited;
      END IF;
      DBMS_OUTPUT.PUT_LINE('is_unlimited.2='|| c_Is_Unlimited ||':'||c_Inst_Is_Unlimited);
      IF c_Inst_Exemption_Sum IS NOT NULL THEN
        IF Nvl(c_Provision_Amount, 0) < c_Inst_Exemption_Sum THEN
          c_Inst_Exemption_Sum := Nvl(c_Provision_Amount, 0);
        END IF;
      ELSE
        c_Inst_Exemption_Sum := 0;
      END IF;

      -- en k���k limit alinmali
       DBMS_OUTPUT.PUT_LINE('is_cover_price.1='|| Indeminfo.r_Cover_Price ||':'||c_Inst_Cover_Price);
      IF c_Inst_Cover_Price IS NOT NULL AND
         Indeminfo.r_Cover_Price > Nvl(c_Inst_Cover_Price, 0) 
      AND c_Is_Unlimited = 0
      THEN         
        c_r_Cover_Price := Nvl(c_Inst_Cover_Price, 0);
      ELSIF c_Is_Unlimited = 1 THEN
        c_r_Cover_Price := NULL;
      ELSE         
        c_r_Cover_Price := Indeminfo.r_Cover_Price;
      END IF;
       DBMS_OUTPUT.PUT_LINE('is_cover_price.2='|| c_r_Cover_Price ||':'||c_Inst_Cover_Price);
      IF c_Inst_r_Day_Seance IS NOT NULL AND
         Nvl(Indeminfo.r_Day_Seance, 0) > Nvl(c_Inst_r_Day_Seance, 0) THEN
        c_r_Day_Seance := Nvl(c_Inst_r_Day_Seance, 0);
      ELSE
        c_r_Day_Seance := Nvl(Indeminfo.r_Day_Seance, 0);
      END IF;

      IF c_Inst_Cover_Price IS NOT NULL THEN
        c_f_Cover_Price := Nvl(c_Inst_Cover_Price, 0);
      ELSE
        c_f_Cover_Price := Indeminfo.f_Cover_Price;
      END IF;

      IF c_Inst_Exemption_Rate IS NOT NULL THEN
        c_Exemption_Rate := c_Inst_Exemption_Rate;
      ELSE
        c_Exemption_Rate := Indeminfo.Exemption_Rate;
      END IF;

      --enf. katsayisini bul.
      c_Max_Increase := 1;

      IF Nvl(Indeminfo.Max_Increase, 1) != 1 THEN
        BEGIN
          SELECT a.Max_Inc_Clearing_System_Id,
                 a.Max_Inc_Curr_Get_Type,
                 a.Max_Inc_Swift_Code
            INTO v_Max_Inc_Clearing_System_Id,
                 v_Max_Inc_Curr_Get_Type,
                 v_Max_Inc_Swift_Code
            FROM Koc_Oc_Prod_Package_Rel a
           WHERE a.Product_Id = Policyinfo.Product_Id
             AND a.Partition_Type = Policyinfo.Partition_Type
             AND a.Package_Id = Policyinfo.Package_Id
             AND a.Dim_Value = Policyinfo.Group_Code
             AND a.Validity_Start_Date <= Trunc(p_Date)
             AND Nvl(a.Validity_End_Date, Trunc(p_Date)) >= Trunc(p_Date);
        EXCEPTION
          WHEN OTHERS THEN
            SELECT a.Max_Inc_Clearing_System_Id,
                   a.Max_Inc_Curr_Get_Type,
                   a.Max_Inc_Swift_Code
              INTO v_Max_Inc_Clearing_System_Id,
                   v_Max_Inc_Curr_Get_Type,
                   v_Max_Inc_Swift_Code
              FROM Koc_Oc_Prod_Package_Rel a
             WHERE a.Product_Id = Policyinfo.Product_Id
               AND a.Partition_Type = Policyinfo.Partition_Type
               AND a.Package_Id = Policyinfo.Package_Id
               AND a.Dim_Value = '0'
               AND a.Validity_Start_Date <= Trunc(p_Date)
               AND Nvl(a.Validity_End_Date, Trunc(p_Date)) >= Trunc(p_Date);
        END;

        c_Max_Increase := Koc_Curr_Utils.Retrieve_Currency_Rate(v_Max_Inc_Swift_Code,
                                                                v_Max_Inc_Curr_Get_Type,
                                                                Trunc(p_Date),
                                                                v_Max_Inc_Clearing_System_Id,
                                                                TRUE) /
                          Koc_Curr_Utils.Retrieve_Currency_Rate(v_Max_Inc_Swift_Code,
                                                                v_Max_Inc_Curr_Get_Type,
                                                                Trunc(Policyinfo.Policy_Start_Date),
                                                                v_Max_Inc_Clearing_System_Id,
                                                                TRUE);

        IF c_Max_Increase > Nvl(Indeminfo.Max_Increase, 1) THEN
          c_Max_Increase := Nvl(Indeminfo.Max_Increase, 1);
        END IF;

        IF c_Max_Increase < 1 THEN
          c_Max_Increase := 1;
        END IF;
      END IF;

      -- c_r_cover_price  kurum tanimi da dikkate alinarak bulunanan kalan limit
      -- c_r_day_seance kurum tanimi da dikkate alinarak bulunanan kalan limit
      -- c_f_cover_price kurum tanimi da dikkate alinarak bulunanan  limit
      -- c_f_day_seance kurum tanimi da dikkate alinarak bulunanan  limit

      IF Nvl(c_Inst_Exemption_Sum, 0) > 0 THEN
        IF Nvl(c_Inst_Exemption_Sum, 0) >= c_Provision_Amount THEN
          c_Inst_Exemption_Sum := c_Provision_Amount;
          c_Provision_Amount   := 0;
        ELSE
          c_Provision_Amount := c_Provision_Amount -
                                Nvl(c_Inst_Exemption_Sum, 0);
        END IF;
      END IF;

      --27032014
      --aaktas
      --kurum i�in muafiyet �alismasin
      --
      -- Muafiyet tutarini d�zenleme
      --
      /* c_Exemption_Sum := 0;
      IF Nvl(c_Inst_Is_Not_Valid_Exemp, 0) = 0
      THEN
          IF Nvl(Indeminfo.r_Exemption_Sum, 0) > 0 AND
               Indeminfo.Exemption_Group IS NOT NULL
          THEN
              IF Nvl(Indeminfo.r_Exemption_Sum, 0) >= c_Provision_Amount
              THEN
                  c_Exemption_Sum    := c_Provision_Amount;
                  c_Provision_Amount := 0;
              ELSE
                  c_Exemption_Sum    := Nvl(Indeminfo.r_Exemption_Sum, 0);
                  c_Provision_Amount := c_Provision_Amount - c_Exemption_Sum;
              END IF;
          END IF;
      END IF; */
      --
      c_Exemption_Sum := 0;

      IF Nvl(c_Inst_Is_Not_Valid_Exemp, 0) = 0 THEN
        IF (Nvl(Indeminfo.r_Exemption_Sum, 0) > 0 OR
           p_Exemption_Ovr_Amount IS NOT NULL) AND
           Indeminfo.Exemption_Group IS NOT NULL THEN
          -- Muafiyet tutarini d�zenleme
          IF p_Exemption_Ovr_Amount IS NOT NULL THEN
            c_Exemption_Sum := p_Exemption_Ovr_Amount;
          ELSE
            IF Nvl(Indeminfo.r_Exemption_Sum, 0) >= c_Provision_Amount THEN
              c_Exemption_Sum := c_Provision_Amount;
            ELSE
              c_Exemption_Sum := Nvl(Indeminfo.r_Exemption_Sum, 0);
            END IF;
          END IF;

          c_Provision_Amount := c_Provision_Amount - c_Exemption_Sum;
        END IF;
      END IF;

      c_Day_Seance := Nvl(p_Day_Seance, 0);

      --
      IF Indeminfo.Indemnity_Payment_Type IN ('NORM', '1KEZ') THEN
        --
        IF c_Is_Unlimited = 1 THEN
          IF Nvl(c_r_Day_Seance, 0) < c_Day_Seance THEN
            IF c_r_Day_Seance = 0 THEN
              c_Day_Seance_Amount := 0;
            ELSE
              c_Day_Seance_Amount := Nvl(c_r_Day_Seance, 0) *
                                     (c_Provision_Amount / c_Day_Seance);
            END IF;

            -- kalan seans sayisinin miktari kadar �deme yapilir.
            IF c_Day_Seance_Amount < c_Provision_Amount THEN
              c_Provision_Amount := c_Day_Seance_Amount;
            END IF;

            c_Day_Seance := Nvl(c_r_Day_Seance, 0);
          END IF;

          u_r_Cover_Price      := NULL;
          u_r_Exemption_Sum    := c_Exemption_Sum;
          u_s_Provision_Amount := c_Provision_Amount *
                                  (1 - c_Exemption_Rate);
          u_s_Spend_Total      := p_Provision_Amount;

          --- g�ne g�re c_prov amount degisiyor spend ilk deger olmali
          u_s_Spend_Day_Seance := p_Day_Seance;

          --- g�ne g�re c_day_seance amount degisiyor spend ilk deger olmali
          u_s_Exemption_Sum := c_Exemption_Sum;
          u_r_Day_Seance    := c_Day_Seance;
        ELSE
          --Mustafa Ku Limit asim ve muafiyet ayni anda geldiginde hataya neden oluyor
          --Hibrit testleri esnasinda ortaya �ikti 20.03.2016
          /*                   IF Nvl(c_r_Cover_Price, 0) * c_Max_Increase <  c_Provision_Amount   - c_Exemption_Sum
          THEN

                  c_Provision_Amount := Nvl(c_r_Cover_Price, 0) * c_Max_Increase ;

          END IF;*/

          IF Nvl(c_r_Cover_Price, 0) * c_Max_Increase < c_Provision_Amount THEN
            c_Provision_Amount := Nvl(c_r_Cover_Price, 0) * c_Max_Increase;
          END IF;

          /* --yasemin
          IF Nvl(c_r_Cover_Price, 0) * c_Max_Increase < (c_Provision_Amount + c_Exemption_Sum)
          THEN
              -- kalan limitin exemption sumdan k���k olmasi durumuda kontrol edildi. bu tip bir durum olur mu ? bilmiyorum!
              IF Nvl(c_r_Cover_Price, 0) * c_Max_Increase > c_Exemption_Sum
              THEN
                  c_Provision_Amount := Nvl(c_r_Cover_Price, 0) * c_Max_Increase - c_Exemption_Sum;
              ELSE
                  c_Provision_Amount := 0;
                  c_Exemption_Sum    := Nvl(c_r_Cover_Price, 0) * c_Max_Increase;
              END IF;
          END IF;*/

          --
          IF Nvl(c_r_Day_Seance, 0) < c_Day_Seance THEN
            IF c_r_Day_Seance = 0 THEN
              c_Day_Seance_Amount := 0;
            ELSE
              --abdullah
              --08122014
              --talep edilen seansin birim fiyati alinmali

              --c_day_seance_amount := nvl (c_r_day_seance, 0) * (c_provision_amount / c_day_seance);
              c_Day_Seance_Amount := Nvl(c_r_Day_Seance, 0) *
                                     (p_Provision_Amount / c_Day_Seance);

              IF c_Day_Seance_Amount > c_Provision_Amount THEN
                c_Day_Seance_Amount := c_Provision_Amount;

                IF c_r_Day_Seance >
                   Round(c_Provision_Amount /
                         (p_Provision_Amount / c_Day_Seance)) THEN
                  c_r_Day_Seance := Round(c_Provision_Amount /
                                          (p_Provision_Amount /
                                          c_Day_Seance));
                END IF;
              END IF;
            END IF;

            -- kalan seans sayisinin miktari kadar �deme yapilir.
            IF c_Day_Seance_Amount < c_Provision_Amount THEN
              c_Provision_Amount := c_Day_Seance_Amount;
            END IF;

            c_Day_Seance := Nvl(c_r_Day_Seance, 0);
          END IF;

          u_r_Cover_Price      := c_Provision_Amount; -- + c_exemption_sum; 17/01/2011 muafiyetin kalan limitten d�smemesi i�in yg
          u_r_Day_Seance       := c_Day_Seance;
          u_r_Exemption_Sum    := c_Exemption_Sum;
          u_s_Provision_Amount := c_Provision_Amount *
                                  (1 - c_Exemption_Rate);
          u_s_Spend_Total      := p_Provision_Amount;

          --- g�ne g�re c_prov amount degisiyor spend ilk deger olmali
          u_s_Spend_Day_Seance := p_Day_Seance;

          --- g�ne g�re c_day_seance amount degisiyor spend ilk deger olmali
          u_s_Exemption_Sum := c_Exemption_Sum;
        END IF;
      ELSIF Indeminfo.Indemnity_Payment_Type = 'GUN' THEN
        --
        IF c_Day_Seance > c_r_Day_Seance THEN
          c_Day_Seance := c_r_Day_Seance;
        END IF;

        --
        IF Nvl(c_Day_Seance, 0) = 0 THEN
          --
          IF c_Provision_Amount > c_f_Cover_Price THEN
            c_Provision_Amount := c_f_Cover_Price;
          END IF;
        ELSE
          --
          IF c_Provision_Amount > c_f_Cover_Price * c_Day_Seance THEN
            c_Provision_Amount := c_f_Cover_Price * c_Day_Seance;
          END IF;
        END IF;

        u_r_Day_Seance       := c_Day_Seance;
        u_r_Cover_Price      := NULL;
        u_r_Exemption_Sum    := c_Exemption_Sum;
        u_s_Provision_Amount := c_Provision_Amount * (1 - c_Exemption_Rate);
        u_s_Spend_Total      := p_Provision_Amount;
        u_s_Spend_Day_Seance := p_Day_Seance;
        u_s_Exemption_Sum    := c_Exemption_Sum;
      ELSIF Indeminfo.Indemnity_Payment_Type = 'DEFA' THEN

        
          KOC_CLM_HLTH_TRNX.Getindemtotalsmdf(p_Contract_Id,
                            p_Partition_No,
                            p_Claim_Inst_Type,
                            p_Claim_Inst_Loc,
                            p_Country_Group,
                            Indeminfo.Parent_Cover_Code,
                            p_Policyinfo.Package_Id,
                            p_Policyinfo.Package_Date,
                            Trunc(p_Date),
                            p_User_Id,
                            p_Is_Pool_Cover,
                            p_Is_Special_Cover,
                            Cur);
          FETCH Cur
            INTO Indeminfoparent;
          CLOSE Cur;

       

        c_Parent_Is_Unlimited   := Nvl(Indeminfoparent.Is_Unlimited, 0);
        c_Parent_Indemnity_Type := Nvl(Indeminfoparent.Indemnity_Payment_Type,
                                       'X');
        c_Parent_r_Cover_Price  := Indeminfoparent.r_Cover_Price;

        IF c_Parent_Is_Unlimited = 0 AND
           c_Parent_Indemnity_Type IN ('NORM', '1KEZ') THEN
          c_Parent_Provision_Amount := c_Provision_Amount;

          IF Nvl(c_Parent_r_Cover_Price, 0) * c_Max_Increase <
             (c_Provision_Amount + c_Exemption_Sum) THEN
            -- kalan limitin exemption sumdan k���k olmasi durumuda kontrol edildi. bu tip bir durum olur mu ? bilmiyorum!
            IF Nvl(c_Parent_r_Cover_Price, 0) * c_Max_Increase >
               c_Exemption_Sum THEN
              c_Parent_Provision_Amount := Nvl(c_Parent_r_Cover_Price, 0) *
                                           c_Max_Increase - c_Exemption_Sum;
            ELSE
              c_Parent_Provision_Amount := 0;
              c_Exemption_Sum           := Nvl(c_Parent_r_Cover_Price, 0) *
                                           c_Max_Increase;
            END IF;
          END IF;
        END IF;

        IF c_Provision_Amount > c_f_Cover_Price THEN
          c_Provision_Amount := c_f_Cover_Price;
        END IF;

        IF c_Parent_Is_Unlimited = 0 AND
           c_Parent_Indemnity_Type IN ('NORM', '1KEZ') THEN
          IF c_Provision_Amount > c_Parent_Provision_Amount THEN
            c_Provision_Amount := c_Parent_Provision_Amount;
          END IF;
        END IF;

        IF c_Day_Seance > c_r_Day_Seance THEN
          c_Day_Seance := c_r_Day_Seance;
        END IF;

        u_r_Day_Seance  := c_Day_Seance;
        u_r_Cover_Price := NULL;

        IF c_Parent_Is_Unlimited = 0 AND
           c_Parent_Indemnity_Type IN ('NORM', '1KEZ') THEN
          u_r_Cover_Price := c_Provision_Amount;
        END IF;

        u_r_Exemption_Sum    := c_Exemption_Sum;
        u_s_Provision_Amount := c_Provision_Amount * (1 - c_Exemption_Rate);
        u_s_Spend_Total      := p_Provision_Amount;
        u_s_Spend_Day_Seance := p_Day_Seance;
        u_s_Exemption_Sum    := c_Exemption_Sum;
      ELSIF Indeminfo.Indemnity_Payment_Type = '2YIL' THEN
        IF Nvl(Indeminfo.s_Spend_Total, 0) > 0 THEN
          c_Provision_Amount := 0;
          c_Day_Seance       := 0;
        ELSE
          Getoldpolicy(p_Contract_Id,
                       p_Partition_No,
                       p_Part_Id,
                       v_Old_Contract_Id,
                       v_Old_Partition_No,
                       v_Term_End_Date);

          
            KOC_CLM_HLTH_TRNX.Getindemtotals(v_Old_Contract_Id,
                           v_Old_Partition_No,
                           p_Claim_Inst_Type,
                           p_Claim_Inst_Loc,
                           p_Country_Group,
                           p_Cover_Code,
                           v_Term_End_Date,
                           0,
                           0,
                           p_User_Id,
                           p_Is_Pool_Cover,
                           p_Is_Special_Cover,
                           Cur);

          FETCH Cur
            INTO Oldindeminfo;

          CLOSE Cur;

          IF Nvl(Oldindeminfo.s_Spend_Total, 0) > 0 THEN
            c_Provision_Amount := 0;
            c_Day_Seance       := 0;
          ELSE
            IF c_Provision_Amount > c_f_Cover_Price THEN
              c_Provision_Amount := c_f_Cover_Price;
            END IF;

            IF c_Day_Seance > c_f_Day_Seance THEN
              c_Day_Seance := c_f_Day_Seance;
            END IF;
          END IF;
        END IF;

        u_r_Day_Seance       := c_Day_Seance;
        u_r_Cover_Price      := 0;
        u_r_Exemption_Sum    := 0;
        u_s_Provision_Amount := c_Provision_Amount * (1 - c_Exemption_Rate);
        u_s_Spend_Total      := p_Provision_Amount;
        u_s_Spend_Day_Seance := p_Day_Seance;
        u_s_Exemption_Sum    := c_Exemption_Sum;
      END IF;

      p_Out_Provision_Amount := Round(c_Provision_Amount * (1 / v_Parite),
                                      Find_Round_Digit(p_Swift_Code, 'P'));
      p_Out_Day_Seance       := c_Day_Seance;
      p_Out_Exemption_Rate   := c_Exemption_Rate;
      p_Out_Exemption_Sum    := Round(c_Exemption_Sum * (1 / v_Parite),
                                      Find_Round_Digit(p_Swift_Code, 'P'));
      p_Out_Inst_Exemp_Sum   := Round(c_Inst_Exemption_Sum * (1 / v_Parite),
                                      Find_Round_Digit(p_Swift_Code, 'P'));

      --kalan limiti bulmak i�in geldiginde anlamli.
      p_r_Day_Seance  := c_r_Day_Seance;
      p_r_Cover_Price := Round(c_r_Cover_Price,
                               Find_Round_Digit(p_Swift_Code, 'P'));

      --mustafaku
      -- Limit asim ve muafiyet beraber oldugunda probleme neden oluyor Hibrit testleri esnasinda ortaya �ikti
      /*            IF p_r_Cover_Price < p_Provision_Amount - c_Exemption_Sum
      THEN
          p_Out_Over_Price := To_Char(p_Provision_Amount - p_r_Cover_Price - c_Exemption_Sum) * (1 / v_Parite);
      ELSE
          p_Out_Over_Price := 0;
      END IF; */
      IF p_r_Cover_Price < p_Provision_Amount THEN
        p_Out_Over_Price := To_Char(p_Provision_Amount - p_r_Cover_Price) *
                            (1 / v_Parite);
      ELSE
        p_Out_Over_Price := 0;
      END IF;

      p_Inst_Provision_Aval_Code := c_Inst_Provision_Aval_Code;
      p_Inst_Is_Cover_Val        := c_Inst_Is_Cover_Val;
    END IF;

   END Computeremaning;
  
  
   PROCEDURE Computeremaning_Main(p_Contract_Id              NUMBER,
                            p_Partition_No             NUMBER,
                            p_Part_Id                  NUMBER,
                            p_Claim_Id                 NUMBER,
                            p_Sf_No                    NUMBER,
                            p_Institute_Code           NUMBER,
                            p_Claim_Inst_Type          VARCHAR2,
                            p_Claim_Inst_Loc           VARCHAR2,
                            p_Country_Group            NUMBER,
                            p_Location_Code            NUMBER,
                            p_Cover_Code               VARCHAR2,
                            p_Swift_Code               VARCHAR2,
                            p_Date                     DATE,
                            p_Invoice_Date             DATE,
                            p_Realization_Date         DATE,
                            p_Prov_Date_Time           DATE,
                            p_Provision_Amount         NUMBER,
                            p_Day_Seance               NUMBER,
                            p_User_Id                  VARCHAR2,
                            p_Is_Pool_Cover            NUMBER,
                            p_Is_Special_Cover         NUMBER,
                            p_Process_Type             NUMBER DEFAULT 0,
                            p_Out_Provision_Amount     OUT NUMBER,
                            p_Out_Day_Seance           OUT NUMBER,
                            p_Out_Exemption_Rate       OUT NUMBER,
                            p_Out_Exemption_Sum        OUT NUMBER,
                            p_Out_Inst_Exemp_Sum       OUT NUMBER,
                            p_r_Day_Seance             OUT NUMBER,
                            p_r_Cover_Price            OUT NUMBER,
                            p_Inst_Provision_Aval_Code OUT VARCHAR2,
                            p_Inst_Is_Cover_Val        OUT NUMBER,
                            p_Out_Over_Price           OUT VARCHAR2,
                            p_Exemption_Ovr_Amount     IN NUMBER DEFAULT NULL, -- Muafiyet tutarini d�zenleme
                            p_Is_Referral              IN NUMBER DEFAULT NULL) IS
    Cur            KOC_CLM_HLTH_TRNX.Refcur;
    Policyinfo     Koc_v_Hlth_Insured_Info_Indem%ROWTYPE;
    Institutinfo   Koc_v_Clm_Suppliers_Main%ROWTYPE;
    p_Package_Id   NUMBER;
    p_Package_Date DATE;
  BEGIN
    IF p_Claim_Id IS NOT NULL THEN
      --Koc_Clm_Hlth_Utils.Getpolinfoforindembyclm(p_Claim_Id, NULL, Cur);
      KOC_CLM_HLTH_TRNX.Getpolinfoforindembyclm_Trnx(p_Claim_Id, NULL, Cur);
      FETCH Cur
        INTO Policyinfo;

      CLOSE Cur;
    END IF;

    IF Policyinfo.Contract_Id IS NULL OR
       Nvl(Policyinfo.Contract_Id, 0) != p_Contract_Id OR
       Nvl(Policyinfo.Partition_No, 0) != p_Partition_No THEN
      Koc_Clm_Hlth_Utils.Getpackageinfoforindem(p_Contract_Id,
                                                p_Partition_No,
                                                p_Date,
                                                p_Package_Id,
                                                p_Package_Date,
                                                p_Part_Id); --neslihank 31072017 plan de�i�ikli�i g�rm�� planlar i�in bu kontrol eklenmi�tir.

      IF p_Package_Id IS NOT NULL THEN
        Koc_Clm_Hlth_Utils.Getpolinfoforindemnity(p_Contract_Id,
                                                  p_Partition_No,
                                                  p_Part_Id,
                                                  p_Package_Id,
                                                  p_Package_Date,
                                                  p_Date,
                                                  Cur);
      ELSE
        Koc_Clm_Hlth_Utils.Getpolinfoforindemnity(p_Contract_Id,
                                                  p_Partition_No,
                                                  p_Part_Id,
                                                  p_Date,
                                                  Cur);
      END IF;

      FETCH Cur
        INTO Policyinfo;

      CLOSE Cur;
    END IF;

    IF Policyinfo.Contract_Id IS NULL THEN
      Raise_Application_Error(-20200, 'Poli�e bulunamadi.');
    END IF;

    Koc_Clm_Hlth_Utils.Getinstitutinfobycode(p_Institute_Code, p_Date, Cur);

    FETCH Cur
      INTO Institutinfo;

    CLOSE Cur;

    IF Institutinfo.Institute_Code IS NULL THEN
      Koc_Clm_Hlth_Utils.Getlastinstitutinfobycode(p_Institute_Code, Cur);

      FETCH Cur
        INTO Institutinfo;

      CLOSE Cur;
    END IF;

    Computeremaning(p_Contract_Id,
                    p_Partition_No,
                    p_Part_Id,
                    p_Claim_Id,
                    p_Sf_No,
                    p_Institute_Code,
                    p_Claim_Inst_Type,
                    p_Claim_Inst_Loc,
                    p_Country_Group,
                    p_Location_Code,
                    p_Cover_Code,
                    p_Swift_Code,
                    p_Date,
                    p_Invoice_Date,
                    p_Realization_Date,
                    p_Prov_Date_Time,
                    p_Provision_Amount,
                    p_Day_Seance,
                    Policyinfo,
                    Institutinfo,
                    p_User_Id,
                    p_Is_Pool_Cover,
                    p_Is_Special_Cover,
                    p_Process_Type,
                    p_Out_Provision_Amount,
                    p_Out_Day_Seance,
                    p_Out_Exemption_Rate,
                    p_Out_Exemption_Sum,
                    p_Out_Inst_Exemp_Sum,
                    p_r_Day_Seance,
                    p_r_Cover_Price,
                    p_Inst_Provision_Aval_Code,
                    p_Inst_Is_Cover_Val,
                    p_Out_Over_Price,
                    p_Exemption_Ovr_Amount,
                    p_Is_Referral); -- Muafiyet tutarini d�zenleme
  END Computeremaning_Main;
  BEGIN
  /*  KOC_CLM_HLTH_TRNX.Computeremaning(v_Contract_Id,
v_Partition_No,
v_Part_Id,
v_Claim_Id,
v_Sf_No,
v_Institute_Code,
v_Claim_Inst_Type,
v_Claim_Inst_Loc,
v_Country_Group,
v_Location_Code,
v_Cover_Code,
v_Swift_Code,
v_Date,
v_Invoice_Date,
v_Realization_Date,
v_Prov_Date_Time,
v_Provision_Amount,
v_Day_Seance,
v_Policyinfo,
v_Institutinfo,
v_User_Id,
v_Is_Pool_Cover,
v_Is_Special_Cover,
v_Process_Type,
v_Out_Provision_Amount,
v_Out_Day_Seance,
v_Out_Exemption_Rate,
v_Out_Exemption_Sum,
v_Out_Inst_Exemp_Sum,
v_r_Day_Seance,
v_r_Cover_Price,
v_Inst_Provision_Aval_Code,
v_Inst_Is_Cover_Val,
v_Out_Over_Price,
v_Exemption_Ovr_Amount,
v_Is_Referral);*/

--customer.koc_clm_hlth_trnx.computeremaning
computeremaning_Main
(p_contract_id => v_contract_id,
                                             p_partition_no => v_partition_no,
                                             p_part_id => v_part_id,
                                             p_claim_id => v_claim_id,
                                             p_sf_no => v_sf_no,
                                             p_institute_code => v_institute_code,
                                             p_claim_inst_type => v_claim_inst_type,
                                             p_claim_inst_loc => v_claim_inst_loc,
                                             p_country_group => v_country_group,
                                             p_location_code => v_location_code,
                                             p_cover_code => v_cover_code,
                                             p_swift_code => v_swift_code,
                                             p_date => v_date,
                                             p_invoice_date => v_invoice_date,
                                             p_realization_date => v_realization_date,
                                             p_prov_date_time => v_prov_date_time,
                                             p_provision_amount => v_provision_amount,
                                             p_day_seance => v_day_seance,
                                             p_user_id => v_user_id,
                                             p_is_pool_cover => v_is_pool_cover,
                                             p_is_special_cover => v_is_special_cover,
                                             p_process_type => v_process_type,
                                             p_out_provision_amount => v_out_provision_amount,
                                             p_out_day_seance => v_out_day_seance,
                                             p_out_exemption_rate => v_out_exemption_rate,
                                             p_out_exemption_sum => v_out_exemption_sum,
                                             p_out_inst_exemp_sum => v_out_inst_exemp_sum,
                                             p_r_day_seance => v_r_day_seance,
                                             p_r_cover_price => v_r_cover_price,
                                             p_inst_provision_aval_code => v_inst_provision_aval_code,
                                             p_inst_is_cover_val => v_inst_is_cover_val,
                                             p_out_over_price => v_out_over_price,
                                             p_exemption_ovr_amount => v_exemption_ovr_amount,
                                             p_is_referral => v_is_referral);

  DBMS_OUTPUT.PUT_LINE('p_out_prov_amo             ='||v_Out_Provision_Amount);
  DBMS_OUTPUT.PUT_LINE('p_out_day_seance           ='||v_Out_Day_Seance);
  DBMS_OUTPUT.PUT_LINE('p_out_Exemption_Rate       ='||v_Out_Exemption_Rate);
  DBMS_OUTPUT.PUT_LINE('p_out_Exemption_Sum        ='||v_Out_Exemption_Sum);
  DBMS_OUTPUT.PUT_LINE('p_out_Inst_Exemp_Sum       ='||v_Out_Inst_Exemp_Sum);
  DBMS_OUTPUT.PUT_LINE('p_r_Day_Seance             ='||v_r_Day_Seance);
  DBMS_OUTPUT.PUT_LINE('p_r_Cover_Price            ='||v_r_Cover_Price);
  DBMS_OUTPUT.PUT_LINE('p_Inst_Provision_Aval_Code ='||v_Inst_Provision_Aval_Code);
  DBMS_OUTPUT.PUT_LINE('p_Inst_Is_Cover_Val        ='||v_Inst_Is_Cover_Val);
  DBMS_OUTPUT.PUT_LINE('p_Out_Over_Price           ='||v_Out_Over_Price);
  END;
  
  
