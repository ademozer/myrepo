import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SearchInWord {
    public static void searchTextInFile(String fileName, String searchText) throws Exception {
        XWPFDocument docx = new XWPFDocument(new FileInputStream(fileName));
        XWPFWordExtractor we = new XWPFWordExtractor(docx);
        Pattern p = Pattern.compile(searchText.toLowerCase());
	    String INPUT = we.getText();
        Matcher m = p.matcher(INPUT.toLowerCase());   // get a matcher object  	
        int count = 0;
        while(m.find()) {
            count++;           
        }
		if(count>0) {			 
			System.out.println("<tr><td>"+fileName+"</td><td>"+count+"</td><td>"+INPUT+"</td></tr>");
		}
    }
   
    public static void listFilesForFolder(File folder, String searchText) throws Exception {
        String temp = "";
        for (File fileEntry : folder.listFiles()) {
			if (fileEntry.isDirectory()) {			
				listFilesForFolder(fileEntry, searchText);
			} else {
				if (fileEntry.isFile()) {
					temp = fileEntry.getName();
					if ((temp.substring(temp.lastIndexOf('.') + 1, temp.length()).toLowerCase()).equals("docx")) {						
						try{
							temp = folder.getAbsolutePath()+ "\\" +temp;
						    searchTextInFile(temp, searchText); 
						} catch(Exception e) {
							System.out.println("<tr><td>"+temp+"</td><td>0</td><td>"+e.getMessage()+"</td></tr>");
						}
					}
			    }
			}
		}   
    }
  
    public static void main(String[] args)throws Exception  {
       
	    String file_name = args[0];
	       
	    String REGEX = "\\b";
	    int cnt = 0;
	    for(String argv : args) {
		    if(cnt>0) {
			    REGEX += argv;
			    if(cnt < (args.length-1)) {
				    REGEX += " ";
			    }
		    }
		    cnt++;
	    }
	    REGEX += "\\b";      
	    File folder = new File(file_name);
	    listFilesForFolder(folder, REGEX);       
    }
}