import oracle.forms.jdapi.*;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.List;
import java.util.ArrayList;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
public class Fmb2Xls
{
 private static Map<Integer, String> item_type_map = new HashMap<Integer,String>();
 private static Map<Integer, String> just_type_map = new HashMap<Integer,String>();
 private static Map<Integer, String> data_type_map = new HashMap<Integer,String>();
 private static Map<Integer, String> data_lensem_map = new HashMap<Integer,String>();
 private static Map<Integer, String> calc_mod_map = new HashMap<Integer,String>();
 private static Map<Integer, String> calc_sum_map = new HashMap<Integer,String>();
 private static Map<Integer, String> phys_bevel_map = new HashMap<Integer,String>();
 private static Map<Integer, String> prompt_disp_map = new HashMap<Integer,String>();
 private static Map<Integer, String> prompt_just_map = new HashMap<Integer,String>();
 private static Map<Integer, String> prompt_ated_map = new HashMap<Integer,String>();
 private static Map<Integer, String> prompt_algn_map = new HashMap<Integer,String>();
 private static Map<Integer, String> prompt_reor_map = new HashMap<Integer,String>();
 private static Map<Integer, String> font_weight_map = new HashMap<Integer,String>();
 private static Map<Integer, String> font_style_map = new HashMap<Integer,String>();
 private static Map<Integer, String> font_space_map = new HashMap<Integer,String>();
 private static Map<Integer, String> func_wrap_map = new HashMap<Integer,String>();
 private static Map<Integer, String> func_case_map = new HashMap<Integer,String>();  
 private static Map<Integer, String> img_format_map = new HashMap<Integer,String>(); 
 private static Map<Integer, String> img_depth_map = new HashMap<Integer,String>(); 
 private static Map<Integer, String> img_dispq_map = new HashMap<Integer,String>(); 
 private static Map<Integer, String> img_sizing_map = new HashMap<Integer,String>(); 
 private static Map<Integer, String> list_type_map = new HashMap<Integer,String>();
 private static Map<Integer, String> block_ns_map = new HashMap<Integer,String>();
 private static Map<Integer, String> block_recor_map = new HashMap<Integer,String>();
 private static Map<Integer, String> block_qdst_map = new HashMap<Integer,String>();;
 private static Map<Integer, String> block_dstyp_map = new HashMap<Integer,String>();
 private static Map<Integer, String> block_dsmod_map = new HashMap<Integer,String>();
 private static Map<Integer, String> block_lcmd_map = new HashMap<Integer,String>();
 private static Map<Integer, String> block_kymd_map = new HashMap<Integer,String>();
 private static Map<Integer, String> block_dmtt_map = new HashMap<Integer,String>();
 private static Map<Integer, String> trg_style_map = new HashMap<Integer,String>();
 private static Map<Integer, String> trg_hie_map = new HashMap<Integer,String>();
 private static Map<Integer, String> cnv_type_map = new HashMap<Integer,String>();
 private static Map<Integer, String> lst_type_map = new HashMap<Integer,String>();
 private static Map<Integer, String> prm_type_map = new HashMap<Integer,String>();
 private static Map<Integer, String> alert_style_map = new HashMap<Integer,String>();
 private static Map<Integer, String> alert_btn_map = new HashMap<Integer,String>();
 private static Map<Integer, String> rg_cdt_map = new HashMap<Integer,String>();
 private static Map<Integer, String> rg_type_map = new HashMap<Integer,String>();
 private static Map<Integer, String> va_type_map = new HashMap<Integer,String>();
 private static Map<Integer, String> win_style_map = new HashMap<Integer,String>();
 private static Map<Integer, String> mi_ityp_map = new HashMap<Integer,String>();
 private static Map<Integer, String> mi_mgit_map = new HashMap<Integer,String>();
 private static Map<Integer, String> mi_ctyp_map = new HashMap<Integer,String>();
 private static Map<Integer, String> rep_exm_map = new HashMap<Integer,String>();
 private static Map<Integer, String> rep_com_map = new HashMap<Integer,String>();
 private static Map<Integer, String> rep_dtyp_map = new HashMap<Integer,String>();
 private static Map<Integer, String> rel_typ_map = new HashMap<Integer,String>();
 private static Map<Integer, String> rel_del_map = new HashMap<Integer,String>();
 private static Map<Integer, String> fm_dre_map  = new HashMap<Integer,String>();
 private static Map<Integer, String> fm_mnl_map  = new HashMap<Integer,String>();
 private static Map<Integer, String> fm_vlu_map  = new HashMap<Integer,String>();
 private static Map<Integer, String> fm_inm_map  = new HashMap<Integer,String>();
 private static Map<Integer, String> fm_ism_map  = new HashMap<Integer,String>();
                
 private static boolean with_properties = true;
 
 public static void disableWithProperties() {
	 with_properties = false;
 }
 
 public static boolean isWithProperties() {
	 return with_properties;
 }
 
 public static List<Map<String,String>> printLibraries(JdapiIterator it, String indent) {	
	List<Map<String,String>>  list = new ArrayList<Map<String,String>>();
	while (it.hasNext())
	{
		Map<String,String> props = new HashMap<String,String>();
		AttachedLibrary lib = (AttachedLibrary)it.next();		
		if(isWithProperties()) {			
			props.put("NAME", lib.getName());
			props.put("COMMENTS", printComments(lib.getComment(),indent + "            "));
			props.put("LIBRARY_LOCATION", lib.getLibraryLocation());			
		}
		list.add(props);	
	}
	return list;
	 
 }
 public static String printTriggerNames(JdapiIterator it) {
    String res = "";
	while (it.hasNext())
	{
		Trigger trg = (Trigger)it.next();
		res += trg.getName() + "\n";		
	}
	return res;
 }
 public static List<Map<String,String>> printTriggers(JdapiIterator it, String indent) {
	List<Map<String,String>>  list = new ArrayList<Map<String,String>>(); 
	while (it.hasNext())
	{    
		Trigger trg = (Trigger)it.next();	
		list.add(printTrigger(trg, indent));
	}
	return list;
 }
 public static Map<String,String> printTrigger(Trigger trg, String indent) {

	Map<String,String> props = new HashMap<String,String>();
	if(isWithProperties()) {
		
		props.put("NAME", trg.getName());
	    props.put("SUBCLASS_INFORMATION", trg.getParentName());
		props.put("COMMENTS", printComments(trg.getComment(),indent + "            "));		
		props.put("TRIGGER_STYLE", (String) trg_style_map.get(trg.getTriggerStyle()));		
		props.put("TRIGGER_TEXT", printClause("Trigger_Text", trg.getTriggerText(),indent + "            "));
		props.put("FIRE_IN_ENTER_QUERY_MODE", (trg.isFireInQuery() ? "Yes" : "No"));		
		props.put("EXECUTION_HIERARCHY", (String) trg_hie_map.get(trg.getExecuteHierarchy()));		
	    props.put("DISPLAY_IN_KEYBOARD_HELP", (trg.isDisplayInKeyboardHelp() ? "Yes" : "No"));		
		props.put("KEYBOARD_HELP_TEXT", printClause("Keyboard_Help_Text", trg.getKeyboardHelpText(),indent + "            "));  
	}
    return props;	
 }

 public static List<Map<String,String>> printProgramUnits(JdapiIterator it, String indent) {
	List<Map<String,String>>  list = new ArrayList<Map<String,String>>();  
	while (it.hasNext())
	{
		ProgramUnit pu = (ProgramUnit)it.next();
		list.add(printProgramUnit(pu, indent));
	}
	return list;
 }
 public static Map<String,String> printProgramUnit(ProgramUnit pu, String indent) {	
	Map<String,String> props = new HashMap<String,String>();
	if(isWithProperties()) {		
		props.put("NAME", pu.getName());
		props.put("SUBCLASS_INFORMATION", pu.getParentName());    				
		props.put("COMMENTS",printComments(pu.getComment(),indent + "            "));	   		
		props.put("TEXT", printClause("Program_Unit_Text", pu.getProgramUnitText(), indent + "            "));
	}
    return props;	
 }

 public static List<Map<String,String>>  printBlocks(JdapiIterator it,String indent) {
	List<Map<String,String>>  list = new ArrayList<Map<String,String>>(); 
	while (it.hasNext())
	{
		Block block = (Block)it.next();
		list.add(printBlock(block, indent));
	}
	return list;
 }
 
 public static List<Map<String,String>>  printBlockTriggers(JdapiIterator it,String indent) {
	List<Map<String,String>>  list = new ArrayList<Map<String,String>>(); 
	while (it.hasNext())
	{
		Block block = (Block)it.next();
		List<Map<String,String>>  itemList = printTriggers(block.getTriggers(),"   ");
		if(itemList.size()>0) {
			Set<String> keySet = itemList.get(0).keySet();	     			
			for(Map<String,String> item : itemList) {				
                item.put("BLOCK_NAME",block.getName());   				 
                list.add(item);				 
			}		
		}		
	}
	return list;
 }
 public static List<Map<String,String>>  printBlockRelations(JdapiIterator it,String indent) {
	List<Map<String,String>>  list = new ArrayList<Map<String,String>>(); 
	while (it.hasNext())
	{
		Block block = (Block)it.next();
		List<Map<String,String>>  itemList = printRelations(block.getRelations(),"   ");
		if(itemList.size()>0) {
			Set<String> keySet = itemList.get(0).keySet();	     			
			for(Map<String,String> item : itemList) {				
                item.put("BLOCK_NAME",block.getName());   				 
                list.add(item);				 
			}		
		}		
	}
	return list;
 }
 
 public static List<Map<String,String>>  printBlockItems(JdapiIterator it,String indent) {
	List<Map<String,String>>  list = new ArrayList<Map<String,String>>(); 
	while (it.hasNext())
	{
		Block block = (Block)it.next();
		List<Map<String,String>>  itemList = printItems(block.getItems(),"   ");
		if(itemList.size()>0) {
			Set<String> keySet = itemList.get(0).keySet();	     			
			for(Map<String,String> item : itemList) {				
                item.put("BLOCK_NAME",block.getName());   				 
                list.add(item);				 
			}		
		}		
	}
	return list;
 }
 
 public static List<Map<String,String>>  printBlockItemTriggers(JdapiIterator it,String indent) {
	List<Map<String,String>>  list = new ArrayList<Map<String,String>>(); 
	while (it.hasNext())
	{
		Block block = (Block)it.next();
		JdapiIterator it2 = block.getItems();
		while (it2.hasNext()) {
			Item item = (Item) it2.next();
			List<Map<String,String>>  trgList = printTriggers(item.getTriggers(),"   ");
			if(trgList.size()>0) {
				Set<String> keySet = trgList.get(0).keySet();	     			
				for(Map<String,String> trg : trgList) {				
					trg.put("BLOCK_NAME",block.getName());  
                    trg.put("ITEM_NAME", item.getName());  					
					list.add(trg);				 
				}		
		    }
		}		
	}
	return list;
 }
 
 public static Map<String,String> printBlock(Block bl, String indent) {	
	Map<String,String> props = new HashMap<String,String>();
	props.put("TRIGGERS",printTriggerNames(bl.getTriggers()));
	props.put("ITEMS",printItemNames(bl.getItems()));
	props.put("RELATIONS",printRelationNames(bl.getRelations()));	
	if(isWithProperties()) {		
		props.put("NAME", bl.getName());		
		props.put("SUBCLASS_INFORMATION", bl.getParentName());
	    props.put("COMMENTS", printComments(bl.getComment(),indent + "            "));
		props.put("NAVIGATION_STYLE", (String) block_ns_map.get(bl.getNavigationStyle()));		
		props.put("PREVIOUS_NAVIGATION_DATA_BLOCK", bl.getPreviousNavigationBlockName());
	    props.put("NEXT_NAVIGATION_DATA_BLOCK", bl.getNextNavigationBlockName());
		props.put("CURRENT_RECORD_VISUAL_ATTRIBUTE_GROUP", bl.getRecordVisualAttributeGroupName());		
		props.put("QUERY_ARRAY_SIZE", ""+bl.getRecordsFetchedCount());
	    props.put("NUMBER_OF_RECORD_BUFFERED", "" + bl.getRecordsBufferedCount());
		props.put("NUMBER_OF_RECORD_DISPLAYED", "" + bl.getRecordsDisplayCount());
	    props.put("QUERY_ALL_RECORDS", (bl.isQueryAllRecords() ? "Yes" : "No"));
	    props.put("RECORD_ORIENTATION", (String) block_recor_map.get(bl.getRecordOrientation()));
		props.put("SINGLE_RECORD",(bl.isSingleRecord() ? "Yes" : "No"));		
		props.put("DATABASE_DATA_BLOCK", (bl.isDatabaseBlock() ? "Yes" : "No"));
		props.put("ENFORCE_PRIMARY_KEY",(bl.isEnforcedPrimaryKey() ? "Yes" : "No"));
		props.put("QUERY_ALLOWED", (bl.isQueryAllowed() ? "Yes" : "No"));
	    props.put("QUERY_DATA_SOURCE_TYPE", (String) block_qdst_map.get(bl.getQueryDataSourceType()));
	    props.put("QUERY_DATA_SOURCE_NAME", bl.getQueryDataSourceName());
		props.put("QUERY_DATA_SOURCE_COLUMNS", printQueryDsColumns(bl.getQueryDataSourceColumns()));		
		props.put("QUERY_DATA_SOURCE_ARGUMENTS", printQueryDsArguments(bl.getQueryDataSourceArguments()));
		props.put("ALIAS", bl.getAlias());
	    props.put("INCLUDE_REF_ITEM", (bl.isIncludeRefitem() ? "Yes" : "No"));
		props.put("WHERE_CLAUSE", bl.getWhereClause());
	    props.put("ORDER_BY_CLAUSE", bl.getOrderByClause());
	    props.put("OPTIMIZER_HINT", bl.getOptionHint());
		props.put("INSERT_ALLOWED",(bl.isInsertAllowed() ? "Yes" : "No"));		
		props.put("UPDATE_ALLOWED", (bl.isUpdateAllowed() ? "Yes" : "No"));
		props.put("LOCKING_MODE",(String) block_lcmd_map.get(bl.getLockMode()));
		props.put("DELETE_ALLOWED", (bl.isDeleteAllowed() ? "Yes" : "No"));
		props.put("KEY_MODE", (String) block_kymd_map.get(bl.getKeyMode()));
		props.put("UPDATE_CHANGED_COLUMN_ONLY",(bl.isUpdateChangedColumns() ? "Yes" : "No"));		
		props.put("ENFORCE_COLUMN_SECURITY", (bl.isEnforcedColumnSecurity() ? "Yes" : "No"));
		props.put("MAXIMUM_QUERY_TIME", "" + bl.getMaximumQueryTime());
		props.put("MAXIMUM_RECORDS_FETCHED", "" + bl.getMaximumRecordsFetched());
		props.put("DML_DATA_TARGET_TYPE", (String) block_dmtt_map.get(bl.getDMLDataType()));
		props.put("DML_DATA_TARGET_NAME", bl.getDMLDataName());
		props.put("INSERT_PROCEDURE_NAME", bl.getInsertProcedureName());		
		props.put("INSERT_PROCEDURE_RESULTSET_COLUMNS", printQueryDsColumns(bl.getInsertDataSourceColumns()));
		props.put("INSERT_PROCEDURE_ARGUMENTS", printQueryDsArguments(bl.getInsertDataSourceArguments()));
		props.put("UPDATE_PROCEDURE_NAME", bl.getUpdateProcedureName());
		props.put("UPDATE_PROCEDURE_RESULTSET_COLUMNS", printQueryDsColumns(bl.getUpdateDataSourceColumns()));
		props.put("UPDATE_PROCEDURE_ARGUMENTS", printQueryDsArguments(bl.getUpdateDataSourceArguments()));
		props.put("DELETE_PROCEDURE_NAME", bl.getDeleteProcedureName());		
		props.put("DELETE_PROCEDURE_RESULTSET_COLUMNS", printQueryDsColumns(bl.getDeleteDataSourceColumns()));
		props.put("DELETE_PROCEDURE_ARGUMENTS", printQueryDsArguments(bl.getDeleteDataSourceArguments()));
		props.put("LOCK_PROCEDURE_NAME", bl.getLockProcedureName());
		props.put("LOCK_PROCEDURE_RESULTSET_COLUMNS", printQueryDsColumns(bl.getLockDataSourceColumns()));
		props.put("LOCK_PROCEDURE_ARGUMENTS", printQueryDsArguments(bl.getLockDataSourceArguments()));
		props.put("DML_ARRAY_SIZE", "" + bl.getDMLArraySize());
	    props.put("PRECOMPUTE_SUMMARIES", (bl.isPrecompSummary() ? "Yes" : "No"));
		props.put("DML_RETURNING_VALUE", (bl.isDMLReturnValue() ? "Yes" : "No") );		
		props.put("SHOW_SCROLL_BAR", (bl.isShowScrollbar() ? "Yes" : "No"));
		props.put("SCROLL_BAR_CANVAS", bl.getScrollbarCanvasName());
		props.put("SCROLL_BAR_TAB_PAGE", bl.getScrollbarTabPageName());
		props.put("SCROLL_BAR_ORIENTATION", (String) block_recor_map.get(bl.getScrollbarOrientation()));
		props.put("SCROLL_BAR_X_POSITION", ""+bl.getScrollbarXPosition());
		props.put("SCROLL_BAR_Y_POSITION", ""+bl.getScrollbarYPosition());
		props.put("SCROLL_BAR_WIDTH", ""+bl.getScrollbarWidth());
	    props.put("SCROLL_BAR_LENGTH", ""+bl.getScrollbarLength());
		props.put("REVERSE_DIRECTION", (bl.isReverseDirection() ? "Yes" : "No"));
		props.put("VISUAL_ATTRIBUTE_GROUP", bl.getVisualAttributeName());
		props.put("FOREGROUND_COLOR", bl.getForegroundColor());
		props.put("BACKGROUND_COLOR", bl.getBackColor());
		props.put("FILL_PATTERN", bl.getFillPattern());
		props.put("DIRECTION", (String) prompt_reor_map.get(bl.getLanguageDirection()));
	   
	}		
	return props; 
 }
   
  public static String printRecordGroupColumns(JdapiIterator it,String indent) {	
	 String columns = "";
	 while (it.hasNext())
	 {		
		RecordGroupColumn rgc = (RecordGroupColumn) it.next();		
		columns += "NAME : "+ rgc.getName() + "\n";
		columns += "DATA_TYPE : "+ (String) rg_cdt_map.get(rgc.getColumnDataType()) + "\n";
		columns += "LENGTH : "+ rgc.getMaximumLength() + "\n";
		columns += "SEMANTICS : "+ rgc.getDataLengthSemantics() + "\n";
		columns += "COLUMN_VALUES : "+ rgc.getColumnValuesCount() + "\n";
		columns += "\n";
	 }
	 return columns;
 }
 public static String printQueryDsColumns(JdapiIterator it) {
	 String res = "";
	 while (it.hasNext())
	 {
		DataSourceColumn dsc = (DataSourceColumn)it.next();
		String dsc_name =  dsc.getDSCName();
		if(dsc_name == null || dsc_name.isEmpty() || dsc_name.length() == 0) {
			dsc_name = "NULL";
		}
		res += "NAME : " + dsc_name +"\n";
		res += "TYPE : " + dsc.getDSCType() +"\n";
		res += "LENGTH : " + dsc.getDSCLength() +"\n";
		res += "PRECISION : " + dsc.getDSCPrecision() +"\n";
		res += "SCALE : " + dsc.getDSCScale() +"\n";
		res += "MANDATORY : " + (dsc.isDSCMandatory() ? "Yes" : "No") +"\n";				
	 }
	 return res;
 }
 public static String printQueryDsArguments(JdapiIterator it) {
	String res  = "";
	while (it.hasNext())
	{
		DataSourceArgument dsa = (DataSourceArgument)it.next();
		String arg_name =  dsa.getDSAName();
		if(arg_name == null || arg_name.isEmpty() || arg_name.length() == 0) {
			arg_name = "NULL";
		}		
		res += "NAME : " + arg_name +"\n";
		res += "TYPE : " + (String) block_dstyp_map.get(dsa.getDSAType()) +"\n";
		res += "TYPE_NAME : " + dsa.getDSATypeName() +"\n";
		res += "MODE : " + (String) block_dsmod_map.get(dsa.getDSAMode()) +"\n";
		res += "VALUE : " + dsa.getDSAValue() +"\n";		
	}
	return res;
 }
 
 public static String printComments(String text, String indent){
	return printClause("Comments", text, indent);
 }
 
 public static String printClause(String name, String text, String indent){
	String res  ="";
	if(text != null && !"null".equals(text) && text.length()>0) {		  							
		text = text.trim();           
	} 
	res += text;
	return res;
 }


 public static List<Map<String,String>> printRelations(JdapiIterator it,String indent) {
	List<Map<String,String>>  list = new ArrayList<Map<String,String>>();  
	while (it.hasNext())
	{
		Relation rl = (Relation)it.next();		
		Map<String,String> props = new HashMap<String,String>();
	    if(isWithProperties()) {			
			props.put("NAME", rl.getName());
			props.put("RELATION_TYPE", (String) rel_typ_map.get(rl.getRelationType()));
		    props.put("SUBCLASS_INFORMATION", rl.getDetailItemref());
			props.put("COMMENTS", printComments(rl.getComment(),indent + "            "));
		    props.put("DETAIL_DATA_BLOCK", rl.getDetailBlock());
			props.put("DELETE_RECORD_BEHAVIOUR", (String) rel_del_map.get(rl.getDeleteRecord()));
		    props.put("PREVENT_MASTERLESS_OPERATIONS", (rl.isPreventMasterlessOperations() ? "Yes" : "No"));
			props.put("DEFERRED", (rl.isDeferred() ? "Yes" : "No"));
		    props.put("AUTOMATIC_QUERY", (rl.isAutoQuery() ? "Yes" : "No"));
			list.add(props);
		}
	}
	return list;
  }
  
  public static String printRelationNames(JdapiIterator it) {
    String res = "";
    while (it.hasNext())
	{
		Relation rl = (Relation)it.next();
		res += rl.getName() + "\n";
	}
	return res;
  }
  
 public static List<Map<String,String>> printItems(JdapiIterator it, String indent) {
	List<Map<String,String>>  list = new ArrayList<Map<String,String>>();  
	while (it.hasNext())
	{
		Item item = (Item)it.next();
		list.add(printItem(item, indent));
    }
	return list;
 }
 
  public static String printItemNames(JdapiIterator it) {
	String res="";
	while (it.hasNext())
	{
		Item item = (Item)it.next();
		res += item.getName() + "\n";		
    }
	return res;
 }
 
 public static Map<String,String> printItem(Item item, String indent) {	
	Map<String,String> props = new HashMap<String,String>();
	
	int item_type = item.getItemType();	
	props.put("NAME", item.getName());
	props.put("ITEM_TYPE", (String) item_type_map.get(item.getItemType()));
	props.put("SUBCLASS_INFORMATION", item.getParentName());
	props.put("COMMENTS", printComments(item.getComment(),indent + "            "));
	props.put("TRIGGERS", printTriggerNames(item.getTriggers()));
	props.put("HELP_BOOK_TOPIC", item.getHelpBookTopic());
	props.put("ENABLED", "");
	props.put("LABEL", "");
	props.put("IMAGE_FORMAT", "");
	props.put("IMAGE_DEPTH", "");
	props.put("DISPLAY_QUALITY", "");
	props.put("SIZING_STYLE", "");
	props.put("ELEMENTS_IN_LIST", "");
	props.put("LIST_TYPE", "");
    props.put("ACCESS_KEY", "");
	props.put("JUSTIFICATION", "");
	props.put("MAPPING_OF_OTHER_VALUES", "");
	props.put("IMPLEMENTATION_CLASS", "");
	props.put("ICONIC", "");
	props.put("ICON_FILENAME", "");
	props.put("DEFAULT_BUTTON", "");
	props.put("MULTI_LINE", "");
	props.put("WRAP_STYLE", "");
	props.put("CASE_RESTRICTION", "");
	props.put("CONCEAL_DATA", "");
	props.put("KEEP_CURSOR_POSITION", "");
	props.put("AUTOMATIC_SKIP", "");
	props.put("VALUE_WHEN_CHECKED", "");
	props.put("VALUE_WHEN_UNCHECKED", "");
	props.put("CHECK_BOX_MAPPING_OF_OTHER_VALUES","");
	props.put("KEYBOARD_NAVIGABLE", "");
	props.put("MOUSE_NAVIGATE","");
	props.put("DATA_TYPE", "");
    props.put("DATA_LENGTH_SEMANTICS", "");
    props.put("MAXIMUM_LENGTH", "");
    props.put("INITIAL_VALUE", "");	
    props.put("REQUIRED","");	
	props.put("FORMAT_MASK","");
	props.put("LOWEST_ALLOWED_VALUE", "");
	props.put("HIGHEST_ALLOWED_VALUE",""); 
	props.put("COPY_VALUE_FROM_ITEM", "");
	props.put("SYNCHRONIZE_WITH_ITEM", "");
	props.put("CALCULATION_MODE", "");
	props.put("FORMULA", "");
	props.put("SUMMARY_FUNCTION","");
	props.put("SUMMARIZED_BLOCK", "");
	props.put("SUMMARIZED_ITEM", "");
	props.put("DISTANCE_BETWEEN_RECORDS","");
	props.put("DATABASE_ITEM", "");
    props.put("COLUMN_NAME", "");
	props.put("PRIMARY_KEY", "");
	props.put("QUERY_ONLY", "");
	props.put("QUERY_ALLOWED", "");
	props.put("CASE_INSENSITIVE_QUERY", "");
	props.put("INSERT_ALLOWED", "");
	props.put("UPDATE_ALLOWED", "");
    props.put("UPDATE_ONLY_IF_NULL", "");
	props.put("LOCK_RECORD", "");
	props.put("LIST_OF_VALUES","");
	props.put("LIST_X_POSITION","");
	props.put("LIST_Y_POSITION","");
	props.put("VALIDATE_FROM_LIST","");
	props.put("EDITOR","");
	props.put("EDITOR_X_POSITION","");
	props.put("EDITOR_Y_POSITION","");
	props.put("VISIBLE","");
	props.put("X_POSITION", "");
	props.put("Y_POSITION", "");
	props.put("WIDTH","");
	props.put("HEIGHT","");
	props.put("BEVEL","");
	props.put("RENDERED", "");
	props.put("SHOW_HORIZONTAL_SCROLL_BAR", "");
	props.put("SHOW_VERTICAL_SCROLL_BAR", "");
	props.put("PROMPT_VISUAL_ATTRIBUTE_GROUP","");
	props.put("FOREGROUND_COLOR", "");
	props.put("HINT", "");
    props.put("DISPLAY_HINT_AUTOMATICALLY", ""); 
	props.put("INITIAL_KEYBOARD_STATE", "");
	props.put("READING_ORDER", "");
	props.put("KEYBOARD_STATE","");
	props.put("DIRECTION","");
	if(isWithProperties()) {		
		if((item_type == 1) ||
		   (item_type == 4) ||
		   (item_type == 5) ||
		   (item_type == 6) || 
		   (item_type == 8)) { 
			props.put("ENABLED", (item.isEnabled() ? "Yes" : "No"));
		}
		if((item_type == 1) ||
		   (item_type == 6)){ 
			props.put("LABEL", item.getLabel());
		}
		if(item_type == 4){			
            props.put("IMAGE_FORMAT", (String) img_format_map.get(item.getImageFormat()));
			props.put("IMAGE_DEPTH", (String) img_depth_map.get(item.getImageDepth()));
			props.put("DISPLAY_QUALITY", (String) img_dispq_map.get(item.getDisplayQuality()));
			props.put("SIZING_STYLE", (String) img_sizing_map.get(item.getSizingStyle()));			
		}
		if(item_type == 5){			
			int elm_count = item.getListElementCount();			
			String elements = "";
			if(elm_count > 0) {
				for(int ndx = 0; ndx < elm_count; ndx++) {					
					elements += "ELEMENT_NO : " + ndx + "\n";
					elements += "ELEMENT_LABEL : " + item.getElementLabel(ndx+1) + "\n";
					elements += "ELEMENT_VALUE : " + item.getElementValue(ndx+1) + "\n";
					elements += "\n";
				}
			}
			props.put("ELEMENTS_IN_LIST", elements);
			props.put("LIST_TYPE", (String) list_type_map.get(item.getListStyle()));			
		}
		if((item_type == 1) ||
		   (item_type == 6) || 
		   (item_type == 7)){			
			props.put("ACCESS_KEY", item.getAccessKey());
		}
		if((item_type == 2) ||
		   (item_type == 8)) {
			props.put("JUSTIFICATION", (String) just_type_map.get(item.getJustification()));
		}
		if((item_type == 5) || //LIST_ITEM
		   (item_type == 7)) { //RADIO_GROUP		
			props.put("MAPPING_OF_OTHER_VALUES", item.getOtherValues());
		}
		if((item_type == 1) ||
		   (item_type == 5) ||
		   (item_type == 6) ||
		   (item_type == 7) ||
		   (item_type == 8)) { 
			props.put("IMPLEMENTATION_CLASS", item.getImplementationClass());
		}
		if(item_type == 6){ 
			props.put("ICONIC", (item.isIconic() ? "Yes" : "No") );
	        props.put("ICON_FILENAME", item.getIconFilename());
	        props.put("DEFAULT_BUTTON", (item.isDefaultButton() ? "Yes" : "No"));
		}
		if(item_type == 8) { 
			props.put("MULTI_LINE", (item.isMultiLine() ? "Yes" : "No"));
			props.put("WRAP_STYLE", (String) func_wrap_map.get(item.getWrapStyle()));
			props.put("CASE_RESTRICTION", (String) func_case_map.get(item.getCaseRestriction()));
			props.put("CONCEAL_DATA", (item.isConcealData() ? "Yes" : "No"));
			props.put("KEEP_CURSOR_POSITION", (item.isKeepCursorPosition() ? "Yes" : "No"));
			props.put("AUTOMATIC_SKIP", (item.isAutoSkip() ? "Yes" : "No"));
		}
		if(item_type == 1) {			
            props.put("VALUE_WHEN_CHECKED", item.getCheckedValue());
			props.put("VALUE_WHEN_UNCHECKED", item.getUncheckedValue());
			props.put("CHECK_BOX_MAPPING_OF_OTHER_VALUES",""+item.getCheckBoxOtherValues());			
		}
		if(item_type == 5) {			
			 props.put("CASE_RESTRICTION", (String) func_case_map.get(item.getCaseRestriction()));
		}		
		props.put("POPUP_MENU", item.getPopupMenuName());		
		if((item_type == 1) ||
		   (item_type == 4) ||
		   (item_type == 5) ||
		   (item_type == 6) ||
		   (item_type == 7) ||
		   (item_type == 8)) { 
			props.put("KEYBOARD_NAVIGABLE", (item.isKeyboardNavigable() ? "Yes" : "No"));
		}		
		if((item_type == 1) ||
		   (item_type == 5) ||
		   (item_type == 6) ||
		   (item_type == 7) 
		   ) {			
			props.put("MOUSE_NAVIGATE", (item.isMouseNavigate() ? "Yes" : "No"));
		}		
		props.put("PREVIOUS_NAVIGATION_ITEM", item.getPreviousNavigationItemName());
		props.put("NEXT_NAVIGATION_ITEM", item.getPreviousNavigationItemName());
		if((item_type == 1) ||
		   (item_type == 2) ||
		   (item_type == 5) ||
		   (item_type == 7) ||
		   (item_type == 8)) {			
			props.put("DATA_TYPE", (String) data_type_map.get(item.getDataType()));
		    props.put("DATA_LENGTH_SEMANTICS", (String) data_lensem_map.get(item.getDataLengthSemantics()));
			props.put("MAXIMUM_LENGTH", ""+item.getMaximumLength());
		    props.put("INITIAL_VALUE", item.getInitializeValue());
			if ((item_type == 2) || 
			   (item_type == 5)  ||
			   (item_type == 8)) {				
				 props.put("REQUIRED", (item.isRequired() ? "Yes" : "No"));
			}
			if ((item_type == 2) || 
				(item_type == 8)) {								
				 props.put("FORMAT_MASK", item.getFormatMask());
			}			
			if(item_type == 8) { 
				props.put("LOWEST_ALLOWED_VALUE", item.getLowestAllowedValue());
				props.put("HIGHEST_ALLOWED_VALUE", item.getHighestAllowedValue());
				
			}			
			props.put("COPY_VALUE_FROM_ITEM", item.getCopyValueFromItem());
			props.put("SYNCHRONIZE_WITH_ITEM", item.getSynchronizedItemName());
			props.put("CALCULATION_MODE", (String) calc_mod_map.get(item.getCalculateMode()));
			props.put("FORMULA", item.getFormula());
			props.put("SUMMARY_FUNCTION", (String) calc_sum_map.get(item.getSummaryFunction()));
			props.put("SUMMARIZED_BLOCK", item.getSummaryBlockName());
			props.put("SUMMARIZED_ITEM", item.getSummaryItemName());
		}
		if(item_type == 4){		
			props.put("REQUIRED", (item.isRequired() ? "Yes" : "No"));
			props.put("SYNCHRONIZE_WITH_ITEM", item.getSynchronizedItemName());
		}		
		props.put("CURRENT_RECORD_VISUAL_ATTRIBUTE_GROUP", item.getRecordVisualAttributeGroupName());
		if((item_type == 1) ||
		   (item_type == 2) ||
		   (item_type == 4) ||
		   (item_type == 5) ||
		   (item_type == 6) ||
		   (item_type == 8)) {			
			props.put("DISTANCE_BETWEEN_RECORDS", ""+item.getDistanceBetweenRecords());
		}	
		props.put("NUMBER_OF_ITEMS_DISPLAYED", ""+item.getItemsDisplay());
		if((item_type == 1) ||
		   (item_type == 2) ||
		   (item_type == 4) ||
		   (item_type == 7) ||
		   (item_type == 8)) {		
			props.put("DATABASE_ITEM", (item.isDatabaseItem() ? "Yes" : "No"));
			props.put("COLUMN_NAME", item.getColumnName());
			if((item_type == 1) ||
			   (item_type == 2) ||
			   (item_type == 5) ||
			   (item_type == 7) ||
			   (item_type == 8)) {				
				props.put("PRIMARY_KEY", (item.isPrimaryKey() ? "Yes" : "No"));
			}						
			props.put("QUERY_ONLY", (item.isQueryOnly() ? "Yes" : "No"));
			if((item_type == 1) ||
			   (item_type == 5) ||
			   (item_type == 7) ||
			   (item_type == 8)) { 
				props.put("QUERY_ALLOWED", (item.isQueryAllowed() ? "Yes" : "No"));
			}
			if(item_type == 8) { 
				props.put("CASE_INSENSITIVE_QUERY", (item.isCaseInsensitiveQuery() ? "Yes" : "No"));
			}
			if((item_type == 1) ||
			   (item_type == 4) ||
			   (item_type == 5) ||
			   (item_type == 7) ||
			   (item_type == 8)) { 
				props.put("INSERT_ALLOWED", (item.isInsertAllowed() ? "Yes" : "No"));
				props.put("UPDATE_ALLOWED", (item.isUpdateAllowed() ? "Yes" : "No"));
			}
			if((item_type == 4) ||
			   (item_type == 5) || 
			   (item_type == 8)) { 
				props.put("UPDATE_ONLY_IF_NULL", (item.isUpdateIfNull() ? "Yes" : "No")); 				
			}
			if((item_type == 4) ||
			   (item_type == 8)) { 
				props.put("LOCK_RECORD", (item.isLockRecord() ? "Yes" : "No"));
			}
			if(item_type == 8) { 
				props.put("LIST_OF_VALUES",item.getLovName());
				props.put("LIST_X_POSITION",""+item.getLovXPosition());
				props.put("LIST_Y_POSITION",""+item.getLovYPosition());
				props.put("VALIDATE_FROM_LIST",(item.isValidateFromList() ? "Yes" : "No"));
				props.put("EDITOR",item.getEditName());
				props.put("EDITOR_X_POSITION",""+item.getEditXPosition());
				props.put("EDITOR_Y_POSITION",""+item.getEditYPosition());
			}
		}
		
		if((item_type == 1) ||
		   (item_type == 2) ||
		   (item_type == 4) ||
		   (item_type == 5) ||
		   (item_type == 6) ||
		   (item_type == 8)) {			 		   			
			props.put("VISIBLE", (item.isVisible() ? "Yes" : "No"));			
		}		
		props.put("CANVAS",item.getCanvasName());
		props.put("TAB_PAGE",item.getTabPageName());
		if((item_type == 1) ||
		   (item_type == 2) ||
		   (item_type == 4) ||
		   (item_type == 5) ||
		   (item_type == 6) ||
		   (item_type == 8)) {			
			props.put("X_POSITION", ""+item.getXPosition());
			props.put("Y_POSITION", ""+item.getYPosition());
			props.put("WIDTH", ""+item.getWidth());
			props.put("HEIGHT", ""+item.getHeight());
		}
		if((item_type == 2) ||
		   (item_type == 4) ||
		   (item_type == 6) || 
		   (item_type == 8)) {			
			props.put("BEVEL", (String) phys_bevel_map.get(item.getBevel()));
			
		}
		if((item_type == 2) ||
		   (item_type == 6) || 
		   (item_type == 8)) {			
            props.put("RENDERED", (item.isRendered() ? "Yes" : "No")); 			
		}
		if(item_type == 4) {			
			props.put("SHOW_HORIZONTAL_SCROLL_BAR", (item.isShowHorizontalScrollbar() ? "Yes" : "No"));
		}
		if(item_type == 8) { 
			props.put("SHOW_VERTICAL_SCROLL_BAR", (item.isShowVerticalScrollbar() ? "Yes" : "No"));
		}				
		props.put("VISUAL_ATTRIBUTE_GROUP", item.getVisualAttributeName());
		if((item_type == 1) ||
		   (item_type == 2) ||
		   (item_type == 4) ||
		   (item_type == 5) ||
		   (item_type == 6) ||
		   (item_type == 8)) {			
			props.put("PROMPT_VISUAL_ATTRIBUTE_GROUP", item.getPromptVisualAttributeName());
		}		
		if((item_type == 1) ||
		   (item_type == 2) ||	
		   (item_type == 5) ||		   
		   (item_type == 6) ||
		   (item_type == 7) ||
		   (item_type == 8)) {			
			props.put("FOREGROUND_COLOR", item.getForegroundColor());
		}		
	    props.put("BACKGROUND_COLOR", item.getBackColor());
		props.put("FILL_PATTERN", item.getFillPattern());
		props.put("FONT_NAME", item.getFontName());
		props.put("FONT_SIZE", ""+item.getFontSize());
		props.put("FONT_WEIGHT", (String) font_weight_map.get(item.getFontWeight()));
		props.put("FONT_STYLE", (String) font_style_map.get(item.getFontStyle()));
		props.put("FONT_SPACING", (String) (String) font_space_map.get(item.getFontSpacing()));		
		props.put("PROMPT",  item.getPrompt());
		props.put("PROMPT_DISPLAY_STYLE",  (String) prompt_disp_map.get(item.getPromptDisplayStyle()));
		props.put("PROMPT_JUSTIFICATION",  (String) prompt_just_map.get(item.getPromptJustification()));
		props.put("PROMPT_ATTACHMENT_EDGE",   (String) prompt_ated_map.get(item.getPromptAttachmentEdge()));
		props.put("PROMPT_ALIGNMENT",  (String) prompt_algn_map.get(item.getPromptAlign()));
		props.put("PROMPT_ATTACHMENT_OFFSET",  ""+item.getPromptAttachmentOffset());
		props.put("PROMPT_ALIGNMENT_OFFSET",  ""+item.getPromptAlignOffset());
		props.put("PROMPT_READING_ORDER",  (String) prompt_reor_map.get(item.getPromptReadingOrder()));
		props.put("PROMPT_FOREGROUND_COLOR", item.getPromptForegroundColor());		
		props.put("PROMPT_FONT_NAME", item.getPromptFontName());
		props.put("PROMPT_FONT_SIZE", ""+item.getPromptFontSize());
		props.put("PROMPT_FONT_WEIGHT", (String) font_weight_map.get(item.getPromptFontWeight()));
		props.put("PROMPT_FONT_STYLE", (String) font_style_map.get(item.getPromptFontStyle()));
		props.put("PROMPT_FONT_SPACING",(String) font_space_map.get(item.getPromptFontSpacing()));		
		if((item_type == 1) ||
		   (item_type == 4) ||
		   (item_type == 5) ||
		   (item_type == 6) || 
		   (item_type == 7) || 
		   (item_type == 8)) { 
			props.put("HINT", item.getHint());
			props.put("DISPLAY_HINT_AUTOMATICALLY", (item.isAutoHint() ? "Yes" : "No"));
		}			
		props.put("TOOLTIP", item.getTooltip());
	    props.put("TOOLTIP_VISUAL_ATTRIBUTE_GROUP", item.getTooltipVisualAttributeGroup());
		if((item_type == 1) ||
		   (item_type == 2) ||		
		   (item_type == 5) ||
		   (item_type == 6) ||
		   (item_type == 7) ||
		   (item_type == 8)) {			
			if((item_type == 2) || 
			   (item_type == 5) ||
			   (item_type == 8)) {				
				props.put("INITIAL_KEYBOARD_STATE", ""+item.getInitializeKeyboardDirection());
	            props.put("READING_ORDER", ""+item.getReadingOrder());
				props.put("KEYBOARD_STATE", ""+item.getKeyboardState());
			}
			if((item_type == 1) ||
			  (item_type == 6) ||
			  (item_type == 7) 
			  ) {				
				props.put("DIRECTION", (String) prompt_reor_map.get(item.getLanguageDirection()));	
			}
		}
	}			
	return props;	
}
 
 public static List<Map<String,String>> printCanvases(JdapiIterator it, String indent) {
	List<Map<String,String>>  list = new ArrayList<Map<String,String>>();  
	while (it.hasNext())
	{
		Canvas cnv = (Canvas)it.next();
		Map<String,String> props = new HashMap<String,String>();		
		if(isWithProperties()) {			
			props.put("NAME", cnv.getName());
			props.put("CANVAS_TYPE", (String) cnv_type_map.get(cnv.getCanvasType()));
		    props.put("SUBCLASS_INFORMATION", cnv.getParentName());
			props.put("COMMENTS", printComments(cnv.getComment(),indent + "            "));
			props.put("HELP_BOOK_TOPIC", cnv.getHelpBookTopic());
			props.put("RAISE_ON_ENTRY", (cnv.isRaiseOnEnter() ? "Yes" : "No"));
			props.put("VISIBLE", (cnv.isVisible() ? "Yes" : "No"));
			props.put("WINDOW", cnv.getWindowName());
			props.put("VIEWPORT_X_POSITION_ON_CANVAS", ""+cnv.getViewportXPosition());
			props.put("VIEWPORT_Y_POSITION_ON_CANVAS", ""+cnv.getViewportYPosition());
			props.put("WIDTH", ""+cnv.getWidth());
			props.put("HEIGHT", ""+cnv.getHeight());
			props.put("BEVEL", (String) phys_bevel_map.get(cnv.getBevel()));
			props.put("VISUAL_ATTRIBUTE_GROUP", cnv.getVisualAttributeName());
			props.put("FOREGROUND_COLOR", cnv.getForegroundColor());
			props.put("BACKGROUND_COLOR", cnv.getBackColor());
			props.put("FILL_PATTERN", cnv.getFillPattern());
			props.put("DIRECTION", (String) prompt_reor_map.get(cnv.getLanguageDirection()));
					
		}
		list.add(props);	
	}
	return list;
  }
  public static List<Map<String,String>> printWindows(JdapiIterator it, String indent) {
	List<Map<String,String>>  list = new ArrayList<Map<String,String>>();   
	while (it.hasNext())
	{
		Window win = (Window)it.next();		
		Map<String,String> props = new HashMap<String,String>();
		if(isWithProperties()) {			
			props.put("NAME", win.getName());		
		    props.put("SUBCLASS_INFORMATION", win.getParentName());
			props.put("COMMENTS", printComments(win.getComment(),indent + "            "));
			props.put("HELP_BOOK_TOPIC", win.getHelpBookTopic());
			props.put("TITLE", win.getTitle());	
			props.put("PRIMARY_CANVAS", win.getPrimaryCanvas());
			props.put("HORIZONTAL_TOOLBAR_CANVAS", win.getHorizontalToolbarCanvasName());
			props.put("VERTICAL_TOOLBAR_CANVAS", win.getVerticalToolbarCanvasName());
		    props.put("WINDOW_STYLE", (String) win_style_map.get(win.getWindowStyle()));
			props.put("MODAL", (win.isModal() ? "Yes" : "No"));
			props.put("HIDE_ON_EXIT", (win.isHideOnExit() ? "Yes" : "No"));
			props.put("CLOSE_ALLOWED", (win.isClearAllowed() ? "Yes" : "No"));
			props.put("MOVE_ALLOWED", (win.isMoveAllowed() ? "Yes" : "No"));
			props.put("RESIZE_ALLOWED", (win.isResizeAllowed() ? "Yes" : "No"));
			props.put("MAXIMIZE_ALLOWED", (win.isMaximizeAllowed() ? "Yes" : "No"));
			props.put("MINIMIZE_ALLOWED", (win.isMinimizeAllowed() ? "Yes" : "No"));
			props.put("MINIMIZED_TITLE", win.getMinimizeTitle());	
			props.put("ICON_FILENAME", win.getIconFilename());	
			props.put("INHERIT_MENU", (win.isInheritMenu() ? "Yes" : "No"));
			props.put("X_POSITION", ""+win.getXPosition());
			props.put("Y_POSITION", ""+win.getYPosition());
			props.put("WIDTH", ""+win.getWidth());
			props.put("HEIGHT", ""+win.getHeight());
			props.put("BEVEL", (String) phys_bevel_map.get(win.getBevel()));
			props.put("SHOW_HORIZONTAL_SCROLL_BAR", (win.isShowHorizontalScrollbar() ? "Yes" : "No"));
		    props.put("SHOW_VERTICAL_SCROLL_BAR", (win.isShowVerticalScrollbar() ? "Yes" : "No"));
			props.put("VISUAL_ATTRIBUTE_GROUP", win.getVisualAttributeName());
			props.put("FOREGROUND_COLOR", win.getForegroundColor());
			props.put("BACKGROUND_COLOR", win.getBackColor());
			props.put("FILL_PATTERN", win.getFillPattern());
		    props.put("FONT_NAME", win.getFontName());
			props.put("FONT_SIZE", ""+win.getFontSize());
			props.put("FONT_WEIGHT", (String) font_weight_map.get(win.getFontWeight()));
			props.put("FONT_STYLE", (String) font_style_map.get(win.getFontStyle()));
			props.put("FONT_SPACING", (String) (String) font_space_map.get(win.getFontSpacing()));
			props.put("DIRECTION", (String) prompt_reor_map.get(win.getLanguageDirection()));			
		}		
		list.add(props);
	}
	return list;
  }
  public static List<Map<String,String>> printParameters(JdapiIterator it, String indent) {
	List<Map<String,String>>  list = new ArrayList<Map<String,String>>();   
	while (it.hasNext())
	{
		ModuleParameter prm = (ModuleParameter)it.next();		
		Map<String,String> props = new HashMap<String,String>();
		if(isWithProperties()) {		
			props.put("NAME", prm.getName());		
		    props.put("SUBCLASS_INFORMATION", prm.getParentName());
			props.put("COMMENTS", printComments(prm.getComment(),indent + "            "));
			props.put("PARAMETER_DATA_TYPE", (String) prm_type_map.get(prm.getParameterDataType()));
			props.put("PARAMETER_INITIAL_VALUE", prm.getParameterInitializeValue());
		}
		list.add(props);		
	}
	return list;
  }
  
  public static List<Map<String,String>> printLovs(JdapiIterator it, String indent) {
	List<Map<String,String>> list = new  ArrayList<Map<String,String>>();   
	while (it.hasNext())
	{ 
         LOV lv  = (LOV)it.next();		
		 list.add(printLOV(lv, indent));
	}	
    return list;	
  }
 public static Map<String,String> printLOV(LOV lv, String indent) {	
	 Map<String,String> props = new HashMap<String,String>();
	 props.put("NAME", lv.getName());		
	 props.put("SUBCLASS_INFORMATION", lv.getParentName());
 	 props.put("COMMENTS", printComments(lv.getComment(),indent + "            "));		
	 props.put("TITLE", lv.getTitle());					
	 props.put("LIST_TYPE", (String) lst_type_map.get(lv.getListType()));
	 props.put("RECORD_GROUP", lv.getRecordGroupName());
	 props.put("COLUMN_MAPPING_PROPERTIES", printLovColMaps(lv.getLOVColumnMappings(), indent + "                "));
	 props.put("FILTER_BEFORE_DISPLAY", (lv.isFilterBeforeDisplay() ? "Yes" : "No"));
	 props.put("AUTOMATIC_DISPLAY", (lv.isAutoDisplay() ? "Yes" : "No"));
     props.put("AUTOMATIC_REFRESH", (lv.isAutoRefresh() ? "Yes" : "No"));	
     props.put("AUTOMATIC_SELECT", (lv.isAutoSelect() ? "Yes" : "No"));	
     props.put("AUTOMATIC_SKIP", (lv.isAutoSkip() ? "Yes" : "No"));	
     props.put("AUTOMATIC_POSITION", (lv.isAutoPosition() ? "Yes" : "No"));	
     props.put("AUTOMATIC_COLUMN_WIDTH", (lv.isAutoColumnWidth() ? "Yes" : "No"));	     
	 props.put("X_POSITON", ""+lv.getXPosition());
	 props.put("Y_POSITON", ""+lv.getYPosition());
	 props.put("WIDTH", ""+lv.getWidth());
	 props.put("HEIGHT", ""+lv.getHeight());
	 props.put("VISUAL_ATTRIBUTE_GROUP", lv.getVisualAttributeName());
	 props.put("FOREGROUND_COLOR", lv.getForegroundColor());
	 props.put("BACKGROUND_COLOR", lv.getBackColor());
	 props.put("FILL_PATTERN", lv.getFillPattern());
	 props.put("FONT_NAME", lv.getFontName());
	 props.put("FONT_SIZE", ""+lv.getFontSize());
	 props.put("FONT_WEIGHT", (String) font_weight_map.get(lv.getFontWeight()));
	 props.put("FONT_STYLE", (String) font_style_map.get(lv.getFontStyle()));
	 props.put("FONT_SPACING", (String) (String) font_space_map.get(lv.getFontSpacing()));
	 props.put("DIRECTION", (String) prompt_reor_map.get(lv.getLanguageDirection()));	
	 return props;
  }
  
   
  
  public static String printLovColMaps(JdapiIterator it, String indent) {
	String res = "";  
	while (it.hasNext())
	{
		LOVColumnMapping lcm  = (LOVColumnMapping)it.next();		
		res += "NAME : " + lcm.getName() + "\n";
        res += "RETURN_ITEM : " + lcm.getReturnItem() + "\n";
        res += "DISPLAY_WITH : " + lcm.getDisplayWidth() +"\n";
        res += "COLUMN_TITLE : " + lcm.getTitle() + "\n"; 
        res += "\n"; 			
	}
	return res;	
  }
  

  public static List<Map<String,String>> printRecordGroups(JdapiIterator it, String indent) {
	List<Map<String,String>> list = new  ArrayList<Map<String,String>>();  
	while (it.hasNext())
	{ 
        RecordGroup rg  = (RecordGroup)it.next();
		list.add(printRecordGroup(rg, indent));
	}
	return list;
  }
 public static Map<String,String>  printRecordGroup(RecordGroup rg, String indent) {		
	Map<String,String> props = new HashMap<String,String>();	
	props.put("QUERY", printClause("Query", rg.getRecordGroupQuery(), indent + "    "));
	if(isWithProperties()) {		
		props.put("NAME", rg.getName());
		props.put("SUBCLASS_INFORMATION", rg.getParentName());
		props.put("COMMENTS", printComments(rg.getComment(),indent + "            "));		
		props.put("RECORD_GROUP_TYPE", (String) rg_type_map.get(rg.getRecordGroupType()));
		props.put("COLUMN_SPECIFICATIONS", printRecordGroupColumns(rg.getRecordGroupColumns(),indent + "                "));				
	}
	return props;
 }
 public static List<Map<String,String>> printAlerts(JdapiIterator it, String indent) {
	List<Map<String,String>>  list = new ArrayList<Map<String,String>>();  
	while (it.hasNext())
	{
		Alert alert = (Alert)it.next();		
		Map<String,String> props = new HashMap<String,String>();
		if(isWithProperties()) {			
			props.put("NAME", alert.getName());		
		    props.put("SUBCLASS_INFORMATION", alert.getParentName());
			props.put("COMMENTS", printComments(alert.getComment(),indent + "            "));		
			props.put("TITLE", alert.getTitle());				
			props.put("MESSAGE", alert.getAlertMessage());
		    props.put("ALERT_STYLE", (String) (String) alert_style_map.get(alert.getAlertStyle()));
			props.put("BUTTON_1_LABEL", alert.getButton1Label());
			props.put("BUTTON_2_LABEL", alert.getButton2Label());
			props.put("BUTTON_3_LABEL", alert.getButton3Label());
			props.put("DEFAULT_ALERT_BUTTON", (String) alert_btn_map.get(alert.getDefaultAlertButton()));			
			props.put("VISUAL_ATTRIBUTE_GROUP", alert.getVisualAttributeName());
			props.put("FOREGROUND_COLOR", alert.getForegroundColor());
			props.put("BACKGROUND_COLOR", alert.getBackColor());
			props.put("FILL_PATTERN", alert.getFillPattern());
		    props.put("FONT_NAME", alert.getFontName());
			props.put("FONT_SIZE", ""+alert.getFontSize());
			props.put("FONT_WEIGHT", (String) font_weight_map.get(alert.getFontWeight()));
			props.put("FONT_STYLE", (String) font_style_map.get(alert.getFontStyle()));
			props.put("FONT_SPACING", (String) (String) font_space_map.get(alert.getFontSpacing()));
			props.put("DIRECTION", (String) prompt_reor_map.get(alert.getLanguageDirection()));	
		}
		list.add(props);  		
	}
	return list;
  }
 public static List<Map<String,String>> printEditors(JdapiIterator it, String indent) {
	List<Map<String,String>>  list = new ArrayList<Map<String,String>>();   
	while (it.hasNext())
	{
		Editor edit = (Editor)it.next();		
		Map<String,String> props = new HashMap<String,String>();
		if(isWithProperties()) {			
			props.put("NAME", edit.getName());		
		    props.put("SUBCLASS_INFORMATION", edit.getParentName());
			props.put("COMMENTS", printComments(edit.getComment(),indent + "            "));		
			props.put("TITLE", edit.getTitle());				
			props.put("BOTTOM_TITLE", edit.getBottomTitle());
		    props.put("WRAP_STYLE", (String) func_wrap_map.get(edit.getWrapStyle()));
			props.put("X_POSITION", ""+edit.getXPosition());
			props.put("Y_POSITION", ""+edit.getYPosition());
			props.put("WIDTH", ""+edit.getWidth());
			props.put("HEIGHT", ""+edit.getHeight());			
			props.put("SHOW_HORIZONTAL_SCROLL_BAR", (edit.isShowHorizontalScrollbar() ? "Yes" : "No"));
			props.put("VISUAL_ATTRIBUTE_GROUP", edit.getVisualAttributeName());
			props.put("FOREGROUND_COLOR", edit.getForegroundColor());
			props.put("BACKGROUND_COLOR", edit.getBackColor());
			props.put("FILL_PATTERN", edit.getFillPattern());
		    props.put("FONT_NAME", edit.getFontName());
			props.put("FONT_SIZE", ""+edit.getFontSize());
			props.put("FONT_WEIGHT", (String) font_weight_map.get(edit.getFontWeight()));
			props.put("FONT_STYLE", (String) font_style_map.get(edit.getFontStyle()));
			props.put("FONT_SPACING", (String) (String) font_space_map.get(edit.getFontSpacing()));				
        }				
		list.add(props);
	}
	return list;
  }
  public static List<Map<String,String>>  printEvents(JdapiIterator it, String indent) {
	List<Map<String,String>>  list = new ArrayList<Map<String,String>>();  
	while (it.hasNext())
	{
		Event evt = (Event)it.next();
		Map<String,String> props = new HashMap<String,String>();
		props.put("NAME", evt.getName());
		list.add(props);		
	}
	return list;
  }
  public static List<Map<String,String>> printObjectGroups(JdapiIterator it, String indent) {
    List<Map<String,String>>  list = new ArrayList<Map<String,String>>();   
	while (it.hasNext())
	{
		ObjectGroup obg = (ObjectGroup)it.next();		
		Map<String,String> props = new HashMap<String,String>();
		if(isWithProperties()) {			
			props.put("NAME", obg.getName());		
		    props.put("SUBCLASS_INFORMATION", obg.getParentName());
			props.put("COMMENTS", printComments(obg.getComment(),indent + "            "));
		}
		list.add(props);		
	}
	return list;
  }
  public static List<Map<String,String>> printPopupMenus(JdapiIterator it, String indent) {
	 List<Map<String,String>>  list = new ArrayList<Map<String,String>>();    
	while (it.hasNext())
	{
		Menu pum = (Menu)it.next();		
		Map<String,String> props = new HashMap<String,String>();
		if(isWithProperties()) {			
			props.put("NAME", pum.getName());		
		    props.put("SUBCLASS_INFORMATION", pum.getParentName());
			props.put("COMMENTS", printComments(pum.getComment(),indent + "            "));
			props.put("TEAR_OF_MENU",  (pum.isTearOffMenu() ? "Yes" : "No"));
			props.put("MENU_ITEMS", printPopupMenuItemNames(pum.getMenuItems()));
		}
		list.add(props);		
	}
	return list;
  }
  private static String printPopupMenuItemNames(JdapiIterator it) {
	  String menu_items = "";
	  while (it.hasNext())
	  {
		MenuItem mi = (MenuItem)it.next();
	    menu_items += mi.getName()+"\n";
	  }
	  return menu_items;
  } 
  
   public static List<Map<String,String>> printPopupMenuItems(JdapiIterator it, String indent) {
	List<Map<String,String>>  list = new ArrayList<Map<String,String>>();    
	while (it.hasNext())
	{
		Menu pum = (Menu)it.next();		
		Map<String,String> props = new HashMap<String,String>();
		
		List<Map<String,String>>  itemList = getPopupMenuItems(pum.getMenuItems(),"   ");
		if(itemList.size()>0) {
			Set<String> keySet = itemList.get(0).keySet();	     			
			for(Map<String,String> item : itemList) {				
                item.put("MENU_NAME",pum.getName());   				 
                list.add(item);				 
			}		
		}				
	}
	return list;
  }
  
  public static List<Map<String,String>>  getPopupMenuItems(JdapiIterator it, String indent) {
	List<Map<String,String>>  list = new ArrayList<Map<String,String>>(); 
	while (it.hasNext())
	{
		MenuItem mi = (MenuItem)it.next();	
		Map<String,String> props = new HashMap<String,String>();				
		props.put("NAME", mi.getName());		
		props.put("SUBCLASS_INFORMATION", mi.getParentName());
		props.put("COMMENTS", printComments(mi.getComment(),indent + "            "));	
		props.put("ENABLED", (mi.isEnabled() ? "Yes" : "No")); 			
		props.put("LABEL", mi.getLabel());						
		props.put("MENU_ITEM_TYPE", (String) mi_ityp_map.get(mi.getMenuItemType()));
		props.put("MAGIC_ITEM", (String) mi_mgit_map.get(mi.getMagicItem()));
		props.put("MENU_ITEM_RADIO_GROUP", mi.getMenuItemRadioGroup());
		props.put("COMMAND_TYPE", (String) mi_ctyp_map.get(mi.getCommandType()));
		props.put("COMMAND_TEXT", ""+mi.getCommandText());
		props.put("MENU_ITEM_CODE", ""+mi.getMenuItemCode());
		props.put("ICON_IN_MENU", (mi.isIconInMenu() ? "Yes" : "No"));
		props.put("ICON_FILENAME", ""+mi.getIconFilename());						
		props.put("VISIBLE", (mi.isVisible() ? "Yes" : "No"));
		props.put("VISUAL_ATTRIBUTE_GROUP", mi.getVisualAttributeName());				
		props.put("FONT_NAME", mi.getFontName());
		props.put("FONT_SIZE", ""+mi.getFontSize());
		props.put("FONT_WEIGHT", (String) font_weight_map.get(mi.getFontWeight()));
		props.put("FONT_STYLE", (String) font_style_map.get(mi.getFontStyle()));
		props.put("FONT_SPACING", (String) (String) font_space_map.get(mi.getFontSpacing()));	
		props.put("HINT", ""+mi.getHint());		
		list.add(props);
		
	}
	return list;
  }
  public static List<Map<String,String>> printPropertyClasses(JdapiIterator it, String indent) {
    List<Map<String,String>>  list = new ArrayList<Map<String,String>>();
    while (it.hasNext())
	{
		PropertyClass pcs = (PropertyClass)it.next();
		
		Map<String,String> props = new HashMap<String,String>();
		if(isWithProperties()) {			
			props.put("NAME", pcs.getName());		
		    props.put("SUBCLASS_INFORMATION", pcs.getParentName());
			props.put("COMMENTS", printComments(pcs.getComment(),indent + "            "));	
		}
		list.add(props);		
	}
	return list;
  }
   public static List<Map<String,String>> printReports(JdapiIterator it, String indent) {
	List<Map<String,String>>  list = new ArrayList<Map<String,String>>();   
	while (it.hasNext())
	{
		Report elm = (Report)it.next();
		
		Map<String,String> props = new HashMap<String,String>();
		if(isWithProperties()) {			
            props.put("NAME", elm.getName());		
		    props.put("SUBCLASS_INFORMATION", elm.getParentName());
			props.put("COMMENTS", printComments(elm.getComment(),indent + "            "));	
          	props.put("FILE_NAME", elm.getFilename());		
		    props.put("EXECUTION_MODE", (String) rep_exm_map.get(elm.getExecuteMode()));
			props.put("COMMUNICATION_MODE", (String) rep_com_map.get(elm.getCommMode()));
            props.put("DATA_SOURCE_DATA_BLOCK", elm.getDataSourceBlock());		
		    props.put("QUERY_NAME", elm.getQueryName());
			props.put("REPORT_DESTINATION_TYPE", (String) rep_dtyp_map.get(elm.getReportDestinationType()));
            props.put("REPORT_DESTINATION_NAME", elm.getReportDestinationName());		
		    props.put("REPORT_DESTINATION_FORMAT", elm.getReportDestinationFormat());
			props.put("REPORT_SERVER", elm.getReportServer()); 
            props.put("OTHER_REPORT_PARAMETERS", elm.getReportParameters());    			
		}
		list.add(props);		
	}
	return list;
  }
   public static List<Map<String,String>> printVisualAttributes(JdapiIterator it, String indent) {
	List<Map<String,String>>  list = new ArrayList<Map<String,String>>();    
	while (it.hasNext())
	{
		VisualAttribute elm = (VisualAttribute)it.next();
		
		Map<String,String> props = new HashMap<String,String>();
		if(isWithProperties()) {
			
			props.put("NAME", elm.getName());		
			props.put("VISUAL_ATTRIBUTE_TYPE", (String) va_type_map.get(elm.getVisualAttributeType()));	
		    props.put("SUBCLASS_INFORMATION", elm.getParentName());
			props.put("COMMENTS", printComments(elm.getComment(),indent + "            "));	
            props.put("FOREGROUND_COLOR", elm.getForegroundColor()); 			
			props.put("BACKGROUND_COLOR", elm.getBackColor());						
		    props.put("FILL_PATTERN", elm.getFillPattern());						
		    props.put("FONT_NAME", elm.getFontName());
			props.put("FONT_SIZE", ""+elm.getFontSize());
			props.put("FONT_WEIGHT", (String) font_weight_map.get(elm.getFontWeight()));
			props.put("FONT_STYLE", (String) font_style_map.get(elm.getFontStyle()));
			props.put("FONT_SPACING", (String) (String) font_space_map.get(elm.getFontSpacing()));			
		}
		list.add(props);
		
	}
	return list;
  }
  
 public static List<Map<String,String>> printFmbProperties(FormModule fmb, String indent) {
	
	List<Map<String,String>>  list = new ArrayList<Map<String,String>>();
	if(isWithProperties()) {
		Map<String,String> props = new HashMap<String,String>();       
		/*props.put("NAME", fmb.getName());		
		props.put("SUBCLASS_INFORMATION", fmb.getParentName());
		props.put("COMMENTS", printComments(fmb.getComment(),indent + "            "));
		props.put("HELP_BOOK_TITLE", fmb.getHelpBookTitle());
		props.put("TITLE", fmb.getTitle());	
		props.put("CONSOLE_WINDOW", fmb.getConsoleWindow());	
		props.put("MENU_MODULE", fmb.getMenuModule());
		props.put("INITIAL_MENU", fmb.getInitializeMenu());
		props.put("DEFER_REQUIRED_ENFORCEMENT", (String) fm_dre_map.get(fmb.getNewdeferReqEnf()));
		props.put("MENU_ROLE", fmb.getMenuRole());
		props.put("MOUSE_NAVIGATION_LIMIT", ""+fmb.getMouseNavigationLimit());
		props.put("FIRST_NAVIGATION_DATA_BLOCK", fmb.getFirstNavigationBlockName());
		props.put("CURRENT_RECORD_VISUAL_ATTRIBUTE_GROUP", fmb.getRecordVisualAttributeGroupName());
		props.put("VALIDATION_UNIT", (String) fm_vlu_map.get(fmb.getValidationUnit()));
		props.put("INTERACTION_MODE", (String) fm_inm_map.get(fmb.getInteractionMode()));
		props.put("MAXIMUM_QUERY_TIME", ""+fmb.getMaximumQueryTime());
		props.put("MAXIMUM_RECORDS_FETCHED",""+ fmb.getMaximumRecordsFetched());
		props.put("ISOLATION_MODE", (String) fm_ism_map.get(fmb.getIsolationMode()));
		props.put("COORDINATE_SYSTEM", "");
		props.put("USE_3D_CONTROLS", (fmb.isUse3dControls() ? "Yes" : "No"));		
		props.put("FORM_HORIZONTAL_TOOLBAR_CANVAS", fmb.getHorizontalToolbarCanvas());
		props.put("FORM_VERTICAL_TOOLBAR_CANVAS", fmb.getVerticalToolbarCanvas());
		props.put("DIRECTION", (String) prompt_reor_map.get(fmb.getLanguageDirection()));			
		props.put("CURSOR_MODE", ""+fmb.getCursorMode());		
		props.put("PARENT_FILE_NAME", fmb.getParentFilename());		
		props.put("PARENT_FILE_PATH", fmb.getParentFilepath());		
		props.put("PARENT_MODULE", fmb.getParentModule());			
		props.put("PARENT_MODULE_TYPE", ""+fmb.getParentModuleType() );	
		props.put("PARENT_NAME", fmb.getParentName());
		props.put("PARENT_TYPE", ""+fmb.getParentType());
		props.put("PERSISTENT_CLIENT_INFO_LENGTH", ""+fmb.getPersistentClientInfoLength());
		props.put("RUNTIME_COMP", ""+fmb.getRuntimeComp());
		props.put("TYPE_ID", ""+fmb.getTypeId());		
		props.put("IS_DIRTY_INFO", (fmb.isDirtyInfo() ? "Yes" : "No"));
		props.put("IS_SAVEPOINT_MODE", (fmb.isSavepointMode() ? "Yes" : "No"));	*/
		props.put("PROPERTY_NAME","NAME"); 
	    props.put("PROPERTY_VALUE", fmb.getName());
       	list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","SUBCLASS_INFORMATION"); 
	    props.put("PROPERTY_VALUE", fmb.getParentName());
		list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","COMMENTS"); 
	    props.put("PROPERTY_VALUE", printComments(fmb.getComment(),indent + "            "));
	    list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","HELP_BOOK_TITLE"); 	
		props.put("PROPERTY_VALUE", fmb.getHelpBookTitle());
		list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","TITLE"); 		
		props.put("PROPERTY_VALUE", fmb.getTitle());	
		list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","CONSOLE_WINDOW"); 		
		props.put("PROPERTY_VALUE", fmb.getConsoleWindow());	
		list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","MENU_MODULE");
		props.put("PROPERTY_VALUE", fmb.getMenuModule());
		list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","INITIAL_MENU");
		props.put("PROPERTY_VALUE", fmb.getInitializeMenu());
		list.add(props);                   
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","DEFER_REQUIRED_ENFORCEMENT");
		props.put("PROPERTY_VALUE", (String) fm_dre_map.get(fmb.getNewdeferReqEnf()));
		list.add(props);      
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","MENU_ROLE");
		props.put("PROPERTY_VALUE", fmb.getMenuRole());
		list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","MOUSE_NAVIGATION_LIMIT");
		props.put("PROPERTY_VALUE", ""+fmb.getMouseNavigationLimit());
		list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","FIRST_NAVIGATION_DATA_BLOCK");
		props.put("PROPERTY_VALUE", fmb.getFirstNavigationBlockName());
		list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","CURRENT_RECORD_VISUAL_ATTRIBUTE_GROUP");
		props.put("PROPERTY_VALUE", fmb.getRecordVisualAttributeGroupName());
		list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","VALIDATION_UNIT");
		props.put("PROPERTY_VALUE", (String) fm_vlu_map.get(fmb.getValidationUnit()));
		list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","INTERACTION_MODE");
		props.put("PROPERTY_VALUE", (String) fm_inm_map.get(fmb.getInteractionMode()));
		list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","MAXIMUM_QUERY_TIME");
		props.put("PROPERTY_VALUE", ""+fmb.getMaximumQueryTime());
		list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","MAXIMUM_RECORDS_FETCHED");
		props.put("PROPERTY_VALUE",""+ fmb.getMaximumRecordsFetched());
		list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","ISOLATION_MODE");
		props.put("PROPERTY_VALUE", (String) fm_ism_map.get(fmb.getIsolationMode()));
		list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","COORDINATE_SYSTEM");
		props.put("PROPERTY_VALUE", "");
		list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","USE_3D_CONTROLS");
		props.put("PROPERTY_VALUE", (fmb.isUse3dControls() ? "Yes" : "No"));
        list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","FORM_HORIZONTAL_TOOLBAR_CANVAS");		
		props.put("PROPERTY_VALUE", fmb.getHorizontalToolbarCanvas());
		list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","FORM_VERTICAL_TOOLBAR_CANVAS"); 
		props.put("PROPERTY_VALUE", fmb.getVerticalToolbarCanvas());
		list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","DIRECTION");
		props.put("PROPERTY_VALUE", (String) prompt_reor_map.get(fmb.getLanguageDirection()));	
        list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","CURSOR_MODE");		
		props.put("PROPERTY_VALUE", ""+fmb.getCursorMode());
        list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","PARENT_FILE_NAME");		
		props.put("PROPERTY_VALUE", fmb.getParentFilename());	
        list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","PARENT_FILE_PATH"); 		
		props.put("PROPERTY_VALUE", fmb.getParentFilepath());	
        list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","PARENT_MODULE");     		
		props.put("PROPERTY_VALUE", fmb.getParentModule());	
        list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","PARENT_MODULE_TYPE");		
		props.put("PROPERTY_VALUE", ""+fmb.getParentModuleType());
        list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","PARENT_NAME"); 		
		props.put("PROPERTY_VALUE", fmb.getParentName());
		list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","PARENT_TYPE"); 
		props.put("PROPERTY_VALUE", ""+fmb.getParentType());
		list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","PERSISTENT_CLIENT_INFO_LENGTH"); 
		props.put("PROPERTY_VALUE", ""+fmb.getPersistentClientInfoLength());
		list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","RUNTIME_COMP");
		props.put("PROPERTY_VALUE", ""+fmb.getRuntimeComp());
		list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","TYPE_ID");
		props.put("PROPERTY_VALUE", ""+fmb.getTypeId());
        list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","IS_DIRTY_INFO");  		
		props.put("PROPERTY_VALUE", (fmb.isDirtyInfo() ? "Yes" : "No"));
		list.add(props);
        props = new HashMap<String,String>();
        props.put("PROPERTY_NAME","IS_SAVEPOINT_MODE");
		props.put("PROPERTY_VALUE", (fmb.isSavepointMode() ? "Yes" : "No"));	
		list.add(props);        
    }	
    return list;	
 }
 
 public static void printPropsList(XSSFSheet sheet, List<Map<String,String>> data) {
	printPropsList(sheet, data, null); 
 }
 public static void printPropsList(XSSFSheet sheet, List<Map<String,String>> data, String[] rowList) {
	    if(data.size()>0) {
			int rowNum = 0;
			int colNum = 0;
			String[] keyList = null;
			if(rowList != null) {
				keyList = rowList;
			} else {
				Set<String> keys = data.get(0).keySet();
				keyList = keys.toArray(new String[keys.size()]);
			}			
			Row row = sheet.createRow(rowNum++);
			for(String key:keyList) {
				Cell cell = row.createCell(colNum++);
				cell.setCellValue(key); 
			}
			for(Map<String,String> props : data) {	
                row = sheet.createRow(rowNum++);
                colNum = 0;				
				for(String key : keyList) {					 				
					 Cell cell = row.createCell(colNum++);
					 String value = "" ;
					 if(props.get(key) != null) {
					    value += (String) props.get(key);
                     }					 
					 if(value.length()<32000) {
					    cell.setCellValue(value);
					 } else {
                         int ndx = 0; 						 
						 while(value.length()>32000) {
							 String value_1 = value.substring(0,32000);
							 if(ndx == 0) {
								 cell.setCellValue(value_1);
							 } else {
								 row = sheet.createRow(rowNum++);
								 int ndy = 0;
								 while(ndy<colNum) {
									 cell = row.createCell(ndy++);
									 if(ndy == colNum) {
                                         cell.setCellValue(value_1);
									 } else {
										 cell.setCellValue("");
									 };									 
								 }
							 }
						     value = value.substring(32000);
							 ndx++;
						 }
						 row = sheet.createRow(rowNum++);
						 int ndy = 0;
						 while(ndy<colNum) {
							 cell = row.createCell(ndy++);
							 if(ndy == colNum) {
							    cell.setCellValue(value);
                             }	else {
								cell.setCellValue("");
							 }						 
						 }
					 }
				}
			}
		}  
 }
 
 public static void main(String[] args)
{
    if(args.length !=2 ) {
		System.out.println("Kullanım : java Fmb2Yml <*.FMB> <*.TYP>"); 
		System.exit(0);
	} 
	XSSFWorkbook workbook = new XSSFWorkbook();
	String fmb_name = args[0];
	String type_name = args[1];
	JdapiModule.openModule(fmb_name);
	JdapiIterator fmbs = Jdapi.getModules();
	FormModule fmb = (FormModule)fmbs.next();
	item_type_map.put(0,"Bean Area");	
	item_type_map.put(1,"Check Box"); //OK		
	item_type_map.put(2,"Display Item"); //OK
	item_type_map.put(3,"Hierarchical Tree");
	item_type_map.put(4,"Image"); //OK
	item_type_map.put(5,"List Item"); //OK
	item_type_map.put(6,"Push Button"); //OK
	item_type_map.put(7,"Radio Group");	//OK
	item_type_map.put(8,"Text Item"); //OK
    item_type_map.put(9,"User Area");
	item_type_map.put(10,"Active X Control (Obsolete) ");
	item_type_map.put(11,"Chart Item (Obsolete)");
	item_type_map.put(12,"OLE Container (Obsolete)");
	item_type_map.put(13,"Sound (Obsolete)");
	item_type_map.put(14,"VBX Control(Obsolete)");
	
	just_type_map.put(0,"x Left");
	just_type_map.put(1,"Left");
	just_type_map.put(2,"Right");
	just_type_map.put(3,"Center");
	just_type_map.put(4,"Start");
	just_type_map.put(5,"End");
	
	data_type_map.put(0,"Char");
	data_type_map.put(1,"Number");
	data_type_map.put(2,"Date");
	data_type_map.put(3,"Alpha");
	data_type_map.put(4,"Integer");
	data_type_map.put(5,"Datetime");
	data_type_map.put(6,"Long");
    data_type_map.put(7,"Rnumber");
	data_type_map.put(8,"Jdate");
	data_type_map.put(9,"Edate");
    data_type_map.put(10,"Time");
	data_type_map.put(11,"Rinteger");
	data_type_map.put(12,"Money");
    data_type_map.put(13,"Rmoney");
	data_type_map.put(14,"Object REF");
	data_type_map.put(15,"Nchar");
	
	data_lensem_map.put(0,"Null");
	data_lensem_map.put(1,"BYTE");
	data_lensem_map.put(2,"CHAR");
	
	calc_mod_map.put(0,"None");
	calc_mod_map.put(1,"Formula");
	calc_mod_map.put(2,"Summary");
	
	calc_sum_map.put(0,"None");
	calc_sum_map.put(1,"Avg");
	calc_sum_map.put(2,"Count");
	calc_sum_map.put(3,"Max");
	calc_sum_map.put(4,"Min");
	calc_sum_map.put(5,"Stddev");
	calc_sum_map.put(6,"Sum");
	calc_sum_map.put(7,"Variance");
	
	phys_bevel_map.put(0,"Raised");
	phys_bevel_map.put(1,"Lowered");
	phys_bevel_map.put(2,"None");
	phys_bevel_map.put(3,"Inset");
	phys_bevel_map.put(4,"Outset");
	phys_bevel_map.put(5,"Plain");
	
	prompt_disp_map.put(0,"Hidden");
	prompt_disp_map.put(1,"First Record");
	prompt_disp_map.put(2,"All Records");
	
	prompt_just_map.put(0,"Left");
	prompt_just_map.put(1,"Right");
	prompt_just_map.put(2,"Center");
	prompt_just_map.put(3,"Start");
	prompt_just_map.put(4,"End");
	
	prompt_ated_map.put(0,"Start");
	prompt_ated_map.put(1,"End");
	prompt_ated_map.put(2,"Top");
	prompt_ated_map.put(3,"Bottom");

    prompt_algn_map.put(0,"Start");
	prompt_algn_map.put(1,"End");
	prompt_algn_map.put(2,"Center");

	prompt_reor_map.put(0,"Default");
	prompt_reor_map.put(1,"Left To Right");
	prompt_reor_map.put(2,"Right To Left");
	
	font_weight_map.put(0,"Ultralight");
	font_weight_map.put(1,"Extralight");
	font_weight_map.put(2,"Light");
	font_weight_map.put(3,"Demilight");
	font_weight_map.put(4,"Normal");
	font_weight_map.put(5,"Ultrabold");
	font_weight_map.put(6,"Extrabold");
	font_weight_map.put(7,"Bold");
	font_weight_map.put(8,"Demibold");
	
    font_style_map.put(0,"Plain");
	font_style_map.put(1,"Italic");
	font_style_map.put(2,"Oblique");
	font_style_map.put(3,"Underline");
	font_style_map.put(4,"Outline");
	font_style_map.put(5,"Shadow");
	font_style_map.put(6,"Inverted");
	font_style_map.put(7,"Overstrike");
	font_style_map.put(8,"Blind");
	
	font_space_map.put(0,"Ultradense");
	font_space_map.put(1,"Extradense");
	font_space_map.put(2,"Dense");
	font_space_map.put(3,"Semidense");
	font_space_map.put(4,"Normal");
    font_space_map.put(5,"Semiexpand");
	font_space_map.put(6,"Expand");
	font_space_map.put(7,"Extraexpand");
	font_space_map.put(8,"Ultraexpand");
	
	func_wrap_map.put(0,"None");
	func_wrap_map.put(1,"Character");
	func_wrap_map.put(2,"Word");

	func_case_map.put(0,"Mixed");
	func_case_map.put(1,"Upper");
	func_case_map.put(2,"Lower");
	
	img_format_map.put(0,"BMP");
	img_format_map.put(1,"CALS");
	img_format_map.put(2,"GIF");
	img_format_map.put(3,"JFIF");
	img_format_map.put(4,"PICT");
	img_format_map.put(5,"RAS");
	img_format_map.put(6,"TIFF");
	img_format_map.put(7,"TPIC");
	
	img_depth_map.put(0,"Original");
	img_depth_map.put(1,"Monochrome");
	img_depth_map.put(2,"Gray");
	img_depth_map.put(3,"LUT");
	img_depth_map.put(4,"RGB");
	
	img_dispq_map.put(0,"High");
    img_dispq_map.put(1,"Medium");
    img_dispq_map.put(2,"Low");
	
	img_sizing_map.put(0, "Crop");
	img_sizing_map.put(1, "Adjust");
   
    list_type_map.put(0, "Poplist");
	list_type_map.put(1, "Tlist");
	list_type_map.put(2, "Combo Box");
	
	block_ns_map.put(0, "Same Record");
	block_ns_map.put(1, "Change Record");
	block_ns_map.put(2, "Change Data Block");
	
	block_recor_map.put(0, "Vertical");
	block_recor_map.put(1, "Horizantal");
	
	block_dstyp_map.put(0,"VARCHAR2");
	block_dstyp_map.put(1,"NUMBER");
	block_dstyp_map.put(2,"LONG");
	block_dstyp_map.put(3,"ROWID");
	block_dstyp_map.put(4,"DATA");
	block_dstyp_map.put(5,"RAW");
	block_dstyp_map.put(6,"LONG RAW");
	block_dstyp_map.put(7,"CHAR");
	block_dstyp_map.put(8,"MLSLABEL");
	block_dstyp_map.put(9,"TABLE");
	block_dstyp_map.put(10,"RECORD");
	block_dstyp_map.put(11,"REFCURSOR");
	block_dstyp_map.put(12,"NAMED TYP");
	block_dstyp_map.put(13,"OBJECT REF");
	block_dstyp_map.put(10,"VARRAY");
	block_dstyp_map.put(11,"Nested Table");
	block_dstyp_map.put(12,"BLOB");
	block_dstyp_map.put(13,"CLOB");
	block_dstyp_map.put(14,"BFILE");
	block_dstyp_map.put(15,"NVARCHAR2");
	block_dstyp_map.put(16,"NCHAR");
	block_dstyp_map.put(17,"NCLOB");
	
	block_qdst_map.put(0,"None");
	block_qdst_map.put(1,"Table");
	block_qdst_map.put(2,"Procedure");
	block_qdst_map.put(3,"Transactional Triggers");
	block_qdst_map.put(4,"FROM clause query");
	
	block_dsmod_map.put(0,"IN");
	block_dsmod_map.put(1,"OUT");
	block_dsmod_map.put(2,"IN OUT");
	
	block_lcmd_map.put(0, "Immediate");
    block_lcmd_map.put(1, "Delayed");
	block_lcmd_map.put(2, "Automatic");
	
	block_kymd_map.put(0, "Unique");
    block_kymd_map.put(1, "Updatable");
    block_kymd_map.put(1, "Non-Updatable");
	block_kymd_map.put(3, "Automatic");
	
    block_dmtt_map.put(0,"None");
	block_dmtt_map.put(1,"Table");
	block_dmtt_map.put(2,"Procedure");
	block_dmtt_map.put(3,"Transactional Triggers");
	
	trg_style_map.put(0,"PL/SQL");
	
	trg_hie_map.put(0, "Override");
	trg_hie_map.put(1, "Before");
	trg_hie_map.put(2, "After");
	
	cnv_type_map.put(0, "Content");
	cnv_type_map.put(1, "Stacked");
	cnv_type_map.put(2, "Vertical Toolbar");
	cnv_type_map.put(3, "Horizantal Toolbar");
	cnv_type_map.put(4, "Tab");
	
	lst_type_map.put(0,"Record Group");
	
	prm_type_map.put(0, "Char");
	prm_type_map.put(1, "Number");
	prm_type_map.put(2, "Date");
	
	alert_style_map.put(0, "Stop");
	alert_style_map.put(1, "Caution");
	alert_style_map.put(2, "Note");
	
	alert_btn_map.put(0, "Button 1");
	alert_btn_map.put(1, "Button 2");
	alert_btn_map.put(2, "Button 3");
	
	rg_cdt_map.put(0,"Character");
	rg_cdt_map.put(1,"Number");
	rg_cdt_map.put(2,"Date");
	
	rg_type_map.put(0,"Query");
	rg_type_map.put(1,"Static");
	
	va_type_map.put(0,"Common");
	va_type_map.put(0,"Prompt");
	va_type_map.put(0,"Title");

	win_style_map.put(0,"Document");
	win_style_map.put(1,"Dialog");
   
    mi_ityp_map.put(0,"Plain");
	mi_ityp_map.put(1,"Check");
    mi_ityp_map.put(2,"Radio");	
	mi_ityp_map.put(3,"Seperator");
	mi_ityp_map.put(4,"Magic");
	
	mi_mgit_map.put(0,"None");
	mi_mgit_map.put(1,"Cut");
	mi_mgit_map.put(2,"Copy");
	mi_mgit_map.put(3,"Paste");
	mi_mgit_map.put(4,"Clear");
	mi_mgit_map.put(5,"Undo");
	mi_mgit_map.put(6,"Help");
	mi_mgit_map.put(7,"About");
	mi_mgit_map.put(8,"Quick");
	mi_mgit_map.put(9,"Window");
	mi_mgit_map.put(10,"Page Setup (Obsolete)");
	
	mi_ctyp_map.put(0,"Null");
    mi_ctyp_map.put(1,"Menu");
    mi_ctyp_map.put(2,"PL/SQL");
	
	rep_exm_map.put(0, "Batch");
	rep_exm_map.put(1, "Runtime");
	
	rep_com_map.put(0, "Synchronous");
	rep_com_map.put(1, "Asynchronous");
	
	rep_dtyp_map.put(0, "Preview");
	rep_dtyp_map.put(1, "File");
	rep_dtyp_map.put(2, "Printer");
	rep_dtyp_map.put(3, "Mail");
	rep_dtyp_map.put(4, "Cache");
	rep_dtyp_map.put(5, "Screen");
	rep_dtyp_map.put(6, "Ftp");
	rep_dtyp_map.put(7, "Webdav");
	rep_dtyp_map.put(8, "BlobDestination");
	rep_dtyp_map.put(9, "OraclePortal");
	rep_dtyp_map.put(10, "OracleWireless");
	rep_dtyp_map.put(11, "SecurePDF");
	rep_dtyp_map.put(12, "PlugDest");
	
	rel_typ_map.put(0,"Join");
	rel_typ_map.put(1,"Ref");
	
	rel_del_map.put(0,"Cascading");
	rel_del_map.put(1,"Isolated");
	rel_del_map.put(2,"Non Isolated");
	
	fm_dre_map.put(0,"Yes");
	fm_dre_map.put(1,"No");
    fm_dre_map.put(2,"4.5");

	fm_mnl_map.put(0,"Form");
	fm_mnl_map.put(1,"Data Block");
	fm_mnl_map.put(2,"Record");
	fm_mnl_map.put(3,"Item");
	
	fm_vlu_map.put(0,"Default");
	fm_vlu_map.put(1,"Form");
	fm_vlu_map.put(2,"Data Block");
	fm_vlu_map.put(3,"Record");
	fm_vlu_map.put(4,"Item");
	
	fm_inm_map.put(0,"Blocking");
	fm_inm_map.put(1,"Non-Blocking");
	
	fm_ism_map.put(0,"Read Committed");
	fm_ism_map.put(1,"Serializable");
	
	
	if("LIB".equals(type_name)) {	
		printPropsList(workbook.createSheet("Attached_Libraries"), printLibraries(fmb.getAttachedLibraries(), "    "));		
	}
	
	if("TRG".equals(type_name)) {		
		printPropsList(workbook.createSheet("Triggers"), printTriggers(fmb.getTriggers(), "    "));	
	}
	if("BLK".equals(type_name)) {		
		printPropsList(workbook.createSheet("Data_Blocks"), printBlocks(fmb.getBlocks(), "    "));	
	}
	if("BLT".equals(type_name)) {		
		printPropsList(workbook.createSheet("Block_Triggers"), printBlockTriggers(fmb.getBlocks(), "    "));	
	}
	if("BLR".equals(type_name)) {	
		printPropsList(workbook.createSheet("Block_Relations"), printBlockRelations(fmb.getBlocks(), "    "));	
	}
	if("BLI".equals(type_name)) {		
		printPropsList(workbook.createSheet("Block_Items"), printBlockItems(fmb.getBlocks(), "    "));	
		printPropsList(workbook.createSheet("Block_Item_Triggers"), printBlockItemTriggers(fmb.getBlocks(), "    "));	
	}
	if("CNV".equals(type_name)) {		
		printPropsList(workbook.createSheet("Canvases"), printCanvases(fmb.getCanvases(), "    "));
	}
	if("LOV".equals(type_name)) {		
		printPropsList(workbook.createSheet("List_Of_Values"), printLovs(fmb.getLOVs(), "    "));
	}
	if("PRM".equals(type_name)) {		
		printPropsList(workbook.createSheet("Parameters"), printParameters(fmb.getModuleParameters(), "    "));
	}
	if("PRU".equals(type_name)) {		
		printPropsList(workbook.createSheet("Program_Units"), printProgramUnits(fmb.getProgramUnits(), "    "));	
	}
	if("RCG".equals(type_name)) {		
		printPropsList(workbook.createSheet("Record_Groups"), printRecordGroups(fmb.getRecordGroups(), "    "));
	}
	if("WIN".equals(type_name)) {		
		printPropsList(workbook.createSheet("Windows"), printWindows(fmb.getWindows(), "    "));
	}
	if("ALR".equals(type_name)) {		
		printPropsList(workbook.createSheet("Alerts"), printAlerts(fmb.getAlerts(), "    "));
	}
	if("EDT".equals(type_name)) {		
		printPropsList(workbook.createSheet("Editors"), printEditors(fmb.getEditors(), "    "));
	}
	if("EVT".equals(type_name)) {		
		printPropsList(workbook.createSheet("Events"), printEvents(fmb.getEvents(), "    "));
	}
	if("OBG".equals(type_name)) {		
		printPropsList(workbook.createSheet("Object_Groups"), printObjectGroups(fmb.getObjectGroups(), "    "));
	}
	if("PUM".equals(type_name)) {		
		printPropsList(workbook.createSheet("Popup_Menus"), printPopupMenus(fmb.getMenus(), "    "));
	}
	
	if("PMI".equals(type_name)) {		
		printPropsList(workbook.createSheet("Popup_Menus_Items"), printPopupMenuItems(fmb.getMenus(), "    "));
	}
	
	if("PCS".equals(type_name)) {		
		printPropsList(workbook.createSheet("Property_Classes"), printPropertyClasses(fmb.getPropertyClasses(), "    "));
	}
	if("REP".equals(type_name)) {		
		printPropsList(workbook.createSheet("Reports"), printReports(fmb.getReports(), "    "));
	}
	if("VAT".equals(type_name)) {		
		printPropsList(workbook.createSheet("Visual_Attributes"), printVisualAttributes(fmb.getVisualAttributes(), "    "));
	} 
	if("FPR".equals(type_name)) {		
		printPropsList(workbook.createSheet("Form_Properties"), printFmbProperties(fmb, "    "));
	} 
	if("ALL".equals(type_name)) {
		printPropsList(workbook.createSheet("Form_Properties"), printFmbProperties(fmb, "    "));
		printPropsList(workbook.createSheet("Form_Triggers"), printTriggers(fmb.getTriggers(), "    "));
        printPropsList(workbook.createSheet("Alerts"), printAlerts(fmb.getAlerts(), "    "));	
        printPropsList(workbook.createSheet("Attached_Libraries"), printLibraries(fmb.getAttachedLibraries(), "    "));	
        printPropsList(workbook.createSheet("Data_Blocks"), printBlocks(fmb.getBlocks(), "    ")); 
        printPropsList(workbook.createSheet("Block_Triggers"), printBlockTriggers(fmb.getBlocks(), "    "));
        printPropsList(workbook.createSheet("Block_Relations"), printBlockRelations(fmb.getBlocks(), "    "));
        printPropsList(workbook.createSheet("Block_Items"), printBlockItems(fmb.getBlocks(), "    "));	
		printPropsList(workbook.createSheet("Block_Item_Triggers"), printBlockItemTriggers(fmb.getBlocks(), "    "));
        printPropsList(workbook.createSheet("Canvases"), printCanvases(fmb.getCanvases(), "    "));
        printPropsList(workbook.createSheet("Editors"), printEditors(fmb.getEditors(), "    ")); 
        printPropsList(workbook.createSheet("Events"), printEvents(fmb.getEvents(), "    "));	
        printPropsList(workbook.createSheet("List_Of_Values"), printLovs(fmb.getLOVs(), "    "));
		printPropsList(workbook.createSheet("Object_Groups"), printObjectGroups(fmb.getObjectGroups(), "    "));
		printPropsList(workbook.createSheet("Parameters"), printParameters(fmb.getModuleParameters(), "    "));
		printPropsList(workbook.createSheet("Popup_Menus"), printPopupMenus(fmb.getMenus(), "    "));
		printPropsList(workbook.createSheet("Popup_Menus_Items"), printPopupMenuItems(fmb.getMenus(), "    "));
		printPropsList(workbook.createSheet("Program_Units"), printProgramUnits(fmb.getProgramUnits(), "    "));
		printPropsList(workbook.createSheet("Property_Classes"), printPropertyClasses(fmb.getPropertyClasses(), "    "));
		printPropsList(workbook.createSheet("Record_Groups"), printRecordGroups(fmb.getRecordGroups(), "    "));
		printPropsList(workbook.createSheet("Reports"), printReports(fmb.getReports(), "    "));
		printPropsList(workbook.createSheet("Visual_Attributes"), printVisualAttributes(fmb.getVisualAttributes(), "    "));
		printPropsList(workbook.createSheet("Windows"), printWindows(fmb.getWindows(), "    "));		
	}
	
	if("ABS".equals(type_name)) {
		printPropsList(workbook.createSheet("Form_Properties"), printFmbProperties(fmb, "    "), new String[]{"PROPERTY_NAME",
		                                                                                                      "PROPERTY_VALUE"});
		printPropsList(workbook.createSheet("Form_Triggers"), printTriggers(fmb.getTriggers(), "    "), new String[]{"NAME", 
		"SUBCLASS_INFORMATION", 
		"COMMENTS", 
		"TRIGGER_STYLE",
		"TRIGGER_TEXT", 
		"FIRE_IN_ENTER_QUERY_MODE", 
		"EXECUTION_HIERARCHY", 		
		"DISPLAY_IN_KEYBOARD_HELP", 		
		"KEYBOARD_HELP_TEXT"});		
        printPropsList(workbook.createSheet("Alerts"), printAlerts(fmb.getAlerts(), "    "), new String[]{"NAME", 
		"SUBCLASS_INFORMATION", 
		"COMMENTS", 
		"TITLE",
		"MESSAGE",
		"ALERT_STYLE",
		"BUTTON_1_LABEL",
		"BUTTON_2_LABEL",
		"BUTTON_3_LABEL",
		"DEFAULT_ALERT_BUTTON",
		"VISUAL_ATTRIBUTE_GROUP", 
		"FOREGROUND_COLOR",
		"BACKGROUND_COLOR",
		"FILL_PATTERN",
		"FONT_NAME", 
		"FONT_SIZE", 
		"FONT_WEIGHT", 
		"FONT_STYLE", 
		"FONT_SPACING",
		"DIRECTION"});	
        printPropsList(workbook.createSheet("Attached_Libraries"), printLibraries(fmb.getAttachedLibraries(), "    "),new String[]{"NAME",
		                                                                                                                           "COMMENTS",
																																   "LIBRARY_LOCATION"});	
        printPropsList(workbook.createSheet("Data_Blocks"), printBlocks(fmb.getBlocks(), "    "),new String[]{ "NAME",	
		"SUBCLASS_INFORMATION",
	    "COMMENTS",
        "TRIGGERS",
        "ITEMS",
        "RELATIONS",		
		"NAVIGATION_STYLE", 	
		"PREVIOUS_NAVIGATION_DATA_BLOCK",
	    "NEXT_NAVIGATION_DATA_BLOCK", 
		"CURRENT_RECORD_VISUAL_ATTRIBUTE_GROUP",
		"QUERY_ARRAY_SIZE", 
	    "NUMBER_OF_RECORD_BUFFERED", 
		"NUMBER_OF_RECORD_DISPLAYED", 
	    "QUERY_ALL_RECORDS", 
	    "RECORD_ORIENTATION", 
		"SINGLE_RECORD",	
		"DATABASE_DATA_BLOCK", 
		"ENFORCE_PRIMARY_KEY",
		"QUERY_ALLOWED", 
	    "QUERY_DATA_SOURCE_TYPE", 
	    "QUERY_DATA_SOURCE_NAME", 
		"QUERY_DATA_SOURCE_COLUMNS", 		
		"QUERY_DATA_SOURCE_ARGUMENTS", 
		"ALIAS", 
	    "INCLUDE_REF_ITEM", 
		"WHERE_CLAUSE", 
	    "ORDER_BY_CLAUSE",
	    "OPTIMIZER_HINT", 
		"INSERT_ALLOWED",	
		"UPDATE_ALLOWED", 
		"LOCKING_MODE",
		"DELETE_ALLOWED", 
		"KEY_MODE", 
		"UPDATE_CHANGED_COLUMN_ONLY",
		"ENFORCE_COLUMN_SECURITY", 
		"MAXIMUM_QUERY_TIME", 
		"MAXIMUM_RECORDS_FETCHED", 
		"DML_DATA_TARGET_TYPE", 
		"DML_DATA_TARGET_NAME", 
		"INSERT_PROCEDURE_NAME", 		
		"INSERT_PROCEDURE_RESULTSET_COLUMNS",
		"INSERT_PROCEDURE_ARGUMENTS", 
		"UPDATE_PROCEDURE_NAME", 
		"UPDATE_PROCEDURE_RESULTSET_COLUMNS", 
		"UPDATE_PROCEDURE_ARGUMENTS", 
		"DELETE_PROCEDURE_NAME", 	
		"DELETE_PROCEDURE_RESULTSET_COLUMNS", 
		"DELETE_PROCEDURE_ARGUMENTS", 
		"LOCK_PROCEDURE_NAME", 
		"LOCK_PROCEDURE_RESULTSET_COLUMNS", 
		"LOCK_PROCEDURE_ARGUMENTS", 
		"DML_ARRAY_SIZE", 
	    "PRECOMPUTE_SUMMARIES", 
		"DML_RETURNING_VALUE", 		
		"SHOW_SCROLL_BAR", 
		"SCROLL_BAR_CANVAS", 
		"SCROLL_BAR_TAB_PAGE", 
		"SCROLL_BAR_ORIENTATION", 
		"SCROLL_BAR_X_POSITION", 
		"SCROLL_BAR_Y_POSITION", 
		"SCROLL_BAR_WIDTH", 
	    "SCROLL_BAR_LENGTH", 
		"REVERSE_DIRECTION", 
		"VISUAL_ATTRIBUTE_GROUP",
		"FOREGROUND_COLOR", 
		"BACKGROUND_COLOR", 
		"FILL_PATTERN", 
		"DIRECTION"}); 
        printPropsList(workbook.createSheet("Block_Triggers"), printBlockTriggers(fmb.getBlocks(), "    "),new String[]{"BLOCK_NAME",
			                                                                                                            "NAME", 
		"SUBCLASS_INFORMATION", 
		"COMMENTS", 
		"TRIGGER_STYLE",
		"TRIGGER_TEXT", 
		"FIRE_IN_ENTER_QUERY_MODE", 
		"EXECUTION_HIERARCHY", 		
		"DISPLAY_IN_KEYBOARD_HELP", 		
		"KEYBOARD_HELP_TEXT"});
        printPropsList(workbook.createSheet("Block_Relations"), printBlockRelations(fmb.getBlocks(), "    "),   new String[]{"BLOCK_NAME", 
		"NAME", 
		"RELATION_TYPE", 
		"SUBCLASS_INFORMATION", 
		"COMMENTS", 
		"DETAIL_DATA_BLOCK", 
		"DELETE_RECORD_BEHAVIOUR", 
		"PREVENT_MASTERLESS_OPERATIONS", 
		"DEFERRED", 
		"AUTOMATIC_QUERY"});
        printPropsList(workbook.createSheet("Block_Items"), printBlockItems(fmb.getBlocks(), "    "), new String[]{"BLOCK_NAME",
		"NAME", 
		"ITEM_TYPE", 
		"SUBCLASS_INFORMATION",
		"COMMENTS", 
		"TRIGGERS",
		"HELP_BOOK_TOPIC",
		"ENABLED", 
		"LABEL", 
		"IMAGE_FORMAT", 
		"IMAGE_DEPTH", 
		"DISPLAY_QUALITY", 
		"SIZING_STYLE", 
		"ELEMENTS_IN_LIST", 
		"LIST_TYPE", 
		"ACCESS_KEY", 
		"JUSTIFICATION", 
		"MAPPING_OF_OTHER_VALUES", 
		"IMPLEMENTATION_CLASS", 
		"ICONIC", 
		"ICON_FILENAME", 
		"DEFAULT_BUTTON", 
		"MULTI_LINE", 
		"WRAP_STYLE", 
		"CASE_RESTRICTION",
		"CONCEAL_DATA", 
		"KEEP_CURSOR_POSITION", 
		"AUTOMATIC_SKIP", 
		"VALUE_WHEN_CHECKED", 
		"VALUE_WHEN_UNCHECKED", 
		"CHECK_BOX_MAPPING_OF_OTHER_VALUES",
		"POPUP_MENU",
		"KEYBOARD_NAVIGABLE", 
		"MOUSE_NAVIGATE",
		"PREVIOUS_NAVIGATION_ITEM",
		"NEXT_NAVIGATION_ITEM",
		"DATA_TYPE", 
		"DATA_LENGTH_SEMANTICS", 
		"MAXIMUM_LENGTH", 
		"INITIAL_VALUE", 
		"REQUIRED",
		"FORMAT_MASK",
		"LOWEST_ALLOWED_VALUE", 
		"HIGHEST_ALLOWED_VALUE", 
		"COPY_VALUE_FROM_ITEM", 
		"SYNCHRONIZE_WITH_ITEM", 
		"CURRENT_RECORD_VISUAL_ATTRIBUTE_GROUP",
		"CALCULATION_MODE", 
		"FORMULA", 
		"SUMMARY_FUNCTION",
		"SUMMARIZED_BLOCK", 
		"SUMMARIZED_ITEM", 
		"DISTANCE_BETWEEN_RECORDS",
		"NUMBER_OF_ITEMS_DISPLAYED",
		"DATABASE_ITEM", 
		"COLUMN_NAME", 
		"PRIMARY_KEY", 
		"QUERY_ONLY", 
		"QUERY_ALLOWED", 
		"CASE_INSENSITIVE_QUERY", 
		"INSERT_ALLOWED", 
		"UPDATE_ALLOWED", 
		"UPDATE_ONLY_IF_NULL", 
		"LOCK_RECORD", 
		"LIST_OF_VALUES",
		"LIST_X_POSITION",
		"LIST_Y_POSITION",
		"VALIDATE_FROM_LIST",
		"EDITOR",
		"EDITOR_X_POSITION",
		"EDITOR_Y_POSITION",
		"VISIBLE",
		"CANVAS",
		"TAB_PAGE",
		"X_POSITION", 
		"Y_POSITION", 
		"WIDTH",
		"HEIGHT",
		"BEVEL",
		"RENDERED", 
		"SHOW_HORIZONTAL_SCROLL_BAR", 
		"SHOW_VERTICAL_SCROLL_BAR", 
		"VISUAL_ATTRIBUTE_GROUP",
		"PROMPT_VISUAL_ATTRIBUTE_GROUP",
		"FOREGROUND_COLOR", 
		"BACKGROUND_COLOR",
		"FILL_PATTERN", 
		"FONT_NAME", 
		"FONT_SIZE", 
		"FONT_WEIGHT", 
		"FONT_STYLE", 
		"FONT_SPACING",
		"PROMPT",  
		"PROMPT_DISPLAY_STYLE", 
		"PROMPT_JUSTIFICATION",  
		"PROMPT_ATTACHMENT_EDGE",   
		"PROMPT_ALIGNMENT",  
		"PROMPT_ATTACHMENT_OFFSET",  
		"PROMPT_ALIGNMENT_OFFSET", 
		"PROMPT_READING_ORDER",  
		"PROMPT_FOREGROUND_COLOR",
		"PROMPT_FONT_NAME", 
		"PROMPT_FONT_SIZE", 
		"PROMPT_FONT_WEIGHT", 
		"PROMPT_FONT_STYLE", 
		"PROMPT_FONT_SPACING",
		"HINT", 
		"DISPLAY_HINT_AUTOMATICALLY", 
		"TOOLTIP",
		"TOOLTIP_VISUAL_ATTRIBUTE_GROUP", 
		"INITIAL_KEYBOARD_STATE", 
		"READING_ORDER", 
		"KEYBOARD_STATE",
	    "DIRECTION"});	
		printPropsList(workbook.createSheet("Block_Item_Triggers"), printBlockItemTriggers(fmb.getBlocks(), "    "),new String[]{"BLOCK_NAME",
																														"ITEM_NAME",
			                                                                                                            "NAME", 
		"SUBCLASS_INFORMATION", 
		"COMMENTS", 
		"TRIGGER_STYLE",
		"TRIGGER_TEXT", 
		"FIRE_IN_ENTER_QUERY_MODE", 
		"EXECUTION_HIERARCHY", 		
		"DISPLAY_IN_KEYBOARD_HELP", 		
		"KEYBOARD_HELP_TEXT"});
        printPropsList(workbook.createSheet("Canvases"), printCanvases(fmb.getCanvases(), "    "), new String[]{"NAME", 
		"CANVAS_TYPE", 
		"SUBCLASS_INFORMATION", 
		"COMMENTS", 
		"HELP_BOOK_TOPIC", 
		"RAISE_ON_ENTRY", 
		"VISIBLE", 
		"WINDOW", 
		"VIEWPORT_X_POSITION_ON_CANVAS", 
		"VIEWPORT_Y_POSITION_ON_CANVAS", 
		"WIDTH", 
		"HEIGHT",
		"BEVEL", 
		"VISUAL_ATTRIBUTE_GROUP", 
		"FOREGROUND_COLOR", 
		"BACKGROUND_COLOR", 
		"FILL_PATTERN", 
	    "DIRECTION"});
        printPropsList(workbook.createSheet("Editors"), printEditors(fmb.getEditors(), "    "), new String[]{"NAME",  
		"SUBCLASS_INFORMATION", 
		"COMMENTS", 
		"TITLE",
		"BOTTOM_TITLE",
		"WRAP_STYLE", 
		"X_POSITION", 
		"Y_POSITION",
		"WIDTH", 
		"HEIGHT", 
		"SHOW_HORIZONTAL_SCROLL_BAR",
		"VISUAL_ATTRIBUTE_GROUP", 
		"FOREGROUND_COLOR", 
		"BACKGROUND_COLOR", 
		"FILL_PATTERN", 
		"FONT_NAME", 
		"FONT_SIZE", 
		"FONT_WEIGHT", 
		"FONT_STYLE", 
		"FONT_SPACING",
	    "DIRECTION"}); 
        printPropsList(workbook.createSheet("Events"), printEvents(fmb.getEvents(), "    "),new String[]{"NAME"});	
        printPropsList(workbook.createSheet("List_Of_Values"), printLovs(fmb.getLOVs(), "    "),new String[]{
		"NAME",  
		"SUBCLASS_INFORMATION", 
		"COMMENTS", 
		"TITLE",
		"LIST_TYPE", 
		"RECORD_GROUP", 
		"COLUMN_MAPPING_PROPERTIES", 
		"FILTER_BEFORE_DISPLAY", 
		"AUTOMATIC_DISPLAY", 
		"AUTOMATIC_REFRESH",
		"AUTOMATIC_SELECT", 
		"AUTOMATIC_SKIP", 
		"AUTOMATIC_POSITION",
		"AUTOMATIC_COLUMN_WIDTH",
		"X_POSITION", 
		"Y_POSITION",
		"WIDTH", 
		"HEIGHT", 
		"VISUAL_ATTRIBUTE_GROUP", 
		"FOREGROUND_COLOR", 
		"BACKGROUND_COLOR", 
		"FILL_PATTERN", 
		"FONT_NAME", 
		"FONT_SIZE", 
		"FONT_WEIGHT", 
		"FONT_STYLE", 
		"FONT_SPACING",
	    "DIRECTION"});
		printPropsList(workbook.createSheet("Object_Groups"), printObjectGroups(fmb.getObjectGroups(), "    "), new String[]{"NAME",  
        "SUBCLASS_INFORMATION", 
	    "COMMENTS"});
		printPropsList(workbook.createSheet("Parameters"), printParameters(fmb.getModuleParameters(), "    "), new String[]{"NAME",  
		"SUBCLASS_INFORMATION", 
		"COMMENTS", 
		"PARAMETER_DATA_TYPE",
		"PARAMETER_INITIAL_VALUE"});
		printPropsList(workbook.createSheet("Popup_Menus"), printPopupMenus(fmb.getMenus(), "    "), new String[]{"NAME",  
		"SUBCLASS_INFORMATION", 
		"COMMENTS", 
		"TEAR_OF_MENU",
		"MENU_ITEMS"});
		printPropsList(workbook.createSheet("Popup_Menus_Items"), printPopupMenuItems(fmb.getMenus(), "    "), new String[]{"NAME",  
		"SUBCLASS_INFORMATION", 
		"COMMENTS", 
		"ENABLED", 			
		"LABEL",						
		"MENU_ITEM_TYPE",
		"MAGIC_ITEM", 
		"MENU_ITEM_RADIO_GROUP", 
		"COMMAND_TYPE", 
		"COMMAND_TEXT", 
		"MENU_ITEM_CODE", 
		"ICON_IN_MENU", 
		"ICON_FILENAME", 					
		"VISIBLE", 
		"VISUAL_ATTRIBUTE_GROUP",  
		"FONT_NAME", 
		"FONT_SIZE", 
		"FONT_WEIGHT", 
		"FONT_STYLE", 
		"FONT_SPACING",
		"HINT"});
		printPropsList(workbook.createSheet("Program_Units"), printProgramUnits(fmb.getProgramUnits(), "    "), new String[]{"NAME", 
		"SUBCLASS_INFORMATION", 
		"COMMENTS", 
		"TEXT"});
		printPropsList(workbook.createSheet("Property_Classes"), printPropertyClasses(fmb.getPropertyClasses(), "    "), new String[]{"NAME", 
		"SUBCLASS_INFORMATION", 
		"COMMENTS"});
		printPropsList(workbook.createSheet("Record_Groups"), printRecordGroups(fmb.getRecordGroups(), "    "), new String[]{"NAME", 
		"SUBCLASS_INFORMATION", 
		"COMMENTS", 
		"QUERY",
		"RECORD_GROUP_TYPE",
		"COLUMN_SPECIFICATIONS"});
		printPropsList(workbook.createSheet("Reports"), printReports(fmb.getReports(), "    "), new String[]{"NAME", 
		"SUBCLASS_INFORMATION", 
		"COMMENTS", 
		"FILE_NAME",	
		"EXECUTION_MODE",
		"COMMUNICATION_MODE", 
		"DATA_SOURCE_DATA_BLOCK",	
		"QUERY_NAME",
		"REPORT_DESTINATION_TYPE", 
		"REPORT_DESTINATION_NAME", 		
		"REPORT_DESTINATION_FORMAT", 
		"REPORT_SERVER", 
		"OTHER_REPORT_PARAMETERS"});
		printPropsList(workbook.createSheet("Visual_Attributes"), printVisualAttributes(fmb.getVisualAttributes(), "    "), new String[]{"NAME", 
		"VISUAL_ATTRIBUTE_TYPE", 
		"SUBCLASS_INFORMATION", 
		"COMMENTS", 
		"FOREGROUND_COLOR",
		"BACKGROUND_COLOR",
		"FILL_PATTERN",
		"FONT_NAME", 
		"FONT_SIZE", 
		"FONT_WEIGHT", 
		"FONT_STYLE", 
		"FONT_SPACING"});
		printPropsList(workbook.createSheet("Windows"), printWindows(fmb.getWindows(), "    "), new String[]{"NAME", 
		"SUBCLASS_INFORMATION", 
		"COMMENTS", 
		"HELP_BOOK_TOPIC",
		"TITLE",	
		"PRIMARY_CANVAS",
		"HORIZONTAL_TOOLBAR_CANVAS", 
		"VERTICAL_TOOLBAR_CANVAS", 
		"WINDOW_STYLE", 
		"MODAL", 
		"HIDE_ON_EXIT",
		"CLOSE_ALLOWED", 
		"MOVE_ALLOWED",
		"RESIZE_ALLOWED", 
		"MAXIMIZE_ALLOWED", 
		"MINIMIZE_ALLOWED", 
		"MINIMIZED_TITLE", 
		"ICON_FILENAME",
		"INHERIT_MENU", 
		"X_POSITION", 
		"Y_POSITION", 
		"WIDTH", 
		"HEIGHT",
		"BEVEL", 
		"SHOW_HORIZONTAL_SCROLL_BAR",
		"SHOW_VERTICAL_SCROLL_BAR", 
		"VISUAL_ATTRIBUTE_GROUP", 
		"FOREGROUND_COLOR",
		"BACKGROUND_COLOR",
		"FILL_PATTERN",
		"FONT_NAME", 
		"FONT_SIZE", 
		"FONT_WEIGHT", 
		"FONT_STYLE", 
		"FONT_SPACING",
		"DIRECTION"});	
	}
		
	try {
		String FILE_NAME = fmb_name+".xlsx";
		FileOutputStream outputStream = new FileOutputStream(FILE_NAME);
		workbook.write(outputStream);
		workbook.close();
	} catch (FileNotFoundException e) {
		e.printStackTrace();
	} catch (IOException e) {
		e.printStackTrace();
	}    
	Jdapi.shutdown();
	}
}