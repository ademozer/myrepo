import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Test2 {

   public static void main(String[] args)throws Exception  {
     // String REGEX = "\\b"+args[1]+"\\b";      
	  String file_name = args[0];
	  XWPFDocument docx = new XWPFDocument(new FileInputStream(file_name));
      
	  String REGEX = "\\b";
	  int cnt = 0;
	  for(String argv : args) {
		  if(cnt>0) {
			  REGEX += argv;
			  if(cnt < (args.length-1)) {
				  REGEX += " ";
			  }
		  }
		  cnt++;
	  }
	  REGEX += "\\b";
	  System.out.println("regexp="+REGEX);
      //using XWPFWordExtractor Class
      XWPFWordExtractor we = new XWPFWordExtractor(docx);
	  
      //System.out.println(we.getText());
	  
	  Pattern p = Pattern.compile(REGEX);
	  String INPUT = we.getText();
	  
      Matcher m = p.matcher(INPUT);   // get a matcher object
      int count = 0;

      while(m.find()) {
         count++;
         System.out.println("Match number "+count);
         System.out.println("start(): "+m.start());
         System.out.println("end(): "+m.end());
      }
   }
}