import java.io.File;
import java.io.FileInputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;

public class SearchInPdf {
    public static void searchTextInFile(String fileName, String searchText) throws Exception {       
      
		Pattern p = Pattern.compile(searchText.toLowerCase());
		
		PdfReader pdfReader = new PdfReader(fileName);
		
		int pageCount = pdfReader.getNumberOfPages();
		int firstfindedPageNumber = 0;
		String PAGE_TEXT="";
		for (int pageNumber = 1; pageNumber < pageCount + 1; pageNumber++) {			
		    PAGE_TEXT = PdfTextExtractor.getTextFromPage(pdfReader, pageNumber);            			
			Matcher m = p.matcher(PAGE_TEXT.toLowerCase());			
			if(m.find()) {
				firstfindedPageNumber = pageNumber;
                break;				 
			}									
		}
		pdfReader.close();
   	
		if(firstfindedPageNumber>0) {			 
			System.out.println("<tr><td>"+fileName+"</td><td>"+pageCount+"</td><td>"+firstfindedPageNumber+"</td><td>"+PAGE_TEXT+"</td></tr>");
		}
    }
   
    public static void listFilesForFolder(File folder, String searchText) throws Exception {
        String temp = "";
        for (File fileEntry : folder.listFiles()) {
			if (fileEntry.isDirectory()) {
			// System.out.println("Reading files under the folder "+folder.getAbsolutePath());
				listFilesForFolder(fileEntry, searchText);
			} else {
				if (fileEntry.isFile()) {
					temp = fileEntry.getName();
					if ((temp.substring(temp.lastIndexOf('.') + 1, temp.length()).toLowerCase()).equals("pdf")) {
						//System.out.println("File= " + folder.getAbsolutePath()+ "\\" + fileEntry.getName());
						try{
							temp = folder.getAbsolutePath()+ "\\" +temp;
						    searchTextInFile(temp, searchText); 
						} catch(Exception e) {
							//System.out.println("<tr><td>"+temp+"</td><td>0</td><td>"+e.getMessage()+"</td></tr>");
						}
					}
			    }
			}
		}   
    }
  
    public static void main(String[] args)throws Exception  {
       
	    String file_name = args[0];
	       
	    String REGEX = "\\b";
	    int cnt = 0;
	    for(String argv : args) {
		    if(cnt>0) {
			    REGEX += argv;
			    if(cnt < (args.length-1)) {
				    REGEX += " ";
			    }
		    }
		    cnt++;
	    }
	    REGEX += "\\b";
	        
	    File folder = new File(file_name);
	    listFilesForFolder(folder, REGEX);       
    }
}