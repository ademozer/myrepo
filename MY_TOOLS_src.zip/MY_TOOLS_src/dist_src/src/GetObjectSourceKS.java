import java.io.*;
import java.util.Map;
import java.util.HashMap;
import java.nio.charset.*;
import oracle.jdbc.OracleCallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Clob;
public class GetObjectSourceKS {
    public static void main(String args[]) {  
		Map<String,Object> result = new HashMap<String, Object>();
		StringBuilder sb = new StringBuilder();
		Connection mConn = null;
        OracleCallableStatement mCst;
		try {	
			String conn_str = args[0];
		    String user = args[1];
		    String pass = args[2];
		    Class.forName("oracle.jdbc.driver.OracleDriver");
			String script = "BEGIN ? := DBMS_METADATA.GET_DDL(?,?,'EPROVIZYON') ||CHR(10)|| '/'; END;";
			mConn = DriverManager.getConnection(conn_str, user, pass);
			if(mConn == null || mConn.isClosed()) {
				throw new Exception("Bağlantı Kurulamadı");
			}
			mCst = (OracleCallableStatement) mConn.prepareCall(script);
			mCst.registerOutParameter(1, java.sql.Types.CLOB);
			mCst.setString(2, args[4]); //OBJECT_TYPE
			mCst.setString(3, args[3]); //OBJECT_NAME
			mCst.execute();
		
			Clob source = mCst.getClob(1);
			sb.append(source.getSubString(1,(int) source.length()));
			mCst.close();
			
			//System.out.println(status);
		} catch(Exception e) {
			e.printStackTrace();
			//result.put("result","ERR:"+e.getMessage());
			sb.append("ERR:"+e.getMessage());
		} finally {
			//sb.append(result.get("result"));
			System.out.println(sb.toString());		
           	try{
				if(mConn != null) {
				   mConn.close();
				}
			} catch(Exception e2){
				sb.append("ERR2:"+e2.getMessage());
			}		
		}
	}

}