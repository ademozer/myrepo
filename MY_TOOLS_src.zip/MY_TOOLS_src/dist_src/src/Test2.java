import java.io.*;
import java.util.Map;
import java.util.HashMap;
import java.lang.reflect.*;
import java.nio.charset.*;
import oracle.jdbc.OracleCallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import oracle.jdbc.OracleTypes;
// Extend HttpServlet class
public class Test2 {
  
public static void main(String args[]) {
   String className = "PlsqlCommand";
   if(args.length == 1) {
      className = args[0]; 
   }
   if(args.length == 2) {
      className = args[1]; 
   }
   String step = "0";
   if(!"NULL".equals(className)) {
	   Map<String,Object> result = new HashMap<String, Object>();
        Connection mConn;
        OracleCallableStatement mCst;
	   try {	 
		    Class.forName("oracle.jdbc.driver.OracleDriver");		
			step = "1";
			mConn = DriverManager.getConnection("jdbc:oracle:thin:@opusuat-scan.allianz-tr.local:1521/OPUSDEV", "ademo", "snow2017d");
			if(mConn == null || mConn.isClosed()) {
				throw new Exception("Bağlantı Kurulamadı");
			}
			step = "2";
			mCst = (OracleCallableStatement) mConn.prepareCall("BEGIN ? := CUSTOMER.ALZ_TR_CARE_UTILS.get_is_aztr_care(?); END;");
			step = "3";
			mCst.registerOutParameter(1, OracleTypes.NUMBER);
			//mCst.setLong(2,Long.parseLong("288981752"));
			mCst.setLong(2,Long.parseLong("301975932"));
			
			mCst.execute();
			step = "5";
			String mes1 = ""+mCst.getInt(1);
		    System.out.println("Sonuc="+mes1);
	   } catch(Exception e) {
		   e.printStackTrace();
		   result.put("result","ERR:"+e.getMessage()+"step="+step);
	   } finally {
		   System.out.println("result="+result.get("result"));		   
	   }
   }
  
   }
  
}