import oracle.forms.jdapi.*;
import java.io.*;
public class FmbSer
{
 public static void printLibraries(JdapiIterator it) {
	while (it.hasNext())
	{
		AttachedLibrary lib = (AttachedLibrary)it.next();
		System.out.println(lib.getName());
	}
	 
 }
 public static void printTriggers(JdapiIterator it) {
	while (it.hasNext())
	{
		Trigger trg = (Trigger)it.next();
		System.out.println(trg.getName());
		System.out.println("{");
		System.out.println(trg.getTriggerText());
		System.out.println("}");
	}
	 
 }
 public static void printProgramUnits(JdapiIterator it) {
	while (it.hasNext())
	{
		ProgramUnit pu = (ProgramUnit)it.next();
		System.out.println(pu.getName());
		System.out.println("{");
		System.out.println(pu.getProgramUnitText());
		System.out.println("}");
	}
	 
 }
 public static void printBlocks(JdapiIterator it) {
	while (it.hasNext())
	{
		Block bl = (Block)it.next();
		System.out.println(bl.getName());
	    System.out.println("[BlockTriggers]{");
		printTriggers(bl.getTriggers());
		System.out.println("}");
		System.out.println("[BlockItems]{");
		printItems(bl.getItems());
		System.out.println("}");
	}
	 
 }
 
 public static void printItems(JdapiIterator it) {
	while (it.hasNext())
	{
		Item item = (Item)it.next();
		System.out.println(item.getName());
		System.out.println("{");
		printTriggers(item.getTriggers());
		System.out.println("}");
	}
	 
 }
 
 public static void printCanvases(JdapiIterator it) {
	while (it.hasNext())
	{
		Canvas cnv = (Canvas)it.next();
		System.out.println(cnv.getName());
	}
  }
  public static void printWindows(JdapiIterator it) {
	while (it.hasNext())
	{
		Window win = (Window)it.next();
		System.out.println(win.getName());
	}
  }
  public static void printParameters(JdapiIterator it) {
	while (it.hasNext())
	{
		ModuleParameter prm = (ModuleParameter)it.next();
		System.out.println(prm.getName());
	}
  }
 public static void printLovs(JdapiIterator it) {
	while (it.hasNext())
	{
		LOV lv  = (LOV)it.next();
		System.out.println(lv.getName());
		System.out.println("{");
		printLovColMaps(lv.getLOVColumnMappings());
		System.out.println("}");
	}
  }
  
   
  
  public static void printLovColMaps(JdapiIterator it) {
	while (it.hasNext())
	{
		LOVColumnMapping lcm  = (LOVColumnMapping)it.next();
		System.out.println(lcm.getName()+":"+lcm.getReturnItem());
	}
  }
 
 public static void printRecordGroups(JdapiIterator it) {
	while (it.hasNext())
	{
		RecordGroup rg  = (RecordGroup)it.next();
		System.out.println(rg.getName());
		System.out.println("{");
		System.out.println(rg.getRecordGroupQuery());
		System.out.println("}");
	}
  }
 public static void main(String[] args)
{
    if(args.length !=2 ) {
		System.out.println("Kullanım : java FmbDetail <*.FMB> <*.TYP>"); 
		System.exit(0);
	} 
	String fmb_name = args[0];
	String type_name = args[1];
	
	try {
		 JdapiModule.openModule(fmb_name);
	     JdapiIterator fmbs = Jdapi.getModules();
	     FormModule fmb = (FormModule)fmbs.next();
		 FileOutputStream fileOut = new FileOutputStream(fmb_name+".ser");
		 ObjectOutputStream out = new ObjectOutputStream(fileOut);
		 JdapiIterator it = fmb.getBlocks();
		 if(it.hasNext()) {
			 Block bl = (Block) it.next();
			 out.writeObject(bl.getPersistentClientInfoObject());
		 }
		 out.close();
		 fileOut.close();
		 System.out.printf("Serialized data is saved in "+fmb_name+".ser");
		 Jdapi.shutdown();
	 }catch(Exception e) {
         e.printStackTrace();
     }
	/*if("LIB".equals(type_name)) {
		printLibraries(fmb.getAttachedLibraries());
	}
	
	if("TRG".equals(type_name)) {
		printTriggers(fmb.getTriggers());
	}
	if("BLK".equals(type_name)) {
		printBlocks(fmb.getBlocks());
	}
	if("CNV".equals(type_name)) {
		printCanvases(fmb.getCanvases());
	}
	if("LOV".equals(type_name)) {
		printLovs(fmb.getLOVs());
	}
	if("PRM".equals(type_name)) {
		printParameters(fmb.getModuleParameters());
	}
	if("PRU".equals(type_name)) {
		printProgramUnits(fmb.getProgramUnits());
	}
	if("RCG".equals(type_name)) {
		printRecordGroups(fmb.getRecordGroups());
	}
	if("WIN".equals(type_name)) {
		printWindows(fmb.getWindows());
	}*/
	
	}
}