import java.util.Map;
import java.util.HashMap;

public class TestCommand implements Command {
  Map<String, Object> mParameters;
  public TestCommand(Map<String, Object> parameters) {
     mParameters = parameters;
  }
  
  public Map<String, Object> execute() {
     Map<String, Object> resMap = new HashMap<String, Object>();
	 try {
		String paramVals = "";
		String result = "";
		for(Object paramVal : (Object[]) mParameters.get("testParam")) {
			paramVals += (String) paramVal;
		}
		if("controllers".equals(paramVals.trim())) {
			result += "function test(){ ";
			result += "    alert(\"Merhaba D�nya\");";
			result += "}";
		} 
		if("controllers2".equals(paramVals.trim())) {
			result +="var controllers = { ";
	        result +="           \"sayHello\" : function() {	";             
			result +="			       alert(\"search action table_name= \" + page.model.table);";
            result +="             }";
			result +="		  };";
		} 
		
	    resMap.put("result", result);
	 } catch(Exception e) {
	    resMap.put("result", "TestCommand Komutu �al��t�r�l�rken hata al�nd�");
		resMap.put("errorMessage", e.getMessage());
	 }  
     return resMap;	 
  }
}