import java.util.*;
public class Interfaces {
   private Map<String, ArrayList<Map<String, Object>>> INTERFACES;
   
   public void setINTERFACES(Map<String, ArrayList<Map<String, Object>>> p_Interfaces) {
	   this.INTERFACES = p_Interfaces;
   }
   
   public Map<String, ArrayList<Map<String, Object>>> getINTERFACES() {
	   return this.INTERFACES;
   }
}