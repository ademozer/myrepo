import java.util.Map;
import java.util.HashMap;
import oracle.jdbc.OracleCallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;

public class PlsqlCommand implements Command {
  private Map<String, Object> mParameters;
  private Connection mConn;
  private OracleCallableStatement mCst;
  public PlsqlCommand(Map<String, Object> parameters) {
     mParameters = parameters;
  }
  
  public Map<String, Object> execute() {
     Map<String, Object> resMap = new HashMap<String, Object>();
	 String step = "0";
	 try {
		/*
		   TO DO : 
		   mConn = DBUtils.getConnection();
		   mCst = mConn.prepareCall(programUnit);
		   mcst.close()
		   mConn.close();
		   
		*/
		step = "1";
		/*String conn_str = "jdbc:oracle:thin:@itdbdbadm01.yksigorta.com.tr:1521/OPUSTEST";
		String user="ADEMO";
		String pass="snow2017d";*/
		String conn_str = getParameter("conn_str");
		String user=getParameter("user");
		String pass=getParameter("pass");
		Class.forName("oracle.jdbc.driver.OracleDriver");
		//Object[] scriptArray = (Object[]) mParameters.get("script");
		//String script = (String) scriptArray[0];
		String script = getParameter("script");
		mConn = DriverManager.getConnection(conn_str, user, pass);
		if(mConn == null || mConn.isClosed()) {
			throw new Exception("Ba�lant� Kurulamad�");
		}
		step = "2";
	    mCst = (OracleCallableStatement) mConn.prepareCall(script);
		step = "3";
		mCst.registerOutParameter(1, 12);
		mCst.registerOutParameter(2, 12);
		step = "4.script="+script;
		mCst.execute();
		step = "5";
		String mes1 = mCst.getString(1);
		String mes2 = mCst.getString(2);
		step = "6";
		String mes = "" + (mes1 != null ? mes1 : "") + (mes2 != null ? mes2 : "");
	    resMap.put("result", mes);
		resMap.put("status","OK");
	 } catch(Exception e) {
	    resMap.put("result", "PlsqlCommand Komutu �al��t�r�l�rken hata al�nd�. Adim = "+step);
		resMap.put("errorMessage", e.getMessage());
		resMap.put("status","ERR");
	 }  finally {
		 try{
		    mCst.close();
		    mConn.close();
		 } catch(Exception e) {
		    resMap.put("errorMessage2", e.getMessage());
		 }
	 }
     return resMap;	 
  }
  
  private String getParameter(String paramName) {
	  Object[] params = (Object[]) mParameters.get(paramName);
      String paramValue = (String) params[0];
	  return paramValue;  
  }
}