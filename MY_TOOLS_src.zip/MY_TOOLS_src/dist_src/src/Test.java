import java.io.*;
import java.util.Map;
import java.util.HashMap;
import java.lang.reflect.*;
import java.nio.charset.*;
// Extend HttpServlet class
public class Test {
  
public static void main(String args[]) {
   String className = "PlsqlCommand";
   if(args.length == 1) {
      className = args[0]; 
   }
   if(args.length == 2) {
      className = args[1]; 
   }
 
   if(!"NULL".equals(className)) {
	   Map<String,Object> result = new HashMap<String, Object>();
	   try {
	      //Class clazz = Class.forName(className);
		  //Constructor constructors[] = clazz.getConstructors();
		  //Command cmd;
		  Map<String, Object> param = new HashMap<String, Object>();
		  
		  //param.put("script",new Object[]{"BEGIN ?:= CUSTOMER.ALZ_TPA_CORE_UTILS.f_get_company_shortname('555'); EXCEPTION WHEN OTHERS THEN ?:=SUBSTR(SQLERRM,1,300); END;"});
         // param.put("FMB_NAME",new String[]{"TEST.FMB"});		  
		  //cmd = (Command) constructors[0].newInstance(param);		
		  param.put("script",new Object[]{"BEGIN ? :=  CUSTOMER.ALZ_TR_CARE_UTILS.get_is_aztr_care(?); END; "});
   		  //param.put("sourceString",new Object[]{"t07k41d81"});
		 // param.put("hashAlgorithm",new Object[]{"SHA-256"});
		  param.put("conn_str", new Object[] {"jdbc:oracle:thin:@opusuat-scan.allianz-tr.local:1521/OPUSDEV"});
	      param.put("user",new Object[]{"ademo"});
          //Command cmd = new HashCommand(param);
          param.put("pass",new Object[]{"snow2017d"});  		  
		  result = cmd.execute();
		 
	   } catch(Exception e) {
		   e.printStackTrace();
		   result.put("result","ERR:"+e.getMessage());
	   } finally {
		   System.out.println("result="+result.get("result"));		   
	   }
   }
  
   }
  
}