import java.io.InputStream;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.*;
import java.util.*;
 
public class TestYaml {
    
    public static void main(String[] args) {
        
        Interfaces config = null;
        
        Yaml yaml = new Yaml(new Constructor(Interfaces.class));
        try {
			InputStream in = ClassLoader.getSystemResourceAsStream(args[0]); 
            config = (Interfaces) yaml.load(in);
        } catch(Exception ex) {
            ex.printStackTrace();
        }
        
       // Map<String, Object> obj =  config.getInterfaces().get("INTERFACES");
        System.out.println("map="+config.getINTERFACES());
    }
}
 