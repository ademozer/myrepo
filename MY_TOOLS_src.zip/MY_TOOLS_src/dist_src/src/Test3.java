import java.util.*;
import java.io.*;
public class Test {
   public static void main(String args[]) {
        /*Variable v1 = new Variable("Adı", "STRING", "Adem");
		Parameter p1 = new Parameter("pAdı","STRING","Ali","IN");
		print(v1);
		print(p1);*/
		String data = loadFile(args[0]);
        print(new Variable("DATA","STRING", data));		
   }
   private static void print(Variable var) {
      System.out.println(var.get());
   }
   
  private static String loadFile(String fileName)  {
  try {
    FileInputStream fis=new FileInputStream(new File(fileName));
    String data = "";
	int content;
	int onuc = 0;
	while ((content = fis.read()) != -1) {
		// convert to char and display it
		//System.out.print((char) content+ ":"+content);
		//System.out.print(content);
		if(content == 13) {
			onuc = 1;//data += "[nl]";
			//continue;
		} else {
			if((content == 10) && (onuc == 1)) {
				data += "[nl]";
			} else {				
				data += (char) content;
			}
			onuc = 0;		    
		}
	}
	fis.close();
	return data;
  }
  catch (Exception ex) {
    // Variable var = new Variable(this.class.getName(), "LOG", ex.getMessage());
	 print(new Variable("HATA","STRING",ex.getMessage()));
   // Logger.getLogger(YamlLoader.class.getName()).log(Level.SEVERE,null,ex);
    return null;
  }
 }
}