import java.util.Map;
import java.io.Serializable;

interface Command extends Serializable{

   Map<String, Object> execute();

}