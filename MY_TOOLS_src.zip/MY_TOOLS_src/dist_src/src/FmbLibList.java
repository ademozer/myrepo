import oracle.forms.jdapi.*;
public class FmbLibList
{
 public static void main(String[] args)
{
    if(args.length !=1 ) {
		System.out.println("Kullanım : java FrmLibList <*.FMB>"); 
		System.exit(0);
	} 
	String fmb_name = args[0];
	JdapiModule.openModule(fmb_name);
	//JdapiModule.openModule("c:\\SAJDI.FMB");
	

	JdapiIterator fmbs = Jdapi.getModules();
	FormModule fmb = (FormModule)fmbs.next();
	JdapiIterator libs = fmb.getAttachedLibraries();



	while (libs.hasNext())
	{

	AttachedLibrary lib = (AttachedLibrary)libs.next();
	System.out.println(lib.getLibraryLocation());
	System.out.println(lib.getLibrarySource());
	System.out.println(lib.getName());


	}
	//fmb.save("c:\\ammar.fmb");

	// finally, free API resources
	Jdapi.shutdown();
	}
}