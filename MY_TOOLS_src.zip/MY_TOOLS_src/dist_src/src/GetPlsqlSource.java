import java.io.*;
import java.util.Map;
import java.util.HashMap;
import java.nio.charset.*;
public class GetPlsqlSource {
    public static void main(String args[]) {  
		Map<String,Object> result = new HashMap<String, Object>();
		StringBuilder sb = new StringBuilder();
		try {
			Command cmd;
			Map<String, Object> param = new HashMap<String, Object>();
			param.put("conn_str", new Object[]{args[0]});
			param.put("user", new Object[]{args[1]});
			param.put("pass", new Object[]{args[2]});
			String type = args[4].replace("_"," ");
			String line_script = "DECLARE v_line   NUMBER:=0; CURSOR c1 IS SELECT MAX(LINE) FROM ALL_SOURCE WHERE NAME='"+args[3]+"' AND TYPE='"+type+"';";
			line_script += "BEGIN OPEN c1;  FETCH c1 INTO v_line;  CLOSE c1;  ?:= v_line;";
			line_script += " EXCEPTION WHEN OTHERS THEN  ?:= dbms_utility.format_error_stack||dbms_utility.format_error_backtrace; END;";
			param.put("script",new Object[]{line_script});
			cmd = new PlsqlCommand(param);	  
			result = cmd.execute();
			int line_count = Integer.parseInt((String) result.get("result"));
			//System.out.println(line_count);
			int line_number = 0;
			while(line_number<line_count) {
			   	param.put("script",new Object[]{getScript(args[3],type, line_number)});
				cmd = new PlsqlCommand(param);
				result = cmd.execute();
				String res = (String) result.get("result");
				String status = res.substring(res.indexOf("<status>")+8,res.indexOf("</status>"));
				if("OK".equals(status)) {
					String line_num_str = res.substring(res.indexOf("<line_number>")+13,res.indexOf("</line_number>"));
					line_number = Integer.parseInt(line_num_str);
					String source = res.substring(res.indexOf("<source>")+8,res.indexOf("</source>"));
					//System.out.println("line_number="+line_number+" line_count="+line_count);					
					sb.append(source);
				} else {
					String message = res.substring(res.indexOf("<message>")+9,res.indexOf("</message>"));
					throw new Exception(message);
				}	
			}
			
			//System.out.println(status);
		} catch(Exception e) {
			e.printStackTrace();
			//result.put("result","ERR:"+e.getMessage());
			sb.append("ERR:"+e.getMessage());
		} finally {
			//sb.append(result.get("result"));
			System.out.println(sb.toString());		   
		}
	}
	private static String getScript(String obj_name, String obj_type, int line_number) {
		String script = "DECLARE v_source VARCHAR2(32767); v_len    NUMBER:=0; v_line   NUMBER:=0;";
		script += " CURSOR c1(p_line IN NUMBER) IS SELECT LINE,TEXT FROM ALL_SOURCE WHERE NAME='"+obj_name+"' AND TYPE='"+obj_type+"' AND LINE > NVL(p_line,0) ORDER BY LINE;";
		script += " BEGIN FOR r1 IN c1("+line_number+") LOOP v_source := v_source || r1.TEXT; v_len := v_len + LENGTH(r1.TEXT); v_line := r1.LINE;"; 
		script += " IF v_len>20000 THEN EXIT; END IF; END LOOP;";
		script += " v_source := '<status>OK</status><line_number>'||v_line||'</line_number><source>'||v_source||'</source>';";
		script += " ?:= v_source; ";
        script += " EXCEPTION WHEN OTHERS THEN  ?:= '<status>ERR</status><message>'||dbms_utility.format_error_stack||dbms_utility.format_error_backtrace||'</message>'; END;";		
		return script;
	}
}