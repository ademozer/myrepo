import oracle.forms.jdapi.*;
import java.util.*;
public class FmbCommand implements Command {
 private Map<String, Object> mParameters; 
 public FmbCommand(Map<String, Object> parameters) {
    mParameters = parameters;	 
 } 	
 public static void printLibraries(JdapiIterator it) {
	while (it.hasNext())
	{
		AttachedLibrary lib = (AttachedLibrary)it.next();
		System.out.println(lib.getName());
	}
	 
 }
 public static void printTriggers(JdapiIterator it) {
	while (it.hasNext())
	{
		Trigger trg = (Trigger)it.next();
		System.out.println(trg.getName());
		System.out.println("{");
		System.out.println(trg.getTriggerText());
		System.out.println("}");
	}
	 
 }
 
 public String getTriggerText(JdapiIterator it) {
	String triggerText = ""; 
	while (it.hasNext())
	{
		Trigger trg = (Trigger)it.next();
		triggerText += trg.getTriggerText();
	}
	return triggerText; 
 }
 public static void printProgramUnits(JdapiIterator it) {
	while (it.hasNext())
	{
		ProgramUnit pu = (ProgramUnit)it.next();
		System.out.println(pu.getName());
		System.out.println("{");
		System.out.println(pu.getProgramUnitText());
		System.out.println("}");
	}
	 
 }
 public static void printBlocks(JdapiIterator it) {
	
	while (it.hasNext())
	{
		Block bl = (Block)it.next();
		
		System.out.println(bl.getName());
	    System.out.println("[BlockTriggers]{");
		printTriggers(bl.getTriggers());
		System.out.println("}");
		System.out.println("[BlockItems]{");
		printItems(bl.getItems());
		System.out.println("}");
	}
	
 }
 
 public List<Object> getBlocks(JdapiIterator it) {
	
	List<Object> blockList = new ArrayList<Object>();
	
	
	while (it.hasNext())
	{
		Block bl = (Block)it.next();
		Map<String, Object> blockMap = new HashMap<String, Object>();
		String formStr = "<form id=\""+bl.getName()+"\" onsubmit=\"return false;\">	";
		
		formStr += getItems(bl.getItems());			
	
		formStr += "</form>";
		
		blockMap.put("FORM",formStr);
		blockMap.put("TRIGGER",getItemsTriggers(bl.getItems()).replace(":RESULT","?"));
		blockMap.put("SCRIPT", getScriptAction(bl.getItems()).replace("#params",getParamArray(bl.getItems())));
		
	   /* System.out.println("[BlockTriggers]{");
		printTriggers(bl.getTriggers());
		System.out.println("}");
		//System.out.println("[BlockItems]{");
		printItems(bl.getItems());
		System.out.println("}");*/
		blockList.add(blockMap);
	}
	return blockList; 
 }
 
 public static void printItems(JdapiIterator it) {
	while (it.hasNext())
	{
		Item item = (Item)it.next();
		System.out.println(item.getName());
		System.out.println("{");
		printTriggers(item.getTriggers());
		System.out.println("}");
	}
	 
 }
 
 public String getItems(JdapiIterator it) {
	String itemStr = "";
	while (it.hasNext())
	{
		
		Item item = (Item)it.next();
		String item_name = item.getName();
		 
		int item_type = item.getItemType();
		if(item_type == 8 && !"RESULT".equals(item_name)) {
		    itemStr += "<input type=\"text\" id=\""+item_name+"\" name=\""+item_name +"\"/><!--item.type.id="+item_type+"-->";
        }
        if(item_type == 6) {
			itemStr += "<button id=\""+item_name+"\" onclick=\""+item.getComment()+"\">"+item.getLabel()+"</button><!--item.type.id="+item_type+"-->";
		}  		
		
		//printTriggers(item.getTriggers());
		//System.out.println("}");
	}
	return itemStr;
	 
 }
 
 public String getItemsTriggers(JdapiIterator it) {
	String itemStr = "";
	while (it.hasNext())
	{
		
		Item item = (Item)it.next();
		String item_name = item.getName();
		 
		int item_type = item.getItemType();
		
        if(item_type == 6) {
			itemStr += "<script id=\""+item_name+".when_button_pressed\" type=\"plsql\">";
			itemStr += getTriggerText(item.getTriggers());
			itemStr += "</script>";
		}  		
		
		//printTriggers(item.getTriggers());
		//System.out.println("}");
	}
	return itemStr;
	 
 }
 
 public String getScriptAction(JdapiIterator it) {
	String itemStr = "";
	
	while (it.hasNext())
	{
		 //$("response").innerHTML = runScript("BTN_SAVE.when_button_pressed",[{"name" : "p_company_code","type" : "VARCHAR2","value" : document.getElementById("TI_COMPANY_CODE").value}]);
		Item item = (Item)it.next();
		String item_name = item.getName();
		 
		int item_type = item.getItemType();
		
        if(item_type == 6) {
			itemStr += "<script>";
			itemStr +=  "function "+item.getComment()+"{";
			itemStr +=  "$(\"response\").innerHTML = runScript(\""+item_name+".when_button_pressed"+"\",[#params])";
			itemStr += "}";
			itemStr += "</script>";
		}  		
		
		//printTriggers(item.getTriggers());
		//System.out.println("}");
	}
	return itemStr;
	 
 }
 
 public String getParamArray(JdapiIterator it) {
	String itemStr = "";
	
	while (it.hasNext())
	{
		 //$("response").innerHTML = runScript("BTN_SAVE.when_button_pressed",[{"name" : "p_company_code","type" : "VARCHAR2","value" : document.getElementById("TI_COMPANY_CODE").value}]);
		Item item = (Item)it.next();
		String item_name = item.getName();
		 
		int item_type = item.getItemType();
		
        if(item_type == 8 && !"RESULT".equals(item_name)) {
			itemStr += "{\"name\" : \""+item_name.replace("TI_","p_")+"\",";
			itemStr +=  "\"type\" : \"VARCHAR2\",";			
			itemStr +=  "\"value\" : $(\""+item_name+"\").value)},";
		}  		
		
		//printTriggers(item.getTriggers());
		//System.out.println("}");
	}
	itemStr = itemStr.substring(1,itemStr.length()-1);
	return itemStr;
	 
 }
 
 public static void printCanvases(JdapiIterator it) {
	while (it.hasNext())
	{
		Canvas cnv = (Canvas)it.next();
		System.out.println(cnv.getName());
	}
  }
  public static void printWindows(JdapiIterator it) {
	while (it.hasNext())
	{
		Window win = (Window)it.next();
		System.out.println(win.getName());
	}
  }
  public static void printParameters(JdapiIterator it) {
	while (it.hasNext())
	{
		ModuleParameter prm = (ModuleParameter)it.next();
		System.out.println(prm.getName());
	}
  }
 public static void printLovs(JdapiIterator it) {
	while (it.hasNext())
	{
		LOV lv  = (LOV)it.next();
		System.out.println(lv.getName());
		System.out.println("{");
		printLovColMaps(lv.getLOVColumnMappings());
		System.out.println("}");
	}
  }
  
   
  
  public static void printLovColMaps(JdapiIterator it) {
	while (it.hasNext())
	{
		LOVColumnMapping lcm  = (LOVColumnMapping)it.next();
		System.out.println(lcm.getName()+":"+lcm.getReturnItem());
	}
  }
 
 public static void printRecordGroups(JdapiIterator it) {
	while (it.hasNext())
	{
		RecordGroup rg  = (RecordGroup)it.next();
		System.out.println(rg.getName());
		System.out.println("{");
		System.out.println(rg.getRecordGroupQuery());
		System.out.println("}");
	}
  }
 
public String getHTML(List<Object> objectList) {
	String template = "<!DOCTYPE html>"+
					  "<html>"+
					  "<title>FmbCommand</title>"+
					  "<meta http-equiv=\"Content-type\" content=\"text/html; charset=utf-8\">"+
					  "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"+
					  "<script src=\"resources/js/Ajax.js\"></script>"+
					  "<script src=\"resources/js/declare.js\"></script>"+
					  "</head>"+
					  "<body>"+
					  "		<div id=\"subcontent\">"+
					  "			{{FORM}}"+
					  "			<div id=\"result\">Sonuçlar</div>"+ 
					  "			<div id=\"response\"></div>"+
				      "			</div>"+
					  "	{{TRIGGER}}"+  
					  "	<script src=\"resources/js/pls_runner.js\"></script>"+
					  "	   {{SCRIPT}}"+
					  " 	</body> "+
					  "	</html>";
	
	  for(Object o : objectList)  {
		  Map<String, Object>  map = (Map<String, Object>) o;
		  template = template.replace("{{FORM}}", ""+map.get("FORM"));
		  template = template.replace("{{TRIGGER}}",""+map.get("TRIGGER"));
		  template = template.replace("{{SCRIPT}}", ""+map.get("SCRIPT"));		 
	  }
	  return template;
} 
 public Map<String, Object> execute() {
    
    Map<String, Object> resMap = new HashMap<String, Object>();
	String fmb_name = "";
	try {
		String fmbArray[] = (String[]) mParameters.get("FMB_NAME");
		if(fmbArray.length<1) {
			throw new Exception("FMB_NAME parametesi boş olamaz");
		}
		fmb_name = "../../resources/fmb/" + fmbArray[0];
		//String type_name = args[1];
		JdapiModule.openModule(fmb_name);
		JdapiIterator fmbs = Jdapi.getModules();
		FormModule fmb = (FormModule)fmbs.next();
	
		resMap.put("result", getHTML(getBlocks(fmb.getBlocks())));
		
		/*if("LIB".equals(type_name)) {
			printLibraries(fmb.getAttachedLibraries());
		}
		
		if("TRG".equals(type_name)) {
			printTriggers(fmb.getTriggers());
		}
		if("BLK".equals(type_name)) {
			printBlocks(fmb.getBlocks());
		}
		if("CNV".equals(type_name)) {
			printCanvases(fmb.getCanvases());
		}
		if("LOV".equals(type_name)) {
			printLovs(fmb.getLOVs());
		}
		if("PRM".equals(type_name)) {
			printParameters(fmb.getModuleParameters());
		}
		if("PRU".equals(type_name)) {
			printProgramUnits(fmb.getProgramUnits());
		}
		if("RCG".equals(type_name)) {
			printRecordGroups(fmb.getRecordGroups());
		}
		if("WIN".equals(type_name)) {
			printWindows(fmb.getWindows());
		}*/
		Jdapi.shutdown();
	} catch(Exception e) {
		e.printStackTrace();
		resMap.put("result","ERR:"+e.getMessage()+"fmb_name="+fmb_name);
		
	}
	return resMap;
	
	}
}