import oracle.forms.jdapi.*;
public class LibDetail
{

 public static void printProgramUnits(JdapiIterator it) {
	while (it.hasNext())
	{
		ProgramUnit pu = (ProgramUnit)it.next();
		System.out.println(pu.getName());
		System.out.println("{");
		System.out.println(pu.getProgramUnitText());
		System.out.println("}");
	}
	 
 }
 public static void main(String[] args)
{
    if(args.length !=1 ) {
		System.out.println("Kullanım : java LibDetail <*.PLL>"); 
		System.exit(0);
	} 
	String lib_name = args[0];
	JdapiModule.openModule(lib_name);
	JdapiIterator modules = Jdapi.getModules();
	PlsqlModule pll = (PlsqlModule)modules.next();
    printProgramUnits(pll.getProgramUnits());
	Jdapi.shutdown();
	}
}