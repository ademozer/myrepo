public class Parameter extends Variable {
   private String m_direction;
   
   public Parameter(String p_name, String p_type, String p_direction) {
      super(p_name, p_type);
	  this.m_direction = p_direction;
   }
   
   public Parameter(String p_name, String p_type, Object p_value, String p_direction) {
      super(p_name, p_type, p_value);
	  this.m_direction = p_direction;
   }
   
}