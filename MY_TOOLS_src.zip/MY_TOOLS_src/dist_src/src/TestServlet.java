// Import required java libraries
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.Map;
import java.util.HashMap;
import java.lang.reflect.*;
import java.lang.Object;
import java.util.Enumeration;
import weblogic.security.*;
import weblogic.security.services.Authentication.*;
import javax.security.auth.callback.*;
import javax.security.auth.*;

// Extend HttpServlet class
public class TestServlet extends HttpServlet {
 
  private String message;
  private Map<String, Object> rspMap;

  public void init() throws ServletException
  {
      // Do required initialization
      message = "Hello World";
  }

  public void doGet(HttpServletRequest request,
                    HttpServletResponse response)
            throws ServletException, IOException
  {
      doPost(request, response);
  }
  
  public void doPost(HttpServletRequest request,
                    HttpServletResponse response)
            throws ServletException, IOException
  {
      response.setContentType("text/html; charset=utf-8");
	  String commandName = request.getParameter("commandName");
	  if("LOGIN".equals(commandName)) {
		try {  
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			CallbackHandler handler = new SimpleCallbackHandler(username,
																password);
			Subject mySubject = weblogic.security.services.Authentication.login(handler);
			weblogic.servlet.security.ServletAuthentication.runAs(mySubject, request);			
			message = "authenticated";
		} catch(Exception e) {
			message = "unauth"+e.getMessage();
		}
		
	  }
	  else if("SESSION_INFO".equals(commandName)) {
		  message = "var SESSION_INFO = {\"SESSION_ID\" :\"" + request.getSession().getId() + "\"};"; 
	  } else {
		  rspMap = processCommand(commandName, getParamMap(request));
		  message = (String) rspMap.get("msg"); 
	  }
	  PrintWriter out = response.getWriter();
	  out.println(message);
  }
  
  
  private Map<String, Object> processCommand(String commandName, Map<String, Object> parameters) {
	  Map<String, Object> resMap = new HashMap<String, Object>();
	  try {
		   Class clazz = Class.forName(commandName);
		   Constructor constructors[] = clazz.getConstructors();			  
		   Command cmd = (Command) constructors[0].newInstance(parameters);		  
		   resMap = cmd.execute();
	  } catch(Exception e) {
		   e.printStackTrace();
		   resMap.put("result","Error"+e.getMessage());
	  } finally {
           resMap.put("msg", resMap.get("result"));		   
	  }		  	  
	  return resMap;
  }
  
  private Map<String, Object> getParamMap(HttpServletRequest req) {
	  Map<String, Object> resMap = new HashMap<String, Object>();
	  Enumeration<String> parameterNames = req.getParameterNames();
      while (parameterNames.hasMoreElements()) {
          String paramName = parameterNames.nextElement();                   
		  if(!"commandName".equals(paramName)) {
			  resMap.put(paramName, req.getParameterValues(paramName));
		  }
	  }
      return resMap;  
  }
}