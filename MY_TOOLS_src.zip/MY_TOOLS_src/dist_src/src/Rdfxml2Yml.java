import java.io.File;
import java.io.FileOutputStream;
import java.io.FilenameFilter;

import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import oracle.apps.xdo.rdfparser.RDFParser;

public class Rdfxml2Yml {
	private static StringBuilder sb;
	
	public static void printAttributes(String nodeName, String indent, NamedNodeMap attrs) {
		sb.append(indent + "- "+ nodeName+":\n");		
        for(int j = 0; j<attrs.getLength(); j++) {
        	Node node2 = attrs.item(j);
        	sb.append(indent + "    - "+ node2.getNodeName()+": "+node2.getNodeValue()+"\n");
        }
	}
	
	public static void printNodes(String nodeName, String indent, NodeList nodeList) throws Exception {
		if(nodeName != null) {
			sb.append(indent + nodeName+": \n");
		}
		for(int i=0; i<nodeList.getLength();i++) {
			Node node = nodeList.item(i);
			Short type = node.getNodeType();
			if(type == 1) {				
				String text = node.getTextContent();
				String name = node.getNodeName();				
				text = text.trim();
				text = text.replaceAll("\n", "\n"+indent+"            ");	
				if("xmlSettings".equals(name)) {			
					printAttributes("XML_Settings", indent + "    ", node.getAttributes());
					sb.append(indent + "        - Text: |\n");						
					sb.append(indent + "            "+text+"\n");
				}
				if("reportHtmlEscapes".equals(name)) {
					sb.append(indent + "    - Report_Html_Escapes:\n");	
					printNodes(null, indent + "    ", node.getChildNodes());
				}
				if("beforeReportHtmlEscape".equals(name)) {
					sb.append(indent + "    - Before_Report_Html_Escape: |\n");						
					sb.append(indent + "        "+text+"\n");
				}
				if("beforePageHtmlEscape".equals(name)) {
					sb.append(indent + "    - Before_Page_Html_Escape: |\n");						
					sb.append(indent + "        "+text+"\n");
				}
				if("afterPageHtmlEscape".equals(name)) {
					sb.append(indent + "    - After_Page_Html_Escape: |\n");						
					sb.append(indent + "        "+text+"\n");
				}
				if("beforeFormHtmlEscape".equals(name)) {
					sb.append(indent + "    - Before_Form_Html_Escape: |\n");						
					sb.append(indent + "        "+text+"\n");
				}
				if("pageNavigationHtmlEscape".equals(name)) {
					sb.append(indent + "    - Page_Navigation_Html_Escape: |\n");						
					sb.append(indent + "        "+text+"\n");
				}
				if("layout".equals(name)) {
					sb.append(indent + "    - Layout:\n");	
					printNodes(null, indent+"    ",node.getChildNodes());
				}
				if("rulers".equals(name)) {
					printAttributes("Rulers", indent + "    ", node.getAttributes());
				}
				if("section".equals(name)) {
					printAttributes("Section", indent + "    ", node.getAttributes());
					printNodes(null, indent + "    ", node.getChildNodes());
				}
				if("body".equals(name)) {
					printAttributes("Body", indent + "    ", node.getAttributes());
					printNodes(null, indent + "    ", node.getChildNodes());
				}
				if("location".equals(name)) {
					printAttributes("Location", indent + "    ", node.getAttributes());					
				}
				if("frame".equals(name)) {
					printAttributes("Frame", indent + "    ", node.getAttributes());
					printNodes(null, indent + "    ", node.getChildNodes());
				}				
				if("geometryInfo".equals(name)) {
					printAttributes("Geometry_Info", indent + "    ", node.getAttributes());				
				}
				if("visualSettings".equals(name)) {
					printAttributes("Visual_Settings", indent + "    ", node.getAttributes());				
				}
				if("text".equals(name)) {
					printAttributes("Text", indent + "    ", node.getAttributes());
					printNodes(null, indent + "    ", node.getChildNodes());
				}	
				if("textSettings".equals(name)) {
					printAttributes("Text_Settings", indent + "    ", node.getAttributes());				
				}
				if("textSegment".equals(name)) {
					printAttributes("Text_Segment", indent + "    ", node.getAttributes());
					printNodes(null, indent + "    ", node.getChildNodes());
				}	
				if("font".equals(name)) {
					printAttributes("Font", indent + "    ", node.getAttributes());						
				}
				if("string".equals(name)) {
					sb.append(indent + "    - String: |\n");						
					sb.append(indent + "        "+text+"\n");					
				}
				if("field".equals(name)) {
					printAttributes("Field", indent + "    ", node.getAttributes());
					printNodes(null, indent + "    ", node.getChildNodes());
				}
				if("generalLayout".equals(name)) {
					printAttributes("General_Layout", indent + "    ", node.getAttributes());
					printNodes(null, indent + "    ", node.getChildNodes());
				}	
				if("conditionalFormat".equals(name)) {					
					sb.append(indent + "    - Conditional_Format:\n");			
					printNodes(null, indent + "    ", node.getChildNodes());
				}	
				if("formatException".equals(name)) {
					printAttributes("Format_Exception", indent + "    ", node.getAttributes());				
					printNodes(null, indent + "    ", node.getChildNodes());
				}	
				if("cond".equals(name)) {
					printAttributes("Cond", indent + "    ", node.getAttributes());
				}
				if("advancedLayout".equals(name)) {
					printAttributes("Advanced_Layout", indent + "    ", node.getAttributes());					
				}	
				if("repeatingFrame".equals(name)) {
					printAttributes("Repeating_Frame", indent + "    ", node.getAttributes());
					printNodes(null, indent + "    ", node.getChildNodes());
				}	
				if("margin".equals(name)) {
					printAttributes("Margin", indent + "    ", node.getAttributes());
					printNodes(null, indent + "    ", node.getChildNodes());
				}
				if("webSource".equals(name)) {
					 sb.append(indent + "    - Web_Source:\n");
					 sb.append(indent + "            "+text+"\n");
				}
				if("reportPrivate".equals(name)) {					
					 printAttributes("Report_Private", indent + "    ", node.getAttributes());
				}
				if("reportWebSettings".equals(name)) {
					 sb.append(indent + "    - Report_Web_Settings:\n");
					 sb.append(indent + "            "+text+"\n");					
				}
				if("function".equals(name)) {
					 sb.append(indent + "    - Function:\n");
					 if(node.hasAttributes()) {
						 sb.append(indent + "        - Name: " + node.getAttributes().item(0).getNodeValue() + "\n");
						 if(node.getAttributes().getLength()>1) {
							 sb.append(indent + "        - Return_Type: " + node.getAttributes().item(1).getNodeValue() + "\n");
						 }
					 }						 
					 sb.append(indent + "        - Text_Source: |\n");				
					 sb.append(indent + "            "+text+"\n");					 
				}
				if("userParameter".equals(name)) {
					printAttributes("User_Parameter", indent + "    ", node.getAttributes());
				}
				if("dataSource".equals(name)) {
					sb.append(indent + "    - Data_Source:\n");
					 if(node.hasAttributes()) {
						 sb.append(indent + "        - Name: " + node.getAttributes().item(0).getNodeValue() + "\n");
						 printNodes(null, indent+"        ",node.getChildNodes());
					 }	
				}
				if("select".equals(name)) {					
					sb.append(indent + "- Query: \n" );
					if(node.getAttributes() != null && node.getAttributes().getLength()>0) {
						sb.append(indent + "    - Can_Parse: " + node.getAttributes().item(0).getNodeValue() + "\n");
					}
					sb.append(indent + "    - Text: |\n ");
					sb.append(indent + "        " + text + "\n");
				}
				if("displayInfo".equals(name)) {
					printAttributes("Display_Info",indent,node.getAttributes());
				}
				if("group".equals(name)) {
					sb.append(indent + "- Group:\n");
					if(node.hasAttributes()) {
						sb.append(indent + "    - Name: " + node.getAttributes().item(0).getNodeValue() + "\n");
						printNodes(null, indent+"    ",node.getChildNodes());
					}	
				}
				if("dataItem".equals(name)) {
					printAttributes("Data_Item",indent, node.getAttributes());
					printNodes(null, indent + "    ", node.getChildNodes());
				}
				if("dataDescriptor".equals(name)) {
					printAttributes("Data_Descriptor",indent, node.getAttributes());
				}
				if("dataItemPrivate".equals(name)) {
					printAttributes("Data_Item_Private",indent, node.getAttributes());
				}
				if("formula".equals(name)) {
					if("data".equals(node.getParentNode().getNodeName())) {
						printAttributes("Formula", indent+"    ", node.getAttributes());
						printNodes(null, indent + "        ", node.getChildNodes());
					} else {
						printAttributes("Formula", indent, node.getAttributes());
						printNodes(null, indent + "    ", node.getChildNodes());
					}
				}
				if("placeholder".equals(name)) {
					if("data".equals(node.getParentNode().getNodeName())) {
						printAttributes("Place_Holder", indent+"    ", node.getAttributes());
						printNodes(null, indent + "        ", node.getChildNodes());
					} else {
						printAttributes("Place_Holder", indent, node.getAttributes());
						printNodes(null, indent + "    ", node.getChildNodes());
					}
				}
				if("summary".equals(name)) {
					if("data".equals(node.getParentNode().getNodeName())) {
						printAttributes("Summary", indent+"    ", node.getAttributes());
						printNodes(null, indent + "        ", node.getChildNodes());
					} else {
						printAttributes("Summary", indent, node.getAttributes());
						printNodes(null, indent + "    ", node.getChildNodes());
					}
				}
				if("link".equals(name)) {
					printAttributes("Link",indent+"    ", node.getAttributes());
				}
								
			} 
		}
	}
	
	public static void rdfxml2yml(String fileName) throws Exception{
		 sb = new StringBuilder();		
		 RDFParser rdf = new RDFParser(fileName);	    
	     sb.append("Report:\n");
	     printAttributes("Atributes", "    ", rdf.ReportComponent().getAttributes());
		 printNodes(null,"    ",rdf.ReportComponent().getChildNodes());			    
		 printNodes("- Data_Components","    ",rdf.DataComponent().getChildNodes());
		 printNodes("- Program_Units","    ", rdf.ProgramUnitComponent().getChildNodes());		 
		 String fileNameYml = fileName.replaceAll("xml", "yml");
	     FileOutputStream fos = new FileOutputStream(new File(fileNameYml));		     
		 fos.write(sb.toString().getBytes());
		 fos.close();	    
	}
	
	
	public static void main(String[] args) throws Exception {					
		if(args.length != 1) {
			System.out.println("Kullanım : Rdfxml2Yml <rdfxmlfile>");
		} else {		
		    rdfxml2yml(args[0]);
		}
	}
	
	public static boolean isNotNull(String text) {
		return (text != null && !"null".equals(text) && !text.isEmpty() && !"".equals(text));
	}

}

