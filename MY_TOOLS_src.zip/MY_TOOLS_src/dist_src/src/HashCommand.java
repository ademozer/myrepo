import java.util.Map;
import java.util.HashMap;
import java.security.MessageDigest;
public class HashCommand implements Command {
  Map<String, Object> mParameters;
  public HashCommand(Map<String, Object> parameters) {
     mParameters = parameters;
  }
  
  public Map<String, Object> execute() {
     Map<String, Object> resMap = new HashMap<String, Object>();
	 try {
		String sourceString = "";
		String hashAlgorithm = "";
		String result = "";
		for(Object paramVal : (Object[]) mParameters.get("sourceString")) {
			sourceString += (String) paramVal;
		}
		
		for(Object paramVal : (Object[]) mParameters.get("hashAlgorithm")) {
			hashAlgorithm += (String) paramVal;
		}
		
		MessageDigest md = MessageDigest.getInstance(hashAlgorithm);
        md.update(sourceString.getBytes());
		byte byteData[] = md.digest();
		StringBuffer hexString = new StringBuffer();
    	for (int i=0;i<byteData.length;i++) {
    		String hex=Integer.toHexString(0xff & byteData[i]);
   	     	if(hex.length()==1) hexString.append('0');
   	     	hexString.append(hex);
    	}
		result = hexString.toString();
	    resMap.put("result", result);
	 } catch(Exception e) {
		e.printStackTrace();
	    resMap.put("result", "HashCommand Komutu �al��t�r�l�rken hata al�nd�");
		resMap.put("errorMessage", e.getMessage());
	 }  
     return resMap;	 
  }

   public static void main(String args[]) {
	   Map<String,Object> result = new HashMap<String, Object>();
	   try {	  
		  Map<String, Object> param = new HashMap<String, Object>();
		  param.put("sourceString",new Object[]{"Deneme123"});
		  param.put("hashAlgorithm",new Object[]{"SHA-256"});
          Command cmd = new HashCommand(param);		  
		  result = cmd.execute();
	   } catch(Exception e) {
		   e.printStackTrace();
		   result.put("result","ERR:"+e.getMessage());
	   } finally {
		   System.out.println("result="+result.get("result"));		   
	   }
   }
}
