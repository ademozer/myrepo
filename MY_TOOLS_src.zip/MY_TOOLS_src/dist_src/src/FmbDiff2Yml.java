import oracle.forms.jdapi.*;
import java.lang.StringBuilder;
import java.util.Map;
import java.util.Set;
import java.util.HashMap;
public class FmbDiff2Yml
{
 private static StringBuilder sb = new StringBuilder();
 private static StringBuilder sb2 = new StringBuilder();
 private static Map<Integer, String> item_type_map = new HashMap<Integer,String>();
 private static Map<Integer, String> just_type_map = new HashMap<Integer,String>();
 private static Map<Integer, String> data_type_map = new HashMap<Integer,String>();
 private static Map<Integer, String> data_lensem_map = new HashMap<Integer,String>();
 private static Map<Integer, String> calc_mod_map = new HashMap<Integer,String>();
 private static Map<Integer, String> calc_sum_map = new HashMap<Integer,String>();
 private static Map<Integer, String> phys_bevel_map = new HashMap<Integer,String>();
 private static Map<Integer, String> prompt_disp_map = new HashMap<Integer,String>();
 private static Map<Integer, String> prompt_just_map = new HashMap<Integer,String>();
 private static Map<Integer, String> prompt_ated_map = new HashMap<Integer,String>();
 private static Map<Integer, String> prompt_algn_map = new HashMap<Integer,String>();
 private static Map<Integer, String> prompt_reor_map = new HashMap<Integer,String>();
 private static Map<Integer, String> font_weight_map = new HashMap<Integer,String>();
 private static Map<Integer, String> font_style_map = new HashMap<Integer,String>();
 private static Map<Integer, String> font_space_map = new HashMap<Integer,String>();
 private static Map<Integer, String> func_wrap_map = new HashMap<Integer,String>();
 private static Map<Integer, String> func_case_map = new HashMap<Integer,String>();  
 private static Map<Integer, String> img_format_map = new HashMap<Integer,String>(); 
 private static Map<Integer, String> img_depth_map = new HashMap<Integer,String>(); 
 private static Map<Integer, String> img_dispq_map = new HashMap<Integer,String>(); 
 private static Map<Integer, String> img_sizing_map = new HashMap<Integer,String>(); 
 private static Map<Integer, String> list_type_map = new HashMap<Integer,String>();
 private static Map<Integer, String> block_ns_map = new HashMap<Integer,String>();
 private static Map<Integer, String> block_recor_map = new HashMap<Integer,String>();
 private static Map<Integer, String> block_qdst_map = new HashMap<Integer,String>();;
 private static Map<Integer, String> block_dstyp_map = new HashMap<Integer,String>();
 private static Map<Integer, String> block_dsmod_map = new HashMap<Integer,String>();
 private static Map<Integer, String> block_lcmd_map = new HashMap<Integer,String>();
 private static Map<Integer, String> block_kymd_map = new HashMap<Integer,String>();
 private static Map<Integer, String> block_dmtt_map = new HashMap<Integer,String>();
 private static Map<Integer, String> trg_style_map = new HashMap<Integer,String>();
 private static Map<Integer, String> trg_hie_map = new HashMap<Integer,String>();
 private static Map<Integer, String> cnv_type_map = new HashMap<Integer,String>();
 private static Map<Integer, String> lst_type_map = new HashMap<Integer,String>();
 private static Map<Integer, String> prm_type_map = new HashMap<Integer,String>();
 private static Map<Integer, String> alert_style_map = new HashMap<Integer,String>();
 private static Map<Integer, String> alert_btn_map = new HashMap<Integer,String>();
 private static Map<Integer, String> rg_cdt_map = new HashMap<Integer,String>();
 private static Map<Integer, String> rg_type_map = new HashMap<Integer,String>();
 private static Map<Integer, String> va_type_map = new HashMap<Integer,String>();
 private static Map<Integer, String> win_style_map = new HashMap<Integer,String>();
 private static Map<Integer, String> mi_ityp_map = new HashMap<Integer,String>();
 private static Map<Integer, String> mi_mgit_map = new HashMap<Integer,String>();
 private static Map<Integer, String> mi_ctyp_map = new HashMap<Integer,String>();
 private static Map<Integer, String> rep_exm_map = new HashMap<Integer,String>();
 private static Map<Integer, String> rep_com_map = new HashMap<Integer,String>();
 private static Map<Integer, String> rep_dtyp_map = new HashMap<Integer,String>();
 private static Map<Integer, String> rel_typ_map = new HashMap<Integer,String>();
 private static Map<Integer, String> rel_del_map = new HashMap<Integer,String>();
 private static boolean with_properties = true; //true;
 
 public static void disableWithProperties() {
	 with_properties = false;
 }
 
 public static boolean isWithProperties() {
	 return with_properties;
 }
 
 public static void printLibraries(JdapiIterator it, JdapiIterator it2, String indent) {
	while (it.hasNext())
	{
		AttachedLibrary lib = (AttachedLibrary)it.next();
		while(it2.hasNext()) {
			AttachedLibrary lib2 = (AttachedLibrary)it2.next();
			if(!lib.getName().equals(lib2.getName())) {
			   sb.append(indent + "- " + lib.getName()+":\n");
			} 
			if(isWithProperties()) {
				sb.append(indent + "    - Lib_Properties:\n");
				sb.append(indent + "        - General:\n");
				sb.append(indent + "            - Name: " + lib.getName()+"\n");		
				printComments(lib.getComment(),indent + "            ");
				sb.append(indent + "        - Functional:\n");
				sb.append(indent + "            - PL/SQL_Library_Location: " + lib.getLibraryLocation()+"\n");
			}
		}
		//System.out.println(lib.getName());
	}
	 
 }
 public static void printTriggerWithName(JdapiIterator it, String name, String indent) {
	while (it.hasNext())
	{
		Trigger trg = (Trigger)it.next();
		if(name.equals(trg.getName())) {
			printTrigger(trg, indent);
		}
	}
 }
 public static void printTriggers(JdapiIterator it, String indent) {
	while (it.hasNext())
	{
		Trigger trg = (Trigger)it.next();
		printTrigger(trg, indent);
	}
 }
 public static void printTrigger(Trigger trg, String indent) {
	sb.append(indent + "- " + trg.getName()+":\n");
	/*String text = indent + "    " + trg.getTriggerText();
	text = text.replaceAll("\n","\n    "+indent);
	sb.append(text+"\n");*/
	if(isWithProperties()) {
		sb.append(indent + "    - Triggger_Properties:\n"); 
		sb.append(indent + "        - General:\n");
		sb.append(indent + "            - Name: " + trg.getName()+"\n");
		sb.append(indent + "            - Subclass_Information: " + trg.getParentName()+"\n");
		printComments(trg.getComment(),indent + "            ");
		sb.append(indent + "        - Functional:\n");
		sb.append(indent + "            - Trigger_Style: " + (String) trg_style_map.get(trg.getTriggerStyle())+"\n");
		//sb.append(indent + "        - Trigger_Text:\n");
		printClause("Trigger_Text", trg.getTriggerText(), indent + "            ");
		sb.append(indent + "            - Fire_In_Enter_Query_Mode: " + (trg.isFireInQuery() ? "Yes" : "No") +"\n");
		sb.append(indent + "            - Execution_Hierarchy: " + (String) trg_hie_map.get(trg.getExecuteHierarchy())+"\n");
		sb.append(indent + "        - Help:\n");
		sb.append(indent + "            - Display_In_Keyboard_Help: " + (trg.isDisplayInKeyboardHelp() ? "Yes" : "No") +"\n");
		printClause("Keyboard_Help_Text", trg.getKeyboardHelpText(),indent + "            ");  
	} else {
		printClause("Trigger_Text", trg.getTriggerText(), indent + "    ");
	}	 
 }
 public static void printProgramUnitWithName(JdapiIterator it, String name, String indent) {
	while (it.hasNext())
	{
		ProgramUnit pu = (ProgramUnit)it.next();
		if(name.equals(pu.getName())) {
			printProgramUnit(pu, indent);
		}
	}
 }
 public static void printProgramUnits(JdapiIterator it, String indent) {
	while (it.hasNext())
	{
		ProgramUnit pu = (ProgramUnit)it.next();
		printProgramUnit(pu, indent);
	}
 }
 public static void printProgramUnit(ProgramUnit pu, String indent) {
	sb.append(indent +"- "+ pu.getName() + ":\n");
	if(isWithProperties()) {
		sb.append(indent + "    - Program_Unit_Properties:\n");
		sb.append(indent + "        - General:\n");
		sb.append(indent + "            - Name: " + pu.getName()+"\n");
		sb.append(indent + "            - Subclass_Information: " + pu.getParentName()+"\n");
		printComments(pu.getComment(),indent + "            ");	   
		sb.append(indent + "        - Functional:\n");
		printClause("Program_Unit_Text", pu.getProgramUnitText(), indent + "            ");
	} else {
		printClause("Program_Unit_Text", pu.getProgramUnitText(), indent + "    ");
	} 
 }
 public static void printBlockWithName(JdapiIterator it, String name, String indent) {
	while (it.hasNext())
	{
		Block block = (Block)it.next();
		if(name.equals(block.getName())) {
			printBlock(block, indent);
		}
	}
 }
 
 public static void printItemWithName(JdapiIterator it, String block_name, String item_name, String indent) {
	while (it.hasNext())
	{		
		Block block = (Block)it.next();
		if(block_name.equals(block.getName())) {
			JdapiIterator it2 = block.getItems();
			while (it2.hasNext())
	        {
			   Item item = (Item)it2.next();
			   if(item_name.equals(item.getName())) {
				   printItem(item, indent);
			   }
			}
		}
	}
 }
 
  public static void printBlockTriggerWithName(JdapiIterator it, String block_name, String trg_name, String indent) {
	while (it.hasNext())
	{		
		Block block = (Block)it.next();
		if(block_name.equals(block.getName())) {
			JdapiIterator it2 = block.getTriggers();
			while (it2.hasNext())
	        {
			   Trigger trg = (Trigger)it2.next();
			   if(trg_name.equals(trg.getName())) {
				   printTrigger(trg, indent);
			   }
			}
		}
	}
 }
 
  public static void printItemTriggerWithName(JdapiIterator it, String block_name, String item_name, String trg_name, String indent) {
	while (it.hasNext())
	{		
		Block block = (Block)it.next();
		if(block_name.equals(block.getName())) {
			JdapiIterator it1 = block.getItems();
			while (it1.hasNext())
	        {
			   Item item = (Item)it1.next();
			   if(item_name.equals(item.getName())) {
				JdapiIterator it2 = item.getTriggers();
				while (it2.hasNext())
				{
				   Trigger trg = (Trigger)it2.next();
				   if(trg_name.equals(trg.getName())) {
					   printTrigger(trg, indent);
				   }
				}
			   }
			}
		}
	}
 }
 
 public static void printBlocks(JdapiIterator it,String indent) {
	while (it.hasNext())
	{
		Block block = (Block)it.next();
		printBlock(block, indent);
	}
 }
 public static void printBlock(Block bl, String indent) {
	sb.append(indent+"- " + bl.getName()+":\n");
	//System.out.println(bl.getName());
	//System.out.println("[BlockTriggers]{");
	sb.append(indent + "    - Block_Triggers:\n");
	printTriggers(bl.getTriggers(),indent + "        ");
	//System.out.println("}");
	//System.out.println("[BlockItems]{");
	sb.append(indent + "    - Block_Items:\n");
	printItems(bl.getItems(),indent + "        ");
	sb.append(indent + "    - Block_Relations:\n");
	printRelations(bl.getRelations(),indent + "        ");
	if(isWithProperties()) {
		sb.append(indent + "    - Block_Properties:\n");
		sb.append(indent + "        - General:\n");
		sb.append(indent + "            - Name: " + bl.getName()+"\n");	
		sb.append(indent + "            - Subclass_Information: " + bl.getParentName()+"\n");
		printComments(bl.getComment(),indent + "            "); 
		sb.append(indent + "        - Navigation:\n");
		sb.append(indent + "            - Navigation_Style: " + (String) block_ns_map.get(bl.getNavigationStyle())+"\n");	
		sb.append(indent + "            - Previous_Navigation_Data_Block: " + bl.getPreviousNavigationBlockName()+"\n");
		sb.append(indent + "            - Next_Navigation_Data_Block: " + bl.getNextNavigationBlockName()+"\n");
		sb.append(indent + "        - Records:\n");
		sb.append(indent + "            - Current_Record_Visual_Attribute_Group: " + bl.getRecordVisualAttributeGroupName()+"\n");
		sb.append(indent + "            - Query_Array_Size: " + bl.getRecordsFetchedCount()+"\n");
		sb.append(indent + "            - Number_Of_Record_Buffered: " + bl.getRecordsBufferedCount()+"\n");
		sb.append(indent + "            - Number_Of_Record_Displayed: " + bl.getRecordsDisplayCount()+"\n");
		sb.append(indent + "            - Query_All_Records: " + (bl.isQueryAllRecords() ? "Yes" : "No") +"\n");
		sb.append(indent + "            - Record_Orientation: " + (String) block_recor_map.get(bl.getRecordOrientation())+"\n");
		sb.append(indent + "            - Single_Record: " + (bl.isSingleRecord() ? "Yes" : "No") +"\n");
		sb.append(indent + "        - Database:\n");
		sb.append(indent + "            - Database_Data_Block: " + (bl.isDatabaseBlock() ? "Yes" : "No") +"\n");
		sb.append(indent + "            - Enforce_Primary_Key: " + (bl.isEnforcedPrimaryKey() ? "Yes" : "No") +"\n");
		sb.append(indent + "            - Query_Allowed: " + (bl.isQueryAllowed() ? "Yes" : "No") +"\n");
		sb.append(indent + "            - Query_Data_Source_Type: " + (String) block_qdst_map.get(bl.getQueryDataSourceType()) +"\n");
		sb.append(indent + "            - Query_Data_Source_Name: " + bl.getQueryDataSourceName() +"\n");
		sb.append(indent + "            - Query_Data_Source_Columns:\n");
		printQueryDsColumns(bl.getQueryDataSourceColumns(), indent + "                ");
		sb.append(indent + "            - Query_Data_Source_Arguments:\n");
		printQueryDsArguments(bl.getQueryDataSourceArguments(), indent + "                ");
		sb.append(indent + "            - Alias: " + bl.getAlias() + "\n");
		sb.append(indent + "            - Include_REF_Item: " + (bl.isIncludeRefitem() ? "Yes" : "No") +"\n");
		printClause("WHERE_Clause", bl.getWhereClause(), indent +"            "); 
		printClause("ORDER_BY_Clause", bl.getOrderByClause(), indent +"            ");
		sb.append(indent + "            - Optimizer_Hint: " + bl.getOptionHint() + "\n");
		sb.append(indent + "            - Insert_Allowed: " + (bl.isInsertAllowed() ? "Yes" : "No") +"\n");
		sb.append(indent + "            - Update_Allowed: " + (bl.isUpdateAllowed() ? "Yes" : "No") +"\n");
		sb.append(indent + "            - Locking_Mode: " + (String) block_lcmd_map.get(bl.getLockMode()) +"\n");
		sb.append(indent + "            - Delete_Allowed: " + (bl.isDeleteAllowed() ? "Yes" : "No") +"\n");
		sb.append(indent + "            - Key_Mode: " + (String) block_kymd_map.get(bl.getKeyMode()) +"\n");
		sb.append(indent + "            - Update_Changed_Column_Only: " + (bl.isUpdateChangedColumns() ? "Yes" : "No") +"\n");
		sb.append(indent + "            - Enforce_Column_Security: " + (bl.isEnforcedColumnSecurity() ? "Yes" : "No") +"\n");
		sb.append(indent + "            - Maximum_Query_Time: " + bl.getMaximumQueryTime() + "\n");
		sb.append(indent + "            - MAximum_Records_Fetched: " + bl.getMaximumRecordsFetched() + "\n");
		sb.append(indent + "        - Advanced_Database:\n");
		sb.append(indent + "            - DML_Data_Target_Type: " + (String) block_dmtt_map.get(bl.getDMLDataType()) + "\n"); //map
		sb.append(indent + "            - DML_Data_Target_Name: " + bl.getDMLDataName() + "\n");
		sb.append(indent + "            - Insert_Procedure_Name: " + bl.getInsertProcedureName() + "\n");
		sb.append(indent + "            - Insert_Procedure_Result_Set_Columns:\n");
		printQueryDsColumns(bl.getInsertDataSourceColumns(), indent + "                ");
		sb.append(indent + "            - Insert_Procedure_Arguments:\n");
		printQueryDsArguments(bl.getInsertDataSourceArguments(), indent + "                ");
		sb.append(indent + "            - Update_Procedure_Name: " + bl.getUpdateProcedureName() + "\n");
		sb.append(indent + "            - Update_Procedure_Result_Set_Columns:\n");
		printQueryDsColumns(bl.getUpdateDataSourceColumns(), indent + "                ");
		sb.append(indent + "            - Update_Procedure_Arguments:\n");
		printQueryDsArguments(bl.getUpdateDataSourceArguments(), indent + "                ");
		sb.append(indent + "            - Delete_Procedure_Name: " + bl.getDeleteProcedureName() + "\n");
		sb.append(indent + "            - Delete_Procedure_Result_Set_Columns:\n");
		printQueryDsColumns(bl.getDeleteDataSourceColumns(), indent + "                ");
		sb.append(indent + "            - Delete_Procedure_Arguments:\n");
		printQueryDsArguments(bl.getDeleteDataSourceArguments(), indent + "                ");
		sb.append(indent + "            - Lock_Procedure_Name: " + bl.getLockProcedureName() + "\n");
		sb.append(indent + "            - Lock_Procedure_Result_Set_Columns:\n");
		printQueryDsColumns(bl.getLockDataSourceColumns(), indent + "                ");
		sb.append(indent + "            - Lock_Procedure_Arguments:\n");
		printQueryDsArguments(bl.getLockDataSourceArguments(), indent + "                ");
		sb.append(indent + "            - DML_Array_Size: " + bl.getDMLArraySize() + "\n");
		sb.append(indent + "            - Precompute Summaries: " + (bl.isPrecompSummary() ? "Yes" : "No") +"\n");
		sb.append(indent + "            - DML_Returning_Value: " + (bl.isDMLReturnValue() ? "Yes" : "No") +"\n");
		sb.append(indent + "        - Scrollbar:\n");
		sb.append(indent + "            - Show_Scroll_Bar: " + (bl.isShowScrollbar() ? "Yes" : "No") +"\n");
		sb.append(indent + "            - Scroll_Bar_Canvas: " + bl.getScrollbarCanvasName() +"\n");
		sb.append(indent + "            - Scroll_Bar_Tab_Page: " + bl.getScrollbarTabPageName() +"\n");
		sb.append(indent + "            - Scroll_Bar_Orientation: " + (String) block_recor_map.get(bl.getScrollbarOrientation()) +"\n"); //map
		sb.append(indent + "            - Scroll_Bar_X_Position: " + bl.getScrollbarXPosition() +"\n");
		sb.append(indent + "            - Scroll_Bar_Y_Position: " + bl.getScrollbarYPosition() +"\n");
		sb.append(indent + "            - Scroll_Bar_Width: " + bl.getScrollbarWidth() +"\n");
		sb.append(indent + "            - Scroll_Bar_Length: " + bl.getScrollbarLength() +"\n");
		sb.append(indent + "            - Reverse_Direction: " + (bl.isReverseDirection() ? "Yes" : "No") +"\n");
		sb.append(indent + "        - Visual_Attributes:\n");
		sb.append(indent + "            - Visual_Attribute_Group: " + bl.getVisualAttributeName()+"\n");
		sb.append(indent + "        - Color:\n");		
		sb.append(indent + "            - Foreground_Color: " + bl.getForegroundColor()+"\n");		
		sb.append(indent + "            - Background_Color: " + bl.getBackColor()+"\n");
		sb.append(indent + "            - Fill_Pattern: " + bl.getFillPattern()+"\n");
		sb.append(indent + "        - International:\n");			
		sb.append(indent + "            - Direction: " + (String) prompt_reor_map.get(bl.getLanguageDirection()) +"\n");
	}
		//System.out.println("}");
	
	 
 }
  public static void printRecordGroupColumns(JdapiIterator it,String indent) {
	 while (it.hasNext())
	 {
		RecordGroupColumn rgc = (RecordGroupColumn)it.next();
		sb.append(indent + "- " + rgc.getName()+":\n");
		sb.append(indent + "    - Data_Type: " + (String) rg_cdt_map.get(rgc.getColumnDataType())+"\n");
		sb.append(indent + "    - Length: " + rgc.getMaximumLength()+"\n");
		sb.append(indent + "    - Semantics: " + rgc.getDataLengthSemantics()+"\n");
		sb.append(indent + "    - Column_Values: " + rgc.getColumnValuesCount()+"\n");	
	 }
 }
 public static void printQueryDsColumns(JdapiIterator it,String indent) {
	 while (it.hasNext())
	 {
		DataSourceColumn dsc = (DataSourceColumn)it.next();
		sb.append(indent + "- " + dsc.getDSCName()+":\n");
		sb.append(indent + "    - Type: " + dsc.getDSCType()+"\n");
		sb.append(indent + "    - Length: " + dsc.getDSCLength()+"\n");
		sb.append(indent + "    - Precision: " + dsc.getDSCPrecision()+"\n");
		sb.append(indent + "    - Scale: " + dsc.getDSCScale()+"\n");
		sb.append(indent + "    - Mandatory: " + (dsc.isDSCMandatory() ? "Yes" : "No") +"\n");		
	 }
 }
 public static void printQueryDsArguments(JdapiIterator it,String indent) {
	while (it.hasNext())
	{
		DataSourceArgument dsa = (DataSourceArgument)it.next();
		sb.append(indent + "- " + dsa.getDSAName()+":\n");
		sb.append(indent + "    - Type: " + (String) block_dstyp_map.get(dsa.getDSAType())+"\n");
		sb.append(indent + "    - Type_Name: " + dsa.getDSATypeName()+"\n");
		sb.append(indent + "    - Mode: " + (String) block_dsmod_map.get(dsa.getDSAMode())+"\n");
		sb.append(indent + "    - Value: " + dsa.getDSAValue()+"\n");
	}
 }
 
 public static void printComments(String text, String indent){
	printClause("Comments", text, indent);
 }
 
 public static void printClause(String name, String text, String indent){
	if(text != null && !"null".equals(text) && text.length()>0) {
		    sb.append(indent + "- " + name + ": |\n");
			text = text.replaceAll("\n","\n    "+indent);
		    sb.append(indent +"    " + text+"\n");
	} else {
		    sb.append(indent + "- " + name + ": "+text+"\n");
	}
 }

 public static void printRelations(JdapiIterator it,String indent) {
	while (it.hasNext())
	{
		Relation rl = (Relation)it.next();
		sb.append(indent + "- " + rl.getName()+":\n");
	    if(isWithProperties()) {
			sb.append(indent + "    - Rel_Properties:\n");
			sb.append(indent + "        - General:\n");
			sb.append(indent + "            - Name: " + rl.getName()+"\n");
			sb.append(indent + "            - Relation_Type: " + (String) rel_typ_map.get(rl.getRelationType())+"\n");
			sb.append(indent + "            - Subclass_Information: " + rl.getDetailItemref()+"\n");
			printComments(rl.getComment(),indent + "            ");
			sb.append(indent + "        - Functional:\n");
			sb.append(indent + "            - Detail_Data_Block: " + rl.getDetailBlock()+"\n");
			printClause("Join_Condition", rl.getJoinCondition(), indent + "                ");
			sb.append(indent + "            - Delete_Record_Behavior: " + (String) rel_del_map.get(rl.getDeleteRecord())+"\n");
			sb.append(indent + "            - Prevent_Masterless_Operetions: " + (rl.isPreventMasterlessOperations() ? "Yes" : "No") +"\n");
			sb.append(indent + "        - Coordination:\n");
			sb.append(indent + "            - Deferred: " + (rl.isDeferred() ? "Yes" : "No") +"\n");
			sb.append(indent + "            - Automatic_Query: " + (rl.isAutoQuery() ? "Yes" : "No") +"\n");
		}
	}
  }
  
 public static void printItems(JdapiIterator it, String indent) {
	while (it.hasNext())
	{
		Item item = (Item)it.next();
		printItem(item, indent);
    }
 }
 
 public static void printItem(Item item, String indent) {
		//System.out.println(item.getName());
	sb.append(indent + "- " + item.getName()+":\n");
	//System.out.println("{");
	int item_type = item.getItemType();
	sb.append(indent + "    - Item_Triggers:\n");
	printTriggers(item.getTriggers(),indent + "        ");
	if(isWithProperties()) {
		sb.append(indent + "    - Item_Properties:\n");
		sb.append(indent + "        - General:\n");
		sb.append(indent + "            - Name: " + item.getName()+"\n");
		sb.append(indent + "            - Item_Type: " + (String) item_type_map.get(item.getItemType())+"\n");
		sb.append(indent + "            - Subclass_Information: " + item.getParentName()+"\n");
		printComments(item.getComment(),indent + "            ");
		sb.append(indent + "            - Help_Book_Topic: " + item.getHelpBookTopic()+"\n");
		sb.append(indent + "        - Functional:\n");
		
		if((item_type == 1) ||
		   (item_type == 4) ||
		   (item_type == 5) ||
		   (item_type == 6) || 
		   (item_type == 8)) { //PUSH_BUTTON,TEXT_ITEM 
			sb.append(indent + "            - Enabled: " + (item.isEnabled() ? "Yes" : "No") +"\n");
		}
		if((item_type == 1) ||
		   (item_type == 6)){ //PUSH_BUTTON
			sb.append(indent + "            - Label: " + item.getLabel()+"\n");
		}
		if(item_type == 4){
			sb.append(indent + "            - Image_Format: " + (String) img_format_map.get(item.getImageFormat())+"\n");
			sb.append(indent + "            - Image_Depth: " + (String) img_depth_map.get(item.getImageDepth())+"\n");		
			sb.append(indent + "            - Display_Quality: " + (String) img_dispq_map.get(item.getDisplayQuality())+"\n");	
			sb.append(indent + "            - Sizing_Style: " + (String) img_sizing_map.get(item.getSizingStyle())+"\n");				
		}
		if(item_type == 5){			
			int elm_count = item.getListElementCount();
			sb.append(indent + "            - Elements_In_List:\n");
			if(elm_count > 0) {
				for(int ndx = 0; ndx < elm_count; ndx++) {
					sb.append(indent + "                - Element_" + ndx+ ":\n");					
					sb.append(indent + "                    - Element_Label: " + item.getElementLabel(ndx+1)+"\n");
					sb.append(indent + "                    - Element_Value: " + item.getElementValue(ndx+1)+"\n");
				}
			}
			sb.append(indent + "            - List_Type: " + (String) list_type_map.get(item.getListStyle())+"\n");
		}
		if((item_type == 1) ||
		   (item_type == 6) || 
		   (item_type == 7)){
			sb.append(indent + "            - Access_Key: " + item.getAccessKey() +"\n");
		}
		if((item_type == 2) ||
		   (item_type == 8)) {  //DISPLAY_ITEM,TEXT_ITEM
			sb.append(indent + "            - Justification: " + (String) just_type_map.get(item.getJustification())+"\n");
		}
		if((item_type == 5) || //LIST_ITEM
		   (item_type == 7)) { //RADIO_GROUP
			sb.append(indent + "            - Mapping_Of_Other_Values: " + item.getOtherValues()+"\n");	
		}
		if((item_type == 1) ||
		   (item_type == 5) ||
		   (item_type == 6) ||
		   (item_type == 7) ||
		   (item_type == 8)) { //TEXT_ITEM 
			sb.append(indent + "            - Implementation_Class: " + item.getImplementationClass()+"\n");	
		}
		if(item_type == 6){ //PUSH_BUTTON
			sb.append(indent + "            - Iconic: " + (item.isIconic() ? "Yes" : "No") +"\n");
			sb.append(indent + "            - Icon_File_Name: " + item.getIconFilename() +"\n");
			sb.append(indent + "            - Default_Button: " + (item.isDefaultButton() ? "Yes" : "No") +"\n");
		}
		if(item_type == 8) { //TEXT_ITEM
			sb.append(indent + "            - Multi_Line: " + (item.isMultiLine() ? "Yes" : "No") +"\n");
			sb.append(indent + "            - Wrap_Style: " + (String) func_wrap_map.get(item.getWrapStyle())+"\n");
			sb.append(indent + "            - Case_Restriction: " + (String) func_case_map.get(item.getCaseRestriction())+"\n");
			sb.append(indent + "            - Conceal_Data: " + (item.isConcealData() ? "Yes" : "No") +"\n");	
			sb.append(indent + "            - Keep_Cursor_Position: " + (item.isKeepCursorPosition() ? "Yes" : "No") +"\n");
			sb.append(indent + "            - Automatic_Skip: " + (item.isAutoSkip() ? "Yes" : "No") +"\n");
		}
		if(item_type == 1) {
			sb.append(indent + "            - Value_When_Checked: " + item.getCheckedValue() +"\n");
			sb.append(indent + "            - Value_When_Unchecked: " + item.getUncheckedValue() +"\n");
			sb.append(indent + "            - Check_Box_Mapping_Of_Other_Values: " + item.getCheckBoxOtherValues() +"\n");			
		}
		if(item_type == 5) {
			sb.append(indent + "            - Case_Restriction: " + (String) func_case_map.get(item.getCaseRestriction())+"\n");
		}		
		sb.append(indent + "            - Popup_Menu: " + item.getPopupMenuName()+"\n");		
		sb.append(indent + "        - Navigation:\n");
		if((item_type == 1) ||
		   (item_type == 4) ||
		   (item_type == 5) ||
		   (item_type == 6) ||
		   (item_type == 7) ||
		   (item_type == 8)) { //TEXT_ITEM 
			sb.append(indent + "            - Keyboard_Navigable: " + (item.isKeyboardNavigable() ? "Yes" : "No") +"\n");
		}		
		if((item_type == 1) ||
		   (item_type == 5) ||
		   (item_type == 6) ||
		   (item_type == 7) 
		   ) {
			sb.append(indent + "            - Mouse_Navigate: " + (item.isMouseNavigate() ? "Yes" : "No") +"\n");
		}
		sb.append(indent + "            - Previous_Navigation_Item: " + item.getPreviousNavigationItemName()+"\n");	
		sb.append(indent + "            - Next_Navigation_Item: " + item.getNextNavigationItemName()+"\n");
		if((item_type == 1) ||
		   (item_type == 2) ||
		   (item_type == 5) ||
		   (item_type == 7) ||
		   (item_type == 8)) {
			sb.append(indent + "        - Data:\n");
			sb.append(indent + "            - Data_Type: " + (String) data_type_map.get(item.getDataType())+"\n");
			sb.append(indent + "            - Data_Length_Semantics: " + (String) data_lensem_map.get(item.getDataLengthSemantics())+"\n");
			sb.append(indent + "            - Maximum_Length: " + item.getMaximumLength()+"\n");
			sb.append(indent + "            - Initial_Value: " + item.getInitializeValue()+"\n");
			if ((item_type == 2) || 
			   (item_type == 5)  ||
			   (item_type == 8)) {
				sb.append(indent + "            - Required: " + (item.isRequired() ? "Yes" : "No") +"\n");
			}
			if ((item_type == 2) || 
				(item_type == 8)) {				
				sb.append(indent + "            - Format_Mask: " + item.getFormatMask()+"\n");
			}			
			if(item_type == 8) { //TEXT_ITEM 
				sb.append(indent + "            - Lowest_Allowed_Value: " + item.getLowestAllowedValue()+"\n");
				sb.append(indent + "            - Highest_Allowed_Value: " + item.getHighestAllowedValue()+"\n");
			}
			sb.append(indent + "            - Copy_Value_From_Item: " + item.getCopyValueFromItem()+"\n");
			sb.append(indent + "            - Synchronize_With_Item: " + item.getSynchronizedItemName()+"\n");
			sb.append(indent + "        - Calculation:\n");
			sb.append(indent + "            - Calculation_Mode: " + (String) calc_mod_map.get(item.getCalculateMode())+"\n");
			sb.append(indent + "            - Formula: " + item.getFormula()+"\n");
			sb.append(indent + "            - Summary_Function: " + (String) calc_sum_map.get(item.getSummaryFunction())+"\n");
			sb.append(indent + "            - Summarized_Block: " + item.getSummaryBlockName()+"\n");
			sb.append(indent + "            - Summarized_Item: " + item.getSummaryItemName()+"\n");
		}
		if(item_type == 4){
			sb.append(indent + "        - Data:\n");
			sb.append(indent + "            - Required: " + (item.isRequired() ? "Yes" : "No") +"\n");
			sb.append(indent + "            - Synchronize_With_Item: " + item.getSynchronizedItemName()+"\n");
		}
		sb.append(indent + "        - Records:\n");
		sb.append(indent + "            - Current_Record_Visual_Attribute_Group: " + item.getRecordVisualAttributeGroupName()+"\n");
		if((item_type == 1) ||
		   (item_type == 2) ||
		   (item_type == 4) ||
		   (item_type == 5) ||
		   (item_type == 6) ||
		   (item_type == 8)) {
			sb.append(indent + "            - Distance_Between_Records: " + item.getDistanceBetweenRecords()+"\n");
		}
		sb.append(indent + "            - Number_Of_Items_Displayed: " + item.getItemsDisplay()+"\n");
		if((item_type == 1) ||
		   (item_type == 2) ||
		   (item_type == 4) ||
		   (item_type == 7) ||
		   (item_type == 8)) {
			sb.append(indent + "        - Database:\n");
			sb.append(indent + "            - Database_Item: " + (item.isDatabaseItem() ? "Yes" : "No") +"\n");
			sb.append(indent + "            - Column_Name: " + item.getColumnName()+"\n");
			if((item_type == 1) ||
			   (item_type == 2) ||
			   (item_type == 5) ||
			   (item_type == 7) ||
			   (item_type == 8)) {
				sb.append(indent + "            - Primary_Key: " + (item.isPrimaryKey() ? "Yes" : "No") +"\n");
			}			
			sb.append(indent + "            - Query_Only: " + (item.isQueryOnly() ? "Yes" : "No") +"\n");
			if((item_type == 1) ||
			   (item_type == 5) ||
			   (item_type == 7) ||
			   (item_type == 8)) { //TEXT_ITEM  
				sb.append(indent + "            - Query_Allowed: " + (item.isQueryAllowed() ? "Yes" : "No") +"\n");
			}
			if(item_type == 8) { //TEXT_ITEM 
				sb.append(indent + "            - Case_Insensitive_Query: " + (item.isCaseInsensitiveQuery() ? "Yes" : "No") +"\n");
			}
			if((item_type == 1) ||
			   (item_type == 4) ||
			   (item_type == 5) ||
			   (item_type == 7) ||
			   (item_type == 8)) { //TEXT_ITEM  
				sb.append(indent + "            - Insert_Allowed: " + (item.isInsertAllowed() ? "Yes" : "No") +"\n");
				sb.append(indent + "            - Update_Allowed: " + (item.isUpdateAllowed() ? "Yes" : "No") +"\n");
			}
			if((item_type == 4) ||
			   (item_type == 5) || 
			   (item_type == 8)) { //TEXT_ITEM 
				sb.append(indent + "            - Update_Only_If_Null: " + (item.isUpdateIfNull() ? "Yes" : "No") +"\n");				
			}
			if((item_type == 4) ||
			   (item_type == 8)) { //TEXT_ITEM 				
				sb.append(indent + "            - Lock_Record: " + (item.isLockRecord() ? "Yes" : "No") +"\n");	
			}
			if(item_type == 8) { //TEXT_ITEM 
				sb.append(indent + "        - List_Of_Values:\n");
				sb.append(indent + "            - List_Of_Values: " + item.getLovName()+"\n");
				sb.append(indent + "            - List_X_Position: " + item.getLovXPosition()+"\n");
				sb.append(indent + "            - List_Y_Position: " + item.getLovYPosition()+"\n");
				sb.append(indent + "            - Validate_From_List: " + (item.isValidateFromList() ? "Yes" : "No") +"\n");	
				sb.append(indent + "        - Editor:\n");
				sb.append(indent + "            - Editor: " + item.getEditName()+"\n");
				sb.append(indent + "            - Editor_X_Position: " + item.getEditXPosition()+"\n");
				sb.append(indent + "            - Editor_Y_Position: " + item.getEditYPosition()+"\n");
			}
		}
		sb.append(indent + "        - Physical:\n");
		if((item_type == 1) ||
		   (item_type == 2) ||
		   (item_type == 4) ||
		   (item_type == 5) ||
		   (item_type == 6) ||
		   (item_type == 8)) {			 		   
			sb.append(indent + "            - Visible: " + (item.isVisible() ? "Yes" : "No") +"\n");
		}
		sb.append(indent + "            - Canvas: " + item.getCanvasName()+"\n");
		sb.append(indent + "            - Tab_Page: " + item.getTabPageName()+"\n");
		if((item_type == 1) ||
		   (item_type == 2) ||
		   (item_type == 4) ||
		   (item_type == 5) ||
		   (item_type == 6) ||
		   (item_type == 8)) {	
			sb.append(indent + "            - X_Position: " + item.getXPosition()+"\n");
			sb.append(indent + "            - Y_Position: " + item.getYPosition()+"\n");
			sb.append(indent + "            - Width: " + item.getWidth()+"\n");
			sb.append(indent + "            - Height: " + item.getHeight()+"\n");
		}
		if((item_type == 2) ||
		   (item_type == 4) ||
		   (item_type == 6) || 
		   (item_type == 8)) {
			sb.append(indent + "            - Bevel: " + (String) phys_bevel_map.get(item.getBevel())+"\n");
			
		}
		if((item_type == 2) ||
		   (item_type == 6) || 
		   (item_type == 8)) {
			sb.append(indent + "            - Rendered: " + (item.isRendered() ? "Yes" : "No") +"\n");   
		}
		if(item_type == 4) {
			sb.append(indent + "            - Show_Horizontal_Scroll_Bar: " + (item.isShowHorizontalScrollbar() ? "Yes" : "No") +"\n");
		}
		if(item_type == 8) { //TEXT_ITEM 
			sb.append(indent + "            - Show_Vertical_Scroll_Bar: " + (item.isShowVerticalScrollbar() ? "Yes" : "No") +"\n");
		}		
		sb.append(indent + "        - Visual_Attributes:\n");
		sb.append(indent + "            - Visual_Attribute_Group: " + item.getVisualAttributeName()+"\n");
		if((item_type == 1) ||
		   (item_type == 2) ||
		   (item_type == 4) ||
		   (item_type == 5) ||
		   (item_type == 6) ||
		   (item_type == 8)) {	
			sb.append(indent + "            - Prompt_Visual_Attribute_Group: " + item.getPromptVisualAttributeName()+"\n");
		}
		sb.append(indent + "        - Color:\n");
		if((item_type == 1) ||
		   (item_type == 2) ||	
		   (item_type == 5) ||		   
		   (item_type == 6) ||
		   (item_type == 7) ||
		   (item_type == 8)) {
			sb.append(indent + "            - Foreground_Color: " + item.getForegroundColor()+"\n");
		}
		sb.append(indent + "            - Background_Color: " + item.getBackColor()+"\n");
		sb.append(indent + "            - Fill_Pattern: " + item.getFillPattern()+"\n");
		sb.append(indent + "        - Font:\n");
		sb.append(indent + "            - Font_Name: " + item.getFontName()+"\n");
		sb.append(indent + "            - Font_Size: " + (item.getFontSize() / 100)+"\n");
		sb.append(indent + "            - Font_Weight: " + (String) font_weight_map.get(item.getFontWeight())+"\n");
		sb.append(indent + "            - Font_Style: " + (String) font_style_map.get(item.getFontStyle())+"\n");
		sb.append(indent + "            - Font_Spacing: " + (String) font_space_map.get(item.getFontSpacing())+"\n");
		sb.append(indent + "        - Prompt:\n");
		sb.append(indent + "            - Prompt: " + item.getPrompt()+"\n");
		sb.append(indent + "            - Prompt_Display_Style: " + (String) prompt_disp_map.get(item.getPromptDisplayStyle())+"\n");
		sb.append(indent + "            - Prompt_Justification: " + (String) prompt_just_map.get(item.getPromptJustification())+"\n");
		sb.append(indent + "            - Prompt_Attachment_Edge: " + (String) prompt_ated_map.get(item.getPromptAttachmentEdge())+"\n");
		sb.append(indent + "            - Prompt_Alignment: " + (String) prompt_algn_map.get(item.getPromptAlign())+"\n");
		sb.append(indent + "            - Prompt_Attachment_Offset: " + item.getPromptAttachmentOffset()+"\n");
		sb.append(indent + "            - Prompt_Alignment_Offset: " + item.getPromptAlignOffset()+"\n");
		sb.append(indent + "            - Prompt_Reading_Order: " + (String) prompt_reor_map.get(item.getPromptReadingOrder())+"\n");
		sb.append(indent + "        - Prompt_Color:\n");
		sb.append(indent + "            - Prompt_Foreground_Color: " + item.getPromptForegroundColor()+"\n");
		sb.append(indent + "        - Prompt_Font:\n");
		sb.append(indent + "            - Prompt_Font_Name: " + item.getPromptFontName()+"\n");
		sb.append(indent + "            - Prompt_Font_Size: " + (item.getPromptFontSize() / 100)+"\n");
		sb.append(indent + "            - Prompt_Font_Weight: " + (String) font_weight_map.get(item.getPromptFontWeight())+"\n");
		sb.append(indent + "            - Prompt_Font_Style: " + (String) font_style_map.get(item.getPromptFontStyle())+"\n");
		sb.append(indent + "            - Prompt_Font_Spacing: " + (String) font_space_map.get(item.getPromptFontSpacing())+"\n");
		sb.append(indent + "        - Help:\n");	   
		if((item_type == 1) ||
		   (item_type == 4) ||
		   (item_type == 5) ||
		   (item_type == 6) || 
		   (item_type == 7) || 
		   (item_type == 8)) { //TEXT_ITEM 
			sb.append(indent + "            - Hint: " + item.getHint() +"\n");
			sb.append(indent + "            - Display_Hint_Automatically: " + (item.isAutoHint() ? "Yes" : "No") +"\n");
		}	
		sb.append(indent + "            - Tooltip: " + item.getTooltip()+"\n");
		sb.append(indent + "            - Tooltip_Visual_Attribute_Group: " + item.getTooltipVisualAttributeGroup()+"\n");
		if((item_type == 1) ||
		   (item_type == 2) ||		
		   (item_type == 5) ||
		   (item_type == 6) ||
		   (item_type == 7) ||
		   (item_type == 8)) {
			sb.append(indent + "        - International:\n");
			if((item_type == 2) || 
			   (item_type == 5) ||
			   (item_type == 8)) {
				sb.append(indent + "            - Initial_Keyboard_State: " + item.getInitializeKeyboardDirection()+"\n");
				sb.append(indent + "            - Reading_Order: " + item.getReadingOrder()+"\n");
				sb.append(indent + "            - Keyboard_State: " + item.getKeyboardState()+"\n");
			}
			if((item_type == 1) ||
			  (item_type == 6) ||
			  (item_type == 7) 
			  ) {
				sb.append(indent + "            - Direction: " + (String) prompt_reor_map.get(item.getLanguageDirection()) +"\n");
			}
		}
	}			
		
}
 
 public static void printCanvases(JdapiIterator it, String indent) {
	while (it.hasNext())
	{
		Canvas cnv = (Canvas)it.next();
		sb.append(indent + "- " + cnv.getName()+":\n");
		if(isWithProperties()) {
			sb.append(indent + "    - Canvas_Properties:\n");
			sb.append(indent + "        - General:\n");
			sb.append(indent + "            - Name: " + cnv.getName()+"\n");
			sb.append(indent + "            - Canvas_Type: " + (String) cnv_type_map.get(cnv.getCanvasType())+"\n");
			sb.append(indent + "            - Subclass_Information: " + cnv.getParentName()+"\n");
			printComments(cnv.getComment(),indent + "            ");
			sb.append(indent + "            - Help_Book_Topic: " + cnv.getHelpBookTopic()+"\n");
			sb.append(indent + "        - Functional:\n");
			sb.append(indent + "            - Raise_On_Entry: " + (cnv.isRaiseOnEnter() ? "Yes" : "No") +"\n");
			sb.append(indent + "            - Popup_Menu: " + cnv.getPopupMenuName()+"\n");
			sb.append(indent + "        - Physical:\n");
			sb.append(indent + "            - Visible: " + (cnv.isVisible() ? "Yes" : "No") +"\n");
			sb.append(indent + "            - Window: " + cnv.getWindowName()+"\n");
			sb.append(indent + "            - Viewport_X_Position_On_Canvas: " + cnv.getViewportXPosition()+"\n");
			sb.append(indent + "            - Viewport_Y_Position_On_Canvas: " + cnv.getViewportYPosition()+"\n");
			sb.append(indent + "            - Width: " + cnv.getWidth()+"\n");
			sb.append(indent + "            - Height: " + cnv.getHeight()+"\n");
			sb.append(indent + "            - Bevel: " + (String) phys_bevel_map.get(cnv.getBevel())+"\n");
			sb.append(indent + "        - Visual_Attributes:\n");
			sb.append(indent + "            - Visual_Attribute_Group: " + cnv.getVisualAttributeName()+"\n");
			sb.append(indent + "        - Color:\n");		
			sb.append(indent + "            - Foreground_Color: " + cnv.getForegroundColor()+"\n");		
			sb.append(indent + "            - Background_Color: " + cnv.getBackColor()+"\n");
			sb.append(indent + "            - Fill_Pattern: " + cnv.getFillPattern()+"\n");
			sb.append(indent + "        - International:\n");			
			sb.append(indent + "            - Direction: " + (String) prompt_reor_map.get(cnv.getLanguageDirection()) +"\n");
		}
		
		
		//System.out.println(cnv.getName());
	}
  }
  public static void printWindows(JdapiIterator it, String indent) {
	while (it.hasNext())
	{
		Window win = (Window)it.next();
		sb.append(indent + "- " + win.getName() + ":\n"); 
		if(isWithProperties()) {
			sb.append(indent + "    - Window_Properties:\n");
			sb.append(indent + "        - General:\n");
			sb.append(indent + "            - Name: " + win.getName()+"\n");
			sb.append(indent + "            - Subclass_Information: " + win.getParentName()+"\n");
			printComments(win.getComment(),indent + "            ");	
			sb.append(indent + "            - Help_Book_Topic: " + win.getHelpBookTopic()+"\n");
			sb.append(indent + "        - Functional:\n");
			sb.append(indent + "            - Title: " + win.getTitle() +"\n");	
			sb.append(indent + "            - Primary_Canvas: " + win.getPrimaryCanvas() +"\n");
			sb.append(indent + "            - Horizontal_Toolbar_Canvas: " + win.getHorizontalToolbarCanvasName() +"\n");	
			sb.append(indent + "            - Vertical_Toolbar_Canvas: " + win.getVerticalToolbarCanvasName() +"\n");	
			sb.append(indent + "            - Window_Style: " +(String) win_style_map.get(win.getWindowStyle())+"\n");
			sb.append(indent + "            - Modal: " + (win.isModal() ? "Yes" : "No") +"\n");
			sb.append(indent + "            - Hide_On_Exit: " + (win.isHideOnExit() ? "Yes" : "No") +"\n");
			sb.append(indent + "            - Close_Allowed: " + (win.isClearAllowed() ? "Yes" : "No") +"\n");
			sb.append(indent + "            - Move_Allowed: " + (win.isMoveAllowed() ? "Yes" : "No") +"\n");
			sb.append(indent + "            - Resize_Allowed: " + (win.isResizeAllowed() ? "Yes" : "No") +"\n");
			sb.append(indent + "            - Maximize_Allowed: " + (win.isMaximizeAllowed() ? "Yes" : "No") +"\n");
			sb.append(indent + "            - Minimize_Allowed: " + (win.isMinimizeAllowed() ? "Yes" : "No") +"\n");		
			sb.append(indent + "            - Minimized_Title: " + win.getMinimizeTitle()+"\n");
			sb.append(indent + "            - Icon_Filename: " + win.getIconFilename()+"\n");
			sb.append(indent + "            - Inherit_Menu: " + (win.isInheritMenu() ? "Yes" : "No") +"\n");		
			sb.append(indent + "        - Physical:\n");
			sb.append(indent + "            - X_Position: " + win.getXPosition()+"\n");
			sb.append(indent + "            - Y_Position: " + win.getYPosition()+"\n");
			sb.append(indent + "            - Width: " + win.getWidth()+"\n");
			sb.append(indent + "            - Height: " + win.getHeight()+"\n");
			sb.append(indent + "            - Bevel: " + (String) phys_bevel_map.get(win.getBevel())+"\n");
			sb.append(indent + "            - Show_Horizontal_Scroll_Bar: " + (win.isShowHorizontalScrollbar() ? "Yes" : "No") +"\n");
			sb.append(indent + "            - Show_Vertical_Scroll_Bar: " + (win.isShowVerticalScrollbar() ? "Yes" : "No") +"\n");
			sb.append(indent + "        - Visual_Attributes:\n");
			sb.append(indent + "            - Visual_Attribute_Group: " + win.getVisualAttributeName()+"\n");
			sb.append(indent + "        - Color:\n");		
			sb.append(indent + "            - Foreground_Color: " + win.getForegroundColor()+"\n");		
			sb.append(indent + "            - Background_Color: " + win.getBackColor()+"\n");
			sb.append(indent + "            - Fill_Pattern: " + win.getFillPattern()+"\n");
			sb.append(indent + "        - Font:\n");
			sb.append(indent + "            - Font_Name: " + win.getFontName()+"\n");
			sb.append(indent + "            - Font_Size: " + (win.getFontSize() / 100)+"\n");
			sb.append(indent + "            - Font_Weight: " + (String) font_weight_map.get(win.getFontWeight())+"\n");
			sb.append(indent + "            - Font_Style: " + (String) font_style_map.get(win.getFontStyle())+"\n");
			sb.append(indent + "            - Font_Spacing: " + (String) font_space_map.get(win.getFontSpacing())+"\n");
			sb.append(indent + "        - International:\n");			
			sb.append(indent + "            - Direction: " + (String) prompt_reor_map.get(win.getLanguageDirection()) +"\n");
		}
		//System.out.println(win.getName());
	}
  }
  public static void printParameters(JdapiIterator it, JdapiIterator it2, String indent) {
	String params1="";
	String params2="";
	Map<String,Object> iv1 = new HashMap<String,Object>();
	Map<String,Object> iv2 = new HashMap<String,Object>();
	Map<String,Object> dt1 = new HashMap<String,Object>();
	Map<String,Object> dt2 = new HashMap<String,Object>();
	Map<String,Object> p1 = new HashMap<String,Object>();
	Map<String,Object> p2 = new HashMap<String,Object>();
	
	while (it.hasNext())
	{
		ModuleParameter prm = (ModuleParameter)it.next();
		//sb.append(indent + "- " + prm.getName() + ":\n");
		params1 += prm.getName()+":";
		if(isWithProperties()) {
			p1.put(prm.getName()+".parentName",prm.getParentName());
			dt1.put(prm.getName()+".dataType",(String) prm_type_map.get(prm.getParameterDataType()));
			iv1.put(prm.getName()+".initValue",  prm.getParameterInitializeValue());
		}
    }
	//sb.append(params1);
    while (it2.hasNext())
	{
		ModuleParameter prm = (ModuleParameter)it2.next();
		//sb.append(indent + "- " + prm.getName() + ":\n");
		params2 += prm.getName()+":";
		if(isWithProperties()) {
			p2.put(prm.getName()+".parentName",prm.getParentName());
			dt2.put(prm.getName()+".dataType",(String) prm_type_map.get(prm.getParameterDataType()));
			iv2.put(prm.getName()+".initValue", prm.getParameterInitializeValue());
		}
    }
	//sb2.append(params2);
	/*while (it.hasNext())
	{
		ModuleParameter prm = (ModuleParameter)it.next();
		if(params2.contains(prm.getName())) {
			sb.append(indent + "- " + prm.getName() + ":\n");
			if(isWithProperties()) {
				sb.append(indent + "    - Parameter_Properties:\n");
				sb.append(indent + "        - General:\n");
				sb.append(indent + "            - Name: " + prm.getName()+"\n");
				sb.append(indent + "            - Subclass_Information: " + prm.getParentName()+"\n");
				//printComments(prm.getComment(),indent + "            ");
				sb.append(indent + "        - Data:\n");
				sb.append(indent + "            - Parameter_Data_Type: " + (String) prm_type_map.get(prm.getParameterDataType())+"\n");
				sb.append(indent + "            - Parameter_Initial_Value: " + prm.getParameterInitializeValue()+"\n");
			}
		}
		//System.out.println(prm.getName());
	}*/
	String paramList1[] = params1.split(":");
	String paramList2[] = params2.split(":");
	String paramList3[] = null;
    String value1 = "";
    String value2 = "";
	for(String param : paramList1) {
		if(!params2.contains(param)) {
			sb.append(indent + "- " + param + ":\n");
			if(isWithProperties()) {
				sb.append(indent + "    - Parameter_Properties:\n");
				sb.append(indent + "        - General:\n");  			
				sb.append(indent + "            - Name: " + param+"\n");
				value1 = (String) p1.get(param+".parentName");
				value2 = (String) p2.get(param+".parentName");
				if(!"".equals(value1) && !value1.equals(value2)) { 
					sb.append(indent + "            - Subclass_Information: " + value1 + "\n");
				}						
				sb.append(indent + "        - Data:\n");
				value1 = (String) dt1.get(param+".dataType");
				value2 = (String) dt2.get(param+".dataType");
				if(!"".equals(value1) && !value1.equals(value2)) { 
					sb.append(indent + "            - Parameter_Data_Type: " + value1 + "\n");
				}		
				value1 = (String) iv1.get(param+".initValue");
				value2 = (String) iv2.get(param+".initValue");
				if(!"".equals(value1) && !value1.equals(value2)) { 
					sb.append(indent + "            - Parameter_Initial_Value: " + value1 + "\n");
		        }		
		    }
		} else {
			if(isWithProperties())  {	
                boolean b = false;			
				if(isMapDiff(p1,p2)) { 
				    sb.append(indent + "- " + param + "_same_param:\n");
					sb.append(indent + "    - Parameter_Properties:\n");
					sb.append(indent + "        - General:\n");  
					sb.append(indent + "            - Name: " + param+"\n");
					value1 = (String) p1.get(param+".parentName");
					value2 = (String) p2.get(param+".parentName");
					if(!"".equals(value1) && !value1.equals(value2)) { 
						sb.append(indent + "            - Subclass_Information: " + value1 + "\n");
					}	
					b = true;
				}	
                if(isMapDiff(dt1,dt2)) {
                   				
					value1 = (String) dt1.get(param+".dataType");
					value2 = (String) dt2.get(param+".dataType");
					if(!"".equals(value1) && !value1.equals(value2)) { 
					    if(!b) {
						  sb.append(indent + "- " + param + "_same_param:\n");
						  sb.append(indent + "    - Parameter_Properties:\n");
						  b = true;
					    }	
					    sb.append(indent + "        - Data:\n");
						sb.append(indent + "            - Parameter_Data_Type: " + value1 + "\n");
					}
                }			
                if(isMapDiff(iv1,iv2)) {	
                    		     				
					value1 = (String) iv1.get(param+".initValue");
					value2 = (String) iv2.get(param+".initValue");
					if(!"".equals(value1) && !value1.equals(value2)) { 
					    if(!b) {
							sb.append(indent + "- " + param + "_same_param:\n");
							sb.append(indent + "    - Parameter_Properties:\n");
							sb.append(indent + "        - Data:\n");
					    }	
						sb.append(indent + "            - Parameter_Initial_Value: " + value1 + "\n");
					}	
                }				
		    }
		}		
	}
	for(String param : paramList2) {
		if(!params1.contains(param)) {
			sb2.append(indent + "- " + param + ":\n");
			if(isWithProperties()) {
				sb2.append(indent + "    - Parameter_Properties:\n");
				sb2.append(indent + "        - General:\n");  
				sb2.append(indent + "            - Name: " + param+"\n");				
				value1 = ""+(String) p1.get(param+".parentName");
				value2 = ""+(String) p2.get(param+".parentName");
				if(!"".equals(value2) && !value1.equals(value2)) { 
						sb2.append(indent + "            - Subclass_Information: " + value2 + "\n");
				}
						
				sb2.append(indent + "        - Data:\n");
				value1 = ""+(String) dt1.get(param+".dataType");
				value2 = ""+(String) dt2.get(param+".dataType");
				if(!"".equals(value2) && !value1.equals(value2)) { 
					sb2.append(indent + "            - Parameter_Data_Type: " + value2 + "\n");
				}		
				value1 = ""+(String) iv1.get(param+".initValue");
				value2 = ""+(String) iv2.get(param+".initValue");
				if(!"".equals(value2) && !value1.equals(value2)) { 
					sb2.append(indent + "            - Parameter_Initial_Value: " + value2 + "\n");
				}
	        }
		} else {
			
			if(isWithProperties())  {	
                boolean b = false;  			
				if(isMapDiff(p2,p1)) { 
				    sb2.append(indent + "- " + param + "_same_param:\n");
					sb2.append(indent + "    - Parameter_Properties:\n");	
					sb2.append(indent + "        - General:\n");  			
					sb2.append(indent + "            - Name: " + param+"\n");					
					value1 = ""+(String) p1.get(param+".parentName");
					value2 = ""+(String) p2.get(param+".parentName");
					if(!"".equals(value2) && !value1.equals(value2)) { 
							sb2.append(indent + "            - Subclass_Information: " + value2 + "\n");
					}
					b = true;
				}
				if(isMapDiff(dt2,dt1)) {
                    						
					value1 = ""+(String) dt1.get(param+".dataType");
					value2 = ""+(String) dt2.get(param+".dataType");
					if(!"".equals(value2) && !value1.equals(value2)) { 
					    if(!b) {
							sb2.append(indent + "- " + param + "_same_param:\n");
							sb2.append(indent + "    - Parameter_Properties:\n");
						    b = true;
					    }	
						sb2.append(indent + "        - Data:\n");
						sb2.append(indent + "            - Parameter_Data_Type: " + value2 + "\n");
					}
                }	
                if(isMapDiff(iv2,iv1)) {                   						
					value1 = ""+(String) iv1.get(param+".initValue");
					value2 = ""+(String) iv2.get(param+".initValue");
					if(!"".equals(value2) && !value1.equals(value2)) { 
					    if(!b) {
						  sb2.append(indent + "- " + param + "_same_param:\n");
						  sb2.append(indent + "    - Parameter_Properties:\n");
						  sb2.append(indent + "        - Data:\n");
					    }	
						sb2.append(indent + "            - Parameter_Initial_Value: " + value2 + "\n");
					}
				}
	        }
		}		
	}
  }
  public static void printLOVWithName(JdapiIterator it, String lv_name, String indent) {
	while (it.hasNext())
	{ 
        LOV lv  = (LOV)it.next();
		 if(lv_name.equals(lv.getName())) {
			printLOV(lv, indent);
		}
	}		
  }
  public static void printLovs(JdapiIterator it, String indent) {
	while (it.hasNext())
	{ 
         LOV lv  = (LOV)it.next();
		 printLOV(lv, indent);
	}		
  }
 public static void printLOV(LOV lv, String indent) {
	sb.append(indent + "- " + lv.getName()+":\n");
	if(isWithProperties()) {
		sb.append(indent + "    - LOV_Properties:\n");
		sb.append(indent + "        - General:\n");
		sb.append(indent + "            - Name: " + lv.getName()+"\n");
		sb.append(indent + "            - Subclass_Information: " + lv.getParentName()+"\n");
		printComments(lv.getComment(),indent + "            ");	   
		sb.append(indent + "        - Functional:\n");
		sb.append(indent + "            - Title: " + lv.getTitle() +"\n");	
		sb.append(indent + "            - List_Type: " +(String) lst_type_map.get(lv.getListType())+"\n");
		sb.append(indent + "            - Record_Group: " + lv.getRecordGroupName() +"\n");
		sb.append(indent + "            - Column_Mapping_Properties:\n");
		printLovColMaps(lv.getLOVColumnMappings(), indent + "                ");
		sb.append(indent + "            - Filter_Before_Display: " + (lv.isFilterBeforeDisplay() ? "Yes" : "No") +"\n");
		sb.append(indent + "            - Automatic_Display: " + (lv.isAutoDisplay() ? "Yes" : "No") +"\n");
		sb.append(indent + "            - Automatic_Refresh: " + (lv.isAutoRefresh() ? "Yes" : "No") +"\n");
		sb.append(indent + "            - Automatic_Select: " + (lv.isAutoSelect() ? "Yes" : "No") +"\n");
		sb.append(indent + "            - Automatic_Skip: " + (lv.isAutoSkip() ? "Yes" : "No") +"\n");
		sb.append(indent + "            - Automatic_Position: " + (lv.isAutoPosition() ? "Yes" : "No") +"\n");
		sb.append(indent + "            - Automatic_Column_Width: " + (lv.isAutoColumnWidth() ? "Yes" : "No") +"\n");
		sb.append(indent + "        - Physical:\n");
		sb.append(indent + "            - X_Position: " + lv.getXPosition()+"\n");
		sb.append(indent + "            - Y_Position: " + lv.getYPosition()+"\n");
		sb.append(indent + "            - Width: " + lv.getWidth()+"\n");
		sb.append(indent + "            - Height: " + lv.getHeight()+"\n");
		sb.append(indent + "        - Visual_Attributes:\n");
		sb.append(indent + "            - Visual_Attribute_Group: " + lv.getVisualAttributeName()+"\n");
		sb.append(indent + "        - Color:\n");		
		sb.append(indent + "            - Foreground_Color: " + lv.getForegroundColor()+"\n");		
		sb.append(indent + "            - Background_Color: " + lv.getBackColor()+"\n");
		sb.append(indent + "            - Fill_Pattern: " + lv.getFillPattern()+"\n");
		sb.append(indent + "        - Font:\n");
		sb.append(indent + "            - Font_Name: " + lv.getFontName()+"\n");
		sb.append(indent + "            - Font_Size: " + (lv.getFontSize() / 100)+"\n");
		sb.append(indent + "            - Font_Weight: " + (String) font_weight_map.get(lv.getFontWeight())+"\n");
		sb.append(indent + "            - Font_Style: " + (String) font_style_map.get(lv.getFontStyle())+"\n");
		sb.append(indent + "            - Font_Spacing: " + (String) font_space_map.get(lv.getFontSpacing())+"\n");
		sb.append(indent + "        - International:\n");			
		sb.append(indent + "            - Direction: " + (String) prompt_reor_map.get(lv.getLanguageDirection()) +"\n");
	} else {
		printLovColMaps(lv.getLOVColumnMappings(), indent + "    ");
	}
  }
  
   
  
  public static void printLovColMaps(JdapiIterator it, String indent) {
	while (it.hasNext())
	{
		LOVColumnMapping lcm  = (LOVColumnMapping)it.next();
		sb.append(indent + "- "+lcm.getName()+":\n");
		sb.append(indent + "    - Return_Item: "+lcm.getReturnItem()+"\n");
		sb.append(indent + "    - Display_Width: "+lcm.getDisplayWidth()+"\n");
		sb.append(indent + "    - Column_Title: "+lcm.getTitle()+"\n");
		//System.out.println(lcm.getName()+":"+lcm.getReturnItem());
	}
  }
  
  public static void printRecordGroupWithName(JdapiIterator it, String rg_name, String indent) {
	while (it.hasNext())
	{ 
        RecordGroup rg  = (RecordGroup)it.next();
		if(rg_name.equals(rg.getName())) {
			printRecordGroup(rg, indent);
		}
	}
  }
  public static void printRecordGroups(JdapiIterator it, String indent) {
	while (it.hasNext())
	{ 
        RecordGroup rg  = (RecordGroup)it.next();
		printRecordGroup(rg, indent);
	}
  }
 public static void printRecordGroup(RecordGroup rg, String indent) {	
	sb.append(indent + "- " + rg.getName() + ":\n");
	printClause("Query", rg.getRecordGroupQuery(), indent + "    ");
	if(isWithProperties()) {
		sb.append(indent + "    - Record_Group_Properties:\n");
		sb.append(indent + "        - General:\n");
		sb.append(indent + "            - Name: " + rg.getName()+"\n");
		sb.append(indent + "            - Subclass_Information: " + rg.getParentName()+"\n");
		printComments(rg.getComment(),indent + "            ");
		sb.append(indent + "        - Functional:\n");
		sb.append(indent + "            - Record_Group_Type: " + (String) rg_type_map.get(rg.getRecordGroupType())+"\n");
		sb.append(indent + "            - Column_Specifications:\n");
		printRecordGroupColumns(rg.getRecordGroupColumns(),indent + "                ");
	}
 }
 public static void printAlerts(JdapiIterator it, JdapiIterator it2, String indent) {
	String alerts="";	
	
	while (it.hasNext())
	{
		Alert alert = (Alert)it.next();
		alerts += alert.getName();
	  
			/*if(isWithProperties()) {
				sb.append(indent + "    - Alert_Properties:\n");
				sb.append(indent + "        - General:\n");
				sb.append(indent + "            - Name: " + alert.getName()+"\n");		
				sb.append(indent + "            - Subclass_Information: " + alert.getParentName()+"\n");
				printComments(alert.getComment(),indent + "            ");	  
				sb.append(indent + "        - Functional:\n");
				sb.append(indent + "            - Title: " + alert.getTitle()+"\n");
				sb.append(indent + "            - Message: " + alert.getAlertMessage()+"\n");
				sb.append(indent + "            - Alert_Style: " + (String) alert_style_map.get(alert.getAlertStyle())+"\n");
				sb.append(indent + "            - Button_1_Label: " + alert.getButton1Label()+"\n");
				sb.append(indent + "            - Button_2_Label: " + alert.getButton2Label()+"\n");
				sb.append(indent + "            - Button_3_Label: " + alert.getButton3Label()+"\n");
				sb.append(indent + "            - Default_Alert_Button: " + (String) alert_btn_map.get(alert.getDefaultAlertButton())+"\n");
				sb.append(indent + "        - Visual_Attributes:\n");
				sb.append(indent + "            - Visual_Attribute_Group: " + alert.getVisualAttributeName()+"\n");
				sb.append(indent + "        - Color:\n");		
				sb.append(indent + "            - Foreground_Color: " + alert.getForegroundColor()+"\n");		
				sb.append(indent + "            - Background_Color: " + alert.getBackColor()+"\n");
				sb.append(indent + "            - Fill_Pattern: " + alert.getFillPattern()+"\n");
				sb.append(indent + "        - Font:\n");
				sb.append(indent + "            - Font_Name: " + alert.getFontName()+"\n");
				sb.append(indent + "            - Font_Size: " + (alert.getFontSize() / 100)+"\n");
				sb.append(indent + "            - Font_Weight: " + (String) font_weight_map.get(alert.getFontWeight())+"\n");
				sb.append(indent + "            - Font_Style: " + (String) font_style_map.get(alert.getFontStyle())+"\n");
				sb.append(indent + "            - Font_Spacing: " + (String) font_space_map.get(alert.getFontSpacing())+"\n");
				sb.append(indent + "        - International:\n");			
				sb.append(indent + "            - Direction: " + (String) prompt_reor_map.get(alert.getLanguageDirection()) +"\n");
			}*/
		
		  
		//System.out.println(alert.getName());
	}
	  while (it2.hasNext()) {
		Alert alert = (Alert)it2.next();
		if(!alerts.contains(alert.getName())) {	
			sb.append(indent + "- " + alert.getName() + ":\n"); 
			//sb2.append(indent + "- " + alert2.getName() + ":\n"); 
		}
	  }
  }
 public static void printEditors(JdapiIterator it, String indent) {
	while (it.hasNext())
	{
		Editor edit = (Editor)it.next();
		sb.append(indent + "- " + edit.getName() + ":\n"); 
		if(isWithProperties()) {
			sb.append(indent + "    - Editor_Properties:\n");
			sb.append(indent + "        - General:\n");
			sb.append(indent + "            - Name: " + edit.getName()+"\n");
			sb.append(indent + "            - Subclass_Information: " + edit.getParentName()+"\n");
			printComments(edit.getComment(),indent + "            ");	   
			sb.append(indent + "        - Functional:\n");
			sb.append(indent + "            - Title: " + edit.getTitle() +"\n");
			sb.append(indent + "            - Bottom_Title: " + edit.getBottomTitle()+"\n");
			sb.append(indent + "            - Wrap_Style: " +(String) func_wrap_map.get(edit.getWrapStyle())+"\n");
			sb.append(indent + "        - Physical:\n");
			sb.append(indent + "            - X_Position: " + edit.getXPosition()+"\n");
			sb.append(indent + "            - Y_Position: " + edit.getYPosition()+"\n");
			sb.append(indent + "            - Width: " + edit.getWidth()+"\n");
			sb.append(indent + "            - Height: " + edit.getHeight()+"\n");
			sb.append(indent + "            - Show_Vertical_Scroll_Bar: " + (edit.isShowVerticalScrollbar() ? "Yes" : "No") +"\n");
			sb.append(indent + "        - Visual_Attributes:\n");
			sb.append(indent + "            - Visual_Attribute_Group: " + edit.getVisualAttributeName()+"\n");
			sb.append(indent + "        - Color:\n");		
			sb.append(indent + "            - Foreground_Color: " + edit.getForegroundColor()+"\n");		
			sb.append(indent + "            - Background_Color: " + edit.getBackColor()+"\n");
			sb.append(indent + "            - Fill_Pattern: " + edit.getFillPattern()+"\n");
			sb.append(indent + "        - Font:\n");
			sb.append(indent + "            - Font_Name: " + edit.getFontName()+"\n");
			sb.append(indent + "            - Font_Size: " + (edit.getFontSize() / 100)+"\n");
			sb.append(indent + "            - Font_Weight: " + (String) font_weight_map.get(edit.getFontWeight())+"\n");
			sb.append(indent + "            - Font_Style: " + (String) font_style_map.get(edit.getFontStyle())+"\n");
			sb.append(indent + "            - Font_Spacing: " + (String) font_space_map.get(edit.getFontSpacing())+"\n");	
        }		
		//System.out.println(edit.getName());
	}
  }
  public static void printEvents(JdapiIterator it, String indent) {
	while (it.hasNext())
	{
		Event evt = (Event)it.next();
		sb.append(indent + "- " + evt.getName() + "\n"); 
		//System.out.println(evt.getName());
	}
  }
  public static void printObjectGroups(JdapiIterator it, String indent) {
	while (it.hasNext())
	{
		ObjectGroup obg = (ObjectGroup)it.next();
		sb.append(indent + "- " + obg.getName() + ":\n"); 
		if(isWithProperties()) {
			sb.append(indent + "    - Object_Group_Properties:\n");
			sb.append(indent + "        - General:\n");
			sb.append(indent + "            - Name: " + obg.getName()+"\n");
			sb.append(indent + "            - Subclass_Information: " + obg.getParentName()+"\n");
			printComments(obg.getComment(),indent + "            ");
		}
		//System.out.println(obg.getName());
	}
  }
  public static void printPopupMenus(JdapiIterator it, String indent) {
	while (it.hasNext())
	{
		Menu pum = (Menu)it.next();
		sb.append(indent + "- " + pum.getName() + ":\n"); 
		if(isWithProperties()) {
			sb.append(indent + "    - Menu_Properties:\n");
			sb.append(indent + "        - General:\n");
			sb.append(indent + "            - Name: " + pum.getName()+"\n");
			sb.append(indent + "            - Subclass_Information: " + pum.getParentName()+"\n");
			printComments(pum.getComment(),indent + "            ");	   
			sb.append(indent + "        - Functional:\n");
			sb.append(indent + "            - Tear_Of_Menu: " + (pum.isTearOffMenu() ? "Yes" : "No") +"\n");
			sb.append(indent + "    - Menu_Items:\n");
			printPopupMenuItems(pum.getMenuItems(), indent + "        ");
		}
		//System.out.println(pum.getName());
	}
  }
  
  public static void printPopupMenuItems(JdapiIterator it, String indent) {
	while (it.hasNext())
	{
		MenuItem mi = (MenuItem)it.next();
		sb.append(indent + "- " + mi.getName() + ":\n"); 
		if(isWithProperties()) {
			sb.append(indent + "    - Menu_Item_Properties:\n");
			sb.append(indent + "        - General:\n");
			sb.append(indent + "            - Name: " + mi.getName()+"\n");
			sb.append(indent + "            - Subclass_Information: " + mi.getParentName()+"\n");
			printComments(mi.getComment(),indent + "            ");	   
			sb.append(indent + "        - Functional:\n");
			sb.append(indent + "            - Enabled: " + (mi.isEnabled() ? "Yes" : "No") +"\n");
			sb.append(indent + "            - Label: " + mi.getLabel()+"\n");
			sb.append(indent + "            - Menu_Item_Type: " +(String) mi_ityp_map.get(mi.getMenuItemType())+"\n");
			sb.append(indent + "            - Magic_Item: " +(String) mi_mgit_map.get(mi.getMagicItem())+"\n");
			sb.append(indent + "            - Menu_Item_Radio_Group: " + mi.getMenuItemRadioGroup()+"\n");
			sb.append(indent + "            - Command_Type: " + (String) mi_ctyp_map.get(mi.getCommandType())+"\n");
			sb.append(indent + "            - Command_Text: " + mi.getCommandText()+"\n");
			printClause("Menu_Item_Code", mi.getMenuItemCode(),indent + "            ");
			sb.append(indent + "            - Icon_In_Menu: " + (mi.isIconInMenu() ? "Yes" : "No") +"\n");
			sb.append(indent + "            - Icon_Filename: " + mi.getIconFilename()+"\n");
			sb.append(indent + "        - Physical:\n");
			sb.append(indent + "            - Visible: " + (mi.isVisible() ? "Yes" : "No") +"\n");
			sb.append(indent + "        - Visual_Attributes:\n");
			sb.append(indent + "            - Visual_Attribute_Group: " + mi.getVisualAttributeName()+"\n");		
			sb.append(indent + "        - Font:\n");
			sb.append(indent + "            - Font_Name: " + mi.getFontName()+"\n");
			sb.append(indent + "            - Font_Size: " + (mi.getFontSize() / 100)+"\n");
			sb.append(indent + "            - Font_Weight: " + (String) font_weight_map.get(mi.getFontWeight())+"\n");
			sb.append(indent + "            - Font_Style: " + (String) font_style_map.get(mi.getFontStyle())+"\n");
			sb.append(indent + "            - Font_Spacing: " + (String) font_space_map.get(mi.getFontSpacing())+"\n");	
			sb.append(indent + "        - Help:\n");
			sb.append(indent + "            - Hint: " +  mi.getHint()+"\n");
		}
		//System.out.println(pum.getName());
	}
  }
  public static void printPropertyClasses(JdapiIterator it, String indent) {
	while (it.hasNext())
	{
		PropertyClass pcs = (PropertyClass)it.next();
		sb.append(indent + "- " + pcs.getName() + ":\n"); 
		if(isWithProperties()) {
			sb.append(indent + "    - Class_Properties:\n"); 
			sb.append(indent + "        - General:\n");
			sb.append(indent + "            - Name: " + pcs.getName()+"\n");
			sb.append(indent + "            - Subclass_Information: " + pcs.getParentName()+"\n");
			printComments(pcs.getComment(),indent + "            ");
		}
		//System.out.println(pcs.getName());
	}
  }
   public static void printReports(JdapiIterator it, String indent) {
	while (it.hasNext())
	{
		Report elm = (Report)it.next();
		sb.append(indent + "- " + elm.getName() + ":\n"); 
		if(isWithProperties()) {
			sb.append(indent + "    - Report_Properties:\n");
			sb.append(indent + "        - General:\n");
			sb.append(indent + "            - Name: " + elm.getName()+"\n");		
			sb.append(indent + "            - Subclass_Information: " + elm.getParentName()+"\n");
			printComments(elm.getComment(),indent + "            ");	   
			sb.append(indent + "        - Oracle_Developer_Integration:\n");		
			sb.append(indent + "            - File_Name: " + elm.getFilename()+"\n");		
			sb.append(indent + "            - Execution_Mode: " + (String) rep_exm_map.get(elm.getExecuteMode())+"\n");
			sb.append(indent + "            - Communication_Mode: " + (String) rep_com_map.get(elm.getCommMode())+"\n");
			sb.append(indent + "            - Data_Source_Data_Block: " + elm.getDataSourceBlock()+"\n");
			sb.append(indent + "            - Query_Name: " + elm.getQueryName()+"\n");
			sb.append(indent + "        - Reports:\n");
			sb.append(indent + "            - Report_Destination_Type: " + (String) rep_dtyp_map.get(elm.getReportDestinationType())+"\n");
			sb.append(indent + "            - Report_Destination_Name: " + elm.getReportDestinationName()+"\n");
			sb.append(indent + "            - Report_Destination_Format: " + elm.getReportDestinationFormat()+"\n");
			sb.append(indent + "            - Report_Server: " + elm.getReportServer()+"\n");
			sb.append(indent + "            - Other_Report_Parameters: " + elm.getReportParameters()+"\n");	
		}
		//System.out.println(pcs.getName());
	}
  }
   public static void printVisualAttributes(JdapiIterator it, String indent) {
	while (it.hasNext())
	{
		VisualAttribute elm = (VisualAttribute)it.next();
		sb.append(indent + "- " + elm.getName() + ":\n"); 
		if(isWithProperties()) {
			sb.append(indent + "    - VA_Properties:\n");
			sb.append(indent + "        - General:\n");
			sb.append(indent + "            - Name: " + elm.getName()+"\n");
			sb.append(indent + "            - Visual_Attribute_Type: " + (String) va_type_map.get(elm.getVisualAttributeType())+"\n");
			sb.append(indent + "            - Subclass_Information: " + elm.getParentName()+"\n");
			printComments(elm.getComment(),indent + "            ");	   
			sb.append(indent + "        - Color:\n");		
			sb.append(indent + "            - Foreground_Color: " + elm.getForegroundColor()+"\n");		
			sb.append(indent + "            - Background_Color: " + elm.getBackColor()+"\n");
			sb.append(indent + "            - Fill_Pattern: " + elm.getFillPattern()+"\n");
			sb.append(indent + "        - Font:\n");
			sb.append(indent + "            - Font_Name: " + elm.getFontName()+"\n");
			sb.append(indent + "            - Font_Size: " + (elm.getFontSize() / 100)+"\n");
			sb.append(indent + "            - Font_Weight: " + (String) font_weight_map.get(elm.getFontWeight())+"\n");
			sb.append(indent + "            - Font_Style: " + (String) font_style_map.get(elm.getFontStyle())+"\n");
			sb.append(indent + "            - Font_Spacing: " + (String) font_space_map.get(elm.getFontSpacing())+"\n");	
		}
		//System.out.println(pcs.getName());
	}
  }
  public static boolean isMapDiff(Map<String,Object> map1, Map<String,Object> map2) {
	  Set<String> keys = map1.keySet();
	  String value1="";
	  String value2="";
	  for(String key : keys) {
		  value1 = "" + map1.get(key);
		  value2 = "" + map2.get(key);
		  if(value1 != null && value2!= null && !"".equals(value1) && !"".equals(value2) && !"null".equals(value1) && !"null".equals(value2) && !value1.equals(value2)) {
			  return true;			  
		  }
	  }
	  return false;
  }
 public static void main(String[] args)
{
    if(args.length !=3 ) {
		System.out.println("Kullanım : java Fmb2Yml <*.FMB> <*.FMB> <*.TYP>"); 
		System.exit(0);
	} 
	String fmb_name = args[0];
	String fmb_name2 = args[1];
	String type_name = args[2];
	JdapiModule.openModule(fmb_name);
    JdapiModule.openModule(fmb_name2);
	JdapiIterator fmbs = Jdapi.getModules();
	FormModule fmb = null;
	FormModule fmb2 = null;
	int ndx=0;
	while(fmbs.hasNext()) {
		if(ndx == 0) {
			fmb = (FormModule)fmbs.next();
		} else {
			fmb2 = (FormModule)fmbs.next();
		}
		ndx++;
	}
	
	item_type_map.put(0,"Bean Area");	
	item_type_map.put(1,"Check Box"); //OK		
	item_type_map.put(2,"Display Item"); //OK
	item_type_map.put(3,"Hierarchical Tree");
	item_type_map.put(4,"Image"); //OK
	item_type_map.put(5,"List Item"); //OK
	item_type_map.put(6,"Push Button"); //OK
	item_type_map.put(7,"Radio Group");	//OK
	item_type_map.put(8,"Text Item"); //OK
    item_type_map.put(9,"User Area");
	item_type_map.put(10,"Active X Control (Obsolete) ");
	item_type_map.put(11,"Chart Item (Obsolete)");
	item_type_map.put(12,"OLE Container (Obsolete)");
	item_type_map.put(13,"Sound (Obsolete)");
	item_type_map.put(14,"VBX Control(Obsolete)");
	
	just_type_map.put(0,"x Left");
	just_type_map.put(1,"Left");
	just_type_map.put(2,"Right");
	just_type_map.put(3,"Center");
	just_type_map.put(4,"Start");
	just_type_map.put(5,"End");
	
	data_type_map.put(0,"Char");
	data_type_map.put(1,"Number");
	data_type_map.put(2,"Date");
	data_type_map.put(3,"Alpha");
	data_type_map.put(4,"Integer");
	data_type_map.put(5,"Datetime");
	data_type_map.put(6,"Long");
    data_type_map.put(7,"Rnumber");
	data_type_map.put(8,"Jdate");
	data_type_map.put(9,"Edate");
    data_type_map.put(10,"Time");
	data_type_map.put(11,"Rinteger");
	data_type_map.put(12,"Money");
    data_type_map.put(13,"Rmoney");
	data_type_map.put(14,"Object REF");
	data_type_map.put(15,"Nchar");
	
	data_lensem_map.put(0,"Null");
	data_lensem_map.put(1,"BYTE");
	data_lensem_map.put(2,"CHAR");
	
	calc_mod_map.put(0,"None");
	calc_mod_map.put(1,"Formula");
	calc_mod_map.put(2,"Summary");
	
	calc_sum_map.put(0,"None");
	calc_sum_map.put(1,"Avg");
	calc_sum_map.put(2,"Count");
	calc_sum_map.put(3,"Max");
	calc_sum_map.put(4,"Min");
	calc_sum_map.put(5,"Stddev");
	calc_sum_map.put(6,"Sum");
	calc_sum_map.put(7,"Variance");
	
	phys_bevel_map.put(0,"Raised");
	phys_bevel_map.put(1,"Lowered");
	phys_bevel_map.put(2,"None");
	phys_bevel_map.put(3,"Inset");
	phys_bevel_map.put(4,"Outset");
	phys_bevel_map.put(5,"Plain");
	
	prompt_disp_map.put(0,"Hidden");
	prompt_disp_map.put(1,"First Record");
	prompt_disp_map.put(2,"All Records");
	
	prompt_just_map.put(0,"Left");
	prompt_just_map.put(1,"Right");
	prompt_just_map.put(2,"Center");
	prompt_just_map.put(3,"Start");
	prompt_just_map.put(4,"End");
	
	prompt_ated_map.put(0,"Start");
	prompt_ated_map.put(1,"End");
	prompt_ated_map.put(2,"Top");
	prompt_ated_map.put(3,"Bottom");

    prompt_algn_map.put(0,"Start");
	prompt_algn_map.put(1,"End");
	prompt_algn_map.put(2,"Center");

	prompt_reor_map.put(0,"Default");
	prompt_reor_map.put(1,"Left To Right");
	prompt_reor_map.put(2,"Right To Left");
	
	font_weight_map.put(0,"Ultralight");
	font_weight_map.put(1,"Extralight");
	font_weight_map.put(2,"Light");
	font_weight_map.put(3,"Demilight");
	font_weight_map.put(4,"Normal");
	font_weight_map.put(5,"Ultrabold");
	font_weight_map.put(6,"Extrabold");
	font_weight_map.put(7,"Bold");
	font_weight_map.put(8,"Demibold");
	
    font_style_map.put(0,"Plain");
	font_style_map.put(1,"Italic");
	font_style_map.put(2,"Oblique");
	font_style_map.put(3,"Underline");
	font_style_map.put(4,"Outline");
	font_style_map.put(5,"Shadow");
	font_style_map.put(6,"Inverted");
	font_style_map.put(7,"Overstrike");
	font_style_map.put(8,"Blind");
	
	font_space_map.put(0,"Ultradense");
	font_space_map.put(1,"Extradense");
	font_space_map.put(2,"Dense");
	font_space_map.put(3,"Semidense");
	font_space_map.put(4,"Normal");
    font_space_map.put(5,"Semiexpand");
	font_space_map.put(6,"Expand");
	font_space_map.put(7,"Extraexpand");
	font_space_map.put(8,"Ultraexpand");
	
	func_wrap_map.put(0,"None");
	func_wrap_map.put(1,"Character");
	func_wrap_map.put(2,"Word");

	func_case_map.put(0,"Mixed");
	func_case_map.put(1,"Upper");
	func_case_map.put(2,"Lower");
	
	img_format_map.put(0,"BMP");
	img_format_map.put(1,"CALS");
	img_format_map.put(2,"GIF");
	img_format_map.put(3,"JFIF");
	img_format_map.put(4,"PICT");
	img_format_map.put(5,"RAS");
	img_format_map.put(6,"TIFF");
	img_format_map.put(7,"TPIC");
	
	img_depth_map.put(0,"Original");
	img_depth_map.put(1,"Monochrome");
	img_depth_map.put(2,"Gray");
	img_depth_map.put(3,"LUT");
	img_depth_map.put(4,"RGB");
	
	img_dispq_map.put(0,"High");
    img_dispq_map.put(1,"Medium");
    img_dispq_map.put(2,"Low");
	
	img_sizing_map.put(0, "Crop");
	img_sizing_map.put(1, "Adjust");
   
    list_type_map.put(0, "Poplist");
	list_type_map.put(1, "Tlist");
	list_type_map.put(2, "Combo Box");
	
	block_ns_map.put(0, "Same Record");
	block_ns_map.put(1, "Change Record");
	block_ns_map.put(2, "Change Data Block");
	
	block_recor_map.put(0, "Vertical");
	block_recor_map.put(1, "Horizantal");
	
	block_dstyp_map.put(0,"VARCHAR2");
	block_dstyp_map.put(1,"NUMBER");
	block_dstyp_map.put(2,"LONG");
	block_dstyp_map.put(3,"ROWID");
	block_dstyp_map.put(4,"DATA");
	block_dstyp_map.put(5,"RAW");
	block_dstyp_map.put(6,"LONG RAW");
	block_dstyp_map.put(7,"CHAR");
	block_dstyp_map.put(8,"MLSLABEL");
	block_dstyp_map.put(9,"TABLE");
	block_dstyp_map.put(10,"RECORD");
	block_dstyp_map.put(11,"REFCURSOR");
	block_dstyp_map.put(12,"NAMED TYP");
	block_dstyp_map.put(13,"OBJECT REF");
	block_dstyp_map.put(10,"VARRAY");
	block_dstyp_map.put(11,"Nested Table");
	block_dstyp_map.put(12,"BLOB");
	block_dstyp_map.put(13,"CLOB");
	block_dstyp_map.put(14,"BFILE");
	block_dstyp_map.put(15,"NVARCHAR2");
	block_dstyp_map.put(16,"NCHAR");
	block_dstyp_map.put(17,"NCLOB");
	
	block_qdst_map.put(0,"None");
	block_qdst_map.put(1,"Table");
	block_qdst_map.put(2,"Procedure");
	block_qdst_map.put(3,"Transactional Triggers");
	block_qdst_map.put(4,"FROM clause query");
	
	block_dsmod_map.put(0,"IN");
	block_dsmod_map.put(1,"OUT");
	block_dsmod_map.put(2,"IN OUT");
	
	block_lcmd_map.put(0, "Immediate");
    block_lcmd_map.put(1, "Delayed");
	block_lcmd_map.put(2, "Automatic");
	
	block_kymd_map.put(0, "Unique");
    block_kymd_map.put(1, "Updatable");
    block_kymd_map.put(1, "Non-Updatable");
	block_kymd_map.put(3, "Automatic");
	
    block_dmtt_map.put(0,"None");
	block_dmtt_map.put(1,"Table");
	block_dmtt_map.put(2,"Procedure");
	block_dmtt_map.put(3,"Transactional Triggers");
	
	trg_style_map.put(0,"PL/SQL");
	
	trg_hie_map.put(0, "Override");
	trg_hie_map.put(1, "Before");
	trg_hie_map.put(2, "After");
	
	cnv_type_map.put(0, "Content");
	cnv_type_map.put(1, "Stacked");
	cnv_type_map.put(2, "Vertical Toolbar");
	cnv_type_map.put(3, "Horizantal Toolbar");
	cnv_type_map.put(4, "Tab");
	
	lst_type_map.put(0,"Record Group");
	
	prm_type_map.put(0, "Char");
	prm_type_map.put(1, "Number");
	prm_type_map.put(2, "Date");
	
	alert_style_map.put(0, "Stop");
	alert_style_map.put(1, "Caution");
	alert_style_map.put(2, "Note");
	
	alert_btn_map.put(0, "Button 1");
	alert_btn_map.put(1, "Button 2");
	alert_btn_map.put(2, "Button 3");
	
	rg_cdt_map.put(0,"Character");
	rg_cdt_map.put(1,"Number");
	rg_cdt_map.put(2,"Date");
	
	rg_type_map.put(0,"Query");
	rg_type_map.put(1,"Static");
	
	va_type_map.put(0,"Common");
	va_type_map.put(0,"Prompt");
	va_type_map.put(0,"Title");

	win_style_map.put(0,"Document");
	win_style_map.put(1,"Dialog");
   
    mi_ityp_map.put(0,"Plain");
	mi_ityp_map.put(1,"Check");
    mi_ityp_map.put(2,"Radio");	
	mi_ityp_map.put(3,"Seperator");
	mi_ityp_map.put(4,"Magic");
	
	mi_mgit_map.put(0,"None");
	mi_mgit_map.put(1,"Cut");
	mi_mgit_map.put(2,"Copy");
	mi_mgit_map.put(3,"Paste");
	mi_mgit_map.put(4,"Clear");
	mi_mgit_map.put(5,"Undo");
	mi_mgit_map.put(6,"Help");
	mi_mgit_map.put(7,"About");
	mi_mgit_map.put(8,"Quick");
	mi_mgit_map.put(9,"Window");
	mi_mgit_map.put(10,"Page Setup (Obsolete)");
	
	mi_ctyp_map.put(0,"Null");
    mi_ctyp_map.put(1,"Menu");
    mi_ctyp_map.put(2,"PL/SQL");
	
	rep_exm_map.put(0, "Batch");
	rep_exm_map.put(1, "Runtime");
	
	rep_com_map.put(0, "Synchronous");
	rep_com_map.put(1, "Asynchronous");
	
	rep_dtyp_map.put(0, "Preview");
	rep_dtyp_map.put(1, "File");
	rep_dtyp_map.put(2, "Printer");
	rep_dtyp_map.put(3, "Mail");
	rep_dtyp_map.put(4, "Cache");
	rep_dtyp_map.put(5, "Screen");
	rep_dtyp_map.put(6, "Ftp");
	rep_dtyp_map.put(7, "Webdav");
	rep_dtyp_map.put(8, "BlobDestination");
	rep_dtyp_map.put(9, "OraclePortal");
	rep_dtyp_map.put(10, "OracleWireless");
	rep_dtyp_map.put(11, "SecurePDF");
	rep_dtyp_map.put(12, "PlugDest");
	
	rel_typ_map.put(0,"Join");
	rel_typ_map.put(1,"Ref");
	
	rel_del_map.put(0,"Cascading");
	rel_del_map.put(1,"Isolated");
	rel_del_map.put(2,"Non Isolated");

	if("LIB".equals(type_name)) {
		sb.append("Attached_Libraries:\n");
		printLibraries(fmb.getAttachedLibraries(), fmb2.getAttachedLibraries(), "    ");
	}
	
	if("TRG".equals(type_name)) {
		sb.append("Triggers:\n");
		printTriggers(fmb.getTriggers(), "    ");
		//System.out.println(sb.toString());
	}
	if("BLK".equals(type_name)) {
		sb.append("Data_Blocks:\n");
		printBlocks(fmb.getBlocks(), "    ");
	}
	if("CNV".equals(type_name)) {
		sb.append("Canvases:\n");
		printCanvases(fmb.getCanvases(), "    ");
	}
	if("LOV".equals(type_name)) {
		sb.append("List_Of_Values:\n");
		printLovs(fmb.getLOVs(), "    ");
	}
	if("PRM".equals(type_name)) {
		sb.append("Parameters:\n");
		printParameters(fmb.getModuleParameters(), fmb2.getModuleParameters(), "    ");
	}
	if("PRU".equals(type_name)) {
		sb.append("Program_Units:\n");
		printProgramUnits(fmb.getProgramUnits(), "    ");
	}
	if("RCG".equals(type_name)) {
		sb.append("Record_Groups:\n");
		printRecordGroups(fmb.getRecordGroups(), "    ");
	}
	if("WIN".equals(type_name)) {
		sb.append("Windows:\n");
		printWindows(fmb.getWindows(), "    ");
	}
	if("ALR".equals(type_name)) {
		sb.append("Alerts:\n");
		printAlerts(fmb.getAlerts(), fmb2.getAlerts(), "    ");
	}
	if("EDT".equals(type_name)) {
		sb.append("Editors:\n");
		printEditors(fmb.getEditors(), "    ");
	}
	if("EVT".equals(type_name)) {
		sb.append("Events:\n");
		printEvents(fmb.getEvents(), "    ");
	}
	if("OBG".equals(type_name)) {
		sb.append("Object_Groups:\n");
		printObjectGroups(fmb.getObjectGroups(), "    ");
	}
	if("PUM".equals(type_name)) {
		sb.append("Popup_Menus:\n");
		printPopupMenus(fmb.getMenus(), "    ");
	}
	if("PCS".equals(type_name)) {
		sb.append("Property_Classes:\n");
		printPropertyClasses(fmb.getPropertyClasses(), "    ");
	}
	if("REP".equals(type_name)) {
		sb.append("Reports:\n");
		printReports(fmb.getReports(), "    ");
	}
	if("VAT".equals(type_name)) {
		sb.append("Visual_Attributes:\n");
		printVisualAttributes(fmb.getVisualAttributes(), "    ");
	}
	if("ALL".equals(type_name) || "ALL_NP".equals(type_name)) {
		if("ALL_NP".equals(type_name)) {
			disableWithProperties();
		}
		sb.append("Module:\n");
		sb.append("    Module_Name: "+fmb.getName()+"\n");
		sb.append("    Triggers:\n");
		printTriggers(fmb.getTriggers(), "        ");
		sb.append("    Alerts:\n");
		//printAlerts(fmb.getAlerts(), "        ");
		sb.append("    Attached_Libraries:\n");
		//printLibraries(fmb.getAttachedLibraries(), "        ");
		sb.append("    Data_Blocks:\n");
		printBlocks(fmb.getBlocks(), "        ");
		sb.append("    Canvases:\n");
		printCanvases(fmb.getCanvases(), "        ");
		sb.append("    Editors:\n");
		printEditors(fmb.getEditors(), "        ");
		sb.append("    Events:\n");
		printEvents(fmb.getEvents(), "        ");
		sb.append("    LOVs:\n");
		printLovs(fmb.getLOVs(), "        ");
		sb.append("    Object_Groups:\n");
		printObjectGroups(fmb.getObjectGroups(), "        ");
		sb.append("    Parameters:\n");
		//printParameters(fmb.getModuleParameters(), "        ");
		sb.append("    Popup_Menus:\n");
		printPopupMenus(fmb.getMenus(), "        ");
		sb.append("    Program_Units:\n");
		printProgramUnits(fmb.getProgramUnits(), "        ");
		sb.append("    Property_Classes:\n");
		printPropertyClasses(fmb.getPropertyClasses(), "        ");
		sb.append("    Record_Groups:\n");
		printRecordGroups(fmb.getRecordGroups(), "        ");
		sb.append("    Reports:\n");
		printReports(fmb.getReports(), "        ");
		sb.append("    Visual_Attributes:\n");
		printVisualAttributes(fmb.getVisualAttributes(), "        ");
		sb.append("    Windows:\n");
		printWindows(fmb.getWindows(), "        ");
	}
	if(type_name.length()>5) {
		sb.append("Module_Name: "+fmb.getName()+"\n");
		if("NP".equals(type_name.substring(4,6))){
			 disableWithProperties();
		}
		if("BLK".equals(type_name.substring(0,3))) {			 
			 sb.append("Data_Block_With_Name:\n");
			 printBlockWithName(fmb.getBlocks(),  type_name.substring(7), "        ");
		}
		if("ITM".equals(type_name.substring(0,3))) {			 
			 sb.append("Block_Item_With_Name:\n");	
             sb.append("    - Block_Name : " + type_name.substring(7, type_name.indexOf("."))+"\n");			 
			 printItemWithName(fmb.getBlocks(),  type_name.substring(7, type_name.indexOf(".")),type_name.substring(type_name.indexOf(".")+1),"        ");
		}
		if("TRG".equals(type_name.substring(0,3))) {			 
			 sb.append("Form_Trigger_With_Name:\n");
			 printTriggerWithName(fmb.getTriggers(),  type_name.substring(7), "        ");
		}
		if("TRB".equals(type_name.substring(0,3))) {			 
			 sb.append("Block_Trigger_With_Name:\n");
			 sb.append("    - Block_Name : " + type_name.substring(7, type_name.indexOf("."))+"\n");		
			 printBlockTriggerWithName(fmb.getBlocks(), type_name.substring(7, type_name.indexOf(".")), type_name.substring(type_name.indexOf(".")+1), "        ");
		}
		if("TRI".equals(type_name.substring(0,3))) {			 
			 sb.append("Item_Trigger_With_Name:\n");
			 String block_name =  type_name.substring(7, type_name.indexOf("."));		
             String temp  = type_name.substring(type_name.indexOf(".")+1);
			 String item_name = temp.substring(0, temp.indexOf("."));
			 String trg_name = temp.substring(temp.indexOf(".")+1);
			 sb.append("    - Block_Name : " + block_name+"\n");	
			 sb.append("    - Item_Name : " + item_name+"\n");	
			 printItemTriggerWithName(fmb.getBlocks(), block_name, item_name, trg_name,"        ");
		}
		if("PRU".equals(type_name.substring(0,3))) {			 
			 sb.append("Program_Unit_With_Name:\n");
			 printProgramUnitWithName(fmb.getProgramUnits(),  type_name.substring(7), "        ");
		}
		if("LOV".equals(type_name.substring(0,3))) {			 
			 sb.append("LOV_With_Name:\n");
			 printLOVWithName(fmb.getLOVs(),  type_name.substring(7), "        ");
		}
		if("RCG".equals(type_name.substring(0,3))) {			 
			 sb.append("RG_With_Name:\n");	
			 printRecordGroupWithName(fmb.getRecordGroups(),  type_name.substring(7), "        ");
		}
	}
	System.out.println(sb.toString());
	System.out.println("--------------");
	System.out.println(sb2.toString());
	Jdapi.shutdown();
	}
}