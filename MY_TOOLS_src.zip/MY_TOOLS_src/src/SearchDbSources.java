import java.io.*;
import java.util.Map;
import java.util.HashMap;
import java.nio.charset.*;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
public class SearchDbSources {
    public static void main(String args[]) {  
		Map<String,Object> result = new HashMap<String, Object>();
		StringBuilder sb = new StringBuilder();
		Connection mConn = null;
        PreparedStatement mPst;
		try {	
			String conn_str = args[0];
		    String user = args[1];
		    String pass = args[2];
			String o_type = args[3];
			int len = args.length;
			if(len>9) {
				throw new Exception("En fazla 9 parametre kabul edilmektedir. G�nderilen:"+len);
			}
			
			String o_name = "%"+args[4]+"%"; 
			/*for(int i=4; i<len; i++) {
				o_name += args[i];
				if(i!=(len-1)) {
					//o_name += "'||CHR(32)||'";
					o_name += " ";
				} 
			}*/
			
			
			
			
			//System.out.println("aranan:"+o_name+":");
								
		    Class.forName("oracle.jdbc.driver.OracleDriver");
			String script = "SELECT NAME,LINE,TEXT FROM all_source where OWNER='CUSTOMER' AND REPLACE(TYPE,' ','_')=? and lower(text) like lower(?)";			
			mConn = DriverManager.getConnection(conn_str, user, pass);
			if(mConn == null || mConn.isClosed()) {
				throw new Exception("Ba�lant� Kurulamad�");
			}			
			//System.out.println("script:"+script+":");
			mPst =  mConn.prepareStatement(script);		
            mPst.setString(1, o_type); //OBJECT_TYPE
			mPst.setString(2, o_name); //OBJECT_NAME 			
		    ResultSet rSet = mPst.executeQuery();	
	        String obj_name = "TMP";
			String tmp = "TMP";
			Long line_number = Long.parseLong("0");
			String obj_text = "";
			int line_count = 0;
			String lines = "";
		
			while(rSet.next()) {
				
				obj_name = rSet.getString("NAME");
				if("TMP".equals(tmp)) {
					tmp = obj_name;
				}
				line_number = rSet.getLong("LINE");
				obj_text = rSet.getString("TEXT");
				lines = lines + "<li>"+line_number+" : "+obj_text+"</li>";
				line_count++;
				
				if(!tmp.equals(obj_name)) {
					tmp = obj_name;		
                    sb.append("<tr><td>"+tmp+"</td><td>"+line_count+"</td><td><ul>"+lines+"</ul></td></tr>\n");
					line_count = 0;
                    lines = "";						                     					
				}
												
			}
			             		
			mPst.close();
			
			//System.out.println(status);
		} catch(Exception e) {
			e.printStackTrace();
			//result.put("result","ERR:"+e.getMessage());
			sb.append("ERR:"+e.getMessage());
		} finally {
			//sb.append(result.get("result"));
			System.out.println(sb.toString());		
           	try{
				if(mConn != null) {
				   mConn.close();
				}
			} catch(Exception e2){
				sb.append("ERR2:"+e2.getMessage());
			}		
		}
	}

}