DECLARE 
   v_hltprv_Log          Hltprv_Log_Typ := Hltprv_Log_Typ();                   
   v_request CLOB;
   v_response CLOB;
   v_url VARCHAR2(200) := --'http://10.70.47.25:19101/hclm-health-claim-service/api/v1/provision/createProvision';
                          --'http://esb.allianz.com.tr:12000/hclm-service/api/v1/provision/createProvision'; 
                          --'http://10.70.47.55:19101/hclm-health-claim-service/api/v1/provision/createProvision';
                          get_url_link('http://esb.allianz.com.tr:12000/hclm-health-claim-service/api/v1/computeremaining/list');
   v_status NUMBER;
   v_message VARCHAR2(1000); 
   v_institute_code NUMBER := 337;
   v_ndx1 NUMBER;
   v_ndx2 NUMBER;
   
   TYPE CoverInfoParamRec IS RECORD(
         Cover_Code            VARCHAR2(10),
         Provision_Amount       NUMBER,
         Day_Seance            NUMBER,         
         Exemption_Over_Amount NUMBER,
         Is_Pool_Cover            NUMBER,
         Is_Special_Cover         NUMBER);
   
   TYPE CoverInfoParamTyp IS TABLE OF CoverInfoParamRec INDEX BY BINARY_INTEGER;
      
   coverList coverInfoParamTyp;   
   
    TYPE ProvOutParamRec IS RECORD(
          Cover_Code                 VARCHAR2(10),    
          Provision_Amount           NUMBER,
          Day_Seance                 NUMBER,
          Exemption_Rate             NUMBER,
          Exemption_Sum              NUMBER,
          Inst_Exemp_Sum             NUMBER,
          Remained_Day_Seance        NUMBER,
          Remained_Cover_Price       NUMBER,         
          Over_Price                 NUMBER);
          
   TYPE ProvOutParamTyp IS TABLE OF ProvOutParamRec INDEX BY BINARY_INTEGER;
          
   ProvOutList ProvOutParamTyp;
  
   v_cover_list CLOB;
   
   FUNCTION booleanToString(p_boolean IN NUMBER) RETURN VARCHAR2 IS
    BEGIN
        RETURN (CASE NVL(p_boolean, 0) WHEN 1 THEN 'true' ELSE 'false' END);
    END booleanToString;
    
    FUNCTION numberToString(p_number IN NUMBER) RETURN VARCHAR2 IS
        v_string VARCHAR2(100);
    BEGIN
        v_string := REPLACE(TO_CHAR(p_number),',','.');
        IF INSTR(v_string,'.') = 1 THEN
           v_string := '0'||v_string;
        END IF;
        RETURN v_string;
    END numberToString;
     FUNCTION stringToNumber(p_string IN VARCHAR2) RETURN NUMBER IS
    BEGIN
       IF NVL(p_string, 'null') = 'null' THEN
          RETURN NULL;
       END IF;
       RETURN TO_NUMBER(p_string,'999999.9999');
    END stringToNumber;
BEGIN       
    coverList(1).Cover_Code := 'S511';
    coverList(1).Day_Seance := 0;
    coverList(1).Provision_Amount := 0;
    coverList(1).Exemption_Over_Amount := 0;
    coverList(1).Is_Pool_Cover := 0;
    coverList(1).Is_Special_Cover := 0;
    
    coverList(2).Cover_Code := 'S534';
    coverList(2).Provision_Amount := 0;
    coverList(2).Day_Seance := 0;
    coverList(2).Exemption_Over_Amount := 0;
    coverList(2).Is_Pool_Cover := 0;
    coverList(2).Is_Special_Cover := 0;
    v_cover_list := '';
    FOR ndx IN 1..coverList.COUNT LOOP       
        IF ndx>1 THEN
           v_cover_list := v_cover_list || ',';
        END IF;
        v_cover_list := v_cover_list || '{
              "coverCode" : "'||coverList(ndx).Cover_Code||'",
              "daySeance" : "'||TO_CHAR(NVL(coverList(ndx).Day_Seance,0))||'",
              "exemptionOverAmount" : "'||numberToString(NVL(coverList(ndx).Exemption_Over_Amount,0))||'",
              "poolCover" : "'||booleanToString(coverList(ndx).Is_Pool_Cover)||'",
              "provisionAmount" : "'||numberToString(NVL(coverList(ndx).Provision_Amount,0))||'",
              "specialCover" : "'||booleanToString(coverList(ndx).Is_Special_Cover)||'"   
        }';        
    END LOOP;
    --DBMS_OUTPUT.PUT_LINE(v_cover_list);
    v_request := '{
                "claimInstLoc" : "YI",
                "claimInstType" : "AK",
                "countryGroup" : "0",
                "contractId" : "410654615",
                "coverInfoParamList": ['||v_cover_list||'],
                "instituteCode" : "13",
                "invoiceDate" : "2019-03-18T00:00:00.000Z",
                "partitionNo" : "2",
                "partnerId" : "37210705",
                "policyGroupCode" : "S9531",
                "policyStartDate" : "2018-09-01T00:00:00.000Z",
                "queryDate" : "2019-03-18T00:00:00.000Z",
                "realizationDate" : "2019-03-18T00:00:00.000Z",
                "referral" : "false",
                "swiftCode": "TL",
                "userGroup": ["1","2","3","4"]
            }';
            
         ALZ_HCLM_CONVERTER_UTILS.callRestService(v_url, 'POST', v_request, v_response, v_status, v_message);
         --DBMS_OUTPUT.PUT_LINE(v_response); 
         
         IF v_status = 0 THEN
           v_ndx1 := INSTR(v_response,'{"data" : {');
           v_ndx2 := INSTR(v_response,'},"uiMessages"') - v_ndx1;         
           v_response := SUBSTR(v_response, v_ndx1+11, v_ndx2-11);          
         ELSE 
           v_ndx1 := INSTR(v_response,'{"errors" : [');
           v_ndx2 := INSTR(v_response,'],"warnings"') - v_ndx1;           
           v_response := SUBSTR(v_response, v_ndx1+15, v_ndx2-17);           
         END IF;
         v_response := replace(replace(replace(replace(v_response,'[{', ''),'}',''),'}]',''),'{',''); 
         --DBMS_OUTPUT.PUT_LINE(v_response);     
         v_ndx1 := 0;
         FOR rec IN (SELECT TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1) , '"',''))   KEY, 
                            TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1, 2), '"','')) VALUE1,
                            TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1, 3), '"','')) VALUE2              
                     FROM (SELECT Regexp_Substr (v_response, '[^,]+', 1, LEVEL) ELEMENT
                             FROM Dual
                          CONNECT BY LEVEL <= LENGTH (Regexp_Replace (v_response, '[^,]+')) + 1)) LOOP 
              --DBMS_OUTPUT.PUT_LINE(rec.KEY||':'||rec.VALUE1||':'||rec.VALUE2);
              
              IF rec.KEY = 'message' THEN
                v_message := rec.value1;
              END IF;
              
              IF rec.VALUE2 IS NOT NULL THEN                  
                  IF rec.VALUE1 = 'provisionAmount' THEN
                      v_ndx1 := v_ndx1 + 1;                      
                      ProvOutList(v_ndx1).Provision_Amount := stringToNumber(rec.VALUE2);
                      ProvOutList(v_ndx1).Cover_Code       := rec.KEY;
                  END IF;
              END IF;  
              
              IF rec.KEY = 'daySeance' THEN             
                  ProvOutList(v_ndx1).Day_Seance := stringToNumber(rec.VALUE1);
              END IF;
              IF rec.KEY = 'exemptionRate' THEN
                  ProvOutList(v_ndx1).Exemption_Rate := stringToNumber(rec.VALUE1);
              END IF;              
              IF rec.KEY = 'exemptionSumAmount' THEN
                 ProvOutList(v_ndx1).Exemption_Sum := stringToNumber(rec.VALUE1);
              END IF;
              IF rec.KEY = 'instituteExemptionSumAmount' THEN
                  ProvOutList(v_ndx1).Inst_Exemp_Sum := stringToNumber(rec.VALUE1);
              END IF;
              IF rec.KEY = 'overPriceAmount' THEN
                  ProvOutList(v_ndx1).Over_Price := stringToNumber(rec.VALUE1);
              END IF;    
              
              IF rec.KEY = 'remainedCoverPriceAmount' THEN
                  ProvOutList(v_ndx1).Remained_Cover_Price := stringToNumber(rec.VALUE1);
              END IF;
              IF rec.KEY = 'remainedDaySeance' THEN
                  ProvOutList(v_ndx1).Remained_Day_Seance := stringToNumber(rec.VALUE1);
              END IF;                                             
        END LOOP;
        IF v_status = 1 THEN 
           Raise_Application_Error(-20200,  v_message);
        END IF; 
        DBMS_OUTPUT.PUT_LINE('count='||ProvOutList.COUNT);
        FOR ndx IN 1..ProvOutList.COUNT LOOP           
            DBMS_OUTPUT.PUT_LINE(ndx||'.out_prov_amo='||ProvOutList(ndx).Provision_Amount);
            DBMS_OUTPUT.PUT_LINE(ndx||'.day_seance='||ProvOutList(ndx).Day_Seance);
            DBMS_OUTPUT.PUT_LINE(ndx||'.cover='||ProvOutList(ndx).Cover_Code);
        END LOOP;
       DBMS_OUTPUT.PUT_LINE('SUCCESS:'||v_message);
END;           
        
