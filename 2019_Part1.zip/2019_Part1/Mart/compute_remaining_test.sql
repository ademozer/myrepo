DECLARE
     p_Out_Provision_Amount  NUMBER;
     p_Out_Day_Seance        NUMBER;
     p_Out_Exemption_Rate    NUMBER;
     p_Out_Exemption_Sum     NUMBER;
     p_Out_Inst_Exemp_Sum    NUMBER;
     p_r_Day_Seance          NUMBER;
     p_r_Cover_Price         NUMBER;
     p_Out_Over_Price        VARCHAR2(200);
     v_request CLOB;
     v_response CLOB;
     v_url VARCHAR2(200) := get_url_link('http://esb.allianz.com.tr:12000/hclm-health-claim-service/api/v1/computeremaining/list');
     v_status NUMBER;
     v_message VARCHAR2(1000);
     v_cover_info VARCHAR2(32000);
     v_user_group VARCHAR2(32000);
     v_ndx NUMBER:=0;
     v_ndx1      NUMBER;
     v_ndx2      NUMBER;
     
    FUNCTION booleanToString(p_boolean IN NUMBER) RETURN VARCHAR2 IS
    BEGIN
        RETURN (CASE NVL(p_boolean, 0) WHEN 1 THEN 'true' ELSE 'false' END);
    END booleanToString;

    FUNCTION dateToString(p_date IN DATE) RETURN VARCHAR2 IS
          v_date  DATE;
          v_timestamp TIMESTAMP;
          v_return VARCHAR2(100);
    BEGIN
        v_return := '';
        v_date := p_date;
        IF v_date IS NOT NULL THEN
           v_timestamp := CAST (v_date AS TIMESTAMP);
           v_return := TO_CHAR(v_date,'YYYY-MM-DD')||'T'||TO_CHAR(v_timestamp,'HH24:MI:SS.FF3')||'Z';
        END IF;
        RETURN v_return;
    END dateToString;

    FUNCTION numberToString(p_number IN NUMBER) RETURN VARCHAR2 IS
        v_string VARCHAR2(100);
    BEGIN
        v_string := REPLACE(TO_CHAR(p_number),',','.');
        IF INSTR(v_string,'.') = 1 THEN
           v_string := '0'||v_string;
        END IF;
        RETURN v_string;
    END numberToString;

    FUNCTION stringToNumber(p_string IN VARCHAR2) RETURN NUMBER IS
    BEGIN
       IF NVL(p_string, 'null') = 'null' THEN
          RETURN NULL;  
       END IF;
       RETURN TO_NUMBER(p_string,'999999.9999');
    END stringToNumber;
BEGIN
  
v_request := '{
            "contractId" : "410654615",
            "coverInfoParamList": [
              {
                "coverCode" : "S741",
                "daySeance" : "0",
                "exemptionOverAmount" : "0",
                "poolCover" : "false",
                "provisionAmount" : "251.5",
                "specialCover" : "false"
              }
            ],
            "instituteCode" : "13",
            "invoiceDate" : "2019-03-07T03:00:00.000Z",
            "partitionNo" : "2",
            "partnerId" : "37210705",
            "policyGroupCode" : "S9531",
            "policyStartDate" : "2018-09-01T00:00:00.000Z",
            "queryDate" : "2019-03-07T03:00:00.000Z",
            "realizationDate" : "2019-03-07T03:00:00.000Z",
            "referral" : "false",
            "swiftCode": "TL",
            "userGroup": ["1","2","3","4"]
        }';
        
ALZ_HCLM_CONVERTER_UTILS.callRestService(v_url, 'POST', v_request, v_response, v_status, v_message);   

 IF v_status = 0 THEN
             v_ndx1 := INSTR(v_response,'{"data" : {');
             v_ndx2 := INSTR(v_response,'},"uiMessages"') - v_ndx1;
             v_response := SUBSTR(v_response, v_ndx1+11, v_ndx2-11);
         ELSE
             v_ndx1 := INSTR(v_response,'{"errors" : [');
             v_ndx2 := INSTR(v_response,'],"warnings"') - v_ndx1;
             v_response := SUBSTR(v_response, v_ndx1+15, v_ndx2-17);
         END IF;

         v_response := replace(replace(replace(replace(v_response,'[{', ''),'}',''),'}]',''),'{','');

         FOR rec IN (SELECT TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1) , '"',''))   KEY,
                            TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1, 2), '"','')) VALUE
                       FROM (SELECT Regexp_Substr (v_response, '[^,]+', 1, LEVEL) ELEMENT
                               FROM Dual
                            CONNECT BY LEVEL <= LENGTH (Regexp_Replace (v_response, '[^,]+')) + 1)) LOOP
              IF rec.KEY = 'message' THEN
                  v_message := rec.VALUE;
              END IF;
              IF rec.KEY = 'daySeance' THEN
                  p_Out_Day_Seance := stringToNumber(rec.VALUE);
              END IF;
              IF rec.KEY = 'exemptionRate' THEN
                  p_Out_Exemption_Rate := stringToNumber(rec.VALUE);
              END IF;
              IF rec.KEY = 'exemptionSumAmount' THEN
                  p_Out_Exemption_Sum := stringToNumber(rec.VALUE);
              END IF;
              IF rec.KEY = 'instituteExemptionSumAmount' THEN
                  p_Out_Inst_Exemp_Sum := stringToNumber(rec.VALUE);
              END IF;
              IF rec.KEY = 'overPriceAmount' THEN
                  p_Out_Over_Price := rec.VALUE;
              END IF;
              IF rec.KEY = 'provisionAmount' THEN
                  p_Out_Provision_Amount := stringToNumber(rec.VALUE);
              END IF;
              IF rec.KEY = 'remainedCoverPriceAmount' THEN                 
                  p_r_Cover_Price := stringToNumber(rec.VALUE);
              END IF;
              IF rec.KEY = 'remainedDaySeance' THEN
                  p_r_Day_Seance := stringToNumber(rec.VALUE);
              END IF;
         END LOOP;
        DBMS_OUTPUT.PUT_LINE( 'remainedCoverPriceAmount='||p_r_Cover_Price);
        DBMS_OUTPUT.PUT_LINE(v_response);  
         p_Out_Over_Price := dateToString(null);
          DBMS_OUTPUT.PUT_LINE( 'remainedCoverPriceAmount2='||p_Out_Over_Price);
         IF v_status = 1 THEN
             Raise_Application_Error(-20200,  v_message);
         END IF;

     EXCEPTION
     WHEN OTHERS THEN      
          DBMS_OUTPUT.PUT_LINE('Limit Hesaplama S�ras�nda Bir Hata Olu�tu:'||v_message);   
     END;   
        
        
