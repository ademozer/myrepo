DECLARE
     p_Out_Provision_Amount  NUMBER;
     p_Out_Day_Seance        NUMBER;
     p_Out_Exemption_Rate    NUMBER;
     p_Out_Exemption_Sum     NUMBER;
     p_Out_Inst_Exemp_Sum    NUMBER;
     p_r_Day_Seance          NUMBER;
     p_r_Cover_Price         NUMBER;
     p_Out_Over_Price        VARCHAR2(200);
     v_request CLOB;
     v_response CLOB;
     v_url VARCHAR2(200) := get_url_link('http://esb.allianz.com.tr:12000/hclm-health-claim-service/api/v1/computeremaining/list');
     v_status NUMBER;
     v_message VARCHAR2(1000);
     v_cover_info VARCHAR2(32000);
     v_user_group VARCHAR2(32000);
     v_ndx NUMBER:=0;
     v_ndx1      NUMBER;
     v_ndx2      NUMBER;
     p_Out_Param_List     ALZ_HCLM_CONVERTER_UTILS.ProvOutParamTyp;
     v_step VARCHAR2(100);
    FUNCTION booleanToString(p_boolean IN NUMBER) RETURN VARCHAR2 IS
    BEGIN
        RETURN (CASE NVL(p_boolean, 0) WHEN 1 THEN 'true' ELSE 'false' END);
    END booleanToString;

    FUNCTION dateToString(p_date IN DATE) RETURN VARCHAR2 IS
          v_date  DATE;
          v_timestamp TIMESTAMP;
          v_return VARCHAR2(100);
    BEGIN
        v_return := '';
        v_date := p_date;
        IF v_date IS NOT NULL THEN
           v_timestamp := CAST (v_date AS TIMESTAMP);
           v_return := TO_CHAR(v_date,'YYYY-MM-DD')||'T'||TO_CHAR(v_timestamp,'HH24:MI:SS.FF3')||'Z';
        END IF;
        RETURN v_return;
    END dateToString;

    FUNCTION numberToString(p_number IN NUMBER) RETURN VARCHAR2 IS
        v_string VARCHAR2(100);
    BEGIN
        v_string := REPLACE(TO_CHAR(p_number),',','.');
        IF INSTR(v_string,'.') = 1 THEN
           v_string := '0'||v_string;
        END IF;
        RETURN v_string;
    END numberToString;

    FUNCTION stringToNumber(p_string IN VARCHAR2) RETURN NUMBER IS
    BEGIN
       IF NVL(p_string, 'null') = 'null' THEN
          RETURN NULL;  
       END IF;
       DBMS_OUTPUT.PUT_LINE('tutar='||p_string);
       RETURN TO_NUMBER(p_string,'999999999.9999');
    END stringToNumber;
    
        procedure callRestService(p_Url               In          Varchar2,
                              p_Method            In          Varchar2,                                                                           
                              p_Request           In          Clob,                    
                              p_Response          Out         Clob, 
                              p_Status            Out         Number, 
                              p_Message           Out         Varchar2) IS 
                              
        v_Req               utl_http.req;
        v_Req_Length        Number;
        v_Res               utl_http.resp;
        v_Buffer            Varchar2(32767);
        v_Offset            Number := 1;
        v_Amount            Number :=32767;
        v_Utl_Err           Varchar2(1000);
        v_value             varchar2(4000);
        hata_code           varchar2(10);
        v_output            varchar2(10);
        v_Response          CLOB;
        v_Line_Number       NUMBER := 0;
        
        Begin
          
            v_Req_Length := dbms_lob.getlength(p_Request);
            v_Req := utl_http.begin_request(p_Url, p_Method, 'HTTP/1.1');                 
            utl_http.set_header(v_Req, 'Content-Length', v_Req_Length);
            utl_http.set_header(v_Req, 'Content-Type', 'application/json;charset=UTF-8');
            utl_http.set_header(v_Req, 'Transfer-Encoding', 'chunked' );
            utl_http.set_header(v_Req, 'Hclm-Channel', 'HCLM' );
            utl_http.set_transfer_timeout(300);
            utl_http.set_body_charset(v_Req,'UTF-8');           
                        
            While (v_Offset < v_Req_Length)
            Loop
               dbms_lob.read(p_Request, v_Amount, v_Offset, v_Buffer);
               utl_http.write_text(r    => v_Req, data => v_Buffer);
               v_Offset := v_Offset + v_Amount;
            End Loop;
            
            v_Res := utl_http.get_response(v_Req);
            p_status := 0;
            p_message := v_Res.status_code || ':' || v_Res.reason_phrase;
            IF v_Res.status_code != 200  THEN                
                p_Status := 1;                                          
            END IF;             
            Begin              
               loop                 
                  utl_http.read_line(v_Res, v_value);
                  v_value := TRIM(regexp_replace(v_value, '([^[:graph:] | ^[:blank:]])', ''));
                  v_Response := v_Response || v_value;                                                    
               end loop;               
               utl_http.end_response(v_Res);               
            Exception              
            When utl_http.end_of_body Then
                 utl_http.end_response(v_Res);
            When utl_http.too_many_requests Then
                 utl_http.end_response(v_Res);
            When Others Then
                 utl_http.end_response(v_Res);
           End;                    
           p_Response := TRIM(v_Response); 
           IF INSTR(p_Response,'"errors"')>0 THEN
               p_Status := 1;
               p_message := 'Business Exception';
           END IF;                              
        EXCEPTION 
           WHEN OTHERS THEN
              utl_http.end_response(v_Res);
              v_utl_err:= Utl_Http.Get_Detailed_Sqlerrm;
              p_Status := 1;
              p_Response := '';
              p_Message := v_utl_err||' - '||p_url;              
    END callRestService;
BEGIN
  
v_request := /*'{
            "claimInstLoc" : "YI",
            "claimInstType" : "AHK",
            "countryGroup" : "0",
            "contractId" : "453914451",
            "coverInfoParamList" : [{
                    "coverCode" : "S693",
                    "daySeance" : "0",
                    "exemptionOverAmount" : "0",
                    "poolCover" : "true",
                    "provisionAmount" : "0",
                    "specialCover" : "false"
              }],
            "instituteCode" : "132740",
            "invoiceDate" : "2019-02-23T00:00:00.000Z",
            "partitionNo" : "7494",
            "partnerId" : "11320667",
            "policyGroupCode" : "S16185",
            "policyStartDate" : "2019-02-15T00:00:00.000Z",
            "queryDate" : "2019-02-23T00:00:00.000Z",
            "realizationDate" : "2019-02-23T00:00:00.000Z",
            "referral" : "false",
            "swiftCode": "TL",
            "userGroup": ["1","2","3","4"]
        }';*/
        '{
            "claimInstLoc" : "YI",
            "claimInstType" : "AHK",
            "countryGroup" : "0",
            "contractId" : "395511839",
            "coverInfoParamList" : [{
                    "coverCode" : "S504",
                    "daySeance" : "0",
                    "exemptionOverAmount" : "0",
                    "poolCover" : "false",
                    "provisionAmount" : "0",
                    "specialCover" : "false"
              }],
            "instituteCode" : "20000",
            "invoiceDate" : "2019-04-02T00:00:00.000Z",
            "partitionNo" : "1586",
            "partnerId" : "40102642",
            "policyGroupCode" : "S6880",
            "policyStartDate" : "2018-06-15T00:00:00.000Z",
            "queryDate" : "2019-04-02T00:00:00.000Z",
            "realizationDate" : "2019-04-02T00:00:00.000Z",
            "referral" : "false",
            "swiftCode": "TL",
            "userGroup": ["1","2","3","4"]
        }';
        v_step:='A';
CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.callRestService(v_url, 'POST', v_request, v_response, v_status, v_message);   
v_step:='B';
DBMS_OUTPUT.PUT_LINE(v_response);
 IF v_status = 0 THEN
             v_ndx1 := INSTR(v_response,'{"data" : {');
             v_ndx2 := INSTR(v_response,'},"uiMessages"') - v_ndx1;
             v_response := SUBSTR(v_response, v_ndx1+11, v_ndx2-11);
         ELSE
             v_ndx1 := INSTR(v_response,'{"errors" : [');
             v_ndx2 := INSTR(v_response,'],"warnings"') - v_ndx1;
             v_response := SUBSTR(v_response, v_ndx1+15, v_ndx2-17);
         END IF;

         v_response := replace(replace(replace(replace(v_response,'[{', ''),'}',''),'}]',''),'{','');

         FOR rec IN (SELECT TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1) , '"',''))   KEY,
                            TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1, 2), '"','')) VALUE1,
                            TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1, 3), '"','')) VALUE2
                     FROM (SELECT Regexp_Substr (v_response, '[^,]+', 1, LEVEL) ELEMENT
                             FROM Dual
                          CONNECT BY LEVEL <= LENGTH (Regexp_Replace (v_response, '[^,]+')) + 1)) LOOP

              IF rec.KEY = 'message' THEN
                v_message := rec.value1;
              END IF;
              v_step := '1';
              IF rec.VALUE2 IS NOT NULL THEN
                  IF rec.VALUE1 = 'provisionAmount' THEN
                      v_ndx1 := v_ndx1 + 1;
                      p_Out_Param_List(v_ndx1).Provision_Amount := stringToNumber(rec.VALUE2);
                      p_Out_Param_List(v_ndx1).Cover_Code       := rec.KEY;
                  END IF;
              END IF;
               v_step := '2';
              IF rec.KEY = 'daySeance' THEN
                  p_Out_Param_List(v_ndx1).Day_Seance := stringToNumber(rec.VALUE1);
              END IF;
               v_step := '3';
              IF rec.KEY = 'exemptionRate' THEN
                  p_Out_Param_List(v_ndx1).Exemption_Rate := stringToNumber(rec.VALUE1);
              END IF;
               v_step := '4';
              IF rec.KEY = 'exemptionSumAmount' THEN
                  p_Out_Param_List(v_ndx1).Exemption_Sum := stringToNumber(rec.VALUE1);
              END IF;
               v_step := '5'; 
              IF rec.KEY = 'instituteExemptionSumAmount' THEN
                  p_Out_Param_List(v_ndx1).Inst_Exemp_Sum := stringToNumber(rec.VALUE1);
              END IF;
               v_step := '6';  
              IF rec.KEY = 'overPriceAmount' THEN
                  p_Out_Param_List(v_ndx1).Over_Price := stringToNumber(rec.VALUE1);
              END IF;
               v_step := '7';
              IF rec.KEY = 'remainedCoverPriceAmount' THEN
                  p_Out_Param_List(v_ndx1).Remained_Cover_Price := stringToNumber(rec.VALUE1);
              END IF;
               v_step := '8';
              IF rec.KEY = 'remainedDaySeance' THEN
                  p_Out_Param_List(v_ndx1).Remained_Day_Seance := stringToNumber(rec.VALUE1);
              END IF;

        END LOOP;

        IF v_status = 1 THEN
           Raise_Application_Error(-20200,  v_message);
        END IF;
        
     EXCEPTION
     WHEN OTHERS THEN      
          v_message := v_message || SQLERRM || ' step:'||v_step;
          DBMS_OUTPUT.PUT_LINE('Limit Hesaplama S�ras�nda Bir Hata Olu�tu:'||v_message);   
     END;   
        
        
