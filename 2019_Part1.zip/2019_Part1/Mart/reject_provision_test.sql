DECLARE
         v_request CLOB;
         v_response CLOB;
         v_url VARCHAR2(200) := 'http://10.70.47.55:19101/hclm-health-claim-service/api/v1/provision/rejectProvision'; 
         v_status NUMBER;
         v_message VARCHAR2(1000);
         v_ndx1 NUMBER;
         v_ndx2 NUMBER;  
         v_result VARCHAR2(1000);   
BEGIN
  v_request := '{
                  "addOrderNo": 1,
                  "cancelRejectReason": "HCLM Test",
                  "claimId": 38747721,
                  "contractId": 395511839,
                  "instituteCode": 175,
                  "partitionNo": 2009,
                  "sfNo": 1
                }';

 ALZ_HCLM_CONVERTER_UTILS.callRestService(v_url, 'POST', v_request, v_response, v_status, v_message);
       
       DBMS_OUTPUT.PUT_LINE(v_response);
       DBMS_OUTPUT.PUT_LINE(v_status);
       DBMS_OUTPUT.PUT_LINE(v_message);
       
         
         IF v_status = 0 THEN
             v_message := NULL;
             v_ndx1 := INSTR(v_response,'{"data" : {');
             v_ndx2 := INSTR(v_response,',"uiMessages"') - v_ndx1;
             v_response := SUBSTR(v_response, v_ndx1+11, v_ndx2-12);
         ELSE
             v_ndx1 := INSTR(v_response,'{"errors" : [');
             v_ndx2 := INSTR(v_response,'],"warnings"') - v_ndx1;
             v_response := SUBSTR(v_response, v_ndx1+15, v_ndx2-17);
         END IF;
         --DBMS_OUTPUT.PUT_LINE(v_response);
         FOR rec IN (SELECT TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1) , '"',''))   KEY,
                            TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1, 2), '"','')) VALUE
                       FROM (SELECT Regexp_Substr (v_response, '[^,]+', 1, LEVEL) ELEMENT
                               FROM Dual
                            CONNECT BY LEVEL <= LENGTH (Regexp_Replace (v_response, '[^,]+')) + 1)) LOOP
             IF rec.KEY IN('errorMessage','message') THEN
                 v_message := rec.value;
             END IF;
             IF rec.KEY IN ('succesCancellation') THEN
                 v_result := rec.value;
             END IF;
         END LOOP;
         IF ((v_message IS NOT NULL AND v_status = 0) OR v_status = 1) THEN
             DBMS_OUTPUT.PUT_LINE('BizEx '||v_message || ' - '||v_result);
         ELSE 
             DBMS_OUTPUT.PUT_LINE(v_message || ' - '||v_result);
         END IF;                 
END;
