declare
   v_out_provision_amount NUMBER;
   v_out_day_seance NUMBER;
   v_out_exemption_rate NUMBER;
   v_out_exemption_sum NUMBER;
   v_out_inst_exemp_sum NUMBER;
   v_r_day_seance NUMBER;
   v_r_cover_price NUMBER;
   v_inst_provision_aval_code VARCHAR2(100);
   v_inst_is_cover_val NUMBER;
   v_out_over_price VARCHAR2(100);

begin
  -- Call the procedure
  
  /*
   procedure computeRemaining(p_Contract_Id           IN NUMBER,
                             p_Partition_No          IN NUMBER,
                             p_Institute_Code        IN NUMBER,
                             p_Claim_Inst_Type       IN VARCHAR2 DEFAULT NULL,
                             p_Claim_Inst_Loc        IN VARCHAR2 DEFAULT NULL,
                             p_Country_Group         IN VARCHAR2 DEFAULT NULL,
                             p_Cover_Code            IN VARCHAR2,
                             p_Swift_Code            IN VARCHAR2,
                             p_Query_Date            IN DATE,
                             p_Provision_Amount      IN NUMBER,
                             p_Day_Seance            IN NUMBER,
                             p_Is_Pool_Cover         IN NUMBER,
                             p_Is_Special_Cover      IN NUMBER,
                             p_Exemption_Ovr_Amount  IN NUMBER DEFAULT NULL,
                             p_Is_Referral           IN NUMBER DEFAULT NULL,
                             p_User_Id               IN VARCHAR2,
                             p_Out_Provision_Amount OUT NUMBER,
                             p_Out_Day_Seance       OUT NUMBER,
                             p_Out_Exemption_Rate   OUT NUMBER,
                             p_Out_Exemption_Sum    OUT NUMBER,
                             p_Out_Inst_Exemp_Sum   OUT NUMBER,
                             p_r_Day_Seance         OUT NUMBER,
                             p_r_Cover_Price        OUT NUMBER,
                             p_Out_Over_Price       OUT VARCHAR2) IS
  */
  customer.ALZ_HCLM_CONVERTER_UTILS.computeRemaining(p_contract_id => 383164557,
                                             p_partition_no => 1,
                                              p_institute_code => 323,                                                                                                                            
                                             p_claim_inst_type => 'AK',
                                             p_claim_inst_loc => 'YI',
                                             p_country_group => 0,                                            
                                             p_cover_code => 'S511',
                                             p_swift_code => 'TL',
                                             p_query_date => SYSDATE,                                            
                                             p_provision_amount => 206.55,
                                             p_day_seance => 0,
                                             p_is_pool_cover => 0,
                                             p_is_special_cover => 0,
                                             p_user_id => 'MEDISER28',
                                             p_exemption_ovr_amount => null,
                                             p_is_referral => null,                                          
                                             p_out_provision_amount => v_out_provision_amount,
                                             p_out_day_seance => v_out_day_seance,
                                             p_out_exemption_rate => v_out_exemption_rate,
                                             p_out_exemption_sum => v_out_exemption_sum,
                                             p_out_inst_exemp_sum => v_out_inst_exemp_sum,
                                             p_r_day_seance => v_r_day_seance,
                                             p_r_cover_price => v_r_cover_price,                                            
                                             p_out_over_price => v_out_over_price
                                            );
DBMS_OUTPUT.PUT_LINE('p_prov_amo='||v_out_provision_amount);
DBMS_OUTPUT.PUT_LINE('p_day_seans='||v_out_day_seance);
DBMS_OUTPUT.PUT_LINE('p_exemp_rate='||v_out_exemption_rate);
DBMS_OUTPUT.PUT_LINE('p_exemp_sum='||v_out_exemption_sum);
DBMS_OUTPUT.PUT_LINE('p_inst_ex_sm='||v_out_inst_exemp_sum);
DBMS_OUTPUT.PUT_LINE('r_day_seans='||v_r_day_seance);
DBMS_OUTPUT.PUT_LINE('r_cov_price='||v_r_cover_price);
DBMS_OUTPUT.PUT_LINE('p_aval_code='||v_inst_provision_aval_code);
DBMS_OUTPUT.PUT_LINE('inst_cover_val='||v_inst_is_cover_val);
DBMS_OUTPUT.PUT_LINE('out_over_price='||v_out_over_price);


end;
