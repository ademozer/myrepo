SELECT
    /*OCQPOL.CONTRACT_ID,
    OCQPOL.POL_STATUS SRC_TYPE,
    ALZD.DOCUMENT_ID,  
    ALZD.DOCUMENT_NAME,  
    ALZD.DOCUMENT_TYPE,
    ALZD.EXPLANATION,  
    ALZD.VALIDITY_START_DATE,  
    ALZD.VALIDITY_END_DATE,
    ALZD.CREATE_DATE,  
    ALZD.CREATED_BY,  
    ALZD.DOCUMENT_GROUP_ID,  
    ALZD.CONTENT_TYPE,  
    ALZD.IS_ORIGINAL,
    'TODO' MIG_STATUS*/
    count(*)
    FROM (
      SELECT DISTINCT 'OCQ' AS POL_STATUS, WC.CONTRACT_ID, WV.AUTH_DOCUMENT_GROUP_ID
        FROM OCQ_KOC_OCP_POL_VERSIONS_EXT WV, OCQ_KOC_OCP_POL_CONTRACTS_EXT WC
      WHERE WV.CONTRACT_ID = WC.CONTRACT_ID
      AND WC.BRANCH_EXT_REF = '20'
      AND WV.AUTH_DOCUMENT_GROUP_ID IS NOT NULL
    ) OCQPOL 
    INNER JOIN ALZ_DOCUMENTS ALZD  
    ON OCQPOL.AUTH_DOCUMENT_GROUP_ID = ALZD.DOCUMENT_GROUP_ID 
    LEFT JOIN CUSTOMER.ALZ_PROD_DOCS ALZP
    ON OCQPOL.AUTH_DOCUMENT_GROUP_ID = ALZP.DOCUMENT_GROUP_ID
    AND ALZD.DOCUMENT_ID = ALZP.OLD_DOC_ID
    WHERE 1=1
    AND OCQPOL.AUTH_DOCUMENT_GROUP_ID <> 0
    AND ALZP.OBJECT_ID IS NULL
    AND ALZD.ATTACHMENT IS NOT NULL
    AND NOT EXISTS (SELECT 1 FROM ALZ_FN_MIG_CONTRACTS A
            WHERE A.DOCUMENT_GROUP_ID = OCQPOL.AUTH_DOCUMENT_GROUP_ID
            AND A.CONTRACT_ID = OCQPOL.CONTRACT_ID
            AND A.DOCUMENT_ID = ALZD.DOCUMENT_ID)
  --  AND OCQPOL.CONTRACT_ID = 262289607
            
            
            select * from all_tables where upper(table_name) like '%BRANCH%'
            
 -- SELECT * FROM OCQ_KOC_OCP_POL_CONTRACTS_EXT WHERE CONTRACT_ID = 262289607
  --  oc_branchs
    
    select * from KOC_OC_BRANCHES
    
    select * from clm_pol_oar where claim_id = 38749108
    
    select * from alz_v_hclm_insured_info 
     where contract_id=410654615 and partition_no=2 and SYSDATE BETWEEN TERM_START_DATE AND TERM_END_DATE
    ORDER BY VERSION_NO DESC
    
    
    SELECT * FROM Koc_Ocp_Pol_Contracts_Ext where contract_id=410654615
    
    
    
      SELECT COUNT(*)
    --INTO v_max_sira_no
    FROM CUSTOMER.ALZ_FN_MIG_CONTRACTS
   WHERE MIG_STATUS='TODO';--SIRA_NO IS NOT NULL;
   
   select * from alz_hltprv_log
     
    
           SELECT PRODUCT_ID,PARTITION_TYPE,GROUP_CODE
             FROM CUSTOMER.Koc_v_Hlth_Insured_Info_Indem
            where contract_id = 410654615
              and partition_no =2;
    
    
    SELECT PRODUCT_ID,PARTITION_TYPE,GROUP_CODE
             FROM CUSTOMER.Koc_v_Hlth_Insured_Info_Indem
            where (contract_id,partition_no) = (select contract_id,oar_no 
                                                  from clm_pol_oar 
                                                 where claim_id=38749108)
                                                 
                                                 
                                                 
    select *
      from koc_oc_network_inst_rel b
     where 1=1 --b.network_id           = 26
       and b.institute_code       = 918
       
       select * from koc_mv_skrm_suppliers m
       where not exists (select 1 from koc_oc_network_inst_rel where institute_code = m.institute_code and network_id=26)
       and claim_inst_type='AK'
       and name not like '%�PT%'
       and exp_date IS NULL
       and INSTITUTE_TYPE!=2
