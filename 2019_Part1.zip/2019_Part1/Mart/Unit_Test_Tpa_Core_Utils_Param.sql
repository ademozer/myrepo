DECLARE
  v_contract_id clm_pol_oar.contract_id%TYPE;
  v_partititon_no clm_pol_oar.Oar_NO%TYPE;
  v_group_code ALZ_TPA_PARAMETERS.GROUP_CODE%TYPE;
  v_parameter_name VARCHAR2(200);
  FUNCTION get_parameter_by_claim (pn_claim_id IN NUMBER, pc_parameter_type IN VARCHAR2, pd_date IN DATE DEFAULT SYSDATE
  , pc_lang IN VARCHAR2, pc_user IN VARCHAR2)
    RETURN VARCHAR2
  IS
    lc_company_code VARCHAR2 (10);
    --lt_hca    CUSTOMER.hlth_cpa_automation_typ;
    --lc_is_aztr_care VARCHAR2 (2);
    lc_partition_type Koc_v_Hlth_Insured_Info_Indem.PARTITION_TYPE%TYPE;
    lc_group_code     Koc_v_Hlth_Insured_Info_Indem.Group_Code%TYPE;
    lc_product_id     Koc_v_Hlth_Insured_Info_Indem.Product_Id%TYPE;
  BEGIN
    IF pn_claim_id IS NULL OR pc_parameter_type IS NULL THEN
      RETURN NULL;
    END IF;

    lc_company_code := ALZ_TPA_CORE_UTILS.get_company_code_by_claim (pn_claim_id);

    --    SELECT alz_tr_care_utils.get_is_aztr_care (contract_id)
    --      INTO lc_is_aztr_care
    --      FROM (  SELECT contract_id
    --                FROM clm_pol_bases
    --               WHERE claim_id = pn_claim_id
    --            GROUP BY contract_id);
    
     
                                                 
    IF lc_company_code IS NOT NULL THEN
      
      SELECT PRODUCT_ID,PARTITION_TYPE,GROUP_CODE
        INTO lc_product_id, lc_partition_type, lc_group_code
        FROM CUSTOMER.Koc_v_Hlth_Insured_Info_Indem
       WHERE (contract_id, partition_no) = (SELECT contract_id, oar_no 
                                              FROM clm_pol_oar 
                                             WHERE claim_id = pn_claim_id);                                           
      --alz_hlth_cpa_utils.group_agency_insured_fields (pn_claim_id, lt_hca);
      RETURN ALZ_TPA_CORE_UTILS.f_get_param_value (lc_company_code, lc_product_id, lc_partition_type
                              , pc_lang, pc_parameter_type, pc_user
                              , pd_date
                              , lc_group_code); --lc_is_aztr_care
    ELSE
      RETURN NULL;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END get_parameter_by_claim;
  
 BEGIN
     
    v_parameter_name := ALZ_TPA_CORE_UTILS.get_parameter_by_claim(38749108,'PROVISION_PHONE',SYSDATE,'TR','ADEMO');
    
    DBMS_OUTPUT.PUT_LINE(v_parameter_name);
 END;
 
 
 --select * from alz_tpa_parameters
