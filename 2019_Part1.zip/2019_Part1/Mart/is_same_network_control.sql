select * from koc_clm_hlth_detail d,clm_pol_oar o 
where 1=1 -- d.provision_date > TO_DATE('01/01/2019','DD/MM/YYYY') AND d.claim_inst_type != d.orig_claim_inst_type
and d.claim_id=o.claim_id
AND d.ext_reference = '56530442'
AND Koc_Clm_hlth_Utils.Is_Same_Network(o.contract_id,o.oar_no,d.process_date,d.institute_code) = 1
and d.request_system IN ('OPUS','PORTAL','WS','ULAK','WEBPOS')
and d.institute_code=991
--and d.institute_code = 4538
--and comm_date IS NULL
--and provision_date IS NOT NULL

select * from koc_mv_skrm_suppliers where  name like '%GLOBAL%'--institute_code IN('4538','337','991')
select * from koc_clm_hlth_reject_loss where claim_id=38749641

select * from Koc_v_Cp_Health_Look_Up where look_up_code='HSTP'
SELECT customer.Alz_Hclm_Converter_Utils.getHclmUsageForOpus FROM DUAL;
