--data bulma
select * from koc_clm_hlth_detail where provision_date>TO_DATE('01/03/2019','DD/MM/YYYY') AND AFFLUENT_FLAG=1 AND ROWNUM<2
select * from clm_pol_oar where claim_id=38749694
 select * from Koc_v_Hlth_Insured_Info_Indem where contract_id=382363231 and partition_no=15
--prov sonucu 
select * from koc_clm_hlth_detail where ext_reference='55711052'
select * from alz_affluent_mail_log where claim_id=38750219

--eski yeni
select * from koc_cp_health_look_up  WHERE Look_Up_Code = 'HCLM_USAGE' for update;
--0 ESKI
--2 YENI

