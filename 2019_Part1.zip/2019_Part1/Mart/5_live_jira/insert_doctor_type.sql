insert into Koc_Cp_Health_Look_Up (LOOK_UP_CODE, PARAMETER, DESC_INT_ID, VALIDITY_START, VALIDITY_END, USERID, ENTRY_DATE, DETAIL_EXPLANATION)
values ('DOCTORTYPE', '1', 410635, to_date('01-04-2012', 'dd-mm-yyyy'), null, 'ADEMO', sysdate, null)
/
insert into Koc_Cp_Health_Look_Up (LOOK_UP_CODE, PARAMETER, DESC_INT_ID, VALIDITY_START, VALIDITY_END, USERID, ENTRY_DATE, DETAIL_EXPLANATION)
values ('DOCTORTYPE', '2', 410636, to_date('01-04-2012', 'dd-mm-yyyy'), null, 'ADEMO', sysdate, null)
/
insert into Koc_Cp_Health_Look_Up (LOOK_UP_CODE, PARAMETER, DESC_INT_ID, VALIDITY_START, VALIDITY_END, USERID, ENTRY_DATE, DETAIL_EXPLANATION)
values ('DOCTORTYPE', '3', 410637, to_date('01-04-2012', 'dd-mm-yyyy'), null, 'ADEMO', sysdate, null)
/
insert into Koc_Cp_Health_Look_Up (LOOK_UP_CODE, PARAMETER, DESC_INT_ID, VALIDITY_START, VALIDITY_END, USERID, ENTRY_DATE, DETAIL_EXPLANATION)
values ('DOCTORTYPE', '4', 411122, to_date('01-04-2012', 'dd-mm-yyyy'), null, 'ADEMO', sysdate, null)
/
insert into Koc_Cp_Health_Look_Up (LOOK_UP_CODE, PARAMETER, DESC_INT_ID, VALIDITY_START, VALIDITY_END, USERID, ENTRY_DATE, DETAIL_EXPLANATION)
values ('DOCTORTYPE', '5', 424458, to_date('30-05-2013', 'dd-mm-yyyy'), null, 'ADEMO', sysdate, null)
/
COMMIT
/
