DECLARE 
   v_desc_int_id NUMBER;
BEGIN
  
select max(int_id) + 1
INTO v_desc_int_id
from  DESCRIPTIONS;

insert into DESCRIPTIONS (INT_ID, JOIN_TABLE)
values (v_desc_int_id, 'KOC_CP_HEALTH_LOOK_UP');

insert into cur_translations (SULA_ORA_NLS_CODE, DESC_INT_ID, SHORT_CODE, LONG_NAME, COMMENTS)
values ('TR', v_desc_int_id, 'HCLM_USAGE', '0-Eski Sistem,1-Sadece Portal Yeni,2-Sadece Opus Yeni,3-Yeni Sistem', null);

insert into cur_translations (SULA_ORA_NLS_CODE, DESC_INT_ID, SHORT_CODE, LONG_NAME, COMMENTS)
values ('US', v_desc_int_id, 'HCLM_USAGE', '0-Old System,1-Only Portal New,2- Only Opus New,3-New System', null);

insert into koc_cp_health_look_up (LOOK_UP_CODE, PARAMETER, DESC_INT_ID, VALIDITY_START, VALIDITY_END, USERID, ENTRY_DATE, DETAIL_EXPLANATION)
values ('HCLM_USAGE', '0', v_desc_int_id, sysdate, null, 'ADEMO', null, 'HCLM Yeni Sistem Kullanımı');

END;
/