DECLARE
v_claim_id NUMBER := 38650230;
p_Contract_Id      NUMBER;
p_Partition_No     NUMBER;
p_Data  KOC_PK_HLTH_PROVISION.Detaildatatyp;
FUNCTION dateToString(p_date IN DATE) RETURN VARCHAR2 IS
          v_date  DATE;
          v_timestamp TIMESTAMP;
          v_return VARCHAR2(100);
    BEGIN
        v_return := '';
        v_date := p_date;
        IF v_date IS NOT NULL THEN
           v_timestamp := CAST (v_date AS TIMESTAMP);
           v_return := TO_CHAR(v_date,'YYYY-MM-DD')||'T'||TO_CHAR(v_timestamp,'HH24:MI:SS.FF3')||'Z';            
        END IF;  
        RETURN v_return;          
    END dateToString; 
procedure Delete_Provisions(p_Contract_Id      NUMBER,
                                 p_Partition_No     NUMBER,
                                 p_Realization_Date DATE,
                                 p_Location_Code    NUMBER,
                                 p_Cover_Code       VARCHAR2,
                                 p_User_Id          VARCHAR2,
                                 p_Del_Or_Rej       NUMBER,
                                 Clmdetail          KOC_PK_HLTH_PROVISION.Detaildatatyp,--KOC_CLM_HLTH_TRNX.Clmdetailtype,
                                 p_Cancelation_Exp  VARCHAR2 DEFAULT NULL) IS
       v_hltprv_Log          Hltprv_Log_Typ := Hltprv_Log_Typ();        
       v_request CLOB;
       v_response CLOB;
       --v_url VARCHAR2(200) := get_url_link('http://esb.allianz.com.tr:12000/hclm-health-claim-service/api/v1/provision/');        
       v_url VARCHAR2(200) := 'http://10.70.47.25:19101/hclm-health-claim-service/api/v1/provision/'; 
       v_status NUMBER;
       v_message VARCHAR2(1000); 
       v_institute_code NUMBER;
       v_ext_ref VARCHAR2(100); 
       v_claim_id NUMBER; 
       v_add_order_no NUMBER;
       v_sf_no NUMBER;      
       v_ndx1      NUMBER; 
       v_ndx2      NUMBER;  
       v_result VARCHAR2(1000);                                
     BEGIN
         
         v_url := v_url || (CASE p_Del_Or_Rej WHEN 1 THEN 'cancelProvision'
                                              WHEN 2 THEN 'rejectProvision' 
                                              WHEN 3 THEN 'cancelProvision'
                                              WHEN 4 THEN 'rejectProvision' 
                            END);
         
         FOR ndx IN 1..ClmDetail.COUNT LOOP    
              v_ext_ref := ClmDetail(ndx).Ext_Reference;
              v_claim_id :=  ClmDetail(ndx).Claim_Id;
              v_add_order_no := ClmDetail(ndx).Add_Order_No;
              v_sf_no := ClmDetail(ndx).Sf_No;
              v_institute_code := ClmDetail(ndx).INSTITUTE_CODE;
         END LOOP;
         
         /*v_request := '{
                        "addOrderNo": 1,
                        "cancelRejectReason": "'||p_Cancelation_Exp||'",
                        "claimId": "'||v_claim_id||'",
                        "contractId": "'||p_Contract_Id||'",
                        "instituteCode": "'||v_institute_code||'",
                        "partitionNo": "'||p_Partition_No||'",
                        "sfNo": "'||v_sf_no||'"
                      }';*/
         v_request := '{
                            "cancelReason": "'||p_Cancelation_Exp||'",
                            "contractId": "'||TO_CHAR(p_Contract_Id)||'",
                            "originDate": "'||dateToString(p_Realization_Date)||'",
                            "partitionNo": "'||TO_CHAR(p_Partition_No)||'",
                            "provisionInstitute": {
                              "instituteCodeAllz": "'||TO_CHAR(v_institute_code)||'"
                            },
                            "referenceList": [
                              {
                                "referenceNo": "'||v_claim_id||'",
                                "type": "CLAIM_ID"
                              },
                              {
                                "referenceNo": "'||v_sf_no||'",
                                "type": "SF_NO"
                              },
                              {
                                "referenceNo": "'||v_add_order_no||'",
                                "type": "ADD_ORDER_NO"
                              }
                            ],
                            "requestSystem": "OPUS",
                            "userCode": "'||p_User_Id||'"
                        }';                      
       
        v_hltprv_Log.Log_Id := NULL;
        v_hltprv_Log.Servicename := 'ALZ_HCLM_CONVERTER_UTILS';
        v_hltprv_Log.Processinfo := v_url;
        v_hltprv_Log.Note        := 'DELETE_PROVISION_REQUEST';
        v_hltprv_Log.Content     := v_request;
        v_hltprv_Log.Institutecode := v_institute_code;
        v_hltprv_Log.Savelogwithpragma;
          
        CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.callRestService(v_url, 'POST', v_request, v_response, v_status, v_message);
       
        v_hltprv_Log.Servicename := 'ALZ_HCLM_CONVERTER_UTILS';
        v_hltprv_Log.Processinfo := v_url;
        v_hltprv_Log.Note        := 'DELETE_PROVISION_RESPONSE';
        v_hltprv_Log.Content     := v_response;
        v_hltprv_Log.Institutecode := v_institute_code;
        v_hltprv_Log.Savelogwithpragma;
        
        IF v_status = 0 THEN             
             v_ndx1 := INSTR(v_response,'cancelProvisionStatus');
             v_ndx2 := INSTR(v_response,'requestSystem') - v_ndx1;
             v_response := SUBSTR(v_response, v_ndx1+25, v_ndx2-27);
             v_response := REPLACE(v_response,'{','');
             v_response := REPLACE(v_response,'}','');
             v_response := REPLACE(v_response,'"provisionNote" :','');
         ELSE
             v_ndx1 := INSTR(v_response,'{"errors" : [');
             v_ndx2 := INSTR(v_response,'],"warnings"') - v_ndx1;
             v_response := SUBSTR(v_response, v_ndx1+15, v_ndx2-17);
         END IF;
        
         FOR rec IN (SELECT TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1) , '"',''))   KEY,
                            TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1, 2), '"','')) VALUE
                       FROM (SELECT Regexp_Substr (v_response, '[^,]+', 1, LEVEL) ELEMENT
                               FROM Dual
                            CONNECT BY LEVEL <= LENGTH (Regexp_Replace (v_response, '[^,]+')) + 1)) LOOP
                            
             IF rec.KEY IN('message', 'text') THEN
                 v_message := rec.value;
             END IF;
             IF rec.KEY IN ('succesCancellation') THEN
                 v_result := rec.value;
             END IF;
            
         END LOOP;
         
         IF v_result = 'false' THEN
              v_status := 1;
         END IF;    
             
         IF v_status = 1 THEN
             Raise_Application_Error(-20200,  v_message);
         END IF; 
         
         DBMS_OUTPUT.PUT_LINE('Success'||v_message||':'||v_hltprv_Log.Log_Id);
         
     EXCEPTION    
     WHEN OTHERS THEN      
        v_hltprv_Log.Servicename   := 'ALZ_HCLM_CONVERTER_UTILS';
        v_hltprv_Log.Processinfo   := v_url;
        v_hltprv_Log.Note          := 'DELETE_PROVISION_EXCEPTION';
        v_hltprv_Log.Content       := v_message || dbms_utility.format_error_stack || dbms_utility.format_error_backtrace;
        v_hltprv_Log.Institutecode := v_institute_code;
        v_hltprv_Log.Savelogwithpragma;
        Raise_Application_Error(-20200,  'Provizyon �ptali S�ras�nda Bir Hata Olu�tu:'||v_message||':'||v_hltprv_Log.Log_Id);                    
     END  Delete_Provisions;  
     
   BEGIN
        SELECT contract_id,oar_no
          INTO p_Contract_Id, p_Partition_No
          FROM clm_pol_oar 
         WHERE claim_id = v_Claim_Id;
        
        Koc_Pk_Hlth_Provision.Getdetaildata(v_Claim_Id, 1, 1, p_Data);
        
        Delete_Provisions(p_Contract_Id, 
                          p_Partition_No,
                          SYSDATE,
                          NULL,
                          NULL,
                          'ADEMO',
                          2,
                          p_Data,
                          'HCLM Cancel Test');
                                  
   END;                          
             
