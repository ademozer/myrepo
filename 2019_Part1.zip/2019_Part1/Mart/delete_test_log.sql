select * from alz_hltprv_log where log_id=105488071;

Koc_Clm_Hlth_Utils.Deletecoverprintvals;
