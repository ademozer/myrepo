DECLARE
  instituteInfo               koc_v_clm_suppliers%ROWTYPE;
  instituteRef                koc_clm_hlth_utils.refCur;
  v_result                    varchar2(2000);
  v_new_claim_inst_type       varchar2(10);
  v_new_claim_inst_type_desc  varchar2(100);
  vClaimInstTypeChanged       boolean := false;
  v_Message_line     VARCHAR2(4000);
  Pos           Number := 1 ;
  
  v_Rate_Type   VARCHAR2(10);
  v_Rate        Number;
BEGIN
  koc_clm_hlth_utils.getInstitutInfoByCode(
                                      337
                                    , SYSDATE
                                    , instituteRef);
  FETCH  instituteRef 
  INTO instituteInfo;
  --pk_general_utils.setinstitutInfo(instituteInfo);
  CLOSE instituteRef;
  
  DBMS_OUTPUT.PUT_LINE('Kurum Ad�:'||instituteInfo.name);
END;
  
