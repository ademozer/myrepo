 PROCEDURE Findprovamount(p_Contract_Id      NUMBER,
                           p_Partition_No     NUMBER,
                           p_Part_Id          NUMBER,
                           p_Claim_Id         NUMBER,
                           p_Rel_Claim_Id     NUMBER,
                           p_Sf_No            NUMBER,
                           p_Institute_Code   NUMBER,
                           p_Claim_Inst_Type  VARCHAR2,
                           p_Claim_Inst_Loc   VARCHAR2,
                           p_Country_Group    NUMBER,
                           p_Location_Code    NUMBER,
                           p_Cover_Code       VARCHAR2,
                           p_Date             DATE,
                           p_Invoice_Date     DATE,
                           p_Realization_Date DATE,
                           p_Policyinfo       Koc_v_Hlth_Insured_Info_Indem%ROWTYPE,
                           p_Institutinfo     Koc_v_Clm_Suppliers%ROWTYPE,
                           p_Clmprovisions    Clmprovisiontype,
                           p_User_Id          VARCHAR2,
                           p_Process_Type     NUMBER DEFAULT 0,
                           Provoutparam       OUT Provoutparamtyp,
                           p_Is_Referral      IN NUMBER DEFAULT NULL) IS
    Cur                          Refcur;
    Indeminfo                    Koc_Clm_Hlth_Indem_Totals%ROWTYPE;
    Indeminfoparent              Koc_Clm_Hlth_Indem_Totals%ROWTYPE;
    Indeminfotbl                 Clmindemtottype;
    Oldindeminfo                 Koc_Clm_Hlth_Indem_Totals%ROWTYPE;
    Policyinfo                   Koc_v_Hlth_Insured_Info_Indem%ROWTYPE;
    Institutinfo                 Koc_v_Clm_Suppliers%ROWTYPE;
    v_Clmprovision               Koc_Clm_Hlth_Provisions%ROWTYPE;
    c_Provision_Amount           NUMBER;
    c_Exemption_Rate             NUMBER;
    c_Day_Seance                 NUMBER;
    c_Exemption_Sum              NUMBER;
    c_Day_Seance_Amount          NUMBER;
    u_r_Cover_Price              NUMBER;
    u_r_Day_Seance               NUMBER;
    u_r_Exemption_Sum            NUMBER;
    u_s_Provision_Amount         NUMBER;
    u_s_Spend_Total              NUMBER;
    u_s_Spend_Day_Seance         NUMBER;
    u_s_Exemption_Sum            NUMBER;
    c_Max_Increase               NUMBER;
    v_Policy_Start_Date          DATE;
    v_Old_Contract_Id            NUMBER;
    v_Old_Partition_No           NUMBER;
    v_Term_End_Date              DATE;
    v_Max_Inc_Clearing_System_Id NUMBER;
    v_Max_Inc_Curr_Get_Type      VARCHAR2(10);
    v_Max_Inc_Swift_Code         VARCHAR2(4);

    Expackrsltbl               Expackrsltbltyp;
    c_Is_Unlimited             NUMBER;
    c_r_Cover_Price            NUMBER;
    c_r_Day_Seance             NUMBER;
    c_f_Cover_Price            NUMBER;
    c_f_Day_Seance             NUMBER;
    c_Inst_Cover_Price         NUMBER := NULL;
    c_Inst_r_Day_Seance        NUMBER := NULL;
    c_Inst_Exemption_Sum       NUMBER := NULL;
    c_Inst_Exemption_Rate      NUMBER := NULL;
    c_Inst_Is_Unlimited        NUMBER := NULL;
    c_Inst_Provision_Aval_Code VARCHAR2(4) := NULL;
    c_Inst_Is_Cover_Val        NUMBER := NULL;
    p_Rsl_Number               NUMBER;
    p_Rsl_Date                 DATE;
    p_Rsl_Char                 VARCHAR2(2000);
    Expackrow                  Koc_Oc_Hlth_Expack_Cov_Rel%ROWTYPE;
    v_Pay_Clearing_System_Id   NUMBER;
    v_Pay_Curr_Get_Type        VARCHAR2(4);
    i                          NUMBER;
    v_Parite                   NUMBER := 1;
    p_Provision_Amount         NUMBER;
    p_Day_Seance               NUMBER;
    Prv                        NUMBER;
    Ind                        NUMBER;
    Parent_r_Cover_Price       NUMBER;
    Parent_r_Day_Seance        NUMBER;
    p_Sign                     NUMBER;
    p_Swift_Code               VARCHAR2(4);
    p_Date_Time                DATE;
    v_Cover_Swf                VARCHAR2(20);
    v_Exch_Date                VARCHAR2(20);
    v_Curr_Date                DATE;
    v_Sum_Claim_Amount         NUMBER;
    p_Exemption_Amount         NUMBER;
    c_Parent_Indemnity_Type    VARCHAR2(20);
    c_Parent_Provision_Amount  NUMBER;
    c_Parent_r_Cover_Price     NUMBER;
    c_Parent_Is_Unlimited      NUMBER;
    c_Inst_Is_Not_Valid_Exemp  NUMBER;
    Vprodpartmdlr              VARCHAR2(10);
    Vcoverpackageid            NUMBER;
    Vcoverpackagedate          DATE;
    Vhaspolicy1kez             NUMBER(1) := 0;
    Vis1kezused                NUMBER(1) := 0;
    Vindex1kez                 NUMBER;
    Vclaiminsttype             Koc_Clm_Hlth_Indem_Totals.Claim_Inst_Type%TYPE;

    v_City_Code    VARCHAR2(3);
    v_Country_Code VARCHAR2(3) DEFAULT 'TR';
    v_Is_Refferal  NUMBER;

    FUNCTION Find1kezindex(Pcovercode      IN Koc_Clm_Hlth_Indem_Totals.Cover_Code%TYPE,
                           Pispoolcover    IN Koc_Clm_Hlth_Indem_Totals.Is_Pool_Cover%TYPE,
                           Pisspecialcover IN Koc_Clm_Hlth_Indem_Totals.Is_Special_Cover%TYPE,
                           Pclaiminstloc   IN Koc_Clm_Hlth_Indem_Totals.Claim_Inst_Loc%TYPE,
                           Pcountrygroup   IN Koc_Clm_Hlth_Indem_Totals.Country_Group%TYPE,
                           Pindeminfotbl   IN Clmindemtottype) RETURN NUMBER IS
      Vindex     NUMBER;
      Vindex1kez NUMBER;
    BEGIN
      Vindex     := 1;
      Vindex1kez := 0;

      --
      WHILE Vindex <= Indeminfotbl.Count LOOP
        IF Pindeminfotbl(Vindex).Cover_Code = Pcovercode AND Pindeminfotbl(Vindex)
           .Is_Pool_Cover = Nvl(Pispoolcover, 0) AND Pindeminfotbl(Vindex)
           .Is_Special_Cover = Nvl(Pisspecialcover, 0) AND Pindeminfotbl(Vindex)
           .Claim_Inst_Loc = Pclaiminstloc AND Pindeminfotbl(Vindex)
           .Country_Group = Nvl(Pcountrygroup, 0) AND Pindeminfotbl(Vindex)
           .Indemnity_Payment_Type = '1KEZ' THEN
          Vindex1kez := Vindex;
          EXIT;
        END IF;

        Vindex := Vindex + 1;
      END LOOP;

      RETURN Vindex1kez;
    END;

    PROCEDURE Insertlog(Plogtext IN VARCHAR2, Psira IN NUMBER) IS
      PRAGMA AUTONOMOUS_TRANSACTION;
    BEGIN
      RETURN;
      /*
              insert into tmp_koc_errors (reference_code
                                         ,process
                                         ,error
                                         ,process_date
                                         ,sira
                                         )
                                  values (p_contract_id || '-' || p_partition_no
                                         ,'findprovamount'
                                         ,plogtext
                                         ,sysdate
                                         ,psira
                                         );
      */
      COMMIT;
    END;
  BEGIN
    --p_process_type :0 deger al
    --p_process_type :1 limit günceller
    --p_process_type :2 islem iptal

    p_Date_Time := To_Date(To_Char(p_Date, 'dd/mm/yyyy') || ' 13:00:00',
                           'dd/mm/yyyy hh24:mi:ss');

    --aaktas
    --1KEZ olan poliçeler AK da harcanirsa daha önce 1KEZ kullanilmis ise ve teminatin AHK li tanimi 1KEZ ise onu kullan

    --insertlog ('p_date_time sonrasi', 1);

    IF p_Claim_Inst_Type = 'AK' THEN
      Vhaspolicy1kez := Checkpolicyforindemnity(p_Policyinfo.Contract_Id,
                                                p_Policyinfo.Partition_No,
                                                p_Policyinfo.Package_Id,
                                                p_Policyinfo.Package_Date,
                                                Trunc(p_Date),
                                                '1KEZ');

      --
      IF Vhaspolicy1kez = 1 THEN
        --hasar dosyalarinda 1KEZ teminati kullanilmis mi
        Vis1kezused := Checkprovisionforindemnity(p_Policyinfo.Contract_Id,
                                                  p_Policyinfo.Partition_No,
                                                  p_Policyinfo.Package_Id,
                                                  p_Policyinfo.Package_Date,
                                                  Trunc(p_Date),
                                                  '1KEZ');
      END IF;
    END IF;

    --insertlog ('vis1kezused setting sonrasi', 2);

    --1KEZ tip tanimli AHK limitlerinide getirmek için claim_inst_type ve claim_inst_loc null gönderiliyor
    Vclaiminsttype := p_Claim_Inst_Type;

    IF Vis1kezused = 1 THEN
      Vclaiminsttype := NULL;
    END IF;

    Getindemtotals(p_Contract_Id,
                   p_Partition_No,
                   Vclaiminsttype,
                   p_Claim_Inst_Loc,
                   p_Country_Group,
                   NULL,
                   Trunc(p_Date),
                   0,
                   0,
                   p_User_Id,
                   3,
                   3,
                   Cur);

    LOOP
      FETCH Cur
        INTO Indeminfotbl(Indeminfotbl.Count + 1);

      EXIT WHEN Cur%NOTFOUND;
    END LOOP;

    CLOSE Cur;

    --insertlog ('indeminfotbl setting sonrasi count : ' || indeminfotbl.count, 3);

    -- keks elden 1
    p_Exemption_Amount := 0;

    IF p_Clmprovisions.Count > 0 THEN
      Find_Exemption_Limit('E',
                           p_Claim_Id,
                           p_Sf_No,
                           p_Clmprovisions(1).Add_Order_No,
                           p_Rel_Claim_Id,
                           p_Exemption_Amount);
    END IF;

    --aaktas
    --21012015
    --poliçe modüler saglik ürünü mü?
    Vprodpartmdlr := Koc_Health_Policy_Utils5.Get_Prod_Part_Mdlr(p_Policyinfo.Product_Id,
                                                                 p_Policyinfo.Partition_Type,
                                                                 Trunc(p_Date));
    Prv           := 1;

    WHILE Prv <= p_Clmprovisions.Count LOOP
      p_Swift_Code := p_Clmprovisions(Prv).Swift_Code;
      Vindex1kez   := 0;
      Indeminfo    := NULL;

      --aaktas
      --1KEZ tanimli teminat var ise bul yoksa asagidaki koddan devam et
      --vindex1KEZ = 0 kalirsa teminatin kendi tanimini bulmasi için alttaki kodda indeminfotbl iöerisinde loop ile arama yapar
      IF Vis1kezused = 1 THEN
        --insertlog ('prv döngüde vis1kezused = 1', 4);
        Vindex1kez := Find1kezindex(p_Clmprovisions (Prv).Cover_Code,
                                    p_Clmprovisions (Prv).Is_Pool_Cover,
                                    p_Clmprovisions (Prv).Is_Special_Cover,
                                    p_Claim_Inst_Loc,
                                    p_Country_Group,
                                    Indeminfotbl);

        --insertlog ('prv döngüde vindex1KEZ = ' || vindex1KEZ, 5);

        IF Vindex1kez > 0 THEN
          Indeminfo := Indeminfotbl(Vindex1kez);
        END IF;
      END IF;

      --insertlog ('prv döngüde indeminfo setting sonrasi ' || vindex1KEZ, 6);

      --
      IF Indeminfo.Cover_Code IS NULL THEN
        Ind := 1;

        WHILE Ind <= Indeminfotbl.Count LOOP
          --insertlog ('1KEZ döngüsüne girmediyse prv döngüsü', 7);

          IF Indeminfotbl(Ind).Cover_Code = p_Clmprovisions(Prv).Cover_Code AND
              Nvl(Indeminfotbl(Ind).Is_Pool_Cover, 0) =
              Nvl(p_Clmprovisions(Prv).Is_Pool_Cover, 0) AND Indeminfotbl(Ind)
             .Claim_Inst_Type = p_Claim_Inst_Type AND Indeminfotbl(Ind)
             .Claim_Inst_Loc = p_Claim_Inst_Loc THEN
            Indeminfo := Indeminfotbl(Ind);
            EXIT;
          END IF;

          --insertlog ('1KEZ döngüsüne girmediyse prv döngüsü', 8);

          Ind := Ind + 1;
        END LOOP;
      END IF;

      p_Provision_Amount := Nvl(p_Clmprovisions(Prv).Request_Amount, 0) -
                            Nvl(p_Clmprovisions(Prv).Refusal_Amount, 0);

      --insertlog ('normal süreç', 9);

      IF p_Provision_Amount < 0 THEN
        p_Provision_Amount := 0;
      END IF;

      p_Day_Seance       := Nvl(p_Clmprovisions(Prv).Req_Cure_Day_Count, 0);
      c_Provision_Amount := Nvl(p_Provision_Amount, 0);

      --
      IF p_Policyinfo.Partition_Type = 'KEKS' THEN
        ----------------------------------------
        v_Sum_Claim_Amount := c_Provision_Amount;

        IF Nvl(v_Sum_Claim_Amount, 0) > 0 AND
           Nvl(p_Exemption_Amount, 0) > 0 THEN
          IF Nvl(v_Sum_Claim_Amount, 0) > Nvl(p_Exemption_Amount, 0) THEN
            v_Sum_Claim_Amount := Nvl(v_Sum_Claim_Amount, 0) -
                                  Nvl(p_Exemption_Amount, 0);
            Provoutparam(Prv).p_Out_Exemption_Sum := p_Exemption_Amount;
            p_Exemption_Amount := 0;
          ELSE
            Provoutparam(Prv).p_Out_Exemption_Sum := v_Sum_Claim_Amount;
            p_Exemption_Amount := Nvl(p_Exemption_Amount, 0) -
                                  Nvl(v_Sum_Claim_Amount, 0);
            v_Sum_Claim_Amount := 0;
          END IF;
        END IF;

        c_Provision_Amount := v_Sum_Claim_Amount;
      END IF;

      --insertlog ('normal süreç', 10);

      --talep tutarinin döviz cinsi teminatin döviz cinsinden farkli ise
      --talep tutarinin teminat döviz cinsi karsiligini bulunur
      --ve limitler bu tutar ile güncellenir.
      --
      IF p_Swift_Code != Indeminfo.Swift_Code THEN
        --insertlog ('normal süreç', 11);

        v_Cover_Swf := Indeminfo.Swift_Code;

        SELECT Decode(v_Cover_Swf,
                      Base_Swift_Code,
                      Pay_Clearing_System_Id,
                      Pay_Swf_Clear_Sys_Id),
               Decode(v_Cover_Swf,
                      Base_Swift_Code,
                      Pay_Curr_Get_Type,
                      Pay_Swf_Curr_Get_Type),
               Decode(v_Cover_Swf,
                      Base_Swift_Code,
                      Pay_Exch_Dates,
                      Pay_Swf_Exch_Dates)
          INTO v_Pay_Clearing_System_Id, v_Pay_Curr_Get_Type, v_Exch_Date
          FROM Koc_Oc_Prod_Partition_Rel
         WHERE Product_Id = p_Policyinfo.Product_Id
           AND Partition_Type = p_Policyinfo.Partition_Type
           AND Validity_Start_Date <= p_Policyinfo.Term_Start_Date
           AND Nvl(Validity_End_Date, p_Policyinfo.Term_Start_Date) >=
               p_Policyinfo.Term_Start_Date;

        --insertlog ('normal süreç', 12);

        IF v_Exch_Date = 'FAT' THEN
          v_Curr_Date := p_Invoice_Date;
        ELSIF v_Exch_Date = 'OLAY' THEN
          v_Curr_Date := p_Date;
        ELSIF v_Exch_Date = 'TAH' THEN
          v_Curr_Date := p_Realization_Date;
        ELSE
          v_Curr_Date := p_Date;
        END IF;

        --insertlog ('normal süreç', 13);

        v_Parite           := Koc_Curr_Utils.Retrieve_Currency_Rate(p_Swift_Code,
                                                                    v_Pay_Curr_Get_Type,
                                                                    Trunc(v_Curr_Date),
                                                                    v_Pay_Clearing_System_Id,
                                                                    TRUE) /
                              Koc_Curr_Utils.Retrieve_Currency_Rate(Indeminfo.Swift_Code,
                                                                    v_Pay_Curr_Get_Type,
                                                                    Trunc(v_Curr_Date),
                                                                    v_Pay_Clearing_System_Id,
                                                                    TRUE);
        c_Provision_Amount := v_Parite * c_Provision_Amount;
        --insertlog ('normal süreç', 14);

      END IF;

      -- provizyon almis hasar dosya--------------------------------------------
      -- provizyon almis lokasyon üzerinde degisiklik yapildiginda dogru provizyon tutarini göstere bilmesi için
      -- önce provizyon almis lokasyon reverse ediliyor.
      --

      --insertlog ('normal süreç', 15);
      IF p_Process_Type = 0 THEN
        --insertlog ('normal süreç', 16);

        BEGIN
          --insertlog ('normal süreç', 17);

          SELECT *
            INTO v_Clmprovision
            FROM Koc_Clm_Hlth_Provisions
           WHERE Claim_Id = p_Claim_Id
             AND Sf_No = p_Sf_No
             AND Location_Code = p_Location_Code
             AND Cover_Code = p_Cover_Code
             AND Status_Code in ('P','CP');

          --insertlog ('normal süreç', 18);

          IF p_Policyinfo.Partition_Type = 'KEKS' THEN
            v_Clmprovision.Exemption_Amount := 0;
          END IF;

          Indeminfo.s_Provision_Amount := Indeminfo.s_Provision_Amount -
                                          v_Parite * Nvl(v_Clmprovision.Provision_Total,
                                                         0);
          Indeminfo.s_Spend_Total      := Indeminfo.s_Spend_Total -
                                          v_Parite *
                                          (Nvl(v_Clmprovision.Request_Amount,
                                               0) - Nvl(v_Clmprovision.Refusal_Amount,
                                                         0));
          Indeminfo.s_Spend_Day_Seance := Indeminfo.s_Spend_Day_Seance -
                                          Nvl(v_Clmprovision.Req_Cure_Day_Count,
                                              0);
          Indeminfo.s_Exemption_Sum    := Indeminfo.s_Exemption_Sum -
                                          v_Parite * Nvl(v_Clmprovision.Exemption_Amount,
                                                         0);
          Indeminfo.r_Exemption_Sum    := Indeminfo.r_Exemption_Sum +
                                          v_Parite * Nvl(v_Clmprovision.Exemption_Amount,
                                                         0);

          IF Indeminfo.Indemnity_Payment_Type IN ('NORM', '1KEZ') AND
             Nvl(Indeminfo.Is_Unlimited, 0) != 1 THEN
            IF v_Clmprovision.Exemption_Rate != 0 THEN
              IF v_Clmprovision.Exemption_Rate != 1 THEN
                --yasemin
                Indeminfo.r_Cover_Price := Indeminfo.r_Cover_Price +
                                           v_Parite *
                                           ((v_Clmprovision.Provision_Total / (1 -
                                           v_Clmprovision.Exemption_Rate)) +
                                           v_Clmprovision.Exemption_Amount);
              ELSE
                --yasemin
                Indeminfo.r_Cover_Price := Indeminfo.r_Cover_Price +
                                           v_Parite *
                                           v_Clmprovision.Exemption_Amount;
              END IF;
            ELSE
              --yasemin
              Indeminfo.r_Cover_Price := Indeminfo.r_Cover_Price +
                                         v_Parite *
                                         v_Clmprovision.Exemption_Amount;
            END IF;
          END IF;

          IF Indeminfo.Indemnity_Payment_Type IN
             ('DEFA', 'GUN', 'NORM', '1KEZ') THEN
            Indeminfo.r_Day_Seance := Indeminfo.r_Day_Seance +
                                      v_Clmprovision.Day_Seance;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            NULL;
            --insertlog ('normal süreç', 19);
        END;
      END IF;

      --insertlog ('normal süreç', 20);

      Policyinfo   := p_Policyinfo;
      Institutinfo := p_Institutinfo;

      --abdullah aktas
      --21012015
      --mdlr tipinde ise partition_type teminatin sub_package_id sini al
      --mdlr poliçesindeki teminatlarin planlari farkli olabilir.
      IF Nvl(Vprodpartmdlr, 'X') = 'MDLR' THEN
        Vcoverpackageid   := Indeminfo.Sub_Package_Id;
        Vcoverpackagedate := Indeminfo.Sub_Package_Date;
      ELSE
        Vcoverpackageid   := Policyinfo.Package_Id;
        Vcoverpackagedate := Policyinfo.Package_Date;
      END IF;

      --ibrahimk
      --expack cov rel de yeni kural için kullanılacak alanlar
      IF p_Institute_Code IS NOT NULL THEN
        Alz_Hlth_Karma_Utils.Get_Inst_City_Code(Institutinfo.Institute_Code,
                                                v_City_Code,
                                                v_Country_Code);
      ELSE
        v_City_Code    := NULL;
        v_Country_Code := NULL;
      END IF;

      IF p_Is_Referral IS NULL THEN
        v_Is_Refferal := Alz_Hlth_Karma_Utils.Get_Clm_Is_Referral(p_Claim_Id     => v_Clmprovision.Claim_Id,
                                                                  p_Sf_No        => v_Clmprovision.Sf_No,
                                                                  p_Add_Order_No => v_Clmprovision.Add_Order_No);
      ELSE
        v_Is_Refferal := p_Is_Referral;
      END IF;
      --insertlog ('normal süreç', 21);

      IF p_Process_Type IN (0, 1) THEN
        --kurum için tanimlanmis limit, muafiyet tutari yada hasta payi var mi?----
        Expackrow.Product_Id           := Policyinfo.Product_Id;
        Expackrow.Partition_Type       := Policyinfo.Partition_Type;
        Expackrow.Contract_Id          := Policyinfo.Contract_Id;
        Expackrow.Partition_No         := Policyinfo.Partition_No;
        Expackrow.Package_Id           := Vcoverpackageid;
        Expackrow.Package_Date         := Vcoverpackagedate;
        Expackrow.Validity_Start_Date  := Nvl(Indeminfo.Validity_Start_Date,
                                              To_Date('01/01/1000',
                                                      'DD/MM/YYYY'));
        Expackrow.Part_Id              := Policyinfo.Partner_Id;
        Expackrow.Claim_Inst_Type      := Nvl(p_Claim_Inst_Type,
                                              Institutinfo.Claim_Inst_Type);
        Expackrow.Claim_Inst_Loc       := Nvl(p_Claim_Inst_Loc,
                                              Institutinfo.Claim_Inst_Loc);
        Expackrow.Institute_Code       := Institutinfo.Institute_Code;
        Expackrow.Inst_Cov_Type        := Institutinfo.Inst_Cov_Type;
        Expackrow.Inst_Validity_Type   := Institutinfo.Inst_Validity_Type;
        Expackrow.Institute_Type       := Institutinfo.Institute_Type;
        Expackrow.Country_Group        := p_Country_Group;
        Expackrow.Child_Cover_Code     := Indeminfo.Cover_Code;
        Expackrow.Is_Pool_Cover        := Indeminfo.Is_Pool_Cover;
        Expackrow.Is_Special_Cover     := Indeminfo.Is_Special_Cover;
        Expackrow.Cover_Cat_Group      := Indeminfo.Cover_Cat_Group;
        Expackrow.Institude_Group_Code := Institutinfo.Institute_Group_Code_Type_2; -- selcenk TSS 03/03/2015
        Expackrow.Spec_Group_Code      := Institutinfo.Institute_Group_Code_Type_s; -- selcenk TSS 03/03/2015
        Expackrow.City_Code            := v_City_Code; --ibrahimk karma 21/09/2016

        --insertlog ('normal süreç', 22);

        Getinstexpackresult(Expackrow,
                            'IS_UNLIMITED',
                            p_Rsl_Number,
                            p_Rsl_Date,
                            p_Rsl_Char);
        Expackrsltbl(1).Is_Unlimited := p_Rsl_Number;

        Getinstexpackresult(Expackrow,
                            'COVER_PRICE',
                            p_Rsl_Number,
                            p_Rsl_Date,
                            p_Rsl_Char);
        Expackrsltbl(1).Cover_Price := p_Rsl_Number;

        Getinstexpackresult(Expackrow,
                            'EXEMPTION_RATE',
                            p_Rsl_Number,
                            p_Rsl_Date,
                            p_Rsl_Char);
        Expackrsltbl(1).Exemption_Rate := p_Rsl_Number;

        --ibrahimk karma 21/09/2106
        Getinstexpackresult(Expackrow,
                            'EXEMPTION_RATE2',
                            p_Rsl_Number,
                            p_Rsl_Date,
                            p_Rsl_Char);
        Expackrsltbl(1).Exemption_Rate2 := p_Rsl_Number;

        IF Nvl(v_Is_Refferal, 0) = 1 AND Expackrsltbl(1)
          .Exemption_Rate2 IS NOT NULL THEN
          Expackrsltbl(1).Exemption_Rate := Expackrsltbl(1).Exemption_Rate2;
        END IF;
        ------------------------------------------------

        Getinstexpackresult(Expackrow,
                            'EXEMPTION_SUM',
                            p_Rsl_Number,
                            p_Rsl_Date,
                            p_Rsl_Char);
        Expackrsltbl(1).Exemption_Sum := p_Rsl_Number;

        Getinstexpackresult(Expackrow,
                            'SPECIAL_COVER_CODE',
                            p_Rsl_Char,
                            p_Rsl_Date,
                            p_Rsl_Char);
        Expackrsltbl(1).Special_Cover_Code := p_Rsl_Char;

        Getinstexpackresult(Expackrow,
                            'IS_COVER_VAL',
                            p_Rsl_Number,
                            p_Rsl_Date,
                            p_Rsl_Char);
        Expackrsltbl(1).Is_Cover_Val := p_Rsl_Number;

        Getinstexpackresult(Expackrow,
                            'MAX_DAY_SEANCE',
                            p_Rsl_Number,
                            p_Rsl_Date,
                            p_Rsl_Char);
        Expackrsltbl(1).Max_Day_Seance := p_Rsl_Number;

        Getinstexpackresult(Expackrow,
                            'PROVISION_AVAL_CODE',
                            p_Rsl_Char,
                            p_Rsl_Date,
                            p_Rsl_Char);
        Expackrsltbl(1).Provision_Aval_Code := p_Rsl_Char;

        --27032014
        --aaktas
        Getinstexpackresult(Expackrow,
                            'IS_NOT_VALID_EXEMP',
                            p_Rsl_Number,
                            p_Rsl_Date,
                            p_Rsl_Char);
        Expackrsltbl(1).Is_Not_Valid_Exemp := p_Rsl_Number;
        --

        i := 0;

        --insertlog ('normal süreç', 23);

        LOOP
          i := i + 1;
          EXIT WHEN i > Expackrsltbl.Count;

          IF Expackrsltbl(i).Is_Unlimited IS NOT NULL THEN
            c_Inst_Is_Unlimited := Expackrsltbl(i).Is_Unlimited;
          END IF;

          IF Expackrsltbl(i).Cover_Price IS NOT NULL THEN
            c_Inst_Cover_Price := Nvl(Expackrsltbl(i).Cover_Price, 0);
          END IF;

          IF Expackrsltbl(i).Max_Day_Seance IS NOT NULL THEN
            c_Inst_r_Day_Seance := Nvl(Expackrsltbl(i).Max_Day_Seance, 0);
          END IF;

          IF Expackrsltbl(i).Exemption_Sum IS NOT NULL THEN
            c_Inst_Exemption_Sum := Nvl(Expackrsltbl(i).Exemption_Sum, 0);
          END IF;

          IF Expackrsltbl(i).Exemption_Rate IS NOT NULL THEN
            c_Inst_Exemption_Rate := Nvl(Expackrsltbl(i).Exemption_Rate, 0);
          END IF;

          IF Expackrsltbl(i).Provision_Aval_Code IS NOT NULL THEN
            c_Inst_Provision_Aval_Code := Expackrsltbl(i)
                                          .Provision_Aval_Code;
          END IF;

          IF Expackrsltbl(i).Is_Cover_Val IS NOT NULL THEN
            c_Inst_Is_Cover_Val := Expackrsltbl(i).Is_Cover_Val;
          END IF;

          IF Expackrsltbl(i).Is_Not_Valid_Exemp IS NOT NULL THEN
            c_Inst_Is_Not_Valid_Exemp := Expackrsltbl(i).Is_Not_Valid_Exemp;
          END IF;
        END LOOP;

        --insertlog ('normal süreç', 24);

        ----kuruma bagli degisenler--------------------
        IF c_Inst_Is_Unlimited IS NOT NULL AND c_Inst_Is_Unlimited = 0 THEN
          c_Is_Unlimited := c_Inst_Is_Unlimited;
        ELSE
          c_Is_Unlimited := Indeminfo.Is_Unlimited;
        END IF;

        IF c_Inst_Exemption_Sum IS NOT NULL THEN
          IF Nvl(c_Provision_Amount, 0) < c_Inst_Exemption_Sum THEN
            c_Inst_Exemption_Sum := Nvl(c_Provision_Amount, 0);
          END IF;
        ELSE
          c_Inst_Exemption_Sum := 0;
        END IF;

        -- en küçük limit alinmali
        --yasemin
        IF c_Inst_Cover_Price IS NOT NULL AND
           Indeminfo.r_Cover_Price > Nvl(c_Inst_Cover_Price, 0) THEN
          c_r_Cover_Price := Nvl(c_Inst_Cover_Price, 0);
        ELSE
          c_r_Cover_Price := Indeminfo.r_Cover_Price;
        END IF;

        IF c_Inst_r_Day_Seance IS NOT NULL AND
           Nvl(Indeminfo.r_Day_Seance, 0) > Nvl(c_Inst_r_Day_Seance, 0) THEN
          c_r_Day_Seance := Nvl(c_Inst_r_Day_Seance, 0);
        ELSE
          c_r_Day_Seance := Nvl(Indeminfo.r_Day_Seance, 0);
        END IF;

        IF c_Inst_Cover_Price IS NOT NULL THEN
          c_f_Cover_Price := Nvl(c_Inst_Cover_Price, 0);
        ELSE
          c_f_Cover_Price := Indeminfo.f_Cover_Price;
        END IF;

        IF c_Inst_Exemption_Rate IS NOT NULL THEN
          c_Exemption_Rate := c_Inst_Exemption_Rate;
        ELSE
          c_Exemption_Rate := Indeminfo.Exemption_Rate;
        END IF;

        ----------------------------------------------------------

        --enf. katsayisini bul.
        c_Max_Increase := 1;

        --insertlog ('normal süreç', 25);

        IF Nvl(Indeminfo.Max_Increase, 1) != 1 THEN
          BEGIN
            --insertlog ('normal süreç', 26);

            SELECT a.Max_Inc_Clearing_System_Id,
                   a.Max_Inc_Curr_Get_Type,
                   a.Max_Inc_Swift_Code
              INTO v_Max_Inc_Clearing_System_Id,
                   v_Max_Inc_Curr_Get_Type,
                   v_Max_Inc_Swift_Code
              FROM Koc_Oc_Prod_Package_Rel a
             WHERE a.Product_Id = Policyinfo.Product_Id
               AND a.Partition_Type = Policyinfo.Partition_Type
               AND a.Package_Id = Policyinfo.Package_Id
               AND a.Dim_Value = Nvl(Policyinfo.Group_Code, 0)
               AND a.Validity_Start_Date <= Trunc(p_Date)
               AND Nvl(a.Validity_End_Date, Trunc(p_Date)) >= Trunc(p_Date);
          EXCEPTION
            WHEN OTHERS THEN
              --insertlog ('normal süreç', 27);

              SELECT a.Max_Inc_Clearing_System_Id,
                     a.Max_Inc_Curr_Get_Type,
                     a.Max_Inc_Swift_Code
                INTO v_Max_Inc_Clearing_System_Id,
                     v_Max_Inc_Curr_Get_Type,
                     v_Max_Inc_Swift_Code
                FROM Koc_Oc_Prod_Package_Rel a
               WHERE a.Product_Id = Policyinfo.Product_Id
                 AND a.Partition_Type = Policyinfo.Partition_Type
                 AND a.Package_Id = Policyinfo.Package_Id
                 AND a.Dim_Value = '0'
                 AND a.Validity_Start_Date <= Trunc(p_Date)
                 AND Nvl(a.Validity_End_Date, Trunc(p_Date)) >=
                     Trunc(p_Date);
              --insertlog ('normal süreç', 28);
          END;

          c_Max_Increase := Koc_Curr_Utils.Retrieve_Currency_Rate(v_Max_Inc_Swift_Code,
                                                                  v_Max_Inc_Curr_Get_Type,
                                                                  Trunc(p_Date),
                                                                  v_Max_Inc_Clearing_System_Id,
                                                                  TRUE) /
                            Koc_Curr_Utils.Retrieve_Currency_Rate(v_Max_Inc_Swift_Code,
                                                                  v_Max_Inc_Curr_Get_Type,
                                                                  Trunc(Policyinfo.Policy_Start_Date),
                                                                  v_Max_Inc_Clearing_System_Id,
                                                                  TRUE);

          IF c_Max_Increase > Nvl(Indeminfo.Max_Increase, 1) THEN
            c_Max_Increase := Nvl(Indeminfo.Max_Increase, 1);
          END IF;
          --insertlog ('normal süreç', 29);
        END IF;

        -- c_r_cover_price  kurum tanimi da dikkate alinarak bulunanan kalan limit
        --  c_r_day_seance kurum tanimi da dikkate alinarak bulunanan kalan limit
        -- c_f_cover_price kurum tanimi da dikkate alinarak bulunanan    limit
        -- c_f_day_seance kurum tanimi da dikkate alinarak bulunanan  limit
        IF Nvl(c_Inst_Exemption_Sum, 0) >= 0 THEN
          IF Nvl(c_Inst_Exemption_Sum, 0) >= c_Provision_Amount THEN
            c_Inst_Exemption_Sum := c_Provision_Amount;
            c_Provision_Amount   := 0;
          ELSE
            c_Provision_Amount := c_Provision_Amount -
                                  Nvl(c_Inst_Exemption_Sum, 0);
          END IF;
        END IF;

        --27032014
        --aaktas
        --kurum için muafiyet çalismasin
        c_Exemption_Sum := 0;

        IF Nvl(c_Inst_Is_Not_Valid_Exemp, 0) = 0 THEN
          IF Nvl(Indeminfo.r_Exemption_Sum, 0) > 0 THEN
            IF Nvl(Indeminfo.r_Exemption_Sum, 0) >= c_Provision_Amount THEN
              c_Exemption_Sum    := c_Provision_Amount;
              c_Provision_Amount := 0;
            ELSE
              c_Exemption_Sum    := Nvl(Indeminfo.r_Exemption_Sum, 0);
              c_Provision_Amount := c_Provision_Amount - c_Exemption_Sum;
            END IF;
          END IF;
        END IF;

        c_Day_Seance := Nvl(p_Day_Seance, 0);

        IF Indeminfo.Indemnity_Payment_Type IN ('NORM', '1KEZ') THEN
          IF c_Is_Unlimited = 1 THEN
            IF Nvl(c_r_Day_Seance, 0) < c_Day_Seance THEN
              IF c_r_Day_Seance = 0 THEN
                c_Day_Seance_Amount := 0;
              ELSE
                c_Day_Seance_Amount := Nvl(c_r_Day_Seance, 0) *
                                       (c_Provision_Amount / c_Day_Seance);
              END IF;

              -- kalan seans sayisinin miktari kadar ödeme yapilir.
              IF c_Day_Seance_Amount < c_Provision_Amount THEN
                c_Provision_Amount := c_Day_Seance_Amount;
              END IF;

              c_Day_Seance := Nvl(c_r_Day_Seance, 0);
            END IF;

            u_r_Cover_Price      := NULL;
            u_r_Exemption_Sum    := c_Exemption_Sum;
            u_s_Provision_Amount := c_Provision_Amount *
                                    (1 - c_Exemption_Rate);
            u_s_Spend_Total      := p_Provision_Amount;
            u_s_Spend_Day_Seance := p_Day_Seance;
            u_s_Exemption_Sum    := c_Exemption_Sum;
            u_r_Day_Seance       := c_Day_Seance;
          ELSE
            --yasemin
            IF Nvl(c_r_Cover_Price, 0) * c_Max_Increase <
               (c_Provision_Amount + c_Exemption_Sum) THEN
              -- kalan limitin exemption sumdan küçük olmasi durumuda kontrol edildi. bu tip bir durum olur mu ? bilmiyorum!
              IF Nvl(c_r_Cover_Price, 0) * c_Max_Increase > c_Exemption_Sum THEN
                c_Provision_Amount := Nvl(c_r_Cover_Price, 0) *
                                      c_Max_Increase - c_Exemption_Sum;
              ELSE
                c_Provision_Amount := 0;
                c_Exemption_Sum    := Nvl(c_r_Cover_Price, 0) *
                                      c_Max_Increase;
              END IF;
            END IF;

            IF Nvl(c_r_Day_Seance, 0) < c_Day_Seance THEN
              IF c_r_Day_Seance = 0 THEN
                c_Day_Seance_Amount := 0;
              ELSE
                c_Day_Seance_Amount := Nvl(c_r_Day_Seance, 0) *
                                       (c_Provision_Amount / c_Day_Seance);
              END IF;

              -- kalan seans sayisinin miktari kadar ödeme yapilir.
              IF c_Day_Seance_Amount < c_Provision_Amount THEN
                c_Provision_Amount := c_Day_Seance_Amount;
              END IF;

              c_Day_Seance := Nvl(c_r_Day_Seance, 0);
            END IF;

            --yasemin
            u_r_Cover_Price := c_Provision_Amount;
            -- + c_exemption_sum; 17/01/2011 muafiyetin kalan limitten düsmemesi için yg
            u_r_Day_Seance       := c_Day_Seance;
            u_r_Exemption_Sum    := c_Exemption_Sum;
            u_s_Provision_Amount := c_Provision_Amount *
                                    (1 - c_Exemption_Rate);
            u_s_Spend_Total      := p_Provision_Amount;
            u_s_Spend_Day_Seance := p_Day_Seance;
            u_s_Exemption_Sum    := c_Exemption_Sum;
          END IF;
        ELSIF Indeminfo.Indemnity_Payment_Type = 'GUN' THEN
          --
          IF c_Day_Seance > c_r_Day_Seance THEN
            c_Day_Seance := c_r_Day_Seance;
          END IF;

          --
          IF Nvl(c_Day_Seance, 0) = 0 THEN
            --
            IF c_Provision_Amount > c_f_Cover_Price THEN
              c_Provision_Amount := c_f_Cover_Price;
            END IF;
          ELSE
            --
            IF c_Provision_Amount > c_f_Cover_Price * c_Day_Seance THEN
              c_Provision_Amount := c_f_Cover_Price * c_Day_Seance;
            END IF;
          END IF;

          u_r_Day_Seance       := c_Day_Seance;
          u_r_Cover_Price      := NULL;
          u_r_Exemption_Sum    := c_Exemption_Sum;
          u_s_Provision_Amount := c_Provision_Amount *
                                  (1 - c_Exemption_Rate);
          u_s_Spend_Total      := p_Provision_Amount;
          u_s_Spend_Day_Seance := p_Day_Seance;
          u_s_Exemption_Sum    := c_Exemption_Sum;
        ELSIF Indeminfo.Indemnity_Payment_Type = 'DEFA' THEN
          -----------------------------------

          Getindemtotalsmdf(p_Contract_Id,
                            p_Partition_No,
                            p_Claim_Inst_Type,
                            p_Claim_Inst_Loc,
                            p_Country_Group,
                            Indeminfo.Parent_Cover_Code,
                            p_Policyinfo.Package_Id,
                            p_Policyinfo.Package_Date,
                            Trunc(p_Date),
                            p_User_Id,
                            p_Clmprovisions(Prv).Is_Pool_Cover,
                            p_Clmprovisions(Prv).Is_Special_Cover,
                            Cur);

          FETCH Cur
            INTO Indeminfoparent;

          CLOSE Cur;

          c_Parent_Is_Unlimited   := Nvl(Indeminfoparent.Is_Unlimited, 0);
          c_Parent_Indemnity_Type := Nvl(Indeminfoparent.Indemnity_Payment_Type,
                                         'X');
          c_Parent_r_Cover_Price  := Indeminfoparent.r_Cover_Price;

          IF c_Parent_Is_Unlimited = 0 AND
             c_Parent_Indemnity_Type IN ('NORM', '1KEZ') THEN
            c_Parent_Provision_Amount := c_Provision_Amount;

            IF Nvl(c_Parent_r_Cover_Price, 0) * c_Max_Increase <
               (c_Provision_Amount + c_Exemption_Sum) THEN
              -- kalan limitin exemption sumdan küçük olmasi durumuda kontrol edildi. bu tip bir durum olur mu ? bilmiyorum!
              IF Nvl(c_Parent_r_Cover_Price, 0) * c_Max_Increase >
                 c_Exemption_Sum THEN
                c_Parent_Provision_Amount := Nvl(c_Parent_r_Cover_Price, 0) *
                                             c_Max_Increase -
                                             c_Exemption_Sum;
              ELSE
                c_Parent_Provision_Amount := 0;
                c_Exemption_Sum           := Nvl(c_Parent_r_Cover_Price, 0) *
                                             c_Max_Increase;
              END IF;
            END IF;
          END IF;

          -------------------------------------

          IF c_Provision_Amount > c_f_Cover_Price THEN
            c_Provision_Amount := c_f_Cover_Price;
          END IF;

          ------------------------------------------------------
          IF c_Parent_Is_Unlimited = 0 AND
             c_Parent_Indemnity_Type IN ('NORM', '1KEZ') THEN
            IF c_Provision_Amount > c_Parent_Provision_Amount THEN
              c_Provision_Amount := c_Parent_Provision_Amount;
            END IF;
          END IF;

          ---------------------------------------------------------------------

          IF c_Day_Seance > c_r_Day_Seance THEN
            c_Day_Seance := c_r_Day_Seance;
          END IF;

          u_r_Day_Seance  := c_Day_Seance;
          u_r_Cover_Price := NULL;

          --------------------------------------------------------------------------------
          IF c_Parent_Is_Unlimited = 0 AND
             c_Parent_Indemnity_Type IN ('NORM', '1KEZ') THEN
            u_r_Cover_Price := c_Provision_Amount;
          END IF;

          --------------------------------------------------------------------------------------

          u_r_Exemption_Sum    := c_Exemption_Sum;
          u_s_Provision_Amount := c_Provision_Amount *
                                  (1 - c_Exemption_Rate);
          u_s_Spend_Total      := p_Provision_Amount;
          u_s_Spend_Day_Seance := p_Day_Seance;
          u_s_Exemption_Sum    := c_Exemption_Sum;
        ELSIF Indeminfo.Indemnity_Payment_Type = '2YIL' THEN
          IF Nvl(Indeminfo.s_Spend_Total, 0) > 0 THEN
            c_Provision_Amount := 0;
            c_Day_Seance       := 0;
          ELSE
            Getoldpolicy(p_Contract_Id,
                         p_Partition_No,
                         p_Part_Id,
                         v_Old_Contract_Id,
                         v_Old_Partition_No,
                         v_Term_End_Date);
            --- dikkat dikkat gözden geçir
            Getindemtotals(v_Old_Contract_Id,
                           v_Old_Partition_No,
                           p_Claim_Inst_Type,
                           p_Claim_Inst_Loc,
                           p_Country_Group,
                           p_Cover_Code,
                           v_Term_End_Date,
                           0,
                           0,
                           p_User_Id,
                           p_Clmprovisions   (Prv).Is_Pool_Cover,
                           p_Clmprovisions   (Prv).Is_Special_Cover,
                           Cur);

            FETCH Cur
              INTO Oldindeminfo;

            CLOSE Cur;

            IF Nvl(Oldindeminfo.s_Spend_Total, 0) > 0 THEN
              c_Provision_Amount := 0;
              c_Day_Seance       := 0;
            ELSE
              IF c_Provision_Amount > c_f_Cover_Price THEN
                c_Provision_Amount := c_f_Cover_Price;
              END IF;

              IF c_Day_Seance > c_f_Day_Seance THEN
                c_Day_Seance := c_f_Day_Seance;
              END IF;
            END IF;
          END IF;

          u_r_Day_Seance       := c_Day_Seance;
          u_r_Cover_Price      := 0;
          u_r_Exemption_Sum    := 0;
          u_s_Provision_Amount := c_Provision_Amount *
                                  (1 - c_Exemption_Rate);
          u_s_Spend_Total      := p_Provision_Amount;
          u_s_Spend_Day_Seance := p_Day_Seance;
          u_s_Exemption_Sum    := c_Exemption_Sum;
        END IF;

        Provoutparam(Prv).p_Out_Provision_Amount := Nvl(Round(c_Provision_Amount *
                                                              (1 / v_Parite),
                                                              Find_Round_Digit(p_Swift_Code,
                                                                               'P')),
                                                        0);
        Provoutparam(Prv).p_Out_Day_Seance := c_Day_Seance;
        Provoutparam(Prv).p_Out_Exemption_Rate := Nvl(c_Exemption_Rate, 1);

        --aaktas
        --31032014
        Provoutparam(Prv).p_Inst_Is_Not_Valid_Exemp := Nvl(c_Inst_Is_Not_Valid_Exemp,
                                                           0);

        -- keks elden 1
        IF p_Policyinfo.Partition_Type <> 'KEKS' THEN
          Provoutparam(Prv).p_Out_Exemption_Sum := Round(c_Exemption_Sum *
                                                         (1 / v_Parite),
                                                         Find_Round_Digit(p_Swift_Code,
                                                                          'P'));
        END IF;

        Provoutparam(Prv).p_Out_Inst_Exemp_Sum := Round(c_Inst_Exemption_Sum *
                                                        (1 / v_Parite),
                                                        Find_Round_Digit(p_Swift_Code,
                                                                         'P'));
        Provoutparam(Prv).p_r_Day_Seance := c_r_Day_Seance;
        Provoutparam(Prv).p_r_Cover_Price := Round(c_r_Cover_Price,
                                                   Find_Round_Digit(p_Swift_Code,
                                                                    'P'));

        IF Provoutparam(Prv).p_r_Cover_Price < c_Provision_Amount THEN
          Provoutparam(Prv).p_Out_Over_Price := To_Char(c_Provision_Amount - Provoutparam(Prv)
                                                        .p_r_Cover_Price) *
                                                (1 / v_Parite);
        ELSE
          Provoutparam(Prv).p_Out_Over_Price := 0;
        END IF;

        Provoutparam(Prv).p_Inst_Provision_Aval_Code := c_Inst_Provision_Aval_Code;
        Provoutparam(Prv).p_Inst_Is_Cover_Val := c_Inst_Is_Cover_Val;
        u_s_Provision_Amount := Round(Nvl(u_s_Provision_Amount, 0),
                                      Find_Round_Digit(p_Swift_Code, 'P'));
        u_s_Spend_Total := Round(Nvl(u_s_Spend_Total, 0),
                                 Find_Round_Digit(p_Swift_Code, 'P'));
        u_s_Exemption_Sum := Round(Nvl(u_s_Exemption_Sum, 0),
                                   Find_Round_Digit(p_Swift_Code, 'P'));
        u_r_Exemption_Sum := Round(Nvl(u_r_Exemption_Sum, 0),
                                   Find_Round_Digit(p_Swift_Code, 'P'));
        u_r_Cover_Price := Round(u_r_Cover_Price,
                                 Find_Round_Digit(p_Swift_Code, 'P'));
        Ind := 1;

        WHILE Ind <= Indeminfotbl.Count LOOP
          IF Indeminfotbl(Ind).Cover_Code = Indeminfo.Parent_Cover_Code AND Indeminfotbl(Ind)
             .Claim_Inst_Type = Indeminfo.Claim_Inst_Type AND Indeminfotbl(Ind)
             .Claim_Inst_Loc = Indeminfo.Claim_Inst_Loc THEN
            Parent_r_Cover_Price := Indeminfotbl(Ind).r_Cover_Price;
            Parent_r_Day_Seance  := Indeminfotbl(Ind).r_Day_Seance;
            EXIT;
          END IF;

          Ind := Ind + 1;
        END LOOP;

        Parent_r_Cover_Price := Parent_r_Cover_Price - u_r_Cover_Price;
        Parent_r_Day_Seance  := Parent_r_Day_Seance - u_r_Day_Seance;
        Ind                  := 1;
        p_Sign               := 1;

        WHILE Ind <= Indeminfotbl.Count LOOP
          IF Indeminfotbl(Ind)
           .Parent_Cover_Code = Indeminfo.Parent_Cover_Code AND Indeminfotbl(Ind)
             .Claim_Inst_Type = Indeminfo.Claim_Inst_Type AND Indeminfotbl(Ind)
             .Claim_Inst_Loc = Indeminfo.Claim_Inst_Loc AND
              Nvl(Indeminfotbl(Ind).Is_Unlimited, 0) != 1 AND
              ((Indeminfotbl(Ind).Cover_Code != Indeminfo.Cover_Code) OR
               (Indeminfotbl(Ind).Cover_Code = Indeminfo.Cover_Code AND Indeminfotbl(Ind)
               .Is_Pool_Cover != Indeminfo.Is_Pool_Cover)) THEN
            IF p_Sign = 1 THEN
              IF Nvl(Parent_r_Cover_Price, 0) <
                 Nvl(Indeminfotbl(Ind).r_Cover_Price, 0) THEN
                Indeminfotbl(Ind).r_Cover_Price := Nvl(Parent_r_Cover_Price,
                                                       0);
              END IF;
            ELSE
              IF Nvl(Indeminfotbl(Ind).f_Cover_Price, 0) <
                 Nvl(Parent_r_Cover_Price, 0) THEN
                Indeminfotbl(Ind).r_Cover_Price := Nvl(Indeminfotbl(Ind)
                                                       .f_Cover_Price,
                                                       0);
              ELSE
                Indeminfotbl(Ind).r_Cover_Price := Nvl(Parent_r_Cover_Price,
                                                       0);
              END IF;
            END IF;
          END IF;

          IF Indeminfotbl(Ind).Cover_Code = Indeminfo.Cover_Code AND Indeminfotbl(Ind)
             .Claim_Inst_Type = Indeminfo.Claim_Inst_Type AND Indeminfotbl(Ind)
             .Claim_Inst_Loc = Indeminfo.Claim_Inst_Loc AND Indeminfotbl(Ind)
             .Is_Pool_Cover != Indeminfo.Is_Pool_Cover AND
              Nvl(Indeminfotbl(Ind).Is_Unlimited, 0) != 1 THEN
            Indeminfotbl(Ind).r_Cover_Price := Nvl(Indeminfotbl(Ind)
                                                   .r_Cover_Price,
                                                   0) +
                                               p_Sign * u_r_Cover_Price;
          END IF;

          IF Indeminfotbl(Ind).Cover_Code = Indeminfo.Cover_Code AND Indeminfotbl(Ind)
             .Claim_Inst_Type = Indeminfo.Claim_Inst_Type AND Indeminfotbl(Ind)
             .Claim_Inst_Loc = Indeminfo.Claim_Inst_Loc THEN
            IF Nvl(Indeminfotbl(Ind).r_Day_Seance, 0) < u_r_Day_Seance THEN
              Indeminfotbl(Ind).r_Day_Seance := 0;
            ELSE
              Indeminfotbl(Ind).r_Day_Seance := Indeminfotbl(Ind)
                                                .r_Day_Seance -
                                                 u_r_Day_Seance;
            END IF;
          END IF;

          IF Indeminfotbl(Ind).Exemption_Group = Indeminfo.Exemption_Group THEN
            Indeminfotbl(Ind).r_Exemption_Sum := Nvl(Indeminfotbl(Ind)
                                                     .r_Exemption_Sum,
                                                     0) -
                                                 Nvl(u_r_Exemption_Sum, 0);
          END IF;

          Ind := Ind + 1;
        END LOOP;
      END IF; -- p_prcoess_type in (0,1)

      Prv := Prv + 1;
    END LOOP;
  END Findprovamount;