      select * from koc_clm_hlth_status  a
                          where claim_id  =23095551
                            and sf_no = 1
                            and add_order_no =1
                            and exists ( select count(1)
                                           from koc_clm_hlth_status  b
                                          where b.claim_id  = a.claim_id 
                                            and b.sf_no = a.sf_no
                                            and b.add_order_no =a.add_order_no
                                            and b.status_code = a.status_code
                                            having count(1)> 0 )
                             and rownum < 2   ; 
                             
select * from hsevim.dm_table_column where table_name='KOC_CLM_HLTH_STATUS'                             

select * from all_source where upper(text) like '%KOC_CLM_HLTH_STATUS%'

PKG_LOAD_HEALTH_CLAIM_DATA

select * from koc_clm_hlth_status where process_date>TO_DATE('01/09/2018','DD/MM/YYYY') AND STATUS_CODE IS NOT NULL

select * from koc_clm_hlth_detail where claim_id=38747721--38167297
select * from clm_pol_oar where claim_id=38167297
select * from koc_clm_hlth_indem_totals where contract_id=400787805 and partition_no=1 and parent_cover_code='S174'

select * from Koc_v_cp_Health_Look_Up where look_up_code='STATUS';

SELECT * FROM ALZ_CLM_DMS_LU_DM_ROLE_MAP
	Koc_Clm_Hlth_Trnx.Delete_Provisions;
  
  Customer.Web_Provision.Assumeprovision
  
  
  SELECT * FROM DBA_DML_LOCKS;
  
  SELECT *--SID,SERIAL# 
FROM V$SESSION 
WHERE SID IN (SELECT SESSION_ID 
FROM DBA_DML_LOCKS );
