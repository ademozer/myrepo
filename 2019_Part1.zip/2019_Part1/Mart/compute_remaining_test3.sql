declare
   v_out_provision_amount NUMBER;
   v_out_day_seance NUMBER;
   v_out_exemption_rate NUMBER;
   v_out_exemption_sum NUMBER;
   v_out_inst_exemp_sum NUMBER;
   v_r_day_seance NUMBER;
   v_r_cover_price NUMBER;
   v_inst_provision_aval_code VARCHAR2(100);
   v_inst_is_cover_val NUMBER;
   v_out_over_price VARCHAR2(100);

begin
  -- Call the procedure
  customer.koc_clm_hlth_trnx.computeremaning(p_contract_id => 383164557,
                                             p_partition_no => 1,
                                             p_part_id => 59862896,
                                             p_claim_id => null,
                                             p_sf_no => null,
                                             p_institute_code => 323,
                                             p_claim_inst_type => 'AK',
                                             p_claim_inst_loc => 'YI',
                                             p_country_group => 0,
                                             p_location_code => NULL,
                                             p_cover_code => 'S511',
                                             p_swift_code => 'TL',
                                             p_date => SYSDATE,
                                             p_invoice_date => SYSDATE,
                                             p_realization_date => SYSDATE,
                                             p_prov_date_time => SYSDATE,
                                             p_provision_amount => 206.55,
                                             p_day_seance => 0,
                                             p_user_id => 'MEDISER28',
                                             p_is_pool_cover => 0,
                                             p_is_special_cover => 0,
                                             p_process_type => 0,
                                             p_out_provision_amount => v_out_provision_amount,
                                             p_out_day_seance => v_out_day_seance,
                                             p_out_exemption_rate => v_out_exemption_rate,
                                             p_out_exemption_sum => v_out_exemption_sum,
                                             p_out_inst_exemp_sum => v_out_inst_exemp_sum,
                                             p_r_day_seance => v_r_day_seance,
                                             p_r_cover_price => v_r_cover_price,
                                             p_inst_provision_aval_code => v_inst_provision_aval_code,
                                             p_inst_is_cover_val => v_inst_is_cover_val,
                                             p_out_over_price => v_out_over_price,
                                             p_exemption_ovr_amount => null,
                                             p_is_referral => null);
DBMS_OUTPUT.PUT_LINE('p_prov_amo='||v_out_provision_amount);
DBMS_OUTPUT.PUT_LINE('p_day_seans='||v_out_day_seance);
DBMS_OUTPUT.PUT_LINE('p_exemp_rate='||v_out_day_seance);
DBMS_OUTPUT.PUT_LINE('p_day_seans='||v_out_day_seance);
DBMS_OUTPUT.PUT_LINE('p_day_seans='||v_out_day_seance);
DBMS_OUTPUT.PUT_LINE('p_day_seans='||v_out_day_seance);
DBMS_OUTPUT.PUT_LINE('p_day_seans='||v_out_day_seance);
DBMS_OUTPUT.PUT_LINE('p_day_seans='||v_out_day_seance);

end;
