DECLARE
    v_url VARCHAR2(400);
    function get_url(p_url1 IN VARCHAR2,p_url2 IN VARCHAR2) RETURN VARCHAR2 IS
      v_parameter VARCHAR2(10);
    BEGIN
         v_parameter := CUSTOMER.KOC_CLM_HLTH_UTILS.Getlookupparamvalue('HCLM_USAGE',SYSDATE);
         IF NVL(v_parameter,0) = 2 THEN
             RETURN p_url1;
         END IF;

         RETURN p_url2;
    END get_url;
    
    FUNCTION numberToString(p_number IN NUMBER) RETURN VARCHAR2 IS 
      v_string VARCHAR2(100);
    BEGIN
        v_string := REPLACE(TO_CHAR(p_number),',','.');   
        IF INSTR(v_string,'.') = 1 THEN         
           v_string := '0'||v_string;      
        END IF;
        RETURN v_string;
    END numberToString;
    
    FUNCTION stringToNumber(p_string IN VARCHAR2) RETURN NUMBER IS
    BEGIN
       RETURN TO_NUMBER(p_string,'999999.9999');
    END stringToNumber;
    
 BEGIN
   
 v_url := get_url('url1','url2');
 --v_url := numberToString(6/4);
-- dbms_output.put_line(numberToString(stringToNumber('931.77')));
 dbms_output.put_line(v_url);
 END;
 
