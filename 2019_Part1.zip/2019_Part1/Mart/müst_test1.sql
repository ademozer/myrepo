DECLARE 
         v_request CLOB;
         v_response CLOB;
         v_url VARCHAR2(200) := 'http://10.70.47.55:19101/hclm-health-claim-service/api/v1/provision/insuredinquiry'; 
         v_status NUMBER;
         v_message VARCHAR2(1000);     
    PROCEDURE initInsuredAndPolicyInfo(p_Part_Id IN NUMBER,--:Koc_Clm_Hlth_Detail.Part_Id,
                                       p_Card_No IN NUMBER,--:Koc_Clm_Hlth_Detail.Card_No,
                                       p_Policy_Ref IN VARCHAR2(100), --  :Koc_Clm_Hlth_Detail.Policy_Ref,
                                       p_Partition_No IN NUMBER, -- :Koc_Clm_Hlth_Detail.Partition_No,
                                       p_Identity_no IN NUMBER, --      --:Koc_Clm_Hlth_Detail.Insured_Identity_No,
                                                   Insuredinforef,
                                              Policyinforef);      
    
   BEGIN
       
       v_request := '{ 
        "instituteInfo": {
          "instituteCodeAllz": 6269
        },
        "insuredNoInfo": {
          "insuredNo": "0001171006127544-2",
          "insuredNoType": "POLICE_NO"
        }
      }';
       ALZ_HCLM_CONVERTER_UTILS.callRestService(v_url, 'POST', v_request, v_response, v_status, v_message);
       
       DBMS_OUTPUT.PUT_LINE(v_response);
       DBMS_OUTPUT.PUT_LINE(v_status);
       DBMS_OUTPUT.PUT_LINE(v_message);
       
       
       KOC_CLM_HLTH_UTILS.IS_SAME_NETWORK;
       
       Getnetworkclaiminsttype
       
    
   END;
   --Koc_Clm_Hlth_Utils.Getpolicyinfobypartid(:Koc_Clm_Hlth_Detail.Part_Id, :Koc_Clm_Hlth_Detail.Provision_Date_Time, Policyinforef);
 --  Koc_Clm_Hlth_Utils.Getinsuredinfobypartnerid(:Koc_Clm_Hlth_Detail.Part_Id, Insuredinforef);
--SELECT CUSTOMER.KOC_CLM_HLTH_UTILS.Getlookupparamdesc('GEND','F', NULL) FROM DUAL


SELECT *--SERVICENAME, PROCESSINFO, HCLM_ERROR_LOCATION, COUNT(1) ERROR_COUNT
FROM BORAD.CGM_INTEGRATIONS A 
WHERE A.SERVICENAME = 'ProvisionServiceCtrlImpl' AND A.PROCESSINFO = 'provisionRequestWS'
GROUP BY SERVICENAME, PROCESSINFO, HCLM_ERROR_LOCATION ORDER BY 4 DESC


SELECT CUSTOMER.KOC_CLM_HLTH_UTILS.Getlookupparamdesc('CLIT','AHK', NULL) FROM DUAL
