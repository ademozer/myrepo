DECLARE
  v_response CLOB;
   v_status   NUMBER := 0;
   v_ndx1 NUMBER;
   v_ndx2 NUMBER;
BEGIN
  
v_response := '{
   "data":    {
      "claimDetailDto": {"extReference" : "1111"},
      "provisionList" : {},
      "overPrice": null
   },
   "uiMessages":    {
      "errorx": [      {
         "code": null,
         "message": "200 i�inde hata",
         "severity": "ERROR"
      }],
      "warnings": [],
      "infos": []
   }
}';
v_response := TRIM(regexp_replace(v_response, '([^[:graph:] | ^[:blank:]])', ''));
IF v_status = 0 AND INSTR(v_response,'"errors"')>0 THEN
   v_status := 1;
END IF;
DBMS_OUTPUT.PUT_LINE(v_response);
 IF v_status = 0 THEN
             v_ndx1 := INSTR(v_response,'"claimDetailDto"');
             DBMS_OUTPUT.PUT_LINE('ndx1='||v_ndx1);
             v_ndx2 := INSTR(v_response,'"provisionList"') - v_ndx1;         
             v_response := SUBSTR(v_response, v_ndx1+19, v_ndx2-27); 
              DBMS_OUTPUT.PUT_LINE('A');         
         ELSE 
             v_ndx1 := INSTR(v_response,'"errors"');
             --v_ndx1 := INSTR(v_response,' "errors": [');
             DBMS_OUTPUT.PUT_LINE('ndx1='||v_ndx1);
             v_ndx2 := INSTR(v_response, '"warnings"') - v_ndx1;           
             v_response := TRIM(SUBSTR(v_response, v_ndx1+20, v_ndx2-36));   
              DBMS_OUTPUT.PUT_LINE('B');        
         END IF;
       DBMS_OUTPUT.PUT_LINE(v_response);
         
         FOR rec IN (SELECT TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1) , '"',''))   KEY, 
                            TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1, 2), '"','')) VALUE              
                       FROM (SELECT Regexp_Substr (v_response, '[^,]+', 1, LEVEL) ELEMENT
                               FROM Dual
                            CONNECT BY LEVEL <= LENGTH (Regexp_Replace (v_response, '[^,]+')) + 1)) LOOP           
             /*IF rec.KEY IN('extReference','message') THEN
                 v_message := rec.value;
             END IF;*/
             DBMS_OUTPUT.PUT_LINE(rec.KEY||':'||rec.VALUE);
         END LOOP;
         
END;
