/*create function pipetest return sys.odcinumberlist pipelined as
begin
  for i in 1..5 loop
    pipe row(i);
    dbms_output.put_line('Piped ' || i);
  end loop;
  return;
end;
/
*/
begin
  for r in (select * from table(pipetest)) loop
    dbms_output.put_line('Got ' || r.column_value);
    --return;
  end loop;
end;


/*declare
  cursor c is select * from table(pipetest);
  n number;
begin
  open c;
  loop
    fetch c into n;
    exit when c%notfound;
    dbms_output.put_line('Got ' || n);
    if n = 3 then
      return;
    end if;
  end loop;
  close c;
end;
*/
