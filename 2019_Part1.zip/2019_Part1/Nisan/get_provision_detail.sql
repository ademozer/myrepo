DECLARE
 v_provision_list CLOB;
 v_claim_id NUMBER := 41904775;--40178198;--40178144;
 Clmprovision KOC_CLM_HLTH_TRNX.Clmprovisiontype;
 ndx NUMBER := 0;
   FUNCTION booleanToString(p_boolean IN NUMBER) RETURN VARCHAR2 IS
    BEGIN
        RETURN (CASE NVL(p_boolean, 0) WHEN 1 THEN 'true' ELSE 'false' END);
    END booleanToString;

    FUNCTION dateToString(p_date IN DATE) RETURN VARCHAR2 IS
          v_date  DATE;
          v_timestamp TIMESTAMP;
          v_return VARCHAR2(100);
    BEGIN
        v_return := '';
        v_date := p_date;
        IF v_date IS NOT NULL THEN
           v_timestamp := CAST (v_date AS TIMESTAMP);
           v_return := TO_CHAR(v_date,'YYYY-MM-DD')||'T'||TO_CHAR(v_timestamp,'HH24:MI:SS.FF3')||dbtimezone;
        END IF;
        RETURN v_return;
    END dateToString;

    FUNCTION numberToString(p_number IN NUMBER) RETURN VARCHAR2 IS
        v_string VARCHAR2(100);
    BEGIN
        v_string := REPLACE(TO_CHAR(p_number),',','.');
        IF INSTR(v_string,'.') = 1 THEN
           v_string := '0'||v_string;
        END IF;
        RETURN v_string;
    END numberToString;
     FUNCTION adjustEscapeChars(p_string IN VARCHAR2) RETURN VARCHAR2 IS
       v_string VARCHAR2(32000);
    BEGIN
        v_string := REPLACE(p_string, CHR(39), CHR(39)||CHR(39));
        --v_string := regexp_replace(p_string, '([^[:graph:] | ^[:blank:]])', '');
        RETURN v_string;
    END adjustEscapeChars;
BEGIN
     v_provision_list := '[';
          FOR rec IN  (SELECT *
        FROM Koc_Clm_Hlth_Provisions
       WHERE Claim_Id = v_Claim_Id
         AND Sf_No = 1
         AND Add_Order_No = 1) LOOP
              IF ndx > 1 THEN
                 v_provision_list := v_provision_list || ',';
              END IF;
              v_provision_list := v_provision_list || '{
                "daySeance" : "'|| TO_CHAR(rec.DAY_SEANCE)||'",
                "exemptionAmount" : "'|| numberToString(rec.EXEMPTION_AMOUNT)||'",
                "entryDate" : "'|| dateToString(rec.ENTRY_DATE)||'",
                "countryCode" : "'||rec.COUNTRY_CODE||'",
                "exemptionRate" : "'|| numberToString(rec.EXEMPTION_RATE)||'",
                "addOrderNo" : "'|| TO_CHAR(rec.ADD_ORDER_NO)||'",
                "addProcAmount" : "'|| numberToString(rec.ADD_PROC_AMOUNT)||'",
                "doctorCode" : "'|| TO_CHAR(rec.DOCTOR_CODE)||'",
                "doctorStatus" : "'||rec.DOCTOR_STATUS||'",
                "breResultCode" : "'||rec.BRE_RESULT_CODE||'",
                "coverDistributionAmount" : "'|| numberToString(rec.COVER_DISTRIBUTION_AMOUNT)||'",
                "claimId" : "'|| TO_CHAR(rec.CLAIM_ID)||'",
                "coverCode" : "'||rec.COVER_CODE||'",
                "isExGratia" : "'|| TO_CHAR(rec.IS_EX_GRATIA)||'",
                "isPoolCover" : "'|| TO_CHAR(rec.IS_POOL_COVER)||'",
                "isSpecialCover" : "'|| TO_CHAR(rec.IS_SPECIAL_COVER)||'",
                "procRequestAmount" : "'|| numberToString(rec.PROC_REQUEST_AMOUNT)||'",
                "procRefusalAmount" : "'|| numberToString(rec.PROC_REFUSAL_AMOUNT)||'",
                "instExemptionAmount" : "'|| numberToString(rec.INST_EXEMPTION_AMOUNT)||'",
                "instRequestAmount" : "'|| numberToString(rec.INST_REQUEST_AMOUNT)||'",
                "provDateTime" : "'|| dateToString(rec.PROV_DATE_TIME)||'",
                "orderNo" : "'||rec.ORDER_NO||'",
                "instAddProcAmount" : "'|| numberToString(rec.INST_ADD_PROC_AMOUNT)||'",
                "locationCode" : "'|| TO_CHAR(rec.LOCATION_CODE)||'",
                "provisionTotal" : "'|| numberToString(rec.PROVISION_TOTAL)||'",
                "provisionExplanation" : "'||rec.PROVISION_EXPLANATION||'",
                "requestAmount" : "'|| numberToString(rec.REQUEST_AMOUNT)||'",
                "refusalAmount" : "'|| numberToString(rec.REFUSAL_AMOUNT)||'",
                "swiftCode" : "'||rec.SWIFT_CODE||'",
                "reqCureDayCount" : "'|| TO_CHAR(rec.REQ_CURE_DAY_COUNT)||'",
                "statusCode" : "'||rec.STATUS_CODE||'",
                "userId" : "'||rec.USER_ID||'",
                "sysRequestAmount" : "'|| numberToString(rec.SYS_REQUEST_AMOUNT)||'",
                "sgkAmount" : "'|| numberToString(rec.SGK_AMOUNT)||'",
                "timeStamp" : "'|| dateToString(rec.TIME_STAMP)||'",
                "subPackageId" : "'|| TO_CHAR(rec.SUB_PACKAGE_ID)||'",
                "subPackageDate" : "'|| dateToString(rec.SUB_PACKAGE_DATE)||'",
                "sfNo" : "'|| TO_CHAR(rec.SF_NO)||'"
              }';
              ndx := ndx + 1;
          END LOOP;
          v_provision_list := v_provision_list || ']';
          FOR rec IN (SELECT *
        FROM Koc_Clm_Hlth_Detail
       WHERE Claim_Id = v_Claim_Id) LOOP
           v_provision_list := v_provision_list || 'clm_detail:{
             "claimId" : "'|| TO_CHAR(rec.Claim_Id)||'",
              "addOrderNo" : "'|| TO_CHAR(rec.Add_Order_No)||'",
              "sfNo" : "'|| TO_CHAR(rec.Sf_No)||'",
              "ahek" : "'|| booleanToString(rec.Is_Ahek)||'",
              "automated" : "'|| booleanToString(rec.IS_AUTOMATED)||'",
              "beforeComplaintIllness" : "'||rec.BEFORE_COMPLAINT_ILLNESS||'",
              "breResultCode" : "'||rec.BRE_RESULT_CODE||'",
              "claimInstLoc" : "'||rec.CLAIM_INST_LOC||'",
              "claimInstType" : "'||rec.CLAIM_INST_TYPE||'",
              "claimStatusType" : "'||rec.STATUS_CODE||'",
              "classDisease1" : "'||rec.CLASS_DISEASE_1||'",
              "classDisease2" : "'||rec.CLASS_DISEASE_2||'",
              "classDisease3" : "'||rec.CLASS_DISEASE_3||'",
              "closeDate" : "'|| dateToString(rec.CLOSE_DATE)||'",
              "commDate" : "'|| dateToString(rec.COMM_DATE)||'",
              "communicationExp1" : "'||adjustEscapeChars(rec.COMMUNICATION_EXP1)||'",
              "communicationExp2" : "'||adjustEscapeChars(rec.COMMUNICATION_EXP2)||'",
              "communicationNo" : "'|| TO_CHAR(rec.COMMUNICATION_NO)||'",
              "communicationNumber1" : "'||rec.COMMUNICATION_NUMBER1||'",
              "communicationNumber2" : "'||rec.COMMUNICATION_NUMBER2||'",
              "complaintStart" : "'||rec.COMPLAINT_START||'",
              "complementary" : "'|| booleanToString(rec.IS_COMPLEMENTARY)||'",
              "consultationDiagnosis" : "'||rec.CONSULTATION_DIAGNOSIS||'",
              "contractMessage" : "'||adjustEscapeChars(rec.CONTRACT_MESSAGE)||'",
              "countryCode" : "'||rec.COUNTRY_CODE||'",
              "cpaStatus" : "'||rec.CPA_STATUS||'",
              "dateOfLoss" : "'|| dateToString(rec.DATE_OF_LOSS)||'",
              "deductionRate" : "'|| TO_CHAR(rec.DEDUCTION_RATE)||'",
              "dhInst" : "'|| TO_CHAR(rec.DH_INST)||'",
              "dischargeDate" : "'||dateToString(rec.DISCHARGE_DATE)||'",
              "doctorCode" : "'|| TO_CHAR(rec.DOCTOR_CODE)||'",
              "doctorStatus" : "'|| rec.DOCTOR_STATUS||'",
              "doctorType" : "'|| rec.DOCTOR_TYPE||'",
              "drDiplomaNo" : "'|| rec.DR_DIPLOMA_NO||'",
              "drNameLastname" : "'|| adjustEscapeChars(rec.DR_NAME_LASTNAME)||'",
              "eprescriptionNo" : "'|| TO_CHAR(rec.E_PRESCRIPTION_NO)||'",
              "exGratia" : "'|| booleanToString(rec.IS_EX_GRATIA)||'",
              "exGratiaFee" : "'|| TO_CHAR(rec.EX_GRATIA_FEE)||'",
              "examDate" : "'|| dateToString(rec.EXAM_DATE)||'",
              "examinationsResults" : "'|| rec.EXAMINATIONS_RESULTS||'",
              "explanation" : "'|| adjustEscapeChars(rec.EXPLANATION)||'",
              "extDoctor" : "'|| booleanToString(rec.IS_EXT_DOCTOR)||'",
              "extDoctorAmt" : "'|| TO_CHAR(rec.EXT_DOCTOR_AMT)||'",
              "finalClassDisease1" : "'|| rec.FINAL_CLASS_DISEASE_1||'",
              "finalClassDisease2" : "'|| rec.FINAL_CLASS_DISEASE_2||'",
              "finalClassDisease3" : "'|| rec.FINAL_CLASS_DISEASE_3||'",
              "fromCityCode" : "'|| rec.FROM_CITY_CODE||'",
              "fromDistrictCode" : "'|| rec.FROM_DISTRICT_CODE||'",
              "fromToPlace" : "'|| rec.FROM_TO_PLACE||'",
              "groupCode" : "'|| rec.GROUP_CODE||'",
              "hasUnreadableDoc" : "'|| rec.HAS_UNREADABLE_DOC||'",
              "hlthSrvPay" : "'|| TO_CHAR(rec.HLTH_SRV_PAY)||'",
              "hospitalAmt" : "'|| TO_CHAR(rec.HOSPITAL_AMT)||'",
              "hospitalRefNo" : "'|| rec.HOSPITAL_REF_NO||'",
              "hospitalizeApprFormExpl1" : "'|| adjustEscapeChars(rec.HOSPITALIZE_APPR_FORM_EXPL_1)||'",
              "hospitalizeApprFormExpl2" : "'|| adjustEscapeChars(rec.HOSPITALIZE_APPR_FORM_EXPL_2)||'",
              "hospitalizeDate" : "'||dateToString(rec.HOSPITALIZE_DATE)||'",
              "identitiyType" : "'|| rec.IDENTITIY_TYPE||'",
              "identityNo" : "'|| rec.IDENTITY_NO||'",
              "identityNumber" : "'|| rec.IDENTITY_NUMBER||'",
              "instGlnCode" : "'|| rec.INST_GLN_CODE||'",
              "instTaxNumber" : "'|| rec.INST_TAX_NUMBER||'",
              "instTaxOffice" : "'|| rec.INST_TAX_OFFICE||'",
              "instituteCode" : "'|| TO_CHAR(rec.INSTITUTE_CODE)||'",
              "invoiceDate" : "'||dateToString(rec.INVOICE_DATE)||'",
              "invoiceExplanation" : "'|| adjustEscapeChars(rec.INVOICE_EXPLANATION)||'",
              "invoiceNo" : "'|| rec.INVOICE_NO||'",
              "invoiceTotal" : "'|| numberToString(rec.INVOICE_TOTAL)||'",
              "judicial" : "'|| booleanToString(rec.IS_JUDICIAL)||'",
              "lastMenstDate" : "'||dateToString(rec.LAST_MENST_DATE)||'",
              "medicalBackground" : "'|| rec.MEDICAL_BACKGROUND||'",
              "medulaDate" : "'||dateToString(rec.MEDULA_DATE)||'",
              "nationality" : "'||rec.NATIONALITY||'",
              "ok" : "'|| booleanToString(rec.IS_OK)||'",
              "onlyExaminationFee" : "'|| booleanToString(rec.IS_ONLY_EXAMINATION_FEE)||'",
              "origClaimInstLoc" : "'|| rec.ORIG_CLAIM_INST_LOC||'",
              "origClaimInstType" : "'|| rec.ORIG_CLAIM_INST_TYPE||'",
              "original" : "'|| booleanToString(rec.IS_ORIGINAL)||'",
              "otherCountry" : "'|| rec.OTHER_COUNTRY||'",
              "otherCountryCity" : "'|| rec.OTHER_COUNTRY_CITY||'",
              "packageDate" : "'|| dateToString(rec.PACKAGE_DATE)||'",
              "packageId" : "'|| TO_CHAR(rec.PACKAGE_ID)||'",
              "partId" : "'|| TO_CHAR(rec.PART_ID)||'",
              "patientAdmittanceDate" : "'|| dateToString(rec.PATIENT_ADMITTANCE_DATE)||'",
              "patientComplaint" : "'|| rec.PATIENT_COMPLAINT||'",
              "patientVisitMade" : "'|| booleanToString(rec.IS_PATIENT_VISIT_MADE)||'",
              "paymentTotal" : "'|| numberToString(rec.PAYMENT_TOTAL)||'",
              "personalNotes" : "'|| rec.PERSONAL_NOTES||'",
              "plannedTreatmentProc" : "'|| rec.PLANNED_TREATMENT_PROC||'",
              "possDischargeDate" : "'|| dateToString(rec.POSS_DISCHARGE_DATE)||'",
              "possHospitalizeDate" : "'|| dateToString(rec.POSS_HOSPITALIZE_DATE)||'",
              "prediagnosisDiagnosis" : "'|| rec.PREDIAGNOSIS_DIAGNOSIS||'",
              "pregnant" : "'|| booleanToString(rec.IS_PREGNANT)||'",
              "prescriptionDate" : "'|| dateToString(rec.PRESCRIPTION_DATE)||'",
              "prescriptionNo" : "'|| TO_CHAR(rec.PRESCRIPTION_NO)||'",
              "prescriptionType" : "'|| TO_CHAR(rec.PRESCRIPTION_TYPE)||'",
              "processDate" : "'|| dateToString(rec.PROCESS_DATE)||'",
              "provisionFeeChargeDate" : "'|| dateToString(rec.PROVISION_FEE_CHARGE_DATE)||'",
              "provisionDate" : "'|| dateToString(rec.PROVISION_DATE)||'",
              "provisionUserId" : "'||rec.PROVISION_USER_ID||'",
              "provDemandDate" : "'|| dateToString(rec.PROV_DEMAND_DATE)||'",
              "processExp" : "'||rec.PROCESS_EXP||'",
              "sgkRefNo" : "'||rec.SGK_REF_NO||'",
              "socSecInstApp" : "'|| TO_CHAR(rec.SOC_SEC_INST_APP)||'",
              "shippingDate" : "'|| dateToString(rec.SHIPPING_DATE)||'",
              "shippingNo" : "'|| TO_CHAR(rec.SHIPPING_NO)||'",
              "realizationDate" : "'|| dateToString(rec.REALIZATION_DATE)||'",
              "relClaimId" : "'|| TO_CHAR(rec.REL_CLAIM_ID)||'",
              "sgkTotal" : "'|| numberToString(rec.SGK_TOTAL)||'",
              "referralInstituteName" : "'||rec.REFERRAL_INSTITUTE_NAME||'",
              "requestAmount" : "'|| numberToString(rec.REQUEST_AMOUNT)||'",
              "requestSystem" : "'||rec.REQUEST_SYSTEM||'",
              "sgkUsed" : "'|| booleanToString(rec.IS_SGK_USED)||'",
              "referral" : "'|| booleanToString(rec.IS_REFERRAL)||'",
              "suspense" : "'|| booleanToString(rec.IS_SUSPENSE)||'",
              "suspenseDate" : "'|| dateToString(rec.SUSPENSE_DATE)||'",
              "specialtySubject" : "'||rec.SPECIALTY_SUBJECT||'",
              "statusCode" : "'||rec.STATUS_CODE||'",
              "swiftCode" : "'||rec.SWIFT_CODE||'",
              "toCityCode" : "'||rec.TO_CITY_CODE||'",
              "toDistrictCode" : "'||rec.TO_DISTRICT_CODE||'",
              "timeStamp" : "'|| rec.TIME_STAMP||'",
              "surgeryDate" : "'|| dateToString(rec.SURGERY_DATE)||'",
              "visitingReason" : "'|| TO_CHAR(rec.VISITING_REASON)||'",
              "urgentCure" : "'|| booleanToString(rec.IS_URGENT_CURE)||'",
              "wrongProvision" : "'|| booleanToString(rec.IS_WRONG_PROVISION)||'",
              "web" : "'|| booleanToString(rec.IS_WEB)||'",
              "webLocationCode" : "'|| TO_CHAR(rec.WEB_LOCATION_CODE)||'",
              "ytType" : "'||rec.YT_TYPE||'"
           }';
       END LOOP;
        
          DBMS_OUTPUT.PUT_LINE(v_provision_list);
END;
          
