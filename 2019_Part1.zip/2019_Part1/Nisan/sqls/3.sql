select * from alz_hltprv_log where institutecode='20000' and log_date>trunc(sysdate) and note LIKE '%UPDATE%'--log_id = 118782320

select * from koc_clm_hlth_indem_totals where contract_id=353770740 and partition_no=1 and cover_code='S175'


select * from ALZ_HLTH_CPA_PROCESS;

 ALZ_HLTH_CPA_BPM_OPERATIONS.Cancel_Process_Instance
 
 SELECT * FROM KOC_CLM_HLTH_DETAIL;
 
 select * from alz_hltprv_log where log_id = 118783906
