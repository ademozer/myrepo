select * from mail_report_exports where trunc(send_date) = trunc(sysdate)

select * from eprovision_groups

select * from all_source where lower(text) like '%kocrepocp%'
