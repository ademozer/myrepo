  Select *
    from (SELECT CASE WHEN LOCATION_CODE IS NOT NULL THEN LOCATION_CODE
            ELSE (CASE WHEN (select SUM(CASE WHEN location_code=920 THEN 1 ELSE 0 END) 
                               from koc_clm_hlth_provisions 
                              where claim_id = p.claim_id) = 1 THEN 920
                       ELSE 910
                  END)
            END LOCATION_CODE,CLAIM_ID,INSTANCE_ID,UNIT_ID,INSTITUTE_CODE,CREATED_BY,CREATE_DATE,STATED_BY,STATE_DATE,STATUS_CODE,IS_EMERGENCY,ROLE_TYPE,PRIORITIZATION
   FROM KOC_CLM_WEB_AUTH_POOL p) r
   WHERE 1 = 1
     and nvl(stated_by, 'null') in ('null', 'MEDISER28')
     and nvl(is_emergency, 0) = 0
     --and claim_id = 40178403
     and LOCATION_CODE = 920
     and decode(NVL(role_type, 'BST'), 'BST', 0, 'KMP', 1, 'YNT', 2) <=
         decode('KMP', 'BST', 1, 'KMP', 2, 'YNT', 3)
     and nvl(status_code, 'null') NOT IN ('C', 'AD')
     and UNIT_ID IN (1, 6, 19759)
   ORDER BY 1;

SELECT CASE WHEN LOCATION_CODE IS NOT NULL THEN LOCATION_CODE
            ELSE (CASE WHEN (select SUM(CASE WHEN location_code=920 THEN 1 ELSE 0 END) 
                               from koc_clm_hlth_provisions 
                              where claim_id = p.claim_id) = 1 THEN 920
                       ELSE 910
                  END)
            END LOCATION_CODE,p.*
   FROM KOC_CLM_WEB_AUTH_POOL p
  WHERE claim_id = 40178403 
              
            
            
