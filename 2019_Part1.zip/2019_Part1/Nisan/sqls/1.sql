select * from alz_hltprv_log where log_id = 122546712

select * from Koc_Cc_Hlth_Tda_Proc_List where process_code_main=89 and process_code_sub1=20 and process_code_sub2=223
select * from Koc_Cc_Hlth_Tda_Proc_List_Hie where parent_process_code_main=89 and parent_process_code_sub1=20 and child_process_code_sub2=223
