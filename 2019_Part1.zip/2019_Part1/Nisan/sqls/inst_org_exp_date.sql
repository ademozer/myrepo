insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (195, to_date('01-01-2013', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (386, to_date('01-01-2013', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (636, to_date('13-09-2007', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (824, to_date('19-03-2014', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (891, to_date('01-10-2011', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (975, to_date('01-03-2008', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (977, to_date('30-05-2010', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (1039, to_date('24-06-2013', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (3161, to_date('07-04-2015', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (1143, to_date('06-12-2011', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (1166, to_date('17-07-2013', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (1179, to_date('01-01-2013', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (1244, to_date('13-02-2014', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (1280, to_date('10-09-2013', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (1331, to_date('06-12-2011', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (1346, to_date('06-12-2011', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (1355, to_date('15-06-2012', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (1372, to_date('10-03-2009', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (1511, to_date('01-06-2010', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (1525, to_date('15-06-2011', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (1713, to_date('01-07-2013', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (2138, to_date('01-12-2010', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (2282, to_date('23-11-2011', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (2508, to_date('10-01-2012', 'dd-mm-yyyy'));

insert into inst_exp_date (INSTITUTE_CODE, EXP_DATE)
values (2769, to_date('01-01-2014', 'dd-mm-yyyy'));

