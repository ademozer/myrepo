with provisions AS (select claim_id,location_code 
from koc_clm_hlth_provisions where entry_date>SYSDATE-1) 
SELECT claim_id,location_code FROM provisions p1
WHERE EXISTS(SELECT 1 FROM provisions WHERE claim_id=p1.claim_id AND location_code='910')
AND EXISTS(SELECT 1 FROM provisions WHERE claim_id=p1.claim_id AND location_code='920')
AND EXISTS(SELECT 1 FROM koc_clm_web_auth_pool WHERE claim_id=p1.claim_id)
AND EXISTS(SELECT 1 FROM koc_clm_hlth_detail  WHERE claim_id=p1.claim_id AND REQUEST_SYSTEM='WS')


SELECT WEB_LOCATION_CODE,EXT_REFERENCE FROM KOC_CLM_HLTH_DETAIL WHERE claim_id=40178331--40476642--40482190 
SELECT * FROM koc_clm_web_auth_pool where claim_id=40178403 FOR UPDATE--40476642--40482190 

SELECT * FROM CUSTOMER.ALZ_DUPLICATE_PROVISION WHERE ext_reference='57011422'--'57015132'

SELECT * FROM ALZ_HLTPRV_LOG WHERE LOG_ID=121393657--121449581

select WEB_LOCATION_CODE,CLAIM_ID FROM KOC_CLM_HLTH_DETAIL where ext_reference='56789079' FOR update
SELECT * FROM koc_clm_hlth_provisions where claim_id=40178403 FOR update
