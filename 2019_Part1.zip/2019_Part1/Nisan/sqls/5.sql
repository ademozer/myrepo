select * from ALZ_HCLM_INSTITUTE_INFO for update

select * from koc_v_cp_health_look_up where look_up_code='HCLM_USAGE'

select * from alz_hltprv_log where log_id > 118782737 and log_date>to_date('16/04/2019 13:50:00','DD/MM/YYYY HH24:MI:SS')

select * from koc_clm_hlth_detail where claim_id=40177772 

select * from koc_clm_hlth_detail where ext_reference='56789375'

select * from koc_cc_hlth_loc_cover_proc where process_code_main=10 ;


select * from alz_hltprv_log where log_id = 118783558


and process_code_sub1=10 
and process_code_sub2=101
and location_code=920 and validity_end_date is null;

ALZ_HCLM_CONVERTER_UTILS;
KOC_CLM_HLTH_TRNX
