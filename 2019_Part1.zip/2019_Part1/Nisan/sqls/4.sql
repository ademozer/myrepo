select * from Koc_Clm_Status_History_Ext where claim_id=25713874

select * from alz_hltprv_log where log_id=118783666--118781439--118781224  --118781213

select * from alz_hclm_institute_info for update

select ALZ_HCLM_CONVERTER_UTILS.getHclmUsageForInst(20000) FROM DUAL;

select * from all_source where upper(text) like '%KOC_CC_HLTH_CONTRACT_VAL%'

select * from KOC_CC_HLTH_CONTRACT_VAL where cont_disc_group_code='BT' and cont_institute_code=13;


ALZ_HLTPRV_INS_PRC_CONT_UTILS


koc_clm_hlth_trnx2.cancelClmRealization

select * from koc_clm_hlth_detail d where provision_date IS NULL and invoice_date>TO_DATE('01/03/2019','DD/MM/YYYY')
and exists(select 1 from koc_clm_hlth_provisions where claim_id=d.claim_id)


select * from customer.alz_duplicate_provision where ext_reference = '56788975'--'56788943'--'56775506'
select * from alz_hltprv_log where log_date>trunc(sysdate) and institutecode='20000'  order by log_date desc--log_id=118617430

select * from koc_clm_hlth_detail where ext_reference='56788943'--'56788943'
select * from koc_clm_hlth_provisions where claim_id=40178197--40178198--40178144
select * from koc_clm_hlth_proc_detail where claim_id=40178144
ALZ_HLTPRV_FAXID_SEQ ;

KOC_CLM_HLTH_INDEM_TOTALS 
select * from 
select * from koc_clm_hlth_indem_totals where contract_id=442147004 and partition_no=188 and cover_code='S513'
SELECT * FROM koc_cc_hlth_loc_cover_proc where process_code_main=60 and process_code_sub1=39 and process_code_sub2=166 and validity_end_date IS NULL


SELECT * FROM DENEME@KASCV@EPROVIZYON
