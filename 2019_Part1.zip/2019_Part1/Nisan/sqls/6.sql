BEGIN
  SELECT *
    FROM (SELECT EXEMPTION_RATE2,CHILD_COVER_CODE,EXEMPTION_RATE
             FROM koc_oc_hlth_expack_cov_rel
            WHERE /*rownum <2  and*/
            main_rule_code = '3'
        -- and sub_rule_code = '34'
        -- AND CHILD_COVER_CODE = ''
        AND EXEMPTION_RATE IS NOT NULL
        AND EXEMPTION_RATE != '0'
         AND CLAIM_INST_LOC = 'YI'
         AND CLAIM_INST_TYPE = 'AHK'
         AND CONTRACT_ID = TO_NUMBER('0')
         AND COUNTRY_GROUP = TO_NUMBER('0')
         AND COVER_CAT_GROUP = '0'
         AND INSTITUTE_TYPE = '0'
         AND INST_COV_TYPE = '0'
         AND INST_VALIDITY_TYPE = '0'
         AND IS_POOL_COVER = TO_NUMBER('0')
         AND IS_SPECIAL_COVER = TO_NUMBER('0')
         AND NETWORK_ID = TO_NUMBER('')
         AND PACKAGE_ID = TO_NUMBER('')
         AND PARTITION_NO = TO_NUMBER('0')
         AND PARTITION_TYPE = '0'
         AND PART_ID = TO_NUMBER('0')
         AND PRODUCT_ID = TO_NUMBER('0')
         AND ((CITY_CODE = '007') OR (SPEC_GROUP_CODE = TO_NUMBER('1')) OR
            (INSTITUDE_GROUP_CODE = TO_NUMBER('5')) OR
            (INSTITUTE_CODE = TO_NUMBER('6596')))
            ORDER BY nvl(column_priority, 0) DESC)
   WHERE rownum < 2;
END;


SELECT * FROM Koc_Clm_Hlth_Proc_Pack_Rel;

koc_clm_hlth_trnx.getTDAProcessGroup



SELECT 1 '1'--,
       --2 '2', 
       --3 '3' 
  from dual;
  
  SELECT 1,2,3 FROM DUAL;
--  (SELECT 1 '1', 2 '2', 3 '3' from dual)
select * from koc_clm_hlth_detail where ext_reference='36998976'
select * from KOC_CLM_HLTH_STTMNT_CRITER where statement_no=3166466 and claim_id=39709164
select * from koc_clm_hlth_sttmnt_select where statement_no=3166466 and claim_id=39709164
select * from koc_clm_hlth_prov_statemnt where statement_no=3166466 and claim_id=39709164
select * from Alz_Invoice_Claim_Files where ext_reference='36998976'
