update clm_suppliers s
set s.exp_date = TO_DATE('01/01/2018','DD/MM/YYYY')
where exists (select 1 
                from koc_clm_suppliers_ext e
               where s.supp_id = e.supp_id
                 and e.institute_code IN (195,
                                          386,
                                          636,
                                          824,
                                          891,
                                          975,
                                          977,
                                          1039,
                                          1143,
                                          1166,
                                          1179,
                                          1244,
                                          1280,
                                          1331,
                                          1346,
                                          1355,
                                          1372,
                                          1511,
                                          1525,
                                          1713,
                                          2138,
                                          2282,
                                          2508,
                                          2769,
                                          3161)
                  )
/
COMMIT
/                  
