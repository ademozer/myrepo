  SELECT 1 FROM (SELECT  DISTINCT comp_name,
            SUBSTR (oracle_username, INSTR (oracle_username, '_', 1, 1) + 1) partaj,
            c.oracle_username user_name,
            d.grandparent_label ust_menu_adi,
            d.parent_label menu_adi,
            b.long_name program_adi
    FROM    sec_functions a,
            sec_dnm_menu_item_functions b,
            sec_system_users c,
            sec_dnm_full_menu d
    WHERE   a.function_id = b.function_id
        AND b.ora_nls_code = 'TR'
        AND b.context_group_name = c.main_menu_context_grp
        AND c.end_date IS NULL
        AND d.context_group = b.context_group_name
        AND d.menu_item = b.menu_item       
    UNION ALL
    SELECT  DISTINCT component_name comp_name,
            SUBSTR (oracle_username, INSTR (oracle_username, '_', 1, 1) + 1) partaj,        
            c.oracle_username user_name,
            a.grandparent_label,
            a.parent_label,
            item_label
    FROM    sec_dnm_full_menu a, 
            sec_dnm_menu_item_functions b, 
            sec_system_users c
    WHERE a.context_group = b.new_ctxt_grp_name
        AND a.ora_nls_code = 'TR'
        AND b.context_group_name = c.main_menu_context_grp)
   WHERE comp_name = 'KOCCLM307'
     AND user_name = 'HERDEMIR'        
      --  AND component_name = 'KOCDMT115'
