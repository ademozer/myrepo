-- kendisine ait rules tablosunda tan�m bulunmayan plan teminatlar� 
select (select a.product_id
          from koc_oc_prod_package_rel a
         where a.package_id = X.package_id
         and rownum<2) product_id ,x.*
  from koc_oc_hlth_pack_cov_rel x
 where x.validity_start_date >= '01.01.2016'
    and not exists (select 1
          from koc_clm_indem_total_rules a
         where a.package_id_2 = X.package_id
           and a.package_date_2 = X.package_date
           and a.claim_inst_type_2 = X.claim_inst_type
           and a.claim_inst_loc_2 = X.claim_inst_loc
           and a.child_cover_code_2 = X.child_cover_code
           and a.country_group_2 = X.country_group);
----

--- 3 �n alt�nda kural� olanlar incelenmeli
select p.ext_reference,
       p.package_name,
       (select x.product_id
          from koc_oc_prod_package_rel x
         where x.package_id = a.package_id
           and rownum < 2) product_id,
       (select count(*)
          from koc_clm_indem_total_rules rul
         where a.package_id = rul.package_id
           and a.package_date = rul.package_date
           and a.child_cover_code = rul.child_cover_code
           and a.country_group = rul.country_group
           and a.claim_inst_type = rul.claim_inst_type
           and a.claim_inst_loc = rul.claim_inst_loc
           and a.is_pool_cover = rul.is_pool_cover
           and a.is_special_cover = rul.is_special_cover) kuraladet,
       a.*
  from Koc_Oc_Hlth_Pack_Cov_Rel a, KOC_OC_PACKAGES p
 where a.package_id = p.package_id(+)
   and a.package_date >= '01.01.2017'
   and a.Is_Unlimited = 0
   and (select count(*)
          from koc_clm_indem_total_rules rul
         where a.package_id = rul.package_id
           and a.package_date = rul.package_date
           and a.child_cover_code = rul.child_cover_code
           and a.country_group = rul.country_group
           and a.claim_inst_type = rul.claim_inst_type
           and a.claim_inst_loc = rul.claim_inst_loc
           and a.is_pool_cover = rul.is_pool_cover
           and a.is_special_cover = rul.is_special_cover) < 3
 order by package_date desc;

-- rulesda olup pack_cov_rel tablosunda tan�m� olmayan teminatlar silinmeli 
select aa.validity_end_date,
       validity_start_date,
       aa.package_id,
       aa.package_id_2,
       aa.package_date,
       aa.package_date_2,
       aa.claim_inst_type,
       aa.claim_inst_type_2,
       aa.claim_inst_loc,
       aa.claim_inst_loc_2,
       aa.child_cover_code,
       aa.child_cover_code_2,
       aa.country_group,
       aa.country_group_2
  from koc_clm_indem_total_rules aa
 where not exists (select 1
          from koc_oc_hlth_pack_cov_rel x
         where x.package_id = aa.package_id
           and x.package_date = aa.package_date)
 order by aa.validity_start_date desc;
