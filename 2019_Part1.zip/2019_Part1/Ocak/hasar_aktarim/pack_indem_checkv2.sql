---hasar aktar�m uygulamas�
select * from Koc_Oc_Hlth_Plan_Match a
select * from Alz_Hlth_Claim_Transfer a
select * from Koc_Clm_Hlth_Transfer_His
select * from alz_hlth_bordro_trans_log
select * from koc_tmp_indem_contract_log

Curdifcover  p_claim_id ile e�itlemi�
curdiff cover a konu olan teminalaraait hasar� se�erken 
hasarlar� se�erken statu kontrol� yapmam��.

hasarlar� aktamadan �nce  hasar�n �zerindeki planda hasar tarihi kontrol� ile ilgili teminat var m� kontrol edilmeli.
yoksa ne yap�lacak? aktar�m� durdur. eksik teminat tan�m� var demektir




select /*+ index(a KOC_CLM_HLTH_DETAIL_IDX12) index(b KOC_CLM_HLTH_PROVISIONS_PK)  */ 
a.date_of_loss, b.prov_date_time,a.claim_id,a.sf_no,a.add_order_no,c.contract_id,c.oar_no,a.status_code,
a.package_id,a.package_date,b.cover_code,b.request_amount,b.provision_total,b.status_code prov_status_code
  from Koc_clm_hlth_detail  a, koc_clm_hlth_provisions b, clm_pol_oar c
where a.claim_id= b.claim_id
and a.sf_no = b.sf_no
and a.add_order_no = b.add_order_no
and a.date_of_loss >= to_date('01.12.2018' ,'dd.mm.yyyy')
and a.claim_id= c.claim_id
and not exists ( select 1 from koc_clm_hlth_indem_totals x
                where x.contract_id = c.contract_id
                and x.partition_no = c.oar_no
                and x.package_id = a.package_id
                and x.package_date = a.package_date
                and x.cover_code = b.cover_code
                and x.claim_inst_type = a.claim_inst_type
                and x.claim_inst_loc =a.claim_inst_loc
                and x.is_pool_cover = b.is_pool_cover
                and x.is_special_cover=b.is_special_cover
                and x.country_group = nvl(a.country_code,0)
                and x.validity_start_date <=a.date_of_loss 
                and nvl(x.validity_end_date,a.date_of_loss ) >= a.date_of_loss 
                and x.is_valid = 1)
