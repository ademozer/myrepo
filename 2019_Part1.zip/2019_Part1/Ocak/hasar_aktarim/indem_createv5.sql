--create_indem_records  -- indem Totals kayd� olu�mam�� poli�elerin indem totatals datas�n� olu�turuyor. Control M Job�
--( MDLR d���nda version_no = 1 ise koc_indemnity de�ilse yani zeyil ise POL_RENEW_TEK, 
-- MDSG ise ALZ_MDLR_HLTH_POLICY_UTILS7.P_MDLR_INDEM_TOTALS veya ALZ_MDLR_HLTH_POLICY_UTILS7.P_MDLR_INDEM_TOTALS_ENDORS  )

-- pol_renew     -- zeyil hareketlerini dikkate alarak indem totals olu�turuyor, transfer poli�eler i�in limitlerini g�ncelliyor.
--- (alz_ghlth_stp_utils , alz_ghlth_stp_policy_utils den �a�r�l�yor)

-- pol_renew_tek(�PTAl olmal�)      (create_indem_records'dan �a�r�l�yor)  

--koc_indemnity   --- zeyilleri dikkate alm�yor
--  (koc_health_movement_routes, koc_health_renewal_utils, alz_hlth_policy_utils,
-- alz_mdlr_hlth_policy_utils,alz_mdlr_hlth_policy_utils1, koc_ocp_hlth_utils2, create_indem_records)mdsg hari� kullaniliyor

--koc_indemnity_renew  --- zeyil hareketini dikkate al�yor, �nceki plan� kapat gibi i�ler yap�yor
--- (pol_renew, pol_renew_tek, koc_hlth_clm_transfer, koc_indemnity_utils, alz_mdlr_hlth_policy_utils7)

-- koc_indemnity_utils.setindemtotals   (koc_clm_hlth_trnx3, koc_helpdesk paketlerinde �a�r�l�yor)
--koc_clm_hlth_trnx3.get_indemnity_errors
--koc_helpdesk.koc_hlth_indem_update

--alz_mdlr_hlth_policy_utils7.p_mdlr_indem_totals
--alz_mdlr_hlth_policy_utils.insert_indemnity   mdsg i�in

--todo : set remaining  �nce havuz teminat� olmayan hasarlar� d�zeltmeli
-- sonra t�m poli�e i�in havuz teminat� olan hasarlar� se�ip bir kez daha remaningleri set etmeli
-- setremainingPool diye ayr� bir proc yaz�lmal� ve poli�e bazl� �al��mal�  
--Pr_Clm_Hlth_Set_Remaining prosed�r�nde yeni yarat�lan�n�n hasar� olmasa bile 
--bir �nceki poli�ede hasar varsa bir �nceki poli�enin hasarlar� yeninin limitinden d��meli
---Koc_Hlth_Clm_Transfer.New_Indem_Total_Update yaln�zca limiti d���yor, s_spen_toal rakamlar�n� da g�ncellemeli, bul bilgi belki s_spend_total_transfer alan�nda tutulmal�
--koc_indemnity_utils.update_indem_old_new proc iptal edilmeli

/*Transfer edilen sigortal�larla ilgili not:

Koc_ocp_partitions_ext.transfer_contract_id, transfer_partition_no bilgisi   hangi poli�eden transfer geldi�ini yani eski poli�e bilgisini tutuyor.

Koc_clm_hlth_indem_totals.trans_contract_id ve trans_partition_no  ise hangi poli�eye transfer oldu�unu  yani yeni poli�e bilgisini tutuyor.
s
Yeni poli�enin indem totals tablosu  yarat�l�yorken Koc_ocp_partitions_ext.is_limit_transfer flag� �1� ise eski poli�edeki harcamalar yeni poli�enin limitinden d���yor.  Ve indem_totls tablosunda trans_contract_id bilgisini update ediyor.  (Pol_renew --- MDSG/NZ/MD hari� sa�l�k �r�nleri)  ve  trans_contract_id bilgisini kullanarak eski poli�eye hasar geldi�inde eski poli�e ile birlikte yeni poli�enin limitlerinden de d��mesini sa�lan�yor.
*/

declare
  p_contract_id  number;
  p_partition_no number;
  p_version_no   number := null;
  p_call_type    number := 0;

  cursor cpolicy(p_contract_id  number,
                 p_partition_no number,
                 p_version_no   number) is
    select distinct contract_id, partition_no, added_version_no
      from (select contract_id,
                   partition_no,
                   min(version_no) over(partition by contract_id, partition_no) as added_version_no,
                   version_no
              from ocp_partitions
             where contract_id = p_contract_id
               and (p_partition_no is null or partition_no = p_partition_no)
            -- and  partition_no between 43000 and 44000
            )
     where (p_version_no is null or version_no = p_version_no);

  cursor ClaimExists(p_contract_id number, p_partition_no number) is
    select 1
      from clm_pol_oar
     where contract_id = p_contract_id
       and oar_no = p_partition_no;

  cursor cprov(p_contract_id      number,
               p_partition_no     number,
               p_loss_start_date  date,
               p_loss_end_date    date,
               p_sub_package_id   number,
               p_sub_package_date date) is
    select b.claim_id,
           b.sf_no,
           b.add_order_no,
           b.date_of_loss,
           b.package_id,
           b.package_date,
           c.sub_package_id,
           c.sub_package_date,
           c.cover_code
      from clm_pol_oar a, koc_clm_hlth_detail b, koc_clm_hlth_provisions c
     where a.contract_id = p_contract_id
       and a.oar_no = p_partition_no
       and a.claim_id = b.claim_id
       and b.claim_id = c.claim_id
       and b.date_of_loss between p_loss_start_date and p_loss_end_date
       and (nvl(c.sub_package_id, 0) <> nvl(p_sub_package_id, 0) or
           nvl(c.sub_package_date, to_date('01.01.1999', 'dd.mm.yyyy')) <>
           nvl(p_sub_package_date, to_date('01.01.1999', 'dd.mm.yyyy')));

  rprov cprov%rowtype;

  type planparttype is record(
    contract_id  number,
    partition_no number,
    package_id   number,
    package_date date,
    
    product_id     number,
    partition_type varchar2(10),
    
    term_start_date date,
    term_end_date   date,
    
    transfer_contract_id  number,
    transfer_partition_no number,
    is_limit_tansfer      number,
    number_of_period      number,
    
    partition_version_no  number,
    partition_action_code varchar2(1),
    pack_version_no       number,
    pack_action_code      varchar2(1),
    policy_start_date     date,
    partner_id            number,
    type_of_interest      varchar2(5),
    prev_package_id       number,
    prev_package_date     date);

  type planparttable is table of planparttype;

  -- order bozulmamal�, distinct kald�r�lmamal�
  cursor cpartplan(p_contract_id  number,
                   p_partition_no number,
                   p_version_no   number) is
    select distinct planq.contract_id,
                    planq.partition_no,
                    planq.product_id,
                    planq.partition_type,
                    planq.package_id,
                    planq.package_date,
                    planq.term_start_date,
                    planq.term_end_date,
                    planq.transfer_contract_id,
                    planq.transfer_partition_no,
                    planq.is_limit_tansfer,
                    planq.number_of_period,
                    planq.partition_version_no,
                    planq.partition_action_code,
                    planq.pack_version_no,
                    planq.pack_action_code,
                    planq.partner_id,
                    planq.type_of_interest,
                    planq.policy_start_date
      from (select /*+ index(VIEWQ.interested KOC_OCP_INTERES_PARTIES_IDX2) */
             viewq.contract_id,
             viewq.partition_no,
             viewq.product_id,
             viewq.partition_type,
             viewq.package_id,
             viewq.package_date,
             viewq.term_start_date,
             viewq.term_end_date,
             viewq.transfer_contract_id,
             viewq.transfer_partition_no,
             viewq.is_limit_tansfer,
             viewq.number_of_period,
             viewq.version_no,
             viewq.partition_version_no,
             viewq.partition_action_code,
             viewq.pack_version_no,
             viewq.pack_action_code,
             viewq.partner_id,
             viewq.type_of_interest,
             viewq.policy_start_date
              from (select ip_links.contract_id,
                           ip_links.partition_no,
                           ip_links.version_no partner_version_no,
                           ip_links.action_code partner_action_code,
                           ip_links.ip_no,
                           interested.partner_id,
                           ip_links.type_of_interest,
                           interested.mailing_address_id,
                           par_ext.version_no partition_version_no,
                           par_ext.action_code partition_action_code,
                           ver_ext.endorsement_no,
                           par_ext.term_start_date,
                           decode(nvl(ver_ext.endorsement_no, 0),
                                  14,
                                  decode(ver.product_id,
                                         63,
                                         ver.business_start_date,
                                         par_ext.business_start_date),
                                  2,
                                  decode(ver.product_id,
                                         63,
                                         ver.business_start_date,
                                         par_ext.business_start_date),
                                  par_ext.term_end_date) term_end_date,
                           par_ext.sub_company_code,
                           par_ext.partner_validity_date,
                           par_ext.transfer_contract_id,
                           par_ext.transfer_partition_no,
                           par_ext.is_limit_tansfer,
                           par.partition_type,
                           ver.product_id,
                           ver.contract_status,
                           ver_ext.version_no,
                           ver_ext.group_code,
                           ver_ext.period_no group_period_no,
                           ver_ext.sub_agent,
                           ver_ext.oldsys_policy_no,
                           cont_ext.is_complementary,
                           cont_ext.number_of_period,
                           cont_ext.company_code,
                           cont_ext.old_contract_id,
                           pack.version_no pack_version_no,
                           pack.action_code pack_action_code,
                           pack.package_id,
                           pack.package_date,
                           pack.network_id,
                           pack.package_label,
                           bases.policy_ref,
                           bases.term_start_date policy_start_date,
                           bases.term_end_date policy_end_date,
                           bases.agent_role
                      from ocp_ip_links              ip_links,
                           ocp_interested_parties    interested,
                           koc_ocp_partitions_ext    par_ext,
                           ocp_partitions            par,
                           koc_ocp_risk_packages     pack,
                           koc_ocp_pol_versions_ext  ver_ext,
                           ocp_policy_versions       ver,
                           koc_ocp_pol_contracts_ext cont_ext,
                           ocp_policy_bases          bases
                     where ip_links.contract_id = interested.contract_id
                       and ip_links.ip_no = interested.ip_no
                       and ip_links.version_no = interested.version_no
                       and interested.version_no =
                           (select max(iinterested.version_no)
                              from ocp_interested_parties iinterested
                             where iinterested.contract_id =
                                   interested.contract_id
                               and iinterested.ip_no = interested.ip_no
                               and iinterested.version_no <=
                                   ver_ext.version_no
                               and iinterested.reversing_version is null)
                       and ip_links.partition_no is not null
                       and par_ext.contract_id = ip_links.contract_id
                       and par_ext.partition_no = ip_links.partition_no
                       and cont_ext.contract_id = ver_ext.contract_id
                       and ver_ext.contract_id = ip_links.contract_id
                       and ver.contract_id = ver_ext.contract_id
                       and ver.version_no = ver_ext.version_no
                       and par_ext.version_no =
                           (select max(a.version_no)
                              from koc_ocp_partitions_ext a
                             where a.contract_id = par_ext.contract_id
                               and a.partition_no = par_ext.partition_no
                               and a.version_no <= ver_ext.version_no
                               and a.reversing_version is null)
                       and par_ext.contract_id = par.contract_id
                       and par_ext.partition_no = par.partition_no
                       and par_ext.version_no = par.version_no
                       and pack.contract_id = par.contract_id
                       and pack.partition_no = par.partition_no
                       and pack.version_no =
                           (select max(a.version_no)
                              from koc_ocp_risk_packages a
                             where a.contract_id = pack.contract_id
                               and a.partition_no = pack.partition_no
                               and a.version_no <= par_ext.version_no
                               and a.reversing_version is null)
                       and not (pack.action_code = 'D' and exists
                             (select 1
                                   from koc_ocp_risk_packages a
                                  where a.contract_id = pack.contract_id
                                    and a.partition_no = pack.partition_no
                                    and a.version_no = pack.version_no
                                    and a.reversing_version is null
                                    and a.action_code = 'A'))
                       and bases.contract_id = ver_ext.contract_id
                       and bases.top_indicator = 'Y') viewq
             where viewq.contract_id = p_contract_id -- 357393375--373811548
               and viewq.partition_no = p_partition_no
               and viewq.version_no <=
                  -- ilgili partition_no yu ilgilendiren versiyonlar al�nd�
                   (select max(xq.version_no)
                      from (select max(x.version_no) version_no
                              from ocp_partitions x
                             where x.contract_id = p_contract_id
                               and x.partition_no = p_partition_no
                               and x.reversing_version is null
                            union
                            select max(x.version_no) version_no
                              from koc_ocp_risk_packages x
                             where x.contract_id = p_contract_id
                               and x.partition_no = p_partition_no
                               and x.reversing_version is null
                            union
                            select max(x.version_no) version_no
                              from ocp_ip_links x
                             where x.contract_id = p_contract_id
                               and x.partition_no = p_partition_no
                               and x.reversing_version is null
                            union
                            select max(x.version_no) version_no
                              from koc_ocp_pol_versions_ext x
                             where x.contract_id = p_contract_id
                               and nvl(x.endorsement_no, 0) in (2, 14)
                               and x.reversing_version is null
                            
                            ) xq)
            
            ) planq -- 419--13127
     where (p_version_no is null or
           planq.partition_version_no = p_version_no)
    --            and planq.partition_version_no<=27
     order by planq.partition_version_no asc;

  cursor cplan(p_contract_id  number,
               p_partition_no number,
               p_version_no   number) is
    select a.package_id, a.package_date
      from koc_ocp_risk_packages a
     where a.contract_id = p_contract_id -- 357393375--373811548
       and a.partition_no = p_partition_no
       and a.action_code = 'A'
       and a.version_no =
           (select max(x.version_no)
              from koc_ocp_risk_packages x
             where x.contract_id = a.contract_id -- 357393375--373811548
               and x.partition_no = a.partition_no
               and x.action_code = 'A'
               and x.reversing_version is null
               and x.version_no < p_version_no);

  cursor cindemplandate(p_contract_id number, p_partition_no number) is
    select distinct a.contract_id,
                    a.partition_no,
                    a.package_id,
                    a.package_date,
                    a.sub_package_id,
                    a.sub_package_date,
                    a.validity_start_date,
                    nvl(a.validity_end_date,
                        to_date('01.01.1999', 'dd.mm.yyyy')) validity_end_date
      from koc_clm_hlth_indem_totals a
     where a.contract_id = p_contract_id -- 357393375--373811548
       and a.partition_no = p_partition_no
       and (a.validity_end_date is null or
           a.validity_end_date > a.validity_start_date)
       and a.is_valid = 1
     order by a.validity_start_date;

  rpartplan      cpartplan%rowtype;
  vplanparttable planparttable;

  rindemplandate     cindemplandate%rowtype;
  rpolicy            cpolicy%rowtype;
  v_contract_id      number;
  v_partition_no     number;
  v_version_no       number;
  v_added_version_no number;

  i number;

  v_prev_package_id   number := null;
  v_prev_package_date date := null;

  v_Claim_Exists      number;
  v_prev_claim_exists number;

  p_indemrec koc_clm_hlth_indem_totals_log%rowtype;
  v_err_sq   number;
  v_err_msg  varchar2(2000);
  sonuc      VARCHAR2(1000);

  procedure updateAndInsertIndemTotals(p_planparttable planparttable) is
  
    cursor cpolicypartner(p_partner_id number) is
      select partner.date_of_birth, partner.sex, partner.marital_status
        from cp_partners partner
       where partner.part_id = p_partner_id;
  
    cursor cpackcovrel(p_package_id in number, p_package_date date) is
      select *
        from koc_oc_hlth_pack_cov_rel
       where package_id = p_package_id
         and package_date = p_package_date
       order by validity_start_date desc;
    rpackcovrel cpackcovrel%rowtype;
  
    vplanparttable      planparttable;
    vplanpartrec        planparttype;
    v_prev_contract_id  number := 0;
    v_prev_partition_no number := 0;
    v_part_class        varchar2(10) := '';
  
    rpolicypartner            cpolicypartner%rowtype;
    vinsuredage               number;
    vinsuredsex               varchar2(2);
    vinsuredmaritalstatus     varchar2(10);
    vinsuredtypeofinterest    varchar2(10);
    v_prev_plan_term_end_date date;
    valreadyinsertedplan      number;
    vplansayac                number;
  
  begin
    vplanparttable         := p_planparttable;
    vinsuredage            := 0;
    vinsuredtypeofinterest := '';
  
    vplansayac := 1;
    loop
      exit when vplansayac > vplanparttable.count;
    
      vplanpartrec := vplanparttable(vplansayac);
    
      if vplanpartrec.contract_id <> v_prev_contract_id then
      
        v_part_class := koc_health_policy_utils5.get_prod_part_mdlr(vplanpartrec.product_id,
                                                                    vplanpartrec.partition_Type,
                                                                    SYSDATE);
      end if;
    
      IF v_part_class = 'MDLR' THEN
        if vplanpartrec.partition_version_no = 1 then
          ALZ_MDLR_HLTH_POLICY_UTILS7.P_MDLR_INDEM_TOTALS(p_contract_id  => vplanpartrec.contract_id,
                                                          p_partition_no => vplanpartrec.partition_no,
                                                          p_quote_id     => NULL,
                                                          result         => sonuc);
        else
          ALZ_MDLR_HLTH_POLICY_UTILS7.P_MDLR_INDEM_TOTALS_ENDORS(p_contract_id  => vplanpartrec.contract_id,
                                                                 P_VERSION_NO   => vplanpartrec.partition_version_no,
                                                                 p_partition_no => vplanpartrec.partition_no,
                                                                 p_quote_id     => NULL,
                                                                 result         => sonuc);
        end if;
      
      else
      
        --partner�n do�um tarihi, cinsiyet, medeni hali bulunur
        if vplanpartrec.contract_id || vplanpartrec.partition_no <>
           v_prev_contract_id || v_prev_partition_no then
        
          open cpolicypartner(vplanpartrec.partner_id);
          fetch cpolicypartner
            into rpolicypartner;
          close cpolicypartner;
        
          vinsuredage := to_number(to_char(vplanpartrec.policy_start_date,
                                           'yyyy')) -
                         to_number(to_char(rpolicypartner.date_of_birth,
                                           'yyyy'));
        
          if vinsuredage < 0 then
            vinsuredage := 0;
          end if;
        
          if vplanpartrec.type_of_interest in ('KZ', '�', 'O') then
            vinsuredtypeofinterest := 'C';
          else
            vinsuredtypeofinterest := vplanpartrec.type_of_interest;
          end if;
        end if;
      
        --  ki�i ��k��� yada ��kart�lan ki�inin giri�i yada  plan de�i�iklik zeyili ise
        -- bir y�ldan uzun d�nemli poli�elerde , �u an yaln�zca YVIT, d�nem de�i�imini ki�i g/� yada plan de�i�ikli�i gibi anlg�lanmamal� , 
        -- ilk d�nemde ki�i G/� yada plan de�i�ikli�i kontrol edilmeli
      
        if nvl(vplanpartrec.prev_package_id, 0) <> 0 and
           nvl(vplanpartrec.number_of_period, 0) = 1 then
        
          if (vplanpartrec.package_id = vplanpartrec.prev_package_id and
             vplanpartrec.package_date = vplanpartrec.prev_package_date) then
          
            --  ki�i ��k��� veya ayn� plan ile tekrar ki�i giri�i ise  term_end_date plan�n biti� tarihi ile update edilir. 
            v_prev_plan_term_end_date := vplanpartrec.term_end_date;
          
          else
            --  ��kart�lan ki�inin farkl� plan ile  giri�i veya plan de�i�iklik zeyili �nceki planin term end_datei yeni plan�n ba�lang�� tarihi ile g�ncellenir
            v_prev_plan_term_end_date := vplanpartrec.term_start_date - 1;
          
          end if;
        
          update koc_clm_hlth_indem_totals a
             set a.validity_end_date = v_prev_plan_term_end_date,
                 a.is_valid          = decode(sign(v_prev_plan_term_end_date -
                                                   a.validity_start_date),
                                              -1,
                                              0,
                                              1)
           where a.contract_id = vplanpartrec.contract_id
             and a.partition_no = vplanpartrec.partition_no
             and a.package_id = vplanpartrec.prev_package_id
             and a.package_date = vplanpartrec.prev_package_date
             and a.is_valid = 1;
        end if;
      
        -- ��kart�lan ki�inin farkl� plan ile giri�i veya plan de�i�iklik zeyili
        -- bir y�ldan uzun d�nemli poli�elerde , �u an yaln�zca YVIT, d�nem de�i�imini ki�i g/� yada plan de�i�ikli�i gibi anlg�lanmamal� , 
        -- ilk d�nemde ki�i G/� yada plan de�i�ikli�i kontrol edilmeli
      
        if (vplanpartrec.package_id <> vplanpartrec.prev_package_id or
           vplanpartrec.package_date <> vplanpartrec.prev_package_date) and
           nvl(vplanpartrec.number_of_period, 0) = 1
        
         then
        
          --bu pack id ve date ait daha �nce indem totals da kay�t varsa  term_end_date i yeni giri� ile updat edilir          
        
          select count(1)
            into valreadyinsertedplan
            from koc_clm_hlth_indem_totals a
           where a.contract_id = vplanpartrec.contract_id
             and a.partition_no = vplanpartrec.partition_no
             and a.package_id = vplanpartrec.package_id
             and a.package_date = vplanpartrec.package_date
             and a.is_valid = 1;
        
          if nvl(valreadyinsertedplan, 0) = 1 then
            update koc_clm_hlth_indem_totals a
               set a.validity_end_date = vplanpartrec.term_end_date,
                   a.is_valid          = decode(sign(vplanpartrec.term_end_date -
                                                     a.validity_start_date),
                                                -1,
                                                0,
                                                1)
             where a.contract_id = vplanpartrec.contract_id
               and a.partition_no = vplanpartrec.partition_no
               and a.package_id = vplanpartrec.package_id
               and a.package_date = vplanpartrec.package_date
               and a.is_valid = 1;
          end if;
        end if;
      
        --ki�inin poli�eye ilk giri�i veya daha �nce indem totalsda olmayan bir plan ile  plan de�i�iklik zeyili
        if nvl(vplanpartrec.prev_package_id, 0) = 0 or
           ((vplanpartrec.package_id <> vplanpartrec.prev_package_id or
            vplanpartrec.package_date <> vplanpartrec.prev_package_date) and
            nvl(valreadyinsertedplan, 0) = 0) then
        
          open cpackcovrel(vplanpartrec.package_id,
                           vplanpartrec.package_date);
          loop
            fetch cpackcovrel
              into rpackcovrel;
          
            exit when cpackcovrel%notfound;
          
            /* dbms_output.put_line('vInsuredAge:' || vinsuredage ||
                                 '  start end age ' ||
                                 rpackcovrel.start_age || ' - ' ||
                                 rpackcovrel.end_age);
            dbms_output.put_line('vInsuredSex:' || vinsuredsex ||
                                 '  gender:' || rpackcovrel.gender ||
                                 ' vInsuredMaritalStatus:' ||
                                 vinsuredmaritalstatus || '  packMarital:' ||
                                 rpackcovrel.marital_status ||
                                 '  vInsuredTypeOfInterest:' ||
                                 vinsuredtypeofinterest ||
                                 'packwill_be_given' ||
                                 rpackcovrel.to_whom_guarante_will_be_given);*/
          
            if vinsuredage >= nvl(rpackcovrel.start_age, vinsuredage) and
               (rpackcovrel.end_age = 0 or
               vinsuredage <= nvl(rpackcovrel.end_age, vinsuredage)) and
               nvl(vinsuredsex, 'x') =
               nvl(rpackcovrel.gender, nvl(vinsuredsex, 'x')) and
               nvl(vinsuredmaritalstatus, 'x') =
               nvl(rpackcovrel.marital_status,
                   nvl(vinsuredmaritalstatus, 'x')) and
               instr(nvl(rpackcovrel.to_whom_guarante_will_be_given, 'x'),
                     rtrim(nvl(vinsuredtypeofinterest, 'x')),
                     1) > 0 then
            
              begin
                insert into koc_clm_hlth_indem_totals
                  (contract_id,
                   partition_no,
                   country_group,
                   claim_inst_type,
                   claim_inst_loc,
                   is_pool_cover,
                   is_special_cover,
                   validity_start_date,
                   cover_code,
                   validity_end_date,
                   is_unlimited,
                   f_cover_price,
                   f_day_seance,
                   f_exemption_sum,
                   s_indemnity_amount,
                   s_provision_amount,
                   s_spend_total,
                   s_spend_day_seance,
                   s_exemption_sum,
                   r_cover_price,
                   r_day_seance,
                   r_exemption_sum,
                   exemption_rate,
                   cover_cat_group,
                   indemnity_payment_type,
                   parent_cover_code,
                   main_or_sub_cov,
                   package_id,
                   package_date,
                   max_increase,
                   swift_code,
                   paid_premium_percentage,
                   priority_level_for_claim,
                   is_valid,
                   is_pharmacy_cover,
                   is_included_renewing_rate,
                   exemption_group,
                   user_group,
                   is_valid_by_rule,
                   sub_package_id,
                   sub_package_date)
                values
                  (vplanpartrec.contract_id,
                   vplanpartrec.partition_no,
                   rpackcovrel.country_group,
                   rpackcovrel.claim_inst_type,
                   rpackcovrel.claim_inst_loc,
                   rpackcovrel.is_pool_cover,
                   rpackcovrel.is_special_cover,
                   vplanpartrec.term_start_date,
                   rpackcovrel.child_cover_code,
                   vplanpartrec.term_end_date,
                   rpackcovrel.is_unlimited,
                   rpackcovrel.cover_price,
                   rpackcovrel.max_day_seance,
                   rpackcovrel.exemption_sum,
                   0,
                   0,
                   0,
                   0,
                   0,
                   rpackcovrel.cover_price,
                   rpackcovrel.max_day_seance,
                   rpackcovrel.exemption_sum,
                   rpackcovrel.exemption_rate,
                   rpackcovrel.cover_cat_group,
                   rpackcovrel.indemnity_payment_type,
                   rpackcovrel.parent_cover_code,
                   rpackcovrel.main_or_sub_cov,
                   rpackcovrel.package_id,
                   rpackcovrel.package_date,
                   rpackcovrel.max_increase,
                   rpackcovrel.swift_code,
                   rpackcovrel.paid_premium_percentage,
                   rpackcovrel.priority_level_for_claim,
                   1,
                   rpackcovrel.is_pharmacy_cover,
                   rpackcovrel.is_included_renewing_rate,
                   rpackcovrel.exemption_group,
                   rpackcovrel.user_group,
                   rpackcovrel.is_valid_by_rule,
                   rpackcovrel.package_id,
                   rpackcovrel.package_date);
              
              exception
                when others then
                  -- todo 
                  -- PK neeniyle insert yapamad��� durumlar oluyor tekrar incelenmeli
                  dbms_output.put_line(vplansayac || '   ' || sqlerrm ||
                                       '    ' ||
                                       vplanpartrec.partition_version_no ||
                                       '   ' ||
                                       vplanpartrec.term_start_date ||
                                       '   ' || vplanpartrec.term_end_date || '  ' ||
                                       rpackcovrel.child_cover_code);
              end;
            end if;
          
          end loop;
          close cpackcovrel;
        end if;
      
        if vplanpartrec.transfer_contract_id is not null and
           vplanpartrec.transfer_partition_no is not null and
           NVL(vplanpartrec.is_limit_tansfer, 0) = 1 then
          --- partitions_ext de kimden transfer geldi�i bilgisi tutuluyor
          --limitler tasinacak demek
        
          /*
           kapatt�m ��nk� Pr_Clm_Hlth_Set_Remaining �nceki poli�enin limitlerinin yenisinden d���yor, bu proc silinmeli
          koc_indemnity_utils.update_indem_old_new(vplanpartrec.transfer_contract_id,
                                                   vplanpartrec.transfer_partition_no,
                                                   vplanpartrec.contract_id,
                                                   vplanpartrec.partition_no);*/
        
          UPDATE koc_clm_hlth_indem_totals -- eski poli�ede kime transfer oldu�u bilgisi tutuluyor
             SET trans_contract_id  = vplanpartrec.contract_id,
                 trans_partition_no = vplanpartrec.partition_no
           WHERE contract_id = vplanpartrec.transfer_contract_id
             AND partition_no = vplanpartrec.transfer_partition_no;
        
        end if;
      
        update koc_clm_hlth_indem_totals a
           set a.is_valid = 0
         where a.contract_id = v_contract_id
           and a.partition_no = v_partition_no
           and a.cover_code in ('S684', 'S675', 'S589')
           and not exists
         (select 1
                  from koc_oc_hlth_pack_cov_rel
                 where package_id = a.package_id
                   and package_date = a.package_date
                   and child_cover_code = a.cover_code
                   and vinsuredage between
                       decode(start_age, 0, 40, null, 40, start_age) and
                       decode(end_age, 0, 999, null, 999, end_age));
      
        if vinsuredsex = 'M' then
          update koc_clm_hlth_indem_totals a
             set a.is_valid = 0
           where a.contract_id = v_contract_id
             and a.partition_no = v_partition_no
             and a.cover_code = 'S589';
        elsif vinsuredsex = 'F' then
          update koc_clm_hlth_indem_totals a
             set a.is_valid = 0
           where a.contract_id = v_contract_id
             and a.partition_no = v_partition_no
             and a.cover_code in ('S684', 'S675');
        end if;
      
      end if; --  IF v_part_class = 'MDLR' THEN sonu
    
      v_prev_contract_id  := vplanpartrec.contract_id;
      v_prev_partition_no := vplanpartrec.partition_no;
      vplansayac          := vplansayac + 1;
    
    end loop;
  
    koc_indemnity_utils.indemnity_pool(v_contract_id,
                                       v_partition_no,
                                       p_call_type);
  
    koc_indemnity_utils.indemnity_special(v_contract_id,
                                          v_partition_no,
                                          p_call_type);
  
  end;

begin

  p_contract_id  := 407459512; --356218402; --426541255;--413323942; --357027375; --306496150; 
  p_partition_no := 248; --955; --863; --8042;-- 28561; 
  v_version_no   := null; --p_version_no;

  v_err_sq := koc_hlth_clm_transfer.geterrseq;

  open cpolicy(p_contract_id, p_partition_no, v_version_no);
  loop
    fetch cpolicy
      into rpolicy;
    exit when cpolicy%notfound;
  
    v_contract_id      := rpolicy.contract_id; --373811548;--357393375;
    v_partition_no     := rpolicy.partition_no; --13127;--419;
    v_added_version_no := rpolicy.added_version_no;
  
    vplanparttable      := planparttable();
    v_prev_package_id   := 0;
    v_prev_package_date := to_date('01.01.1900', 'dd.mm.yyyy');
    v_Claim_Exists      := 0;
    v_prev_claim_exists := 0;
  
    p_Indemrec              := null;
    p_Indemrec.contract_id  := v_contract_id;
    p_Indemrec.partition_no := v_partition_no;
    p_Indemrec.package_id   := null;
    p_Indemrec.package_date := null;
    p_Indemrec.log_type     := 'INDEM-CREATE';
    p_Indemrec.Log_Detail   := 'Plan G�ncelleme Ba�lad�';
    p_Indemrec.log_state    := 'KOC_INDEMNITY_UTILS';
    p_Indemrec.log_status   := 0;
    p_Indemrec.online_sq_no := v_err_sq;
  
    koc_indemnity_utils.insert_indem_totals_log(p_Indemrec, null, null);
  
    -- Sigortal�n�n eklendi�i ilk versiyon ise �nceki plan yoktur o nedenle okumaya gerek yok  
    if v_version_no is not null and
       nvl(v_version_no, 0) <> v_added_version_no then
      open cplan(v_contract_id, v_partition_no, v_version_no);
      fetch cplan
        into v_prev_package_id, v_prev_package_date;
      close cplan;
    end if;
  
    -- version_no null ise t�m zeyil hareketleri okunur ve indem totals en ba�tan tekrar olu�turulur
    if v_version_no is null then
    
      delete from koc_clm_hlth_indem_totals
       where contract_id = v_contract_id
         and partition_no = v_partition_no;
    
    end if;
    ---
  
    open cpartplan(v_contract_id, v_partition_no, v_version_no);
    loop
      fetch cpartplan
        into rpartplan;
      exit when cpartplan%notfound;
    
      --number_of_period  YVIT 2YL i�in eklenmi�. di�er poli�elerde 1 olmal�
    
      if nvl(rpartplan.number_of_period, 0) = 0 then
        rpartplan.number_of_period := 1;
      end if;
    
      for i in 1 .. rpartplan.number_of_period loop
        vplanparttable.extend;
      
        vplanparttable(vplanparttable.last).contract_id := rpartplan.contract_id;
        vplanparttable(vplanparttable.last).partition_no := rpartplan.partition_no;
        vplanparttable(vplanparttable.last).package_id := rpartplan.package_id;
        vplanparttable(vplanparttable.last).package_date := rpartplan.package_date;
        vplanparttable(vplanparttable.last).term_start_date := add_months(rpartplan.term_start_date,
                                                                          (i - 1) * 12); --rpartplan.term_start_date;
        vplanparttable(vplanparttable.last).term_end_date := add_months(rpartplan.term_end_date,
                                                                        (i -
                                                                        rpartplan.number_of_period) * 12); --rpartplan.term_end_date;
      
        vplanparttable(vplanparttable.last).number_of_period := i;
      
        vplanparttable(vplanparttable.last).transfer_contract_id := rpartplan.transfer_contract_id;
        vplanparttable(vplanparttable.last).transfer_partition_no := rpartplan.transfer_partition_no;
        vplanparttable(vplanparttable.last).is_limit_tansfer := rpartplan.is_limit_tansfer;
        vplanparttable(vplanparttable.last).number_of_period := rpartplan.number_of_period;
      
        vplanparttable(vplanparttable.last).partition_version_no := rpartplan.partition_version_no;
        vplanparttable(vplanparttable.last).partition_action_code := rpartplan.partition_action_code;
        vplanparttable(vplanparttable.last).partition_type := rpartplan.partition_type;
        vplanparttable(vplanparttable.last).product_id := rpartplan.product_id;
      
        vplanparttable(vplanparttable.last).pack_version_no := rpartplan.pack_version_no;
        vplanparttable(vplanparttable.last).pack_action_code := rpartplan.pack_action_code;
        vplanparttable(vplanparttable.last).policy_start_date := rpartplan.policy_start_date;
        vplanparttable(vplanparttable.last).partner_id := rpartplan.partner_id;
        vplanparttable(vplanparttable.last).type_of_interest := rpartplan.type_of_interest;
      
        vplanparttable(vplanparttable.last).prev_package_id := v_prev_package_id;
        vplanparttable(vplanparttable.last).prev_package_date := v_prev_package_date;
      
        if nvl(rpartplan.is_limit_tansfer, 0) = 1 and
           rpartplan.transfer_contract_id is not null and
           rpartplan.transfer_partition_no is not null then
          v_prev_claim_exists := 1;
        end if;
      end loop;
      v_prev_package_id   := vplanparttable(vplanparttable.last).package_id;
      v_prev_package_date := vplanparttable(vplanparttable.last)
                             .package_date;
    
    end loop;
    close cpartplan;
  
    updateAndInsertIndemTotals(vplanparttable);
  
    --- claim update
    open ClaimExists(v_contract_id, v_partition_no);
    fetch claimExists
      into v_Claim_Exists;
    close claimExists;
  
    if nvl(v_Claim_Exists, 0) = 1 or nvl(v_prev_claim_exists, 0) = 1 then
      open cindemplandate(v_contract_id, v_partition_no);
      loop
        fetch cindemplandate
          into rindemplandate;
        exit when cindemplandate%notfound;
      
        open cprov(v_contract_id,
                   v_partition_no,
                   rindemplandate.validity_start_date,
                   rindemplandate.validity_end_date,
                   rindemplandate.sub_package_id,
                   rindemplandate.sub_package_date);
        loop
          fetch cprov
            into rprov;
          exit when cprov%notfound;
          update koc_clm_hlth_provisions a
             set sub_package_id   = rindemplandate.sub_package_id,
                 sub_package_date = rindemplandate.sub_package_date
           where claim_id = rprov.claim_id
             and sf_no = rprov.sf_no
             and add_order_no = rprov.add_order_no;
        end loop;
        close cprov;
      
        update koc_clm_hlth_detail a
           set package_id   = rindemplandate.package_id,
               package_date = rindemplandate.package_date
         where claim_id in (select claim_id
                              from clm_pol_oar
                             where contract_id = v_contract_id
                               and oar_no = v_partition_no)
           and a.date_of_loss between rindemplandate.validity_start_date and
               rindemplandate.validity_end_date
           and (a.package_id <> rindemplandate.package_id or
               a.package_date <> rindemplandate.package_date);
      
        update koc_clm_bordro_rep a
           set a.package_id = rindemplandate.package_id
         where a.claim_id in (select claim_id
                                from clm_pol_oar
                               where contract_id = v_contract_id
                                 and oar_no = v_partition_no)
           and a.date_of_loss between rindemplandate.validity_start_date and
               rindemplandate.validity_end_date
           and a.package_id <> rindemplandate.package_id;
      
        update koc_clm_muallak_bordro_rep a
           set a.package_id = rindemplandate.package_id
         where a.claim_id in (select claim_id
                                from clm_pol_oar
                               where contract_id = v_contract_id
                                 and oar_no = v_partition_no)
           and a.date_of_loss between rindemplandate.validity_start_date and
               rindemplandate.validity_end_date
           and a.package_id <> rindemplandate.package_id;
      
      end loop;
      close cindemplandate;
    
      --todo : set remaining  �nce havuz teminat� olmayan hasarlar� d�zeltmeli
      -- sonra t�m poli�e i�in havuz teminat� olan hasarlar� se�ip bir kez daha remaningleri set etmeli
      -- setremainingPool diye ayr� bir proc yaz�lmal� ve poli�e bazl� �al��mal�
    
      koc_hlth_clm_transfer.pr_clm_hlth_set_remaining(v_contract_id,
                                                      v_partition_no,
                                                      0,
                                                      0,
                                                      v_err_sq,
                                                      v_err_msg);
    end if;
    -- todo : e�er bireyselde �al���yorsa ve bireysel bu proca girmiyorsa kald�ral�m
    koc_health_policy_utils2.set_birth_right(v_contract_id, --sadece biraysel poli�elerde �al���yor bu nedenle i�indeki commit bizi ilgilendirmiyor ama grup i�in de �al��acaksa commit p_call_type_baz�nda de�i�meli
                                             v_partition_no,
                                             v_version_no);
  
    p_Indemrec              := null;
    p_Indemrec.contract_id  := v_contract_id;
    p_Indemrec.partition_no := v_partition_no;
    p_Indemrec.package_id   := null;
    p_Indemrec.package_date := null;
    p_Indemrec.log_type     := 'INDEM-CREATE';
    p_Indemrec.Log_Detail   := 'Plan G�ncelleme Bitti';
    p_Indemrec.log_state    := 'KOC_INDEMNITY_UTILS';
    p_Indemrec.log_status   := 0;
    p_Indemrec.online_sq_no := v_err_sq;
  
    koc_indemnity_utils.insert_indem_totals_log(p_Indemrec, null, null);
  
    -- her sigortal�da  commit
    commit;
  end loop;

end;

/*
1 419139242 38003
2 356574503 26461
3 355452290 23548
4 442964810 19710
5 441564560 19401
6 355453327 18172
7 442967122 16029
8 355452474 14022
9 443086403 12996
10  442964834 12130
11  355452545 11965
12  357027375 11238
13  442964850 11061
14  357723851 10359
15  442787105 9983
16  373811548 9658
17  356533695 5849
18  395511839 5693
19  442692553 4637
20  429720980 4324
21  356226881 4222
22  420414665 4073
23  355451503 4062
24  442338662 3974
25  357160526 3826
26  355451475 3763
27  406548068 3645
28  356216407 3527
29  355452191 3524
30  398035271 3445
31  356814882 3402
32  355453265 3232
33  442169622 3199
34  442957220 3175
35  442958835 3088
36  442961109 3064
37  442703926 3043
38  406114249 3038
39  402609394 2907
40  442964938 2875
41  355346337 2772
42  356215064 2770*/
