

---
--- CREATE YAPILACAKLAR LISTESI
---

1-) Koc_Clm_Hlth_Detail objesi oluşturulacaktır. Bu bilgiler, BRE ve REQUEST ile ortaklaşa doldurulacaktır.
	
	1.1 ALZ_HLTPRV_UTILS.Setclaimdetail --> Burada sadece obje olusturuluyor. Tek bir adet olacaktır.
	
	1.2 ALZ_HLTPRV_UTILS.Transclaimdetail --> Burada  da logic var
	
	1.3 ALZ_HLTPRV_UTILS.Updateprovisionstatus --> BRE'den çıkan sonuç Reject ise Objenin Status_Code = 'R' -> ALZ_HLTPRV_UTILS.Updateprovisionstatus içerisinde Rejectclaimfile
												--> Eğer BRE'den çıkan sonuç Reject değil ise ve eşleşmeyen kayıtlar var ise  UPDATE Koc_Clm_Hlth_Detail SET Status_Code = 'CP'
	
	1.4  ALZ_HLTPRV_UTILS.Transclaimdiagnose --> ClaimDetail objesinin içerisindeki  Class_Disease ve Final_Class_Disease degerleri set edilecektir.
	
	1.5 ALZ_HLTPRV_UTILS.Createclaimfile  --> BRE icerisinden gelen isAhek ve isComplimentary bilgisi set edilecektir.



2-) Liste halinde Koc_Clm_Hlth_Diagnosis objesi oluşturulacatır.

	2.1  ALZ_HLTPRV_UTILS.Setclaimdiagnose --> BRE'den gelen degerlere gore liste halinde obje oluşturulacaktır.
	
	

3-) Liste halinde Koc_Clm_Hlth_Provisions objesi oluşturulacaktır.

	3.1 ALZ_HLTPRV_UTILS.Choosecover --> Burada her bir provizyon elemanı için Teminat seçimi yapılacaktır.
	
		3.1.1 ALZ_HLTPRV_UTILS.Choosecoverfrombre 		--> Phltbreprovision.Healthprocesses'e gore teminat olusturma
	
		3.1.2 ALZ_HLTPRV_UTILS.Choosecoverforpreapprove --> yatisli icin teminat objesi olusturulacaktır
		
		3.1.3 ALZ_HLTPRV_UTILS.Choosecoverforproc 		--> 
		
		3.1.4 ALZ_HLTPRV_UTILS.Choosecoverforitem 		--> 

		3.1.5 ALZ_HLTPRV_UTILS.Choosecoverformedicine	--> 
	
	3.2 ALZ_HLTPRV_UTILS.Updateprovisionstatus --> BRE'den çıkan sonuç Reject ise Koc_Clm_Hlth_Provisions Objesinin Status_Code = 'R' -> ALZ_HLTPRV_UTILS.Updateprovisionstatus içerisinde Rejectclaimfile

	3.3 ALZ_HLTPRV_UTILS.Updatehealthprovisions --> Liste halindeki Koc_Clm_Hlth_Provisions objesinin her bir elemanı için 6 bilgi update edilecektir.
		(Vsumprocinstamt,Vsumprocsysamt,Vsumprocrequest,Vsumprocreject,Vsgkusedforcover,Vsumprocreject)
		(Koc_Clm_Hlth_Hospt_Utils.Settransamounts ve  Koc_Clm_Hlth_Trnx.Computeremaning işlemi burada yapılmayacaktır.)
		
	3.4 ALZ_HLTPRV_UTILS.Updatecoverstatus 
		Liste halindeki Koc_Clm_Hlth_Proc_Detail, Koc_Clm_Medicine_Indem_Det ve Koc_Clm_Hlth_Item_Detail objeleri içerisinde tüm elemanlar RED mi kontrolü yapılacak.
		Eğer hepsi red ise Liste halinde Koc_Clm_Hlth_Provisions objesi de RED olarak güncellenecektir.-->  UPDATE Koc_Clm_Hlth_Provisions  SET Status_Code = 'PR'
	
	3.5 SONRA KARAR VERILECEK!!! Koc_Clm_Hlth_Hosp_Med_Utils.Updatehealthprovisions içerisinde yapılan ASO kontrolü burada yapılacak!
		ASO durumuna göre buraya yeni bir provizyon objesi eklenebilir.!!!
	

4-) Liste halinde Koc_Clm_Hlth_Proc_Detail objesi oluşturulacaktır. BRE ve REQUEST ile ortaklaşa doldurulacaktır.

	4.1 ALZ_HLTPRV_UTILS.Setclaimprocess --> Liste halinde obje oluşturulacaktır.
	
	4.2 ALZ_HLTPRV_UTILS.Transclaimprocess

	4.2 ALZ_HLTPRV_UTILS.Updateprovisionstatus --> BRE'den çıkan sonuç Reject ise Koc_Clm_Hlth_Proc_Detail Objesinin Status_Code = 'R' -> ALZ_HLTPRV_UTILS.Updateprovisionstatus içerisinde Rejectclaimfile



5-) Liste halinde Koc_Clm_Medicine_Indem_Det objesi BRE ve REQUEST ile beraber oluşturulacak. --> (BRE kısmından BreResultCode, BarCode, LocationCode, CoverCode bilgileri BREden geliyor)
	
	5.1 ALZ_HLTPRV_UTILS.Setclaimmedicine --> Liste halinde obje oluşturulacaktır.

	5.2 ALZ_HLTPRV_UTILS.Updateprovisionstatus --> BRE'den çıkan sonuç Reject ise Koc_Clm_Medicine_Indem_Det Objesinin Status_Code = 'R' -> ALZ_HLTPRV_UTILS.Updateprovisionstatus içerisinde Rejectclaimfile

	5.3 ALZ_HLTPRV_UTILS.Transclaimmedicine --> Burada status update var


6-) Liste halinde Koc_Clm_Vacc_Indem_Totals objesi BRE ve REQUEST ile beraber oluşturulacak. --> (Eğer provisionreq.Medicalinfo.Consumables(i).Type = 'ASI' ise bu oluştutulacaktır.)
	
	6.1 ALZ_HLTPRV_UTILS.Setclaimmedicine --> Liste halinde obje oluşturulacaktır.
	
	6.2 ALZ_HLTPRV_UTILS.Updateprovisionstatus --> BRE'den çıkan sonuç Reject ise Koc_Clm_Vacc_Indem_Totals Objesinin Status_Code = 'R' -> ALZ_HLTPRV_UTILS.Updateprovisionstatus içerisinde Rejectclaimfile



7-) Liste halinde Koc_Clm_Hlth_Item_Detail objesi BRE ve REQUEST ile beraber oluşturulacak. -->  (BRE kısmından LocationCode bilgisi BRE'den geliyor)
	
	7.1 ALZ_HLTPRV_UTILS.Setclaimitem --> Liste halinde obje oluşturulacaktır.
	
	7.2 ALZ_HLTPRV_UTILS.Updateprovisionstatus --> BRE'den çıkan sonuç Reject ise Koc_Clm_Hlth_Item_Detail Objesinin Status_Code = 'R' -> ALZ_HLTPRV_UTILS.Updateprovisionstatus içerisinde Rejectclaimfile

	7.3 ALZ_HLTPRV_UTILS.Transclaimitem --> Burada status update var



8-) Liste halinde Koc_Clm_Web_Notmatch_Proc objesi oluşturulacak. -->  (BRE kısmından LocationCode bilgisi BRE'den geliyor)((NOT ::Koc_Clm_Hlth_Proc_Detail objesi ile aynı sadece not match flag'i var)
	
	8.1 ALZ_HLTPRV_UTILS.Choosecoverforproc --> Liste halinde obje oluşturulacaktır.
	
	8.2 ALZ_HLTPRV_UTILS.Choosecoverforpreapprove --> Liste halinde obje oluşturulacaktır.

	8.3 Not matchler icin Koc_Clm_Trans_Ext tablosuna 'SYT0' ile kayıt atmamız gerekiyor. Bunu unutma!!!


9-) Liste halinde Koc_Clm_Hlth_Reject_Loss objesi BRE ile oluşturulacak.
	
	9.1 ALZ_HLTPRV_UTILS.Setbredecision --> Liste halinde obje oluşturulacaktır.
	
	9.2 İçeriye gönderilen Liste insert edildikten sonra DELETE Koc_Clm_Web_Authorization ve LOOP  Koc_Clm_Hlth_Bpm_Utils.Insertauthorization işlemi vardır!!! Bunu unutma


10-) Liste halinde Koc_Clm_Web_Authorization objesi BRE ile oluşturulacak. --> ODN objeleri
	
	10.1 ALZ_HLTPRV_UTILS.Setbredecision --> Liste halinde obje oluşturulacaktır.



11-) Hasta yakını ve hasta bilgi formu için Objeleri oluştur. Sadece Requestten gelen değere göre oluşturuyor.
	
	11.1 Bir adet Koc_Clm_Hlth_Patient_Info_Form objesi oluşturuluyor.			(ALZ_HLTPRV_UTILS.Transclaimpatientinfoform  ve ALZ_HLTPRV_UTILS.Setclaimpatientinfoform)
	11.2 Liste halinde Koc_Clm_Hlth_Patient_Poly_Info objesi oluşturuluyor. 	(ALZ_HLTPRV_UTILS.(Transclaimpatientinfoform  ve ALZ_HLTPRV_UTILS.Setclaimpatientinfoform)
	11.3 Liste halinde Koc_Clm_Hlth_Patient_Exam_Info objesi oluşturuluyor. 	(ALZ_HLTPRV_UTILS.Transclaimpatientinfoform  ve ALZ_HLTPRV_UTILS.Setclaimpatientinfoform)
	11.4 Liste halinde Koc_Clm_Hlth_Patient_Surg_Note objesi oluşturuluyor. 	(ALZ_HLTPRV_UTILS.(Transclaimpatientinfoform  ve ALZ_HLTPRV_UTILS.Setclaimpatientinfoform)
	11.5 Liste halinde Koc_Clm_Hlth_Patient_Consl_Rep objesi oluşturuluyor. 	(ALZ_HLTPRV_UTILS.Transclaimpatientinfoform  ve ALZ_HLTPRV_UTILS.Setclaimpatientinfoform)
	11.6 Bir adet Alz_Hltprv_Relationship_Detail objesi oluşturulacak.			(ALZ_HLTPRV_UTILS.Transclaimrelationship  ve ALZ_HLTPRV_UTILS.Setclaimpatientinfoform)


12-) Otomatik dogum kararı verebilmek icin BRE tarafından parametre geciren obje olusturulacaktır. --> (BRE.Odnpregnantrestriction ve BRE.Pregnantrestriction)

	12.1 ALZ_HLTPRV_UTILS.Setpregnantdecision --> Transactional tarafta yapılacaktır.
		 (Koc_Clm_Hlth_Bpm_Auth_Function.Pregnantrestriction ve Koc_Clm_Hlth_Utils3.Pregdecisioninsertreject insert atılacak)
		 
		 
		 
		 