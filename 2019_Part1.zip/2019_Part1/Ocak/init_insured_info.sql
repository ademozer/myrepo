                    PROCEDURE Init_Insured_Info(v_Question NUMBER) IS
                        
                        	Insuredinfo                Koc_Clm_Hlth_Utils.Insuredtype := Koc_Clm_Hlth_Utils.Insuredtype();
                        	Policyinfo                 Koc_Clm_Hlth_Utils.Policytype := Koc_Clm_Hlth_Utils.Policytype();
                        	Insuredinforef             Koc_Clm_Hlth_Utils.Refcur;
                        	Policyinforef              Koc_Clm_Hlth_Utils.Refcur;
                        	v_Any_Policy               Koc_v_Health_Insured_Info%ROWTYPE;
                        	p_Close                    NUMBER;
                        	p_Day_Control              NUMBER;
                        	p_Status_Code              VARCHAR2(20);
                        	p_Status_Exp               VARCHAR2(200);
                        	v_Policyno                 NUMBER;
                        	v_Sayac                    NUMBER;
                        	v_Gecerli_Police           BOOLEAN;
                        	p_Close2                   NUMBER;
                        	p_Day_Control2             NUMBER;
                        	p_Status_Code2             VARCHAR2(20);
                        	p_Status_Exp2              VARCHAR2(200);
                        	v_Policyno2                NUMBER;
                        	v_Sayac2                   NUMBER;
                        	v_Gecerli_Police2          BOOLEAN;
                        	v_New_Claim_Inst_Type      VARCHAR2(10);
                        	v_New_Claim_Inst_Type_Desc VARCHAR2(100);
                        	v_Current_Block            VARCHAR2(100);
                        	v_Gecersiz_Exp             VARCHAR2(4000) := NULL;
                        	v_Many_Policy              NUMBER;
                        	Vip_Degree                 VARCHAR2(10);
                        	v_Status                   NUMBER;
                        	v_Messages                 VARCHAR2(200);
                        	v_Explanation              VARCHAR2(200);
                        	v_Ext                      NUMBER;
                        	Vclaiminsttypechanged      BOOLEAN := FALSE;
                        
                        	--ibrahimk
                        	v_Is_Plan_Comp NUMBER;
                        	v_Tss_Tem_Say  NUMBER;
                        	v_Oss_Tem_Say  NUMBER;
                        	--
                        
                        	p_Result NUMBER; -- orhan topal  
                        
                        --TYH-63377 - Allianz TR Care Üretim - Dilek Altunbaş - 26/04/2017 
                          CURSOR c_allianz_tr_care is 
                        -- kp 27.04.2017
                        SELECT DISTINCT DECODE(a.aztr_care_provision_type,'OP','Allianz TR Care PLUS','NP','Allianz TR Care','Provizyon Giriş Ekranı')
                          FROM koc_ocp_pol_versions_ext b
                              ,koc_cp_group_master a
                              ,ocp_policy_bases c
                        WHERE b.contract_id = :koc_clm_hlth_detail.contract_id
                           AND b.group_code = a.group_code
                           AND c.contract_id = b.contract_id
                           AND c.term_start_date = a.policy_start_date
                           AND c.term_end_date = a.policy_end_date
                           AND b.signature_date BETWEEN a.validity_start_date AND NVL(a.validity_end_date,b.signature_date);
                          	
                        --kp  v_aztr_care_provision_type varchar2(2);
                        
                        
                        BEGIN
                           --Müstehaklık Sorgusu Bağlanınca Buralar İptal olacak
                        	/*IF :Koc_Clm_Hlth_Detail.Contract_Id IS NULL AND
                        		 :Koc_Clm_Hlth_Detail.Policy_Ref IS NOT NULL
                        	THEN
                        		:Koc_Clm_Hlth_Detail.Contract_Id := Koc_Clm_Hlth_Utils.Getcontractidbypolicyref(:Koc_Clm_Hlth_Detail.Policy_Ref);
                        		IF :Koc_Clm_Hlth_Detail.Contract_Id IS NULL
                        		THEN
                        			Opu001.Msg(999999, 'E', NULL, NULL, NULL, 'Poliçe bulunamadı.');
                        			RAISE Form_Trigger_Failure;
                        		END IF;
                        	END IF;
                        
                        	IF :Koc_Clm_Hlth_Detail.Part_Id IS NOT NULL
                        	THEN
                        		Koc_Clm_Hlth_Utils.Getinsuredinfobypartnerid(:Koc_Clm_Hlth_Detail.Part_Id, Insuredinforef);
                        	
                        	ELSIF :Koc_Clm_Hlth_Detail.Card_No IS NOT NULL OR
                        				:Koc_Clm_Hlth_Detail.Insured_Identity_No IS NOT NULL
                        	THEN
                        		Koc_Clm_Hlth_Utils.Getinsuredinfobyactivecardno(:Koc_Clm_Hlth_Detail.Card_No, :Koc_Clm_Hlth_Detail.Insured_Identity_No,
                        																										:Koc_Clm_Hlth_Detail.Provision_Date_Time, Insuredinforef);
                        	
                        	ELSIF :Koc_Clm_Hlth_Detail.Policy_Ref IS NOT NULL AND
                        				:Koc_Clm_Hlth_Detail.Partition_No IS NOT NULL
                        	THEN
                        	
                        		Koc_Clm_Hlth_Utils.Getinsuredinfobycontractid(:Koc_Clm_Hlth_Detail.Contract_Id, :Koc_Clm_Hlth_Detail.Partition_No, Insuredinforef);
                        	END IF;*/
							
							
							
                        
                        	IF :Koc_Clm_Hlth_Detail.Part_Id IS NOT NULL OR
                        		 :Koc_Clm_Hlth_Detail.Card_No IS NOT NULL OR
                        		 :Koc_Clm_Hlth_Detail.Partition_No IS NOT NULL OR
                        		 :Koc_Clm_Hlth_Detail.Insured_Identity_No IS NOT NULL
                        	THEN
							    -- Müstehaklık Sorgusu Buraya Bağlanacak.
								
								ALZ_HCLM_CONVERTER_UTILS.initInsuredAndPolicyInfo(:Koc_Clm_Hlth_Detail.Part_Id,
								                                                  :Koc_Clm_Hlth_Detail.Card_No,
																		          :Koc_Clm_Hlth_Detail.Policy_Ref,
                                                                                  :Koc_Clm_Hlth_Detail.Partition_No,
																		          :Koc_Clm_Hlth_Detail.Insured_Identity_No,
           																          Insuredinforef,
																		          Policyinforef); 
																		 
                        		LOOP
                        			Insuredinfo.Extend;
                        		
                        			FETCH Insuredinforef
                        				INTO Insuredinfo(Insuredinfo.Last);
                        		
                        			EXIT WHEN Insuredinforef%NOTFOUND;
                        		END LOOP;
                        		CLOSE Insuredinforef;
                        	
                        		IF Insuredinfo(1).Part_Id IS NULL
                        		THEN
                        			Opu001.Msg(999999, 'E', NULL, NULL, NULL, 'Sigortalı bulunamadı.');
                        			RAISE Form_Trigger_Failure;
                        		END IF;
								
										 
                        	
                        		:Koc_Clm_Hlth_Detail.Part_Id             := Insuredinfo(1).Part_Id;
                        		:Koc_Clm_Hlth_Detail.Card_No             := Insuredinfo(1).Card_Info;
                        		:Global.Detail_Card_No                   := Insuredinfo(1).Card_Info;
                        		:Koc_Clm_Hlth_Detail.Insured_Identity_No := Insuredinfo(1).Identity_No;
                        		:Global.Insured_Identity_No              := Insuredinfo(1).Identity_No;
                        		:Koc_Clm_Hlth_Detail.Marital_Status      := Insuredinfo(1).Marital_Status_Exp;
                        		:Koc_Clm_Hlth_Detail.Gender              := Insuredinfo(1).Sex_Exp;
                        		:Koc_Clm_Hlth_Detail.Date_Of_Birth       := Insuredinfo(1).Date_Of_Birth;
                        	
                        		Pk_General_Utils.Setinsuredinfo(Insuredinfo);
                        	
                        		:Koc_Clm_Hlth_Detail.Insured_Name := Insuredinfo(1).First_Name || ' ' || Insuredinfo(1).Name;
                        	
                        		Set_Window_Property('WINDOW0', Title, 'Sigortalı: ' || :Koc_Clm_Hlth_Detail.Insured_Name);
                        	
                        		:Koc_Clm_Hlth_Detail.Insured_Vip := NULL;
                        	
                        		IF Nvl(Insuredinfo(1).Vip, 0) = 1
                        		THEN
                        			Vip_Degree := Koc_Clm_Hlth_Utils.Getvipdegree(Insuredinfo(1).Part_Id);
                        			IF Vip_Degree IS NOT NULL
                        			THEN
                        				:Koc_Clm_Hlth_Detail.Insured_Vip := 'VIP' || '-' || Vip_Degree;
                        			ELSE
                        				:Koc_Clm_Hlth_Detail.Insured_Vip := 'VIP';
                        			END IF;
                        		END IF;
                        	
                        		Synchronize;
                        	
                        		-- yeni giriş ise çalış  / bilgileri bulamadıysa
                        		IF ((:Koc_Clm_Hlth_Detail.Status_Code IS NULL AND (v_Question = 3 OR :Koc_Clm_Hlth_Detail.Claim_Id IS NULL) AND
                        			 :Koc_Clm_Hlth_Detail.Card_No IS NOT NULL)) OR
                        			 (:Koc_Clm_Hlth_Detail.Claim_Id IS NOT NULL AND :Koc_Clm_Hlth_Detail.Contract_Id IS NULL AND :Koc_Clm_Hlth_Detail.Policy_Ref IS NULL)
                        		
                        		THEN
                        			p_Day_Control    := 0;
                        			p_Close          := 1;
                        			p_Status_Code    := 'X';
                        			v_Sayac          := 0;
                        			v_Gecerli_Police := FALSE;
                        		    --müstehaklık sorgusundan dönmeli
                        			/*IF :Koc_Clm_Hlth_Detail.Contract_Id IS NULL
                        			THEN
                        				Koc_Clm_Hlth_Utils.Getpolicyinfobypartid(:Koc_Clm_Hlth_Detail.Part_Id, :Koc_Clm_Hlth_Detail.Provision_Date_Time, Policyinforef);
                        			ELSE
                        				Koc_Clm_Hlth_Utils.Getpolinfobypartandcontract(:Koc_Clm_Hlth_Detail.Contract_Id, :Koc_Clm_Hlth_Detail.Partition_No,
                        																											 :Koc_Clm_Hlth_Detail.Part_Id, :Koc_Clm_Hlth_Detail.Provision_Date_Time, Policyinforef);
                        			END IF;*/
									
                        		
                        			LOOP
                        				Policyinfo.Extend;
                        			
                        				FETCH Policyinforef
                        					INTO Policyinfo(Policyinfo.Last);
                        			
                        				EXIT WHEN Policyinforef%NOTFOUND;
                        			
                        				v_Any_Policy := Policyinfo(Policyinfo.Last);
                        			     -- müstehaklıkta olmalı. 
                        				/*Koc_Clm_Hlth_Trnx.Getvalidpolicyparam(Policyinfo(Policyinfo.Last).Contract_Id, Policyinfo(Policyinfo.Last).Partition_No,
                        																							Policyinfo(Policyinfo.Last).Insured_Old_Contract, Policyinfo(Policyinfo.Last).Policy_Start_Date,
                        																							:Koc_Clm_Hlth_Detail.Provision_Date_Time, Policyinfo(Policyinfo.Last).Product_Id,
                        																							Policyinfo(Policyinfo.Last).Sub_Company_Code, p_Day_Control, p_Close, p_Status_Code, p_Status_Exp);*/
																													
                        			
                        				IF p_Status_Code IS NOT NULL
                        				THEN
                        					v_Gecersiz_Exp := Policyinfo(Policyinfo.Last).Policy_Ref || ':' || p_Status_Exp || ',';
                        				END IF;
                        			
                        				IF p_Day_Control = 1 AND
                        					 p_Close = 0 AND
                        					 p_Status_Code IS NULL
                        				THEN
                        					v_Gecerli_Police := TRUE;
                        					v_Sayac          := v_Sayac + 1;
                        					v_Policyno       := Policyinfo.Last;
                        				END IF;
                        			END LOOP;
                        			CLOSE Policyinforef;
                        		
                        			-- sigoralının girilen poliçesi geçersiz ise başka geçerli poliçesi var mı kontrol ediliyor
                        			v_Gecerli_Police2 := FALSE;
                        		
                        			IF NOT v_Gecerli_Police AND
                        				 :Koc_Clm_Hlth_Detail.Contract_Id IS NOT NULL
                        			THEN
                        				p_Day_Control2    := 0;
                        				p_Close2          := 1;
                        				p_Status_Code2    := 'X';
                        				v_Sayac2          := 0;
                        				v_Gecerli_Police2 := FALSE;
                        			
                        				:Koc_Clm_Hlth_Detail.Contract_Id := NULL;
										--müstehaklık sorgusundan dönmüş olmalı
                        			    /* 
                        				Koc_Clm_Hlth_Utils.Getpolicyinfobypartid(:Koc_Clm_Hlth_Detail.Part_Id, :Koc_Clm_Hlth_Detail.Provision_Date_Time, Policyinforef);
										*/
                        				LOOP
                        					Policyinfo.Extend;
                        				
                        					FETCH Policyinforef
                        						INTO Policyinfo(Policyinfo.Last);
                        				
                        					EXIT WHEN Policyinforef%NOTFOUND;
                        				
                        					v_Any_Policy := Policyinfo(Policyinfo.Last);
                        				    -- müstehaklık tan dönmeli
                        					/*Koc_Clm_Hlth_Trnx.Getvalidpolicyparam(Policyinfo(Policyinfo.Last).Contract_Id, Policyinfo(Policyinfo.Last).Partition_No,
                        																								Policyinfo(Policyinfo.Last).Insured_Old_Contract, Policyinfo(Policyinfo.Last).Policy_Start_Date,
                        																								:Koc_Clm_Hlth_Detail.Provision_Date_Time, Policyinfo(Policyinfo.Last).Product_Id,
                        																								Policyinfo(Policyinfo.Last).Sub_Company_Code, p_Day_Control2, p_Close2, p_Status_Code2, p_Status_Exp2);*/
                        				
                        					IF p_Day_Control2 = 1 AND
                        						 p_Close2 = 0 AND
                        						 p_Status_Code2 IS NULL
                        					THEN
                        						v_Gecerli_Police2 := TRUE;
                        						v_Sayac2          := v_Sayac2 + 1;
                        						v_Policyno2       := Policyinfo.Last;
                        					END IF;
                        				END LOOP;
                        				CLOSE Policyinforef;
                        			END IF;
                        		
                        			IF NOT v_Gecerli_Police
                        			THEN
                        				--sigoralının geçerli poliçesi yok 
                        				IF NOT v_Gecerli_Police2
                        				THEN
                        					:Koc_Clm_Hlth_Detail.Status_Code := 'GECERSIZ';
                        				
                        					IF :Koc_Clm_Hlth_Detail.Claim_Id IS NULL
                        					THEN
                        						:Koc_Clm_Hlth_Detail.Claim_Id     := Koc_Clm_Hlth_Trnx.Genclaimid; --genRequestId;
                        						:Koc_Clm_Hlth_Detail.Sf_No        := 1;
                        						:Koc_Clm_Hlth_Detail.Add_Order_No := 1;
                        					END IF;
                        				
                        					IF v_Gecersiz_Exp IS NOT NULL
                        					THEN
                        						v_Gecersiz_Exp := Substr(v_Gecersiz_Exp, 1, Length(v_Gecersiz_Exp) - 1);
                        						Opu001.Msg(999999, 'E', NULL, NULL, NULL, v_Gecersiz_Exp);
                        					END IF;
                        				
                        					IF v_Any_Policy.Contract_Id IS NOT NULL
                        					THEN
                        						Opu001.Msg(999999, 'E', NULL, NULL, NULL, 'Poliçe hasara kapatılmıştır. Sigortalının geçerli poliçesi bulunmamaktadır.');
                        					
                        						:Koc_Clm_Hlth_Detail.Contract_Id         := v_Any_Policy.Contract_Id;
                        						:Koc_Clm_Hlth_Detail.Partition_No        := v_Any_Policy.Partition_No;
                        						:Global.Partition_No                     := v_Any_Policy.Partition_No;
                        						:Global.Prev_Policy_Ref                  := v_Any_Policy.Policy_Ref;
                        						:Koc_Clm_Hlth_Detail.Policy_Ref          := v_Any_Policy.Policy_Ref;
                        						:Koc_Clm_Hlth_Detail.Term_Start_Date     := v_Any_Policy.Term_Start_Date;
                        						:Koc_Clm_Hlth_Detail.Term_End_Date       := v_Any_Policy.Term_End_Date;
                        						:Koc_Clm_Hlth_Detail.Type_Of_Interest    := v_Any_Policy.Type_Of_Interest_Exp;
                        						:Koc_Clm_Hlth_Detail.Group_Code          := v_Any_Policy.Group_Code;
                        						:Koc_Clm_Hlth_Detail.Sub_Company_Code    := v_Any_Policy.Sub_Company_Code;
                        						:Koc_Clm_Hlth_Detail.Partition_Type      := v_Any_Policy.Partition_Type;
                        						:Koc_Clm_Hlth_Detail.Product_Id          := v_Any_Policy.Product_Id;
                        						:Koc_Clm_Hlth_Detail.Package_Id          := v_Any_Policy.Package_Id;
                        						:Koc_Clm_Hlth_Detail.Package_Name        := v_Any_Policy.Pack_Name;
                        						:Koc_Clm_Hlth_Detail.Package_Date        := v_Any_Policy.Package_Date;
                        						:Koc_Clm_Hlth_Detail.Policy_Holder       := v_Any_Policy.Ph_Name;
                        						:Koc_Clm_Hlth_Detail.Partition_Type_Desc := Koc_Clm_Hlth_Utils2.Getpartitiontypedesc(v_Any_Policy.Partition_Type);
                        						:Koc_Clm_Hlth_Detail.Ip_No               := v_Any_Policy.Ip_No;
                        						:Koc_Clm_Hlth_Detail.Insured_Entry_Date  := Koc_Clm_Hlth_Utils.Getfirstentrydate(:Koc_Clm_Hlth_Detail.Part_Id, NULL);
                        					
                        						--ibrahimk
                        						Is_Plan_Tip;
                        					
                        						Checkemergency_Status(:Koc_Clm_Hlth_Detail.Group_Code, :Koc_Clm_Hlth_Detail.Term_Start_Date, :Koc_Clm_Hlth_Detail.Term_End_Date, 0);
                        					
                        						--musti@kora öss
                        						Get_Oss_Date(:Koc_Clm_Hlth_Detail.Part_Id, v_Any_Policy.Group_Code, v_Any_Policy.Term_End_Date);
                        						--musti@kora öss
                        					
                        						--aysel 27.04.2010    
                        						IF v_Any_Policy.Partition_Type = 'EKO1'
                        						THEN
                        							Set_Item_Property('koc_clm_hlth_detail.v_plan_entry_date', Visible, Property_True);
                        							Set_Item_Property('koc_clm_hlth_detail.v_plan_entry_date', Enabled, Property_True);
                        							:Koc_Clm_Hlth_Detail.v_Plan_Entry_Date := Koc_Clm_Hlth_Utils.Getfirstentrydate_Parttype(:Koc_Clm_Hlth_Detail.Part_Id,
                        																																																			v_Any_Policy.Partition_Type);
                        						ELSE
                        							Set_Item_Property('koc_clm_hlth_detail.v_plan_entry_date', Visible, Property_False);
                        							Set_Item_Property('koc_clm_hlth_detail.v_plan_entry_date', Enabled, Property_False);
                        						END IF;
                        					
                        						IF :Koc_Clm_Hlth_Detail.Product_Id = 63
                        						THEN
                        							:Koc_Clm_Hlth_Detail.Disease_Date := :Koc_Clm_Hlth_Detail.Term_Start_Date;
                        						ELSE
                        							:Koc_Clm_Hlth_Detail.Disease_Date := :Koc_Clm_Hlth_Detail.Term_End_Date;
                        						END IF;
                        					
                        						IF v_Any_Policy.Obyg = 1
                        						THEN
                        							:Koc_Clm_Hlth_Detail.Obyg := 'OBYG';
                        						ELSE
                        							:Koc_Clm_Hlth_Detail.Obyg := NULL;
                        						END IF;
                        					
                        						----BKUNDAK BASLANGIC
                        						---BKUNDAK SEGMENT BILGILERI
                        						Koc_Partner_Utils.Vip_Blist_Control_For_Partner(:Koc_Clm_Hlth_Detail.Part_Id, v_Status, v_Messages);
                        					
                        						IF Nvl(v_Status, 0) <> 0
                        						THEN
                        							Set_Item_Property('koc_clm_hlth_detail.black_partner', Visual_Attribute, 'VA_SEGMENT');
                        							:Koc_Clm_Hlth_Detail.Black_Partner := v_Messages;
                        						END IF;
                        					
                        						Synchronize;
                        						Insurednotes;
                        						Pk_General_Utils.Policyinfo := v_Any_Policy;
                        					
                        						-- poliçeye bağlı, yeni kurum lokasyonu
												/*buralar iptal edilmeli. ademo */
                        						Claiminsttype;
                        						Getnewclaiminsttype(:Koc_Clm_Hlth_Detail.Package_Id, :Koc_Clm_Hlth_Detail.Orig_Claim_Inst_Type, :Koc_Clm_Hlth_Detail.Institute_Code,
                        																:Koc_Clm_Hlth_Detail.Inst_City_Code, v_New_Claim_Inst_Type);
                        					
                        						IF v_New_Claim_Inst_Type IS NOT NULL
                        						THEN
                        							:Koc_Clm_Hlth_Detail.Claim_Inst_Type      := v_New_Claim_Inst_Type;
                        							:Koc_Clm_Hlth_Detail.Claim_Inst_Type_Desc := v_New_Claim_Inst_Type;
                        							Vclaiminsttypechanged                     := TRUE;
                        						END IF;
                        					
                        						IF NOT Vclaiminsttypechanged
                        						THEN
                        							IF :Koc_Clm_Hlth_Detail.Claim_Inst_Type NOT IN ('AK', 'AHK', 'DH')
                        							THEN
                        								:Koc_Clm_Hlth_Detail.Claim_Inst_Type := :Koc_Clm_Hlth_Detail.Orig_Claim_Inst_Type;
                        							END IF;
                        						END IF;
                        					
                        						IF :Koc_Clm_Hlth_Detail.Claim_Inst_Type <> :Koc_Clm_Hlth_Detail.Orig_Claim_Inst_Type
                        						THEN
                        							Opu001.Msg(999999, 'I', NULL, NULL, NULL,
                        												 'Dikkat, kurum tipi değişiyor ! (' || :Koc_Clm_Hlth_Detail.Orig_Claim_Inst_Type || '->' ||
                        													:Koc_Clm_Hlth_Detail.Claim_Inst_Type || ')');
                        						END IF;
                        					    --- ademo
                        						Ispolicyvalidforinst;
                        					ELSE
                        						Opu001.Msg(999999, 'E', NULL, NULL, NULL,
                        											 'Sigortalının geçerli poliçesi bulunmamaktadır. Sigortalımıza lütfen anlaşmalı kurum fiyatlarını uygulamayı unutmayınız.');
                        						Go_Item('control.explanation');
                        						Show_View('CAN_EXPLANATION');
                        					END IF;
                        				ELSE
                        					IF v_Gecersiz_Exp IS NOT NULL
                        					THEN
                        						v_Gecersiz_Exp := Substr(v_Gecersiz_Exp, 1, Length(v_Gecersiz_Exp) - 1);
                        						Opu001.Msg(999999, 'E', NULL, NULL, NULL, v_Gecersiz_Exp);
                        					END IF;
                        				
                        					Opu001.Msg(999999, 'W', NULL, NULL, NULL,
                        										 'Seçilen poliçe hasara kapatılmıştır. Sigortalının geçerli başka poliçesi var. Lütfen poliçeyi seçiniz.');
                        					Choosepolicy(1);
                        				END IF;
                        			ELSE
                        				:Control.Query_Claim_Id := NULL;
                        			
                        				IF Isanyclaimininstitute != 0 AND
                        					 :Koc_Clm_Hlth_Detail.Card_No IS NOT NULL AND
                        					 :Koc_Clm_Hlth_Detail.Claim_Id IS NULL AND
                        					 v_Question IN (1, 3)
                        				THEN
                        					Opu001.Msg(999999, 'Q', NULL, NULL, NULL, 'Sigortalının provizyona açık hasar dosyaları görüntülensin mi ?');
                        					IF Opu001.v_Alert_Button = Alert_Button1
                        					THEN
                        						Chooseprovision;
                        					END IF;
                        				END IF;
                        			
                        				--s.k. 11.03.2008
                        				-- geçerli  birden fazla poliçesi var ise 
                        				v_Many_Policy := 0;
                        			
                        				IF :Koc_Clm_Hlth_Detail.Contract_Id IS NOT NULL
                        				THEN
                        					v_Many_Policy := Koc_Clm_Hlth_Utils2.Countvalidpolicy(NULL, NULL, :Koc_Clm_Hlth_Detail.Part_Id, :Koc_Clm_Hlth_Detail.Provision_Date_Time);
                        				END IF;
                        			
                        				IF (v_Sayac > 1 OR v_Many_Policy > 1) AND
                        					 :Control.Query_Claim_Id IS NULL AND
                        					 :Koc_Clm_Hlth_Detail.Policy_Ref IS NULL
                        				THEN
                        					Opu001.Msg(999999, 'W', NULL, NULL, NULL, 'Sigortalının birden fazla geçerli poliçesi var. Lütfen poliçeyi seçiniz.');
                        					Choosepolicy(1);
                        				
                        					-- poliçeye bağlı, yeni kurum lokasyonu ---------------------------
                        					Claiminsttype;
                        					Getnewclaiminsttype(:Koc_Clm_Hlth_Detail.Package_Id, :Koc_Clm_Hlth_Detail.Orig_Claim_Inst_Type, :Koc_Clm_Hlth_Detail.Institute_Code,
                        															:Koc_Clm_Hlth_Detail.Inst_City_Code, v_New_Claim_Inst_Type);
                        				
                        					IF v_New_Claim_Inst_Type IS NOT NULL
                        					THEN
                        						:Koc_Clm_Hlth_Detail.Claim_Inst_Type      := v_New_Claim_Inst_Type;
                        						:Koc_Clm_Hlth_Detail.Claim_Inst_Type_Desc := v_New_Claim_Inst_Type;
                        						Vclaiminsttypechanged                     := TRUE;
                        					END IF;
                        				
                        					IF NOT Vclaiminsttypechanged
                        					THEN
                        						IF :Koc_Clm_Hlth_Detail.Claim_Inst_Type NOT IN ('AK', 'AHK', 'DH')
                        						THEN
                        							:Koc_Clm_Hlth_Detail.Claim_Inst_Type := :Koc_Clm_Hlth_Detail.Orig_Claim_Inst_Type;
                        						END IF;
                        					END IF;
                        				
                        					IF :Koc_Clm_Hlth_Detail.Claim_Inst_Type <> :Koc_Clm_Hlth_Detail.Orig_Claim_Inst_Type
                        					THEN
                        						Opu001.Msg(999999, 'I', NULL, NULL, NULL,
                        											 'Dikkat, kurum tipi değişiyor ! (' || :Koc_Clm_Hlth_Detail.Orig_Claim_Inst_Type || '->' ||
                        												:Koc_Clm_Hlth_Detail.Claim_Inst_Type || ')');
                        					END IF;
                        				
                        					Ispolicyvalidforinst;
                        				END IF;
                        			
                        				-- s.k. 11.03.2008
                        				-- GEÇERLİ 1 POLİÇE VAR İSE
                        				IF v_Sayac = 1 AND
                        					 :Control.Query_Claim_Id IS NULL
                        				THEN
                        					:Koc_Clm_Hlth_Detail.Contract_Id         := Policyinfo(v_Policyno).Contract_Id;
                        					:Koc_Clm_Hlth_Detail.Partition_No        := Policyinfo(v_Policyno).Partition_No;
                        					:Global.Partition_No                     := Policyinfo(v_Policyno).Partition_No;
                        					:Global.Prev_Policy_Ref                  := Policyinfo(v_Policyno).Policy_Ref;
                        					:Koc_Clm_Hlth_Detail.Policy_Ref          := Policyinfo(v_Policyno).Policy_Ref;
                        					:Koc_Clm_Hlth_Detail.Term_Start_Date     := Policyinfo(v_Policyno).Term_Start_Date;
                        					:Koc_Clm_Hlth_Detail.Term_End_Date       := Policyinfo(v_Policyno).Term_End_Date;
                        					:Koc_Clm_Hlth_Detail.Type_Of_Interest    := Policyinfo(v_Policyno).Type_Of_Interest_Exp;
                        					:Koc_Clm_Hlth_Detail.Group_Code          := Policyinfo(v_Policyno).Group_Code;
                        					:Koc_Clm_Hlth_Detail.Sub_Company_Code    := Policyinfo(v_Policyno).Sub_Company_Code;
                        					:Koc_Clm_Hlth_Detail.Partition_Type      := Policyinfo(v_Policyno).Partition_Type;
                        					:Koc_Clm_Hlth_Detail.Product_Id          := Policyinfo(v_Policyno).Product_Id;
                        					:Koc_Clm_Hlth_Detail.Package_Id          := Policyinfo(v_Policyno).Package_Id;
                        					:Koc_Clm_Hlth_Detail.Package_Name        := Policyinfo(v_Policyno).Pack_Name;
                        					:Koc_Clm_Hlth_Detail.Package_Date        := Policyinfo(v_Policyno).Package_Date;
                        					:Koc_Clm_Hlth_Detail.Policy_Holder       := Policyinfo(v_Policyno).Ph_Name;
                        					:Koc_Clm_Hlth_Detail.Partition_Type_Desc := Koc_Clm_Hlth_Utils2.Getpartitiontypedesc(Policyinfo(v_Policyno).Partition_Type);
                        					:Koc_Clm_Hlth_Detail.Ip_No               := Policyinfo(v_Policyno).Ip_No;
                        					:Koc_Clm_Hlth_Detail.Insured_Entry_Date  := Koc_Clm_Hlth_Utils.Getfirstentrydate(:Koc_Clm_Hlth_Detail.Part_Id, NULL);
                        				
                        					--ibrahimk
                        					Is_Plan_Tip;
                        				
                        					--musti@kora öss
                        					Get_Oss_Date(:Koc_Clm_Hlth_Detail.Part_Id, Policyinfo(v_Policyno).Group_Code, Policyinfo(v_Policyno).Term_End_Date);
                        					--musti@kora öss
                        				
                        					Checkemergency_Status(:Koc_Clm_Hlth_Detail.Group_Code, :Koc_Clm_Hlth_Detail.Term_Start_Date, :Koc_Clm_Hlth_Detail.Term_End_Date, 0);
                        				
                        					--aysel 27.04.2010        
                        					IF Policyinfo(v_Policyno).Partition_Type = 'EKO1'
                        					THEN
                        						Set_Item_Property('koc_clm_hlth_detail.v_plan_entry_date', Visible, Property_True);
                        						Set_Item_Property('koc_clm_hlth_detail.v_plan_entry_date', Enabled, Property_True);
                        						:Koc_Clm_Hlth_Detail.v_Plan_Entry_Date := Koc_Clm_Hlth_Utils.Getfirstentrydate_Parttype(:Koc_Clm_Hlth_Detail.Part_Id,
                        																																																		Policyinfo(v_Policyno).Partition_Type);
                        					ELSE
                        						Set_Item_Property('koc_clm_hlth_detail.v_plan_entry_date', Visible, Property_False);
                        						Set_Item_Property('koc_clm_hlth_detail.v_plan_entry_date', Enabled, Property_False);
                        					END IF;
                        				
                        					IF Policyinfo(v_Policyno).Obyg = 1
                        					THEN
                        						:Koc_Clm_Hlth_Detail.Obyg := 'OBYG';
                        					ELSE
                        						:Koc_Clm_Hlth_Detail.Obyg := NULL;
                        					END IF;
                        				
                        					IF :Koc_Clm_Hlth_Detail.Product_Id = 63
                        					THEN
                        						:Koc_Clm_Hlth_Detail.Disease_Date := :Koc_Clm_Hlth_Detail.Term_Start_Date;
                        					ELSE
                        						:Koc_Clm_Hlth_Detail.Disease_Date := :Koc_Clm_Hlth_Detail.Term_End_Date;
                        					END IF;
                        				
                        					-- poliçeye bağlı, yeni kurum lokasyonu ---------------------------
                        					Claiminsttype;
                        					Getnewclaiminsttype(:Koc_Clm_Hlth_Detail.Package_Id, :Koc_Clm_Hlth_Detail.Orig_Claim_Inst_Type, :Koc_Clm_Hlth_Detail.Institute_Code,
                        															:Koc_Clm_Hlth_Detail.Inst_City_Code, v_New_Claim_Inst_Type);
                        				
                        					IF v_New_Claim_Inst_Type IS NOT NULL
                        					THEN
                        						:Koc_Clm_Hlth_Detail.Claim_Inst_Type      := v_New_Claim_Inst_Type;
                        						:Koc_Clm_Hlth_Detail.Claim_Inst_Type_Desc := v_New_Claim_Inst_Type;
                        						Vclaiminsttypechanged                     := TRUE;
                        					END IF;
                        				
                        					IF NOT Vclaiminsttypechanged
                        					THEN
                        						IF :Koc_Clm_Hlth_Detail.Claim_Inst_Type NOT IN ('AK', 'AHK', 'DH')
                        						THEN
                        							:Koc_Clm_Hlth_Detail.Claim_Inst_Type := :Koc_Clm_Hlth_Detail.Orig_Claim_Inst_Type;
                        						END IF;
                        					END IF;
                        				
                        					IF :Koc_Clm_Hlth_Detail.Claim_Inst_Type <> :Koc_Clm_Hlth_Detail.Orig_Claim_Inst_Type
                        					THEN
                        						Opu001.Msg(999999, 'I', NULL, NULL, NULL,
                        											 'Dikkat, kurum tipi değişiyor ! (' || :Koc_Clm_Hlth_Detail.Orig_Claim_Inst_Type || '->' ||
                        												:Koc_Clm_Hlth_Detail.Claim_Inst_Type || ')');
                        					END IF;
                        				
                        					Synchronize;
                        					Insurednotes;
                        					Ispolicyvalidforinst;  -- müstehaklık servisinde bu kontrol yapılıyor. burada tekrar yapılmasına gerek yok 
                        				
                        					Pk_General_Utils.Policyinfo := Policyinfo(v_Policyno);
                        				
                        					IF :Koc_Clm_Hlth_Detail.Contract_Id IS NOT NULL AND
                        						 v_Question IN (1, 3)
                        					THEN
                        						Opu001.Msg(999999, 'Q', NULL, NULL, NULL, 'Poliçenin kalan limitleri görüntülensin mi?');
                        						IF Opu001.v_Alert_Button = Alert_Button1
                        						THEN
                        							Choosepolicy(1);
                        						ELSE
                        							IF :Koc_Clm_Hlth_Detail.Claim_Id IS NULL
                        							THEN
                        								:Koc_Clm_Hlth_Detail.Claim_Id     := Koc_Clm_Hlth_Trnx.Genclaimid; --.genRequestId;
                        								:Koc_Clm_Hlth_Detail.Sf_No        := 1;
                        								:Koc_Clm_Hlth_Detail.Add_Order_No := 1;
                        							END IF;
                        						END IF;
                        					END IF;
                        				END IF; --1 poliçe var ise
                        			END IF; --geçerli poliçe yok
                        		END IF; --status_code is null yeni giriş
                        	END IF; -- kart no yada part id var ise  
                        
                        	/*Orhan topal 14 kasim 2015 Affulent Custormer*/
                        	DECLARE
                        	
                        		x_Segment_Kodu             NUMBER;
                        		x_Segment_Aciklamasi       VARCHAR2(200);
                        		x_Segment_Ekran_Aciklamasi VARCHAR2(200);
                        		Count_Word                 NUMBER;
                        		x_First_Word               VARCHAR2(200);
                        		x_Second_Word              VARCHAR2(200);
                        	
                        	BEGIN
                        		Customer.Alz_Affluent_Customer.Get_Policy_Customer(Koc_Ocp_Hlth_Utils.Get_Policy_Ref(:Koc_Clm_Hlth_Detail.Contract_Id),
                        																											 :Koc_Clm_Hlth_Detail.Insured_Identity_No, p_Result);
                        	
                        		IF (p_Result = 1)
                        		THEN
                        			Set_Item_Property('KOC_CLM_HLTH_DETAIL.AFFLUENT_CUSTOMER1', Visible, Property_True);
                        			Set_Item_Property('KOC_CLM_HLTH_DETAIL.AFFLUENT_CUSTOMER2', Visible, Property_True);
                        		
                        			Customer.Alz_Affluent_Customer.Get_Policy_Customer_Value(Koc_Ocp_Hlth_Utils.Get_Policy_Ref(:Koc_Clm_Hlth_Detail.Contract_Id),
                        																															 :Koc_Clm_Hlth_Detail.Insured_Identity_No, x_Segment_Kodu, x_Segment_Aciklamasi,
                        																															 x_Segment_Ekran_Aciklamasi);
                        		
                        			SELECT Instr(x_Segment_Ekran_Aciklamasi, ' ', 1) INTO Count_Word FROM Dual;
                        		
                        			IF (Count_Word = 0)
                        			THEN
                        				:Koc_Clm_Hlth_Detail.Affluent_Customer1 := x_Segment_Ekran_Aciklamasi;
                        				:Koc_Clm_Hlth_Detail.Affluent_Customer2 := '';
                        			ELSE
                        				SELECT Substr(x_Segment_Ekran_Aciklamasi, 1, Instr(x_Segment_Ekran_Aciklamasi, ' ', 1) - 1),
                        							 Substr(x_Segment_Ekran_Aciklamasi, Instr(x_Segment_Ekran_Aciklamasi, ' ', 1) + 1)
                        					INTO x_First_Word,
                        							 x_Second_Word
                        					FROM Dual;
                        			
                        				:Koc_Clm_Hlth_Detail.Affluent_Customer1 := x_First_Word;
                        				:Koc_Clm_Hlth_Detail.Affluent_Customer2 := x_Second_Word;
                        			END IF;
                        		
                        		ELSE
                        			Set_Item_Property('KOC_CLM_HLTH_DETAIL.AFFLUENT_CUSTOMER1', Visible, Property_False);
                        			Set_Item_Property('KOC_CLM_HLTH_DETAIL.AFFLUENT_CUSTOMER2', Visible, Property_False);
                        		END IF;
                        
                        --TYH-63377 - Allianz TR Care Üretim - Dilek Altunbaş - 26/04/2017 
                        -- kp 27.04.2017 Init_Insured_Info içerisinde ürüne göre set ediliyor.
                        	 	:BOILER.PROVIZYON := 'Provizyon Giriş Ekranı'; 
                            Set_Item_Property('BOILER.PROVIZYON',VISUAL_ATTRIBUTE,'VA_NORMAL');
                        
                        
                            open c_allianz_tr_care;
                        	 fetch c_allianz_tr_care into :BOILER.PROVIZYON; --v_aztr_care_provision_type;
                        	 close c_allianz_tr_care;	 	
                           
                           --set_item_property('BOILER.PROVIZYON',Background_color,'r100g25b0');
                           --SET_VA_PROPERTY('MY_COLOR', FOREGROUND_COLOR, 'r191g223b191'); 
                           IF :BOILER.PROVIZYON = 'Provizyon Giriş Ekranı' THEN
                               Set_Item_Property('BOILER.PROVIZYON',VISUAL_ATTRIBUTE,'VA_NORMAL');      
                           ELSE
                               Set_Item_Property('BOILER.PROVIZYON',VISUAL_ATTRIBUTE,'VA_ALZTRCARE');
                           END IF;     
                        	
                        	EXCEPTION
                        		WHEN OTHERS THEN
                        			Message('HATA: ' || SQLERRM);
                              Opu001.Msg(999999, 'E', NULL, NULL, NULL, 'INIT_INSURED_INFO - Beklenemdik bir hata oluştu, hata bilgisi ekranın sol altındadır.');
                        	END;
                        	/*Orhan topal 14 kasim 2015 Affulent Custormer*/
                        	Is_Complementary; --mustafaku TSS Flag    
                        END;