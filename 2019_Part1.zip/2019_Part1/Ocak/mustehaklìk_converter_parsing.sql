DECLARE 
 TYPE t_policy IS TABLE OF Koc_v_Health_Insured_Info%ROWTYPE;
 --TYPE t_insured IS TABLE OF Koc_v_Health_Partner_Info%ROWTYPE;
 
 v_policy_list t_policy := t_policy();
 v_policy Koc_v_Health_Insured_Info%ROWTYPE;
 v_insured Koc_v_Health_Partner_Info%ROWTYPE;
 v_data VARCHAR2(32767) := '"originDate": "2018-02-22T12:06:02.000+0000",
    "partId": 7732393,
    "identityNo": 15934126528,
    "taxId": null,
    "cardNo": "7049448",
    "firstName": "AHMAD",
    "surName": "SARIG�L",
    "fatherName": "�LHAM�",
    "motherName": "SEYRAN",
    "sex": "M",
    "dateOfBirth": "1983-05-04T21:00:00.000+0000",
    "beneficiaryGroup": null,
    "phoneNumber": null,
    "mobilePhone": null,
    "policyMessage": null,
    "policies": [
      {
        "policyRef": "0001071002857742-1",
        "contractId": 367856493,
        "partitionType": "MDSG",
        "partitionNo": 1,
        "groupCode": null,
        "partitionTypeDesc": null,
        "locationCheck": null,
        "vipInfo": null,
        "vipMessage": null,
        "relationShip": null,
        "phName": "KODE B�L���M LTD.�T�.",
        "partitionName": null,
        "productId": 63,
        "productName": null,
        "policyStatus": "AKTIF",
        "policyStatusMessage": "\r\nPoli�enin ge�ersiz oldu�u anla�mal� kurum giderleri hi�bir �ekilde kar��lanmayacakt�r.",
        "subCompanyCode": null,
        "subCompanyName": "045",
        "termStartDate": "2018-03-01T21:00:00.000+0000",
        "termEndDate": "2019-03-01T21:00:00.000+0000",
        "actionCode": "A",
        "hasObyg": false,
        "packageId": 114682,
        "packageDate": "2015-03-02T22:00:00.000+0000",
        "typeOfInterest": "K",
        "typeOfInterestExp": "K",
        "contractStatus": "I",
        "policyStartDate": "2018-03-01T21:00:00.000+0000",
        "policyEndDate": "2019-03-01T21:00:00.000+0000",
        "policeSirket": "Allianz Sigorta A.�.",
        "ipNo": 1,
        "agentIntId": 39541,
        "phPartnerId": 48179090,
        "groupName": null,
        "versionNo": 2,
        "packExtRef": "MDLR_DUMMY",
        "packName": "MOD�LER",
        "packageStatus": "A",
        "packageValid": null,
        "termStartDateTime": "02/03/2018 00:00:00",
        "termEndDateTime": "02/03/2019 00:00:00",
        "endorsementNo": 1,
        "insuredOldContract": null,
        "policyOldContract": null,
        "prodExtRef": null,
        "priority": 99,
        "useExempRate": false,
        "dayControlOk": false,
        "closedToIndemnity": false,
        "statusCode": null,
        "paymentProblems": null,
        "provisionEnabled": false,
        "contractMessage": null,
        "complementary": false,
        "tpaCompanyCode": null,
        "tpaCompanyName": null
      }
    ],
    "stories": null,
    "requestSystem": null,
    "logId": null';
 v_policies VARCHAR2(32767);
 v_ndx1 NUMBER;
 v_ndx2 NUMBER;
 v_pre VARCHAR2(32767);
 v_post VARCHAR2(32767);
 v_ndx NUMBER:=0;
 BEGIN
   
     v_ndx1 := INSTR(v_data,'"policies": [');
     v_ndx2 := INSTR(v_data,'],') - v_ndx1;
     v_policies := SUBSTR(v_data, v_ndx1+11, v_ndx2-10);
     v_data := SUBSTR(v_data, 1, v_ndx1-1);
     FOR rec_1 IN (SELECT COLUMN_VALUE FROM TABLE(CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.convertPayloadToTable(v_data))) LOOP
            v_ndx := 0;
            FOR rec_2 IN (SELECT FIELD_NAME, FIELD_VALUE FROM TABLE(rec_1.COLUMN_VALUE)) LOOP                       
                 IF rec_2.FIELD_NAME = 'partId' THEN
                     v_insured.part_id := rec_2.FIELD_VALUE;
                 END IF;
                 IF rec_2.FIELD_NAME = 'identityNo' THEN
                     v_insured.identity_No := rec_2.FIELD_VALUE;
                 END IF;
                 IF rec_2.FIELD_NAME = 'cardNo' THEN
                     v_insured.card_Info := rec_2.FIELD_VALUE;
                 END IF; 
                 IF rec_2.FIELD_NAME = 'firstName' THEN
                     v_insured.first_name := rec_2.FIELD_VALUE;
                 END IF;         
            END LOOP;               
            DBMS_OUTPUT.put_line(v_insured.first_name);                                           
     END LOOP;
     FOR rec_1 IN (SELECT COLUMN_VALUE FROM TABLE(CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.convertPayloadToTable(v_policies))) LOOP
            v_ndx := 0;
            FOR rec_2 IN (SELECT FIELD_NAME, FIELD_VALUE FROM TABLE(rec_1.COLUMN_VALUE)) LOOP                       
                 IF rec_2.FIELD_NAME = 'policyRef' THEN
                     v_policy.policy_ref := rec_2.FIELD_VALUE;
                 END IF;
                 IF rec_2.FIELD_NAME = 'contractId' THEN
                     v_policy.contract_Id := rec_2.FIELD_VALUE;
                 END IF;
                 IF rec_2.FIELD_NAME = 'partitionType' THEN
                     v_policy.partition_Type := rec_2.FIELD_VALUE;
                 END IF; 
                 IF rec_2.FIELD_NAME = 'partitionNo' THEN
                     v_policy.partition_No := rec_2.FIELD_VALUE;
                 END IF;         
            END LOOP;   
            v_policy_list.EXTEND;    
            v_policy_list(v_policy_list.COUNT) := v_policy;
            DBMS_OUTPUT.put_line(v_policy.Contract_Id);                                           
     END LOOP;
     
     
     
   /*v_ndx1 := INSTR(v_data,'"policies"');
   v_pre :=  SUBSTR(v_data, 1, v_ndx1-1);
   v_post := SUBSTR(v_data, v_ndx1+15);
   v_ndx2 := INSTR(v_post,'"stories"');
   v_policies := TRSUBSTR(v_post,1,v_ndx2-1);*/
   
  -- DBMS_OUTPUT.PUT_LINE(v_data); 
   --v_ndx2 := INSTR(v_data,'],');
 DBMS_OUTPUT.PUT_LINE(v_ndx1 || ':' || v_ndx2);
   ---v_policies := SUBSTR(v_data, v_ndx1+14, 2019);
   --v_data := SUBSTR(v_data, 1, v_ndx1) || SUBSTR(v_data, v_ndx2);
   
   --DBMS_OUTPUT.PUT_LINE(v_policies);  
 
 
 END;
