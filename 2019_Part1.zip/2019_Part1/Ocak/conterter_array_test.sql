DECLARE 
v_ndx NUMBER := 0;
BEGIN 
FOR recList IN (SELECT COLUMN_VALUE FROM TABLE(CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.convertPayloadToTable('[
      {
        "policyRef": "0001071002857742-1",
        "contractId": 367856493,
        "partitionType": "MDSG",
        "partitionNo": 1      
      },
      {
        "policyRef": "0001071002857742-2",
        "contractId: 367856494,
        "partitionType": "TSSF",
        "partitionNo": 2       
      }
    ]'))) LOOP 
    DBMS_OUTPUT.PUT_LINE('Record['||v_ndx||']');
    FOR rec IN (SELECT FIELD_NAME,FIELD_VALUE FROM TABLE(recList.COLUMN_VALUE)) LOOP      
           DBMS_OUTPUT.PUT_LINE(rec.FIELD_NAME || ':'||rec.FIELD_VALUE);
    END LOOP;
    v_ndx := v_ndx + 1;
END LOOP;

END;
