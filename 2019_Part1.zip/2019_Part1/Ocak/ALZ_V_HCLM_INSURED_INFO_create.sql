CREATE OR REPLACE FORCE VIEW "ALZ_V_HCLM_INSURED_INFO" (contract_id, partition_no, partner_version_no, partner_action_code, ip_no, partner_id, type_of_interest, mailing_address_id, partition_version_no, partition_action_code, endorsement_no, term_start_date, term_end_date, sub_company_code, partner_validity_date, partition_type, product_id,contract_status, version_no, group_code, group_period_no, sub_agent, oldsys_policy_no, is_complementary, company_code, old_contract_id, pack_version_no, pack_action_code, package_id, package_date, network_id, package_label, policy_ref, policy_start_date, policy_end_date, agent_role, priority, possible_exiting_date)
AS
select ip_links.contract_id,
           ip_links.partition_no,
           ip_links.version_no partner_version_no,
           ip_links.action_code partner_action_code,
           ip_links.ip_no,
           interested.partner_id,
           ip_links.type_of_interest,
           interested.mailing_address_id,
           par_ext.version_no par_ext_version_no,
           par_ext.action_code partition_action_code,
           ver_ext.endorsement_no,
           par_ext.term_start_date,
           decode(nvl(ver_ext.endorsement_no, 0),
                  14,
                  decode(ver.product_id,
                         63,
                         ver.business_start_date,
                         par_ext.business_start_date),
                  2,
                  decode(ver.product_id,
                         63,
                         ver.business_start_date,
                         par_ext.business_start_date),
                  par_ext.term_end_date) term_end_date,
           par_ext.sub_company_code,
           par_ext.partner_validity_date,
           par.partition_type,
           ver.product_id,
           ver.contract_status,
           ver_ext.version_no,
           ver_ext.group_code,
          ver_ext.period_no group_period_no,
           ver_ext.sub_agent,
           ver_ext.oldsys_policy_no,
           cont_ext.is_complementary,
           cont_ext.company_code,
           cont_ext.old_contract_id,
           pack.version_no pack_version_no,
           pack.action_code pack_action_code,
           pack.package_id,
           pack.package_date,
           pack.network_id,
           pack.package_label,
           bases.policy_ref,
           bases.term_start_date policy_start_date,
           bases.term_end_date policy_end_date,
           bases.agent_role,
      Koc_Clm_Hlth_Utils.Getpolicypriority(ip_links.Contract_Id,
                                            ip_links.Partition_No,
                                            ver_ext.Group_Code) Priority,
       DECODE(ver.Product_Id,
              64,
              (SELECT Possible_Exiting_Date
                 FROM Koc_Clm_Close_To_Indemnity b
                WHERE b.Contract_Id = ip_links.Contract_Id
                  AND b.Partition_No = ip_links.Partition_No
                  AND b.Possible_Exiting_Date IS NOT NULL),
              null) Possible_Exiting_Date
      from ocp_ip_links              ip_links,
           ocp_interested_parties    interested,
           koc_ocp_partitions_ext    par_ext,
           ocp_partitions            par,
           koc_ocp_risk_packages     pack,
           koc_ocp_pol_versions_ext  ver_ext,
           ocp_policy_versions       ver,
           koc_ocp_pol_contracts_ext cont_ext,
           ocp_policy_bases          bases
     where ip_links.contract_id = interested.contract_id
       and ip_links.ip_no = interested.ip_no
       and ip_links.version_no = interested.version_no
      and interested.version_no =
           (select max(iinterested.version_no)
              from ocp_interested_parties iinterested
             where iinterested.contract_id = interested.contract_id
               and iinterested.ip_no = interested.ip_no
               and iinterested.version_no <= ver_ext.version_no
               and iinterested.reversing_version is null)
       and ip_links.partition_no is not null
       and par_ext.contract_id = ip_links.contract_id
       and par_ext.partition_no = ip_links.partition_no
       and cont_ext.contract_id = ver_ext.contract_id
       and ver_ext.contract_id = ip_links.contract_id
       and ver.contract_id = ver_ext.contract_id
       and ver.version_no = ver_ext.version_no
       and par_ext.version_no =
           (select max(a.version_no)
              from koc_ocp_partitions_ext a
             where a.contract_id = par_ext.contract_id
               and a.partition_no = par_ext.partition_no
               and a.version_no <= ver_ext.version_no
               and a.reversing_version is null)
       and par_ext.contract_id = par.contract_id
       and par_ext.partition_no = par.partition_no
       and par_ext.version_no = par.version_no
      and pack.contract_id = par.contract_id
       and pack.partition_no = par.partition_no
       and pack.version_no =
           (select max(a.version_no)
              from koc_ocp_risk_packages a
             where a.contract_id = pack.contract_id
               and a.partition_no = pack.partition_no
               and a.version_no <= par_ext.version_no
               and a.reversing_version is null)
       and not (pack.action_code = 'D' and exists
             (select 1
                   from koc_ocp_risk_packages a
                  where a.contract_id = pack.contract_id
                    and a.partition_no = pack.partition_no
                    and a.version_no = pack.version_no
                    and a.reversing_version is null
                    and a.action_code = 'A'))
       and bases.contract_id = ver_ext.contract_id
       and bases.top_indicator = 'Y'
/       
