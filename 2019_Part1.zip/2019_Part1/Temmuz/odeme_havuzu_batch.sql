BEGIN
alz_acc_payment_utils_load.loadpaymentpool_s316(trunc(sysdate),'PAY');
END;
