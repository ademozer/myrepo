update cp_partners 
   set telephone = '2322425193'
 where part_id=80057965
/
COMMIT
/
