DECLARE

v_1 VARCHAR2(100);
v_Exemption_Over_Amount NUMBER := 20;
FUNCTION numberToString(p_number IN NUMBER) RETURN VARCHAR2 IS
        v_string VARCHAR2(100);
    BEGIN
        v_string := REPLACE(TO_CHAR(p_number),',','.');
        IF INSTR(v_string,'.') = 1 THEN
           v_string := '0'||v_string;
        END IF;
        RETURN v_string;
    END numberToString;
/*FUNCTION numberToString2(p_number IN NUMBER) RETURN VARCHAR2 IS
        v_string VARCHAR2(100);
    BEGIN
        IF p_number IS NULL THEN
          RETURN '';
        END IF;
        v_string := REPLACE(TO_CHAR(p_number),',','.');
        IF INSTR(v_string,'.') = 1 THEN
           v_string := '0'||v_string;
        END IF;
        RETURN v_string;
    END numberToString2;*/
BEGIN
 
v_1 := '"exemptionOverAmount" : "'||numberToString(v_Exemption_Over_Amount)||'"';

DBMS_OUTPUT.PUT_LINE(v_1);
v_Exemption_Over_Amount := NULL;
v_1 := '"exemptionOverAmount" : "'||numberToString(NULL)||'"';
DBMS_OUTPUT.PUT_LINE(v_1);
END;

--SELECT TO_CHAR(NULL) FROM DUAL
