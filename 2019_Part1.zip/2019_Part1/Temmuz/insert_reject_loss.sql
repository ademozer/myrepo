insert into koc_clm_hlth_reject_loss (CLAIM_ID, SF_NO, LOCATION_CODE, ADD_ORDER_NO, COVER_CODE, PROCESS_CODE_MAIN, PROCESS_CODE_SUB1, PROCESS_CODE_SUB2, MAIN_CODE, ITEM_CODE, SUB_ITEM_CODE, REFUSE_EXPLANATION, REFUSE_AMOUNT, USERID, ENTRY_DATE, BARCODE, TIME_STAMP, SEQ_NO, IS_BRE_DECISION, UBB_CODE)
values (41570466, 1, 0, 1, '0', 0, 0, 0, '13', '15', '11', '�riner sistem ta�lar� tedavisi i�in istisna mevcuttur', null, 'MEDISER157', null, 0, to_date('04-07-2019 15:04:08', 'dd-mm-yyyy hh24:mi:ss'), 1, '0', '0')
/
COMMIT
/

