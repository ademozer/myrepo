DECLARE
p_ext_reference VARCHAR2(100) := '57938308';--;'57938304';--'57562819';--'57938304';
procedure loadpaymentpool_s316(p_payment_date date, p_mode varchar2) is
    /* Grup tazminat*/
    v_data_date date := p_payment_date;
    cursor c316 is
      select --GROUP_CODE,grup_baslik,product_id,policy_ref,SIGortali_NO,
       org_payment_code,
       ext_reference,
       claim_id,
       sf_no,
       SIGORTALI_ADI_SOYADI,
       alici_adi_soyadi,
       'TL' currency_code,
       creditor_bank,
       creditor_subsidiary,
       account_no,
       --correspondent_bank, correspondent_subsidiary,
       --correspondent_account_code,
       --correspondent_iban_code,
       iban_code,
       tckn_vkn,
       partner_type,
       identity_no,
       tax_number,
       contract_id,
       ip_no,
       tutar,
       policy_ref
        from (select
              --e.GROUP_CODE,
              --decode(e.GROUP_CODE,null,null,c.policy_ref ||' No.lu Poli�e Toplami : ') grup_baslik,
              --c.product_id,
              --c.policy_ref,
              --d.oar_no SIGortali_NO,
               alz_acc_payment_utils_load.safetonumber(max(a.sf_total_type)) org_payment_code,
               e.ext_reference,
               b.claim_id,
               b.sf_no,
               nvl(substr(koc_clm_hlth_utils.getpartnernamebypartid(e.part_id),1,30),chr(32)) SIGORTALI_ADI_SOYADI,
               nvl(b.creditor_name, chr(32)) alici_adi_soyadi,
               'TL' currency_code,
               b.creditor_bank,
               b.creditor_subsidiary,
               b.account_no,
               b.iban_code,
               --b.correspondent_bank,
               --b.correspondent_subsidiary,
               --b.correspondent_account_code,
               --b.correspondent_iban_code,
               decode(k.partner_type, 'I', f.identity_no, 'P', f.tax_number) tckn_vkn,
               k.partner_type,
               f.identity_no,
               f.tax_number,
               c.contract_id,
               a.ip_no,
               sum(decode(a.sf_total_type, 11, 1, 12, -1, null) *
                   a.trans_amt * nvl(b.currency_exchange_rate, 1)) tutar,
                   c.policy_ref
                from clm_trans a,
                     koc_clm_trans_ext b,
                     clm_pol_bases c,
                     clm_pol_oar d,
                     koc_clm_hlth_detail e,
                     cp_partners k,
                     koc_cp_partners_ext f
               where a.claim_id = b.claim_id
                 and a.sf_no = b.sf_no
                 and a.trans_no = b.trans_no
                 and a.claim_id = c.claim_id
                 and a.claim_id = d.claim_id
                 and a.claim_id = e.claim_id
                 and b.claim_id = e.claim_id
                 and b.sf_no = e.sf_no
                 and b.add_order_no = e.add_order_no
                 AND e.ext_reference = p_ext_reference
                 and k.part_id = f.part_id
                 and k.part_id = e.part_id
                 and b.technical_approved_date is not null
                 and b.transfer_bank_date is null
                 and b.payment_approved_date = TRUNC(SYSDATE)
                 and b.ticket_date is null
                 and b.hsap is null /*g�vence hesab� �demeleri manuel yap�laca��ndan otomatik aktar�m engelleniyor*/
                 and b.payment_type = 5
                 and a.sf_total_type in (11)
                 and nvl(b.is_account_approved, 0) != 1
                 and a.trans_no in
                     (select max(x.trans_no)
                        from koc_clm_trans_ext x, clm_trans y
                       where x.claim_id = y.claim_id
                         and x.sf_no = y.sf_no
                         and y.trans_no = y.trans_no
                         and x.claim_id = b.claim_id
                         and x.sf_no = b.sf_no
                         and x.add_order_no = b.add_order_no
                         and x.hlth_cover_code = b.hlth_cover_code
                         and y.sf_total_type in (11, 12))
               group by e.group_code,
                        c.product_id,
                        c.policy_ref,
                        e.ext_reference,
                        b.claim_id,
                        b.sf_no,
                        d.oar_no,
                        e.part_id,
                        b.creditor_name,
                        b.creditor_bank,
                        b.creditor_subsidiary,
                        b.account_no,
                        b.correspondent_bank,
                        b.correspondent_subsidiary,
                        b.correspondent_account_code,
                        b.correspondent_iban_code,
                        decode(k.partner_type,
                               'I',
                               f.identity_no,
                               'P',
                               f.tax_number),
                        k.partner_type,
                        f.identity_no,
                        f.tax_number,
                        b.iban_code,
                        c.contract_id,
                        a.ip_no) xx;
    --order by 1,2,3,decode(xx.product_id,63,6,64,4),6 ;

    v_c316_row c316%rowtype;

    v_bankaccount alz_acc_payment_bank_account%rowtype;
    v_payment     alz_acc_payment_pool%rowtype;
    v_payment_id  varchar2(14);
    v_status       varchar2(5);
    v_error        varchar2(2000);
    v_poolstatus ALZ_ACC_PAYMENT_POOL.STATUS%TYPE;
    v_owner_name  varchar2(100);
    v_payment_order_num  number;

    cursor c_bank_history(p_contract_id number,p_ip_no number)is
    select a.iban_code,
           a.acc_owner_partid,
           a.identity_no,
           a.bank_code,
           a.subsidiary_code
      FROM koc_acc_bank_history a
     WHERE a.contract_id = p_contract_id
       AND a.ip_no = p_ip_no
       AND (a.validity_end_date is null or trunc (a.validity_end_date) > trunc (sysdate));

    v_identity_no varchar2(20);
    v_sgk_srv_IBAN_CODE varchar2(34);
    v_iban_code varchar2(40);
    v_acc_owner_partid number;
    v_bank_code number;
    v_subsidiary_code number;
  begin
    if p_mode = 'PAY' then
       v_poolstatus := '05';
    elsif p_mode = 'INFO' then
       v_poolstatus := '14';
    else
       dbms_output.put_line('INVALID RUN MODE');
       raise PROGRAM_ERROR;
    end if;
    v_data_date                 := alz_acc_payment_utils_load.addworkdays(p_payment_date, -1);
    --v_payment.payment_order_num := getdailysequence(p_payment_date);

     
   -- FOR rec IN c316 LOOP 
    open c316;
    loop
      fetch c316
        into
        
         v_payment.org_payment_code,
             v_payment.ext_reference,
             v_payment.claim_id,
             v_payment.sf_no,
             v_owner_name,
             v_payment.receiving_name_surname,
             v_payment.swift_code,
             v_payment.receiving_bank_code,
             v_payment.receiving_subsidiary_code,
             v_payment.receiving_account_no,
             v_payment.receiving_iban,
             v_payment.receiving_tckn_ykn_vkn,
             v_c316_row.partner_type,
             v_c316_row.identity_no,
             v_c316_row.tax_number,
             v_payment.contract_id,
             v_c316_row.ip_no,
             v_payment.payment_amount,
             v_payment.policy_ref;
      --v_payment.receiving_tckn_ykn_vkn,
      --v_payment.payment_amount,
      --v_payment.creating_userid;
        dbms_output.put_line('1');
        dbms_output.put_line('desc='||v_payment.ext_reference);
        
      exit when c316%notfound;
      
      BEGIN
          SELECT IBAN_CODE INTO v_sgk_srv_IBAN_CODE FROM koc_acc_bank_history WHERE contract_id IN (1, 2) AND VALIDITY_END_DATE  IS NULL AND IBAN_CODE = v_payment.receiving_iban;-- sgk.srv �deme
      EXCEPTION
      WHEN OTHERS THEN
          v_sgk_srv_IBAN_CODE := NULL;
      END;
      
      dbms_output.put_line('receiving_iban1='||v_payment.receiving_iban||' v_sgk_srv_iban_code='||v_sgk_srv_IBAN_CODE);
      --v_payment.payment_order_num := v_payment.payment_order_num + 1;
      --v_payment.claim_id          := null;
      --v_payment.sf_no             := null;
      --v_payment.ext_reference     := null;
      v_payment.description_text := v_payment.ext_reference||' '||v_owner_name||' '||v_payment.policy_ref;
      dbms_output.put_line('desc='||v_payment.description_text);
      v_iban_code := NULL;
      v_acc_owner_partid := null;
      v_identity_no := null;
      v_bank_code := null;
      v_subsidiary_code := null;

      open c_bank_history(v_payment.contract_id,v_c316_row.ip_no);
        fetch c_bank_history
        into v_iban_code, v_acc_owner_partid, v_identity_no, v_bank_code, v_subsidiary_code;
        close c_bank_history;

        if( v_c316_row.partner_type = 'I')then
            v_identity_no :=  v_c316_row.tax_number;
            v_iban_code   := v_payment.receiving_iban;
        end if;

        -- sgk.srv �deme
        if v_sgk_srv_IBAN_CODE IS NOT NULL 
        AND v_sgk_srv_IBAN_CODE = v_payment.receiving_iban then
          v_identity_no := null;
          v_iban_code   := v_payment.receiving_iban;
        end if;


        v_payment.receiving_iban := v_iban_code;

        if v_iban_code is null then
            v_payment.receiving_bank_code := v_bank_code;
            v_payment.receiving_subsidiary_code := v_subsidiary_code;
        else
            v_payment.receiving_account_no := null;
            v_payment.receiving_bank_code := null;
            v_payment.receiving_subsidiary_code := null;
        end if;

        v_payment.receiving_tckn_ykn_vkn := v_identity_no;

      if p_mode = 'PAY' then
          update koc_clm_trans_ext b
             set transfer_bank_date = v_data_date
           where b.claim_id = v_payment.claim_id
             and b.sf_no = v_payment.sf_no
             and b.technical_approved_date is not null
             and b.transfer_bank_date is null
             and b.payment_approved_date = v_data_date
             and b.ticket_date is null
             and b.payment_type = 5
             and nvl(b.is_account_approved, 0) != 1
          /*
          and (
               (b.correspondent_bank = p_bank_code and p_bank_code=67 and p_transfer_type = 'HAVALE' and  b.creditor_bank = b.correspondent_bank)
               or
               (b.correspondent_bank = p_bank_code and p_bank_code=67 and p_transfer_type = 'EFT' and  b.creditor_bank != b.correspondent_bank)
               or
               (b.correspondent_bank = p_bank_code and p_bank_code=46 and p_transfer_type = 'HAVALE' and  b.creditor_bank = b.correspondent_bank)
               or
               (b.correspondent_bank = 64 and p_bank_code=67 and p_transfer_type = 'EFT' and b.creditor_bank = b.correspondent_bank)
              )*/
          ;
       end if;

      v_payment.request_date := p_payment_date;

         v_payment.branch_code := 2;
         v_payment.payment_date := p_payment_date;
         v_payment.status := v_poolstatus;
         v_payment.source_code := 'KOCCLM316';
         v_payment.department_code := 'STHS';
         v_payment.payment_code := 03;
         v_payment.creating_program_name := 'PPLOAD';
         v_payment.creating_userid := 'AUTO';

      alz_acc_payment_utils_load.alignandinsertrow2(
                        v_payment,
                        v_payment_id,
                        v_payment_order_num,
                        v_status,
                        v_error);
      if v_status is not null then
         ROLLBACK;
        dbms_output.put_line(v_error);
        raise PROGRAM_ERROR;
      end if;
      dbms_output.put_line('iban_code='||v_payment.receiving_iban);
    end loop;
    commit;
  end loadpaymentpool_s316;
  
  BEGIN
    loadpaymentpool_s316(TRUNC(SYSDATE),'PAY');
  END;
