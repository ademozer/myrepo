SELECT *
        FROM Koc_Clm_Hlth_Indem_Totals a
       WHERE Contract_Id = 443156417
         AND Partition_No = 754
         AND Claim_Inst_Type = 'AHK'
         AND Claim_Inst_Loc = 'YI'
        AND Package_Id = 260758
        -- AND Package_Date = p_Package_Date
         --AND Country_Group = Nvl(p_Country_Group, 0)
         AND a.Cover_Code = 'S511'
             --Decode(p_Cover_Code, NULL, a.Cover_Code, 'S511')
         AND a.Is_Pool_Cover = 0
        /* AND a.Is_Pool_Cover =
             Decode(Nvl(p_Is_Pool_Cover, 0),
                    3,
                    Nvl(a.Is_Pool_Cover, 0),
                    Nvl(p_Is_Pool_Cover, 0))
         AND a.Is_Special_Cover =
             Decode(Nvl(p_Is_Special_Cover, 0),
                    3,
                    Nvl(a.Is_Special_Cover, 0),
                    Nvl(p_Is_Special_Cover, 0))*/
         AND Nvl(a.Is_Valid, 0) = 1
         AND a.Validity_Start_Date =
             (SELECT MAX(Aa.Validity_Start_Date)
                FROM Koc_Clm_Hlth_Indem_Totals Aa
               WHERE Aa.Contract_Id = a.Contract_Id
                 AND Aa.Partition_No = a.Partition_No
                 AND Aa.Claim_Inst_Type = a.Claim_Inst_Type
                 AND Aa.Claim_Inst_Loc = a.Claim_Inst_Loc
                 AND Aa.Country_Group = a.Country_Group
                 AND Aa.Cover_Code = a.Cover_Code
                 AND Aa.Is_Special_Cover = a.Is_Special_Cover
                 AND Aa.Is_Pool_Cover = a.Is_Pool_Cover
                 AND Aa.Package_Date = a.Package_Date
                 AND Aa.Package_Id = a.Package_Id
                 AND Nvl(Aa.Is_Valid, 0) = 1
                -- AND Aa.Validity_Start_Date <= p_Date
                )
                
                select * from koc_clm_hlth_detail where ext_reference='57183512'
                
                select * from koc_ocp_risk_packages where contract_id=443156417 and partition_no=754
                
                select * from koc_oc_hlth_doc_contents where paragraf2 like '%i� orta��%'
                
                select * from koc_clm_hlth_detail where ext_reference='57665794'
                
                select   ALZ_TPA_CLAIM_UTILS.GET_TPA_RCI_COMPANY_ID(41339206) from dual
                
         SELECT   * --a.trading_partner_code
           FROM   koc_rci_companies_ext a
          WHERE   a.rci_company_id = pc_rci_company_id;
                
                update koc_oc_hlth_doc_proc_ref 
                   set paragraph_1 = '�irketimiz, Grup Sa�l�k Sigorta Poli�esi �zel �artlar� ve Grup Protokolleri gere�ince, Risk De�erlendirmesi yapmaktad�r. Bu de�erlendirme sonucunda mevcut hastal���n riskine g�re hastal�k istisnas�/ hastal�k ek primi(s�rprimi) uygulanmas� veya ba�vurunun kabul edilmemesi se�eneklerine g�re karar verilmektedir.'
                 where paragraph_1='�irketimiz, Grup Sa�l�k Sigorta Poli�esi �zel �artlar� ve Grup Protokolleri gere�ince, Risk De�erlendirmesi yapmaktador. Bu de�erlendirme sonucunda mevcut hastal���n riskine g�re hastal�k istisnas�/ hastal�k ek primi(s�rprimi) uygulanmas� veya ba�vurunun kabul edilmemesi se�eneklerine g�re karar verilmektedir.'
                
                
