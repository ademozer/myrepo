select rowid,a.* from wip_policy_versions a where contract_id = 472065389;
select * from ocp_policy_bases where contract_id = 472065389
select * from ocq_policy_bases where contract_id = 472065389;
select * from clm_subfiles where ext_reference='57183512'
select * from clm_pol_oar where claim_id=41144603
select * from koc_clm_hlth_detail where ext_reference IN('57183512','57513674') for update
select * from koc_ocp_risk_packages where contract_id=443156417 and partition_no=1175

260757
260758

UPDATE wip_policy_versions
   SET MOVE_CODE = 'GHGAQ',
       MOVEMENT_REASON_CODE = 'GHGAQ'
WHERE contract_id = 443204581


UPDATE koc_clm_hlth_detail
   SET package_id = 260758
 WHERE ext_reference = '57513674';
 
 
select * from  MDLR_GHLTH_SEARC_SQL_LOG  order by log_date desc
