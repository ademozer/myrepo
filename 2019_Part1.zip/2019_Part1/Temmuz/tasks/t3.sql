select * from pme_errors where contract_id = 443204581 order by timestamp desc;

select * from inf_gam_err_logs where origin_id = '443204581' order by timestamp

	Select A.Group_Code , A.period_no
		--	  into v_group_Code ,v_period_no
			  From Wip_Koc_Ocp_Pol_Versions_Ext A
			 Where A.Contract_Id = '443204581';
       
       --S9227 - 5
       
        pme_w_pol.wip_continue;
        
        pme_public.wip_continue;
        
        select * from koc_ocp_health a where a.contract_id = 443204581 and top_indicator = 'Y'
            AND action_code <> 'D' and a.partition_no not in (select b.partition_no from ocp_partitions b where b.contract_id = a.contract_id AND top_indicator = 'Y'
            AND action_code <> 'D');

       
SELECT ALZ_GHLTH_GROUP_UTILS.group_has_changed('S9227', 5)  FROM DUAL      
       
select * from ocp_policy_bases where policy_ref = '0001171006128183'
443204581
443204581;

 PME_UTILS.Validate_and_Authorise;
 CUST_PARTNER_UTILS.add_partner_role;
 
 select * from all_source where text like '%Ge�ersiz Ortak No.%'
 
 select * from koc_cp_partners_Ext where part_id=80090989
