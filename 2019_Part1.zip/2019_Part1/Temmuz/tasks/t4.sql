select * from koc_clm_hlth_indem_totals where contract_id=442806538 and partition_no IN(3464,4653) and exemption_group=1;

SELECT * FROM cfg_v_oc_products_api 

select * from cur_translations where desc_int_id=166229;

SELECT *
	 -- INTO v_aski_user
    FROM inf_v_lck_logical_locks_api l
   WHERE l.object_uid = '434415571'--TO_CHAR(p_contract_id)
   --  AND l.object_type_code = 'POLICY'
     AND l.status = 'A'
    -- AND gios_username <> USER;
    
    
    select * from 
    
    
    --update 
    koc_ocp_health 
       --set
      --  action_code = 'D'
     where contract_id = 434415571 
       and partition_no = 500
       and version_no = 15
       
       
       
