           SELECT dtl.claim_id,
                  cpb.contract_id,
                  cpo.oar_no partition_no,
                  dtl.add_order_no,
                  dtl.sf_no,
                  dtl.group_code,
                  cpb.product_id,
                  --                 prv.location_code,
                  NVL (
                     DECODE (
                        cpb.product_id,
                        64, (SELECT gm.description
                               FROM koc_cp_group_master gm   --05.06.2017: 794
                              WHERE     TRUNC (SYSDATE) BETWEEN gm.policy_start_date
                                                            AND NVL (
                                                                   gm.policy_end_date,
                                                                   SYSDATE + 1)
                                    AND dtl.group_code = gm.group_code
                                    AND rownum<2),
                        63, NULL,
                        NULL),
                     '-')
                     grup_adi,
                  TO_CHAR (cpb.policy_ref,
                           '0000g0000g0000g0000',
                           'nls_numeric_characters=.-')
                     policy_ref,
                  koh.family_code aile_kodu,
                  cpo.oar_no sira_no,
                  koh.comp_reg_code sicil_no,
                  dtl.claim_inst_type,
                  dtl.claim_inst_loc,
                  dtl.package_id,
                  dtl.package_date,
                  NULL cover_code,
                  (SELECT h.title
                     FROM koc_dmt_v_current_agents h
                    WHERE     h.agen_int_id = cpb.agent_role
                          AND TRUNC (SYSDATE) BETWEEN h.start_date
                                                  AND NVL (h.end_date,
                                                           TRUNC (SYSDATE))) --partaj
                     partaj,
                  cr.cancel_reason_code,
                  (SELECT reference_code
                     FROM dmt_agents dm, koc_v_policy_agent p          --agent
                    WHERE     dm.int_id = p.sub_agent
                          AND p.contract_id = cpb.contract_id)
                     ekip_kodu,
                  (SELECT first_name || ' ' || surname
                     FROM cp_partners zz
                    WHERE zz.part_id = dtl.part_id)
                     ad_soyad,
                  TO_CHAR (cr.approve_date, 'dd.mm.yyyy') ilk_onay_tarihi,
                  cr.payment_approve_cancel_date iptal_onay_tarihi,
                  (SELECT long_name
                     FROM koc_cp_health_look_up lk, cur_translations cur
                    WHERE     lk.look_up_code = 'CANREASCOD'
                          AND lk.desc_int_id = cur.desc_int_id
                          AND cur.sula_ora_nls_code = 'TR'
                          AND lk.parameter = cr.cancel_reason_code)
                     iptal_neden_kodu_aciklama,
                  (SELECT MAX (e.payment_approved_date)
                     FROM koc_clm_trans_ext e
                    WHERE     e.claim_id = dtl.claim_id
                          AND e.sf_no = dtl.sf_no
                          AND e.add_order_no = dtl.add_order_no
                          AND e.realization_ticket_date IS NOT NULL
                          AND e.payment_approved_date IS NOT NULL)
                     ikinci_onay_tarihi,
                  dtl.ext_reference hasar_no,
                  Customer.Clmr_String_Agg (
                     koc_clm_hlth_utils.getlookupparamdesc (
                        'INDABDOC',
                        icp.ABSENT_DOC_CODE,
                        icp.entry_date))
                     istenen_evraklar,
                  dtl.cpa_status,
                  decode (dtl.status_code,'R','RET',dtl.status_code) status_code,
                  --                 koc_clm_hlth_utils.getcoverdef (prv.cover_code) cover_name,
                  dtl.invoice_total fatura_tutar,
                  (SELECT MAX (process_date)
                     FROM alz_hlth_cpa_detail_history a
                    WHERE     a.claim_id = dtl.claim_id
                          AND a.cpa_status = dtl.cpa_status)
                     islem_tarihi,
                  TO_CHAR (dtl.comm_date, 'dd.mm.yyyy hh24:mi:ss')
                     belge_giris_tarihi,
                  (SELECT l.detail_explanation
                     FROM koc_cp_health_look_up l
                    WHERE     l.look_up_code = 'CPA_STAT'
                          AND l.validity_start <= TRUNC (SYSDATE)
                          AND l.validity_end IS NULL
                          AND l.parameter NOT IN ('HS', 'HM', 'UR')
                          AND l.parameter = dtl.status_code)
                     karar_kodu,
                  NULL tutar,
                  NULL ret_nedenleri,
                  NULL kismi_ret,
                  (SELECT DECODE (acc.iban_code,
                                  NULL, account_no,
                                  acc.iban_code)
                             accn
                     FROM ocp_ip_links l,
                          ocp_interested_parties i,
                          koc_acc_bank_history acc
                    WHERE     i.contract_id = l.contract_id
                          AND i.ip_no = l.ip_no
                          AND i.contract_id = acc.contract_id
                          AND i.ip_no = acc.ip_no
                          AND l.role_type = 'INS'
                          AND l.top_indicator = 'Y'
                          AND l.action_code <> 'D'
                          AND i.partner_id = dtl.part_id
                          AND i.contract_id = CPB.CONTRACT_ID
                          AND l.version_no = i.version_no
                          AND acc.validity_end_date IS NULL
                          --                         AND DECODE (account_no, NULL, iban_code) IS NOT NULL
                          AND ROWNUM < 2)
                     hesap_no,
                  dtl.invoice_no fatura_no,
                  TO_CHAR (dtl.invoice_date, 'dd.mm.yyyy') fatura_tarihi,
                  customer.clmr_string_agg (icp.explanation) aciklama,
                  koc_clm_hlth_utils.getinstitutnamebycode (dtl.institute_code,
                                                            TRUNC (SYSDATE))
                     kurum_adi,
                  'SONRADAN �DEME' saglik_odeme_servisi,
                  CASE
                     WHEN cpb.product_id = 64
                     THEN
                        NVL (
                           (SELECT kcc.explanation ins_email
                              FROM customer.koc_cp_comm_devices kcc
                             WHERE     kcc.part_id = dtl.part_id
                                   AND kcc.comm_dev_type = '0090'
                                   AND kcc.validity_end_date IS NULL
                                   AND kcc.explanation IS NOT NULL
                                   AND EXISTS
                                          (SELECT 1
                                             FROM koc_cp_comm_dev_type_ref b1
                                            WHERE     b1.comm_dev_type =
                                                         kcc.comm_dev_type
                                                  AND NVL (format, 'A') <>
                                                         '9999 999 99 99')
                                   AND ROWNUM < 2),
                           '64')
                     WHEN cpb.product_id = 63
                     THEN
                        NVL (
                           (SELECT kcc.explanation ins_email
                              FROM customer.koc_cp_comm_devices kcc
                             WHERE     kcc.part_id = dtl.part_id
                                   AND kcc.comm_dev_type = '0090'
                                   AND kcc.validity_end_date IS NULL
                                   AND kcc.explanation IS NOT NULL
                                   AND EXISTS
                                          (SELECT 1
                                             FROM koc_cp_comm_dev_type_ref b1
                                            WHERE     b1.comm_dev_type =
                                                         kcc.comm_dev_type
                                                  AND NVL (format, 'A') <>
                                                         '9999 999 99 99')
                                   AND ROWNUM < 2),
                           '63'
                           --v_health_document_mail
                           )
                  END
                     ins_email,
                  DECODE (cpb.product_id,
                          63, 'bireyseltazminat@allianz.com.tr',
                          64, 'kurumsaltazminat@allianz.com.tr')
                     --v_health_document_mail
                     allianz_address,
                  cr.explanation cancel_reas,
                  dtl.part_id
             FROM koc_clm_hlth_detail dtl,
                  --                 koc_clm_hlth_provisions prv,
                  clm_pol_bases cpb,
                  clm_pol_oar cpo,
                  koc_ocp_health koh,
                  koc_clm_ind_app_canc_reas cr,
                  koc_clm_hlth_incomp_papers icp          -- mistaken document
            WHERE 1=1
                  --AND comm_date BETWEEN Pc_start_date AND Pc_end_date -- process_date olabilir
                --  AND dtl.process_date BETWEEN &Pc_start_date AND &Pc_end_date --comm_date ilk kay�tta doluyor daha sonra de�i�ikli�e u�ram�yor.
                  AND dtl.provision_date IS NULL
                  AND dtl.claim_id = cpb.claim_id
                  AND dtl.claim_id = cpo.claim_id
                  AND cpb.contract_id = koh.contract_id
                  AND cpb.version_no = koh.version_no
                  AND cpo.oar_no = koh.partition_no
                  AND dtl.claim_id = cr.claim_id(+)
                  AND dtl.sf_no = cr.sf_no(+)
                  AND dtl.add_order_no = cr.add_order_no(+)
                  AND dtl.invoice_no = cr.invoice_no(+)
                  AND dtl.claim_id = icp.claim_id(+)
                  AND dtl.sf_no = icp.sf_no(+)
                  AND dtl.add_order_no = icp.add_order_no(+)
                  AND icp.status_code(+) = 'A'
                  AND dtl.claim_id = NVL (null, dtl.claim_id)
                  AND cpb.policy_ref='0001071003272369'
                  AND NOT EXISTS
                             (SELECT *
                                FROM alz_hlth_clm_cust_inform_mail a
                               WHERE     a.claim_id = dtl.claim_id
                                     AND a.add_order_no = dtl.add_order_no
                                     AND a.sf_no = dtl.sf_no
                                     AND a.status_code = dtl.status_code
                                     AND a.err_msg is null )
         GROUP BY dtl.claim_id,
                  cpb.contract_id,
                  dtl.add_order_no,
                  dtl.sf_no,
                  cpb.product_id,
                  --                 prv.location_code,
                  dtl.group_code,
                  TO_CHAR (cpb.policy_ref,
                           '0000g0000g0000g0000',
                           'nls_numeric_characters=.-'),
                  koh.family_code,
                  cpo.oar_no,
                  koh.comp_reg_code,
                  dtl.claim_inst_type,
                  dtl.claim_inst_loc,
                  dtl.package_id,
                  dtl.package_date,
                  dtl.part_id,
                  --                 prv.sub_package_id,
                  --                 prv.sub_package_date,
                  --                 prv.cover_code,
                  dtl.ext_reference,
                  dtl.cpa_status,
                  cpb.agent_role,
                  dtl.status_code,
                  decode (dtl.status_code,'R','RET',dtl.status_code),
                  --                 koc_clm_hlth_utils.getcoverdef (prv.cover_code),
                  TO_CHAR (dtl.comm_date, 'dd.mm.yyyy hh24:mi:ss'),
                  --                 '%' || (1 - prv.exemption_rate) * 100,
                  --                 prv.provision_total,
                  dtl.part_id,
                  dtl.invoice_no,
                  TO_CHAR (dtl.invoice_date, 'dd.mm.yyyy'),
                  koc_clm_hlth_utils.getinstitutnamebycode (
                     dtl.institute_code,
                     TRUNC (SYSDATE)),
                  DECODE (cpb.product_id,
                          63, 'bireyseltazminat@allianz.com.tr',
                          64, 'kurumsaltazminat@allianz.com.tr'),
                  --v_health_document_mail,
                  TO_CHAR (cr.approve_date, 'dd.mm.yyyy'),
                  cr.payment_approve_cancel_date,
                  cr.cancel_reason_code,
                  icp.entry_date,
                  cr.explanation,
                  cpo.oar_no,
                  dtl.invoice_total;
