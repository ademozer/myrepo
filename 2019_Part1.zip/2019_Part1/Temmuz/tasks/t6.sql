select * from koc_clm_hlth_detail where ext_reference = '57604308'  for update; --'57034674' for update;
select * from koc_clm_trans_ext where claim_id=40508239
select * from koc_clm_hlth_provisions where claim_id= 40182702

select * from alz_hclm_version_info where claim_id=40182702--40182607--40182555

select * from alz_hclm_institute_info for update

select * from alz_hltprv_log where log_id = 118814348;

koc_clm_hlth_trnx;

SELECT * FROM alz_hltprv_log where log_date>TRUNC(sysdate) and insurednotype='EXT_REFERENCE'


84427171;

select * from koc_clm_hlth_detail where ext_reference = '57604308'

select * from ocp_policy_bases where contract_id IN(443086403,356574503)
select * from ocp_policy_versions where contract_id IN(443086403,356574503)
 --policy_ref='0001171006128059';
select * from koc_ocp_health where contract_id IN(443086403,356574503) 
and family_name='MUTLU AL'

update koc_ocp_health
   set family_code = 20971
 where contract_id = 443086403
   and partition_no = 24605

select t.*,rowid from alz_ghlth_related_info t where t.identity_no= 14255438372;

20783,24605
14255438372

select * from ocp_interested_parties where contract_id IN(356574503,443086403) and partner_id=88846012
select * from ocp_policy_versions where contract_id IN(443086403,356574503) and version_no=87
select * from koc_ocp_pol_versions_ext where contract_id IN(443086403,356574503) and version_no=193
select t.*,rowid from koc_v_endorsement t where t.endorsement_no=1

   SELECT Bank_Code, Subsidiary_Code, Account_No, Account_Owner, Iban_Code                     
     FROM Koc_Acc_Bank_History
    WHERE Contract_Id = 2
      AND Validity_End_Date IS NULL;

select * from koc_ocp_health where contract_id=402169228

select * from koc_ocp_pol_contracts_ext  where contract_id=402169228

select * from ocp_policy_versions where contract_id=402169228

select * from koc_ocp_risk_packages where contract_id=402169228

select * from ocp_interested_parties where contract_id=402169228;

select * from all_tables where table_name like '%ADDRESS%'

select * from cp_addresses where add_id=56560117


SELECT *
                              FROM customer.koc_cp_comm_devices
                             WHERE     part_id IN(84427171,78833290)
                                   AND kcc.comm_dev_type = '0090'
                                   AND kcc.validity_end_date IS NULL
                                   AND kcc.explanation IS NOT NULL
                                   
                                   
select * from customer.alz_duplicate_provision where ext_reference='54550420'--'55885313' ;
select * from alz_hltprv_log where log_id=92939857--107911209--107911218        
select * from koc_clm_hlth_detail where ext_reference='54728439' ;    
select * from koc_clm_hlth_provisions where claim_id=37355078;



select nvl(max(family_code),0) + 1
                from (select family_code
                from wip_koc_ocp_health
                where contract_id = 443086403
                union all
                select family_code
                from koc_ocp_health
                where contract_id = 443086403
                union all
                SELECT a.family_code  FROM ocq_koc_ocp_health a, ocq_quotes b
          where a.quote_ID= b.quote_ID
          and b.contract_id= 443086403); 
                    
          
          
              select *--family_code
                from wip_koc_ocp_health
               where old_policy_contract_id = 356574503             
                 and partition_no = 24605
                 
                 
                 select t.family_code,t.*,rowid from koc_excel_transfer t where t.contract_id=356574503 and surname='AL'--443086403
                
