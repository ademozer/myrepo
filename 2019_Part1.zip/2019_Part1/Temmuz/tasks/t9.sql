select * from alz_hlth_clm_cust_inform_mail where claim_id = 41147272;
select * from koc_clm_hlth_detail where ext_reference = '57515321'
select * from clm_pol_bases where claim_id = 41147272;
select * from clm_pol_oar 
select * from koc_sms_list where gsm_no=--claim_id =  41147272;

0001071003272369

select * from koc_cp_partners_ext where part_id in(84427171,78833290)

select * from cp_partners where part_id in(84427171,78833290)


select * from koc_dmt_agents_title_ext where  title like '%�ENTOP%'

select * from koc_dmt_agents_ext where int_id=12169

SELECT *
  FROM Koc_Cp_Comm_Devices  where part_id in(84427171,78833290)
