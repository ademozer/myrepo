Poli�e no: 0001 1710 0612 7432 - 0001 1710 0612 7432 poli�ede KAAN ERDAL isimli ki�inin ba�vurusu poli�ele�tirilmek istenmektedir fakat bekleyenler alan�nda ki�inin bilgileri 
gelmemekte - opus grup sa�l�k  00:03:59
Description   
Merhaba,
0001 1710 0612 7432 poli�ede KAAN ERDAL isimli ki�inin ba�vurusu poli�ele�tirilmek istenmektedir fakat bekleyenler alan�nda ki�inin bilgileri gelmemektedir. 
�� takip ekran�nda haz�r ba�vuru- teklif poli�ele�ebilir olarak g�r�lmekte ama poli�ede gelmedi�i i�in zeyili yap�lamamaktad�r. 
Ekran g�r�nt�s� ektedir. Bu durumda olan ba�ka ki�ilerde vard�r. 
Poli�e ask�s�nda gelmeyen ki�ilerin poli�ede g�r�lebilir olarak sistemde d�zeltme yap�lmas�n� rica ederiz.

SELECt contract_id from ocp_policy_bases where policy_ref = '0001171006127432'

SELECT * FROM koc_cp_partners_ext where identity_no = '46072365340'

select * from ocp_interested_parties where partner_id = 112097992 and contract_id = 401809071

select * from wip_interested_parties where partner_id = 112097992 and contract_id = 401809071

select * from ocq_interested_parties where partner_id = 112097992 and contract_id = 401809071

86753499
1169 -- ip_no

select * from ocq_ip_links where quote_id = 86753499 and ip_no = 1169

1168 -- partition_no

select * from ocq_koc_ocp_partitions_ext where quote_id = 86753499 and partition_no = 1168


select * from koc_hpf_trans where contract_id = 401809071 and partition_no = 1168

UPDATE ocq_koc_ocp_partitions_ext a 
   SET a.quote_status = 'T053' 
      ,a.quote_status_exp = 'T5947800 manual ��z�m' 
      ,a.quote_status_date = SYSDATE 
      ,a.quote_status_user = USER 
WHERE a.quote_id = 86753499 
  AND a.partition_no = 1168; 
