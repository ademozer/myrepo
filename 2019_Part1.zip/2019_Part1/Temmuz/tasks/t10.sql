SELECT * FROM KOC_CLM_HLTH_INDEM_DEC WHERE CLAIM_ID=40464267 FOR UPDATE;
SELECT * FROM CLM_TRANS WHERE CLAIM_ID=40464267 ORDER BY TRANS_NO;
SELECT * FROM KOC_CLM_TRANS_EXT WHERE CLAIM_ID=40464267 ORDER BY TRANS_NO;
SELECT * FROM KOC_CLM_STATUS_HISTORY_EXT WHERE CLAIM_ID=40464267;
SELECT * FROM CLM_STATUS_HISTORY WHERE CLAIM_ID=40464267;
SELECT * FROM Koc_Clm_Hlth_Reject_Loss WHERE CLAIM_ID=40464267;
select * from clm_pol_oar where CLAIM_ID=40464267;
--koc_clm_hlth_trnx
select * from alz_hlth_bordro_trans_log WHERE CLAIM_ID=40464267;
select * from koc_clm_hlth_provisions where claim_id=40464267;
select * from clm_subfiles  where claim_id=40464267;
select * from koc_clm_hlth_detail where claim_id=40464267;
select * from Koc_Clm_Hlth_Incomp_Papers where claim_id=40464267;
             SET Status_Code = 'C'
           WHERE Claim_Id = Clmdetail(1).Claim_Id

select * from alz_hltprv_log where log_id=132449924;
	Web_Clm_Hlth_Hospt_Utils.Koc_Bpm_Project_Log_Write;
select * from koc_bpm_project_log where key_info='40464267' 
and process_date between TO_DATE('12/04/2019 08:04:00','DD/MM/YYYY HH24:MI:SS') 
AND TO_DATE('12/04/2019 08:07:00','DD/MM/YYYY HH24:MI:SS');

select * from clm_subfiles where ext_reference='37418598'

37418596
select * from koc_clm_hlth_detail where ext_reference='37418598'--'37418596'
select * from koc_clm_hlth_provisions@opusprep where claim_id=41846612--41846593;

select * from koc_clm_hlth_reject_loss@opusprep where claim_id=41846593;
select * from alz_hltprv_log where log_date>trunc(sysdate) and insurednotype='EXT_REFERENCE' and insuredno='37418597'
select * from hst_cc_web_inst_doctor where doctor_surname='DE��RMENC�O�LU' F�SUN DE��RMENC�O�LU


SELECT * FROM CLM_TRANS WHERE CLAIM_ID=41846612 ORDER BY TRANS_NO;
SELECT * FROM KOC_CLM_TRANS_EXT WHERE CLAIM_ID=41846612 ORDER BY TRANS_NO;
SELECT * FROM KOC_CLM_STATUS_HISTORY_EXT WHERE CLAIM_ID=41846612;
