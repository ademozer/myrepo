select * from customer.alz_duplicate_provision where ext_reference='58077314'--'55885313';
select * from alz_hltprv_log where log_id=132143263

select * from koc_cc_web_inst_doctor where doctor_identity_no='28957295300'
select * from hst_cc_web_inst_doctor where doctor_code=71945

select * from customer.alz_duplicate_provision where ext_reference='54557881';
select * from alz_hltprv_log where log_id=96958650--94785498
select * from koc_clm_suppliers_ext where institute_code=13 for update;

select * from clm_pol_oar where contract_id=421754807 and oar_no=1;

select * from clm_subfiles where claim_id in(41874035,41874036)

select * from koc_clm_hlth_detail where ext_reference='54557881' for update
union
select * from koc_clm_hlth_detail@opusdev where ext_reference='55885313'

 -- for update;
select * from koc_clm_hlth_provisions where claim_id=37125931 and cover_code='ST534'  for update
union 
select * from koc_clm_hlth_provisions@opusprep where claim_id=38937633 and cover_code='S513'
 --for update;
select * from koc_clm_hlth_reject_loss where claim_id=37355078;

select * from koc_clm_trans_ext where claim_id=37125931
update koc_clm_hlth_provisions 
   set provision_total=190.52
 where claim_id=37125931 
   and cover_code='ST534'


   select *
            from koc_clm_hlth_detail a
            where a.CLAIM_ID = 38937633
            and a.SF_NO= 1
            AND a.ADD_ORDER_NO=1
            and a.STATUS_CODE in ('R','C')
            and exists (select 1
                                from koc_clm_hlth_provisions b
                                where b.CLAIM_ID = a.CLAIM_ID
                                and b.SF_NO= a.SF_NO
                                and b.ADD_ORDER_NO = a.ADD_ORDER_NO
                                and b.STATUS_CODE not in ('R','C') )
            union all
                select *
                from koc_clm_hlth_detail a
                where a.CLAIM_ID = 38937633
                and a.SF_NO= 1
                AND a.ADD_ORDER_NO= 1
                and a.STATUS_CODE in ('TAH','ODE')
                and exists (select 1
                                    from koc_clm_hlth_provisions b
                                    where b.CLAIM_ID = a.CLAIM_ID
                                    and b.SF_NO= a.SF_NO
                                    and b.ADD_ORDER_NO = a.ADD_ORDER_NO
                                    and b.STATUS_CODE not in ('TAH','ODE','C','R') )
                                    
                                    
                                     select *
                from koc_clm_hlth_detail a
                where a.CLAIM_ID = 38937633
                and a.SF_NO= 1
                AND a.ADD_ORDER_NO= 1
                and a.STATUS_CODE ='P'
                and exists (select 1
                                    from koc_clm_hlth_provisions b
                                    where b.CLAIM_ID = a.CLAIM_ID
                                    and b.SF_NO= a.SF_NO
                                    and b.ADD_ORDER_NO = a.ADD_ORDER_NO
                                    and b.STATUS_CODE not in ('P','R','C') );


update koc_clm_hlth_provisions
set request_amount = 328.6,
    proc_request_amount = 328.6,
    inst_request_amount = 328.6,
    sys_request_amount = 328.6
where claim_id = 38937633
  and cover_code = 'S513'
    
