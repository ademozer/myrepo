update koc_clm_hlth_provisions
set request_amount = 328.6,
    proc_request_amount = 328.6,
    inst_request_amount = 328.6,
    sys_request_amount = 328.6
where claim_id = 38937633
  and cover_code = 'S513'
/
COMMIT
/  
