DECLARE
    HCLM_CHANNEL VARCHAR2(100) := 'CENTRAL_REIMBURSEMENT';
    v_request CLOB;
    v_response CLOB;
    v_url VARCHAR2(200) := get_url_link('http://esb.allianz.com.tr:12000/hclm-health-claim-service/api/v1/computeremaining/list');
    v_status NUMBER;
    v_message VARCHAR2(1000); 
    procedure callRestService(p_Url               In          Varchar2,
                              p_Method            In          Varchar2,                                                                           
                              p_Request           In          Clob,                    
                              p_Response          Out         Clob, 
                              p_Status            Out         Number, 
                              p_Message           Out         Varchar2) IS 
                              
        v_Req               utl_http.req;
        v_Req_Length        Number;
        v_Res               utl_http.resp;
        v_Buffer            Varchar2(32767);
        v_Offset            Number := 1;
        v_Amount            Number :=32767;
        v_Utl_Err           Varchar2(1000);
        v_value             varchar2(4000);
        hata_code           varchar2(10);
        v_output            varchar2(10);
        v_Response          CLOB;
        v_Line_Number       NUMBER := 0;
        
        Begin
          
            v_Req_Length := dbms_lob.getlength(p_Request);
            v_Req := utl_http.begin_request(p_Url, p_Method, 'HTTP/1.1');                 
            utl_http.set_header(v_Req, 'Content-Length', v_Req_Length);
            utl_http.set_header(v_Req, 'Content-Type', 'application/json;charset=UTF-8');
            utl_http.set_header(v_Req, 'Transfer-Encoding', 'chunked' );
            utl_http.set_header(v_Req, 'Hclm-Channel', HCLM_CHANNEL );
            utl_http.set_transfer_timeout(300);
            utl_http.set_body_charset(v_Req,'UTF-8');           
                        
            While (v_Offset < v_Req_Length)
            Loop
               dbms_lob.read(p_Request, v_Amount, v_Offset, v_Buffer);
               utl_http.write_text(r    => v_Req, data => v_Buffer);
               v_Offset := v_Offset + v_Amount;
            End Loop;
            
            v_Res := utl_http.get_response(v_Req);
            p_status := 0;
            p_message := v_Res.status_code || ':' || v_Res.reason_phrase;
            IF v_Res.status_code != 200  THEN                
                p_Status := 1;                                          
            END IF;             
            Begin              
               loop                 
                  utl_http.read_line(v_Res, v_value);
                  v_value := TRIM(regexp_replace(v_value, '([^[:graph:] | ^[:blank:]])', ''));
                  v_Response := v_Response || v_value;                                                    
               end loop;               
               utl_http.end_response(v_Res);               
            Exception              
            When utl_http.end_of_body Then
                 utl_http.end_response(v_Res);
            When utl_http.too_many_requests Then
                 utl_http.end_response(v_Res);
            When Others Then
                 utl_http.end_response(v_Res);
           End;                    
           p_Response := TRIM(v_Response); 
           IF INSTR(p_Response,'"errors"')>0 THEN
               p_Status := 1;
               p_message := 'Business Exception';
           END IF;                              
        EXCEPTION 
           WHEN OTHERS THEN
              utl_http.end_response(v_Res);
              v_utl_err:= Utl_Http.Get_Detailed_Sqlerrm;
              p_Status := 1;
              p_Response := '';
              p_Message := v_utl_err||' - '||p_url;              
    END callRestService;
    
    BEGIN
      
     v_request := '{
            "claimInstLoc" : "YI",
            "claimInstType" : "AHK",
            "countryGroup" : "0",
            "contractId" : "461709478",
            "coverInfoParamList" : [{
                    "coverCode" : "S511",
                    "daySeance" : "0",
                    "exemptionOverAmount" : "",
                    "poolCover" : "false",
                    "provisionAmount" : "129",
                    "specialCover" : "false"
              }],
            "instituteCode" : "20000",
            "invoiceDate" : "2019-05-01T00:00:00.000+03:00",
            "partitionNo" : "2056",
            "partnerId" : "8484792",
            "policyGroupCode" : "S9397",
            "policyStartDate" : "2019-03-17T00:00:00.000+03:00",
            "queryDate" : "2019-05-01T00:00:00.000+03:00",
            "realizationDate" : "2019-05-01T00:00:00.000+03:00",
            "referral" : "false",
            "swiftCode": "TL",
            "userGroup": ["1","2","3","4"]
        }';

 
        
         DBMS_OUTPUT.PUT_LINE(v_request);           
         --ALZ_HCLM_CONVERTER_UTILS.
         callRestService(v_url, 'POST', v_request, v_response, v_status, v_message);
         DBMS_OUTPUT.PUT_LINE('----------------------------');
         DBMS_OUTPUT.PUT_LINE(v_response);
         DBMS_OUTPUT.PUT_LINE('----------------------------');
         DBMS_OUTPUT.PUT_LINE(v_status||'- '||v_message);
        
     EXCEPTION
     WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Hata:'||SQLERRM);
     END;
