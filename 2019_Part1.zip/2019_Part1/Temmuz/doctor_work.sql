select * from koc_cc_web_inst_doctor where doctor_identity_no='45160010254'
select * from hst_cc_web_inst_doctor where doctor_code='177857';



update hst_cc_web_inst_doctor 
 set doctor_identity_no='45160010254'
 where doctor_code='177857';
 
 select * from ALZ_HLTH_CPA_PROCESS WHERE ext_reference = '56794276';
 
 ALZ_HLTH_CPA.insertInvoiceHistory
