update hst_cc_web_inst_doctor 
   set doctor_identity_no='45160010254'
 where doctor_code='177857'
/
COMMIT
/ 
