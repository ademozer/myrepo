insert into alz_hclm_institute_info (INSTITUTE_CODE, HCLM_USAGE)
values (1657, 0);

insert into alz_hclm_institute_info (INSTITUTE_CODE, HCLM_USAGE)
values (2072, 1);

insert into alz_hclm_institute_info (INSTITUTE_CODE, HCLM_USAGE)
values (4549, 1);

insert into alz_hclm_institute_info (INSTITUTE_CODE, HCLM_USAGE)
values (36, 1);

insert into alz_hclm_institute_info (INSTITUTE_CODE, HCLM_USAGE)
values (2630, 1);

insert into alz_hclm_institute_info (INSTITUTE_CODE, HCLM_USAGE)
values (5949, 1);

insert into alz_hclm_institute_info (INSTITUTE_CODE, HCLM_USAGE)
values (529, 1);

insert into alz_hclm_institute_info (INSTITUTE_CODE, HCLM_USAGE)
values (13, 1);

insert into alz_hclm_institute_info (INSTITUTE_CODE, HCLM_USAGE)
values (2780, 1);

insert into alz_hclm_institute_info (INSTITUTE_CODE, HCLM_USAGE)
values (20000, 1);

insert into alz_hclm_institute_info (INSTITUTE_CODE, HCLM_USAGE)
values (1750, 1);

insert into alz_hclm_institute_info (INSTITUTE_CODE, HCLM_USAGE)
values (132740, 1);

insert into alz_hclm_institute_info (INSTITUTE_CODE, HCLM_USAGE)
values (996, 1);

insert into alz_hclm_institute_info (INSTITUTE_CODE, HCLM_USAGE)
values (337, 1);

insert into alz_hclm_institute_info (INSTITUTE_CODE, HCLM_USAGE)
values (4617, 1);

insert into alz_hclm_institute_info (INSTITUTE_CODE, HCLM_USAGE)
values (175, 1);

insert into alz_hclm_institute_info (INSTITUTE_CODE, HCLM_USAGE)
values (6105, 1);

insert into alz_hclm_institute_info (INSTITUTE_CODE, HCLM_USAGE)
values (746, 1);

insert into alz_hclm_institute_info (INSTITUTE_CODE, HCLM_USAGE)
values (1752, 1);

insert into alz_hclm_institute_info (INSTITUTE_CODE, HCLM_USAGE)
values (4538, 0);

insert into alz_hclm_institute_info (INSTITUTE_CODE, HCLM_USAGE)
values (852, 1);

COMMIT;
