select * from alz_acc_payment_pool where claim_id=41689435-- ext_reference='57924312'
   
      -- ext_reference
      
      select * from koc_clm_hlth_detail where group_code='S16037' and process_date>(sysdate-30) and provision_date is null--ext_reference='57939307';
select * from koc_clm_hlth_detail where ext_reference='57562819'--'57938304'     
 select * from koc_clm_trans_ext where claim_id=41207797 order by trans_no--41689435 order by trans_no
 
 57562819
     -- delete clm_trans where claim_id=41690442
      select alz_acc_payment_utils_load.addworkdays(trunc(sysdate+1),-1) from dual;
      
      select * from ocp_policy_bases where policy_ref='0001171006127993';
      
      --select * from clm_pol_oar where contract_id=441564560 and oar_no=
      select * from koc_acc_bank_history where identity_no='46723449986'--36622974504
      select * from koc_cp_partners_ext where part_id=102491356;
      
       SELECT *  FROM koc_acc_bank_history WHERE contract_id IN (1,2)
      
      koc_clm_hlth_trnx2.indemnityRealization;
      
     select * from    KOC_CLM_TRANS_EXT_DEL_LOG where claim_id = 41690442;
     
     
     koc_clm_hlth_trnx2.updateClmTransBank
