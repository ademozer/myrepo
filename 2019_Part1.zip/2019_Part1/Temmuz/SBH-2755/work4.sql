 BEGIN 
   
 FOR rec IN (
  select --GROUP_CODE,grup_baslik,product_id,policy_ref,SIGortali_NO,
       org_payment_code,
       ext_reference,
       claim_id,
       sf_no,
       SIGORTALI_ADI_SOYADI,
       alici_adi_soyadi,
       'TL' currency_code,
       creditor_bank,
       creditor_subsidiary,
       account_no,
       --correspondent_bank, correspondent_subsidiary,
       --correspondent_account_code,
       --correspondent_iban_code,
       iban_code,
       tckn_vkn,
       partner_type,
       identity_no,
       tax_number,
       contract_id,
       ip_no,
       tutar,
       policy_ref
        from (select
              --e.GROUP_CODE,
              --decode(e.GROUP_CODE,null,null,c.policy_ref ||' No.lu Poli�e Toplami : ') grup_baslik,
              --c.product_id,
              --c.policy_ref,
              --d.oar_no SIGortali_NO,
               alz_acc_payment_utils_load.safetonumber(max(a.sf_total_type)) org_payment_code,
               a.ext_reference,
               b.claim_id,
               b.sf_no,
               nvl(substr(koc_clm_hlth_utils.getpartnernamebypartid(e.part_id),1,30),chr(32)) SIGORTALI_ADI_SOYADI,
               nvl(b.creditor_name, chr(32)) alici_adi_soyadi,
               'TL' currency_code,
               b.creditor_bank,
               b.creditor_subsidiary,
               b.account_no,
               b.iban_code,
               --b.correspondent_bank,
               --b.correspondent_subsidiary,
               --b.correspondent_account_code,
               --b.correspondent_iban_code,
               decode(k.partner_type, 'I', f.identity_no, 'P', f.tax_number) tckn_vkn,
               k.partner_type,
               f.identity_no,
               f.tax_number,
               c.contract_id,
               a.ip_no,
               sum(decode(a.sf_total_type, 11, 1, 12, -1, null) *
                   a.trans_amt * nvl(b.currency_exchange_rate, 1)) tutar,
                   c.policy_ref
                from clm_trans a,
                     koc_clm_trans_ext b,
                     clm_pol_bases c,
                     clm_pol_oar d,
                     koc_clm_hlth_detail e,
                     cp_partners k,
                     koc_cp_partners_ext f
               where a.claim_id = b.claim_id
                 and a.sf_no = b.sf_no
                 and a.trans_no = b.trans_no
                 and a.claim_id = c.claim_id
                 and a.claim_id = d.claim_id
                 and a.claim_id = e.claim_id
                 and b.claim_id = e.claim_id
                 and b.sf_no = e.sf_no
                 and b.add_order_no = e.add_order_no
                 and k.part_id = f.part_id
                 and k.part_id = e.part_id
                 and b.technical_approved_date is not null
                 and b.transfer_bank_date is null
                 and e.ext_reference='57924304'
                 and b.payment_approved_date = TRUNC(SYSDATE)
                 and b.ticket_date is null
                 and b.hsap is null /*g�vence hesab� �demeleri manuel yap�laca��ndan otomatik aktar�m engelleniyor*/
                 and b.payment_type = 5
                 and a.sf_total_type in (11)
                 and nvl(b.is_account_approved, 0) != 1
                 and a.trans_no in
                     (select max(x.trans_no)
                        from koc_clm_trans_ext x, clm_trans y
                       where x.claim_id = y.claim_id
                         and x.sf_no = y.sf_no
                         and y.trans_no = y.trans_no
                         and x.claim_id = b.claim_id
                         and x.sf_no = b.sf_no
                         and x.add_order_no = b.add_order_no
                         and x.hlth_cover_code = b.hlth_cover_code
                         and y.sf_total_type in (11, 12))
               group by e.group_code,
                        c.product_id,
                        c.policy_ref,
                        a.ext_reference,
                        b.claim_id,
                        b.sf_no,
                        d.oar_no,
                        e.part_id,
                        b.creditor_name,
                        b.creditor_bank,
                        b.creditor_subsidiary,
                        b.account_no,
                        b.correspondent_bank,
                        b.correspondent_subsidiary,
                        b.correspondent_account_code,
                        b.correspondent_iban_code,
                        decode(k.partner_type,
                               'I',
                               f.identity_no,
                               'P',
                               f.tax_number),
                        k.partner_type,
                        f.identity_no,
                        f.tax_number,
                        b.iban_code,
                        c.contract_id,
                        a.ip_no)) LOOP
                        
                   dbms_output.put_line('deneme');     
              END LOOP;
              
         END;
