update koc_clm_hlth_provisions 
   set provision_total=190.52
 where claim_id=37125931 
   and cover_code='ST534'
/
COMMIT
/   
