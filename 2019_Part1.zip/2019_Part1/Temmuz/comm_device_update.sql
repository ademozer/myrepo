update Koc_Cp_Comm_Devices 
   set validity_end_date = (sysdate-1)
 where comm_dev_id=197075614
/
COMMIT
/    
