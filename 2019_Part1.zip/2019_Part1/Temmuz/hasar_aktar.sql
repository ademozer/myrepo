DECLARE 

p_Old_Contract_Id  NUMBER := 442806538;
p_Old_Partition_No NUMBER := 3464;
p_New_Contract_Id  NUMBER := 442806538;
p_New_Partition_No NUMBER := 4653;
p_Err_Seq          NUMBER;
p_Result           VARCHAR2(1000);
BEGIN
  

 CUSTOMER.Koc_hlth_Clm_Transfer.Pr_Settranspolicycoverlimits(p_Old_Contract_Id,
                                                             p_Old_Partition_No,
                                                             p_New_Contract_Id,
                                                             p_New_Partition_No,
                                                             p_Err_Seq,
                                                             p_Result);
                                                    
DBMS_OUTPUT.PUT_LINE('p_err_seq='||p_Err_Seq||' p_result='||p_Result);

END;                                                    
