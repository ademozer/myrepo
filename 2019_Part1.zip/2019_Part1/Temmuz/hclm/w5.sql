﻿SELECT * FROM ALZ_HCLM_INSTITUTE_INFO for update
--SELECT * FROM ALZ_HCLM_INSTITUTE_INF

select * from alz_hltprv_log where log_id=118810625

select * from koc_clm_hlth_detail where ext_reference ='57575304' for update
select * from alz_hlth_detail_hist where claim_id=40464267
SELECT * FROM alz_hclm_version_info where claim_id=40182450 and sf_no=1 and add_order_no=1

select * from koc_clm_hlth_proc_detail where claim_id=40182450 and cover_code='S511'

select * from customer.alz_duplicate_provision where ext_reference ='57575304' order by log_id
select * from all_tables where table_name like '%DETAIL%HIS%'

SELECT * FROM KOC_CLM_HLTH_INDEM_DEC where claim_id=40464267
select * FROM KOC_CLM_HLTH_STATUS_HIS


SELECT institute_code,
       assignee,
       process_date,
       sf_total_type,
       ext_reference,
       hlth_cover_code,
       cover_exp,
       sirket_payi,
       realization_ticket_date,
       clm_status
  FROM (SELECT e.institute_code,
               a.assignee,
               d.process_date,
               DECODE(a.sf_total_type,
                      '10',
                      'Provizyon/Muallak',
                      '11',
                      'Tahakkuk',
                      12,
                      'Tahakkuk Ýptal',
                      'Diðer') sf_total_type,
               a.ext_reference,
               b.hlth_cover_code,
               koc_clm_hlth_utils.getcoverdef(b.hlth_cover_code) cover_exp,
               a.trans_amt * NVL(b.currency_exchange_rate, 1) sirket_payi,
               b.realization_ticket_date,
               decode(c.clm_status,
                      'CANCELLED',
                      'Ýptal',
                      'OPEN',
                      'Açýk',
                      c.clm_status) clm_status
          FROM clm_trans                  a,
               koc_clm_trans_ext          b,
               clm_status_history         c,
               koc_clm_status_history_ext d,
               koc_mv_skrm_suppliers      e
         WHERE a.claim_id = b.claim_id
           AND a.sf_no = b.sf_no
           AND a.trans_no = b.trans_no
           AND a.claim_id = c.claim_id
           AND a.sf_no = c.sf_no
           AND a.trans_no = c.trans_no
           AND c.status_id = d.status_id
           AND a.supp_id = e.supp_id
           AND c.clm_status != 'CLOSED'
         ORDER BY d.process_date DESC)
      where ext_reference='57459752';
      
      SELECT * FROM koc_clm_trans_ext where claim_id=40464267 order by 3
      
      select * from clm_status_history where claim_id=40464267   
      select * from koc_clm_status_history_ext where claim_id=40464267 
      select * from koc_clm_hlth_provisions where claim_id=40464267 
      
      select * from koc_clm_hlth_detail where ext_reference='56792583' for update;
      select * from customer.alz_duplicate_provision where ext_reference='57544532';
      
      select * from alz_hltprv_log where log_date>sysdate-1 and servicename='TSSProvisionServiceCtrlImpl'  and UPPER(CONTENT) LIKE '%ZİYA%'--log_id=118808992--118809033
      
      select * from koc_cc_web_inst_doctor where doctor_code='30638'
      
      select * from alz_hltprv_log where log_id=126901769
      
      select * from all_source where text like '%Sehir%'
      
      select * from koc_mv_skrm_suppliers where institute_code='3210'
      
      select * from koc_cc_web_inst_doctor where doctor_name='ZİYA' and doctor_surname='ÖMER'
      
      select * from customer.alz_branch_code_cgm_rel  where branchcodeallz='1470';
      
      ALZ_HCLM_CONVERTER_UTILS
      
      a := 'ali''nin';
      
      
      alz_hltprv_form_utils.get_stat_head;
      
      SELECT * FROM Koc_Clm_Hlth_tmp_Proc_Detail where claim_id=40182482 and cover_code='S511'
      SELECT * FROM 
      
      select * from alz_hltprv_log where log_date>TRUNC(SYSDATE) AND INSUREDNO>'56792583'--log_id=118810598
      
      select * from alz_hltprv_log where log_id=118811463;
      
      Koc_Clm_Hlth_Trnx.Clmprovisiontype;
      
      select * from all_source where lower(text) like '%değerlendirilmiştir%';
      
      
      ALZ_HEALTH_INFORMER_UTILS
