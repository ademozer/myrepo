select * from koc_clm_hlth_detail where ext_reference='57846161' for update;
select * from koc_clm_hlth_provisions where claim_id=41570466 for update;--and cover_code='S513'
union
select * from koc_clm_hlth_provisions@opusdev where claim_id=38937633 and cover_code='S513'


delete koc_clm_hlth_provisions where claim_id=37115745 and cover_code='S660';

select * from koc_clm_trans_ext where claim_id=37115745
select * from koc_clm_web_auth_pool where claim_id=37115745;
select * from customer.alz_duplicate_provision where ext_reference='57846161';

koc_clm_hlth_trnx2.isClmApproved


update koc_clm_hlth_provisions
   SET REQUEST_AMOUNT = 328.6,
       PROC_REQUEST_AMOUNT = 328.6,
       INST_REQUEST_AMOUNT = 328.6,
       SYS_REQUEST_AMOUNT = 328.6
 WHERE claim_id=38937633 
   and cover_code='S513'





select * from alz_hltprv_log where log_id=129893076;
select * from koc_clm_hlth_status where claim_id=41570466
select * from alz_hlth_detail_hist where claim_id=41570466
select * from koc_clm_trans_ext where claim_id=41570466
select * from koc_clm_hlth_indem_dec where claim_id=41570466
select * from koc_clm_status_history_log where claim_id=41570466
select * from koc_clm_hlth_proc_detail where claim_id=38937633 for update
