DECLARE
  Clmdetail Koc_Clm_Hlth_Trnx.Clmdetailtype;
PROCEDURE Delete_Provisions(p_Contract_Id      NUMBER,
                              p_Partition_No     NUMBER,
                              p_Realization_Date DATE,
                              p_Location_Code    NUMBER,
                              p_Cover_Code       VARCHAR2,
                              p_User_Id          VARCHAR2,
                              p_Del_Or_Rej       NUMBER,
                              Clmdetail          Koc_Clm_Hlth_Trnx.Clmdetailtype,
                              p_Cancelation_Exp  VARCHAR2 DEFAULT NULL) IS
    -- p_del_or_rej = 1 ALL delete
    -- p_del_or_rej = 2 ALL reject
    -- p_del_or_rej = 3 DELETE
    -- p_del_or_rej = 4 REJECT

    CURSOR Curprovsum(p_Claim_Id     NUMBER,
                      p_Sf_No        NUMBER,
                      p_Add_Order_No NUMBER,
                      p_Cover_Code   VARCHAR2) IS
      SELECT b.Claim_Id,
             b.Sf_No,
             b.Add_Order_No,
             b.Cover_Code,
             b.Swift_Code,
             b.Is_Pool_Cover,
             b.Is_Special_Cover,
             SUM(b.Exemption_Amount) Exemption_Amount,
             SUM(b.Provision_Total) Provision_Total,
             SUM(b.Refusal_Amount) Refusal_Amount,
             SUM(b.Request_Amount) Request_Amount
        FROM Koc_Clm_Hlth_Provisions b
       WHERE b.Claim_Id = p_Claim_Id
         AND b.Sf_No = p_Sf_No
         AND b.Add_Order_No = p_Add_Order_No
         AND b.Cover_Code = p_Cover_Code
       GROUP BY b.Claim_Id,
                b.Sf_No,
                b.Add_Order_No,
                b.Cover_Code,
                b.Swift_Code,
                b.Is_Pool_Cover,
                b.Is_Special_Cover;

    Recprovsum Curprovsum%ROWTYPE;

    CURSOR Curclmprovision(p_Claim_Id     NUMBER,
                           p_Sf_No        NUMBER,
                           p_Add_Order_No NUMBER) IS
      SELECT a.*
        FROM Koc_Clm_Hlth_Provisions a
       WHERE a.Claim_Id = p_Claim_Id
         AND a.Sf_No = p_Sf_No
         AND a.Add_Order_No = p_Add_Order_No
         AND a.Location_Code = Nvl(p_Location_Code, a.Location_Code)
         AND a.Cover_Code = Nvl(p_Cover_Code, a.Cover_Code);

    Clmprovision         Curclmprovision%ROWTYPE;
    p_Raise              VARCHAR2(2000);
    j                    NUMBER;
    Cur                  Koc_Clm_Hlth_Trnx.Refcur;
    Policyinfo           Koc_v_Hlth_Insured_Info_Indem%ROWTYPE;
    Institutinfo         Koc_v_Clm_Suppliers%ROWTYPE;
    Insuredinfo          Koc_v_Health_Partner_Info%ROWTYPE;
    v_Clmdetail          Koc_Clm_Hlth_Detail%ROWTYPE;
    v_Clmprovision       Koc_Clm_Hlth_Provisions%ROWTYPE;
    v_Status_Id          NUMBER;
    v_Clm_Sf_Id          NUMBER;
    v_Int_Ref            NUMBER;
    v_Trans_No           NUMBER;
    v_Provision_Amount   NUMBER;
    v_Exemption_Amount   NUMBER;
    v_Cnt                NUMBER;
    v_Cnt_All            NUMBER;
    v_Ext_Reference      VARCHAR2(30);
    v_Detail_Del_Status  VARCHAR2(20);
    v_Clm_Del_Status     VARCHAR2(20);
    p_Provision_Date     DATE;
    Clmid                NUMBER;
    v_Base_Contract_Id   NUMBER;
    v_Letter_No          NUMBER;
    v_Date_Of_Loss       DATE;
    v_Trans_Date         DATE;
    v_Muallak_Date       DATE;
    v_First_Agent_Int_Id NUMBER;
    v_First_Sub_Agent    NUMBER;
    p_Exemption_Amount   NUMBER;
    Vhaspolicy1kez       NUMBER(1);
    Vis1kezused          NUMBER(1) := 0;
    Vclaiminsttype       Koc_Clm_Hlth_Indem_Totals.Claim_Inst_Type%TYPE;
    Verrmsg              VARCHAR2(1000);

    -- emre.elcik -- 20150422 --
    v_Clm_Check     Alz_Clm_Hlth_Error_Log.Is_Checked%TYPE := NULL;
    v_Error_Exp     Alz_Clm_Hlth_Error_Log.Explanation%TYPE := NULL;
    v_Countindemdec PLS_INTEGER := 0;
  BEGIN
    Clmid := 1;

    IF Clmdetail(Clmid).Provision_Date IS NULL THEN
      p_Provision_Date := Nvl(Clmdetail(Clmid).Date_Of_Loss,
                              Clmdetail(Clmid).Invoice_Date);
      p_Provision_Date := To_Date(To_Char(p_Provision_Date, 'dd/mm/yyyy') ||
                                  ' 13:00:00',
                                  'dd/mm/yyyy hh24:mi:ss');
    ELSE
      p_Provision_Date := Clmdetail(Clmid).Provision_Date;
      p_Provision_Date := To_Date(To_Char(p_Provision_Date, 'dd/mm/yyyy') ||
                                  ' 13:00:00',
                                  'dd/mm/yyyy hh24:mi:ss');
    END IF;

    v_Date_Of_Loss := Nvl(Clmdetail(Clmid).Provision_Date,
                          Clmdetail(Clmid).Invoice_Date);

    Koc_Clm_Hlth_Utils.Getallpolinfoforindemnity(p_Contract_Id,
                                                 p_Partition_No,
                                                 Clmdetail(Clmid).Part_Id,
                                                 p_Provision_Date,
                                                 Cur);

    FETCH Cur
      INTO Policyinfo;

    CLOSE Cur;

    v_First_Agent_Int_Id := Koc_Clm_Hlth_Trnx.Getfirstagent(Policyinfo.Contract_Id);
    v_First_Sub_Agent    := Koc_Clm_Hlth_Trnx.Getfirstsubagent(Policyinfo.Contract_Id);

    --- poli�e bitis tarihinde prov veya fatura
    IF Policyinfo.Contract_Id IS NULL THEN
      IF Clmdetail(Clmid).Provision_Date IS NULL THEN
        p_Provision_Date := Nvl(Clmdetail(Clmid).Date_Of_Loss,
                                Clmdetail(Clmid).Invoice_Date);
        p_Provision_Date := To_Date(To_Char(p_Provision_Date, 'dd/mm/yyyy') ||
                                    ' 11:00:00',
                                    'dd/mm/yyyy hh24:mi:ss');
      ELSE
        p_Provision_Date := Clmdetail(Clmid).Provision_Date;
        p_Provision_Date := To_Date(To_Char(p_Provision_Date, 'dd/mm/yyyy') ||
                                    ' 11:00:00',
                                    'dd/mm/yyyy hh24:mi:ss');
      END IF;

      Koc_Clm_Hlth_Utils.Getallpolinfoforindemnity(p_Contract_Id,
                                                   p_Partition_No,
                                                   Clmdetail(Clmid).Part_Id,
                                                   p_Provision_Date,
                                                   Cur);

      FETCH Cur
        INTO Policyinfo;

      CLOSE Cur;
    END IF;

    Koc_Clm_Hlth_Utils.Getinsuredinfobypartnerid(Policyinfo.Partner_Id,
                                                 Cur);

    FETCH Cur
      INTO Insuredinfo;

    CLOSE Cur;

    Koc_Clm_Hlth_Utils.Getinstitutinfobycode(Clmdetail(Clmid)
                                             .Institute_Code,
                                             p_Provision_Date,
                                             Cur);

    FETCH Cur
      INTO Institutinfo;

    CLOSE Cur;

    IF Institutinfo.Institute_Code IS NULL THEN
      Koc_Clm_Hlth_Utils.Getlastinstitutinfobycode(Clmdetail(Clmid)
                                                   .Institute_Code,
                                                   Cur);

      FETCH Cur
        INTO Institutinfo;

      CLOSE Cur;
    END IF;

    

 

    SELECT *
      INTO v_Clmdetail
      FROM (SELECT a.*
              FROM Web_Clm_Hlth_Detail a
             WHERE a.Claim_Id = Clmdetail(Clmid).Claim_Id
               AND a.Sf_No = Clmdetail(Clmid).Sf_No
               AND a.Add_Order_No = Clmdetail(Clmid).Add_Order_No
            UNION
            SELECT a.*
              FROM Koc_Clm_Hlth_Detail a
             WHERE a.Claim_Id = Clmdetail(Clmid).Claim_Id
               AND a.Sf_No = Clmdetail(Clmid).Sf_No
               AND a.Add_Order_No = Clmdetail(Clmid).Add_Order_No
               AND NOT EXISTS
             (SELECT 1
                      FROM Web_Clm_Hlth_Detail b
                     WHERE b.Claim_Id = a.Claim_Id
                       AND b.Sf_No = a.Sf_No
                       AND b.Add_Order_No = a.Add_Order_No));

    /*v_Base_Contract_Id := Koc_Clm_Hlth_Trnx.Getclaimcontractid(Clmdetail(Clmid).Claim_Id);*/
    BEGIN
    SELECT Contract_Id
      INTO v_Base_Contract_Id
      FROM Clm_Pol_Bases
     WHERE Claim_Id = Clmdetail(Clmid).Claim_Id;
    EXCEPTION
    WHEN OTHERS THEN
       NULL;
    END;
    IF v_Base_Contract_Id IS NULL THEN
      -- elden fatura red
      /*INSERT INTO Clm_Bases
        (Claim_Id,
         Clm_Status,
         Clm_Line_Id,
         Manual_Claim,
         Date_Reported,
         Chargeable_Code)
      VALUES
        (Clmdetail(Clmid).Claim_Id, 'OPEN', 20, 'N', SYSDATE, 0);

      INSERT INTO Clm_Pol_Bases
        (Claim_Id,
         Contract_Id,
         Product_Id,
         Prod_Version,
         Contract_Status,
         Term_Start_Date,
         Term_End_Date,
         Version_No,
         Date_Of_Loss,
         Policy_Ref,
         Agent_Role)
      VALUES
        (Clmdetail(Clmid).Claim_Id,
         Policyinfo.Contract_Id,
         Policyinfo.Product_Id,
         NULL,
         Policyinfo.Contract_Status,
         Policyinfo.Term_Start_Date,
         Policyinfo.Term_End_Date,
         Policyinfo.Version_No,
         v_Date_Of_Loss,
         Policyinfo.Policy_Ref,
         v_First_Agent_Int_Id);

      INSERT INTO Clm_Pol_Oar
        (Claim_Id, Contract_Id, Oar_No, Version_No)
      VALUES
        (Clmdetail(Clmid).Claim_Id,
         Policyinfo.Contract_Id,
         Policyinfo.Partition_No,
         Policyinfo.Version_No);

      v_Ext_Reference := Clmdetail(Clmid).Ext_Reference;

      SELECT Clm_Sf_Id_Seq.Nextval INTO v_Clm_Sf_Id FROM Dual;

      INSERT INTO Clm_Subfiles
        (Claim_Id,
         Sf_No,
         Sf_Type,
         Clm_Status,
         Sf_Desc,
         Sf_Id,
         Ext_Reference)
      VALUES
        (Clmdetail(Clmid).Claim_Id,
         1,
         'HLT',
         'OPEN',
         '',
         v_Clm_Sf_Id,
         v_Ext_Reference);

      INSERT INTO Koc_Clm_Subfiles_Ext
        (Claim_Id,
         Sf_No,
         Product_Id,
         Term_Start_Date,
         Term_End_Date,
         Date_Of_Loss,
         Policy_Ref,
         Oldsys_Policy_No,
         Manual_Claim,
         Convert_Flag,
         Partition_Type,
         Agent_Role,
         Sub_Agent)
      VALUES
        (Clmdetail(Clmid).Claim_Id,
         1,
         Policyinfo.Product_Id,
         Policyinfo.Term_Start_Date,
         Policyinfo.Term_End_Date,
         v_Date_Of_Loss,
         Policyinfo.Policy_Ref,
         Policyinfo.Oldsys_Policy_No,
         'N',
         NULL,
         Policyinfo.Partition_Type,
         v_First_Agent_Int_Id,
         v_First_Sub_Agent);

      INSERT INTO Clm_Interested_Parties
        (Claim_Id,
         Ip_No,
         Object_Type,
         Part_Id,
         Ins_Obj_Uid,
         Ip_Type,
         Version_No,
         Object_Id,
         Claimant)
      VALUES
        (Clmdetail(Clmid).Claim_Id,
         Policyinfo.Ip_No,
         'CLM',
         Insuredinfo.Part_Id,
         Clmdetail(Clmid).Claim_Id,
         'INS',
         Policyinfo.Version_No,
         Insuredinfo.Part_Id,
         'N');*/
         DBMS_OUTPUT.PUT_LINE('Base_Contract_Id Is Null');
    END IF;

  

    --IF Nvl(Clmdetail(Clmid).Status_Code, 'PP') IN ('P', 'R', 'I', 'TI', 'PP', 'H', 'PR')
    --Limit asim �alismalari Selma Hanim mustafaku HealthDetail statu kodu nun CP gelmesi durumunda hesaplamalar �alismiyordu.
    --T�m statu kod kontrol� DB tarafinda oldugu i�in problem olmamali
    IF Nvl(Clmdetail(Clmid).Status_Code, 'PP') IN
       ('P', 'R', 'I', 'TI', 'PP', 'H', 'PR', 'CP') THEN
      OPEN Curclmprovision(Clmdetail(Clmid).Claim_Id,
                           Clmdetail(Clmid).Sf_No,
                           Clmdetail(Clmid).Add_Order_No);

      LOOP
        FETCH Curclmprovision
          INTO Clmprovision;

        EXIT WHEN Curclmprovision%NOTFOUND;

        IF Nvl(Clmprovision.Status_Code, 'PP') IN
           ('P', 'R', 'I', 'TI', 'PP', 'PR', 'C') THEN
          SELECT *
            INTO v_Clmprovision
            FROM (SELECT a.*
                    FROM Web_Clm_Hlth_Provisions a
                   WHERE a.Claim_Id = Clmprovision.Claim_Id
                     AND a.Sf_No = Clmprovision.Sf_No
                     AND a.Add_Order_No = Clmprovision.Add_Order_No
                     AND a.Location_Code = Clmprovision.Location_Code
                     AND a.Cover_Code = Clmprovision.Cover_Code
                  UNION
                  SELECT a.*
                    FROM Koc_Clm_Hlth_Provisions a
                   WHERE a.Claim_Id = Clmprovision.Claim_Id
                     AND a.Sf_No = Clmprovision.Sf_No
                     AND a.Add_Order_No = Clmprovision.Add_Order_No
                     AND a.Location_Code = Clmprovision.Location_Code
                     AND a.Cover_Code = Clmprovision.Cover_Code
                     AND NOT EXISTS
                   (SELECT 1
                            FROM Web_Clm_Hlth_Provisions b
                           WHERE b.Claim_Id = a.Claim_Id
                             AND b.Sf_No = a.Sf_No
                             AND b.Add_Order_No = a.Add_Order_No
                             AND b.Cover_Code = a.Cover_Code
                             AND b.Location_Code = a.Location_Code));

          IF Nvl(Clmdetail(Clmid).Status_Code, 'PP') <> ('R') THEN
            DBMS_OUTPUT.PUT_LINE('Update_Provisions->C');
            /*UPDATE Koc_Clm_Hlth_Provisions
               SET Status_Code      = 'C',
                   Provision_Total  = 0,
                   Exemption_Amount = 0,
                   Sgk_Amount       = 0
             WHERE Claim_Id = Clmprovision.Claim_Id
               AND Sf_No = Clmprovision.Sf_No
               AND Add_Order_No = Clmprovision.Add_Order_No
               AND Location_Code = Clmprovision.Location_Code
               AND Cover_Code = Clmprovision.Cover_Code
               AND Nvl(Status_Code, 'PP') NOT IN ('R');

            UPDATE Koc_Clm_Hlth_Proc_Detail
               SET Status_Code = 'C'
             WHERE Claim_Id = Clmprovision.Claim_Id
               AND Sf_No = Clmprovision.Sf_No
               AND Add_Order_No = Clmprovision.Add_Order_No
               AND Location_Code = Clmprovision.Location_Code
               AND Cover_Code = Clmprovision.Cover_Code
               AND Nvl(Status_Code, 'PP') NOT IN ('R');

            UPDATE Koc_Clm_Medicine_Indem_Det
               SET Status_Code = 'C'
             WHERE Claim_Id = Clmprovision.Claim_Id
               AND Sf_No = Clmprovision.Sf_No
               AND Add_Order_No = Clmprovision.Add_Order_No
               AND Location_Code = Clmprovision.Location_Code
               AND Cover_Code = Clmprovision.Cover_Code
               AND Nvl(Status_Code, 'PP') NOT IN ('R');

            UPDATE Koc_Clm_Hlth_Item_Detail
               SET Status_Code = 'C'
             WHERE Claim_Id = Clmprovision.Claim_Id
               AND Sf_No = Clmprovision.Sf_No
               AND Add_Order_No = Clmprovision.Add_Order_No
               AND Location_Code = Clmprovision.Location_Code
               AND Cover_Code = Clmprovision.Cover_Code
               AND Nvl(Status_Code, 'PP') NOT IN ('R');

            UPDATE Koc_Clm_Vacc_Indem_Totals
               SET Status_Code = 'C'
             WHERE Claim_Id = Clmprovision.Claim_Id
               AND Sf_No = Clmprovision.Sf_No
               AND Add_Order_No = Clmprovision.Add_Order_No
               AND Part_Id = Clmdetail(1).Part_Id
               AND Nvl(Status_Code, 'PP') NOT IN ('R')
               AND Vaccine_Code IN
                   (SELECT b.Vaccine_Code
                      FROM Koc_Clm_Medicine_Indem_Det a,
                           Koc_Cc_Vacc_Medicine_Rel   b
                     WHERE a.Claim_Id = Clmprovision.Claim_Id
                       AND Sf_No = Clmprovision.Sf_No
                       AND Add_Order_No = Clmprovision.Add_Order_No
                       AND a.Location_Code = Clmprovision.Location_Code
                       AND a.Cover_Code = Clmprovision.Cover_Code
                       AND a.Barcode = b.Barcode);*/
                       
          ELSE
             DBMS_OUTPUT.PUT_LINE('Update_Provisions->R');
            /*UPDATE Koc_Clm_Hlth_Provisions
               SET Status_Code      = 'R',
                   Provision_Total  = 0,
                   Exemption_Amount = 0,
                   Sgk_Amount       = 0
             WHERE Claim_Id = Clmprovision.Claim_Id
               AND Sf_No = Clmprovision.Sf_No
               AND Add_Order_No = Clmprovision.Add_Order_No
               AND Location_Code = Clmprovision.Location_Code
               AND Cover_Code = Clmprovision.Cover_Code;

            UPDATE Koc_Clm_Hlth_Proc_Detail
               SET Status_Code = 'R'
             WHERE Claim_Id = Clmprovision.Claim_Id
               AND Sf_No = Clmprovision.Sf_No
               AND Add_Order_No = Clmprovision.Add_Order_No
               AND Location_Code = Clmprovision.Location_Code
               AND Cover_Code = Clmprovision.Cover_Code;

            UPDATE Koc_Clm_Medicine_Indem_Det
               SET Status_Code = 'R'
             WHERE Claim_Id = Clmprovision.Claim_Id
               AND Sf_No = Clmprovision.Sf_No
               AND Add_Order_No = Clmprovision.Add_Order_No
               AND Location_Code = Clmprovision.Location_Code
               AND Cover_Code = Clmprovision.Cover_Code;

            UPDATE Koc_Clm_Hlth_Item_Detail
               SET Status_Code = 'R'
             WHERE Claim_Id = Clmprovision.Claim_Id
               AND Sf_No = Clmprovision.Sf_No
               AND Add_Order_No = Clmprovision.Add_Order_No
               AND Location_Code = Clmprovision.Location_Code
               AND Cover_Code = Clmprovision.Cover_Code;

            UPDATE Koc_Clm_Vacc_Indem_Totals
               SET Status_Code = 'R'
             WHERE Claim_Id = Clmprovision.Claim_Id
               AND Sf_No = Clmprovision.Sf_No
               AND Add_Order_No = Clmprovision.Add_Order_No
               AND Part_Id = Clmdetail(1).Part_Id;*/
          END IF;

          IF Nvl(Clmprovision.Status_Code, 'PP') IN ('P') THEN
            /*Reverseremainig(p_Contract_Id,
                            p_Partition_No,
                            p_Realization_Date,
                            p_User_Id,
                            v_Clmdetail,
                            v_Clmprovision);*/
              DBMS_OUTPUT.PUT_LINE('Reverse_Remaining');
          END IF;
             DBMS_OUTPUT.PUT_LINE('Insert Clm Trans');
          /*v_Trans_No         := Getmaxtransno(Clmdetail(Clmid).Claim_Id,
                                              Clmdetail(Clmid).Sf_No) + 1;
          v_Provision_Amount := 0;
          v_Exemption_Amount := 0;

          OPEN Curprovsum(Clmdetail              (Clmid).Claim_Id,
                          Clmdetail              (Clmid).Sf_No,
                          Clmdetail              (Clmid).Add_Order_No,
                          Clmprovision.Cover_Code);

          FETCH Curprovsum
            INTO Recprovsum;

          CLOSE Curprovsum;

          SELECT MIN(Process_Date)
            INTO v_Muallak_Date
            FROM Koc_Process_Close a
           WHERE a.Process_Type = 'CLMH'
             AND a.Agent_Int_Id = 12354
             AND a.Close_Date >= p_Provision_Date
             AND a.Status_Code = 1;

          v_Trans_Date := Trunc(p_Provision_Date);

          IF v_Muallak_Date > Trunc(p_Provision_Date) THEN
            v_Trans_Date := v_Muallak_Date;
          END IF;

          SELECT Clm_Int_Ref_Seq.Nextval INTO v_Int_Ref FROM Dual;

          SELECT Ext_Reference
            INTO v_Ext_Reference
            FROM Clm_Subfiles
           WHERE Claim_Id = Clmprovision.Claim_Id
             AND Sf_No = 1;

          INSERT INTO Clm_Trans
            (Claim_Id,
             Sf_No,
             Trans_No,
             Movement_Id,
             Assignee,
             Sf_Total_Type,
             Trans_Type,
             Trans_Date,
             Clm_Status,
             Trans_Amt,
             Trans_Amt_Swf,
             Trans_Base_Amt,
             Rsv_Amt,
             Int_Ref,
             Supp_Id,
             Ip_No,
             Oar_No,
             Ext_Reference)
          VALUES
            (Clmprovision.Claim_Id,
             1,
             v_Trans_No,
             1,
             p_User_Id,
             10,
             10,
             v_Trans_Date,
             'TRANS',
             Recprovsum.Provision_Total,
             Clmprovision.Swift_Code,
             Recprovsum.Request_Amount,
             Recprovsum.Refusal_Amount,
             v_Int_Ref,
             Institutinfo.Supp_Id,
             Policyinfo.Ip_No,
             Policyinfo.Partition_No,
             v_Ext_Reference);
            */
         /* BEGIN
            Koc_Clm_Bordro.Alz_Hlth_Bordro_Trans_Log(Clmprovision.Claim_Id,
                                                     v_Trans_No,
                                                     'KOC_CLM_HLTH_TRNX-5274',
                                                     NULL,
                                                     1);
          EXCEPTION
            WHEN OTHERS THEN
              BEGIN
                Koc_Clm_Bordro.Alz_Hlth_Bordro_Trans_Log(Clmprovision.Claim_Id,
                                                         v_Trans_No,
                                                         'KOC_CLM_HLTH_TRNX-5274',
                                                         NULL,
                                                         1,
                                                         Substr(SQLERRM,
                                                                1,
                                                                950));
              EXCEPTION
                WHEN OTHERS THEN
                  NULL;
              END;
          END;*/

          /*INSERT INTO Koc_Clm_Trans_Ext
            (Claim_Id,
             Sf_No,
             Trans_No,
             Exemption_Amount,
             Hlth_Cover_Code,
             Add_Order_No) --,institute_code)
          VALUES
            (Clmprovision.Claim_Id,
             Clmprovision.Sf_No,
             v_Trans_No,
             Recprovsum.Exemption_Amount,
             Clmprovision.Cover_Code,
             Clmprovision.Add_Order_No); --,institutInfo.institute_code);

          --,creditor_name,creditor_address,swift_code,currency_exchange_rate,user_name,ticket_date,ticket_no, payment_approved_date, technical_approved_date, realization_batch_id, realization_ticket_no, realization_ticket_date, realization_user, payment_user, transfer_bank_date, is_account_approved, money_order_address, add_order_no, cause_code)

          -- cc_clm_levels para hareketi ise  "TRANS", de?ilse "SUBFILE"
          SELECT Clm_Status_Id_Seq.Nextval INTO v_Status_Id FROM Dual;

          INSERT INTO Clm_Status_History
            (Status_Id,
             Claim_Id,
             Clm_Line_Id,
             Clm_Level,
             Clm_Status,
             Csh_Date,
             Csh_Username,
             Sf_No,
             Trans_No)
          VALUES
            (v_Status_Id,
             Clmprovision.Claim_Id,
             20,
             'TRANS',
             'CANCELLED',
             Trunc(SYSDATE),
             p_User_Id,
             1,
             v_Trans_No);

          INSERT INTO Koc_Clm_Status_History_Ext
            (Status_Id,
             Claim_Id,
             Sf_No,
             Clm_Status,
             Process_Date,
             Userid,
             Explanation)
          VALUES
            (v_Status_Id,
             Clmprovision.Claim_Id,
             Clmprovision.Sf_No,
             'CANCELLED',
             SYSDATE,
             p_User_Id,
             NULL);*/
             DBMS_OUTPUT.PUT_LINE('insert history:CANCELLED');
        END IF;
      END LOOP;

    --SBH-1364 mustafaku    kocclm300 de de silindi�i i�in rakam s�f�rlanmadan silindi.
    --Provizyon yada ASO teminat� revizyon ve iptallerinde, ASO giri� ekran�ndaki ASO tutarlar�n�n s�f�rlanmas�
    /*DELETE FROM Koc_Clm_Hlth_Aso_Prov
     WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
       AND Sf_No = Clmdetail(Clmid).Sf_No
       AND Add_Order_No = Clmdetail(Clmid).Add_Order_No;
    --SBH-1364 mustafaku
    */

      SELECT COUNT(*)
        INTO v_Cnt
        FROM Koc_Clm_Hlth_Provisions
       WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
         AND Sf_No = Clmdetail(Clmid).Sf_No
         AND Add_Order_No = Clmdetail(Clmid).Add_Order_No
         AND Nvl(Status_Code, 'PP') NOT IN ('C', 'R');

      SELECT COUNT(*)
        INTO v_Cnt_All
        FROM Koc_Clm_Hlth_Provisions
       WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
         AND Sf_No = Clmdetail(Clmid).Sf_No
         AND Nvl(Status_Code, 'PP') NOT IN ('C', 'R');

      v_Detail_Del_Status := 'C';

      IF p_Del_Or_Rej IN (2, 4) THEN
        DBMS_OUTPUT.PUT_LINE('change_del_status:'||v_Detail_Del_Status||'->R');
        v_Detail_Del_Status := 'R';
      END IF;

      --
      IF v_Cnt = 0 AND p_Del_Or_Rej IN (1, 2) THEN
        UPDATE Koc_Clm_Hlth_Detail
           SET Status_Code = v_Detail_Del_Status,
               Close_Date  = Trunc(SYSDATE)
         WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
           AND Sf_No = Clmdetail(Clmid).Sf_No
           AND Add_Order_No = Clmdetail(Clmid).Add_Order_No;
       
       DBMS_OUTPUT.PUT_LINE('update_detail:'||SQL%ROWCOUNT);
        
        UPDATE Koc_Clm_Hlth_Prov_Statemnt
           SET Status_Code = v_Detail_Del_Status
         WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
           AND Sf_No = Clmdetail(Clmid).Sf_No
           AND Entry_Date =
               (SELECT MAX(Entry_Date)
                  FROM Koc_Clm_Hlth_Prov_Statemnt
                 WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
                   AND Sf_No = Clmdetail(Clmid).Sf_No);
        DBMS_OUTPUT.PUT_LINE('update_statement:'||SQL%ROWCOUNT);           

        IF v_Cnt_All = 0 THEN
          UPDATE Clm_Subfiles
             SET Clm_Status = 'CANCELLED'
           WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
             AND Sf_No = Clmdetail(Clmid).Sf_No;
            DBMS_OUTPUT.PUT_LINE('update_subfiles:'||SQL%ROWCOUNT);
             
        END IF;

        BEGIN
          DBMS_OUTPUT.PUT_LINE('Insert_Indem_dec:'||v_Detail_Del_Status);
          /*INSERT INTO Koc_Clm_Hlth_Indem_Dec
            (Claim_Id,
             Sf_No,
             Add_Order_No,
             Process_Date,
             File_Agreement_Code,
             Explanation,
             Userid)
          VALUES
            (Clmdetail(Clmid).Claim_Id,
             Clmdetail(Clmid).Sf_No,
             Clmdetail(Clmid).Add_Order_No,
             SYSDATE,
             v_Detail_Del_Status,
             p_Cancelation_Exp,
             p_User_Id);*/
        EXCEPTION
          WHEN Dup_Val_On_Index THEN
            NULL;
        END;
      END IF;
    END IF;

    
    ------ red mektuplari i�in kayit atiliyor.
   /* SELECT COUNT(*)
      INTO v_Cnt
      FROM Koc_Clm_Hlth_Reject_Loss
     WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
       AND Sf_No = Clmdetail(Clmid).Sf_No
       AND Add_Order_No = Clmdetail(Clmid).Add_Order_No;

    IF v_Cnt > 0 THEN
      SELECT COUNT(*)
        INTO v_Cnt
        FROM Koc_Clm_Ltr_Doc_Process
       WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
         AND Sf_No = Clmdetail(Clmid).Sf_No
         AND Add_Order_No = Clmdetail(Clmid).Add_Order_No
         AND Letter_Type = 3;

      IF v_Cnt <= 0 THEN
        SELECT Nvl(MAX(Letter_No), 0) + 1
          INTO v_Letter_No
          FROM Koc_Clm_Ltr_Doc_Process
         WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
           AND Sf_No = Clmdetail(Clmid).Sf_No
           AND Add_Order_No = Clmdetail(Clmid).Add_Order_No;

        INSERT INTO Koc_Clm_Ltr_Doc_Process
          (Claim_Id,
           Sf_No,
           Add_Order_No,
           Letter_No,
           Letter_Type,
           Letter_Occurence_Date)
        VALUES
          (Clmdetail(Clmid).Claim_Id,
           Clmdetail(Clmid).Sf_No,
           Clmdetail(Clmid).Add_Order_No,
           v_Letter_No,
           3,
           Trunc(SYSDATE));
      END IF;
    END IF;
*/
    -- KEKS  iptalde red tutarini sifirla.
    UPDATE Koc_Clm_Hlth_Reject_Loss
       SET Refuse_Explanation = Refuse_Explanation || '(REFUSE_AMOUNT:' ||
                                Refuse_Amount || ' User_id:' || p_User_Id || ')',
           Refuse_Amount      = 0
     WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
       AND Sf_No = Clmdetail(Clmid).Sf_No
       AND Add_Order_No = Clmdetail(Clmid).Add_Order_No
       AND Cover_Code = p_Cover_Code
       AND Location_Code = p_Location_Code;
    
    DBMS_OUTPUT.PUT_LINE('update_reject_loss:'||SQL%ROWCOUNT);
    
    UPDATE Koc_Clm_Hlth_Provisions b
       SET b.Refusal_Amount = 0
     WHERE b.Claim_Id = Clmdetail(Clmid).Claim_Id
       AND b.Sf_No = Clmdetail(Clmid).Sf_No
       AND b.Add_Order_No = Clmdetail(Clmid).Add_Order_No
       AND b.Cover_Code = p_Cover_Code;
       
    DBMS_OUTPUT.PUT_LINE('update_provisions:'||SQL%ROWCOUNT);

    --KESK

    -->02/04/2008 yetki limitleri ile ilgili ekleme B�
    --BEGIN
      DELETE FROM Koc_Clm_Hlth_Prov_Limit
       WHERE Claim_Id = Clmdetail(Clmid).Claim_Id
         AND Sf_No = Clmdetail(Clmid).Sf_No
         AND Add_Order_No = Clmdetail(Clmid).Add_Order_No;
         DBMS_OUTPUT.PUT_LINE('delete_prov_limit:'||SQL%ROWCOUNT);

   -- END;

    --<02/04/2008 yetki limitleri ile ilgili ekleme B�
    --saglik muallak calismasi 22.02.2011 aysel
    /*Hlth_Clm_Check(Clmdetail(Clmid).Claim_Id,
                   Clmdetail(Clmid).Sf_No,
                   Clmdetail(Clmid).Add_Order_No);*/
    DBMS_OUTPUT.PUT_LINE('Hlth_Clm_Check');                  


    
  END Delete_Provisions;
  
  BEGIN
    
     FOR rec IN (SELECT  Provision_Date,
                         Date_Of_Loss,   
                         Invoice_Date,
                         Part_Id,
                         Institute_Code,
                         Claim_Id,
                         Sf_No,
                         Add_Order_No,
                         Status_Code
                  FROM koc_clm_hlth_detail
                 WHERE ext_reference = '57001826') LOOP
                  
            Clmdetail(1).Provision_Date := rec.Provision_Date;
            Clmdetail(1).Date_Of_Loss   := rec.Date_Of_Loss;
            Clmdetail(1).Invoice_Date   := rec.Invoice_Date;
            Clmdetail(1).Part_Id   := rec.Part_Id;
            Clmdetail(1).Institute_Code   := rec.Institute_Code;
            Clmdetail(1).Claim_Id   := rec.Claim_Id;
            Clmdetail(1).Sf_No   := rec.Sf_No;
            Clmdetail(1).Add_Order_No   := rec.Add_Order_No;
            Clmdetail(1).Status_Code := rec.Status_Code;
            
    END LOOP;
    
    DELETE_PROVISIONS(450171395,
                      2,
                      TO_DATE('12/04/2019 08:06:00','DD/MM/YYYY HH24:MI:SS') ,
                      NULL,
                      NULL,
                      'ADEMO',
                      2,
                      Clmdetail,
                      NULL);
                      
    END;
