update hst_cc_web_inst_doctor h
   set h.doctor_identity_no = (select distinct doctor_identity_no from ademo.doctor_info@opusdev where doctor_code=h.doctor_code)
 where h.doctor_code in (select distinct doctor_code from ademo.doctor_info@opusdev) 
   and h.doctor_identity_no is null and  nvl(doctor_source, 'PORTAL') = 'PORTAL'
/
COMMIT
/   
