declare
  
 v_hclm_usage NUMBER;
 
 begin
   
 v_hclm_usage := ALZ_HCLM_CONVERTER_UTILS.getHclmUsage(null, null, null, NULL,null, null);
 
 dbms_output.put_line('hclm_usage:'||v_hclm_usage);
 
 end;
