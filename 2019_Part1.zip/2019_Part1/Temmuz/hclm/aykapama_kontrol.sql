select * from koc_process_close where process_date=TO_DATE('01/08/2019','DD/MM/YYYY') and process_type IN ('ACCH','CLOH') for update

select koc_clm_hlth_trnx.isMonthClosedForClm(TO_DATE('01/07/2019','DD/MM/YYYY')) from dual;

 SELECT *--Decode(Status_Code, 1, 0, 1)
    --  INTO v_Result
      FROM Koc_Process_Close
     WHERE Process_Type = 'ACCH'
       AND Agent_Int_Id = 12354
       AND TO_DATE('01/01/2020','DD/MM/YYYY') BETWEEN Process_Date AND Close_Date;
