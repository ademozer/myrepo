SELECT * FROM KOC_AUTHORIZATION_ROLE_DEF WHERE ROLE_CODE='HCLMPROV' FOR UPDATE

SELECT * from koc_auth_user_role_rel where username='WARTOSUN' and role_code='HCLMPROV' FOR UPDATE

SELECT * from koc_auth_user_role_rel where username='WEBLOGIC'

select * from koc_auth_user_role_rel a where not exists (select 1 from web_sec_system_users b where b.user_name=a.username) and a.username like 'WS%'

select * from web_sec_system_users where user_name='WEBLOGIC'

SELECT ALZ_HCLM_CONVERTER_UTILS.getHclmUsage(null, null, null, 'WS', NULL, NULL) FROM DUAL;


--SELECT * from koc_auth_user_role_rel where username='HBATMAZ';

select * from koc_clm_hlth_provisions p where time_stamp>TO_DATE('10/07/2019','DD/MM/YYYY') and refusal_amount>0 and sgk_amount>0 and status_code NOT IN('R','C')
and not exists (select 1 from koc_clm_web_auth_pool where claim_id=p.claim_id)

select * from koc_clm_hlth_detail where claim_id=41572640--41087016;

select * from customer.alz_duplicate_provision where ext_reference='57723805';

select * from alz_hltprv_log where log_id=128685612--126138062

select * from koc_clm_hlth_detail where ext_reference='57723805' for update;
select * from koc_clm_hlth_provisions where claim_id=41414985--41905039 for update
select * from clm_pol_oar where contract_id=400797581 and oar_no=909 order by 1--claim_id=41414985
 
select * from clm_subfiles where claim_id=32750128--39296656--42070436;

select *--contract_id,partition_no,country_group,claim_inst_type,claim_inst_loc,cover_code,package_id,package_date,validity_start_date,validity_end_date,is_valid 
from koc_clm_hlth_indem_totals where contract_id=400797581 and partition_no=909 and cover_code='S520';
select * from koc_ocp_risk_packages where contract_id=400797581 and partition_no=909 

select * from koc_clm_hlth_indem_totals where contract_id=302481466 and partition_no=112 and cover_code IN ('ST534','S520','ST533') 

--57848007
select * from koc_ocp_pol_versions_ext where contract_id=400797581 and version_no=20;

select * from hst_cc_web_inst_doctor where doctor_name='BE��R' and doctor_surname='KES�C�';
select * from hst_cc_web_inst_doctor where doctor_code=223227;
select * from alz_hltprv_log where log_id=133399319;

select * from koc_cc_web_inst_doctor where doctor_identity_no='11735399468'
select * from hst_cc_web_inst_doctor where doctor_code=263309
select * from Alz_Branch_Code_Cgm_Rel where branchcodeallz=1370;


select * from koc_clm_hlth_provisions p where time_stamp>TO_DATE('01/07/2019','DD/MM/YYYY') 
and cover_code='ST504' and req_cure_day_count>0
and exists (select 1 from koc_clm_hlth_detail d,koc_clm_hlth_indem_totals i, clm_pol_oar o
            where d.claim_id = p.claim_id and o.claim_id = p.claim_id 
            and i.contract_id=o.contract_id and i.partition_no=o.oar_no and i.package_id=d.package_id and i.cover_code IN('ST533','S520')
            and i.f_day_seance > 0
            )
--and refusal_amount>0 and sgk_amount>0 and status_code NOT IN('R','C')


select * from koc_oc_hlth_pack_cov_rel a where child_cover_code='ST504'
and exists (select 1 from koc_oc_hlth_pack_cov_rel b where a.package_id=b.package_id and a.package_date=b.package_date and b.child_cover_code='S520')

