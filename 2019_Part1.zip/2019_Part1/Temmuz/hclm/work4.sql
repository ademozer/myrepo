select * from alz_hclm_institute_info for update;

select * from ocp_policy_bases where policy_ref='0001171006127432';
select * from ocp_policy_bases where contract_id=319311573

select * from wip_koc_ocp_health where contract_id=401809071 and partition_no=1168--and family_code=573--319311573 and family_name='ERDAL'

select * from koc_ocp_pol_contracts_ext where contract_id=319311573
select * from koc_v_health_insured_info where partner_id=112097992--contract_id=319311573 and partition_no=741
select * from cp_partners where part_id=112097992
select * from koc_cp_partners_ext where identity_no='46072365340'
select * from ocq_quotes;

SELECT *
                FROM Hst_Cc_Web_Inst_Doctor
             WHERE 1=1 --Institute_Code = Pinstitutecode
                 --AND Specialty_Subject = Pspecialtysubject
                 --AND Doctor_Name || ' ' || Doctor_Surname = Pnamesurname
                -- AND TRANSLATE(UPPER(Doctor_Name || ' ' || Doctor_Surname),'�','I') = TRANSLATE(UPPER(Pnamesurname),'�','I') --ademo.SBH-2586
               --  AND Pnamesurname IS NOT NULL
                -- AND TRANSLATE(UPPER(Doctor_Name || ' ' || Doctor_Surname),'�','I') = TRANSLATE(UPPER('figen ta�er'),'�','I')
                 AND NLS_UPPER(Doctor_Name || ' ' || Doctor_Surname, 'nls_sort=xturkish') = NLS_UPPER('figen ta�er','nls_sort=xturkish')
                 AND Validity_End_Date IS NULL

   select * from koc_ocp_health a where a.contract_id =401809071 and top_indicator = 'Y';
   
   
   	ALZ_GHLTH_SEARCH_UTILS.Get_Dashboard_Search_Lists(p_User,v_Ghlth_Ppa_Srch_Cri_Rec,V_Srch_DB_Rec);
   
   select *from ocp_partitions where contract_id=401809071 and partition_no=698
   
            AND action_code <> 'D' and a.partition_no not in (select b.partition_no from ocp_partitions b where b.contract_id = a.contract_id AND top_indicator = 'Y'
            AND action_code <> 'D');
