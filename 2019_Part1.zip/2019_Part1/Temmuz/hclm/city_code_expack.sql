SELECT EXEMPTION_RATE,INSTITUTE_CODE,CITY_CODE
           FROM koc_oc_hlth_expack_cov_rel
          WHERE /*rownum <2  and*/
          main_rule_code = '3'
       and sub_rule_code = '30'
       AND CHILD_COVER_CODE = 'S511'
       AND CLAIM_INST_LOC = 'YI'
       AND CLAIM_INST_TYPE = 'AHK'
       AND CONTRACT_ID = TO_NUMBER('0')
       AND COUNTRY_GROUP = TO_NUMBER('0')
       AND COVER_CAT_GROUP = '0'
       AND INSTITUTE_TYPE = '0'
       AND INST_COV_TYPE = '0'
       AND INST_VALIDITY_TYPE = '0'
       AND IS_POOL_COVER = TO_NUMBER('0')
       AND IS_SPECIAL_COVER = TO_NUMBER('0')
       AND PACKAGE_DATE = TO_DATE('31/12/2018', 'DD/MM/YYYY')
       AND PACKAGE_ID = TO_NUMBER('260532')
       AND PARTITION_NO = TO_NUMBER('0')
       AND PARTITION_TYPE = '0'
       AND PART_ID = TO_NUMBER('0')
       AND PRODUCT_ID = TO_NUMBER('0')
       AND ((CITY_CODE = '00') OR (SPEC_GROUP_CODE = TO_NUMBER('1')) OR
          (INSTITUDE_GROUP_CODE = TO_NUMBER('')) OR
          (INSTITUTE_CODE = TO_NUMBER('20000')))
          ORDER BY nvl(column_priority, 0) DESC
          
         -- select * from koc_mv_skrm_suppliers where institute_code='20000';
         
         koc_clm_hlth_trnx;
        


 SELECT Lpad(s.City_Code, 3, '0'),s.city_code, s.Country_Code
              --INTO p_City_Code, p_Country_Code
              FROM Koc_Clm_Suppliers_Ext b,
                   Clm_Suppliers         c,
                   Koc_Cp_Address_Links  k,
                   Koc_Cp_v_Addresses    s
             WHERE b.Institute_Code = '20000'
               AND c.Supp_Id = b.Supp_Id
               AND c.Supp_Type = 'SKRM'
               AND k.Part_Id = c.Part_Id
               AND SYSDATE BETWEEN k.From_Date AND Nvl(k.To_Date, SYSDATE)
               AND s.Add_Id = k.Add_Id
               AND s.City_Code IS NOT NULL
               AND c.Eff_Date = (SELECT MIN(t.Eff_Date)
                                   FROM Clm_Suppliers t
                                  WHERE c.Supp_Id = t.Supp_Id)
