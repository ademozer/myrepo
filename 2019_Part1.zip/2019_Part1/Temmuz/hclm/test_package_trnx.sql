 DECLARE
  v_claim_id NUMBER;
  v_medula_date DATE := SYSDATE;
  v_Provision_Date DATE := SYSDATE;
  Cur KOC_CLM_HLTH_TRNX.Refcur;
  Policyinfo                 Koc_v_Hlth_Insured_Info_Indem%ROWTYPE; 
  v_ext_reference VARCHAR2(100) := '58106431';
  
  PROCEDURE Getpolinfoforindembyclm_Trnx(p_Claim_Id NUMBER,
                                         p_Date     DATE,
                                         Cur        IN OUT KOC_CLM_HLTH_TRNX.Refcur) IS
    v_Contract_Id  NUMBER := 0;
    v_Partition_No NUMBER := 0;
    v_Part_Id      NUMBER := 0;
    v_Ip_No        NUMBER;
    v_Package_Id   NUMBER;
    v_Package_Date DATE;
  BEGIN
    BEGIN
      SELECT b.Contract_Id,
             b.Oar_No,
             c.Part_Id,
             c.Ip_No,
             Package_Id,
             Package_Date
        INTO v_Contract_Id,
             v_Partition_No,
             v_Part_Id,
             v_Ip_No,
             v_Package_Id,
             v_Package_Date
        FROM Koc_Clm_Hlth_Detail a, Clm_Pol_Oar b, Clm_Interested_Parties c
       WHERE a.Claim_Id = b.Claim_Id
         AND a.Claim_Id = p_Claim_Id
         AND a.Claim_Id = c.Claim_Id
         AND Rownum < 2;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
        dbms_output.put_line('Hata.1'||SQLERRM);
    END;

    IF v_Package_Id IS NOT NULL AND v_Package_Date IS NOT NULL THEN
      OPEN Cur FOR
        SELECT a.*
          FROM Koc_v_Hlth_Insured_Info_Indem a
         WHERE a.Contract_Id = v_Contract_Id
           AND a.Partition_No = v_Partition_No
           AND a.Partner_Id = v_Part_Id
           AND a.Ip_No = v_Ip_No
           AND a.Package_Id = v_Package_Id
           AND a.Package_Date = v_Package_Date;
           DBMS_OUTPUT.PUT_LINE('b1:contract_id='||v_Contract_Id||' partition_no ='||v_Partition_No);
           DBMS_OUTPUT.PUT_LINE('part_id='||v_Part_Id||' ip_no ='||v_Ip_No);
           DBMS_OUTPUT.PUT_LINE('pack_id='||v_Package_Id||' pack_date ='||v_Package_Date); 
    ELSE
         DBMS_OUTPUT.PUT_LINE('b2');
      OPEN Cur FOR
        SELECT a.*
          FROM Koc_v_Hlth_Insured_Info_Indem a
         WHERE a.Contract_Id = v_Contract_Id
           AND a.Partition_No = v_Partition_No
           AND a.Partner_Id = v_Part_Id
           AND a.Ip_No = v_Ip_No
           AND EXISTS
         (SELECT NULL
                  FROM Koc_Clm_Hlth_Indem_Totals i
                 WHERE i. Contract_Id = a.Contract_Id
                   AND i.Partition_No = a.Partition_No
                   AND a.Package_Id = i.Package_Id
                   AND a.Package_Date = i.Package_Date
                   AND Nvl(p_Date, SYSDATE) BETWEEN i.Validity_Start_Date AND
                       i.Validity_End_Date --neslihank 31072017 plan de�i�ikli�i g�rm�� planlar i�in bu kontrol eklenmi�tir.
                   AND i.Is_Valid = 1);
    END IF;
  END;
  
 BEGIN
   
  SELECT claim_id, medula_date, provision_date
     INTO v_claim_id, v_medula_date, v_provision_date
    FROM koc_clm_hlth_detail
   WHERE ext_reference = v_ext_reference;
   
  --KOC_CLM_HLTH_TRNX.
  Getpolinfoforindembyclm_Trnx(v_Claim_Id,
                                   nvl(v_medula_date, v_Provision_Date ),
                                   Cur);
      FETCH Cur
        INTO Policyinfo;

      CLOSE Cur;
   
  DBMS_OUTPUT.PUT_LINE('Policy_Info.Contract_Id = '||Policyinfo.Contract_Id);
  
  EXCEPTION
  WHEN OTHERS THEN
     DBMS_OUTPUT.PUT_LINE('Hata:'||SQLERRM);
  END;
