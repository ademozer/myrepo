DECLARE
bk_data KOC_CLM_HLTH_UTILS.PROVDISEASERECTYPE;
v_CONTRACT_ID NUMBER :=441137722;--426737758;
v_PARTITION_NO      NUMBER := 1;
v_PART_ID     NUMBER :=  43797304;
v_PRODUCT_ID  NUMBER := 63;
v_PARTITION_TYPE   VARCHAR2(10) := 'MDSG';
v_GROUP_CODE  VARCHAR2(10) := NULL;
v_SUB_COMPANY_CODE VARCHAR2(10) := NULL;
v_DISEASE_DATE DATE := TO_DATE('25/12/2018 00:00:01','DD/MM/YYYY HH24:MI:SS');

BEGIN
koc_clm_hlth_utils.getdiesaesnotesforprov(v_CONTRACT_ID, 
                                          v_PARTITION_NO, 
                                          v_PART_ID, 
                                          v_PRODUCT_ID, 
                                          v_PARTITION_TYPE, 
                                          v_GROUP_CODE, 
                                          v_SUB_COMPANY_CODE, 
                                          v_DISEASE_DATE,
                                          bk_data);
--PLSQL_TABLE.POPULATE_BLOCK(bk_data, 'UWP_DISEASE_NOTES');
/*
Contract_Id       NUMBER,
    Partition_No      NUMBER,
    Part_Id           NUMBER,
    Product_Id        NUMBER,
    Partition_Type    VARCHAR2(10),
    Group_Code        VARCHAR2(10),
    Sub_Company_Code  VARCHAR2(10),
    Message           VARCHAR2(2000),
    Modified_Hep_Rate NUMBER,
    Application_Code  VARCHAR2(3),
    Uw_Disease_Code   VARCHAR2(10)
*/

FOR ndx IN 1..bk_data.COUNT LOOP
   DBMS_OUTPUT.PUT_LINE('App_Code   ='||bk_data(ndx).Application_Code);
   DBMS_OUTPUT.PUT_LINE('Uwp_Disease='||bk_data(ndx).Uw_Disease_Code);
   DBMS_OUTPUT.PUT_LINE('Message='||bk_data(ndx).Message);
END LOOP;
  

EXCEPTION 
WHEN OTHERS THEN
  DBMS_OUTPUT.PUT_LINE('Hata:'||SQLERRM);
END;

--SELECT * FROM koc_clm_hlth_detail where ext_reference  IN ('58106433','58106431');

--SELECT * FROM CLM_POL_OAR WHERE claim_id=41904816
