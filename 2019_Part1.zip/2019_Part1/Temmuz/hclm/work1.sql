select * from alz_hltprv_log where insuredno='56793308' and insurednotype='EXT_REFERENCE'
select * from clm_subfiles where ext_reference='56793308'
select * from alz_hclm_version_info where claim_id = 40183758
select * from alz_hltprv_log where log_id = 118822438;

koc_clm_hlth_trnx.isMonthClosedForClm;

SELECT *--Decode(Status_Code, 1, 0, 1)
      --INTO v_Result
      FROM Koc_Process_Close
     WHERE Process_Type IN('CLOH','ACCH')
       AND Agent_Int_Id = 12354
       AND Process_Date > trunc(sysdate)
       for update
      -- AND p_Date BETWEEN Process_Date AND Close_Date;
      
      
      select * from Koc_v_Cp_Health_Look_Up where look_up_code='HSTP'
      
      
      select * from koc_clm_suppliers_ext where institute_group_code_type_2='8'
      SELECT ins_grp.GROUP_CODE TYPE_CODE, ins_grp.GROUP_NAME TYPE_DESCRIPTION 
  FROM KOC_HLTH_INSTITUTE_GRP_TYPE_2 ins_grp 
 WHERE TRUNC (SYSDATE) BETWEEN TRUNC (ins_grp.validity_start_date) 
   AND TRUNC (NVL (ins_grp.validity_end_date, TO_DATE ('01.01.3000', 'dd.mm.yyyy')))


select * from alz_hltprv_log where log_id=130661320--130661315--129923997;

Select * from Alz_Branch_Code_Cgm_Rel where branchcodecgm=1078;

select * from all_source where lower(text) like '%Kullan�c�/Kurum bilgileri yanl��%'

select * from koc_mv_skrm_suppliers where institute_code IN('3255','6089')--institute_skrs_code='514177'

select * from all_tables where owner='CUSTOMER' and table_name like '%CONVERT%'
select * from ALZ_HLTPRV_PROCESS_CONVERT_MAP where institute_code IN('6089','937598') for update


update Koc_Clm_Suppliers_Ext set Institute_Skrs_Code = 937598 where institute_code = 6089;


koc_clm_hlth_trnx2.updateClmTransBank

select * from  Koc_Clm_Suppliers_Ext@opusdev where institute_code in('6089','3255');




select p.par_value 
from alz_general_lists_par p 
where p.par_name='TUTAR' 
and exists (SELECT 1 FROM alz_general_lists_column c,
alz_general_lists_col_val v
WHERE c.col_id = v.col_id
AND v.list_id = p.list_id
AND v.list_seq = p.list_seq
AND c.col_name = 'DOCTOR_IDENTITY_NO' 
AND v.col_value='15365408002') --:doctorIdentityNo 
and exists (SELECT 1 FROM alz_general_lists_column c,
alz_general_lists_col_val v
WHERE c.col_id = v.col_id
AND v.list_id = p.list_id
AND v.list_seq = p.list_seq
AND c.col_name = 'PROCESS_TYPE' 
AND v.col_value='10.10.101') --:processCodeMain :processCodeSub1 :processCodeSub2
and exists (SELECT 1 FROM alz_general_lists_column c,
alz_general_lists_col_val v
WHERE c.col_id = v.col_id
AND v.list_id = p.list_id
AND v.list_seq = p.list_seq
AND c.col_name = 'INSTITUTE_CODE' 
AND v.col_value='3255') 


SELECT * FROM alz_general_lists_column c,
alz_general_lists_col_val v
WHERE c.col_id = v.col_id
AND v.list_id = 1
AND v.list_seq = 1
AND c.col_name = 'INSTITUTE_CODE' 
AND v.col_value='3255'


select EXT_REFERENCE,IS_PREGNANT from Koc_Clm_Hlth_Detail where ext_reference IN('56793752','56793758') 
