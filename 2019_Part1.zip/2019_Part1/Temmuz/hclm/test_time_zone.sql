DECLARE
 v_date_str VARCHAR2(100);
 
 /*
 DECLARE
      A TIMESTAMP WITH TIME ZONE;
      B TIMESTAMP WITH TIME ZONE;
      C TIMESTAMP WITH TIME ZONE;
   BEGIN
      --C := TO_TIMESTAMP_TZ('2015-03-03 00:00:00.000','YYYY-MM-DD HH24:MI:SS.FF3 TZR TZD');
      --DBMS_OUTPUT.PUT_LINE(TO_CHAR(C,'YYYY-MM-DD HH:MI:SS.FF3 TZH:TZM'));
      C := TO_TIMESTAMP_TZ('2017-03-03 00:00:00.000 Europe/Istanbul','YYYY-MM-DD HH24:MI:SS.FF3 TZR');
      DBMS_OUTPUT.PUT_LINE(TO_CHAR(C,'TZH:TZM'));
END;
 */
FUNCTION dateToString(p_date IN DATE) RETURN VARCHAR2 IS
          v_date  DATE;
          v_timestamp TIMESTAMP;
          v_return VARCHAR2(100);
          v_timezone VARCHAR2(20);
    BEGIN
        v_return := '';
        v_date := p_date;
        IF v_date IS NOT NULL THEN
           IF v_date > TO_DATE('2017','YYYY') THEN
               v_timezone := dbtimezone;
           ELSE
               v_timezone := TO_CHAR(TO_TIMESTAMP_TZ(TO_CHAR(v_date,'YYYY-MM-DD')||' Europe/Istanbul','YYYY-MM-DD TZR'),'TZH:TZM');
           END IF;
           v_timestamp := CAST (v_date AS TIMESTAMP WITH LOCAL TIME ZONE);
           --v_return := TO_CHAR(v_timestamp, 'YYYY-MM-DDHH24:MI:SS.FFTZH:TZM');--TO_CHAR(v_date,'YYYY-MM-DD')||'T'||TO_CHAR(v_timestamp,'HH24:MI:SS.FF3')||dbtimezone;
           v_return := TO_CHAR(v_date,'YYYY-MM-DD')||'T'||TO_CHAR(v_timestamp,'HH24:MI:SS.FF3')||v_timezone;--dbtimezone;
        END IF;
        RETURN v_return;
    END dateToString;

BEGIN
  
v_date_str := dateToString(TO_DATE('25/04/2016','DD/MM/YYYY'));

DBMS_OUTPUT.PUT_LINE(v_date_str);

END;

-- SELECT SESSIONTIMEZONE FROM DUAL;
--SELECT TO_TIMESTAMP_TZ('2015-02-01 12:00:00', 'YYYY-MM-DD HH:MI:SS') FROM DUAL;
--SELECT TO_TIMESTAMP_TZ('03/03/2015 00:00:00','DD/MM/YYYY HH:MI:SS') FROM DUAL;
