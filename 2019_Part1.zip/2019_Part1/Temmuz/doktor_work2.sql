create table doctor_info as   
select k.doctor_code,h.doctor_source, h.validity_start_date,h.validity_end_date,h.doctor_identity_no, k.doctor_identity_no from koc_cc_web_inst_doctor k, hst_cc_web_inst_doctor h
 where k.doctor_code = h.doctor_code
   --and k.doctor_identity_no != h.doctor_identity_no
   and h.doctor_identity_no is null
   and k.doctor_identity_no is not null
  -- and k.specialty_subject = h.specialty_subject
   and nvl(k.doctor_source, 'PORTAL') = 'PORTAL'
  -- and nvl(h.doctor_source, 'PORTAL') != 'PORTAL'
   and k.validity_end_date is null
   and exists(select 1 from hst_cc_web_inst_doctor where doctor_code = h.doctor_code and doctor_source='PORTAL')
   --and k.doctor_code=181406
   --and h.doctor_code = 232144
--   and h.validity_end_date is not null; 
 
update hst_cc_web_inst_doctor h
   set doctor_identity_no = (select doctor_identity_no from koc_cc_web_inst_doctor k where k.doctor_code = h.doctor_code and k.doctor_identity_no is not null and k.validity_end_date IS NULL)
 where nvl(h.doctor_source, 'PORTAL') = 'PORTAL'
   and h.doctor_identity_no is null
   and exists(select 1 from koc_cc_web_inst_doctor k where k.doctor_code=h.doctor_code and k.doctor_identity_no is not null and k.validity_end_date is null)
  
   
 select count(*) from hst_cc_web_inst_doctor h where nvl(h.doctor_source, 'PORTAL') = 'PORTAL'
    and h.doctor_identity_no is null
    and exists(select 1 from koc_cc_web_inst_doctor k where k.doctor_code=h.doctor_code and k.doctor_identity_no is not null and k.validity_end_date is null)
    
    
    
    select doctor_code,brans_koc,brans_his,count(*) from doctor_info2
    group by doctor_code,brans_koc,brans_his
    having count(*)>7
    
    select doctor_code, count(*) from doctor_info
    group by doctor_code
    having count(*)>7
    
    select doctor_code from doctor_info2
    minus
    select doctor_code from doctor_info
    
    where doctor_code=232057
    
    drop table doctor_info
    
    select * from hst_cc_web_inst_doctor@opusprep where doctor_code=71945
   
   select * from koc_clm_hlth_detail where doctor_code=71945 order by process_date desc
    
    select * from ademo.doctor_info@opusdev where doctor_identity_no=48121507930
    select * from hst_cc_web_inst_doctor@opusdev  where doctor_code=  2957--doctor_identity_no='48121507930'
    232144
    
    select count(*) from hst_cc_web_inst_doctor@opusprep where doctor_code in(select doctor_code from doctor_info) 
    and doctor_identity_no is null and  nvl(doctor_source, 'PORTAL') = 'PORTAL'
    
    grant select on doctor_info to public
    
    select count(*) from hst_cc_web_inst_doctor where doctor_code in(select doctor_code from ademo.doctor_info@opusdev) 
    and doctor_identity_no is null and  nvl(doctor_source, 'PORTAL') = 'PORTAL'
    
    
    update hst_cc_web_inst_doctor h
       set doctor_identity_no = (select distinct doctor_identity_no from ademo.doctor_info@opusdev where doctor_code=h.doctor_code)
     where doctor_code in(select doctor_code from ademo.doctor_info@opusdev) 
       and doctor_identity_no is null and  nvl(doctor_source, 'PORTAL') = 'PORTAL'
       
       select doctor_identity_no,count(*) from ademo.doctor_info@opusdev group by doctor_identity_no 
       select * from  ademo.doctor_info@opusdev where doctor_identity_no=46696721416
       
       1 234   8/22/2009 8/24/2009   40621561016
2 2963    1/11/2010 3/23/2010   10691542222
3 231   8/22/2009 8/24/2009   29483398220
4 1654    12/14/2009  12/17/2009    11080287816
5 2955    1/11/2010 3/23/2010   13439930664
6 2943    4/17/2009 3/23/2010   44857365844
7 3554    2/13/2010 2/26/2010   30506235958
8 262   8/24/2009 8/24/2009   22145384852
9 2959    1/11/2010 3/23/2010   13280111670
10  278   2/11/2008 8/24/2009   59938371768
11  2822    6/21/2009 3/23/2010   11648976114
12  2957    1/11/2010 3/23/2010   40036581456

       
       select * from  ademo.doctor_info@opusdev where doctor_code=71945; --for update;
       
       ALZ_HCLM_CONVERTER_UTILS
