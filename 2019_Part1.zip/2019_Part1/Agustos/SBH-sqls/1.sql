ALZ_HCLM_CONVERTER_UTILS;

ALZ_TOBB_USER

select * from alz_hclm_version_info where claim_id=41905772--41905713
select * from koc_clm_hlth_detail where ext_reference='58107478' in ('58107433','58107424');

select * from alz_hltprv_log where log_date>sysdate-2 and insuredno='58107478' and insurednotype='EXT_REFERENCE' order by log_id
select * from alz_hltprv_log where log_id=132463165;

SELECT Koc_Clm_Hlth_Utils.Is_Same_Network(472566077, 1, sysdate, 8) FROM DUAL ;

select * from koc_clm_hlth_reject_loss where barcode!=0
