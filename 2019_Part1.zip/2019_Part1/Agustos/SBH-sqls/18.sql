 customer.alz_hlth_karma_utils.process_price_control (4974, 'S-AT-G�Z', '17/06/2019', 'TM', 'S5001', 'GRUP_OZEL', '35', 48,6, , v_price_return);
 
         SELECT Institute_Code,
               NULL Group_Code,
               Price_Type,
               NULL Network_Id,             
               Add_Unit Oss_Add_Unit,
               Add_Price Oss_Add_Price,
               Tss_Add_Unit,
               Tss_Add_Rate,
               Tss_Add_Price,
               Ahek_Add_Rate,
               Academic_Add_Rate,
               Validity_Start_Date,
               Validity_End_Date,
               process_group
          FROM Koc_Cc_Hlth_Tda_Inst_Val
         WHERE Institute_Code = 4974
           AND Discount_Group_Code = 'S-AT-G�Z'
           --AND validity_end_date is null
           for update
         --  AND Validity_Start_Date <= p_Date
         --  AND Nvl(Validity_End_Date, p_Date) >= p_Date
         --  AND Nvl(Process_Group, '0') = Nvl(p_Process_Group, '0')
        --   AND Price_Type = p_Price_Type;
        
        
          SELECT Institute_Code,
                       NULL Group_Code,
                       Price_Type,
                       NULL Network_Id,                      
                       Add_Unit Oss_Add_Unit,
                       Add_Price Oss_Add_Price,
                       Tss_Add_Unit,
                       Tss_Add_Rate,
                       Tss_Add_Price,
                       Ahek_Add_Rate,
                       Academic_Add_Rate,
                       Validity_Start_Date,
                       Validity_End_Date
                  FROM Koc_Cc_Hlth_Tda_Inst_Val
                 WHERE Institute_Code = 4974
                   AND Discount_Group_Code = 'S-AT-G�Z' 
                   AND Validity_Start_Date <= &p_Date
                   AND Nvl(Validity_End_Date, &p_Date) >= &p_Date
                   
                   
                   select * from alz_hclm_institute_info where institute_code=175 for update
               
