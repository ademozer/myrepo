select * from alz_hclm_version_info where claim_id=40185253
select TO_CHAR(PROVISION_DATE,'DD/MM/YYYY HH24:MI:SS') from koc_clm_hlth_detail where claim_id=40185081
select claim_id,TO_CHAR(PROVISION_DATE,'DD/MM/YYYY HH24:MI:SS') from koc_clm_hlth_detail where ext_reference='56794174'
--"2019-07-08T16:21:53.000+0300"
select * from alz_hltprv_log where log_id=118834428;
select sum_exemption_amount from koc_clm_hlth_detail where ext_reference IN('56794274','56794273') -- for update
select * from koc_clm_hlth_provisions where claim_id IN(40185266,40185267);
select * from alz_hclm_institute_info for update
select * from alz_hltprv_log where log_date>trunc(sysdate) and insurednotype='EXT_REFERENCE' and insuredno='56794240'
select * from koc_clm_hlth_detail where ext_reference='55628221' for update
select * from koc_cp_partners_ext where part_id=85720830;

koc_clm_hlth_trnx2.updateclmtransbank 

55628221


select * from all_source where lower(text) like '%doktor kimlik no bilgisi bo� olamaz!%';
HLTPRV_DR_TYP;
select * from koc_mv_skrm_suppliers where institute_skrs_code='937598';
update Koc_Clm_Suppliers_Ext set Institute_Skrs_Code = 937598 where institute_code = 6089;


select * from hst_cc_web_inst_doctor where doctor_code=232144 for update;--doctor_identity_no='48121507930' for update

koc_clm_hlth_trnx2.doClmRealizationAcc;

base_swift_code


--select * from dba_fga_audit_trail
select * from ALZ_HLTPRV_TSS_SOURCE_TYPE
select * from ALZ_HLTPRV_PROCESS_CONVERT_MAP where institute_code=6089;

select * from alz_hclm_institute_info for update;

select * from koc_clm_hlth_indem_totals where contract_id=461709478 and partition_no=2056 and parent_cover_code='S504' and cover_code='S511' for update;

select * from alz_hltprv_log where log_date>trunc(sysdate) and servicename='ALZ_HCLM_CONVERTER_UTILS' and institutecode='20000' 
and content like '%S511%'
;


select * from alz_hltprv_log where log_id=131981833;

select * from koc_cc_web_inst_doctor where doctor_identity_no='45160010254'
select * from hst_cc_web_inst_doctor where doctor_code='177857';

select * from koc_mv_skrm_suppliers where institute_skrs_code='508555'
select * from koc_clm_suppliers_ext where institute_code=2713 for update
select * from ademo.doctor_info@opusdev where doctor_identity_no=45160010254;


ALZ_HLTPRV_UTILS;

select * from clm_pol_oar where contract_id=442703926 and oar_no=680;
select * from clm_subfiles where claim_id in(
select claim_id from clm_pol_oar where contract_id=442703926 and oar_no=680
) 

select * from koc_clm_hlth_detail where ext_reference='56764133'

select  from koc_clm_hlth_indem_totals where contract_id=442703926 and partition_no=680 and cover_code='S511'
select * from koc_oc_hlth_expack_cov_rel where 
