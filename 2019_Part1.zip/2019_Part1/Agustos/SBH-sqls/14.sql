426737758 partition_no =1

select * from Koc_v_Hlth_Insured_Info_Indem where contract_id=426737758 and partition_no=1

select * from koc_clm_hlth_detail where ext_reference IN ('58106431','58106433')

select * from alz_hltprv_log where log_date>trunc(sysdate) and insurednotype='EXT_REFERENCE' and insuredno='58106431';

select * from koc_ocp_risk_packages where contract_id=426737758 and partition_no =1
--part_id=39555617 ip_no =2


SELECT FROM_TZ(CAST(TO_DATE('2019-03-03 03:00:00', 'YYYY-MM-DD HH:MI:SS') AS TIMESTAMP), 'Europe/Istanbul') AT TIME ZONE 'Europe/Istanbul' "West Coast Time"
FROM DUAL;


SELECT FROM_TZ(CAST(TO_DATE('2019-03-03 03:00:00', 'YYYY-MM-DD HH:MI:SS') AS TIMESTAMP WITH LOCAL TIME), 'Europe/Istanbul') AT TIME ZONE 'Europe/Istanbul' "West Coast Time"
FROM DUAL;

select * from KOC_CLM_WEB_AUTH_POOL
