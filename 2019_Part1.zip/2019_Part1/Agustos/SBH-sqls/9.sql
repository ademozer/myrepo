ALZ_HCLM_CONVERTER_UTILS;

select * from KOC_CLM_HLTH_DETAIL;

KOC_CLM_HLTH_TRNX.Set_sms_deny;

select * from customer.ALZ_HLTPRV_TSS_SOURCE_TYPE;

SELECT u.* FROM CUSTOMER.alz_ghlth_insured_users@opusprep u WHERE USER_NAME;

select * from alz_hltprv_log where log_id=131684585;

HLTPRV_PROV_DIST_CLAIM_TYP;
--HLTPRV_PROV_DIST_COVER_TYP
--HLTPRV_PROV_DIST_CLAIM_TYP;

ALZ_HLTPRV_UTILS

select * from koc_mv_skrm_suppliers where institute_code=4974--institute_skrs_code='504655'
select * from koc_clm_suppliers_ext where institute_code=4974 for update --
501327;

select * from Koc_Cc_Hlth_Tda_Proc_List where sut_code='907660'--'704770' --SUT-MUA, --SUT-HONKO
select * from Koc_Cc_Hlth_Tda_Inst_Val where institute_code='3957' and discount_group_code IN('SUT-LABO') 
--'4974' and discount_group_code IN('SUT-HONKO','SUT-MUA')

select * from alz_hltprv_log where log_id=133366697--132923327
