select * from alz_hltprv_log where insurednotype='EXT_REFERENCE'  and note='UPDATE_PROVISION_REQUEST' and log_id>118832636--=118829089
select * from alz_hclm_version_info where claim_id=40185095--40184650;
select * from alz_hltprv_log where log_id=118833118
select * from koc_clm_hlth_indem_totals where contract_id=442806538 and partition_no IN(3464,4653) and exemption_group=1; 

select * from clm_pol_oar where claim_id=41769242
select * from koc_clm_hlth_detail where ext_reference='56794174';
select * from koc_clm_hlth_indem_totals where contract_id=472116522 and partition_no=300 and cover_code='S511'
select * from koc_oc_hlth_expack_cov_rel where  institute_code=918 and child_cover_code='S511' order by package_date desc--and city_code=34
select * from koc_mv_skrm_suppliers where institute_code=20000

koc_hlth_clm_transfer;

ALZ_HLTH_HOSPITAL_UTILS.GET_ASSIGNED_TEAM_CONTACT_INFO

--2019-07-08T16:21:53.000+0300
