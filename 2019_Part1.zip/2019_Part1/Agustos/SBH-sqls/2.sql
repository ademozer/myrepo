select d.* from koc_clm_hlth_detail d, clm_pol_oar o where d.process_date < (sysdate-1) and d.process_date>(sysdate-15) 
and d.claim_id=o.claim_id
and exists (select 1 from koc_clm_hlth_provisions where claim_id = d.claim_id AND cover_code='S511')
and exists (select 1 from koc_clm_hlth_proc_detail where claim_id = d.claim_id AND process_code_main=10 and process_code_sub1=10 and process_code_sub2=101)
and exists (select 1 from koc_clm_hlth_indem_totals where contract_id = o.contract_id and partition_no=o.oar_no AND cover_code='S511')
and exists (select 1 from koc_clm_hlth_indem_totals where contract_id = o.contract_id and partition_no=o.oar_no AND cover_code=(select parent_cover_code 
from koc_clm_hlth_indem_totals where contract_id = o.contract_id and partition_no=o.oar_no AND cover_code='S511' AND rownum<2)
and nvl(is_unlimited,0) = 1
)
and rownum<5

select * from clm_subfiles where ext_reference='58106756';
select * from koc_clm_hlth_proc_detail where claim_id IN (41905420,41905349);

select * from koc_clm_hlth_detail where ext_Reference='58106818' for update;
select * from koc_clm_hlth_provisions where claim_id=41905420 for update;
