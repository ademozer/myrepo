select * from alz_hltprv_log where log_date>trunc(sysdate) and insurednotype='EXT_REFERENCE' and insuredno='58302667';
select * from koc_clm_hlth_detail where ext_reference='58302667';
select * from koc_clm_hlth_provisions where claim_id=42079052;
select * from koc_clm_hlth_reject_loss where claim_id=42079052;
select * from customer.alz_duplicate_provision where ext_reference='58242277';
select * from alz_hltprv_log where log_id=132455735--133715012;
select * from koc_clm_suppliers_ext where institute_code=13 for update;
koc_clm_hlth_trnx;
select * from koc_cc_web_inst_doctor where institute_code=13 and title='Prof.' and specialty_subject=1200--doctor_identity_no='45748233556'
--select * from koc_clm_indem_total_rules where package_id=261868 and child_cover_code='ST534' for update
select * from Alz_Branch_Code_Cgm_Rel where branchcodeallz=1200;

select * from Koc_Cc_Hlth_Tda_Inst_Val where institute_code=13 and discount_group_code IN ('DR��','DRAT') and validity_end_date is null for update

select * from alz_hclm_institute_info where institute_code=746 for update;
Alz_HCLM_CONVERTER_UTILS
