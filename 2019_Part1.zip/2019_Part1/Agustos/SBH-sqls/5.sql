BEGIN
  SELECT o.policy_ref,
         b.partition_no,
         c.partner_id,
         c.customer_name_text,
         c.version_no,
         b.contract_id,
         o.term_start_date,
         o.term_end_date
    FROM ocp_ip_links           b,
         ocp_interested_parties c,
         ocp_policy_bases       o,
         ocp_policy_versions    v
   WHERE b.contract_id = c.contract_id
     AND b.ip_no = c.ip_no
     AND b.contract_id = o.contract_id
     AND o.version_no = 1
     AND o.contract_id = v.contract_id
     AND v.version_no = 1
     AND v.product_id IN (63, 64)
     AND b.role_type = 'INS'
     AND c.partner_id = 52701887
   Order by o.term_end_date desc;
END;

select * from alz_hltprv_log where log_id=132453437;


SELECT *--Max_Filter_Unit_Id
      --  INTO v_Max_Filter_Unit_Id
        FROM Koc_Cc_Web_User_Def r
       WHERE   1=1  --r.User_Name = 'CKOCAAYAN'
             AND r.Validity_Start_Date <= TRUNC (SYSDATE)
             AND (   r.Validity_End_Date IS NULL
                  OR r.Validity_End_Date >= TRUNC (SYSDATE));
                  
                  
                select * from Koc_Cc_Web_User_Unit_Rel a where validity_end_Date is null
                and exists (select 1
      --  INTO v_Max_Filter_Unit_Id
        FROM Koc_Cc_Web_User_Def r
       WHERE  r.User_Name = a.User_Name
             AND r.Validity_Start_Date <= TRUNC (SYSDATE)
             AND (   r.Validity_End_Date IS NULL
                  OR r.Validity_End_Date >= TRUNC (SYSDATE)                  
                  )
                  AND Max_Filter_Unit_Id IS NULL)
                  
                  SELECT e.Unit_Id
              --INTO v_Unit_Id
              FROM Koc_Cc_Web_User_Unit_Rel e, Koc_Cc_Web_Unit_Ref t
             WHERE     e.User_Name = '724SERVICES'
                   AND e.Validity_Start_Date <= TRUNC (SYSDATE)
                   AND (   e.Validity_End_Date IS NULL
                        OR e.Validity_End_Date >= TRUNC (SYSDATE))
                   AND t.Unit_Id = e.Unit_Id
                   AND t.Validity_Start_Date <= TRUNC (SYSDATE)
                   AND (   t.Validity_End_Date IS NULL
                        OR t.Validity_End_Date >= TRUNC (SYSDATE))
                   AND DECODE (t.Unit_Type,
                               'K', 0,
                               'O', 1,
                               'G', 2,
                               'B', 3,
                               'P', 4) =
                          (SELECT MAX (
                                     DECODE (b.Unit_Type,
                                             'K', 0,
                                             'O', 1,
                                             'G', 2,
                                             'B', 3,
                                             'P', 4))
                                     Unit_Degree
                             FROM Koc_Cc_Web_User_Unit_Rel r,
                                  Koc_Cc_Web_Unit_Ref b
                            WHERE     r.User_Name = e.User_Name
                                  AND r.Validity_Start_Date <=
                                         TRUNC (SYSDATE)
                                  AND (   r.Validity_End_Date IS NULL
                                       OR r.Validity_End_Date >=
                                             TRUNC (SYSDATE))
                                  AND b.Unit_Id = r.Unit_Id
                                  AND b.Validity_Start_Date <=
                                         TRUNC (SYSDATE)
                                  AND (   b.Validity_End_Date IS NULL
                                       OR b.Validity_End_Date >=
                                             TRUNC (SYSDATE)));
                                             
                                             select * from alz_hclm_institute_info where institute_code=323 for update
                                             
                                             KOC_DISCLOSURE_CLAIM_UTILS;
                                             
                                             ALZ_ENDOFMONTH_UTILS;
                                             
                                             ALZ_EJB_LOGGER;
                                             
                                             ALZ_MDLR_HLTH_POLICY_UTILS2;
                                             ALZ_MDLR_HLTH_LOOKUP_UTILS
