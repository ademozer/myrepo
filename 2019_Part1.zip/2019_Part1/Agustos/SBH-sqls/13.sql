SELECT *
              FROM Koc_Cc_Hlth_Tda_Inst_Val x
             WHERE x.Discount_Group_Code = 'S-AT-G�Z'
              AND x.Institute_Code = '4937'
               AND x.Validity_End_Date IS NULL
            --   AND Nvl(x.Process_Group, 0) = Nvl(c.Process_Group, 0)
               AND x.Validity_Start_Date <= &Pprovisiondate
               AND (x.Validity_End_Date >= &Pprovisiondate OR x.Validity_End_Date IS NULL)
               AND ((Nvl(x.Add_Unit, 0) + Nvl(x.Add_Rate, 0) + Nvl(x.Add_Price, 0)) != 0 OR
                   (Nvl(x.Tss_Add_Unit, 0) + Nvl(x.Tss_Add_Rate, 0) + Nvl(x.Tss_Add_Price, 0)) != 0 OR (Nvl(x.Ahek_Add_Rate, 0) != 0))
                   
                   select * from Koc_Cc_Hlth_Tda_Proc_List where discount_group_code='S-AT-G�Z';
                   
                   select * from customer.alz_duplicate_provision where ext_reference='58158320';
                   
                   select * from alz_hltprv_log where log_id=132450524;
                   
                   
                   select * from koc_clm_hlth_detail where ext_reference ='58106398' for update;
                   
                   select * from clm_pol_oar where claim_id=41904775
                   
                   koc_clm_hlth_utils.getdiesaesnotesforprov
                   
                   SELECT Contract_Id,
                     Partition_No,
                     --p_Part_Id,
                     0 Product_Id,
                     '0' Partition_Type,
                     '0' Group_Code,
                     '0' Sub_Company_Code,
                     Substr(Explanation, 1, 2000) Message,
                     To_Number(NULL) Modified_Hep_Rate,
                     ' ' Application_Code,
                     ' ' Uw_Disease_Code,
                     1 Orderer
                FROM Koc_Hlth_Disease_Notes
               WHERE Contract_Id = 420318324
                 AND Partition_No = 1;
                 
                 
                 SELECT 0 Contract_Id,
                      0 Partition_No,
                      d.Part_Id,
                      d.Product_Id,
                      d.Partition_Type,
                      d.Group_Code,
                      d.Sub_Company_Code,
                      Substr(f.Long_Name, 1, 2000) Message,
                      d.Modified_Hep_Rate,
                      D2.Application_Code,
                      D2.Uw_Disease_Code,
                      CASE
                        WHEN D2.Application_Code IN (51, 52, 53) THEN
                         1000
                        WHEN D2.Application_Code = 21 THEN
                         0
                        ELSE
                         1
                      END Orderer
                 FROM Koc_Cp_Hlth_Uwp_Part_Rel d,
                      Koc_Oc_Hlth_Uwp_Detail   D2,
                      Koc_Oc_Hlth_Uwp_Warn_Ref e,
                      Inf_v_Lang_Trans_Api_Tr  f
                WHERE d.Part_Id = p_Part_Id
                  AND d.Product_Id = p_Product_Id
                  AND d.Partition_Type = p_Partition_Type
                  AND d.Group_Code =
                      Decode(p_Product_Id, 63, '0', p_Group_Code)
                  AND d.Sub_Company_Code =
                      Decode(p_Product_Id, 63, '0', p_Sub_Company_Code)
                  AND d.Note_Start_Date <= p_Date
                  AND ((Nvl(d.Note_End_Date, SYSDATE) >= SYSDATE AND
                      p_Date > SYSDATE AND p_Product_Id = 64) OR
                      (Nvl(d.Note_End_Date, p_Date) >= p_Date AND
                      p_Date < SYSDATE AND p_Product_Id = 64) OR
                      (Nvl(d.Note_End_Date, p_Date) >= p_Date AND
                      p_Product_Id = 63))
                  AND D2.Uw_Pack_No = d.Uw_Pack_No
                  AND d.Warning_On_Policy = e.Warning_On_Policy
                  AND d.Rec_Status = '1' -- gecerli ise
                  AND e.Desc_Int_Id = f.Desc_Int_Id
                  AND e.Validity_Start_Date <= p_Date
                  AND Nvl(e.Validity_End_Date, p_Date) >= p_Date
               UNION ALL
               SELECT 0 Contract_Id,
                      0 Partition_No,
                      d.Part_Id,
                      d.Product_Id,
                      d.Partition_Type,
                      d.Group_Code,
                      d.Sub_Company_Code,
                      Substr(Dg.Disease_Group_Name || '-' ||
                             Ap.Application_Name,
                             1,
                             2000) Message,
                      d.Modified_Hep_Rate,
                      Det.Application_Code,
                      Det.Uw_Disease_Code,
                      CASE
                        WHEN Det.Application_Code IN (51, 52, 53) THEN
                         1000
                        WHEN Det.Application_Code = 21 THEN
                         0
                        ELSE
                         1
                      END Orderer
                 FROM Koc_Cp_Hlth_Uwp_Part_Rel   d,
                      Koc_Oc_Hlth_Uwp_Warn_Ref   e,
                      Koc_Oc_Hlth_Uwp_Detail     Det,
                      Koc_Oc_Hlth_Uwp_App_Types  Ap,
                      Koc_Oc_Hlth_Uwp_Dis_Groups Dg
                WHERE d.Uw_Pack_No = Det.Uw_Pack_No
                  AND Det.Application_Code = Ap.Application_Code
                  AND Det.Uw_Disease_Code = Dg.Uw_Disease_Code
                  AND d.Warning_On_Policy = e.Warning_On_Policy(+)
                  AND e.Warning_On_Policy IS NULL -- warning'i yoksa
                AND d.Part_Id = 63923594
                 AND d.Product_Id = 63
                 AND d.Partition_Type = 'MDSG'
                 AND d.Rec_Status = '1' -- gecerli ise
                -- AND d.Group_Code =
                  --   Decode(p_Product_Id, 63, '0', p_Group_Code)
               --  AND d.Sub_Company_Code =
                --     Decode(p_Product_Id, 63, '0', p_Sub_Company_Code)
                 AND d.Note_Start_Date <= p_Date
                 AND ((Nvl(d.Note_End_Date, SYSDATE) >= SYSDATE AND
                     p_Date > SYSDATE AND p_Product_Id = 64) OR
                     (Nvl(d.Note_End_Date, p_Date) >= p_Date AND
                     p_Date < SYSDATE AND p_Product_Id = 64) OR
                     (Nvl(d.Note_End_Date, p_Date) >= p_Date AND
                     p_Product_Id = 63))
                   
                   
                   IN('58106363','58106388')
                   '58106357';
                   select * from alz_hclm_version_info@opusdev where claim_id=41904719;
                   
                   select * from alz_hltprv_log where log_date > trunc(sysdate) and insurednotype='EXT_REFERENCE' and insuredno='58106398'--'58106363'
                    select * from alz_hltprv_log where log_date > trunc(sysdate) and insurednotype='EXT_REFERENCE' and insuredno='58106363'
                   select * from hst_cc_web_inst_doctor where doctor_name='NEB�L' and doctor_surname='EM�R'
