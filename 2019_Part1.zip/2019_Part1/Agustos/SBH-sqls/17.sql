select * from user_errors
SELECT CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.getHclmUsageForInst(13) FROM DUAL;

select * from clm_subfiles where claim_id=41904844--ext_reference='58106433'
select * from clm_pol_oar where contract_id=426737758 and oar_no=1 order by claim_id;

select * from koc_clm_hlth_detail where ext_reference='58106451' for update;

select * from koc_sms_list where claim_id=41935878;
select * from clm_subfiles where ext_reference='58131779';

select * from alz_hltprv_log where log_date>trunc(sysdate) and insurednotype='EXT_REFERENCE' and insuredno='58106451' order by log_date

select * from koc_clm_hlth_detail@opusdev where sgk_ref_no LIKE '2W172FB%' and process_date>TO_DATE('01/05/2019','DD/MM/YYYY');

select * from customer.alz_duplicate_provision where ext_reference='57322573';

select * from alz_hltprv_log where log_id=133366325--133366320--124616712;

select * from koc_clm_suppliers_ext where institute_code='3957' for update;

select * from all_Source where lower(text) like '%provizyon tarihi en fazla%';

ALZ_HLTPRV_CONTROL_UTILS;


