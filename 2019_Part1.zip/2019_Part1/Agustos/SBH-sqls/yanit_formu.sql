SELECT SUM(Talep_Edilmemesi_Gereken_Tutar) FROM
(SELECT Koc_Clm_Hlth_Utils.Getrejectlossdesc(a.Main_Code, a.Item_Code, a.Sub_Item_Code, b.Provision_Date) Aciklama1,
       Round(a.Refuse_Amount, 2) Talep_Edilmemesi_Gereken_Tutar,
       b.Swift_Code
  FROM Koc_Clm_Hlth_Reject_Loss a,
       Koc_Clm_Hlth_Detail      b
 WHERE a.Claim_Id = 40907392
   AND a.Sf_No = 1
   AND (a.Main_Code = 16 AND a.Item_Code = 12)
   AND b.Claim_Id = a.Claim_Id
   AND b.Sf_No = a.Sf_No
UNION ALL
SELECT ' Kurum :' || Nvl(Inst_Request_Amount, 0) || ' - Sistem :' || Nvl(Sys_Request_Amount, 0) || ' ' ||
       Koc_Clm_Hlth_Utils.Getcoverdef(a.Cover_Code) Aciklama1,
       Round(Nvl(Inst_Request_Amount, 0) - Nvl(Sys_Request_Amount, 0), 2) Talep_Edilmemesi_Gereken_Tutar,
       b.Swift_Code
  FROM Koc_Clm_Hlth_Provisions a,
       Koc_Clm_Hlth_Detail     b
 WHERE a.Claim_Id = 40907392
   AND a.Sf_No = 1
   AND b.Claim_Id = a.Claim_Id
   AND b.Sf_No = a.Sf_No
   AND Round(Nvl(Inst_Request_Amount, 0) - Nvl(Sys_Request_Amount, 0), 2) > 0);
   
   select * from koc_clm_hlth_detail where claim_id=41905155
  
  select claim_id,count(*) 
   from Koc_Clm_Hlth_Reject_Loss 
   where main_code='16' and item_code='12'
   and refuse_amount>0 
   and claim_id>40905155
  -- and NVL(time_stamp,TO_DATE('01/01/2012','DD/MM/YYYY'))>to_date('01/06/2019','DD/MM/YYYY')
   group by claim_id
   having count(*)>1
   
   --select * from alz_hclm_version_info where claim_id=40905379
   select * from Koc_Clm_Hlth_Reject_Loss  where claim_id=40907392
   select * from clm_subfiles where claim_id=40907392;
   
   select * from customer.alz_duplicate_provision where ext_reference='57334451';
   select * from alz_hltprv_log where log_id=124734478
