DECLARE
      v_price NUMBER;
BEGIN
      v_price := CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.calculateProcessPrice(1289,  -- institute_code
                            '34',  -- city_code
                            130,
                            20,
                            116,
                            TO_DATE('04/12/2018','DD/MM/YYYY'),
                            1, -- is_vat_included
                            'S11183', -- group_code
                            0,
                            0,
                            355577538,
                            288,
                            0,
                            0,
                            0,
                            0,
                            0);
      DBMS_OUTPUT.PUT_LINE('fiyat='||v_price);
 END;
