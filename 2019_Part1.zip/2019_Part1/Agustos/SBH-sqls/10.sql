select * from alz_hclm_institute_info;

SELECT CUSTOMER.KOC_CLM_HLTH_UTILS.Getlookupparamvalue('HCLM_USAGE', SYSDATE) FROM DUAL;

SELECT  *--K.DETAIL_EXPLANATION
	  --INTO  V_ACIKLAMA
	  FROM  KOC_CP_HEALTH_LOOK_UP K
	 WHERE  K.LOOK_UP_CODE = 'CPA_STAT';
   
  select * from koc_auth_user_role_rel;
  select  * from KOC_AUTHORIZATION_ROLE_DEF@opusdev where role_code like '%PROV%'
  
  select * from all_source where lower(text) like '%from koc_auth_user_role_rel%'
  
  
