SELECT *--COUNT(1)
     -- INTO Vcnt
      FROM Koc_Cc_Hlth_Tda_Proc_List c
     WHERE c.Process_Code_Main = 10
       AND c.Process_Code_Sub1 = 10
       AND c.Process_Code_Sub2 = 108
       AND c.Validity_Start_Date <= trunc(sysdate) 
       AND (c.Validity_End_Date >= trunc(sysdate)  OR c.Validity_End_Date IS NULL)
       AND EXISTS (SELECT 1
              FROM Koc_Clm_Hlth_Inst_Loc_Rel a
             WHERE a.Institute_Code = 13
               AND a.Location_Code = 910
               AND a.Validity_Start_Date <= trunc(sysdate) 
               AND (a.Validity_End_Date >= trunc(sysdate)  OR a.Validity_End_Date IS NULL))
       AND EXISTS (SELECT 1
              FROM Koc_Cc_Hlth_Loc_Cover_Proc b
             WHERE b.Location_Code = 910
               AND b.Process_Code_Main = c.Process_Code_Main
               AND b.Process_Code_Sub1 = c.Process_Code_Sub1
               AND b.Process_Code_Sub2 = c.Process_Code_Sub2
               AND b.Validity_Start_Date <= trunc(sysdate) 
               AND (b.Validity_End_Date >= trunc(sysdate)  OR b.Validity_End_Date IS NULL))
       AND EXISTS (SELECT 1
              FROM Koc_Cc_Hlth_Tda_Inst_Val x
             WHERE x.Discount_Group_Code = c.Discount_Group_Code
               AND x.Institute_Code = 13
               AND Nvl(x.Process_Group, 0) = Nvl(c.Process_Group, 0)
               AND x.Validity_Start_Date <= trunc(sysdate) 
               AND (x.Validity_End_Date >= trunc(sysdate)  OR x.Validity_End_Date IS NULL)
               AND ((Nvl(x.Add_Unit, 0) + Nvl(x.Add_Rate, 0) + Nvl(x.Add_Price, 0)) != 0 OR
                   (Nvl(x.Tss_Add_Unit, 0) + Nvl(x.Tss_Add_Rate, 0) + Nvl(x.Tss_Add_Price, 0)) != 0 OR (Nvl(x.Ahek_Add_Rate, 0) != 0))
            UNION
            SELECT 1
              FROM Koc_Cc_Hlth_Tda_Inst_Val_Gr x
             WHERE x.Discount_Group_Code = c.Discount_Group_Code
               AND x.Institute_Code = 13
               AND x.Group_Code = Nvl(null, 'xxx')
               AND Validity_Start_Date <= trunc(sysdate) 
               AND (x.Validity_End_Date >= trunc(sysdate)  OR x.Validity_End_Date IS NULL)
               AND Nvl(x.Process_Group, 0) = Nvl(c.Process_Group, 0)
               AND ((Nvl(x.Add_Unit, 0) + Nvl(x.Add_Rate, 0) + Nvl(x.Add_Price, 0)) != 0 OR
                   (Nvl(x.Tss_Add_Unit, 0) + Nvl(x.Tss_Add_Rate, 0) + Nvl(x.Tss_Add_Price, 0)) != 0 OR (Nvl(x.Ahek_Add_Rate, 0) != 0)))
      /* AND NOT EXISTS (SELECT 1
              FROM Koc_Cc_Web_Inst_Proc e
             WHERE e.Institute_Code = 13
               AND e.Process_Code_Main = c.Process_Code_Main
               AND e.Process_Code_Sub1 = c.Process_Code_Sub1
               AND e.Process_Code_Sub2 = c.Process_Code_Sub2
               AND e.Type = '-'
               AND e.Validity_Start_Date <= trunc(sysdate) 
               AND (e.Validity_End_Date >= trunc(sysdate)  OR e.Validity_End_Date IS NULL));*/
               
               
        
             SELECT * FROM Koc_Cc_Web_Inst_Proc e
             WHERE e.Institute_Code = 13
               AND e.Process_Code_Main = 10
               AND e.Process_Code_Sub1 = 10
               AND e.Process_Code_Sub2 = 108
               AND e.Type = '-'
               AND e.Validity_Start_Date <= trunc(sysdate) 
               AND (e.Validity_End_Date >= trunc(sysdate)  OR e.Validity_End_Date IS NULL) for update
               
               select institute_code from koc_clm_hlth_detail where ext_reference='58106756'
