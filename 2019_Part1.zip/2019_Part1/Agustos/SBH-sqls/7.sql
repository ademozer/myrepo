select *  from alz_hltprv_process_convert_map where institute_code in(13,3255) for update
