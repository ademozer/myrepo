select * from customer.alz_duplicate_provision where ext_reference='58070794'
select * from alz_hltprv_log where log_id=132081034;
select * from koc_clm_hlth_detail where ext_reference='58070794';

koc_hlth_clm_transfer.pr_clm_hlth_set_remaining;

select * from koc_oc_hlth_plan_match;
 
KOC_CLM_HLTH_BPM_UTILS.Getinstlistbyusername 
 
