      SELECT /*Nvl(Gen.At_Ws_Prov_Ctrl_Period, 0),
             Nvl(Gen.Yt_Ws_Prov_Ctrl_Period, 0),
             Nvl(Gen.At_Ws_Proc_Entr_Ctrl_Period, 0),
             Nvl(Gen.Yt_Ws_Proc_Entr_Ctrl_Period, 0),
             Nvl(Gen.At_Ws_Proc_Upd_Ctrl_Period, 0),
             Nvl(Gen.Yt_Ws_Proc_Upd_Ctrl_Period, 0),
             Nvl(Gen.At_Ulak_Prov_Ctrl_Period, 0),
             Nvl(Gen.Yt_Ulak_Prov_Ctrl_Period, 0),
             Nvl(Gen.At_Ulak_Prov_Upd_Ctrl_Period, 0),
             Nvl(Gen.Yt_Ulak_Prov_Upd_Ctrl_Period, 0),
             Nvl(Gen.At_Ulak_Proc_Entr_Ctrl_Period, 0),
             Nvl(Gen.Yt_Ulak_Proc_Entr_Ctrl_Period, 0),
             Nvl(Gen.At_Ulak_Proc_Upd_Ctrl_Period, 0),
             Nvl(Gen.Yt_Ulak_Proc_Upd_Ctrl_Period, 0)*/

       /* INTO v_Atwsprovctrlperiod,
             v_Ytwsprovctrlperiod,
             v_Atwsprocentrctrlperiod,
             v_Ytwsprocentrctrlperiod,
             v_Atwsprocupdctrlperiod,
             v_Ytwsprocupdctrlperiod,
             v_Atulakprovctrlperiod,
             v_Ytulakprovctrlperiod,
             v_Atulakprovupdctrlperiod,
             v_Ytulakprovupdctrlperiod,
             v_Atulakprocentrctrlperiod,
             v_Ytulakprocentrctrlperiod,
             v_Atulakprocupdctrlperiod,
             v_Ytulakprocupdctrlperiod*/
        *
        FROM Koc_Cc_Web_Unit_Gen_Ref Gen
       WHERE Gen.Institute_Code = 0
         AND Gen.Validity_End_Date IS NULL
         FOR UPDATE;
         --v_Atulakprovctrlperiod
