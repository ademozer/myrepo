DECLARE
 v_claim_id   NUMBER :=  ;
 v_sf_no      NUMBER;
 v_resp       Customer.Hltprv_Provision_Resp_Typ;
 v_prov_dist  Customer.Hltprv_Prov_Dist_Claim_Typ;
 
PROCEDURE Fillprovisionservices(Pclaimid  IN Koc_Clm_Hlth_Detail.Claim_Id%TYPE,
                                                                    Psfno     IN Koc_Clm_Hlth_Detail.Sf_No%TYPE,
                                                                    Presp     IN OUT Customer.Hltprv_Provision_Resp_Typ,
                                                                    Pprovdist IN OUT Customer.Hltprv_Prov_Dist_Claim_Typ) IS
        CURSOR Crprocess(Cpclaimid IN Koc_Clm_Hlth_Detail.Claim_Id%TYPE,
                                         Cpsfno    IN Koc_Clm_Hlth_Detail.Sf_No%TYPE) IS
            SELECT P1.Process_Code_Main,
                         P1.Process_Code_Sub1,
                         P1.Process_Code_Sub2,
                         P1.Indemnity_Amount,
                         P1.Inst_Indemnity_Amount,
                         P1.Process_Count,
                         P1.Status_Code,
                         P1.Explanation,
                         P1.Entrance_Date,
                         P1.Drg_Code,
                         P1.Doctor_Code,
                         P1.Doctor_Status,
                         P1.Sgk_Amount,
                         P1.Order_No,
                         P1.Vat_Rate,
                         P1.Right_Left,
                         P1.Proc_Type,
                         P1.Physiotherapy_Session,
                         P1.Diagnosis_Id,
                         P1.Surgery_Id,
                         P2.Provision_Date,
                         P2.Group_Code,
                         P2.Status_Code               Claim_Status,
                         P1.Group_No,
                         P1.Seq_No,
                         P1.Req_Process_Name,
                         P1.Req_Process_Code,
                         P1.Req_Process_List_Type,
                         P1.Related_Process,
                         P1.Related_Process_List_Type,
                         P3.Cover_Code,
                         P3.Add_Order_No,
                         P3.Location_Code,
                         P3.Swift_Code,
                         P3.Provision_Total,
                         P3.Request_Amount,
                         P3.Refusal_Amount,
                         P3.Exemption_Amount,
                         P3.Exemption_Rate,
                         P3.Sgk_Amount                Cover_Sgk_Amount,
                         P3.Add_Proc_Amount,
                         P2.Request_System
                FROM Koc_Clm_Hlth_Proc_Detail P1,
                         Koc_Clm_Hlth_Detail      P2,
                         Koc_Clm_Hlth_Provisions  P3
             WHERE P1.Claim_Id = Cpclaimid
                 AND P1.Sf_No = Cpsfno
                 AND P1.Add_Order_No = 1
                 AND P1.Claim_Id = P2.Claim_Id
                 AND P1.Sf_No = P2.Sf_No
                 AND P1.Add_Order_No = P2.Add_Order_No
                 AND P3.Claim_Id = P1.Claim_Id
                 AND P3.Sf_No = P1.Sf_No
                 AND P3.Add_Order_No = P1.Add_Order_No
                 AND P3.Location_Code = P1.Location_Code
                 AND P3.Cover_Code = P1.Cover_Code;

        CURSOR Crdoctor(Cpdoctorcode Hst_Cc_Web_Inst_Doctor.Doctor_Code%TYPE) IS
            SELECT Doctor_Name,
                         Doctor_Surname,
                         Specialty_Subject,
                         Title,
                         Doctor_Identity_No,
                         Doctor_Staff,
                         Doctor_Certificate_Number
                FROM Hst_Cc_Web_Inst_Doctor
             WHERE Doctor_Code = Cpdoctorcode;

        CURSOR Crsurgery(Cpsurgeryid IN Koc_Clm_Hlth_Surgery_Detail.Surgery_Id%TYPE) IS
            SELECT Cut_No,
                         Recurrence,
                         Is_Revision,
                         Right_Left,
                         Process_Score,
                         Is_Laparoscopic_Surgery,
                         Is_Robotic_Surgery,
                         Package_Type,
                         Surgery_Package_No
                FROM Koc_Clm_Hlth_Surgery_Detail
             WHERE Surgery_Id = Cpsurgeryid;

        CURSOR Crdiagnose(Cpdiagnoseid IN Koc_Clm_Hlth_Diagnosis.Diagnosis_Id%TYPE) IS
            SELECT Diagnosis_Code,
                         Diagnosis_Desc,
                         Diagnosis_Type
                FROM Koc_Clm_Hlth_Diagnosis
             WHERE Diagnosis_Id = Cpdiagnoseid;

        --��lem teminat� ve i�lem redleri
        CURSOR Crrejects(Cpclaimid IN NUMBER,
                                         Cpsfno    IN NUMBER,
                                         Cploccode IN NUMBER,
                                         Cpmain    IN NUMBER,
                                         Cpsub1    IN NUMBER,
                                         Cpsub2    IN NUMBER,
                                         Cpseqno   IN NUMBER) IS
            SELECT DISTINCT Main_Code,
                                            Item_Code,
                                            Sub_Item_Code
                FROM Koc_Clm_Hlth_Reject_Loss
             WHERE Claim_Id = Cpclaimid
                 AND Sf_No = Cpsfno
                 AND Add_Order_No = 1
                 AND Process_Code_Main = Cpmain
                 AND Process_Code_Sub1 = Cpsub1
                 AND Process_Code_Sub2 = Cpsub2
                 AND Seq_No = Cpseqno;

        CURSOR Crrejects2(Cpclaimid IN NUMBER,
                                            Cpsfno    IN NUMBER) IS
            SELECT DISTINCT Main_Code,
                                            Item_Code,
                                            Sub_Item_Code
                FROM Koc_Clm_Hlth_Reject_Loss
             WHERE Claim_Id = Cpclaimid
                 AND Sf_No = Cpsfno
                 AND Add_Order_No = 1
                 AND Location_Code = 0
                 AND Cover_Code = '0'
                 AND Nvl(Process_Code_Main, 0) = 0
                 AND Nvl(Process_Code_Sub1, 0) = 0
                 AND Nvl(Process_Code_Sub2, 0) = 0
                 AND Nvl(Barcode, 0) = 0
                 AND Nvl(Ubb_Code, '0') = '0';

        Vrejexpl VARCHAR2(1000);
        v_Ind    NUMBER;
        Vlast    NUMBER;
        --vlast2      number;
        Vcount         NUMBER;
        Vbaseswiftcode VARCHAR2(4) := Base_Swift_Code;
    BEGIN
        FOR Rec IN Crprocess(Pclaimid, Psfno)
        LOOP
            /*HizmetBilgileri*/
            IF Presp.Resultinfo IS NULL
            THEN
                Presp.Resultinfo := Hltprv_Result_Typ();
            END IF;

            IF Presp.Resultinfo.Resultreturning IS NULL
            THEN
                Presp.Resultinfo.Resultreturning := Hltprv_Resultreturning_Typ();
            END IF;

            IF Presp.Resultinfo.Resultreturning.Serviceinfosreturning IS NULL
            THEN
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning := Hltprv_Serviceinfreturning_Tbl();
            END IF;

            Presp.Resultinfo.Resultreturning.Serviceinfosreturning.Extend;
            Vlast := Presp.Resultinfo.Resultreturning.Serviceinfosreturning.Last;
            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast) := Hltprv_Serviceinfreturning_Typ();

            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation := Hltprv_Serviceinfos_Typ();
            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess := Hltprv_Srvcbsdprcss_Typ();

            IF Rec.Req_Process_Name IS NOT NULL
            THEN
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Name := Rec.Req_Process_Name;
            ELSE
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Name := Koc_Clm_Hlth_Utils.Getprocessdesc(Rec.Process_Code_Main,
                                                                                                                                                                                                                                                                                                             Rec.Process_Code_Sub1,
                                                                                                                                                                                                                                                                                                             Rec.Process_Code_Sub2,
                                                                                                                                                                                                                                                                                                             Rec.Provision_Date);
            END IF;

            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Processcode := Hltprv_Processcode_Typ();
            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Processcode.Processcodelist := Rec.Req_Process_List_Type;
            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Processcode.Processcodevalue := Rec.Req_Process_Code;

            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Drgcode := Rec.Drg_Code;

            IF Rec.Related_Process IS NOT NULL
            THEN
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Relatedprocesscode := Hltprv_Processcode_Typ();
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Relatedprocesscode.Processcodelist := Rec.Related_Process_List_Type;
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Relatedprocesscode.Processcodevalue := Rec.Related_Process;
            END IF;

            IF Rec.Doctor_Code IS NOT NULL
            THEN
                FOR Recdoctor IN Crdoctor(Rec.Doctor_Code)
                LOOP
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr := Hltprv_Dr_Typ();
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Namesurname := Recdoctor.Doctor_Name || ' ' ||
                                                                                                                                                                                                                                                                 Recdoctor.Doctor_Surname;

                    IF Recdoctor.Title = 'Prof.'
                    THEN
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Title := 'PROF';
                    ELSIF Recdoctor.Title = 'Do�.'
                    THEN
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Title := 'DOC';
                    ELSIF Recdoctor.Title IN ('Yard. Do�', 'Yard. Do�.')
                    THEN
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Title := 'YRD_DOC';
                    ELSIF Recdoctor.Title = 'Uzman'
                    THEN
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Title := 'UZM';
                    ELSIF Recdoctor.Title = 'Pratisyen'
                    THEN
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Title := 'PRTS';
                    ELSE
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Title := NULL;
                    END IF;

                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Branch := Convertbranchcode2(Rec.Request_System,
                                                                                                                                                                                                                                                                                             Rec.Provision_Date,
                                                                                                                                                                                                                                                                                             Recdoctor.Specialty_Subject);
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Staffstatus := Recdoctor.Doctor_Staff;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Identityno := Recdoctor.Doctor_Identity_No;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Diplomaregistrationno := Recdoctor.Doctor_Certificate_Number;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Dr.Drtype := Rec.Doctor_Status;
                END LOOP;
            END IF;

            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Amountrequest := Rec.Inst_Indemnity_Amount;
            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Amountsgk := Rec.Sgk_Amount;

            IF Rec.Entrance_Date IS NOT NULL
            THEN
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Processdatetime := Hltprv_Processdatetime_Typ();
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Processdatetime.Processdate := Trunc(Rec.Entrance_Date);
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Processdatetime.Processtime := To_Char(Rec.Entrance_Date,
                                                                                                                                                                                                                                                                                                        'hh24:mi:ss');
            END IF;

            IF Rec.Proc_Type = 'AMELIYAT' AND
                 Rec.Surgery_Id IS NOT NULL
            THEN
                FOR Recsurgery IN Crsurgery(Rec.Surgery_Id)
                LOOP
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail := Hltprv_Detail_Typ();
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Surgery := Hltprv_Surgery_Typ();

                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Surgery.Incisionno := Recsurgery.Cut_No;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Surgery.Relapse := Recsurgery.Recurrence;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Surgery.Revision := Recsurgery.Is_Revision;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Surgery.Rightleft := Recsurgery.Right_Left;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Surgery.Processpoints := Recsurgery.Process_Score;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Surgery.Laparoscopicsurgery := Recsurgery.Is_Laparoscopic_Surgery;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Surgery.Roboticssurgery := Recsurgery.Is_Robotic_Surgery;

                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Surgery.Surgerypackage := Hltprv_Surgerypackage_Typ();
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Surgery.Surgerypackage.Packagetype := Recsurgery.Package_Type;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Surgery.Surgerypackage.Packageno := Recsurgery.Surgery_Package_No;
                    --surgerypackage.consumables  ???? kullan�lm�yor
                --presp.resultinfo.resultreturning.serviceinfosreturning(vLast).serviceinformation.servicebasedprocess.detail.surgery.surgerypackage.consumables
                END LOOP;
            ELSIF Rec.Proc_Type = 'FIZIK_TEDAVI' AND
                        Rec.Physiotherapy_Session IS NOT NULL
            THEN
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail := Hltprv_Detail_Typ();
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Physiotherapy := Hltprv_Physiotherapy_Typ();
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Physiotherapy.Seance := Rec.Physiotherapy_Session;
            ELSIF Rec.Proc_Type = 'MUAYENE' AND
                        Rec.Diagnosis_Id IS NOT NULL
            THEN
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail := Hltprv_Detail_Typ();
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Examination := Hltprv_Examination_Typ();
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Examination.Disease := Hltprv_Disease_Typ();

                FOR Recdiagnose IN Crdiagnose(Rec.Diagnosis_Id)
                LOOP
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Examination.Disease.Name := Recdiagnose.Diagnosis_Desc;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Examination.Disease.Code := Recdiagnose.Diagnosis_Code;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Examination.Disease.Type := Recdiagnose.Diagnosis_Type;
                END LOOP;
            ELSIF Rec.Proc_Type = 'KONSULTASYON' AND
                        Rec.Diagnosis_Id IS NOT NULL
            THEN
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail := Hltprv_Detail_Typ();
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Consultation := Hltprv_Consultation_Typ();
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Consultation.Disease := Hltprv_Disease_Typ();

                FOR Recdiagnose IN Crdiagnose(Rec.Diagnosis_Id)
                LOOP
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Consultation.Disease.Name := Recdiagnose.Diagnosis_Desc;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Consultation.Disease.Code := Recdiagnose.Diagnosis_Code;
                    Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Detail.Consultation.Disease.Type := Recdiagnose.Diagnosis_Type;
                END LOOP;
            END IF;

            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Orderno := Rec.Order_No;
            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Ratevat := Rec.Vat_Rate;
            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Rightleft := Rec.Right_Left;

            IF Rec.Explanation IS NOT NULL
            THEN
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Explanation := Hltprv_Note_Typ();
                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Serviceinformation.Servicebasedprocess.Explanation.Text := Rec.Explanation;
            END IF;

            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult := Hltprv_Decisionresult_Typ();
            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Decisiontypecode := Convertstatuscode(Rec.Status_Code, 0
                                                                                                                                                                                                                                                    --rec.refusal_amount
                                                                                                                                                                                                                                                 );

            IF Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Decisiontypecode = 'RED'
            THEN
                FOR r IN Crrejects(Pclaimid, Psfno, Rec.Location_Code, Rec.Process_Code_Main, Rec.Process_Code_Sub1, Rec.Process_Code_Sub2, Rec.Seq_No)
                LOOP
                    Vrejexpl := Findrejectexplanation(r.Main_Code, r.Item_Code, r.Sub_Item_Code, '5', Rec.Group_Code, Rec.Provision_Date);

                    IF Vrejexpl IS NOT NULL
                    THEN
                        --
                        IF Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation IS NULL
                        THEN
                            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation := Customer.Hltprv_Note_Tbl();
                        END IF;

                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation.Extend;
                        Vcount := Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation.Last;

                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation(Vcount) := Customer.Hltprv_Note_Typ();
                        Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation(Vcount).Text := Vrejexpl;
                    END IF;
                END LOOP;

                IF Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation IS NULL
                THEN
                    FOR r IN Crrejects2(Pclaimid, Psfno)
                    LOOP
                        Vrejexpl := Findrejectexplanation(r.Main_Code, r.Item_Code, r.Sub_Item_Code, '5', Rec.Group_Code, Rec.Provision_Date);

                        IF Vrejexpl IS NOT NULL
                        THEN
                            --
                            IF Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation IS NULL
                            THEN
                                Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation := Customer.Hltprv_Note_Tbl();
                            END IF;

                            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation.Extend;
                            Vcount := Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation.Last;

                            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation(Vcount) := Customer.Hltprv_Note_Typ();
                            Presp.Resultinfo.Resultreturning.Serviceinfosreturning(Vlast).Decisionresult.Explanation(Vcount).Text := Vrejexpl;
                        END IF;
                    END LOOP;
                END IF;
            END IF;

            --
            -- Teminat tutarlar�n� i�lem/malzeme/ ila� detaylar�na da��tmak i�in ilgili objeye y�kle
            Pprovdist.Setcoverdetails(Rec.Cover_Code, Rec.Add_Order_No, Rec.Location_Code, Rec.Provision_Total, Rec.Request_Amount, Rec.Refusal_Amount,
                                                                Rec.Exemption_Amount, Rec.Exemption_Rate, Rec.Cover_Sgk_Amount, Rec.Add_Proc_Amount, v_Ind);

            --
            -- Hizmetleri ilgili teminata ekle
            IF v_Ind > 0
            THEN
                Pprovdist.Cover_Details(v_Ind).Setprocessdetail(Rec.Process_Code_Main, Rec.Process_Code_Sub1, Rec.Process_Code_Sub2, Rec.Seq_No, Rec.Group_No,
                                                                                                                Rec.Order_No, Rec.Status_Code, Nvl(Rec.Swift_Code, Vbaseswiftcode), Rec.Indemnity_Amount,
                                                                                                                Rec.Inst_Indemnity_Amount, Rec.Sgk_Amount, Rec.Process_Count, Vlast);
            END IF;
            --

        END LOOP;
    END;
