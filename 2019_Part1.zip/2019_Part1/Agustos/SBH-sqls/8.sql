 SELECT *--MAX(Process_Date) Processdate
                FROM Koc_Clm_Hlth_Indem_Dec
             WHERE Claim_Id = 41904938
                 AND Sf_No = 1
                 AND Add_Order_No = 1
                 AND File_Agreement_Code IN ('P', 'R', 'C');
                 
                 select * from koc_clm_hlth_detail where claim_id=41904939
                 select * from clm_subfiles where ext_reference='57322573'--claim_id=41904939;
                 
                 --select * from alz_hltprv_bre_log where claim_id=40889211
                 
                 select * from customer.alz_duplicate_provision where ext_reference='57931736';
                 select * from alz_hltprv_log where log_id=128685612;
                 select * from koc_clm_hlth_detail where ext_reference='56793556'--'57931736';
                 select * from koc_clm_hlth_provisions@opusprep where claim_id = 41681537 for update
                 select * from koc_clm_hlth_indem_totals where contract_id=400797581 and partition_no=1 and cover_code='S520';
                 
                 select * from alz_hltprv_log where log_date>TO_DATE('01/07/2019','DD/MM/YYYY') 
                 and log_date < TO_DATE('30/07/2019','DD/MM/YYYY') and insurednotype='EXT_REFERENCE' and insuredno='57931736';
                 
                 select * from user_errors;
                 
                 Koc_Pk_Hlth_Provision.Getprovisiondata;
