SELECT *--COUNT(1)
      --INTO Vcnt
      FROM Koc_Cc_Hlth_Tda_Proc_List c
     WHERE c.Process_Code_Main = &Pprocesscodemain
       AND c.Process_Code_Sub1 = &Pprocesscodesub1
       AND c.Process_Code_Sub2 = &Pprocesscodesub2
       AND c.Validity_Start_Date <= &Pprovisiondate
       AND (c.Validity_End_Date >= &Pprovisiondate OR c.Validity_End_Date IS NULL)
       AND EXISTS (SELECT 1
              FROM Koc_Clm_Hlth_Inst_Loc_Rel a
             WHERE a.Institute_Code = &Pinstcode
               AND a.Location_Code = &Plocationcode
               AND a.Validity_Start_Date <= &Pprovisiondate
               AND (a.Validity_End_Date >= &Pprovisiondate OR a.Validity_End_Date IS NULL))
       AND EXISTS (SELECT 1
              FROM Koc_Cc_Hlth_Loc_Cover_Proc b
             WHERE b.Location_Code = &Plocationcode
               AND b.Process_Code_Main = c.Process_Code_Main
               AND b.Process_Code_Sub1 = c.Process_Code_Sub1
               AND b.Process_Code_Sub2 = c.Process_Code_Sub2
               AND b.Validity_Start_Date <= &Pprovisiondate
               AND (b.Validity_End_Date >= &Pprovisiondate OR b.Validity_End_Date IS NULL))
      /* AND EXISTS (SELECT 1
              FROM Koc_Cc_Hlth_Tda_Inst_Val x
             WHERE x.Discount_Group_Code = c.Discount_Group_Code
               AND x.Institute_Code = &Pinstcode
               AND Nvl(x.Process_Group, 0) = Nvl(c.Process_Group, 0)
               AND x.Validity_Start_Date <= &Pprovisiondate
               AND (x.Validity_End_Date >= &Pprovisiondate OR x.Validity_End_Date IS NULL)
               AND ((Nvl(x.Add_Unit, 0) + Nvl(x.Add_Rate, 0) + Nvl(x.Add_Price, 0)) != 0 OR
                   (Nvl(x.Tss_Add_Unit, 0) + Nvl(x.Tss_Add_Rate, 0) + Nvl(x.Tss_Add_Price, 0)) != 0 OR (Nvl(x.Ahek_Add_Rate, 0) != 0))
            UNION
            SELECT 1
              FROM Koc_Cc_Hlth_Tda_Inst_Val_Gr x
             WHERE x.Discount_Group_Code = c.Discount_Group_Code
               AND x.Institute_Code = &Pinstcode
               --AND x.Group_Code = Nvl(Pgroupcode, 'xxx')
               AND Validity_Start_Date <= &Pprovisiondate
               AND (x.Validity_End_Date >= &Pprovisiondate OR x.Validity_End_Date IS NULL)
               AND Nvl(x.Process_Group, 0) = Nvl(c.Process_Group, 0)
               AND ((Nvl(x.Add_Unit, 0) + Nvl(x.Add_Rate, 0) + Nvl(x.Add_Price, 0)) != 0 OR
                   (Nvl(x.Tss_Add_Unit, 0) + Nvl(x.Tss_Add_Rate, 0) + Nvl(x.Tss_Add_Price, 0)) != 0 OR (Nvl(x.Ahek_Add_Rate, 0) != 0)))*/
       AND NOT EXISTS (SELECT 1
              FROM Koc_Cc_Web_Inst_Proc e
             WHERE e.Institute_Code = &Pinstcode
               AND e.Process_Code_Main = c.Process_Code_Main
               AND e.Process_Code_Sub1 = c.Process_Code_Sub1
               AND e.Process_Code_Sub2 = c.Process_Code_Sub2
               AND e.Type = '-'
               AND e.Validity_Start_Date <= &Pprovisiondate
               AND (e.Validity_End_Date >= &Pprovisiondate OR e.Validity_End_Date IS NULL));
