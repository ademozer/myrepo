SELECT DISTINCT institute_code FROM (
SELECT process_code_main, process_code_sub1, process_code_sub2, institute_code
                  FROM (WITH institute_price AS (select INSTITUTE_CODE,
                                                        DISCOUNT_GROUP_CODE,
                                                        ADD_RATE,
                                                        ADD_PRICE,
                                                        ADD_UNIT,
                                                        TSS_ADD_RATE,
                                                        TSS_ADD_PRICE,
                                                        TSS_ADD_UNIT,
                                                        AHEK_ADD_RATE,
                                                        ACADEMIC_ADD_RATE
                                                   from Koc_Cc_Hlth_Tda_Inst_Val
                                                  where validity_end_date is null
                                                    and add_unit > 0 
                                                    and add_unit is not null
                                                    --and institute_code='1115'                                                                                                    
                                                   ), process_list AS (SELECT p.process_code_main,
                                                                                             p.process_code_sub1,
                                                                                             p.process_code_sub2,
                                                                                             p.discount_group_code,
                                                                                             a.agreement_code
                                                                                        FROM Koc_Cc_Hlth_Tda_Proc_List     p,
                                                                                             KOC_CC_HLTH_TDA_DICNT_AGG_REL a
                                                                                       where a.discount_code =
                                                                                             p.discount_group_code
                                                                                         and a.agreement_code = 'TTB'    
                                                                                         and p.validity_end_date IS NULL)
                         SELECT institute_price.*, process_list.*
                           FROM institute_price, process_list
                          WHERE institute_price.discount_group_code =
                                process_list.discount_group_code) ) 
 
