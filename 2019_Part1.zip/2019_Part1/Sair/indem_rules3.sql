SELECT a.Main_Or_Sub_Cov ,a.*
FROM Koc_Clm_Hlth_Indem_Totals a
WHERE 1=1
AND a.parent_Cover_Code ='S534'
AND a.Contract_Id = 15356132
AND a.Partition_No = 831  
AND a.Is_Pool_Cover = Nvl(0, 0)
AND a.Is_Special_Cover = Nvl(0, 0)
AND Nvl(a.Is_Valid, 0) = 1
AND a.Validity_Start_Date <= to_date('01/01/2008','MM/DD/YYYY')
AND Nvl(a.Validity_End_Date, to_date('01/01/2008','MM/DD/YYYY')) >= to_date('01/01/2008','MM/DD/YYYY')
and exists(
SELECT *
FROM Koc_Clm_Indem_Total_Rules b
WHERE Package_Id = a.Package_Id
AND Package_Id = Package_Id_2
AND Country_Group_2 =a.Country_Group
AND Claim_Inst_Type_2 =a.Claim_Inst_Type
AND Claim_Inst_Loc_2 =a.Claim_Inst_Loc
AND Is_Pool_Cover = a.Is_Pool_Cover
AND Is_Special_Cover =  a.Is_Special_Cover
AND Trunc(Package_Date) = Trunc(to_date('01/01/2007','MM/DD/YYYY'))
AND Country_Group = 0
AND Claim_Inst_Type = 'AK'
AND Claim_Inst_Loc = 'YI'
AND Child_Cover_Code = 'S500'
AND Validity_Start_Date <= to_date('01/01/2008','MM/DD/YYYY')
AND Nvl(Validity_End_Date, to_date('01/01/2008','MM/DD/YYYY')) >= to_date('01/01/2008','MM/DD/YYYY')
)
