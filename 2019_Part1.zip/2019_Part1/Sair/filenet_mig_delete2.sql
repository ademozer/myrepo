BEGIN

 EXECUTE IMMEDIATE 'CREATE TABLE alz_documents_tmp  as             
                                 select * from alz_documents
                                 where document_id not in (select document_id 
                                                             from alz_fn_mig_contracts 
                                                            where mig_status=''DONE'')';
                       
 EXECUTE IMMEDIATE 'truncate table alz_documents';

 EXECUTE IMMEDIATE 'insert into alz_documents select * from alz_documents_tmp';

COMMIT;

EXCEPTION WHEN OTHERS THEN
  DBMS_OUTPUT.PUT_LINE('Hata:'||SQLERRM);
  ROLLBACK;
END;
/


                       
                         
                       
                   
