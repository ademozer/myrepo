DECLARE 
   v_stmt VARCHAR2(32000);  
   l_try      NUMBER;
   l_status   NUMBER;
   l_task_name VARCHAR2(100) := 'filenet_mig_delete';
BEGIN
 /* DBMS_PARALLEL_EXECUTE.create_task (task_name => l_task_name); 
  DBMS_PARALLEL_EXECUTE.create_chunks_by_number_col(task_name   => l_task_name,
                                                    table_owner => 'CUSTOMER',
                                                    table_name  => 'ALZ_FN_MIG_CONTRACTS',
                                                    table_column => 'SIRA_NO',
                                                    chunk_size  => 20000);*/
  v_stmt := 'DECLARE v_count NUMBER := 0;
    v_commit NUMBER := 100;
    
CURSOR c_main IS
   SELECT m.DOCUMENT_ID,        
          m.ROWID ROW_ID                   
     FROM ALZ_FN_MIG_CONTRACTS m
    WHERE m.MIG_STATUS=''DONE''     
     AND SIRA_NO>=:start_id
     AND SIRA_NO<=:end_id;     
           
BEGIN   
  
  FOR r_main IN c_main LOOP  
       
          DELETE ALZ_DOCUMENTS 
          WHERE DOCUMENT_ID = r_main.DOCUMENT_ID;
            
          UPDATE ALZ_FN_MIG_CONTRACTS
             SET MIG_STATUS = ''DELETED'',
                 ERROR_DESC = v_err_msg
           WHERE ROWID = r_main.ROW_ID; 
                                  
       EXCEPTION
       WHEN OTHERS THEN
           v_err_msg := SQLERRM;
           UPDATE ALZ_FN_MIG_CONTRACTS
             SET MIG_STATUS = ''DEL_FAIL'', 
                 ERROR_DESC = SUBSTR(v_err_msg,1,400)
           WHERE ROWID = r_main.ROW_ID;
       END;
        IF MOD(v_count, v_commit) = 0 THEN 
           COMMIT;
        END IF;
        v_count := v_count +1;           
   END LOOP;
   COMMIT;
  
EXCEPTION
WHEN OTHERS THEN
     v_err_msg := SQLERRM;
     --DBMS_OUTPUT.PUT_LINE(''Hata:''||SUBSTR(v_err_msg,1,200));
     ROLLBACK;   
 END;';

  DBMS_PARALLEL_EXECUTE.run_task(task_name      => l_task_name,
                                 sql_stmt       => v_stmt,
                                 language_flag  => DBMS_SQL.NATIVE,
                                 parallel_level => 20);
   l_try := 0;
   l_status := DBMS_PARALLEL_EXECUTE.task_status(l_task_name);
  dbms_output.put_line(l_status);
 
  --DBMS_PARALLEL_EXECUTE.drop_task('l_task_name');                               
                                             
END;
/
