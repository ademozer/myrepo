select * from user_errors

          SELECT d.user_type as user_type, g.user_group as user_group        
            FROM CUSTOMER.Koc_Cp_User_Detail d, CUSTOMER.Koc_Oc_Hlth_User_Grp_Rel g
           WHERE d.Userid = 'MEDISER28'
             AND d.user_type = g.user_type
             AND d.Validity_Start_Date <= SYSDATE
             AND (d.Validity_End_Date IS NULL OR d.Validity_End_Date >= SYSDATE)
             AND g.Validity_Start_Date <= SYSDATE
             AND (g.Validity_End_Date IS NULL OR g.Validity_End_Date >=SYSDATE);
             
            SELECT CUSTOMER.KOC_CLM_HLTH_UTILS.Getlookupparamvalue('HCLM_USAGE',SYSDATE) FROM DUAL
            
            GRANT EXECUTE ON CUSTOMER.KOC_CLM_HLTH_UTILS  TO ADEMO;
