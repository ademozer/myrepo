

SELECT *
FROM Koc_Clm_Indem_Total_Rules b
WHERE Package_Id = 63709
AND Package_Id = Package_Id_2
AND Trunc(Package_Date) = Trunc(to_date('01/01/2007','MM/DD/YYYY'))
AND Country_Group = 0
AND Claim_Inst_Type = 'AK'
AND Claim_Inst_Loc = 'YI'
AND Child_Cover_Code = 'S501'
AND Validity_Start_Date <= to_date('01/01/2008','MM/DD/YYYY')
AND Nvl(Validity_End_Date, to_date('01/01/2008','MM/DD/YYYY')) >= to_date('01/01/2008','MM/DD/YYYY') 
