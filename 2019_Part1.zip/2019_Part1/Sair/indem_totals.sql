select * from koc_clm_hlth_indem_totals a, koc_clm_indem_total_rules b
where contract_id = 300643084 
and partition_no = 1908 
and a.claim_inst_type = 'AK'
and a.claim_inst_loc = 'YI'
and a.parent_cover_code = 'S534'
--and a.cover_code <> a.parent_cover_code
--and a.cover_code = 'S513'
and a.package_id = b.package_id
and a.package_date = b.package_date
and a.cover_code = b.child_cover_code
and a.country_group = b.country_group
and a.claim_inst_type = b.claim_inst_type
and a.claim_inst_loc = b.claim_inst_loc
and a.is_pool_cover = b.is_pool_cover
and a.is_special_cover = b.is_special_cover



select * from koc_clm_indem_total_rules
where package_id= 114683
and package_date = '01.12.2018'
and claim_inst_type = 'AK'
and claim_inst_loc = 'YI'
and child_cover_code = 'S762'

select * from koc_clm_hlth_indem_totals where sub_package_id = 114683

S762

select * from koc_clm_hlth_indem_totals a
where a.contract_id = 290946944
and a.partition_no = 2
and a.claim_inst_type = 'AK'
and a.claim_inst_loc = 'YI'
and a.parent_cover_code = 'S174'
and exists (
SELECT *
FROM Koc_Clm_Indem_Total_Rules b
WHERE Package_Id = a.Sub_Package_Id
AND Package_Id = Package_Id_2
AND Country_Group_2 =a.Country_Group
AND Claim_Inst_Type_2 =a.Claim_Inst_Type
AND Claim_Inst_Loc_2 =a.Claim_Inst_Loc
AND Is_Pool_Cover = a.Is_Pool_Cover
AND Is_Special_Cover =  a.Is_Special_Cover
--AND Trunc(Package_Date) = Trunc(to_date('01/01/2007','MM/DD/YYYY'))
AND Country_Group = 0
AND Claim_Inst_Type = 'AK'
AND Claim_Inst_Loc = 'YI'
AND Child_Cover_Code = 'S762'
--AND Validity_Start_Date <= to_date('01/01/2008','MM/DD/YYYY')
--AND Nvl(Validity_End_Date, to_date('01/01/2008','MM/DD/YYYY')) >= to_date('01/01/2008','MM/DD/YYYY')


)

select * from koc_oc_packages where partition_type='TSS'

select * from KOC_OC_HLTH_PACK_COV_REL where package_id=32946
select * from KOC_CC_HLTH_LOC_COVER_PROC where cover_code='S508'

select * from koc_oc_hlth_expack_cov_rel where package_id='111684' and child_cover_code='S683'

select * from KOC_v_HLTH_PACK_COV_VIEW
