 
select a.package_id,a.package_id_2,a.* from koc_clm_indem_total_rules a
where a.package_id = 252480-- 118494
and a.package_date = '27.04.2017' --'01.12.2018'
and a.child_cover_code = 'S699' --'ST504'
and a.claim_inst_type = 'AHK-IS'
and a.claim_inst_loc = 'YI' 
 
300643084 
1908
-S687

SELECT a.Main_Or_Sub_Cov ,a.*
FROM Koc_Clm_Hlth_Indem_Totals a
WHERE 1=1
AND a.parent_Cover_Code ='S687'
AND a.Contract_Id = 300643084
AND a.Partition_No = 1908  
--AND a.Is_Pool_Cover = Nvl(0, 0)
AND a.Is_Special_Cover = Nvl(0, 0)
AND Nvl(a.Is_Valid, 0) = 1
AND a.Validity_Start_Date <= to_date('05/05/2017','MM/DD/YYYY')
AND Nvl(a.Validity_End_Date, to_date('05/05/2017','MM/DD/YYYY')) >= to_date('05/06/2017','MM/DD/YYYY')
and exists(
SELECT *
FROM Koc_Clm_Indem_Total_Rules b
WHERE Package_Id = a.Package_Id
AND Package_Id = Package_Id_2
AND Country_Group_2 =a.Country_Group
AND Claim_Inst_Type_2 =a.Claim_Inst_Type
AND Claim_Inst_Loc_2 =a.Claim_Inst_Loc
AND Is_Pool_Cover = a.Is_Pool_Cover
AND Is_Special_Cover =  a.Is_Special_Cover
AND Trunc(Package_Date) = Trunc(to_date('04/27/2017','MM/DD/YYYY'))
AND Country_Group = 0
AND Claim_Inst_Type = 'AK'
AND Claim_Inst_Loc = 'YI'
AND Child_Cover_Code = 'S687'
AND Validity_Start_Date <= to_date('04/27/2017','MM/DD/YYYY')
AND Nvl(Validity_End_Date, to_date('04/27/2018','MM/DD/YYYY')) >= to_date('05/05/2017','MM/DD/YYYY')
)


SELECT *
FROM Koc_Clm_Indem_Total_Rules b
WHERE Package_Id =252480
AND Package_Id = Package_Id_2
--AND Country_Group_2 =a.Country_Group
--AND Claim_Inst_Type_2 =a.Claim_Inst_Type
--AND Claim_Inst_Loc_2 =a.Claim_Inst_Loc
----AND Is_Pool_Cover = a.Is_Pool_Cover
--AND Is_Special_Cover =  a.Is_Special_Cover
AND Trunc(Package_Date) = Trunc(to_date('04/27/2017','MM/DD/YYYY'))
AND Country_Group = 0
AND Claim_Inst_Type = 'AK'
AND Claim_Inst_Loc = 'YI'
AND Child_Cover_Code = 'S687'
AND Validity_Start_Date <= to_date('04/27/2017','MM/DD/YYYY')
AND Nvl(Validity_End_Date, to_date('04/27/2018','MM/DD/YYYY')) >= to_date('05/06/2017','MM/DD/YYYY')


select * from ocp_policy_bases where contract_id = 353869514

0001071002777531

select a.POLICY_REF,a.POLICY_START_DATE,a.CONTRACT_ID,b.PART_ID,b.CARD_NO,c.IDENTITY_NO, a.COMPANY_CODE
  from KOC_V_HEALTH_INSURED_INFO a, koc_hlth_customer_id_cards b, koc_cp_partners_ext c
 WHERE a.PARTNER_ID = b.PART_ID
   AND c.PART_ID = b.PART_ID
   AND a.POLICY_REF='0001071002777531' 
   AND b.VALIDITY_END_DATE IS NULL;
   
   
   Koc_Clm_Hlth_Hospt_Utils.Resetsyt0


