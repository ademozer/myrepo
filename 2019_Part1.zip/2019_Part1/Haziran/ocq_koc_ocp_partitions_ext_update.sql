UPDATE ocq_koc_ocp_partitions_ext a 
   SET a.quote_status = 'T053' 
      ,a.quote_status_exp = 'T5947800 manual ��z�m' 
      ,a.quote_status_date = SYSDATE 
      ,a.quote_status_user = USER 
WHERE a.quote_id = 86753499 
  AND a.partition_no = 1168
/
COMMIT
/
