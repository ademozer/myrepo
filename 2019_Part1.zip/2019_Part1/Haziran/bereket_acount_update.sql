UPDATE alz_account_sap_attribute 
   SET trading_partner_code = 999999
 WHERE account_code IN('1220527814',
                       '1220527824')
/
COMMIT
/                                 
