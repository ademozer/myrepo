update koc_ocp_health
   set family_code = 20971   
 where contract_id = 443086403
  and partition_no = 24605
/
update ocq_koc_ocp_health
   set family_code = 20971 
 where contract_id = 443086403               
   and partition_no = 24605
/   
COMMIT
/
