delete koc_clm_hlth_provisions 
 where claim_id=37115745 
   and cover_code='S660'
/
COMMIT
/
