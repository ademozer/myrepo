grant select, insert, update, delete on CUSTOMER.ALZ_AFFLUENT_MAIL_LOG to ALLZWEBPOL
/
grant select, insert, update, delete on CUSTOMER.ALZ_AFFLUENT_MAIL_LOG to ALLZWEBPRV
/
grant select on CUSTOMER.ALZ_AFFLUENT_MAIL_LOG_S to ALLZWEBPOL
/
grant select on CUSTOMER.ALZ_AFFLUENT_MAIL_LOG_S to ALLZWEBPRV
/