UPDATE wip_policy_versions
   SET MOVE_CODE = 'GHGAQ',
       MOVEMENT_REASON_CODE = 'GHGAQ'
WHERE contract_id = 443204581
/
COMMIT
/
