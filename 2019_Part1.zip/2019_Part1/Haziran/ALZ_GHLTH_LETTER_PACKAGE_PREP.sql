
  CREATE OR REPLACE PACKAGE "CUSTOMER"."ALZ_GHLTH_LETTER" is

  c_dml_successful_insert           constant varchar2(10) := 'ins: 00000';
  c_dml_successful_update           constant varchar2(10) := 'upd: 00000';
  c_dml_successful_delete           constant varchar2(10) := 'del: 00000';
  c_TEST_MSG_ON  constant number := 1;
  c_TEST_MSG_OFF constant number := 0;
  c_successful_paragraph_setting   constant varchar2(10) := 'prg: 00000';
  c_successful_info_fetch           constant varchar2(10) := 'ftc: 00000';
  c_successful_letter_operations    constant varchar2(10) := 'let: 00000';
  -->-- muafiyet yaz� b�l�mleri ------------------------
  g_MFYT_YZS_SE                         koc_oc_hlth_doc_proc_ref.subject_exp%type;
  g_MFYT_YZS_P1                         koc_oc_hlth_doc_proc_ref.paragraph_1%type;
  g_MFYT_YZS_P1_1                       koc_oc_hlth_doc_proc_ref.paragraph_1%type;
  g_MFYT_YZS_P2                         koc_oc_hlth_doc_proc_ref.paragraph_2%type;
  g_MFYT_YZS_P2_1                       koc_oc_hlth_doc_proc_ref.paragraph_2%type;
  g_MFYT_YZS_P3                         koc_oc_hlth_doc_proc_ref.paragraph_3%type;
  g_MFYT_YZS_P3_1                         koc_oc_hlth_doc_proc_ref.paragraph_3%type;

  -->-- red yaz� b�l�mleri ------------------------
  g_KBL_EDLMYN_OBF_YZS_SE              koc_oc_hlth_doc_proc_ref.subject_exp%type;
  g_KBL_EDLMYN_OBF_YZS_P1              koc_oc_hlth_doc_proc_ref.paragraph_1%type;
  g_KBL_EDLMYN_OBF_YZS_P2              koc_oc_hlth_doc_proc_ref.paragraph_2%type;
  g_KBL_EDLMYN_OBF_YZS_P3              koc_oc_hlth_doc_proc_ref.paragraph_3%type;

  -->-- beyans�z yaz� b�l�mleri ------------------------
  g_BYN_EDLMYN_MVCT_HSTLK_YZS_SE  koc_oc_hlth_doc_proc_ref.subject_exp%type;
  g_BYN_EDLMYN_MVCT_HSTLK_YZS_P1  koc_oc_hlth_doc_proc_ref.paragraph_1%type;
  g_BYN_EDLMYN_MVCT_HSTLK_YZSP11  koc_oc_hlth_doc_proc_ref.paragraph_1%type;  --selcenk
  g_BYN_EDLMYN_MVCT_HSTLK_YZS_P2  koc_oc_hlth_doc_proc_ref.paragraph_2%type;
  g_BYN_EDLMYN_MVCT_HSTLK_YZSP21  koc_oc_hlth_doc_proc_ref.paragraph_2%type; -- selcenk
  g_BYN_EDLMYN_MVCT_HSTLK_YZS_P3  koc_oc_hlth_doc_proc_ref.paragraph_3%type;

  -->-- Global de�i�kenler -----------------------------

  g_policy_ref         ocp_policy_bases.policy_ref%type;
  g_group_name         koc_v_health_insured_info.group_name%type;
  g_sub_company_name   koc_v_health_insured_info.sub_company_name%type;
  g_group_code         koc_v_health_insured_info.group_code%type;
  g_sub_company_code   koc_v_health_insured_info.sub_company_code%type;
  g_family_code        koc_ocp_health.family_code%type;
  g_pol_version_no     koc_v_health_insured_info.version_no%type;

  g_police_ustu_uw_yazisi_T1 varchar2(1000) := null;
  g_police_ustu_uw_yazisi_T1_d varchar2(1000) := null;
  g_obf_hastalik_aciklama    varchar2(1000) := null; -- kullany�myyor..
  g_police_ustu_uw_yazisi_T3 varchar2(1000) := null;
  g_police_ustu_uw_yazisi_T3_d varchar2(1000) := null;

  g_product_ids_2_5            varchar2(1000) := null;
  g_product_ids_2_5_d            varchar2(1000) := null;
  g_uw_pack_nos_2_5            varchar2(1000) := null;
  g_uw_pack_nos_2_5_d            varchar2(1000) := null;
  g_surprim_oranlari           varchar2(1000) := null;
  g_surprim_oranlari_d           varchar2(1000) := null;
  g_application_codes_2_5      varchar2(1000) := null;
  g_application_codes_2_5_d      varchar2(1000) := null;

  g_bynsz_product_ids_2_5            varchar2(1000) := null;
  g_bynsz_product_ids_2_5_d            varchar2(1000) := null;
  g_bynsz_uw_pack_nos_2_5            varchar2(1000) := null;
  g_bynsz_uw_pack_nos_2_5_d            varchar2(1000) := null;
  g_bynsz_surprim_oranlari           varchar2(1000) := null;
  g_bynsz_surprim_oranlari_d           varchar2(1000) := null;
  g_bynsz_application_codes_2_5      varchar2(1000) := null;
  g_bynsz_application_codes_2_5d      varchar2(1000) := null;


  g_product_ids_8              varchar2(1000) := null;
  g_uw_pack_nos_8              varchar2(1000) := null;
  g_application_codes_8        varchar2(1000) := null;

  g_contract_id   ocp_policy_bases.contract_id%type;
  g_partition_no  number;

  g_cnt_mf        number := 0;
  g_cnt_mf_d        number := 0;
  g_cnt_sp        number := 0;
  g_cnt_sp_d        number := 0;
  g_bynsz_cnt_mf  number := 0;
  g_bynsz_cnt_mf_d  number := 0;
  g_bynsz_cnt_sp  number := 0;
  g_bynsz_cnt_sp_d  number := 0;

  type type_uwp_details is record(  uw_pack_no  koc_cp_hlth_uwp_part_rel.uw_pack_no%type
                              ,product_id  koc_cp_hlth_uwp_part_rel.product_id%type
                              ,uw_disease_code  koc_oc_hlth_uwp_detail.uw_disease_code%type
                              ,application_code  koc_oc_hlth_uwp_detail.application_code%type
                              ,hep_rate  koc_cp_hlth_uwp_part_rel.hep_rate%type
                              ,UW_PACK_NO_DESC  koc_oc_hlth_uwp_app_types.application_name%type
                              ,HAS_ADD_PREMIUM_DESC  varchar2(200)
                              ,modified_hep_rate  koc_cp_hlth_uwp_part_rel.modified_hep_rate%type
                              ,warning_and_rate   varchar2(2000)
                              ,warning_on_policy  koc_cp_hlth_uwp_part_rel.warning_on_policy%type
                              ,warning_on_policy_desc  varchar2(2000)
                              ,adsoyad varchar2(500)
                            );

  uwp_det_rec type_uwp_details;

  type ref_cur_sigortali is ref cursor;

  --procedure populate_uwp_table(p_part_id number);
  --function fn_set_global_sigortali_info(p_part_id number) return varchar2;

  function fn_get_app_code(  p_uw_pack_no      number
                            ,p_app_code        varchar2
                            ,p_product_id      number
                            ,p_uw_disease_code varchar2
                           ) return varchar2;

  function fn_set_mektup_paragraphs(  p_sigortali_adi_soyadi  varchar2
                                      --,p_policy_ref            varchar2
                                      --,p_partition_no          number
                                      --,p_grup_adi              varchar2
                                      ,p_police_ustu_uw_YAZISI varchar2
                                      ,p_obf_hastalik_aciklama varchar2
                                      ,p_dsig varchar2
                                      ,p_beyanli varchar2
                                      )return varchar2;

  function fn_run_mektup_process(p_contract_id number,p_part_id number, p_print number, p_version_no number) return varchar2;

  function fn_insert_action
  ( p_contract_id in number  , p_partition_no      in number  , p_report_type in varchar2, p_sub_report_type  varchar2
   ,p_se          in varchar2, p_p1                in varchar2, p_p2          in varchar2, p_p3               varchar2
   ,p_version     in number  , p_c_value_1         in varchar2, p_n_value_1   in number
   ,p_part_id     in number  , p_product_ids       in varchar2, p_group_code  in varchar2, p_sub_company_code varchar2
   ,p_uw_pack_nos in varchar2, p_application_codes in varchar2, p_family_code in varchar2
  )
  return varchar2;


  /*function fn_update_action
  ( p_contract_id in number  , p_partition_no in number, p_report_type varchar2, p_sub_report_type varchar2
   ,p_se          in varchar2, p_p1 varchar2           , p_p2          varchar2, p_p3 varchar2
  )return varchar2;
  */

  function fn_delete_tmp_letters
  ( p_contract_id in number, p_partition_no in number)
  return varchar2;

  function fn_get_next_version(p_contract_id in number, p_partition_no in number) return number;

  function FN_POLICY_REF(p_contract_id number)return varchar2;

procedure validate_uw_pack_no( p_uw_pack_no in out koc_cp_hlth_uwp_part_rel.uw_pack_no%type
                              ,p_product_id in out koc_cp_hlth_uwp_part_rel.product_id%type
                              ,p_out_uw_disease_code in out koc_oc_hlth_uwp_detail.uw_disease_code%type
                              ,p_out_application_code in out koc_oc_hlth_uwp_detail.application_code%type
                              ,p_in_out_hep_rate in out koc_cp_hlth_uwp_part_rel.hep_rate%type
                              ,p_out_UW_PACK_NO_DESC in out koc_oc_hlth_uwp_app_types.application_name%type
                              ,p_out_HAS_ADD_PREMIUM_DESC in out varchar2
                              ,p_modified_hep_rate in koc_cp_hlth_uwp_part_rel.modified_hep_rate%type
                              ,p_out_warning_and_rate in out varchar2
                              ,p_in_out_warning_on_policy in out varchar2
                              ,p_out_warning_on_policy_desc in out varchar2
);

PROCEDURE set_warning_on_pol ( p_uw_pack_no_desc in varchar2
                              ,p_warning_on_policy_desc in varchar2
                              ,p_application_code in koc_oc_hlth_uwp_detail.application_code%type
                              ,p_modified_hep_rate in koc_cp_hlth_uwp_part_rel.modified_hep_rate%type
                              ,p_out_warning_and_rate in out varchar2
);

PROCEDURE set_warning_on_pol_desc(set_just_default number
                              ,p_product_id in koc_cp_hlth_uwp_part_rel.product_id%type
                              ,p_uw_disease_code in out koc_oc_hlth_uwp_detail.uw_disease_code%type
                              ,p_application_code in out koc_oc_hlth_uwp_detail.application_code%type
                              ,p_out_UW_PACK_NO_DESC in out koc_oc_hlth_uwp_app_types.application_name%type
                              ,p_in_out_warning_on_policy in out varchar2
                              ,p_modified_hep_rate in koc_cp_hlth_uwp_part_rel.modified_hep_rate%type
                              ,p_out_warning_on_policy_desc in out varchar2
                              ,p_warning_and_rate in out varchar2
);

function fn_tamlayan_eki(p_isim varchar2) return varchar2;

FUNCTION FN_ADSOYAD (p_part_id IN NUMBER) RETURN VARCHAR2;

function fn_has_sent_before( p_contract_id               number
                              ,p_partition_no            number
                              ,p_report_type             varchar2
                              ,p_sub_report_type         varchar2
                              ,p_uw_pack_no              number
                              ,p_uw_pack_nos             varchar2
                              ,p_part_id                 number
                              ,p_by_part_or_contract     varchar2
                              ,p_by_uw_pack_set_or_item  varchar2
  )
  return number;

function fn_validate_note_date(p_date date, p_note_start_date date, p_note_end_date date, p_product_id number)
return number;

  function fn_is_cont_partition_alive(p_contract_id in number, p_partition_no in number)
	return number;

end ALZ_GHLTH_LETTER;

CREATE OR REPLACE PACKAGE BODY "CUSTOMER"."ALZ_GHLTH_LETTER" is
 cursor cr_uwp_part_rel(cp_pid number)
  is
    select uwp.uw_creation_type beyanli_mi,uwp.* from KOC_CP_HLTH_UWP_PART_REL uwp
     where part_id = cp_pid
       and rec_status = '1';

    rec_uwp_part_rel cr_uwp_part_rel%rowtype;


  function fn_run_mektup_process (p_contract_id number,p_part_id number, p_print number, p_version_no number)
  return varchar2
  is
    l_dml_res            varchar2(100);   --> Mektup paketi i�inde ger�ekle�tirilen DML i�lemlerin sonucu
    l_mf_veya_sp_mevcut  number := 0;     --> Ba�lanan paketler aras�nda MUAF�YET ve/veya S�RPR�M var m�?
    l_mf_veya_sp_mevcut_d  number := 0;
    l_bynsz_mf_veya_sp_mevcut number := 0;
    l_bynsz_mf_veya_sp_mevcut_d number := 0;
    l_red_mevcut         number := 0;     --> Ba�lanan paketler aras�nda RED var m�?
    l_red_mevcut_d         number := 0;
    l_next_version       number;          --> Mektup versiyonu
    l_app_code           koc_oc_hlth_uwp_detail.application_code%type;

    l_part_id            number;
    l_family_code        number;

    l_mr_rep_result      varchar2(100);

    rc_sigortali  ref_cur_sigortali;
    rec           koc_v_health_insured_info%rowtype;

    function fn_family_code(p_contract_id number, p_partition_no number)
    return number
    is
      l_fam number;

      cursor c_fam is
      select family_code

        from koc_ocp_health h
       where h.contract_id  = p_contract_id
         and h.partition_no = p_partition_no
         and top_indicator  = 'Y'
         and rownum < 2;
    begin
      open c_fam;
        fetch c_fam into l_fam;
      close c_fam;

      return l_fam;

      exception
        when others then
          return null;
    end fn_family_code;

  begin

    l_mf_veya_sp_mevcut := 0;
    g_cnt_mf            := 0;
    g_cnt_mf_d            := 0;
    g_cnt_sp            := 0;
    g_cnt_sp_d            := 0;
    l_red_mevcut        := 0;


    open cr_uwp_part_rel(p_part_id);
    fetch cr_uwp_part_rel into rec_uwp_part_rel;
    if( cr_uwp_part_rel%notfound )then
      close cr_uwp_part_rel; -- eklenecek
      return('-999');
    else
      null;
    end if;

    -->-- Sigortal� bilgileri al�n�r..
       -- �r�n tipi ba�lanan paketin �r�n tipine uygun her bir poli�e i�in birer mektup i�lemi yap�l�r
       -- ��nk� bir sigortal� birden �ok  poli�eye ba�l� olabilir -------------------------------------
    l_part_id := p_part_id;

    begin
      koc_clm_hlth_utils.getpolicyinfobypartid (l_part_id, null, rc_sigortali);
      exception when others then
        raise;
    end;

    LOOP

      fetch rc_sigortali into rec;
      exit when rc_sigortali%notfound;

      if(rec.contract_id = p_contract_id and
         fn_is_cont_partition_alive(rec.contract_id, rec.partition_no) = 1
      )then
        if cr_uwp_part_rel%isopen then close cr_uwp_part_rel; end if;

        open cr_uwp_part_rel(p_part_id); -- eklenecek
        fetch cr_uwp_part_rel into rec_uwp_part_rel;

        g_police_ustu_uw_yazisi_T1 := NULL;
        g_police_ustu_uw_yazisi_T1_d := NULL;
        g_obf_hastalik_aciklama    := NULL;
        g_police_ustu_uw_yazisi_T3 := NULL;
        g_police_ustu_uw_yazisi_T3_d := NULL;

        g_product_ids_2_5          := NULL;
        g_product_ids_2_5_d          := NULL;
        g_uw_pack_nos_2_5          := NULL;
        g_uw_pack_nos_2_5_d          := NULL;
        g_surprim_oranlari         := NULL;
        g_surprim_oranlari_d         := NULL;
        g_application_codes_2_5    := NULL;
        g_application_codes_2_5_d    := NULL;

        g_bynsz_product_ids_2_5          := NULL;
        g_bynsz_product_ids_2_5_d          := NULL;
        g_bynsz_uw_pack_nos_2_5          := NULL;
        g_bynsz_uw_pack_nos_2_5_d          := NULL;
        g_bynsz_surprim_oranlari         := NULL;
        g_bynsz_surprim_oranlari_d         := NULL;
        g_bynsz_application_codes_2_5    := NULL;
        g_bynsz_application_codes_2_5d    := NULL;

        g_product_ids_8            := NULL;
        g_uw_pack_nos_8            := NULL;
        g_application_codes_8      := NULL;

        l_mf_veya_sp_mevcut        := 0;
        g_cnt_mf                   := 0;
        g_cnt_sp                   := 0;
        l_red_mevcut               := 0;
        l_bynsz_mf_veya_sp_mevcut  := 0;

        g_policy_ref       := rec.policy_ref;
        g_contract_id      := rec.contract_id;
        g_pol_version_no   := rec.version_no;
        g_partition_no     := rec.partition_no;
        g_group_name       := rec.group_name;
        g_sub_company_name := rec.sub_company_name;
        g_group_code       := rec.group_code;
        g_sub_company_code := rec.sub_company_code;
        g_family_code      := fn_family_code(g_contract_id, g_partition_no);

        -->-- Hen�z bas�lmam�� olan ge�ici mektuplar silinir. -----------
        begin
          l_dml_res := fn_delete_tmp_letters(g_contract_id, g_partition_no);

          if(l_dml_res <> c_dml_successful_delete)then
            return l_dml_res;
          end if;
        end;
        --<-- Hen�z bas�lmam�� olan ge�ici mektuplar silinir. -----------

        l_next_version := fn_get_next_version(g_contract_id, g_partition_no);

        -->-- Blok �zerinde INSERT modlu kay�tlar�n poli�e �zeri UW yaz�lar� ", " ile bir araya getirilir.----
        loop

          if(rec.partition_type             = rec_uwp_part_rel.PARTITION_TYPE             and
             rec.product_id                 = rec_uwp_part_rel.PRODUCT_ID                 and
             nvl(rec.group_code, '0')       = nvl(rec_uwp_part_rel.GROUP_CODE, '0')       and
             nvl(rec.sub_company_code, '0') = nvl(rec_uwp_part_rel.SUB_COMPANY_CODE, '0') and
             fn_validate_note_date(rec.term_end_date, rec_uwp_part_rel.note_start_date,rec_uwp_part_rel.note_end_date,
                                   rec_uwp_part_rel.product_id
                                  ) = 1
          )then

            uwp_det_rec.uw_pack_no        := rec_uwp_part_rel.uw_pack_no;
            uwp_det_rec.product_id        := rec_uwp_part_rel.product_id;
            uwp_det_rec.hep_rate          := rec_uwp_part_rel.hep_rate;
            uwp_det_rec.modified_hep_rate := rec_uwp_part_rel.modified_hep_rate;
            uwp_det_rec.warning_on_policy := rec_uwp_part_rel.warning_on_policy;
            uwp_det_rec.adsoyad           := fn_adsoyad(rec_uwp_part_rel.part_id);

            validate_uw_pack_no( uwp_det_rec.uw_pack_no
                                ,uwp_det_rec.product_id
                                ,uwp_det_rec.uw_disease_code
                                ,uwp_det_rec.application_code
                                ,uwp_det_rec.hep_rate
                                ,uwp_det_rec.UW_PACK_NO_DESC
                                ,uwp_det_rec.HAS_ADD_PREMIUM_DESC
                                ,uwp_det_rec.modified_hep_rate
                                ,uwp_det_rec.warning_and_rate
                                ,uwp_det_rec.warning_on_policy
                                ,uwp_det_rec.warning_on_policy_desc
                               );

           -->-- paket kayd� ge�erli olmal� -----------------------------------
           if(rec_uwp_part_rel.rec_status <> '2')then
             l_app_code := fn_get_app_code( rec_uwp_part_rel.uw_pack_no, null
                                                       ,rec_uwp_part_rel.product_id, null
                                                      );

              if( l_app_code like '2%' or l_app_code like '5%' or l_app_code = 31 )then -- orhan topal 27122017 katki payi 32 kaldirildi
               if(rec_uwp_part_rel.UW_CREATION_TYPE = '1') then
                  if rec_uwp_part_rel.dsig = 1 then
                     --selcenk 18/12/2014--
                     l_mf_veya_sp_mevcut_d        := l_mf_veya_sp_mevcut_d + 1;

                     if(l_app_code like '5%')then g_cnt_mf_d := g_cnt_mf_d + 1; else g_cnt_sp_d := g_cnt_sp_d + 1; end if;

                     g_police_ustu_uw_yazisi_T1_d := g_police_ustu_uw_yazisi_T1_d                 ||
                                                   uwp_det_rec.warning_and_rate || ', ' || chr(10);

                     g_product_ids_2_5_d       := g_product_ids_2_5_d       || rec_uwp_part_rel.product_id        || '|';
                     g_uw_pack_nos_2_5_d       := g_uw_pack_nos_2_5_d       || rec_uwp_part_rel.uw_pack_no        || '|';
                     g_application_codes_2_5_d := g_application_codes_2_5_d || l_app_code                                  || '|';
                     g_surprim_oranlari_d      := g_surprim_oranlari_d      || rec_uwp_part_rel.modified_hep_rate || '|';
                    --selcenk 18/12/2014--
                  else
                     l_mf_veya_sp_mevcut        := l_mf_veya_sp_mevcut + 1;

                     if(l_app_code like '5%')then g_cnt_mf := g_cnt_mf + 1; else g_cnt_sp := g_cnt_sp + 1; end if;

                     g_police_ustu_uw_yazisi_T1 := g_police_ustu_uw_yazisi_T1        ||
                                                   uwp_det_rec.warning_and_rate || ', ' || chr(10);

                     g_product_ids_2_5       := g_product_ids_2_5       || rec_uwp_part_rel.product_id        || '|';
                     g_uw_pack_nos_2_5       := g_uw_pack_nos_2_5       || rec_uwp_part_rel.uw_pack_no        || '|';
                     g_application_codes_2_5 := g_application_codes_2_5 || l_app_code                         || '|';
                     g_surprim_oranlari      := g_surprim_oranlari      || rec_uwp_part_rel.modified_hep_rate || '|';
                  end if; --dsig kontrol�
               elsif  (rec_uwp_part_rel.UW_CREATION_TYPE = '2') then --   beyans�z
                  if rec_uwp_part_rel.dsig = '1' then
                        --selcenk 18/12/2014 --
                     l_bynsz_mf_veya_sp_mevcut_d := l_bynsz_mf_veya_sp_mevcut_d + 1;

                     if(l_app_code like '5%')then g_bynsz_cnt_mf_d := g_bynsz_cnt_mf_d + 1; else g_bynsz_cnt_sp_d := g_bynsz_cnt_sp_d + 1; end if;

                     g_police_ustu_uw_yazisi_T3_d := g_police_ustu_uw_yazisi_T3_d                 ||
                                                   uwp_det_rec.warning_and_rate || ', ' || chr(10);

                     g_bynsz_product_ids_2_5_d       := g_bynsz_product_ids_2_5_d       || rec_uwp_part_rel.product_id        || '|';
                     g_bynsz_uw_pack_nos_2_5_d       := g_bynsz_uw_pack_nos_2_5_d       || rec_uwp_part_rel.uw_pack_no        || '|';
                     g_bynsz_application_codes_2_5d := g_bynsz_application_codes_2_5d || l_app_code                                  || '|';
                     g_bynsz_surprim_oranlari_d      := g_bynsz_surprim_oranlari_d      || rec_uwp_part_rel.modified_hep_rate || '|';
                      --selcenk 18/12/2014 --
                  else
                     l_bynsz_mf_veya_sp_mevcut := l_bynsz_mf_veya_sp_mevcut + 1;

                     if(l_app_code like '5%')then g_bynsz_cnt_mf := g_bynsz_cnt_mf + 1; else g_bynsz_cnt_sp := g_bynsz_cnt_sp + 1; end if;

                     g_police_ustu_uw_yazisi_T3 := g_police_ustu_uw_yazisi_T3                 ||
                                                   uwp_det_rec.warning_and_rate || ', ' || chr(10);

                     g_bynsz_product_ids_2_5       := g_bynsz_product_ids_2_5       || rec_uwp_part_rel.product_id        || '|';
                     g_bynsz_uw_pack_nos_2_5       := g_bynsz_uw_pack_nos_2_5       || rec_uwp_part_rel.uw_pack_no        || '|';
                     g_bynsz_application_codes_2_5 := g_bynsz_application_codes_2_5 || l_app_code                                  || '|';
                     g_bynsz_surprim_oranlari      := g_bynsz_surprim_oranlari      || rec_uwp_part_rel.modified_hep_rate || '|';
                  end if; --dsig kontrol�
               end if; --beyanl� m� kontrol�
            end if;
           end if;
          --<-- paket kayd� ge�erli olmal� -----------------------------------
        end if;


          fetch cr_uwp_part_rel into rec_uwp_part_rel;  -- eklenecek
          if(cr_uwp_part_rel%notfound)then exit; end if; -- eklenecek

        end loop;
        close cr_uwp_part_rel;
        --<-- Blok �zerinde INSERT modlu kay�tlar�n poli�e �zeri UW yaz�lar� ", " ile bir araya getirilir.----

        -->-- e�er muafiyet ya da s�rprim mevcut ise ---------------
        if(l_mf_veya_sp_mevcut > 0 and
           --selcenk 11/12/2014 task 186996  fn_has_sent_before(g_contract_id, g_partition_no, '1', '1',null, g_uw_pack_nos_2_5, p_part_id, 'BY_PART', 'UW_PACK_SET') = 0
             fn_has_sent_before(g_contract_id, g_partition_no, '1', '1',null, g_uw_pack_nos_2_5, p_part_id, 'BY_CONTRACT', 'UW_PACK_SET' ) = 0
        )then
          g_police_ustu_uw_yazisi_T1 := substr(g_police_ustu_uw_yazisi_T1, 1, length(g_police_ustu_uw_yazisi_T1) - 3);

          -- Mektup paragraflar� olu�turulmal�.
          l_dml_res := fn_set_mektup_paragraphs(  uwp_det_rec.adsoyad
                                                          --,p_policy_ref            varchar2
                                                          --,p_partition_no          number
                                                          --,p_grup_adi              varchar2
                                                            ,g_police_ustu_uw_yazisi_T1
                                                            ,null--p_obf_hastalik_aciklama varchar2
                                                            ,'0'
                                                            ,'1'--beyanl�
                                                          );

          if(l_dml_res <> c_successful_paragraph_setting)then
            return l_dml_res;
          end if;

          -->-- Muafiyet/S�rprim mektubu insert edilir ---
          begin
            l_dml_res :=
              fn_insert_action(
                g_contract_id, g_partition_no, '1', '1'
               ,g_MFYT_YZS_SE, g_MFYT_YZS_p1, g_MFYT_YZS_p2, g_MFYT_YZS_p3
               ,l_next_version
               ,g_group_name || ';' || g_sub_company_name || ';' || g_surprim_oranlari --c_value_1
               ,null                                                                                           --n_value_1
               ,l_part_id, g_product_ids_2_5, g_group_code, g_sub_company_code
               ,g_uw_pack_nos_2_5, g_application_codes_2_5, g_family_code
              );

            if(l_dml_res <> c_dml_successful_insert)then
              return l_dml_res;
            end if;

            if(p_print = 1)then
              /*pr_mr_raporu( g_contract_id, g_partition_no, p_version_no--l_next_version
                           ,'1', '1', 'PRINTER', l_mr_rep_result
                          );*/-- ekrana bas�l�yor kald�r�ls�

              if(l_mr_rep_result <> '0')then
                null;
                --return l_mr_rep_result;
              end if;
            end if;

          end;
          --<-- Muafiyet/S�rprim mektubu insert edilir ---

        end if;
        -----------------------selcenk 22/12/2014-------------------
        if(l_mf_veya_sp_mevcut_d > 0 and
             fn_has_sent_before(g_contract_id, g_partition_no, '1', '2',null, g_uw_pack_nos_2_5_d, p_part_id, 'BY_CONTRACT', 'UW_PACK_SET' ) = 0
        )then
          g_police_ustu_uw_yazisi_T1_d := substr(g_police_ustu_uw_yazisi_T1_d, 1, length(g_police_ustu_uw_yazisi_T1_d) - 3);
            -- Mektup paragraflar� olu�turulmal�.
          l_dml_res := fn_set_mektup_paragraphs(  uwp_det_rec.adsoyad
                                                          --,p_policy_ref            varchar2
                                                          --,p_partition_no          number
                                                          --,p_grup_adi              varchar2
                                                            ,g_police_ustu_uw_yazisi_T1_d
                                                            ,null--p_obf_hastalik_aciklama varchar2
                                                            ,'1'
                                                            ,'1'--beyanl�
                                                          );

          if(l_dml_res <> c_successful_paragraph_setting)then
            return l_dml_res;
          end if;

          -->-- Muafiyet/S�rprim mektubu insert edilir ---
          begin
            l_dml_res :=
              fn_insert_action(
                g_contract_id, g_partition_no, '1', '2'
               ,g_MFYT_YZS_SE, g_MFYT_YZS_p1_1, g_MFYT_YZS_p2_1, g_MFYT_YZS_p3
               ,l_next_version
               ,g_group_name || ';' || g_sub_company_name || ';' || g_surprim_oranlari_d --c_value_1
               ,null                                                                                           --n_value_1
               ,l_part_id, g_product_ids_2_5_d, g_group_code, g_sub_company_code
               ,g_uw_pack_nos_2_5_d, g_application_codes_2_5_d, g_family_code
              );

            if(l_dml_res <> c_dml_successful_insert)then
              return l_dml_res;
            end if;
            if(p_print = 1)then
              /*pr_mr_raporu( g_contract_id, g_partition_no, p_version_no--l_next_version
                           ,'1', '2', 'PRINTER', l_mr_rep_result);*/-- ekran bas�m� kald�r�ld�
              if(l_mr_rep_result <> '0')then
                null;
              end if;
            end if;

          end;
          --<-- Muafiyet/S�rprim mektubu insert edilir ---
        end if;
        -----------------------selcenk 22/12/2014-------------------

        --<-- e�er muafiyet ya da s�rprim mevcut ise ---------------

        -->-- red mevcutsa -----------------------------------------
        if(l_red_mevcut > 0 and
          --selcenk 11/12/2014 task 186996   fn_has_sent_before(g_contract_id, g_partition_no, '2', '2' , null, g_uw_pack_nos_8, p_part_id, 'BY_PART', 'UW_PACK_SET') = 0
            fn_has_sent_before(g_contract_id, g_partition_no, '2', '2' , null, g_uw_pack_nos_8, p_part_id, 'BY_CONTRACT', 'UW_PACK_SET') = 0
        )then
          -- Mektup paragraflar� olu�turulmal�.
          g_obf_hastalik_aciklama := substr(g_obf_hastalik_aciklama, 1, length(g_obf_hastalik_aciklama) - 2);
          l_dml_res := fn_set_mektup_paragraphs(  uwp_det_rec.adsoyad
                                                            --,p_policy_ref            varchar2
                                                            --,p_partition_no          number
                                                            --,p_grup_adi              varchar2
                                                              ,g_police_ustu_uw_yazisi_T1
                                                              ,g_obf_hastalik_aciklama
                                                              ,'0'
                                                              ,null
                                                           );

          if(l_dml_res <> c_successful_paragraph_setting)then
            return l_dml_res;
          end if;

          -->-- Red Mektupu insert edilir. --------
          begin
            l_dml_res :=
              fn_insert_action(
                g_contract_id, g_partition_no, '2', '2'
               ,g_KBL_EDLMYN_OBF_YZS_SE, g_KBL_EDLMYN_OBF_YZS_p1
               ,g_KBL_EDLMYN_OBF_YZS_p2, g_KBL_EDLMYN_OBF_YZS_p3
               ,l_next_version
               ,g_group_name || ';' || g_sub_company_name
               ,null
               ,l_part_id, g_product_ids_8, g_group_code, g_sub_company_code
               ,g_uw_pack_nos_8, g_application_codes_8, g_family_code
              );

            if(l_dml_res <> c_dml_successful_insert)then
              return l_dml_res;
            end if;

            if(p_print = 1)then
             /* pr_mr_raporu( g_contract_id, g_partition_no, p_version_no--l_next_version
                           ,'2', '2', 'PRINTER', l_mr_rep_result
                          );*/ --ekran bas�m� kald�r�ld�

              if(l_mr_rep_result <> '0')then
                null;
                --return l_mr_rep_result;
              end if;
            end if;
          end;
          --<-- Red Mektupu insert edilir. --------
        end if;
        --<-- red mevcutsa ---------

        -->-- e�er beyans�z muafiyet ya da s�rprim mevcut ise ---------------
        if(l_bynsz_mf_veya_sp_mevcut > 0 and
           -- selcenk 11/12/2014 task 186996 fn_has_sent_before(g_contract_id, g_partition_no, '3', '3' ,  null, g_bynsz_uw_pack_nos_2_5, p_part_id, 'BY_PART', 'UW_PACK_SET') = 0
           fn_has_sent_before(g_contract_id, g_partition_no, '3', '3' ,  null, g_bynsz_uw_pack_nos_2_5, p_part_id, 'BY_CONTRACT', 'UW_PACK_SET') = 0
        )then

          g_police_ustu_uw_yazisi_T3 := substr(g_police_ustu_uw_yazisi_T3, 1, length(g_police_ustu_uw_yazisi_T3) - 3);

          -- Mektup paragraflar� olu�turulmal�.
          l_dml_res := fn_set_mektup_paragraphs(  uwp_det_rec.adsoyad
                                                          --,p_policy_ref            varchar2
                                                          --,p_partition_no          number
                                                          --,p_grup_adi              varchar2
                                                            ,g_police_ustu_uw_yazisi_T3
                                                            ,null--p_obf_hastalik_aciklama varchar2
                                                            ,'0'
                                                            ,'2'--beyans�z)
                                                          );

          if(l_dml_res <> c_successful_paragraph_setting)then
            return l_dml_res;
          end if;

          -->-- Beyans�z Muafiyet/S�rprim mektubu insert edilir ---
          begin
            l_dml_res :=
              fn_insert_action(
                g_contract_id, g_partition_no, '3', '3'
               ,g_BYN_EDLMYN_MVCT_HSTLK_YZS_SE, g_BYN_EDLMYN_MVCT_HSTLK_YZS_p1
               ,g_BYN_EDLMYN_MVCT_HSTLK_YZS_p2, g_BYN_EDLMYN_MVCT_HSTLK_YZS_p3
               ,l_next_version
               ,g_group_name || ';' || g_sub_company_name || ';' || g_bynsz_surprim_oranlari --c_value_1
               ,null                                                                                                 --n_value_1
               ,l_part_id, g_bynsz_product_ids_2_5, g_group_code, g_sub_company_code
               ,g_bynsz_uw_pack_nos_2_5, g_bynsz_application_codes_2_5, g_family_code
              );

            if(l_dml_res <> c_dml_successful_insert)then
              return l_dml_res;
            end if;

            if(p_print = 1)then
            /*  pr_mr_raporu( g_contract_id, g_partition_no, p_version_no--l_next_version
                           ,'3', '3', 'PRINTER', l_mr_rep_result
                          );*/--ekran bas�m� kald�r�ld�

              if(l_mr_rep_result <> '0')then
                null;
                --return l_mr_rep_result;
              end if;
            end if;
          end;
          --<-- Beyans�z Muafiyet/S�rprim mektubu insert edilir ---
        end if;


        ------------------selcenk 22/12/2014----------------
       if(l_bynsz_mf_veya_sp_mevcut_d > 0 and
           -- selcenk 11/12/2014 task 186996 fn_has_sent_before(g_contract_id, g_partition_no, '3', '3' ,  null, g_bynsz_uw_pack_nos_2_5, p_part_id, 'BY_PART', 'UW_PACK_SET') = 0
           fn_has_sent_before(g_contract_id, g_partition_no, '3', '4' ,  null, g_bynsz_uw_pack_nos_2_5_d, p_part_id, 'BY_CONTRACT', 'UW_PACK_SET') = 0
        )then

          g_police_ustu_uw_yazisi_T3_d := substr(g_police_ustu_uw_yazisi_T3_d, 1, length(g_police_ustu_uw_yazisi_T3_d) - 3);

          -- Mektup paragraflar� olu�turulmal�.
          l_dml_res := fn_set_mektup_paragraphs(  uwp_det_rec.adsoyad
                                                          --,p_policy_ref            varchar2
                                                          --,p_partition_no          number
                                                          --,p_grup_adi              varchar2
                                                            ,g_police_ustu_uw_yazisi_T3_d
                                                            ,null--p_obf_hastalik_aciklama varchar2
                                                            ,'1'
                                                            ,'2'--beyans�z
                                                          );

          if(l_dml_res <> c_successful_paragraph_setting)then
            return l_dml_res;
          end if;

          -->-- Beyans�z Muafiyet/S�rprim mektubu insert edilir ---
          begin
            l_dml_res :=
              fn_insert_action(
                g_contract_id, g_partition_no, '3', '4'
               ,g_BYN_EDLMYN_MVCT_HSTLK_YZS_SE, g_BYN_EDLMYN_MVCT_HSTLK_YZSp11
               ,g_BYN_EDLMYN_MVCT_HSTLK_YZSp21, g_BYN_EDLMYN_MVCT_HSTLK_YZS_p3
               ,l_next_version
               ,g_group_name || ';' || g_sub_company_name || ';' || g_bynsz_surprim_oranlari --c_value_1
               ,null                                                                                                 --n_value_1
               ,l_part_id, g_bynsz_product_ids_2_5_d, g_group_code, g_sub_company_code
               ,g_bynsz_uw_pack_nos_2_5_d, g_bynsz_application_codes_2_5d, g_family_code
              );

            if(l_dml_res <> c_dml_successful_insert)then
              return l_dml_res;
            end if;

            if(p_print = 1)then
            /*  pr_mr_raporu( g_contract_id, g_partition_no, p_version_no--l_next_version
                           ,'3', '4', 'PRINTER', l_mr_rep_result
                          );*/--ekrandan kald�r�ld�

              if(l_mr_rep_result <> '0')then
                null;
                --return l_mr_rep_result;
              end if;
            end if;
          end;
          --<-- Beyans�z Muafiyet/S�rprim mektubu insert edilir ---
        end if;

        -----------------selcenk 22/12/2014-----------------------------
        --<-- e�er beyans�z muafiyet ya da s�rprim mevcut ise ---------------
      end if; -- rec.contract_id = :parameter.contract_id and fn_is_cont_partition_alive(rec.contract_id, rec.partition_no) = 1
      END LOOP;
      --ADD_CODE:KORA05:18.03.2008
      --cr_uwp_part_rel kapatilmadan cikilabiliyordu. bu durumu engellemek icin eklendi
      -->>
      if cr_uwp_part_rel%isopen then close cr_uwp_part_rel; end if;
      --<<
      if rc_sigortali%isopen then close rc_sigortali;end if;
      --<-- Sigortal� bilgileri al�n�r.. Her bir poli�e i�in birer mektup i�lemi yap�l�r
         -- ��nk� bir sigortal� birden �ok  poli�eye ba�l� olabilir -------------------------------------

    return c_successful_letter_operations;
  End fn_run_mektup_process;


  function fn_get_app_code(  p_uw_pack_no       number
                            ,p_app_code         varchar2
                            ,p_product_id       number
                            ,p_uw_disease_code  varchar2
                           )
  return varchar2
  is
    l_app_code varchar2(10);

    cursor c
        is
          select uwp_app.APPLICATION_CODE
            from koc_oc_hlth_uwp_detail    uwp_det
                ,koc_oc_hlth_uwp_app_types uwp_app
          where uwp_det.uw_pack_no       = p_uw_pack_no
            and uwp_det.application_code = nvl(p_app_code, uwp_det.application_code)
            and uwp_det.product_id       = nvl(p_product_id, uwp_det.product_id)
            and uwp_det.uw_disease_code  = nvl(p_uw_disease_code, uwp_det.uw_disease_code)
            and sysdate between uwp_det.validity_start
                            and nvl(uwp_det.validity_end, to_date('31129999', 'DDMMYYYY'))
            and uwp_app.application_code = uwp_det.application_code
            and sysdate between uwp_app.validity_start_date
                            and nvl(uwp_app.validity_end_date, to_date('31129999', 'DDMMYYYY'))
            and rownum < 2;
  begin
    open c;
      fetch c into l_app_code;
    close c;

    return l_app_code;
  End fn_get_app_code;

  function fn_insert_action
  ( p_contract_id in number  , p_partition_no      in number  , p_report_type in varchar2, p_sub_report_type  varchar2
   ,p_se          in varchar2, p_p1                in varchar2, p_p2          in varchar2, p_p3               varchar2
   ,p_version     in number  , p_c_value_1         in varchar2, p_n_value_1   in number
   ,p_part_id     in number  , p_product_ids       in varchar2, p_group_code  in varchar2, p_sub_company_code varchar2
   ,p_uw_pack_nos in varchar2, p_application_codes in varchar2, p_family_code in varchar2
  )
  return varchar2
  is -- Herhangi tipten bir mektubu insert eder...
    l_ileti number;
    l_pol_ref varchar2(30);

  begin
    savepoint mr_insert_point;

    l_pol_ref := FN_POLICY_REF(p_contract_id);


    insert into koc_oc_hlth_doc_proc_ref (
       ref_no, report_type, sub_report_type, version_no,
       report_occurance_date, created_by, updated_by,
       subject_exp, paragraph_1, paragraph_2, paragraph_3,
       is_printable,
       contract_id, partition_no, print_date, c_value_1, n_value_1,
       part_id, product_ids, group_code, sub_company_code,
       uw_pack_nos, application_codes, family_code,pol_version_no)
    values (l_pol_ref || '/' ||p_partition_no, p_report_type, p_sub_report_type, p_version
        , sysdate, user, null
        , p_se, p_p1, p_p2, p_p3
        , null
        , p_contract_id, p_partition_no, null, p_c_value_1 || 'Poli�ele�tirme' , p_n_value_1
        , p_part_id, p_product_ids, p_group_code, p_sub_company_code
        , p_uw_pack_nos, p_application_codes, p_family_code, g_pol_version_no
    );
    commit;
    return c_dml_successful_insert;
    exception
      when others then
        ROLLBACK to mr_insert_point;
        return 'INSERT ERROR -> ' || sqlcode || ' : ' || sqlerrm;

  End fn_insert_action;


  function fn_delete_tmp_letters
  ( p_contract_id in number, p_partition_no in number)
  return varchar2
  is -- Kesinle�memi� mektuplar� siler.. Bir mektup i�leminden �nce muhakkak uygulanmal�d�r.
    l_ileti number;
  begin
    savepoint mr_tmp_delete_point;

    delete from koc_oc_hlth_doc_proc_ref  dpr
     where dpr.contract_id  = p_contract_id
       and dpr.partition_no = p_partition_no
       and dpr.print_date   is null
       and dpr.report_type  in('1', '2', '3');

    return c_dml_successful_delete;

    exception
      when others then
        ROLLBACK to mr_tmp_delete_point;
        return 'FN_DELETE_TMP_LETTERS ERROR -> ' || sqlcode || ' : ' || sqlerrm;

  End fn_delete_tmp_letters;


  function fn_get_next_version(p_contract_id in number, p_partition_no in number)
  return number
  is
    l_nv number;
  begin
    select nvl(max(version_no) , 0) + 1
      into l_nv
      from koc_oc_hlth_doc_proc_ref  dpr
     where dpr.contract_id  = p_contract_id
       and dpr.partition_no = p_partition_no
       and dpr.report_type  in('1', '2', '3');

    return l_nv;
  end;

  function FN_POLICY_REF(p_contract_id number)
  return varchar2
  is
    l_pol_ref varchar2(30);
  begin
    begin
      select policy_ref
        into l_pol_ref
        from ocp_policy_bases pb
       where pb.contract_id = p_contract_id
         and pb.version_no  = 1
         and rownum         < 2;

      exception
        when others then
          return null;
    end;


    if(l_pol_ref is not null)then
      l_pol_ref := substr(l_pol_ref,1,4) || ' ' || substr(l_pol_ref,5,4)  || ' ' ||
                   substr(l_pol_ref,9,4) || ' ' || substr(l_pol_ref,13,4);
    end if;

    return l_pol_ref;
  end FN_POLICY_REF;

procedure validate_uw_pack_no( p_uw_pack_no                 in out koc_cp_hlth_uwp_part_rel.uw_pack_no%type
                              ,p_product_id                 in out koc_cp_hlth_uwp_part_rel.product_id%type
                              ,p_out_uw_disease_code        in out koc_oc_hlth_uwp_detail.uw_disease_code%type
                              ,p_out_application_code       in out koc_oc_hlth_uwp_detail.application_code%type
                              ,p_in_out_hep_rate            in out koc_cp_hlth_uwp_part_rel.hep_rate%type
                              ,p_out_UW_PACK_NO_DESC           in out koc_oc_hlth_uwp_app_types.application_name%type
                              ,p_out_HAS_ADD_PREMIUM_DESC      in out varchar2
                              ,p_modified_hep_rate              in koc_cp_hlth_uwp_part_rel.modified_hep_rate%type
                              ,p_out_warning_and_rate       in out varchar2
                              ,p_in_out_warning_on_policy   in out varchar2
                              ,p_out_warning_on_policy_desc    in out varchar2
)
is
  v_hep_rate koc_oc_hlth_uwp_detail.add_premium_rate%type;
begin

  begin
    begin
    -- paket okunur
    select t.uw_disease_code,
           t.application_code,
           t.add_premium_rate
      into p_out_uw_disease_code,
           p_out_application_code,
           v_hep_rate
      from koc_oc_hlth_uwp_detail t
     where t.uw_pack_no = p_uw_pack_no
       and t.product_id = p_product_id
       and t.validity_end is null;

    exception when no_data_found then
      -- paket okunur
      select t.uw_disease_code,
             t.application_code,
             t.add_premium_rate
        into p_out_uw_disease_code,
             p_out_application_code,
             v_hep_rate
        from koc_oc_hlth_uwp_detail t
       where t.uw_pack_no = p_uw_pack_no
         and t.product_id = p_product_id
         and t.validity_end = ( select max(tt.validity_end)
                                       from koc_oc_hlth_uwp_detail tt
                                      where tt.uw_pack_no = p_uw_pack_no
                                        and tt.product_id = p_product_id
                                    )
         and rownum < 2;

    end;

    if nvl(v_hep_rate,-1)<>nvl(p_in_out_hep_rate,-2) and v_hep_rate is not null then
      p_in_out_hep_rate:=v_hep_rate;
    end if;

    exception
      when others then
        p_uw_pack_no := null;
        p_out_application_code := null;
        p_out_uw_disease_code := null;
  end;

  -- uygulama tipleri
  begin
    select t.application_name ,
           decode(t.has_add_premium, 1 , 'Evet', 0 , 'Hay�r', 'Hay�r')  has_add_premium_desc
      into p_out_UW_PACK_NO_DESC,
           p_out_HAS_ADD_PREMIUM_DESC
      from koc_oc_hlth_uwp_app_types t
     where t.validity_end_date is null
       and t.application_code = p_out_application_code;
    exception when others then
      p_out_UW_PACK_NO_DESC:=null;
      p_out_HAS_ADD_PREMIUM_DESC:=null;
  end;



  -- Hastalik Kodlari
  begin
    select nvl(p_out_UW_PACK_NO_DESC, ' ') || ' : ' ||
           nvl(t.disease_group_name,' ')
      into p_out_UW_PACK_NO_DESC
      from koc_oc_hlth_uwp_dis_groups t
     where t.validity_end_date is null
       and t.uw_disease_code = p_out_uw_disease_code;

    exception when others then null;
  end;


  set_warning_on_pol ( p_out_uw_pack_no_desc
                      ,p_out_warning_on_policy_desc
                      ,p_out_application_code
                      ,p_modified_hep_rate
                      ,p_out_warning_and_rate
                      );
  if p_uw_pack_no is null then
    p_uw_pack_no := 0;
  end if;


  -- police ustu mesaji

      set_warning_on_pol_desc(0
                              ,p_product_id
                              ,p_out_uw_disease_code
                              ,p_out_application_code
                              ,p_out_UW_PACK_NO_DESC
                              ,p_in_out_warning_on_policy
                              ,p_modified_hep_rate
                              ,p_out_warning_on_policy_desc
                              ,p_out_warning_and_rate
      ); -- warning_on_policy degerini getirir
        if nvl(p_in_out_warning_on_policy ,0) = 0  then
          set_warning_on_pol_desc(1
                                      ,p_product_id
                                      ,p_out_uw_disease_code
                                      ,p_out_application_code
                                      ,p_out_UW_PACK_NO_DESC
                                      ,p_in_out_warning_on_policy
                                      ,p_modified_hep_rate
                                      ,p_out_warning_on_policy_desc
                                      ,p_out_warning_and_rate
              ); -- bulamadiysa default'u getirir
        end if;


end validate_uw_pack_no;


PROCEDURE set_warning_on_pol ( p_uw_pack_no_desc         in  varchar2
                              ,p_warning_on_policy_desc  in  varchar2
                              ,p_application_code        in  koc_oc_hlth_uwp_detail.application_code%type
                              ,p_modified_hep_rate       in  koc_cp_hlth_uwp_part_rel.modified_hep_rate%type
                              ,p_out_warning_and_rate   in out  varchar2
)
IS
BEGIN
  if p_APPLICATION_CODE in (11,81,91) then
      -- red veya kabul ise hastalik + uyg.
      p_out_warning_and_rate := p_UW_PACK_NO_DESC ;
  else
      -- degilse police ustu mesaji
       p_out_warning_and_rate := p_warning_on_policy_desc ;
  end if;

  -- null ise bosluk ata
  if p_out_warning_and_rate is null then p_out_warning_and_rate:=' '; end if;

  -- rate'i ekle
  if nvl(p_modified_hep_rate,0)>0 then
    p_out_warning_and_rate := p_out_warning_and_rate || ' (%' ||
                              p_modified_hep_rate || ')';
  end if;

END set_warning_on_pol;

PROCEDURE set_warning_on_pol_desc(set_just_default number
                              ,p_product_id          in koc_cp_hlth_uwp_part_rel.product_id%type
                              ,p_uw_disease_code     in out koc_oc_hlth_uwp_detail.uw_disease_code%type
                              ,p_application_code    in out koc_oc_hlth_uwp_detail.application_code%type
                              ,p_out_UW_PACK_NO_DESC in out koc_oc_hlth_uwp_app_types.application_name%type
                              ,p_in_out_warning_on_policy in out varchar2
                              ,p_modified_hep_rate in koc_cp_hlth_uwp_part_rel.modified_hep_rate%type
                              ,p_out_warning_on_policy_desc in out varchar2
                              ,p_warning_and_rate in out varchar2
) IS
  v_WARNING_ON_POLICY koc_cp_hlth_uwp_part_rel.WARNING_ON_POLICY%type;
BEGIN


  begin
    -- default warning ref okunur
    select WARNING_ON_POLICY, get_desc_int_id_name(t.desc_int_id, null)
      into v_WARNING_ON_POLICY ,
           p_out_warning_on_policy_desc
      from koc_oc_hlth_uwp_warn_ref t
     where t.uw_disease_code  = p_uw_disease_code
       and t.application_code = p_application_code
       AND T.PRODUCT_ID = p_PRODUCT_ID
       anD T.WARNING_ON_POLICY = (decode(nvl(set_just_default,0), 1, T.WARNING_ON_POLICY, p_in_out_WARNING_ON_POLICY ))
       and t.is_default=(decode(nvl(set_just_default,0), 1, 1, t.is_default ))
       and t.validity_end_date is null
       and rownum<2
     order by t.validity_start_date desc;

    if ( nvl(v_WARNING_ON_POLICY,-1) <> nvl(p_in_out_WARNING_ON_POLICY,-2)) then
      p_in_out_WARNING_ON_POLICY:=v_WARNING_ON_POLICY;
    end if;

  exception when others then
    if p_in_out_WARNING_ON_POLICY is not null then
      p_in_out_WARNING_ON_POLICY := null;
    end if;
    p_out_warning_on_policy_desc := null;
  end;

    set_warning_on_pol ( p_out_uw_pack_no_desc
                      ,p_out_warning_on_policy_desc
                      ,p_application_code
                      ,p_modified_hep_rate
                      ,p_warning_and_rate
                      );

END set_warning_on_pol_desc;

function fn_tamlayan_eki(p_isim varchar2)
return varchar2
is
  -- �simlere uygun olan -n�n -nin -nun -n�n -n -in -un -�n
  -- iyelik eklerinden birini d�nderir.
  -- saim kuru, kora 16/08/2006
  l_sesli_harfler constant varchar2(20) := 'AaEeI��iOo��Uu��';

  j number;
  l_ek varchar2(3);
  l_harf varchar2(1);
  l_sesli varchar2(1);
  l_sesli_yer number;
  l_found boolean := false;

  l_cnt number := 0;
begin
  l_found := false;
  j := length(p_isim);

  loop
    l_cnt := l_cnt + 1;

    l_harf := substr(p_isim, j, 1);

    if(instr(l_sesli_harfler, l_harf) > 0)then
      l_found     := true;
      l_sesli     := l_harf;
      l_sesli_yer := j;
    end if;

    if(l_sesli in('A','a'))then
      l_ek := '�n';
    elsif(l_sesli in('E','e'))then
      l_ek := 'in';
    elsif(l_sesli in('I','i'))then
      l_ek := '�n';
    elsif(l_sesli in('�','i'))then
      l_ek := 'in';
    elsif(l_sesli in('O','o'))then
      l_ek := 'un';
    elsif(l_sesli in('�','�'))then
      l_ek := '�n';
    elsif(l_sesli in('U','u'))then
      l_ek := 'un';
    elsif(l_sesli in('�','�'))then
      l_ek := '�n';
    end if;

    if(l_found = true)then
      if( l_sesli_yer = length(p_isim))then
        l_ek := 'n' || l_ek;
        return l_ek;
      else
        return l_ek;
      end if;
    end if;

    exit when l_found = true or l_cnt = 100;

    j:= j - 1;

  end loop;

  l_ek :=  null;
  return l_ek;
End fn_tamlayan_eki;

FUNCTION FN_ADSOYAD (p_part_id IN NUMBER) --RETURN _ IS
  RETURN VARCHAR2 IS
DEGER VARCHAR2(80);

BEGIN
  SELECT FIRST_NAME||' '||NAME
    INTO DEGER
    FROM KOC_cp_v_hlth_partners
   WHERE PART_ID = p_part_id
     and sysdate between from_date and end_date;
  RETURN(DEGER);

 exception
  when no_data_found then
    return null;

  when others then
   return null;
    --raise;
 END;

  function fn_has_sent_before( p_contract_id             number
                              ,p_partition_no            number
                              ,p_report_type             varchar2
                              ,p_sub_report_type         varchar2
                              ,p_uw_pack_no              number
                              ,p_uw_pack_nos             varchar2
                              ,p_part_id                 number
                              ,p_by_part_or_contract     varchar2
                              ,p_by_uw_pack_set_or_item  varchar2
  )
  return number
  is
    l_ret number := 0;

    function fn_do_strings_differ (p_string_to_tokenize varchar2, p_string_to_tokenize2 varchar2, p_delimeter varchar2)
    return number
    is
      l_dif number;
    begin
      select count(*)
        into l_dif from
        ( select Rtrim( Substr( x.token, Instr(x.token, p_delimeter, 1, iter.pos) + 1, Instr(x.token, p_delimeter, 1, iter.pos + 1) - Instr(x.token, p_delimeter, 1, iter.pos)
                              ), p_delimeter
                      ) token --, iter.pos as position
            from ( select p_delimeter || p_string_to_tokenize || p_delimeter token from dual) x
                ,( select rownum as pos from all_objects where rownum <=100)                 iter
           where iter.pos <= (Length(x.token) - Length(replace(x.token, p_delimeter))) - 1
          MINUS
          select Rtrim( Substr( x.token, Instr(x.token, p_delimeter, 1, iter.pos) + 1, Instr(x.token, p_delimeter, 1, iter.pos + 1) - Instr(x.token, p_delimeter, 1, iter.pos)
                              ), p_delimeter
                      ) token --, iter.pos as position
            from ( select p_delimeter || p_string_to_tokenize2 || p_delimeter token from dual) x
                ,( select rownum as pos from all_objects where rownum <=100)                  iter
           where iter.pos <= (Length(x.token) - Length(replace(x.token, p_delimeter))) - 1
          UNION ALL
          select Rtrim( Substr( x.token, Instr(x.token, p_delimeter, 1, iter.pos) + 1, Instr(x.token, p_delimeter, 1, iter.pos + 1) - Instr(x.token, p_delimeter, 1, iter.pos)
                              ), p_delimeter
                      ) token --, iter.pos as position
            from ( select p_delimeter || p_string_to_tokenize2 || p_delimeter token from dual) x
                ,( select rownum as pos from all_objects where rownum <=100)                  iter
           where iter.pos <= (Length(x.token) - Length(replace(x.token, p_delimeter))) - 1
          MINUS
          select Rtrim( Substr( x.token, Instr(x.token, p_delimeter, 1, iter.pos) + 1, Instr(x.token, p_delimeter, 1, iter.pos + 1) - Instr(x.token, p_delimeter, 1, iter.pos)
                              ), p_delimeter
                      ) token --, iter.pos as position
            from ( select p_delimeter || p_string_to_tokenize || p_delimeter token from dual) x
                ,( select rownum as pos from all_objects where rownum <=100)                 iter
           where iter.pos <= (Length(x.token) - Length(replace(x.token, p_delimeter))) - 1
        );

      return l_dif;
    end fn_do_strings_differ;


  begin
    l_ret := 0;

    if(p_uw_pack_no is null and p_uw_pack_nos is null)then return 1; end if;
    if(p_by_part_or_contract not in('BY_PART', 'BY_CONTRACT'))then return 1; end if;
    if(p_by_uw_pack_set_or_item not in('UW_PACK_ITEM', 'UW_PACK_SET'))then return 1; end if;

    if(p_by_part_or_contract = 'BY_CONTRACT')then
      if(p_by_uw_pack_set_or_item = 'UW_PACK_ITEM') then
        select count(*)
          into l_ret
          from koc_oc_hlth_doc_proc_ref v
         where v.contract_id     = p_contract_id
           and v.partition_no    = p_partition_no
           and v.report_type     = p_report_type
           and v.sub_report_type = p_sub_report_type
           and (    v.uw_pack_nos like         p_uw_pack_no || '|%'
                 or v.uw_pack_nos like '%|' || p_uw_pack_no || '|%'
                 or v.uw_pack_nos = p_uw_pack_no
               )
           and v.print_date is not null;


        return l_ret;
      elsif(p_by_uw_pack_set_or_item = 'UW_PACK_SET') then
        for cr_set_by_contract in( select uw_pack_nos
                                    from koc_oc_hlth_doc_proc_ref v
                                   where v.contract_id     = p_contract_id
                                     and v.partition_no    = p_partition_no
                                     and v.report_type     = p_report_type
                                     and v.sub_report_type = p_sub_report_type
                                     and v.print_date is not null
        )loop
          if(fn_do_strings_differ(p_uw_pack_nos, cr_set_by_contract.uw_pack_nos, '|') > 0)then
            l_ret := 1;
            exit;
          end if;

        end loop;

        return l_ret;
      end if;

    Elsif(p_by_part_or_contract = 'BY_PART')then
      if(p_by_uw_pack_set_or_item = 'UW_PACK_ITEM') then
        select count(*)
          into l_ret
          from koc_oc_hlth_doc_proc_ref v
         where v.part_id         = p_part_id
           and v.report_type     = p_report_type
           and v.sub_report_type = p_sub_report_type
           and (    v.uw_pack_nos like         p_uw_pack_no || '|%'
                 or v.uw_pack_nos like '%|' || p_uw_pack_no || '|%'
                 or v.uw_pack_nos = p_uw_pack_no
               )
           and v.print_date is not null;

       return l_ret;
      elsif(p_by_uw_pack_set_or_item = 'UW_PACK_SET') then
        for cr_set_by_part in( select uw_pack_nos
                                 from koc_oc_hlth_doc_proc_ref v
                                where v.part_id         = p_part_id
                                  and v.report_type     = p_report_type
                                  and v.sub_report_type = p_sub_report_type
                                  and v.print_date is not null
        )loop
          if(fn_do_strings_differ(p_uw_pack_nos, cr_set_by_part.uw_pack_nos, '|') = 0)then
            l_ret := 1;
            exit;
          end if;

        end loop;

        return l_ret;
      end if;
    End if;

    exception when others then
      raise;
      --return 0;
  end fn_has_sent_before;

  function fn_validate_note_date(p_date date, p_note_start_date date, p_note_end_date date, p_product_id number)
  return number
  is
  begin
    if( p_note_start_date <= p_date and
        (  ( NVL(p_note_end_date, SYSDATE) >= SYSDATE and
             p_date > SYSDATE and
             p_product_id = 64
           )OR
           ( NVL(p_note_end_date, p_date) >= p_date and
             p_date < SYSDATE and
             p_product_id = 64
           )OR
           ( NVL(p_note_end_date, p_date) >= p_date and
                 p_product_id = 63
           )
        )
    )then
      return 1;
    else
      return 0;
    end if;
  end fn_validate_note_date;

  function fn_is_cont_partition_alive(p_contract_id in number, p_partition_no in number)
  return number
  is
    l_cnt number;
  begin
    select count(*)
      into l_cnt
      from koc_ocp_partitions_ext pe
     where pe.contract_id  = p_contract_id
       and pe.partition_no = p_partition_no
       and action_code     = 'D'
       and top_indicator   = 'Y';

      if( l_cnt > 0)then
        return 0;
      else
        return 1;
      end if;

      exception
        when others then
          return 0;
  end fn_is_cont_partition_alive;

  function fn_set_mektup_paragraphs(  p_sigortali_adi_soyadi  varchar2
                                     ,p_police_ustu_uw_YAZISI varchar2
                                     ,p_obf_hastalik_aciklama varchar2
                                     ,p_dsig varchar2
                                     ,p_beyanli varchar2
                                   )
  return varchar2
  is
    l_ileti           number;
    l_mf_ve_sp        varchar2(100);
    l_bynsz_mf_ve_sp  varchar2(100);
  begin
    g_MFYT_YZS_SE :=null;
    g_MFYT_YZS_P1 :=null;
    g_MFYT_YZS_P1_1 :=null;
    g_MFYT_YZS_P2 :=null;
    g_MFYT_YZS_P2_1 :=null;
    g_BYN_EDLMYN_MVCT_HSTLK_YZS_P1 :=null;
    g_BYN_EDLMYN_MVCT_HSTLK_YZSP11 :=null;
    g_BYN_EDLMYN_MVCT_HSTLK_YZS_P2 :=null;
    g_BYN_EDLMYN_MVCT_HSTLK_YZSP21 :=null;
    g_MFYT_YZS_SE := substr( 'Sigortal� ' || p_sigortali_adi_soyadi          ||
                                         ''' ' || fn_tamlayan_eki(p_sigortali_adi_soyadi) ||
                                         ' Poli�e Uygulamalar� Hakk�nda.'
                                         , 1, 200);

    if p_beyanli='1' and nvl(p_dsig,'0')='0' then  -- beyanli + dsigsiz
       g_MFYT_YZS_P1 := substr( '�irketimiz, Grup Sa�l�k Sigorta Poli�esi �zel �artlar� ve Grup Protokolleri gere�ince, '  ||
                                            'Risk De�erlendirmesi yapmaktador. ' ||
                                            'Bu de�erlendirme sonucunda mevcut hastal���n riskine '   ||
                                            'g�re hastal�k istisnas�/ hastal�k ek primi(s�rprimi) uygulanmas� veya ba�vurunun kabul edilmemesi se�eneklerine g�re karar verilmektedir.'
                                            , 1, 2000); -- selcenk 22/12/2014
       g_MFYT_YZS_P2 := substr( ' Sn. ' || p_sigortali_adi_soyadi||''' '|| fn_tamlayan_eki(p_sigortali_adi_soyadi) ||
                                            ' beyan etmi� olduklar� rahats�zl�klar� nedeniyle poli�esine a�a��daki �ekilde uygulama yap�lm��t�r;' ||
                                            chr(10)|| '"' ||p_police_ustu_uw_YAZISI   || '" '|| l_mf_ve_sp
                                            , 1, 2000 -- selcenk 22/12/2014
                                            );
    end if;

    if p_beyanli='1' and nvl(p_dsig,'0')='1' then  -- beyanli + dsigli (Mektup tipi 2 )
       g_MFYT_YZS_P1_1 :=  substr( '�irketimiz, Grup Sa�l�k Sigorta Poli�esi �zel �artlar� ve Grup Protokolleri gere�ince, '||
                                               'Risk De�erlendirmesi yapmaktad�r. ' ||
                                               'Bu de�erlendirme sonucunda mevcut hastal���n riskine '   ||
                                               'g�re hastal�k istisnas�/ hastal�k ek primi(s�rprimi) uygulanmas� veya ba�vurunun kabul edilmemesi se�eneklerine g�re karar verilmektedir.'
                                               , 1, 2000); -- selcenk 22/12/2014

       g_MFYT_YZS_P2_1 :=  substr( 'Sn. ' || p_sigortali_adi_soyadi||''' ' || fn_tamlayan_eki(p_sigortali_adi_soyadi)||
                                              ' beyan etmi� olduklar� rahats�zl�klar� ve/veya �nceki sigorta �irketinden temin edilmi� olan '||
                                              ' ge�i� bilgilerinde varolan poli�e uygulamalar� nedeniyle, poli�e a�a��daki �ekilde d�zenlenmi�tir; '  || '"' ||
                                              chr(10)|| p_police_ustu_uw_YAZISI || '" '||l_mf_ve_sp
                                             , 1, 2000 );  -- selcenk 22/12/2014
    end if;

    if p_beyanli='2' and nvl(p_dsig,'0')='0' then -- beyansiz + dsigsiz
       g_MFYT_YZS_P1 :=  substr( '�irketimiz, Grup Sa�l�k Sigorta Poli�esi �zel �artlar� ve Grup Protokolleri gere�ince, '||
                                             'Risk De�erlendirmesi yapmaktad�r. ' ||
                                             'Bu de�erlendirme sonucunda mevcut hastal���n riskine '   ||
                                             'g�re hastal�k istisnas�/ hastal�k ek primi(s�rprimi) uygulanmas� veya ba�vurunun kabul edilmemesi se�eneklerine g�re karar verilmektedir.'
                                             , 1, 2000); -- selcenk 22/12/2014

       g_MFYT_YZS_P2 := substr(  'Sn. ' || p_sigortali_adi_soyadi||''' '|| fn_tamlayan_eki(p_sigortali_adi_soyadi)||
                                             ' poli�eye giri� / kabul edilmi� olan ilk sigortal�l�k tarihinden �nce varolan rahats�zl�klar�ndan dolay� a�a��daki �ekilde uygulama yap�lm��t�r;' ||
                                              chr(10)|| '" ' ||p_police_ustu_uw_YAZISI   || '" ' ||l_mf_ve_sp
                                             , 1, 2000); -- selcenk 22/12/2014
    end if;

-->-- Red Mektup Paragraflar� ----
   g_KBL_EDLMYN_OBF_YZS_SE := substr( p_sigortali_adi_soyadi || ''' ' || fn_tamlayan_eki(p_sigortali_adi_soyadi)   ||
                                                  ' Sa�l�k Sigortas� Poli�esine Giri� Talebi Hakk�nda.'
                                                 , 1, 200
                                                );

   g_KBL_EDLMYN_OBF_YZS_P1 := substr( '�irketimiz, Grup Sa�l�k Sigortas� Poli�e �zel �artlar� gere�ince, '      ||
                                                  'sigorta kapsam�na dahil olacak ki�ilerin �nbilgi formunda beyan etti�i ' ||
                                                  't�m bilgileri esas alarak risk de�erlendirmesi yapmaktad�r. '            ||
                                                  'Bu de�erlendirme sonucunda �irketimiz, mevcut hastal���n riskine g�re '  ||
                                                  'ilgili ki�iyi sigortalamayabilmektedir.'
                                                 , 1, 2000
                                                );

  g_KBL_EDLMYN_OBF_YZS_P2 := substr( g_sub_company_name || ' Grup Sigortal�m�z Sn. ' ||
                                                 p_sigortali_adi_soyadi || ''' ' || fn_tamlayan_eki(p_sigortali_adi_soyadi) ||
                                                 ' grup sa�l�k sigorta kapsam�na al�nmas� i�in  doldurdu�u '             ||
                                                 '�n bilgi formunda '
                                                , 1, 2000
                                               );

  g_KBL_EDLMYN_OBF_YZS_P3 := substr( 'Taraf�m�zdan yap�lan de�erlendirmede bu durumun sa�l�k sigortas� '     ||
                                                 'a��s�ndan olu�turdu�u y�ksek risk nedeniyle  Sn.: '                    ||
                                                 p_sigortali_adi_soyadi || ''' ' || fn_tamlayan_eki(p_sigortali_adi_soyadi) ||
                                                 ' poli�eye giri�i yap�lamamaktad�r.'
                                                , 1, 2000
                                               );

   g_BYN_EDLMYN_MVCT_HSTLK_YZS_SE := substr( 'Sigortal� ' || p_sigortali_adi_soyadi        ||
                                         ''' ' || fn_tamlayan_eki(p_sigortali_adi_soyadi) ||
                                      --   '? ' || fn_tamlayan_eki('sERKAN') ||
                                         ' Poli�e Uygulamalar� Hakk�nda.'
                                         --' Poli�esine Uygulanan Muafiyet Hakk�nda.'
                                        , 1, 200
                                       );
-------------mektup tipi 3 'e kar��l�k geliyor ????? ----------------------

     if p_beyanli='2' and nvl(p_dsig,'0')='0' then  -- beyansiz + dsigli
      g_BYN_EDLMYN_MVCT_HSTLK_YZS_P1 :=  substr( '�irketimiz, Grup Sa�l�k Sigorta Poli�esi �zel �artlar� ve Grup Protokolleri gere�ince, '||
                                             'Risk De�erlendirmesi yapmaktad�r. ' ||
                                             'Bu de�erlendirme sonucunda mevcut hastal���n riskine '   ||
                                             'g�re hastal�k istisnas�/ hastal�k ek primi(s�rprimi) uygulanmas� veya ba�vurunun kabul edilmemesi se�eneklerine g�re karar verilmektedir.'
                                             , 1, 2000); -- selcenk 22/12/2014

       g_BYN_EDLMYN_MVCT_HSTLK_YZS_P2 := substr(  'Sn. ' || p_sigortali_adi_soyadi||''' '|| fn_tamlayan_eki(p_sigortali_adi_soyadi)||
                                             ' poli�eye giri� / kabul edilmi� olan ilk sigortal�l�k tarihinden �nce varolan rahats�zl�klar�ndan dolay� a�a��daki �ekilde uygulama yap�lm��t�r;' ||
                                              chr(10)|| '" ' ||p_police_ustu_uw_YAZISI   || '" ' ||l_mf_ve_sp
                                             , 1, 2000); -- selcenk 22/12/2014

     end if;
     if p_beyanli='2' and nvl(p_dsig,'0')='1' then  -- beyansiz + dsigli

      g_BYN_EDLMYN_MVCT_HSTLK_YZSP11 := substr( '�irketimiz, Grup Sa�l�k Sigorta Poli�esi �zel �artlar� ve Grup Protokolleri gere�ince, '||
                                               'Risk De�erlendirmesi yapmaktad�r. ' ||
                                               'Bu de�erlendirme sonucunda mevcut hastal���n riskine '   ||
                                               'g�re hastal�k istisnas�/ hastal�k ek primi(s�rprimi) uygulanmas� veya ba�vurunun kabul edilmemesi se�eneklerine g�re karar verilmektedir.'
                                               , 1, 2000); -- selcenk 22/12/2014

      g_BYN_EDLMYN_MVCT_HSTLK_YZSP21 := substr( 'Sn. ' || p_sigortali_adi_soyadi||''' '|| fn_tamlayan_eki(p_sigortali_adi_soyadi)||
                                               ' �nceki sigorta �irketinden temin edilmi� olan ge�i� bilgilerinde varolan a�a��daki poli�e uygulamalar� aktar�lm��t�r; ' ||
                                               chr(10)|| '" ' ||p_police_ustu_uw_YAZISI   || '" '||l_mf_ve_sp
                                               , 1, 2000);
     end if;

 return c_successful_paragraph_setting;

  exception
    when others then
      --l_ileti := fn_ileti_goster('ALERT_ERROR', 'PR_SET_MEKTUP_PARAGRAPHS ERROR -> ' || sqlcode || ' : ' || sqlerrm);
      return 'FN_SET_MEKTUP_PARAGRAPHS ERROR -> ' || sqlcode || ' : ' || sqlerrm;
  End fn_set_mektup_paragraphs;


end ALZ_GHLTH_LETTER;
/
