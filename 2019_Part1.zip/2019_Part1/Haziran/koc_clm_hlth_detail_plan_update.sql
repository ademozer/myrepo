UPDATE koc_clm_hlth_detail
   SET package_id = 260758
 WHERE ext_reference = '57513674'
/
COMMIT
/
