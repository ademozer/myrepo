 SELECT   a.master_data_type,
                /* DECODE (
                     a.opus_code,
                     'MAPPING',
                     (SELECT   b.master_data_code
                        FROM   alz_account_sap_attribute_rel b
                       WHERE   b.account_code = a.account_code
                               AND b.opus_code =
                                     NVL (p_posting.opus_master_code, 'X')),
                     a.master_data_code
                  )
                     master_data_code,*/
                  a.special_gl_indicator_code,
                  a.posting_key_debit,
                  a.posting_key_credit,
                  a.sap_account,
                 /* DECODE (a.opus_code,
                          'MAPPING', NVL (p_posting.opus_master_code, 'X'),
                          a.opus_code)
                     opus_code,*/
                  a.account_category_code,
                  a.has_trading_partner,
                  a.has_sub_item,
                  a.has_dist_channel,
                  a.has_date_of_loss,
                  a.has_region,
                  a.has_cost_center,
                  a.has_invoice_no,
                  a.has_invoice_date,
                  a.has_vendor_name,
                  a.has_lob,
                  a.has_customer_segment,
                  a.check_mandatory_fields,
                  a.account_sap_type,
                  a.sub_item_group_code,
                  a.internal_account_id,
                  a.is_swift,
                  a.sub_account_category,
                  a.sap_transfered,
                  a.tax_code,
                  a.ledger_group,
                  a.sap_oper_account,
                  a.trading_partner_code,
                  a.default_cost_center,
                  a.account_code
           FROM   alz_account_sap_attribute a
          WHERE   a.account_code IN('1220527814',
          '1220527824')
          
          
          
          
          
          
          '1220527614',
          '1220527624',          
          '1220527714',
          '1220527814',
          '1220527824'
          
          SELECT a.GL_ACCT_REF_CODE HESAP_KODU, 
          b.LONG_NAME A�IKLAMA
     FROM Ac_Gl_System_Refs a, 
          CUR_TRANSLATIONS b
    WHERE a.GL_ACCT_REF_CODE IN ( 
          '1220527814',
          '1220527824'
                                 )
       AND a.DESC_INT_ID = b.DESC_INT_ID
    AND b.SULA_ORA_NLS_CODE = 'TR'
    --AND b.long_name like '%F�BA%'


 '1220527814',
          '1220527824'
          
          UPDATE alz_account_sap_attribute 
             SET trading_partner_code = 999999
           WHERE account_code IN('1220527814',
                                 '1220527824')
