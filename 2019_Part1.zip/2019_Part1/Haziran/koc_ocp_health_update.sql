update koc_ocp_health 
   set action_code = 'D'
 where contract_id = 434415571 
   and partition_no = 500
   and version_no = 15
/
COMMIT
/
 
