ALTER TABLE ALZ_HCLM_VERSION_INFO RENAME COLUMN TPA_COMPONY_CODE TO TPA_COMPANY_CODE
/
ALTER TABLE ALZ_HCLM_VERSION_INFO ADD(group_code       VARCHAR2(10),
                                      partner_id       NUMBER(10),
                                      contract_id      NUMBER(10),
                                      partition_no     NUMBER(5),
                                      bre_result_code  VARCHAR2(10),
                                      approved_status  VARCHAR2(50),
                                      customer_type    NUMBER(2))
/
comment on column ALZ_HCLM_VERSION_INFO.group_code
  is 'Poliçenin Grup Kodu'
/  
comment on column ALZ_HCLM_VERSION_INFO.partner_id
  is 'Unsur Numarası'
/  
comment on column ALZ_HCLM_VERSION_INFO.contract_id
  is 'Poliçe No'
/  
comment on column ALZ_HCLM_VERSION_INFO.partition_no
  is 'Poliçedeki Sıra No'
/  
comment on column ALZ_HCLM_VERSION_INFO.bre_result_code
  is 'BRE de çıkan sonuç kodu'
/  
comment on column ALZ_HCLM_VERSION_INFO.approved_status
  is 'Onaylanma Durumu'
/  
comment on column ALZ_HCLM_VERSION_INFO.customer_type
  is '0-Normal,1-Affluent, 2- CSuite, vb.'
/ 