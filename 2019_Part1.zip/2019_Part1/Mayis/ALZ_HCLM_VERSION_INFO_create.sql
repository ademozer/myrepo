create table ALZ_HCLM_VERSION_INFO
(
  claim_id         NUMBER(10) not null,
  sf_no            NUMBER(4) not null,
  add_order_no     NUMBER(2) not null,
  version_no       NUMBER(10) not null,
  log_id           NUMBER(10),
  entry_date       DATE default SYSDATE not null,
  user_id          VARCHAR2(50),
  is_limit_updated NUMBER(1),
  status_code      VARCHAR2(10),
  hclm_usage       NUMBER(1),
  institute_code   NUMBER(10),
  tpa_company_code VARCHAR2(10),
  hclm_channel     VARCHAR2(50),
  provision_type   NUMBER(1),
  group_code       VARCHAR2(10),
  partner_id       NUMBER(10),
  contract_id      NUMBER(10),
  partition_no     NUMBER(5),
  bre_result_code  VARCHAR2(10),
  approved_status  VARCHAR2(50),
  customer_type    NUMBER(2),
  CONSTRAINT ALZ_HCLM_VERSION_INFO_PK PRIMARY KEY (CLAIM_ID,SF_NO,ADD_ORDER_NO,VERSION_NO)
)
/
comment on table ALZ_HCLM_VERSION_INFO
  is 'HCLM sisteminden alınan provizyonlar için versiyon bilgilerinini tutar'
/  
comment on column ALZ_HCLM_VERSION_INFO.claim_id
  is 'Hasar dosyasının 3 lü key yapısından 1.sidir.'
/  
comment on column ALZ_HCLM_VERSION_INFO.sf_no
  is 'Hasar dosyasının 3 lü key yapısından 2.sidir.'
/  
comment on column ALZ_HCLM_VERSION_INFO.add_order_no
  is 'Hasar dosyasının 3 lü key yapısından 3.südür.'
/  
comment on column ALZ_HCLM_VERSION_INFO.version_no
  is 'Bu tablo içim 4. key alanıdır. Versiyon numarasını tutar'
/  
comment on column ALZ_HCLM_VERSION_INFO.log_id
  is 'ALZ_HLTPRV_LOG tablosundaki LOG_ID kolonuna işaret eder'
/  
comment on column ALZ_HCLM_VERSION_INFO.entry_date
  is 'Tabloya kayıt insert edilme tarihi'
/  
comment on column ALZ_HCLM_VERSION_INFO.user_id
  is 'Tabloya insert yapan kullanıcı adı'
/  
comment on column ALZ_HCLM_VERSION_INFO.is_limit_updated
  is 'Limit Güncelleme yapıldı ise 1 yapılmadı ise 0'
/  
comment on column ALZ_HCLM_VERSION_INFO.status_code
  is 'Hasar dosyasının durumu'
/  
comment on column ALZ_HCLM_VERSION_INFO.hclm_usage
  is 'HCLM sistemi kullanıdı ise 1, kullanılmadı ise 0'
/  
comment on column ALZ_HCLM_VERSION_INFO.institute_code
  is 'Hasar dosyasının açıldığı kurum kodu'
/  
comment on column ALZ_HCLM_VERSION_INFO.tpa_company_code
  is 'TPA şirketinin kodu'
/  
comment on column ALZ_HCLM_VERSION_INFO.hclm_channel
  is 'Provizyon Kanal Bilgisi'
/  
comment on column ALZ_HCLM_VERSION_INFO.provision_type
  is '0-ÖSS,1-TSS'
/ 
comment on column ALZ_HCLM_VERSION_INFO.group_code
  is 'Poliçenin Grup Kodu'
/  
comment on column ALZ_HCLM_VERSION_INFO.partner_id
  is 'Unsur Numarası'
/  
comment on column ALZ_HCLM_VERSION_INFO.contract_id
  is 'Poliçe No'
/  
comment on column ALZ_HCLM_VERSION_INFO.partition_no
  is 'Poliçedeki Sıra No'
/  
comment on column ALZ_HCLM_VERSION_INFO.bre_result_code
  is 'BRE de çıkan sonuç kodu'
/  
comment on column ALZ_HCLM_VERSION_INFO.approved_status
  is 'Onaylanma Durumu'
/  
comment on column ALZ_HCLM_VERSION_INFO.customer_type
  is '0-Normal,1-Affluent, 2- CSuite, vb.'
/  
CREATE OR REPLACE PUBLIC SYNONYM ALZ_HCLM_VERSION_INFO FOR CUSTOMER.ALZ_HCLM_VERSION_INFO
/
GRANT DELETE, INSERT, SELECT, UPDATE ON CUSTOMER.ALZ_HCLM_VERSION_INFO TO DEVELOPER_USER
/  
GRANT DELETE, INSERT, SELECT, UPDATE ON CUSTOMER.ALZ_HCLM_VERSION_INFO TO ALLZWEBPOL
/
GRANT DELETE, INSERT, SELECT, UPDATE ON CUSTOMER.ALZ_HCLM_VERSION_INFO TO ALLZWEBPRV
/