update koc_clm_hlth_detail d
set d.status_code='C'
where exists (select 1 from ademo.sbh_2046_cancel_claims@opusdev where ext_reference=d.ext_reference)
/
COMMIT
/