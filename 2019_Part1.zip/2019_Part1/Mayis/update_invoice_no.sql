update koc_clm_hlth_detail 
   set invoice_no = SUBSTR(invoice_no,1,INSTR(invoice_no,'(')-1)
 where claim_id in(
         Select b.claim_id
           From Koc_Clm_Hlth_Prov_Statemnt B              
          Where B.Statement_No = 367592            
            And Nvl(B.Invoice_Total, 0) <> 0
            And (('ODM' = 'ODM' And B.Status_Code = 'ODE') Or ('ODM' = 'TAH' And not exists (select 1
                                                                                                   from koc_clm_hlth_prov_statemnt bb
                                                                                                  where BB.STATEMENT_NO = B.STATEMENT_NO
                                                                                                    and BB.STATUS_CODE = 'ODE'
                                                                                                 )
                                                                 )
                )
            AND b.invoice_no like '%(%')
/
COMMIT
/ 