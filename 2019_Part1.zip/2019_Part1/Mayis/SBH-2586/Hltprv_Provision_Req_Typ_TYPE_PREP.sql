
  CREATE OR REPLACE TYPE "CUSTOMER"."HLTPRV_PROVISION_REQ_TYP" AS OBJECT
(
      origindate                date                        -- gerekti�inde ge�mi� bir tarih baz al�narak okumalar yap�lmas� i�in default trunc(sysdate)
    , institute                 hltprv_institute_typ        --  1
    , institutepass             hltprv_institutepass_typ    --  1.4
    , reference                 hltprv_reference_tbl        --  2
    , insured                   hltprv_pinsured_typ         --  3 TalepSigortaliBilgileri
    , relationshipinfo          hltprv_relationshipinfo_typ --  4 yakinlikbilgileri
    , dr                        hltprv_dr_typ               --  5 DoktorBilgileri
    , referralinfo              hltprv_referral_typ         --  6 SevkBilgileri
    , medicalinfo               hltprv_medicalinfo_typ      --  7 medikalBilgiler
    , sgkinfo                   hltprv_sgkinfo_typ          --  8 SGKBilgileri
    , mondial                   hltprv_mondial_typ          --  9 Ambulans bilgileri
    , personalnotes             varchar2(5000)              --  10 KisiselNotlar
    , amountrequest             number                      --  11 TalepEdilenTutar
    , provisiondate             date                        --  12 ProvizyonOnProvizyonAlinmakIstenenTarih
    , requestsystem             varchar2(50)                --  13 OPUS/WS(WEBSERVIS)/PORTAL
    , logid                     number                      -- LogBilgileri
    , meduladate                DATE
    --
    , constructor function hltprv_provision_req_typ return self as result

    , member function getReferenceId(p_ReferenceType Varchar2) return Varchar2

    , Member procedure validateattributes (p_requestsystem in varchar2 default null)

    , member procedure Write_Log(p_LogId  number default null)


    , Member Function Gettypevalueinclob(P_indent_level  Pls_integer Default Null) Return Clob

    , Member Procedure WriteObjectToLog(p_logid  number default null)

    , Member Procedure Dbms_output_type

)
; 
ALTER TYPE "CUSTOMER"."HLTPRV_PROVISION_REQ_TYP" ADD member function getSgkRefNoVerifiedFromMedula(p_ReferenceType Varchar2) return Varchar2 cascade
CREATE OR REPLACE TYPE BODY "CUSTOMER"."HLTPRV_PROVISION_REQ_TYP" IS

      constructor function hltprv_provision_req_typ return self as result is
      begin
         --
         --developer_utils.send_test_mail('hltprv_provision_typ.constructor');
         if self.origindate is null then
           self.origindate := trunc(sysdate);
         end if;

        if self.provisiondate is null then -- Hata almamal� olarak konu�uldu..
          self.provisiondate := sysdate;
        end if;

        return;
         --
      end;
      --
      member function getReferenceId(p_ReferenceType Varchar2) return Varchar2 Is
         v_Ind  Pls_Integer;
      Begin
          --
          If p_ReferenceType Is Null then
             Return Null;
          End if;
          --
          If Self.Reference is null then
             Return Null;
          End If;

          v_Ind := Self.Reference.First;
          While v_Ind Is Not Null Loop
              If Upper(Self.Reference(v_Ind).Type) = Upper(p_ReferenceType) Then
                 Return Self.Reference(v_Ind).referenceNo;
              End if;
              v_Ind := Self.Reference.Next(v_Ind);
          End loop;
          --
          Return Null;
          --
      End;

			--Tss Medula Takibi Check edilmemi� olan takip nolar�n bilgisini tutar. -- 1:Meduladan verify edilmi�, 0:Meduladan verify edilmemi� SgkRefNo dur

	  member function getSgkRefNoVerifiedFromMedula(p_ReferenceType Varchar2) return Varchar2 is
	     v_Ind  Pls_Integer;
      Begin
          --
          If p_ReferenceType Is Null then
             Return Null;
          End if;
          --
          If Self.Reference is null then
             Return Null;
          End If;

          v_Ind := Self.Reference.First;
          While v_Ind Is Not Null Loop
              If Upper(Self.Reference(v_Ind).Type) = Upper(p_ReferenceType) Then
                 Return Self.Reference(v_Ind).VERIFIEDFROMMEDULA;
              End if;
              v_Ind := Self.Reference.Next(v_Ind);
          End loop;
          --
          Return Null;
          --
      End;

      -- obje �zerine atanan verilerin do�rulu�unu kontrol eder
      member procedure validateattributes (p_requestsystem in varchar2 default null) is
      v_ind            pls_integer;
      v_level          pls_integer;
      v_indent         varchar2(1000);

      hltprv_log       hltprv_log_typ  := hltprv_log_typ();

   begin
        --attributes
        -- origindate
        -- personalnotes

        -- amountrequest
        if self.amountrequest is not null and self.amountrequest < 0 then
           raise_application_error(-20110, 'Talep edilen tutar bilgisi negatif olamaz!');
        end if;

        if self.requestsystem in('PORTAL', 'WS') and trunc(self.provisiondate) > trunc(sysdate) then
          raise_application_error(-20110, 'Provizyon tarihi ' || TO_CHAR(trunc(sysdate),'DD/MM/YYYY') ||' den b�y�k olamaz.');
        end if;

        -- requestsystem
        -- logid

        --ba�l� objeler
        if self.institute is not null then
            self.institute.validateattributes(self.requestsystem);
        else
            raise_application_error(-20110, 'Kurum bilgileri bo� olamaz!');
        end if;

        if self.institutepass is not null then
            self.institutepass.validateattributes(self.requestsystem);
        else
            raise_application_error(-20110, 'Kurum �ifre bilgileri bo� olamaz!');
        end if;

        if self.reference is not null then
            v_Ind := self.reference.first;
            While v_Ind Is Not Null Loop
               self.reference(v_Ind).validateattributes(self.requestsystem);
               v_Ind := self.reference.next(v_Ind);
            End Loop;
        end if;

        if self.insured is not null then
            self.insured.validateattributes(self.requestsystem);

        else
            raise_application_error(-20110, 'Sigortal� bilgileri bo� olamaz!');
        end if;



         -- relationship
        if self.relationshipinfo is not null then


           self.relationshipinfo.validateattributes(self.requestsystem);
        --else
        --   raise_application_error(-20110, 'Sigortali yak�nl�k bilgisi bo� olamaz!');
        end if;
         --

        if self.dr is not null then
            self.dr.validateattributes(self.requestsystem);
        --else
        --    raise_application_error(-20110, 'Doktor bilgileri bo� olamaz!');
        end if;

        if self.referralinfo is not null then
            self.referralinfo.validateattributes(self.requestsystem);
        end if;

        if self.medicalinfo is not null then
            self.medicalinfo.validateattributes(self.requestsystem);
        else
            raise_application_error(-20110, 'Medikal bilgiler bo� olamaz!');
        end if;

        if self.sgkinfo is not null then
            self.sgkinfo.validateattributes(self.requestsystem);
        else
            raise_application_error(-20110, 'SGK bilgileri bo� olamaz!');
        end if;
        --
        if self.mondial is not null then
            self.mondial.validateattributes(self.requestsystem);
        end if;
        --
        --ba�l� arraylar
        --

   end;

     member procedure write_log(p_logid  number default null) is
         --
         dbms_line       varchar2 (255);
         dbms_status     integer;
         hltprv_log      hltprv_log_typ  := hltprv_log_typ();
         --
   begin

         hltprv_log.log_id := nvl(p_logid, self.logid);
         dbms_output.enable (32000);

         self.dbms_output_type;

         dbms_output.get_line (dbms_line, dbms_status);

         while dbms_status = 0
         loop
            hltprv_log.Content := hltprv_log.Content||dbms_line||chr(10);
            dbms_output.get_line (dbms_line, dbms_status);
         end loop;
         dbms_output.disable;

         hltprv_log.servicename     := 'PROVIZYON';
         hltprv_log.processinfo     := 'HLTPRV_PROVISION_REQ_TYP';
         hltprv_log.institutecode   := self.institute.institutecodeallz;
         hltprv_log.insuredno       := self.insured.id;
         hltprv_log.insurednotype   := 'PARTID';

         hltprv_log.savelogwithpragma;
         --
   end;


    Member Function GetTypeValueInClob(p_indent_level  pls_integer default Null
      ) return clob is
      v_ind            pls_integer;
      v_level          pls_integer;
      v_indent         varchar2(1000);
      --
      v_Return        CLOB;
      --
   Begin
        --
        if abs(nvl(p_indent_level, 0)) > 1  then
           v_level := abs(nvl(p_indent_level, 0));
        else
           v_level := 1;
        end if;
        for i in 1..v_level loop
           v_indent := v_indent||'    ';
        end loop;
        v_indent := v_indent||'  --> ';
        --
        v_Return := v_Return||v_indent||'HLTPRV_PROVISION_REQ_TYP'||Chr(10);
        v_Return := v_Return||v_indent||'Amountrequest    :'||self.AMOUNTREQUEST||Chr(10);
        v_Return := v_Return||v_indent||'Origindate       :'||self.ORIGINDATE||Chr(10);
        v_Return := v_Return||v_indent||'Requestsystem    :'||self.REQUESTSYSTEM||Chr(10);
        v_Return := v_Return||v_indent||'Provisiondate    :'||self.PROVISIONDATE||Chr(10);
        v_Return := v_Return||v_indent||'Meduladate       :'||self.Meduladate||Chr(10);
        v_Return := v_Return||v_indent||'Personalnotes    :'||self.PERSONALNOTES||Chr(10);
        v_Return := v_Return||v_indent||'Logid            :'||self.LOGID||Chr(10);
        if Self.MEDICALINFO Is Not Null Then
           v_Return := v_Return||self.MEDICALINFO.GetTypeValueInClob(p_indent_level);
        else
           v_Return := v_Return||'TYPE - HLTPRV_MEDICALINFO_TYP: Null';
        end if;
        if Self.SGKINFO Is Not Null Then
           v_Return := v_Return||self.SGKINFO.GetTypeValueInClob(p_indent_level);
        else
           v_Return := v_Return||'TYPE - HLTPRV_SGKINFO_TYP: Null';
        end if;
        if Self.Mondial Is Not Null Then
           v_Return := v_Return||self.MONDIAL.GetTypeValueInClob(p_indent_level);
        else
           v_Return := v_Return||'TYPE - HLTPRV_MONDIAL_TYP: Null';
        end if;
        if Self.REFERRALINFO Is Not Null Then
           v_Return := v_Return||self.REFERRALINFO.GetTypeValueInClob(p_indent_level);
        else
           v_Return := v_Return||'TYPE - HLTPRV_REFERRAL_TYP: Null';
        end if;
        if Self.RELATIONSHIPINFO Is Not Null Then
           v_Return := v_Return||self.RELATIONSHIPINFO.GetTypeValueInClob(p_indent_level);
        else
           v_Return := v_Return||'TYPE - HLTPRV_RELATIONSHIPINFO_TYP: Null';
        end if;
        if Self.DR Is Not Null Then
           v_Return := v_Return||self.DR.GetTypeValueInClob(p_indent_level);
        else
           v_Return := v_Return||'TYPE - HLTPRV_DR_TYP: Null';
        end if;
        if Self.INSURED Is Not Null Then
           v_Return := v_Return||self.INSURED.GetTypeValueInClob(p_indent_level);
        else
           v_Return := v_Return||'TYPE - HLTPRV_PINSURED_TYP: Null';
        end if;
        if Self.INSTITUTEPASS Is Not Null Then
           v_Return := v_Return||self.INSTITUTEPASS.GetTypeValueInClob(p_indent_level);
        else
           v_Return := v_Return||'TYPE - HLTPRV_INSTITUTEPASS_TYP: Null';
        end if;
        if Self.INSTITUTE Is Not Null Then
           v_Return := v_Return||self.INSTITUTE.GetTypeValueInClob(p_indent_level);
        else
           v_Return := v_Return||'TYPE - HLTPRV_INSTITUTE_TYP: Null';
        end if;
        if Self.REFERENCE Is Not Null Then
           v_Ind := self.REFERENCE.First;
           While v_Ind Is Not Null Loop
               V_return := V_return||Self.Reference(v_Ind).Gettypevalueinclob(P_indent_level);
               v_Ind := self.REFERENCE.Next(v_Ind);
           End Loop;
        else
           v_Return := v_Return||'TYPE - HLTPRV_REFERENCE_TBL: Null';
        end if;
        --;
        return v_Return;
        --;
   end;


   Member Procedure WriteObjectToLog(p_logid  number default null) is
      --
      hltprv_log      hltprv_log_typ  := hltprv_log_typ();
      v_Log_Mode      Varchar2(50);
      --
   begin
      --
      hltprv_log.log_id := p_logid;
      If Coalesce(hltprv_log.log_id, 0) > 0 then
         v_Log_Mode := Customer.hltprv_log_typ.GetLogMode(hltprv_log.log_id);
      End if;
      --
      If Coalesce(v_Log_Mode, 'NORMAL') Not In ('DEBUG', 'STRESS') Then
         Return;
      End if;
      --
      hltprv_log.processinfo := 'HLTPRV_PROVISION_REQ_TYP';
      If v_Log_Mode = 'DEBUG' Then
         hltprv_log.Content     := Self.GetTypeValueInClob;
      End if;
      --
      hltprv_log.savelogwithpragma;
      --
   End;


   Member Procedure Dbms_output_type Is
   Begin
        Return;
        Dbms_Output.Put_Line(Self.GetTypeValueInClob );
   end;

end;
/
