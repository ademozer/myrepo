 SELECT *
                FROM Koc_Cc_Web_Inst_Doctor
             WHERE 1=1 --Institute_Code = Pinstitutecode
                 --AND Specialty_Subject = Pspecialtysubject
                 --AND Doctor_Name || ' ' || Doctor_Surname = Pnamesurname
                -- AND Pnamesurname IS NOT NULL
                 AND Validity_End_Date IS NULL
            UNION ALL
            SELECT *
                FROM Hst_Cc_Web_Inst_Doctor h
             WHERE 1=1--Institute_Code = Pinstitutecode
               --  AND Specialty_Subject = Pspecialtysubject
                -- AND Doctor_Name || ' ' || Doctor_Surname = Pnamesurname
                 --AND Pnamesurname IS NOT NULL
                 AND DOCTOR_SOURCE='ULAK'
                 AND Validity_End_Date IS NULL
                 AND EXISTS (SELECT 1 FROM Koc_Cc_Web_Inst_Doctor 
                 where UPPER(Doctor_Name || ' ' || Doctor_Surname) = UPPER(h.Doctor_Name || ' ' || h.Doctor_Surname) and specialty_subject = h.specialty_subject
                 and institute_code = h.institute_code               
                 and doctor_identity_no is not null or doctor_certificate_number is not null) 
                                  
                -- select * from Hst_Cc_Web_Inst_Doctor where doctor_code=203726
                                select * from koc_Cc_Web_Inst_Doctor where institute_code=1874 and specialty_subject=1530 and UPPER(Doctor_Name || ' ' || Doctor_Surname) IN(TRANSLATE('MURAT NAB� BULUT','�','I'),'MURAT NAB� BULUT') for update
--doctor_code in(191183,193491)
                
                select * from hst_Cc_Web_Inst_Doctor where doctor_code=12273 for update and UPPER(Doctor_Name || ' ' || Doctor_Surname) = TRANSLATE('MURAT NAB� BULUT','�','I')
                
                
                SELECT *
                FROM Koc_Cc_Web_Inst_Doctor
             WHERE Institute_Code = 1874
                 AND Specialty_Subject = 1530
                -- AND Doctor_Name || ' ' || Doctor_Surname = Pnamesurname
                 AND UPPER(Doctor_Name || ' ' || Doctor_Surname) IN ('MURAT NAB� BULUT',UPPER('MURAT NAB� BULUT'),TRANSLATE(UPPER('MURAT NAB� BULUT'),'�','I'))
                 --AND Pnamesurname IS NOT NULL
                 AND Validity_End_Date IS NULL
                 
                 
                   select * from Koc_Clm_Hlth_Preapprove_Detail  where process_date >trunc(sysdate-10)
                   
                   
                   
              SELECT a.parameter,a.explanation
                FROM Alz_Look_Up@opusdev a
               WHERE a.Code = 'DR_TITLE'
                 and a.validity_start_date <= trunc(sysdate) and a.validity_end_date is null;
