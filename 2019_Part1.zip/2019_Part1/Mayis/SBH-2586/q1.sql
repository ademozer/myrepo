select *
from
        customer.koc_clm_hlth_indem_totals healthclai0_ 
    where
        healthclai0_.claim_inst_loc='YI'
        and healthclai0_.claim_inst_type='AK' 
        and healthclai0_.contract_id=357898173 
        and healthclai0_.package_id=114682        
        --and healthclai0_.cover_code='ST504'
        and healthclai0_.PARENT_COVER_CODE='S403'
        and healthclai0_.is_pool_cover=0 
        and healthclai0_.is_special_cover=0         
        and healthclai0_.country_group=0
        and healthclai0_.partition_no=1;  
 


select * from koc_clm_hlth_detail where request_system='ULAK' and provision_date>TO_DATE('13/05/2019','DD/MM/YYYY')-- ext_reference='56791448' for update--40181328; 

--insert into koc_clm_web_auth_pool 
select * from koc_clm_web_auth_pool where claim_id=40181077--40181328 for update

select * from koc_clm_hlth_provisions where claim_id=40181077 for update

SELECT * FROM alz_hltprv_log 
where log_id=118797161 order by log_date


select * from koc_clm_hlth_detail where ext_reference = '57375196'
select * from customer.alz_duplicate_provision where ext_reference='57375196'

select * from alz_hltprv_log where log_id=125157231;


WEB_HLTPRV_UTILS.GETHLTPRVRESPOBJ

SELECT * FROM Hst_Cc_Web_Inst_Doctor where  lower(doctor_name) like '%enes%' and lower(doctor_surname) like '%uysal%' and validity_end_date is null and institute_code=813 and specialty_subject=1010
SELECT * FROM Koc_Cc_Web_Inst_Doctor where doctor_code IN (242640,
244286,
244286,
257466,
265365,
253262,
260413,
252849,
257475,
260412,
257484,
267416)

SELECT * FROM Koc_Cc_Web_Inst_Doctor where doctor_code='257466' for update;



SELECT *
                FROM Koc_Cc_Web_Inst_Doctor
             WHERE Institute_Code = 813
                 AND (Specialty_Subject = 1010 OR Specialty_Subject IS NULL)
                 AND Doctor_Name || ' ' || Doctor_Surname = UPPER('enes uysal')
                -- AND Pnamesurname IS NOT NULL
                 AND Validity_End_Date IS NULL
            UNION ALL
            SELECT *
                FROM Hst_Cc_Web_Inst_Doctor
             WHERE Institute_Code = 813
                 AND Specialty_Subject = 1010
                 AND UPPER(Doctor_Name || ' ' || Doctor_Surname) = UPPER('enes uysal')
                -- AND Pnamesurname IS NOT NULL
                 AND Validity_End_Date IS NULL;
