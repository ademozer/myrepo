DECLARE
v_Pinstitutecode      NUMBER := 3210;
v_Pspecialtysubject   VARCHAR2(100) := 1470;
v_Pnamesurname        VARCHAR2(100) := 'Z�YA �MER';
v_Pidentityno         VARCHAR2(100);
v_Pdiplomano          VARCHAR2(100);
v_title               VARCHAR2(100);
v_Pdoctor          Koc_Cc_Web_Inst_Doctor%ROWTYPE;

    PROCEDURE Finddoctor(Pinstitutecode    IN NUMBER,
                                             Pspecialtysubject IN VARCHAR2,
                                             Pnamesurname      IN VARCHAR2,
                                             Pidentityno       IN VARCHAR2,
                                             Pdiplomano        IN VARCHAR2,
                                             Pdoctor           OUT Koc_Cc_Web_Inst_Doctor%ROWTYPE) IS
        /*SBH-2180
          CURSOR Crdoctorbyidentity IS
            SELECT *
                FROM Koc_Cc_Web_Inst_Doctor
             WHERE Institute_Code = Pinstitutecode
                 AND Specialty_Subject = Pspecialtysubject
                 AND Doctor_Identity_No = Pidentityno
                 AND Pidentityno IS NOT NULL
                 AND Validity_End_Date IS NULL
            UNION ALL
            SELECT *
                FROM Hst_Cc_Web_Inst_Doctor
             WHERE Institute_Code = Pinstitutecode
                 AND Specialty_Subject = Pspecialtysubject
                 AND Doctor_Identity_No = Pidentityno
                 AND Pidentityno IS NOT NULL
                 AND Validity_End_Date IS NULL;*/
           --SBH-2180
         CURSOR Crdoctorbyidentity_mnw IS
            SELECT *
                FROM Koc_Cc_Web_Inst_Doctor
             WHERE Institute_Code = Pinstitutecode
                 AND Specialty_Subject = Pspecialtysubject
                 AND Doctor_Identity_No = Pidentityno
                 AND Pidentityno IS NOT NULL
                 AND Validity_End_Date IS NULL;
         --SBH-2180
         CURSOR Crdoctorbyidentity_hst IS
            SELECT *
                FROM Hst_Cc_Web_Inst_Doctor
             WHERE Institute_Code = Pinstitutecode
                 AND Specialty_Subject = Pspecialtysubject
                 AND Doctor_Identity_No = Pidentityno
                 AND Pidentityno IS NOT NULL
                 AND Validity_End_Date IS NULL;

        CURSOR Crdoctorbydiploma IS
            SELECT *
                FROM Koc_Cc_Web_Inst_Doctor
             WHERE Institute_Code = Pinstitutecode
                 AND Specialty_Subject = Pspecialtysubject
                 AND Doctor_Certificate_Number = Pdiplomano
                 AND Pdiplomano IS NOT NULL
                 AND Validity_End_Date IS NULL
            UNION ALL
            SELECT *
                FROM Hst_Cc_Web_Inst_Doctor
             WHERE Institute_Code = Pinstitutecode
                 AND Specialty_Subject = Pspecialtysubject
                 AND Doctor_Certificate_Number = Pdiplomano
                 AND Pdiplomano IS NOT NULL
                 AND Validity_End_Date IS NULL;

        CURSOR Crdoctorbynamesurname IS
            SELECT *
                FROM Koc_Cc_Web_Inst_Doctor
             WHERE Institute_Code = Pinstitutecode
                 AND Specialty_Subject = Pspecialtysubject
                -- AND Doctor_Name || ' ' || Doctor_Surname = Pnamesurname
                 AND TRANSLATE(UPPER(Doctor_Name || ' ' || Doctor_Surname),'�','I') = TRANSLATE(UPPER(Pnamesurname),'�','I')
                 AND Pnamesurname IS NOT NULL
                 AND Validity_End_Date IS NULL
            UNION ALL
            SELECT *
                FROM Hst_Cc_Web_Inst_Doctor
             WHERE Institute_Code = Pinstitutecode
                 AND Specialty_Subject = Pspecialtysubject
                 --AND Doctor_Name || ' ' || Doctor_Surname = Pnamesurname
                 AND TRANSLATE(UPPER(Doctor_Name || ' ' || Doctor_Surname),'�','I') = TRANSLATE(UPPER(Pnamesurname),'�','I')
                 AND Pnamesurname IS NOT NULL
                 AND Validity_End_Date IS NULL;

        Vdoctor Koc_Cc_Web_Inst_Doctor%ROWTYPE;
    BEGIN
        IF Pnamesurname IS NULL AND
             Pidentityno IS NULL AND
             Pdiplomano IS NULL AND
             Pspecialtysubject IS NULL
        THEN
            RETURN;
        ELSE
            IF Vdoctor.Doctor_Code IS NULL
            THEN
                IF Pidentityno IS NOT NULL
                THEN
                  /* SBH-2180
                    OPEN Crdoctorbyidentity;

                    FETCH Crdoctorbyidentity    INTO Vdoctor;

                    CLOSE Crdoctorbyidentity;*/
                   --SBH-2180
                   OPEN Crdoctorbyidentity_mnw;
                   FETCH Crdoctorbyidentity_mnw    INTO Vdoctor;
                   CLOSE Crdoctorbyidentity_mnw;
                   IF Vdoctor.Doctor_Code IS NULL
                   THEN
                     OPEN Crdoctorbyidentity_hst;
                     FETCH Crdoctorbyidentity_hst    INTO Vdoctor;
                     CLOSE Crdoctorbyidentity_hst;
                   END IF ;
                   --SBH-2180
                END IF;
            END IF;
            /* SBH-2082 - WS den gelen taleplerde diploma noya g�re dr bilgilerinin bulunmas�n�n �nlenmesi
            IF Vdoctor.Doctor_Code IS NULL
            THEN
                IF Pdiplomano IS NOT NULL
                THEN
                    OPEN Crdoctorbydiploma;

                    FETCH Crdoctorbydiploma
                        INTO Vdoctor;

                    CLOSE Crdoctorbydiploma;
                END IF;
            END IF;
            */
            IF Vdoctor.Doctor_Code IS NULL
            THEN
                IF Pnamesurname IS NOT NULL
                THEN
                    OPEN Crdoctorbynamesurname;

                    FETCH Crdoctorbynamesurname
                        INTO Vdoctor;

                    CLOSE Crdoctorbynamesurname;
                    /*FOR rec IN Crdoctorbynamesurname LOOP
                        DBMS_OUTPUT.PUT_LINE('Doktor_Adi   : '||rec.DOCTOR_NAME||' '||rec.DOCTOR_SURNAME);
                        DBMS_OUTPUT.PUT_LINE('Doktor_TCKN  : '||rec.DOCTOR_IDENTITY_NO);
                        DBMS_OUTPUT.PUT_LINE('Doktor_CN    : '||rec.DOCTOR_CERTIFICATE_NUMBER);
                        DBMS_OUTPUT.PUT_LINE('Doktor_Code  : '||rec.DOCTOR_CODE);
                    END LOOP;*/
                END IF;
            END IF;
        END IF;

        Pdoctor := Vdoctor;
    END finddoctor;
    
    BEGIN
        finddoctor(v_Pinstitutecode,
        v_Pspecialtysubject,
        v_Pnamesurname,
        v_Pidentityno,
        v_Pdiplomano,
        v_Pdoctor);
        
        DBMS_OUTPUT.PUT_LINE('Doktor_Adi   : '||v_Pdoctor.DOCTOR_NAME||' '||v_Pdoctor.DOCTOR_SURNAME);
        DBMS_OUTPUT.PUT_LINE('Doktor_TCKN  : '||v_Pdoctor.DOCTOR_IDENTITY_NO);
        DBMS_OUTPUT.PUT_LINE('Doktor_CN    : '||v_Pdoctor.DOCTOR_CERTIFICATE_NUMBER);
        DBMS_OUTPUT.PUT_LINE('Doktor_Code  : '||v_Pdoctor.DOCTOR_CODE);
        
         IF v_Pdoctor.Doctor_code IS NOT NULL
         THEN
            IF v_Pdoctor.Doctor_Identity_no IS NOT NULL THEN 
                 UPDATE Hst_Cc_Web_Inst_Doctor
                       SET Title                     = NVL(V_title, Title),
                           Doctor_Identity_No        = NVL(Doctor_Identity_No, v_Pdoctor.Doctor_Identity_no),
                           Doctor_Staff              = NVL(v_Pdoctor.Doctor_Staff, Doctor_Staff),
                           Doctor_Certificate_Number = NVL(v_Pdoctor.DOCTOR_CERTIFICATE_NUMBER, Doctor_Certificate_Number) 
                               --,Doctor_Type               = Vdoctortype
                   WHERE Doctor_Code = v_Pdoctor.Doctor_code;              
            END IF;
        END IF;
             
    END;
    
    
