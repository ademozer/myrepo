DECLARE 

  Cursor cr_inv(Pc_Statement_No Koc_Clm_Hlth_Prov_Statemnt.Statement_No%Type
                , Pc_Type          Varchar2
                   )
      is
         Select Nvl(D.Invoice_No, B.Invoice_No) Invoiceid,
               -- d.invoice_no detail_fat_no,
               -- b.invoice_no icmal_fat_no,  
                Nvl(D.Invoice_Date, B.Invoice_Date) Invoicedate,
                D.Institute_Code,
                Nvl(B.Invoice_Total, D.Invoice_Total) Amount,
                D.Swift_Code Swift_Code
           From Koc_Clm_Hlth_Prov_Statemnt B
              , Koc_Clm_Hlth_Detail D
          Where B.Statement_No = pc_statement_no
            And D.Claim_Id = B.Claim_Id
            And D.Sf_No = B.Sf_No
            And D.Add_Order_No = 1
            And Nvl(B.Invoice_Total, 0) <> 0
            And ((Pc_Type = 'ODM' And B.Status_Code = 'ODE') Or (Pc_Type = 'TAH' And not exists (select 1
                                                                                                   from koc_clm_hlth_prov_statemnt bb
                                                                                                  where BB.STATEMENT_NO = B.STATEMENT_NO
                                                                                                    and BB.STATUS_CODE = 'ODE'
                                                                                                 )
                                                                 )
                );
                
       v_statement_no Koc_Clm_Hlth_Prov_Statemnt.Statement_No%Type := 367592; 
       v_type  VARCHAR2(100) := 'ODM';
       v_Batch_Info    ALZ_INV_PROCESS_UTILS.Manuel_Inv_Batch_Info_Type;
       v_err_msg     VARCHAR2(2000);
   Begin
         /*for rec in cr_inv(v_statement_no, v_type) loop
           dbms_output.put_line('fatura_no='||rec.detail_fat_no||':'||rec.icmal_fat_no); 
         end loop;*/
         open cr_inv(v_statement_no, v_type);
         loop
            fetch cr_inv into v_Batch_Info.Invoiceid
                            ,
                             v_Batch_Info.Invoicedate
                            , v_Batch_Info.Institute_Code
                            , v_Batch_Info.Amount
                            , v_Batch_Info.Swift_Code;
            exit when cr_inv%notfound;
            dbms_output.put_line('fatura_no='||v_Batch_Info.Invoiceid);  
           -- v_batches_Info(v_batches_Info.count + 1) := v_Batch_Info;
         end loop;
   exception
   when others then
        v_err_msg := SQLERRM;
        dbms_output.put_line('hata:'||v_err_msg);
   end;    
