﻿ SELECT  det.invoice_date
        ,det.invoice_no
        ,KOC_CLM_HLTH_UTILS.Getpartnernamebypartid(det.part_id) insured_name 
        ,DECODE(a.sf_total_type,'11','Tahakkuk','12','Tahakkuk Ýptali','') description 
        ,det.ext_reference                
        ,b.ticket_no      
        ,SUM(DECODE(a.sf_total_type,'11',1,0)*(NVL(a.trans_amt,0)-NVL(b.stoppage_amount,0))*NVL(b.currency_exchange_rate,1)) credit_amount
        ,SUM(DECODE(a.sf_total_type,'12',1,0)*(NVL(a.trans_amt,0)-NVL(b.stoppage_amount,0))*NVL(b.currency_exchange_rate,1)) debit_amount
        ,sum(nvl (b.stoppage_amount, 0) * nvl (b.currency_exchange_rate, 1)) as stoppage_amount,
        null as az_invoice_no,
        null as az_invoice_date,
        null as invoice_status_type,
        null as uu_id,
        null as profile_id
    FROM koc_clm_trans_ext b
        ,clm_trans a
        ,koc_clm_suppliers_ext c   
        ,koc_clm_hlth_detail det
   WHERE b.ticket_date >= &p_start_date--LEAST(NVL(:p_start_date,:p_start_date_tss),NVL(:p_start_date_tss,:p_start_date))
     AND b.ticket_date <= &p_end_date--GREATEST(NVL(:p_end_date,:p_end_date_tss),NVL(:p_end_date_tss,:p_end_date))
     AND b.payment_type = '7'
     AND a.claim_id = b.claim_id
     AND a.sf_no = b.sf_no
     AND a.trans_no = b.trans_no
     AND c.supp_id = a.supp_id  
     AND det.claim_id = b.claim_id
     AND det.sf_no = b.sf_no
     AND det.add_order_no = b.add_order_no   
     AND det.institute_code = &p_inst_code
     AND c.payment_group_code = &p_payment_group_code 
     AND det.is_complementary = &p_is_tss
   /*  AND (
          (
           &p_oss = 1 AND &p_tss = 1 AND 
           ((&p_oss = 1
              AND c.oss_agreement_status = 1 
              AND c.payment_group_code = DECODE(&p_payment_group_code,NULL,c.payment_group_code,&p_payment_group_code) 
              AND NVL(det.is_complementary,0) = 0
              AND b.ticket_date >= &p_start_date
              AND b.ticket_date <= &p_end_date
            ) OR    
            (&p_tss = 1 
              AND c.tss_agreement_status = 1 
              AND c.tss_payment_group_code = DECODE(&p_payment_group_code_tss,NULL,c.tss_payment_group_code,&p_payment_group_code_tss) 
              AND NVL(det.is_complementary,0) = 1
              AND b.ticket_date >= &p_start_date --_tss
              AND b.ticket_date <= &p_end_date   --_tss                  
            )
           )
          ) OR 
          (&p_oss = 1 AND &p_tss = 0 
                      AND c.oss_agreement_status = 1 
                      AND c.payment_group_code = DECODE(&p_payment_group_code,NULL,c.payment_group_code,&p_payment_group_code) 
                      AND NVL(det.is_complementary,0) = 0
                      AND b.ticket_date >= &p_start_date
                      AND b.ticket_date <= &p_end_date
          ) OR    
          (&p_oss = 0 AND &p_tss = 1 
                      AND c.tss_agreement_status = 1 
                      AND c.tss_payment_group_code = DECODE(&p_payment_group_code_tss,NULL,c.tss_payment_group_code,&p_payment_group_code_tss) 
                      AND NVL(det.is_complementary,0) = 1
                      AND b.ticket_date >= &p_start_date--_tss
                      AND b.ticket_date <= &p_end_date--_tss                      
          )
         ) */                                           
GROUP BY det.invoice_date
        ,det.invoice_no
        ,det.part_id          
        ,a.sf_total_type
        ,det.ext_reference                
        ,b.ticket_no
