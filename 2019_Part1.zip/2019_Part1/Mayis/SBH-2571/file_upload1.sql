DECLARE

 v_reconc_id    NUMBER := 8464;
 v_tcknvkn_type VARCHAR2(20) := 'TCKN';
 v_tckn_vkn     VARCHAR2(11) := 11848131030;
 v_remote_file_path VARCHAR2(20) := '/TMP';
 v_remote_file  VARCHAR2(100) := 'GOLGE_ACAROGLU.docx';
 v_doc_type_code VARCHAR2(20) := 'AS0V002';
   
 PROCEDURE file_upload(p_reconc_id IN NUMBER
                    ,p_tcknvkn_type IN VARCHAR2
                    ,p_tckn_vkn IN VARCHAR2
                    ,p_remote_file_path IN VARCHAR2
                    ,p_remote_file IN VARCHAR2
                    ,p_doc_type_code IN VARCHAR2)  IS
  HOST                VARCHAR2 (255);
  soap_request        VARCHAR2 (32767);
  soap_respond        VARCHAR2 (32767);
  http_req            UTL_HTTP.req;
  http_resp           UTL_HTTP.resp;
  v_username          VARCHAR2(500);
  v_password          VARCHAR2(500);
  v_isSuccess         VARCHAR2(100);

BEGIN
  HOST := get_url_link('http://esb.allianz.com.tr:12000/FileNetServices/DocumentManagementService?wsdl');

         /* uat     'http://10.70.47.55:18213/FileNetServices/DocumentManagementService?wsdl'; */
         /* devtest 'http://10.70.47.25:17001/FileNetServices/DocumentManagementService?WSDL'; */

   soap_request := '<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:web="http://webservice.filenet.allianz.com/">
                       <soap:Header/>
                       <soap:Body>
                          <web:insertReconciliationDocuments>
                             <ReconciliationId>'||TO_CHAR(p_reconc_id)||'</ReconciliationId>
                             <StatusOrder>999</StatusOrder>
                             <SourceType>OpusAdmin</SourceType>
                             <IdentityType>'||p_tcknvkn_type||'</IdentityType>
                             <IdentityNo>'||p_tckn_vkn||'</IdentityNo>
                             <documents>
                                <barcode></barcode>
                                <createdBy></createdBy>
                                <documentId></documentId>
                                <file></file>
                                <filePath>'||p_remote_file_path||'</filePath>
                                <major>1</major>
                                <name>'||p_remote_file||'</name>
                                <type>'||p_doc_type_code||'</type>
                             </documents>
                          </web:insertReconciliationDocuments>
                       </soap:Body>
                    </soap:Envelope>';

    http_req := utl_http.begin_request(host, 'POST', 'HTTP/1.1');
    utl_http.set_header(http_req, 'Accept-Encoding', 'gzip,deflate');
    utl_http.set_header(http_req, 'Connection', 'keep-alive');
    utl_http.set_header(http_req, 'Content-Type', 'application/soap+xml;charset=UTF-8');
    utl_http.set_header(http_req, 'Content-Length', length(soap_request));
    BEGIN
        SELECT MAX(DECODE(a.param_name,'FILENET_OPUS_USER',param_value)) v_username
              ,MAX(DECODE(a.param_name,'FILENET_OPUS_PASSWORD',param_value)) v_password
          INTO v_username
              ,v_password
         FROM alz_clm_filenet_param a
        WHERE a.param_name IN ('FILENET_OPUS_USER','FILENET_OPUS_PASSWORD');
    UTL_HTTP.SET_AUTHENTICATION(http_req,v_username,v_password);
    END;

    utl_http.write_text(http_req, soap_request);
    http_resp := utl_http.get_response(http_req);
     
    /* dbms_output.put_line('Response> status_code: "' || http_resp.status_code || '"');
     dbms_output.put_line('Response> reason_phrase: "' || http_resp.reason_phrase || '"'); 
     dbms_output.put_line('Response> http_version: "' || http_resp.http_version || '"'); */

    utl_http.read_text(http_resp, soap_respond, 32000);
    utl_http.end_response(http_resp);
    
    v_isSuccess := http_resp.reason_phrase;
    
    dbms_output.put_line('v_isSuccess: '||v_isSuccess); 
        
    soap_respond := TRIM(regexp_replace(soap_respond, '([^[:graph:] | ^[:blank:]])', ''));
    soap_respond := TRIM(regexp_replace(soap_respond, 'S:', ''));
    soap_respond := TRIM(regexp_replace(soap_respond, 'ns0:', '')); 
    dbms_output.put_line('response: '||soap_respond); 
    FOR rec IN (SELECT * FROM XMLTABLE('/Envelope/Body/insertReconciliationDocumentsResponse/return'
                      PASSING XMLTYPE(REPLACE(soap_respond,'S:',''))
                      COLUMNS status  VARCHAR2(100) PATH 'status')) LOOP
                    v_isSuccess := rec.status;                                   
    END LOOP; 

    /* substr(soap_respond, instr(soap_respond, '<status>')+length('<status>'), (instr(soap_respond, '</status>')-instr(soap_respond, '<status>')-length('<status>'))); */
     dbms_output.put_line('v_isSuccess: '||v_isSuccess); 

    --RETURN(v_isSuccess); /*OK*/
 END file_upload;
 
 BEGIN
   
    file_upload(v_reconc_id
               ,v_tcknvkn_type
               ,v_tckn_vkn
               ,v_remote_file_path
               ,v_remote_file
               ,v_doc_type_code);
               
 END;
