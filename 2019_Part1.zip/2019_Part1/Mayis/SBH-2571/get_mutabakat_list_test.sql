declare
  TYPE refCur IS REF CURSOR;
  master_cur    refCur;
  status_cur    refCur;
  document_cur  refCur;
  doccode_cur   refCur;
  v_institute_code NUMBER := 757; 
  v_reconciliation_date DATE := null;--TO_DATE('16/05/2019','DD/MM/YYYY');
  
  v_document_cur    alz_hlth_supp_reconc_docs%rowtype;
  v_tcknvkn_number number;
  v_tcknvkn_type   varchar2(10);
  v_reconc_status  varchar2(10);
  v_approve_exp    varchar2(10);
  v_doc_code_exp   varchar2(500);
  v_doc_date       date;  
  v_filenet_link   varchar2(2000);
  --v_doccode_cur    alz_hlth_cpa_doc_ref%rowtype;
  --v_doc_code       varchar2(10);
    
  v_process_results customer.process_result_table;
  PROCEDURE getreconciliationinf(p_institute_code       NUMBER,
                                 p_reconciliation_date  DATE,
                                 p_reconc_status        VARCHAR2,
                                 p_approve_exp          VARCHAR2,
                                 master_cur             OUT refCur,
                                 status_cur             OUT refCur,
                                 document_cur           OUT refCur,
                                 tcknvkn_number         out number,
                                 tcknvkn_type           out varchar2,
                                 p_process_results in out customer.process_result_table) IS

    --v_result refCur;
    v_tcnkn_no number;
    v_vkn_no   number;
  BEGIN
  --Master bilgileri dolduruluyor
    open master_cur for
      select distinct a.reconciliation_id,a.supp_id,a.institute_code,
                      a.reconciliation_date,a.reconciliation_amount,
                      a.reconciliation_status,a.sub_status,
                      a.client_key,a.send_status,a.send_status_exp,
                      a.process_date,a.process_user
        from alz_hlth_supp_reconciliation a
       where a.institute_code=p_institute_code
         and ((p_reconciliation_date is not null and a.reconciliation_date=p_reconciliation_date)
          or (p_reconciliation_date is null))
         and nvl(a.sub_status,0)=nvl(p_approve_exp,nvl(a.sub_status,0))
         and exists(select 1 from alz_hlth_supp_reconc_status w
                       where w.reconciliation_id=a.reconciliation_id
                         --and w.status_type<>'CANCELLED'
                         and w.status_type=nvl(p_reconc_status,w.status_type)
                         and w.status_order_no=(select max(t.status_order_no)
                                               from alz_hlth_supp_reconc_status t
                                               where t.reconciliation_id=w.reconciliation_id))
     order by a.institute_code,a.reconciliation_date asc;

    --master_cur := v_result;

   --Status bilgileri dolduruluyor
     open status_cur for
      select distinct b.reconciliation_id,b.status_order_no,b.status_type,b.explanation,
                      b.approve_user,b.supp_reconc_amount,b.process_date,b.process_user
        from  alz_hlth_supp_reconciliation a,
              alz_hlth_supp_reconc_status  b
       where a.reconciliation_id=b.reconciliation_id
         and a.institute_code=p_institute_code
         and ((p_reconciliation_date is not null and a.reconciliation_date=p_reconciliation_date)
          or (p_reconciliation_date is null))
         and nvl(a.sub_status,0)=nvl(p_approve_exp,nvl(a.sub_status,0))
         and exists(select 1 from alz_hlth_supp_reconc_status w
                       where w.reconciliation_id=a.reconciliation_id
                         --and w.status_type<>'CANCELLED'
                         and w.status_type=nvl(p_reconc_status,w.status_type)
                         and w.status_order_no=(select max(t.status_order_no)
                                               from alz_hlth_supp_reconc_status t
                                               where t.reconciliation_id=w.reconciliation_id))
         order by b.reconciliation_id,b.status_order_no asc;

   -- status_cur := v_result;

   --Document bilgileri dolduruluyor
     open document_cur for
      select distinct NVL(c.reconciliation_id, a.reconciliation_id) reconciliation_id, c.status_order_no, 
                      c.object_id, c.doc_code,NVL(c.process_date,a.process_date) process_date, NVL(c.process_user, a.process_user) process_user
        from alz_hlth_supp_reconciliation a,
             alz_hlth_supp_reconc_docs  c
       where a.reconciliation_id=c.reconciliation_id(+)
         and  a.institute_code=p_institute_code
        and ((p_reconciliation_date is not null and a.reconciliation_date=p_reconciliation_date)
         or (p_reconciliation_date is null))
         and nvl(a.sub_status,0)=nvl(p_approve_exp,nvl(a.sub_status,0))
         and exists(select 1 from alz_hlth_supp_reconc_status w
                       where w.reconciliation_id=a.reconciliation_id
                         and w.status_type<>'CANCELLED'
                         and w.status_type=nvl(p_reconc_status,w.status_type)
                         and w.status_order_no=(select max(t.status_order_no)
                                               from alz_hlth_supp_reconc_status t
                                               where t.reconciliation_id=w.reconciliation_id));
         --order by c.reconciliation_id,c.status_order_no,c.object_id asc;
        /* select distinct a.reconciliation_id,a.supp_id,a.institute_code,
                      a.reconciliation_date,a.reconciliation_amount,
                      a.reconciliation_status,a.sub_status,
                      a.client_key,a.send_status,a.send_status_exp,
                      a.process_date,a.process_user
        from alz_hlth_supp_reconciliation a
       where a.institute_code=757
        -- and ((p_reconciliation_date is not null and a.reconciliation_date=p_reconciliation_date)
        --  or (p_reconciliation_date is null))
         --and nvl(a.sub_status,0)=nvl(p_approve_exp,nvl(a.sub_status,0))
         and exists(select 1 from alz_hlth_supp_reconc_status w
                       where w.reconciliation_id=a.reconciliation_id
                         and w.status_type<>'CANCELLED'
                        -- and w.status_type=nvl(p_reconc_status,w.status_type)
                         and w.status_order_no=(select max(t.status_order_no)
                                               from alz_hlth_supp_reconc_status t
                                               where t.reconciliation_id=w.reconciliation_id))
     order by a.institute_code,a.reconciliation_date asc;*/
    --document_cur := v_result;

    begin
      select c.identity_no,c.tax_number into v_tcnkn_no,v_vkn_no
       from koc_clm_suppliers_ext a,clm_suppliers b,koc_cp_partners_ext c
       where b.supp_id = a.supp_id
         and c.part_id = b.part_id
         and a.institute_code=p_institute_code;
       exception when no_data_found then
          v_tcnkn_no:=0;
          v_vkn_no:=0;
    end;
        --�ncelik olarak VKN bilgisi al�n�yor.
     if nvl(v_vkn_no,0)<>0 then
        tcknvkn_number:=v_vkn_no;
        tcknvkn_type:='VKN';
     else
        tcknvkn_number:=v_tcnkn_no;
        tcknvkn_type:='TCKN';
     end if;

  exception
    when others then
      dbms_output.put_line('hata');
      alz_web_process_utils.process_result(0,
                                           9,
                                           -1,
                                           'GET_DATA_INF_ERR',
                                           SUBSTR(SQLERRM || '--' ||
                                                  DBMS_UTILITY.format_error_backtrace,
                                                  1,
                                                  1000),
                                           p_institute_code,
                                           -1,
                                           NULL,
                                           'ALZ_HLTH_SUPP_RECONC_UTILS.getreconciliationinf',
                                           null,
                                           p_process_results);

  END getreconciliationinf;
   procedure print_cursor(p_cur IN  KOC_CLM_HLTH_PHARMACY_UTILS.rc) IS 
      v_data_msg CLOB;
      v_ndx NUMBER;
      v_keys_data VARCHAR2(32000);
    BEGIN
        v_data_msg := '{"data":[';
        FOR rec_1 IN (SELECT ROWNUM ROW_NO, 
                                      t1.column_value.getStringVal() ROW_DATA
                                 FROM (SELECT * FROM TABLE (XMLSEQUENCE(p_cur))) t1)    
                 LOOP                   
                     IF rec_1.ROW_NO>1 THEN
                         v_data_msg := v_data_msg || ',';
                     END IF;
                     v_data_msg := v_data_msg || '{';
                     v_ndx := 0;
                     FOR rec_2 IN (SELECT EXTRACTVALUE (t.COLUMN_VALUE, '/*') AS NODE_VALUE,
                                                        t.COLUMN_VALUE.getrootelement () AS NODE_NAME
                                     FROM TABLE (XMLSEQUENCE (EXTRACT(EXTRACT(XMLTYPE(rec_1.ROW_DATA), '//*'), '/ROW/*'))) t)
                     LOOP
                        IF v_ndx>0 THEN
                           v_data_msg := v_data_msg || ',';
               IF rec_1.ROW_NO = 1 THEN
                v_keys_data := v_keys_data || ',';
               END IF;
                        END IF;
            IF rec_1.ROW_NO = 1 THEN
              v_keys_data := v_keys_data || LOWER(rec_2.NODE_NAME);
            END IF;
                        v_data_msg := v_data_msg || '"' || LOWER(rec_2.NODE_NAME) || '":"' || TRIM(rec_2.Node_Value) || '"';
                        v_ndx := v_ndx + 1;                         
                     END LOOP;
                     v_data_msg := v_data_msg || '}';
                 END LOOP;   
          v_data_msg := v_data_msg||']}';
          DBMS_OUTPUT.PUT_LINE(v_data_msg);
    END print_cursor; 
  begin
  
                                                                                        
    --alz_hlth_supp_reconc_utils.
    getreconciliationinf(v_institute_code,
                                                    v_reconciliation_date,
                                                    v_reconc_status,
                                                    v_approve_exp,
                                                    master_cur,
                                                    status_cur,
                                                    document_cur,
                                                    v_tcknvkn_number,
                                                    v_tcknvkn_type,
                                                    v_process_results);
  
   print_cursor(document_cur);
   dbms_output.put_line('stataus');
   print_cursor(status_cur);
   dbms_output.put_line('master');
   print_cursor(master_cur);
end;
