DECLARE
PROCEDURE reconc_file_upload (p_remote_file_path IN VARCHAR2, p_remote_file IN VARCHAR2, p_doc_type IN VARCHAR2)  IS
  HOST                VARCHAR2 (255);
  soap_request        VARCHAR2 (32767);
  soap_respond        VARCHAR2 (32767);
  http_req            UTL_HTTP.req;
  http_resp           UTL_HTTP.resp;
  v_username          VARCHAR2(500);
  v_password          VARCHAR2(500);
  v_isSuccess         VARCHAR2(100);

BEGIN
  HOST := get_url_link('http://esb.allianz.com.tr:12000/FileNetServices/DocumentManagementService?wsdl'); 
         -- uat 'http://10.70.47.55:18213/FileNetServices/DocumentManagementService?wsdl';
         -- devtest 'http://10.70.47.25:17001/FileNetServices/DocumentManagementService?WSDL'; 
         -- get_url_link('http://esb.allianz.com.tr:12000/CreditCardCalls/CreditCardCallsProxy?wsdl');

    soap_request := '<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:web="http://webservice.filenet.allianz.com/">
                       <soap:Header/>
                       <soap:Body>
                          <web:insertReconciliationDocuments>
                             <ReconciliationId>9990</ReconciliationId>
                             <StatusOrder>1</StatusOrder>
                             <SourceType>OpusAdmin</SourceType>
                             <IdentityType>TCKN</IdentityType>
                             <IdentityNo>44818414116</IdentityNo>
                             <documents>
                                <barcode></barcode>
                                <createdBy></createdBy>
                                <documentId></documentId>
                                <file></file>
                                <filePath>'||p_remote_file_path||'</filePath>
                                <major>1</major>
                                <name>'||p_remote_file||'</name>
                                <type>'||p_doc_type||'</type>
                             </documents>
                          </web:insertReconciliationDocuments>
                       </soap:Body>
                    </soap:Envelope>';

    http_req := utl_http.begin_request(host, 'POST', 'HTTP/1.1');
    utl_http.set_header(http_req, 'Accept-Encoding', 'gzip,deflate');
    utl_http.set_header(http_req, 'Connection', 'keep-alive');
    utl_http.set_header(http_req, 'Content-Type', 'application/soap+xml;charset=UTF-8');
    utl_http.set_header(http_req, 'Content-Length', length(soap_request));
    BEGIN
        SELECT MAX(DECODE(a.param_name,'FILENET_OPUS_USER',param_value)) v_username
              ,MAX(DECODE(a.param_name,'FILENET_OPUS_PASSWORD',param_value)) v_password
          INTO v_username
              ,v_password    
         FROM alz_clm_filenet_param a
        WHERE a.param_name IN ('FILENET_OPUS_USER','FILENET_OPUS_PASSWORD');
    UTL_HTTP.SET_AUTHENTICATION(http_req,v_username,v_password);     
    END;
    
    utl_http.write_text(http_req, soap_request);
    http_resp := utl_http.get_response(http_req);

    dbms_output.put_line('Response> status_code: "' || http_resp.status_code || '"');
    dbms_output.put_line('Response> reason_phrase: "' || http_resp.reason_phrase || '"'); --*
    dbms_output.put_line('Response> http_version: "' || http_resp.http_version || '"');
        
    utl_http.read_text(http_resp, soap_respond, 32000);
    utl_http.end_response(http_resp);
    dbms_output.put_line('soap_respond: '||soap_respond);
    v_isSuccess := substr(soap_respond, instr(soap_respond, '<status>')+length('<status>'), (instr(soap_respond, '</status>')-instr(soap_respond, '<status>')-length('<status>')));    
    dbms_output.put_line('v_isSuccess: '||v_isSuccess); --*
END;
BEGIN
   reconc_file_upload('\TMP','pddevr.csv','AS0V001');
END;   

/*

select * from alz_hlth_supp_reconc_docs order by process_date desc

select * from alz_docs where object_id = 43561206
*/
/*
{343BFB75-A9F3-407B-8AD4-12C9797EC5B0}

http://aztrfnapptest.allianz-tr.local:9080/navigator/bookmark.jsp?desktop=HASARYONETIMI&repositoryId=HASARYONETIMI&docid={D80B3FE8-EA05-41BE-878E-A1F2281FFACE}&template_name=Document&version=released


*/
