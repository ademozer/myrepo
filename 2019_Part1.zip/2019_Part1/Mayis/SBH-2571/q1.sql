select distinct c.reconciliation_id,c.status_order_no,
                     c.object_id,c.doc_code,c.process_date,c.process_user,a.institute_code
        from alz_hlth_supp_reconciliation a,
             alz_hlth_supp_reconc_docs  c
       where a.reconciliation_id=c.reconciliation_id
         --and  a.institute_code=1526
        -- and ((p_reconciliation_date is not null and a.reconciliation_date=p_reconciliation_date)
          --or (p_reconciliation_date is null))
       --  and nvl(a.sub_status,0)=nvl(p_approve_exp,nvl(a.sub_status,0))
         and exists(select 1 from alz_hlth_supp_reconc_status w
                       where w.reconciliation_id=a.reconciliation_id
                         --and w.status_type<>'CANCELLED'
                         --and w.status_type=nvl(p_reconc_status,w.status_type)
                         and w.status_order_no=(select max(t.status_order_no)
                                               from alz_hlth_supp_reconc_status t
                                               where t.reconciliation_id=w.reconciliation_id))
         order by c.reconciliation_id,c.status_order_no,c.object_id asc;
         
         select * from alz_hlth_supp_reconc_docs--@opusprep
         select * from alz_hlth_supp_reconciliation@opusprep where reconciliation_id=13148--3220
         
         select * from alz_hlth_supp_reconc_docs order by process_date desc
         select distinct status_type from alz_hlth_supp_reconc_status 
         
         select * from alz_hlth_supp_reconc_status  where reconciliation_id=2220 for update
         select * from alz_docs where object_id = 49029831
         
         {AD78E6AD-A378-4363-9EF7-7F84DC7CE60D}
http://aztrfnapptest.allianz-tr.local:9080/navigator/bookmark.jsp?desktop=HASARYONETIMI&repositoryId=HASARYONETIMI&docid={AD78E6AD-A378-4363-9EF7-7F84DC7CE60D}&template_name=Document&version=released
