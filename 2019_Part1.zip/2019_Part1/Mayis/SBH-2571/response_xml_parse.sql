DECLARE
 po_data CLOB;
BEGIN
  
FOR rec IN (SELECT * FROM XMLTABLE('/Envelope/Body/insertReconciliationDocumentsResponse/return'
                  PASSING XMLTYPE('<Envelope xmlns:S="http://www.w3.org/2003/05/soap-envelope"><S:Header><X-OPNET-Transaction-Trace xmlns="http://opnet.com">pid=17219,requestid=18246f6f-5686-4f4d-b13a-fdef423b0862</X-OPNET-Transaction-Trace></S:Header><Body><insertReconciliationDocumentsResponse xmlns:ns0="http://webservice.filenet.allianz.com/"><return><status>FAILURE</status></return></insertReconciliationDocumentsResponse></Body></Envelope>')
                  COLUMNS 
                    status     VARCHAR2(100) PATH 'status')) LOOP
                    po_data := po_data || '{"status":"' || rec.status||'"}';
                 --DBMS_OUTPUT.PUT_LINE('Tckn:'||rec.TcKimlikNo||' Ad�:'||rec.Adi||' Soyadi:'||rec.Soyadi||' SicilNo: '||rec.SicilNo||' KayitDurumAdi: '||rec.KayitDurumuAdi ||' CalisanTipAdi:'||rec.CalisanTipiAdi||' BaslangicTarihi:'||rec.BaslangicTarihi||' BitisTarihi:'||rec.BitisTarihi);
              END LOOP; 
DBMS_OUTPUT.PUT_LINE(po_data);
END;

              
--SELECT '<ns0:insertReconciliationDocumentsResponse xmlns:ns0="http://webservice.filenet.allianz.com/"><return><status>FAILURE</status></return></ns0:insertReconciliationDocumentsResponse></S:Body>';
