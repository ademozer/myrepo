﻿DECLARE
  p_part_id NUMBER := 102501891;
  p_group_code VARCHAR2(100) := 'S16037'; 
  p_to_whom_clm_paid VARCHAR2(100);
  p_sgk_srv  NUMBER := 1;
  p_bank_code  VARCHAR2(100);
  p_bank_code_desc VARCHAR2(100);
  p_subsidiary_code VARCHAR2(100);
         p_subsidiary_code_desc VARCHAR2(100);
         p_account_no VARCHAR2(100);
         p_IBAN_CODE VARCHAR2(100);
         p_ACC_OWNER_PARTID VARCHAR2(100);
         p_account_owner VARCHAR2(100);
         p_ACCOUNT_EXPLANATION VARCHAR2(100);
         p_money_order_address VARCHAR2(100);
        --  p_payment_param_payment_type = '5' and p_bankasiz = 0
          
PROCEDURE paymentProcess(p_bankasiz number default 0)
IS
   CURSOR curpartner (p_part_id NUMBER)
   IS
      SELECT   pi.identity_no, pi.TAX_NUMBER, sp.PARTNER_TYPE
        FROM   koc_cp_partners_ext pi, cp_partners sp
       WHERE   pi.part_id = p_part_id AND sp.PART_ID = pi.PART_ID;

   curpartnerrec      curpartner%ROWTYPE;


   v_bank_code        VARCHAR2 (100);
   v_subsidary_code   VARCHAR2 (100);
   v_account_no       VARCHAR2 (100);
   
   --Kfs sirket grubu main_group_code = S9136
   --Garanti Bankasý Sandýk Hesabý = S16037
   Cursor C1 is 
      select t.main_group_code 
        from koc_cp_group_master t 
       where t.main_group_code in( 'S16037', 'S9136') 
         and t.validity_end_date is null 
         and t.group_code = p_group_code;--:koc_clm_hlth_detail.group_code;
   
   v_mainGroupCode varchar2(20) := null;  
   
BEGIN
   v_bank_code :='100'; --NULL;
   v_subsidary_code := NULL;
   v_account_no := NULL;


   /*IF :payment_param.payment_type IS NULL
   THEN
      opu001.msg (999999,
                  'E',
                  NULL,
                  NULL,
                  NULL,
                  'Lütfen ödeme tipini seçiniz.');
      GO_ITEM ('payment_param.payment_type');
      RAISE form_trigger_failure;
   END IF;*/

   --:payment_param.to_whom_clm_paid := 'INSURED';
   p_to_whom_clm_paid := 'INSURED';
   
   /*IF :koc_clm_hlth_detail.date_of_loss <= TO_DATE ('31122007', 'DDMMYYYY')
      AND:koc_clm_hlth_detail.group_code = 'S5001'
   THEN                                                     --aysel 21.01.2008
      IF :koc_clm_hlth_detail.sub_company_code IS NOT NULL
         AND--:koc_acc_bank_history.bank_code is null and
            :koc_acc_gr_bank_history.bank_code IS NOT NULL
      THEN
         :payment_param.to_whom_clm_paid := 'GROUP';
      END IF;
   END IF;*/



   --IF koc_clm_hlth_trnx.isMonthClosedForClm (p_payment_param_payment_date) = 0
  -- THEN
    --  IF p_payment_param_payment_type = '5' and p_bankasiz = 0
   --THEN
         --GO_ITEM ('payment_param.bank_code');
         p_bank_code_desc := NULL;
         p_subsidiary_code_desc := NULL;
         p_account_no := NULL;
         p_IBAN_CODE := NULL;
         p_ACC_OWNER_PARTID := NULL;
         p_account_owner := NULL;
         p_ACCOUNT_EXPLANATION := NULL;
         p_money_order_address := NULL;

         IF p_to_whom_clm_paid = 'INSURED'
         THEN
           /* IF :koc_acc_bank_history.bank_code IS NULL
               AND:koc_acc_bank_history.IBAN_CODE IS NOT NULL
            THEN
               parse_iban_no (:koc_acc_bank_history.IBAN_CODE,
                              v_bank_code,
                              v_subsidary_code,
                              v_account_no);
            END IF;*/

            p_bank_code :=
               NVL (null, v_bank_code);
            /*p_payment_param_subsidiary_code :=
               :koc_acc_bank_history.subsidiary_code;
            p_payment_param_account_no := :koc_acc_bank_history.account_no;
            p_payment_param_IBAN_CODE := :koc_acc_bank_history.IBAN_CODE;
            p_payment_param_ACC_OWNER_PARTID :=
               :koc_acc_bank_history.ACC_OWNER_PARTID;
            p_payment_param_account_owner :=
               :koc_acc_bank_history.account_owner;
            p_payment_param_INDEMNITY_ACCOUNT_EXPLANATION :=
               :koc_acc_bank_history.INDEMNITY_ACCOUNT_EXPLANATION;
            p_payment_param_is_account_approved :=
               :koc_acc_bank_history.IS_INDEMN_ACC_APPROVED;*/

            IF p_ACC_OWNER_PARTID IS NOT NULL
            THEN
               OPEN curpartner (p_ACC_OWNER_PARTID);
            ELSE
               p_ACC_OWNER_PARTID := p_part_id;

               OPEN curpartner (p_part_id);
            END IF;

            FETCH curpartner INTO curpartnerrec;

            CLOSE curpartner;

           /* IF curpartnerrec.PARTNER_TYPE = 'P'
            THEN
               p_tc_no := curpartnerrec.identity_no;
            ELSE
               p_vkn_no := curpartnerrec.TAX_NUMBER;
            END IF;*/
         ELSE
            /*IF :koc_acc_gr_bank_history.bank_code IS NULL
               AND:koc_acc_gr_bank_history.IBAN_CODE IS NOT NULL
            THEN
               parse_iban_no (:koc_acc_gr_bank_history.IBAN_CODE,
                              v_bank_code,
                              v_subsidary_code,
                              v_account_no);
            END IF;*/

            p_bank_code :=
               NVL (null, v_bank_code);
            p_subsidiary_code := '1';
              -- :koc_acc_gr_bank_history.subsidiary_code;
           -- p_account_no := :koc_acc_gr_bank_history.account_no;
          --  p_payment_param_IBAN_CODE := :koc_acc_gr_bank_history.IBAN_CODE;
          --  p_payment_param_account_owner :=
             --  :koc_acc_gr_bank_history.account_owner;
           -- p_payment_param_INDEMNITY_ACCOUNT_EXPLANATION :=
            --   :koc_acc_gr_bank_history.INDEMNITY_ACCOUNT_EXPLANATION;
         END IF;

         IF p_sgk_srv = 1
         THEN   
            for rec in C1 Loop
                v_mainGroupCode := rec.main_group_code;
            End Loop;
                                                            -- task 191293
            if(v_mainGroupCode = 'S16037') Then --Garanti bankasy Sandyk Hesaby
                   SELECT Bank_Code, Subsidiary_Code, Account_No, Account_Owner, Iban_Code
                     INTO p_Bank_Code,
                          p_Subsidiary_Code,
                          p_Account_No,
                          p_Account_Owner,
                          p_Iban_Code
                     FROM Koc_Acc_Bank_History
                    WHERE Contract_Id = 2
                      AND Validity_End_Date IS NULL;
            elsif(v_mainGroupCode = 'S9136') Then--KFS ?irketler grubudur
                 SELECT Bank_Code, Subsidiary_Code, Account_No, Account_Owner, Iban_Code
                   INTO p_Bank_Code,
                        p_Subsidiary_Code,
                        p_Account_No,
                        p_Account_Owner,
                        p_Iban_Code
                   FROM Koc_Acc_Bank_History
                  WHERE Contract_Id = 1
                    AND Validity_End_Date IS NULL;
            End if;
            
         END IF;

         p_bank_code_desc :=
            koc_clm_hlth_utils2.getBankName (p_bank_code);
         p_subsidiary_code_desc :=
            koc_clm_hlth_utils2.getSubsidiaryName (
               p_bank_code,
               p_subsidiary_code
            );
      /*Task 142518
                                               show_view('CAN_INDEMNITY_TRANSFER');
                                               show_window('WINDOW_INDEMNITY_TRANSFER');*/
      
      -- Omert SBH-363 banka bilgisi olmadan tahakkuk edilebilsin
      /*ELSIF :payment_param.payment_type = '5' and p_bankasiz = 1 THEN 
          
         :payment_param.bank_code_desc := NULL;
         :payment_param.subsidiary_code_desc := NULL;
         :payment_param.account_no := NULL;
         :payment_param.account_owner := NULL;
         :payment_param.IBAN_CODE := NULL;
         :payment_param.ACC_OWNER_PARTID := NULL;
         :payment_param.INDEMNITY_ACCOUNT_EXPLANATION := NULL;
         :payment_param.money_order_address := NULL;

         :payment_param.bank_code := NULL;
         :payment_param.subsidiary_code := NULL;
         :payment_param.is_account_approved := NULL;

         CHECK_INVOICE_HASH(true,false);
         get_provision(1);
         UPDATE_STATUS('TAH_BT');
         UPDATE_FIRST_CLM_HASH;
         BEGIN
          ALZ_HLTH_CPA.insertInvoiceHistory(:koc_clm_hlth_detail.claim_id,:koc_clm_hlth_detail.sf_no,:koc_clm_hlth_detail.add_order_no,'TAH_BT','Statü degistirildi',1);
         EXCEPTION WHEN OTHERS
         THEN
           message('Faturanýn tarihçe bilgilerinde hata alýndý'||' '||SQLERRM);
         END;   
         BEGIN
           BPM_EXECUTE_TASK(:KOC_CLM_HLTH_DETAIL.claim_id,:KOC_CLM_HLTH_DETAIL.add_order_no,'TAHAKKUK');
         exception when others
          then NULL;
       --opu001.msg(999999,'W',NULL,NULL,NULL,'BPM''yi kontrol ediniz'||' '||SUBSTR(SQLERRM,1,2000));
         END;*/
      /*ELSIF :payment_param.payment_type = '8'
      THEN
         :payment_param.bank_code_desc := NULL;
         :payment_param.subsidiary_code_desc := NULL;
         :payment_param.account_no := NULL;
         :payment_param.account_owner := NULL;
         :payment_param.IBAN_CODE := NULL;
         :payment_param.ACC_OWNER_PARTID := NULL;
         :payment_param.INDEMNITY_ACCOUNT_EXPLANATION := NULL;
         :payment_param.money_order_address := NULL;

         :payment_param.bank_code := NULL;
         :payment_param.subsidiary_code := NULL;
         :payment_param.is_account_approved := NULL;

       --opu001.msg(99999,'Q',null,null,null,'Isleminizi yapmak istediginizden emin misiniz?');
       --IF opu001.v_alert_button =ALERT_BUTTON1  THEN 
         CHECK_INVOICE_HASH(true,false);
         get_provision(1);
         UPDATE_STATUS('TAH');
         UPDATE_FIRST_CLM_HASH;
         BEGIN
          ALZ_HLTH_CPA.insertInvoiceHistory(:koc_clm_hlth_detail.claim_id,:koc_clm_hlth_detail.sf_no,:koc_clm_hlth_detail.add_order_no,'TAH','Statü degistirildi',1);
         EXCEPTION WHEN OTHERS
         THEN
           message('Faturanýn tarihçe bilgilerinde hata alýndý'||' '||SQLERRM);
         END;   
         BEGIN
           BPM_EXECUTE_TASK(:KOC_CLM_HLTH_DETAIL.claim_id,:KOC_CLM_HLTH_DETAIL.add_order_no,'TAHAKKUK');
         exception when others
          then NULL;
       --opu001.msg(999999,'W',NULL,NULL,NULL,'BPM''yi kontrol ediniz'||' '||SUBSTR(SQLERRM,1,2000));
         END;
       --ELSE
       --  go_block('KOC_CLM_HLTH_DETAIL');
       --  go_item('PUSH_BUTTON508');
       --END IF;*/
      --ELSE
        /* opu001.msg (999999,
                     'E',
                     NULL,
                     NULL,
                     NULL,
                     'Hatali ödeme tipi.');
         GO_ITEM ('payment_param.payment_type');
         RAISE form_trigger_failure;*/
       --  dbms_output.put_line('hatalı ödeme tipi');
      --END IF;
   --ELSE
      /*opu001.msg (999999,
                  'E',
                  NULL,
                  NULL,
                  NULL,
                  'Girdiðiniz tarih itibari ile hasar ayý kapalý');
      GO_ITEM ('payment_param.payment_date');
      RAISE form_trigger_failure;*/
     -- dbms_output.put_line('Girdiðiniz tarih itibari ile hasar ayý kapalý');
   --END IF;
   dbms_output.put_line('sgk_srv='||p_sgk_srv);
   dbms_output.put_line('bank='||p_Bank_Code);
   dbms_output.put_line('iban='||p_Iban_Code);
END paymentProcess;

BEGIN
    paymentProcess(0);
END;
