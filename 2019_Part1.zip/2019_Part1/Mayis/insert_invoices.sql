prompt Importing table invoices...
set feedback off
set define off
insert into invoices (INVOICEID, INVOICEDATE, INSTITUTE_CODE, AMOUNT, SWIFT_CODE, EXT_REFERENCE)
values ('21672(27/10/2012)', to_date('01-01-2013', 'dd-mm-yyyy'), 2769, 11.32, 'TL', '32734181');

insert into invoices (INVOICEID, INVOICEDATE, INSTITUTE_CODE, AMOUNT, SWIFT_CODE, EXT_REFERENCE)
values ('23480(31/10/2012)', to_date('01-01-2013', 'dd-mm-yyyy'), 2769, 40.656, 'TL', '32740289');

insert into invoices (INVOICEID, INVOICEDATE, INSTITUTE_CODE, AMOUNT, SWIFT_CODE, EXT_REFERENCE)
values ('170034(07/11/2012)', to_date('01-01-2013', 'dd-mm-yyyy'), 2769, 16.832, 'TL', '32742589');

insert into invoices (INVOICEID, INVOICEDATE, INSTITUTE_CODE, AMOUNT, SWIFT_CODE, EXT_REFERENCE)
values ('368448(16/11/2012)', to_date('01-01-2013', 'dd-mm-yyyy'), 2769, 10.72, 'TL', '32750351');

insert into invoices (INVOICEID, INVOICEDATE, INSTITUTE_CODE, AMOUNT, SWIFT_CODE, EXT_REFERENCE)
values ('338410(16/11/2012)', to_date('01-01-2013', 'dd-mm-yyyy'), 2769, 16.704, 'TL', '32750352');

insert into invoices (INVOICEID, INVOICEDATE, INSTITUTE_CODE, AMOUNT, SWIFT_CODE, EXT_REFERENCE)
values ('87079(19/11/2012)', to_date('01-01-2013', 'dd-mm-yyyy'), 2769, 14.872, 'TL', '32752058');

insert into invoices (INVOICEID, INVOICEDATE, INSTITUTE_CODE, AMOUNT, SWIFT_CODE, EXT_REFERENCE)
values ('7358(19/11/2012)', to_date('01-01-2013', 'dd-mm-yyyy'), 2769, 32.528, 'TL', '32752472');

insert into invoices (INVOICEID, INVOICEDATE, INSTITUTE_CODE, AMOUNT, SWIFT_CODE, EXT_REFERENCE)
values ('0(20/11/2012)', to_date('01-01-2013', 'dd-mm-yyyy'), 2769, 1041.184, 'TL', '32752760');

insert into invoices (INVOICEID, INVOICEDATE, INSTITUTE_CODE, AMOUNT, SWIFT_CODE, EXT_REFERENCE)
values ('9940', to_date('11-03-2013 15:32:40', 'dd-mm-yyyy hh24:mi:ss'), 2769, 12.48, 'TL', '32852826');

insert into invoices (INVOICEID, INVOICEDATE, INSTITUTE_CODE, AMOUNT, SWIFT_CODE, EXT_REFERENCE)
values ('264227', to_date('31-01-2013 17:55:04', 'dd-mm-yyyy hh24:mi:ss'), 2769, 15.888, 'TL', '32817798');

insert into invoices (INVOICEID, INVOICEDATE, INSTITUTE_CODE, AMOUNT, SWIFT_CODE, EXT_REFERENCE)
values ('24247', to_date('26-01-2013 22:54:08', 'dd-mm-yyyy hh24:mi:ss'), 2769, 20.88, 'TL', '32813526');

insert into invoices (INVOICEID, INVOICEDATE, INSTITUTE_CODE, AMOUNT, SWIFT_CODE, EXT_REFERENCE)
values ('630224', to_date('25-01-2013 13:00:00', 'dd-mm-yyyy hh24:mi:ss'), 2769, 9.216, 'TL', '32813527');

insert into invoices (INVOICEID, INVOICEDATE, INSTITUTE_CODE, AMOUNT, SWIFT_CODE, EXT_REFERENCE)
values ('0', to_date('15-03-2013', 'dd-mm-yyyy'), 2769, 22.096, 'TL', '32857144');

prompt Done.
