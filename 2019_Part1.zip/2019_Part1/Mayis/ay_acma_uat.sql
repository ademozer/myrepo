DECLARE
 v_start_date VARCHAR2(10) := '01/05/2019';
BEGIN
insert into koc_process_close  
select * from koc_process_close@opusprep where process_date = to_date('01/05/2019','DD/MM/YYYY')
minus
select * from koc_process_close where process_date = to_date('01/05/2019','DD/MM/YYYY');
EXCEPTION
WHEN OTHERS THEN
   DBMS_OUTPUT.PUT_LINE(
END;

select * from user_errors
