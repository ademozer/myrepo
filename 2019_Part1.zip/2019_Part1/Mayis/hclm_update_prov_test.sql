DECLARE      
       v_hltprv_Log          Hltprv_Log_Typ := Hltprv_Log_Typ();                   
       v_request CLOB;
       v_response CLOB;
       v_url VARCHAR2(200) := --'http://10.70.47.25:19101/hclm-health-claim-service/api/v1/provision/createProvision';
                              --'http://esb.allianz.com.tr:12000/hclm-service/api/v1/provision/createProvision'; 
                              --'http://10.70.47.55:19101/hclm-health-claim-service/api/v1/provision/updateProvision';
                              --get_url_link('http://esb.allianz.com.tr:12000/hclm-health-claim-service/api/v1/provision/createProvision');
                              get_url_link('http://esb.allianz.com.tr:12000/hclm-health-claim-service/api/v1/provision/updateProvision');
                              --'http://uatesb.allianz.com.tr:12000/hclm-health-claim-service/api/v1/provision/updateProvision';
       v_status NUMBER;
       v_message VARCHAR2(1000); 
       v_institute_code NUMBER := 337;
       v_ndx1 NUMBER;
       v_ndx2 NUMBER;
       v_process_name VARCHAR2(400) := 'Deri laserasyonu onar??m??, 5 cm''den k??????k, tek bir alanda';
       
       CURSOR crs_obj(p_data IN CLOB) IS 
          SELECT trim(replace (Regexp_Substr (Xt.Element, '[^:]+', 1) , '"',''))   KEY, 
                 trim(replace (Regexp_Substr (Xt.Element, '[^:]+', 1, 2), '"','')) VALUE              
           FROM (Select Regexp_Substr (p_data, '[^,]+', 1, Level) Element
                   From Dual
                Connect By Level <= Length (Regexp_Replace (p_data, '[^,]+')) + 1) Xt; 
                
       procedure callRestService(p_Url               In          Varchar2,
                              p_Method            In          Varchar2,                                                                           
                              p_Request           In          Clob,                    
                              p_Response          Out         Clob, 
                              p_Status            Out         Number, 
                              p_Message           Out         Varchar2) IS 
                              
        v_Req               utl_http.req;
        v_Req_Length        Number;
        v_Res               utl_http.resp;
        v_Buffer            Varchar2(32767);
        v_Offset            Number := 1;
        v_Amount            Number :=32767;
        v_Utl_Err           Varchar2(1000);
        v_value             varchar2(4000);
        hata_code           varchar2(10);
        v_output            varchar2(10);
        v_Response          CLOB;
        v_Line_Number       NUMBER := 0;
        
        Begin
          
            v_Req_Length := dbms_lob.getlength(p_Request);
            --v_Req := utl_http.begin_request(get_url_link(p_Url), p_Method, 'HTTP/1.1');   
            v_Req := utl_http.begin_request(p_Url, p_Method, 'HTTP/1.1');      
            utl_http.set_header(v_Req, 'Content-Length', v_Req_Length);
            utl_http.set_header(v_Req, 'Content-Type', 'application/json;charset=UTF-8');
            utl_http.set_header (v_Req,'Transfer-Encoding', 'chunked' );
            utl_http.set_body_charset(v_Req,'UTF-8');
            --UTL_HTTP.set_response_error_check(false); 
            
            While (v_Offset < v_Req_Length)
            Loop
               dbms_lob.read(p_Request, v_Amount, v_Offset, v_Buffer);
               utl_http.write_text(r    => v_Req, data => v_Buffer);
               v_Offset := v_Offset + v_Amount;
            End Loop;
            
            v_Res := utl_http.get_response(v_Req);
            p_status := 0;
            p_message := v_Res.status_code || ':' || v_Res.reason_phrase;
            IF v_Res.status_code != 200  THEN 
                --DBMS_OUTPUT.PUT_LINE('Hata:'|| v_Res.status_code);
                --DBMS_OUTPUT.PUT_LINE('Hata:'|| v_Res.reason_phrase);
                --p_message := v_Res.status_code || ':' || v_Res.reason_phrase;
                p_Status := 1;
               -- utl_http.read_text(v_Res, p_message);
               -- DBMS_OUTPUT.PUT_LINE('Hata:'|| p_message);
               -- Raise_Application_Error(-20200, v_Res.status_code || ' - Hata Olu�tu');                                     
            END IF; 
            
            Begin
              
               loop                 
                  utl_http.read_line(v_Res, v_value);
                  v_value := TRIM(regexp_replace(v_value, '([^[:graph:] | ^[:blank:]])', ''));
                  v_Response := v_Response || v_value;                                                    
               end loop;               
               utl_http.end_response(v_Res);               
            Exception              
            When utl_http.end_of_body Then
                 utl_http.end_response(v_Res);
            When utl_http.too_many_requests Then
                 utl_http.end_response(v_Res);
            When Others Then
                 utl_http.end_response(v_Res);
           End;  
           --DBMS_OUTPUT.PUT_LINE('response='||v_response);    
           /*IF p_Status = 1 THEN
               p_Response := '';
               RETURN;
           END IF;*/
           
           p_Response := TRIM(v_Response);
          
          
           
        EXCEPTION 
           WHEN OTHERS THEN
              utl_http.end_response(v_Res);
              v_utl_err:= Utl_Http.Get_Detailed_Sqlerrm;
              p_Status := 1;
              p_Response := '';
              p_Message := v_utl_err||' - '||p_url;
              
    END callRestService;
    
BEGIN
      select process_name INTO v_process_name 
      from Koc_Cc_Hlth_Tda_Proc_List 
      where process_code_main='150' and process_code_sub1='59' and process_code_sub2='187';
      
      dbms_output.put_line('i�lem ad�  :'||v_process_name);
      v_process_name := REPLACE(v_process_name,CHR(39), CHR(39)||CHR(39));
          
       v_request := '{
              "contractId" : "419139242",
              "instituteCode" : "13",
              "partitionNo" : "2692",
              "realizationDate" : "2019-05-06T11:27:27.000Z",
              "claimDetailDto" : {"extReference" : "56790882",
              "claimId" : "40180290",
              "addOrderNo" : "1",
              "sfNo" : "1",
              "ahek" : "false",
              "automated" : "false",
              "beforeComplaintIllness" : "",
              "breResultCode" : "PP",
              "claimInstLoc" : "YI",
              "claimInstType" : "AK",
              "claimStatusType" : "PP",
              "classDisease1" : "4S610",
              "classDisease2" : "",
              "classDisease3" : "",
              "closeDate" : "",
              "commDate" : "",
              "communicationExp1" : "",
              "communicationExp2" : "",
              "communicationNo" : "",
              "communicationNumber1" : "",
              "communicationNumber2" : "",
              "complaintStart" : "",
              "complementary" : "false",
              "consultationDiagnosis" : "",
              "contractMessage" : "",
              "countryCode" : "",
              "cpaStatus" : "",
              "dateOfLoss" : "2019-05-06T11:27:27.000Z",
              "deductionRate" : "",
              "dhInst" : "",
              "dischargeDate" : "2019-05-06T00:00:00.000Z",
              "doctorCode" : "265721",
              "doctorStatus" : "TT_FORMUNU_DOLDURAN",
              "doctorType" : "Anla�mal� Doktor",
              "drDiplomaNo" : "102954",
              "drNameLastname" : "TANER BAYRAKTAR",
              "eprescriptionNo" : "",
              "exGratia" : "false",
              "exGratiaFee" : "",
              "examDate" : "",
              "examinationsResults" : "",
              "explanation" : "",
              "extDoctor" : "false",
              "extDoctorAmt" : "",
              "finalClassDisease1" : "4S610",
              "finalClassDisease2" : "",
              "finalClassDisease3" : "",
              "fromCityCode" : "",
              "fromDistrictCode" : "",
              "fromToPlace" : "",
              "groupCode" : "S9136",
              "hasUnreadableDoc" : "",
              "hlthSrvPay" : "",
              "hospitalAmt" : "",
              "hospitalRefNo" : "",
              "hospitalizeApprFormExpl1" : "",
              "hospitalizeApprFormExpl2" : "",
              "hospitalizeDate" : "2019-05-06T00:00:00.000Z",
              "identitiyType" : "",
              "identityNo" : "48307054180",
              "identityNumber" : "",
              "instGlnCode" : "",
              "instTaxNumber" : "",
              "instTaxOffice" : "",
              "instituteCode" : "13",
              "invoiceDate" : "",
              "invoiceExplanation" : "",
              "invoiceNo" : "",
              "invoiceTotal" : "",
              "judicial" : "false",
              "lastMenstDate" : "",
              "medicalBackground" : "",
              "medulaDate" : "",
              "nationality" : "",
              "ok" : "false",
              "onlyExaminationFee" : "false",
              "origClaimInstLoc" : "YI",
              "origClaimInstType" : "AK",
              "original" : "false",
              "otherCountry" : "",
              "otherCountryCity" : "",
              "packageDate" : "2018-10-01T00:00:00.000Z",
              "packageId" : "259157",
              "partId" : "24644647",
              "patientAdmittanceDate" : "2019-05-06T11:41:58.000Z",
              "patientComplaint" : "",
              "patientVisitMade" : "false",
              "paymentTotal" : "",
              "personalNotes" : "",
              "plannedTreatmentProc" : "",
              "possDischargeDate" : "",
              "possHospitalizeDate" : "",
              "prediagnosisDiagnosis" : "",
              "pregnant" : "false",
              "prescriptionDate" : "",
              "prescriptionNo" : "",
              "prescriptionType" : "",
              "processDate" : "2019-05-06T11:28:59.000Z",
              "provisionFeeChargeDate" : "",
              "provisionDate" : "2019-05-06T11:27:27.000Z",
              "provisionUserId" : "SKR500204",
              "provDemandDate" : "",
              "processExp" : "",
              "sgkRefNo" : "",
              "socSecInstApp" : "",
              "shippingDate" : "",
              "shippingNo" : "",
              "realizationDate" : "",
              "relClaimId" : "",
              "sgkTotal" : "0",
              "referralInstituteName" : "",
              "requestAmount" : "",
              "requestSystem" : "WS",
              "sgkUsed" : "false",
              "referral" : "false",
              "suspense" : "false",
              "suspenseDate" : "",
              "specialtySubject" : "1380",
              "statusCode" : "PP",
              "swiftCode" : "TL",
              "toCityCode" : "",
              "toDistrictCode" : "",
              "timeStamp" : "",
              "surgeryDate" : "",
              "visitingReason" : "",
              "urgentCure" : "false",
              "wrongProvision" : "false",
              "web" : "true",
              "webLocationCode" : "910",
              "ytType" : "DIGER",
              "updateLimit" : "true",
              "versionNo" : "1",
                  "itemList" : [{
                "claimId" : "40180290",
                "addOrderNo" : "1",
                "coverCode" : "S659",
                "drgCode" : "",
                "explanation" : "",
                "breResultCode" : "",
                "locationCode" : "910",
                "quantity" : "1",
                "price" : "16.77",
                "itemType" : "MALZEME",
                "orderNo" : "45-73695815-450001-9",
                "processCode" : "61460614",
                "processCodeList" : "CARI_LISTE",
                "sfNo" : "1",
                "ubbCode" : "4049500263863",
                "surgeryId" : "",
                "vatRate" : "",
                "statusCode" : "PP",
                "timeStamp" : "2019-05-06T11:28:37.000Z",
                "seqNo" : "1",
                "reqItemName" : "Omnistrip Elastic 12x101mm. Paul Hartmann. 5406853",
                "reqItemUbbcode" : "4049500263863"
              },{
                "claimId" : "40180290",
                "addOrderNo" : "1",
                "coverCode" : "S659",
                "drgCode" : "",
                "explanation" : "",
                "breResultCode" : "",
                "locationCode" : "910",
                "quantity" : "1",
                "price" : "50.04",
                "itemType" : "MALZEME",
                "orderNo" : "45-73695815-450001-10",
                "processCode" : "22010710",
                "processCodeList" : "CARI_LISTE",
                "sfNo" : "1",
                "ubbCode" : "9999999999999",
                "surgeryId" : "",
                "vatRate" : "",
                "statusCode" : "PP",
                "timeStamp" : "2019-05-06T11:28:37.000Z",
                "seqNo" : "2",
                "reqItemName" : "50 Surgipro 19mm Keskin 38 45cm SP661",
                "reqItemUbbcode" : "10884521037380"
              },{
                "claimId" : "40180290",
                "addOrderNo" : "1",
                "coverCode" : "S659",
                "drgCode" : "",
                "explanation" : "",
                "breResultCode" : "",
                "locationCode" : "910",
                "quantity" : "1",
                "price" : "12.57",
                "itemType" : "MALZEME",
                "orderNo" : "45-73695815-450001-11",
                "processCode" : "61495307",
                "processCodeList" : "CARI_LISTE",
                "sfNo" : "1",
                "ubbCode" : "9999999999999",
                "surgeryId" : "",
                "vatRate" : "",
                "statusCode" : "PP",
                "timeStamp" : "2019-05-06T11:28:37.000Z",
                "seqNo" : "3",
                "reqItemName" : "Eldiven. Cerrahi. Steril. Pudrasiz. No:8. Encore Microptic. Ansell. 5787105EU",
                "reqItemUbbcode" : "25414566417261"
              },{
                "claimId" : "40180290",
                "addOrderNo" : "1",
                "coverCode" : "S659",
                "drgCode" : "",
                "explanation" : "",
                "breResultCode" : "",
                "locationCode" : "910",
                "quantity" : "1",
                "price" : "33.11",
                "itemType" : "MALZEME",
                "orderNo" : "45-73695815-450001-12",
                "processCode" : "22041404",
                "processCodeList" : "CARI_LISTE",
                "sfNo" : "1",
                "ubbCode" : "9999999999999",
                "surgeryId" : "",
                "vatRate" : "",
                "statusCode" : "PP",
                "timeStamp" : "2019-05-06T11:28:37.000Z",
                "seqNo" : "4",
                "reqItemName" : "Bandaj Coban 2.5 cm 1581 3M",
                "reqItemUbbcode" : "04046719706204"
              }],
                  "medicineList" : [{
                "claimId" : "40180290",
                "addOrderNo" : "1",
                "coverCode" : "S659",
                "barcode" : "8699546355174",
                "classDisease4" : "",
                "controlExpiryDate" : "",
                "barcode2d" : "0",
                "barcodeSerialNum" : "",
                "barcodeExpiryDate" : "",
                "barcodeLotNum" : "",
                "breResultCode" : "",
                "locationCode" : "910",
                "dosePeriod" : "0",
                "dose1" : "",
                "dose2" : "",
                "equMedicineApp" : "",
                "dose3" : "",
                "dose3Period" : "",
                "expiryDate" : "",
                "dose4" : "",
                "dose4Period" : "",
                "noteId" : "",
                "itemType" : "ILAC",
                "drgCode" : "",
                "explanation" : "",
                "sfNo" : "1",
                "unit" : "1",
                "price" : "26.52",
                "secondBarcode" : "",
                "statusCode" : "PP",
                "rejectUncheck" : "",
                "rejectUnit" : "",
                "rejectExplanation" : "",
                "secondBarcGiven" : "",
                "timeStamp" : "2019-05-06T11:28:37.000Z",
                "orderNo" : "45-73695815-450001-4",
                "surgeryId" : "",
                "vatRate" : "",
                "seqNo" : "3",
                "processCode" : "13010209",
                "processCodeList" : "CARI_LISTE",
                "reqMedicineName" : "Bepanthene Plus 30 g Krem",
                "reqMedicineBarcode" : "8699546355174"
              },{
                "claimId" : "40180290",
                "addOrderNo" : "1",
                "coverCode" : "S659",
                "barcode" : "8699546385492",
                "classDisease4" : "",
                "controlExpiryDate" : "",
                "barcode2d" : "0",
                "barcodeSerialNum" : "",
                "barcodeExpiryDate" : "",
                "barcodeLotNum" : "",
                "breResultCode" : "",
                "locationCode" : "910",
                "dosePeriod" : "0",
                "dose1" : "",
                "dose2" : "",
                "equMedicineApp" : "",
                "dose3" : "",
                "dose3Period" : "",
                "expiryDate" : "",
                "dose4" : "",
                "dose4Period" : "",
                "noteId" : "",
                "itemType" : "ILAC",
                "drgCode" : "",
                "explanation" : "",
                "sfNo" : "1",
                "unit" : "1",
                "price" : "25.94",
                "secondBarcode" : "",
                "statusCode" : "PP",
                "rejectUncheck" : "",
                "rejectUnit" : "",
                "rejectExplanation" : "",
                "secondBarcGiven" : "",
                "timeStamp" : "2019-05-06T11:28:37.000Z",
                "orderNo" : "45-73695815-450001-3",
                "surgeryId" : "",
                "vatRate" : "",
                "seqNo" : "2",
                "processCode" : "13020313",
                "processCodeList" : "CARI_LISTE",
                "reqMedicineName" : "Madecassol 10 mg1 g 40 g Pomad",
                "reqMedicineBarcode" : "8699546385492"
              },{
                "claimId" : "40180290",
                "addOrderNo" : "1",
                "coverCode" : "S659",
                "barcode" : "8699809575158",
                "classDisease4" : "",
                "controlExpiryDate" : "",
                "barcode2d" : "0",
                "barcodeSerialNum" : "",
                "barcodeExpiryDate" : "",
                "barcodeLotNum" : "",
                "breResultCode" : "",
                "locationCode" : "910",
                "dosePeriod" : "0",
                "dose1" : "",
                "dose2" : "",
                "equMedicineApp" : "",
                "dose3" : "",
                "dose3Period" : "",
                "expiryDate" : "",
                "dose4" : "",
                "dose4Period" : "",
                "noteId" : "",
                "itemType" : "ILAC",
                "drgCode" : "",
                "explanation" : "",
                "sfNo" : "1",
                "unit" : "1",
                "price" : "9.34",
                "secondBarcode" : "",
                "statusCode" : "PP",
                "rejectUncheck" : "",
                "rejectUnit" : "",
                "rejectExplanation" : "",
                "secondBarcGiven" : "",
                "timeStamp" : "2019-05-06T11:28:37.000Z",
                "orderNo" : "45-73695815-450001-5",
                "surgeryId" : "",
                "vatRate" : "",
                "seqNo" : "4",
                "processCode" : "50011812",
                "processCodeList" : "CARI_LISTE",
                "reqMedicineName" : "Dolven 100 mg5 ml 100 ml Ped. Surup",
                "reqMedicineBarcode" : "8699809575158"
              },{
                "claimId" : "40180290",
                "addOrderNo" : "1",
                "coverCode" : "S659",
                "barcode" : "8699809756663",
                "classDisease4" : "",
                "controlExpiryDate" : "",
                "barcode2d" : "0",
                "barcodeSerialNum" : "",
                "barcodeExpiryDate" : "",
                "barcodeLotNum" : "",
                "breResultCode" : "",
                "locationCode" : "910",
                "dosePeriod" : "0",
                "dose1" : "",
                "dose2" : "",
                "equMedicineApp" : "",
                "dose3" : "",
                "dose3Period" : "",
                "expiryDate" : "",
                "dose4" : "",
                "dose4Period" : "",
                "noteId" : "",
                "itemType" : "ILAC",
                "drgCode" : "",
                "explanation" : "",
                "sfNo" : "1",
                "unit" : "1",
                "price" : "11.83",
                "secondBarcode" : "",
                "statusCode" : "PP",
                "rejectUncheck" : "",
                "rejectUnit" : "",
                "rejectExplanation" : "",
                "secondBarcGiven" : "",
                "timeStamp" : "2019-05-06T11:28:37.000Z",
                "orderNo" : "45-73695815-450001-6",
                "surgeryId" : "",
                "vatRate" : "",
                "seqNo" : "5",
                "processCode" : "13030145",
                "processCodeList" : "CARI_LISTE",
                "reqMedicineName" : "Rifocin 250 mg3 ml 1 Ampul",
                "reqMedicineBarcode" : "8699809756663"
              },{
                "claimId" : "40180290",
                "addOrderNo" : "1",
                "coverCode" : "S659",
                "barcode" : "8699839960580",
                "classDisease4" : "",
                "controlExpiryDate" : "",
                "barcode2d" : "0",
                "barcodeSerialNum" : "",
                "barcodeExpiryDate" : "",
                "barcodeLotNum" : "",
                "breResultCode" : "",
                "locationCode" : "910",
                "dosePeriod" : "0",
                "dose1" : "",
                "dose2" : "",
                "equMedicineApp" : "",
                "dose3" : "",
                "dose3Period" : "",
                "expiryDate" : "",
                "dose4" : "",
                "dose4Period" : "",
                "noteId" : "",
                "itemType" : "ASI",
                "drgCode" : "",
                "explanation" : "",
                "sfNo" : "1",
                "unit" : "1",
                "price" : "17.26",
                "secondBarcode" : "",
                "statusCode" : "PP",
                "rejectUncheck" : "",
                "rejectUnit" : "",
                "rejectExplanation" : "",
                "secondBarcGiven" : "",
                "timeStamp" : "2019-05-06T11:28:37.000Z",
                "orderNo" : "45-73695815-450001-7",
                "surgeryId" : "",
                "vatRate" : "",
                "seqNo" : "1",
                "processCode" : "61471259",
                "processCodeList" : "CARI_LISTE",
                "reqMedicineName" : "TdVac 0.5 ml IM Enjeksiyon Icin Suspansiyon Iceren Ampul",
                "reqMedicineBarcode" : "8699839960580"
              },{
                "claimId" : "40180290",
                "addOrderNo" : "1",
                "coverCode" : "S659",
                "barcode" : "8699844750633",
                "classDisease4" : "",
                "controlExpiryDate" : "",
                "barcode2d" : "0",
                "barcodeSerialNum" : "",
                "barcodeExpiryDate" : "",
                "barcodeLotNum" : "",
                "breResultCode" : "",
                "locationCode" : "910",
                "dosePeriod" : "0",
                "dose1" : "",
                "dose2" : "",
                "equMedicineApp" : "",
                "dose3" : "",
                "dose3Period" : "",
                "expiryDate" : "",
                "dose4" : "",
                "dose4Period" : "",
                "noteId" : "",
                "itemType" : "ILAC",
                "drgCode" : "",
                "explanation" : "",
                "sfNo" : "1",
                "unit" : "2",
                "price" : "0.72",
                "secondBarcode" : "",
                "statusCode" : "PP",
                "rejectUncheck" : "",
                "rejectUnit" : "",
                "rejectExplanation" : "",
                "secondBarcGiven" : "",
                "timeStamp" : "2019-05-06T11:28:37.000Z",
                "orderNo" : "45-73695815-450001-2",
                "surgeryId" : "",
                "vatRate" : "",
                "seqNo" : "1",
                "processCode" : "61482035",
                "processCodeList" : "CARI_LISTE",
                "reqMedicineName" : "Lidofast 2 ml 20 Ampul",
                "reqMedicineBarcode" : "8699844750633"
              }],
                  "processList": [{
                "claimId" : "40180290",
                "addOrderNo" : "1",
                "breResultCode" : "",
                "coverCode" : "S659",
                "groupNo" : "0",
                "discountGroupCode" : "ASGKM�D",
                "entranceDate" : "2019-05-06T00:00:00.000Z",
                "explanation" : "",
                "drgCode" : "",
                "doctorCode" : "",
                "doctorStatus" : "",
                "diagnosisId" : "",
                "locationCode" : "910",
                "processCodeMain" : "150",
                "processCodeSub1" : "59",
                "processCodeSub2" : "184",
                "indemnityAmount" : "806.53",
                "processGroup" : "DEAT",
                "processCount" : "1",
                "instIndemnityAmount" : "865.07",
                "orderNo" : "45-73695815-450001-8",
                "procType" : "",
                "physiotherapySession" : "",
                "processDate" : "",
                "sfNo" : "1",
                "userId" : "SKR500204",
                "statusCode" : "PP",
                "swiftCode" : "",
                "timeStamp" : "2019-05-06T11:28:37.000Z",
                "sgkAmount" : "",
                "vatRate" : "",
                "rightLeft" : "HICBIRI",
                "surgeryId" : "",
                "seqNo" : "1",
                "reqProcessName" : "'||v_process_name||'",
                "reqProcessCode" : "150_59_184",
                "reqProcessListType" : "DIGER",
                "relatedProcess" : "",
                "relatedProcessListType" : ""
              }],
                  "provisionList": [{
                "daySeance" : "0",
                "exemptionAmount" : "0",
                "entryDate" : "2019-05-06T11:27:31.000Z",
                "countryCode" : "",
                "exemptionRate" : "0",
                "addOrderNo" : "1",
                "addProcAmount" : "0",
                "doctorCode" : "",
                "doctorStatus" : "",
                "breResultCode" : "",
                "coverDistributionAmount" : "0",
                "claimId" : "40180290",
                "coverCode" : "S659",
                "isExGratia" : "0",
                "isPoolCover" : "0",
                "isSpecialCover" : "0",
                "procRequestAmount" : "806.53",
                "procRefusalAmount" : "0",
                "instExemptionAmount" : "0",
                "instRequestAmount" : "1011.35",
                "provDateTime" : "2019-05-06T11:27:31.000Z",
                "orderNo" : "",
                "instAddProcAmount" : "0",
                "locationCode" : "910",
                "provisionTotal" : "1011.35",
                "provisionExplanation" : "gfdfg",
                "requestAmount" : "1011.35",
                "refusalAmount" : "0",
                "swiftCode" : "TL",
                "reqCureDayCount" : "0",
                "statusCode" : "PP",
                "userId" : "SKR500204",
                "sysRequestAmount" : "1011.35",
                "sgkAmount" : "0",
                "timeStamp" : "",
                "subPackageId" : "",
                "subPackageDate" : "",
                "sfNo" : "1"
              }],
                  "rejectLossList": [],
                  "vaccineList" : []
               }
          }';
       
       /*v_hltprv_Log.Log_Id := NULL;
       v_hltprv_Log.Servicename := 'HCLM_TEST';
       v_hltprv_Log.Processinfo := v_url;
       v_hltprv_Log.Note        := 'Request';
       v_hltprv_Log.Content     := v_request;
       v_hltprv_Log.Institutecode := v_institute_code;   
       v_hltprv_Log.Savelogwithpragma;*/
       
       CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.
       callRestService(v_url, 'POST', v_request, v_response, v_status, v_message);
       DBMS_OUTPUT.PUT_LINE(v_response);
      /* v_hltprv_Log.Servicename := 'HCLM_TEST';
       v_hltprv_Log.Processinfo := v_url;
       v_hltprv_Log.Note        := 'Response';
       v_hltprv_Log.Content     := v_response||v_status||v_message;
       v_hltprv_Log.Institutecode := v_institute_code;
       v_hltprv_Log.Savelogwithpragma;*/
       --DBMS_OUTPUT.PUT_LINE('resp:'||v_response);
       --v_response := TRIM(regexp_replace(v_response, '([^[:graph:] | ^[:blank:]])', ''));  
       IF v_status = 0 THEN
           v_ndx1 := INSTR(v_response,'{"claimDetailDto" : {');
           v_ndx2 := INSTR(v_response,',"provisionList"') - v_ndx1;         
           v_response := SUBSTR(v_response, v_ndx1+21, v_ndx2-21);          
       ELSE 
           v_ndx1 := INSTR(v_response,'{"errors" : [');
           v_ndx2 := INSTR(v_response,'],"warnings"') - v_ndx1;           
           v_response := SUBSTR(v_response, v_ndx1+15, v_ndx2-17);           
       END IF;
       FOR rec IN (SELECT TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1) , '"',''))   KEY, 
                          TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1, 2), '"','')) VALUE              
                     FROM (SELECT Regexp_Substr (v_response, '[^,]+', 1, LEVEL) ELEMENT
                             FROM Dual
                          CONNECT BY LEVEL <= LENGTH (Regexp_Replace (v_response, '[^,]+')) + 1)) LOOP           
           IF rec.KEY IN('extReference','message') THEN
                v_message := rec.value;
           END IF;
       END LOOP;
       IF v_status = 1 THEN 
           Raise_Application_Error(-20200,  v_message);
       END IF; 
       DBMS_OUTPUT.PUT_LINE('SUCCESS:'||v_message);
EXCEPTION WHEN OTHERS THEN
  
   v_message := SQLERRM;
   /*v_message := v_message || dbms_utility.format_error_stack || dbms_utility.format_error_backtrace;
        v_hltprv_Log.Servicename := 'ALZ_HCLM_CONVERTER_UTILS';
        v_hltprv_Log.Processinfo := v_url;
        v_hltprv_Log.Note        := 'PROVISION_EXCEPTION';
        v_hltprv_Log.Content     := v_message;
        v_hltprv_Log.Institutecode := v_institute_code;
        v_hltprv_Log.Savelogwithpragma;*/
        --Raise_Application_Error(-20200,  'Provizyon S�ras�nda Beklenmedik Bir Hata Olu�tu:'||v_hltprv_Log.Log_Id);      
   DBMS_OUTPUT.PUT_LINE('FAIL:'||v_message);
END;
