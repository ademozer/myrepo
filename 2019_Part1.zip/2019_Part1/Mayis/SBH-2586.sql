DECLARE 
  Pinstitutecode     NUMBER := 813;
  Pspecialtysubject  VARCHAR2(100) := '1010';
  Pnamesurname       VARCHAR2(100) := 'enes uysal';
  Pidentityno        VARCHAR2(100) := NULL;
  Pdiplomano         VARCHAR2(100) := NULL;
  Pdoctor            Koc_Cc_Web_Inst_Doctor%ROWTYPE;
PROCEDURE Finddoctor(Pinstitutecode    IN NUMBER,
                                             Pspecialtysubject IN VARCHAR2,
                                             Pnamesurname      IN VARCHAR2,
                                             Pidentityno       IN VARCHAR2,
                                             Pdiplomano        IN VARCHAR2,
                                             Pdoctor           OUT Koc_Cc_Web_Inst_Doctor%ROWTYPE) IS
        /*SBH-2180
          CURSOR Crdoctorbyidentity IS
            SELECT *
                FROM Koc_Cc_Web_Inst_Doctor
             WHERE Institute_Code = Pinstitutecode
                 AND Specialty_Subject = Pspecialtysubject
                 AND Doctor_Identity_No = Pidentityno
                 AND Pidentityno IS NOT NULL
                 AND Validity_End_Date IS NULL
            UNION ALL
            SELECT *
                FROM Hst_Cc_Web_Inst_Doctor
             WHERE Institute_Code = Pinstitutecode
                 AND Specialty_Subject = Pspecialtysubject
                 AND Doctor_Identity_No = Pidentityno
                 AND Pidentityno IS NOT NULL
                 AND Validity_End_Date IS NULL;*/
           --SBH-2180
         CURSOR Crdoctorbyidentity_mnw IS
            SELECT *
                FROM Koc_Cc_Web_Inst_Doctor
             WHERE Institute_Code = Pinstitutecode
                 AND Specialty_Subject = Pspecialtysubject
                 AND Doctor_Identity_No = Pidentityno
                 AND Pidentityno IS NOT NULL
                 AND Validity_End_Date IS NULL;
         --SBH-2180
         CURSOR Crdoctorbyidentity_hst IS
            SELECT *
                FROM Hst_Cc_Web_Inst_Doctor
             WHERE Institute_Code = Pinstitutecode
                 AND Specialty_Subject = Pspecialtysubject
                 AND Doctor_Identity_No = Pidentityno
                 AND Pidentityno IS NOT NULL
                 AND Validity_End_Date IS NULL;

        CURSOR Crdoctorbydiploma IS
            SELECT *
                FROM Koc_Cc_Web_Inst_Doctor
             WHERE Institute_Code = Pinstitutecode
                 AND Specialty_Subject = Pspecialtysubject
                 AND Doctor_Certificate_Number = Pdiplomano
                 AND Pdiplomano IS NOT NULL
                 AND Validity_End_Date IS NULL
            UNION ALL
            SELECT *
                FROM Hst_Cc_Web_Inst_Doctor
             WHERE Institute_Code = Pinstitutecode
                 AND Specialty_Subject = Pspecialtysubject
                 AND Doctor_Certificate_Number = Pdiplomano
                 AND Pdiplomano IS NOT NULL
                 AND Validity_End_Date IS NULL;

        CURSOR Crdoctorbynamesurname IS
            SELECT *
                FROM Koc_Cc_Web_Inst_Doctor
             WHERE Institute_Code = Pinstitutecode
                 AND Specialty_Subject = Pspecialtysubject
                 AND UPPER(Doctor_Name || ' ' || Doctor_Surname) = UPPER(Pnamesurname)
                 AND Pnamesurname IS NOT NULL
                 AND Validity_End_Date IS NULL
            UNION ALL
            SELECT *
                FROM Hst_Cc_Web_Inst_Doctor
             WHERE Institute_Code = Pinstitutecode
                 AND Specialty_Subject = Pspecialtysubject
                 AND UPPER(Doctor_Name || ' ' || Doctor_Surname) = UPPER(Pnamesurname)
                -- AND Doctor_Name || ' ' || Doctor_Surname = Pnamesurname
                 AND Pnamesurname IS NOT NULL
                 AND Validity_End_Date IS NULL;

        Vdoctor Koc_Cc_Web_Inst_Doctor%ROWTYPE;
    BEGIN
        IF Pnamesurname IS NULL AND
             Pidentityno IS NULL AND
             Pdiplomano IS NULL AND
             Pspecialtysubject IS NULL
        THEN
            RETURN;
        ELSE
            IF Vdoctor.Doctor_Code IS NULL
            THEN
                IF Pidentityno IS NOT NULL
                THEN
                  /* SBH-2180
                    OPEN Crdoctorbyidentity;

                    FETCH Crdoctorbyidentity    INTO Vdoctor;

                    CLOSE Crdoctorbyidentity;*/
                   --SBH-2180
                   OPEN Crdoctorbyidentity_mnw;
                   FETCH Crdoctorbyidentity_mnw    INTO Vdoctor;
                   CLOSE Crdoctorbyidentity_mnw;
                   IF Vdoctor.Doctor_Code IS NULL
                   THEN
                     OPEN Crdoctorbyidentity_hst;
                     FETCH Crdoctorbyidentity_hst    INTO Vdoctor;
                     CLOSE Crdoctorbyidentity_hst;
                   END IF ;
                   --SBH-2180
                END IF;
            END IF;
            /* SBH-2082 - WS den gelen taleplerde diploma noya g�re dr bilgilerinin bulunmas�n�n �nlenmesi
            IF Vdoctor.Doctor_Code IS NULL
            THEN
                IF Pdiplomano IS NOT NULL
                THEN
                    OPEN Crdoctorbydiploma;

                    FETCH Crdoctorbydiploma
                        INTO Vdoctor;

                    CLOSE Crdoctorbydiploma;
                END IF;
            END IF;
            */
            IF Vdoctor.Doctor_Code IS NULL
            THEN
                IF Pnamesurname IS NOT NULL
                THEN
                    OPEN Crdoctorbynamesurname;

                    FETCH Crdoctorbynamesurname
                        INTO Vdoctor;

                    CLOSE Crdoctorbynamesurname;
                END IF;
            END IF;
        END IF;

        Pdoctor := Vdoctor;
    END finddoctor;
    BEGIN
        finddoctor(Pinstitutecode,
                                             Pspecialtysubject,
                                             Pnamesurname,
                                             Pidentityno,
                                             Pdiplomano,
                                             Pdoctor);
         DBMS_OUTPUT.PUT_LINE('Doktor Identity_No='||Pdoctor.DOCTOR_IDENTITY_NO);  
         DBMS_OUTPUT.PUT_LINE('Doktor Ad Soyad='||Pdoctor.Doctor_Name || ' - ' || Pdoctor.Doctor_Surname);       
         DBMS_OUTPUT.PUT_LINE('Doktor Kodu='||Pdoctor.Doctor_Code);                                         
    END;
