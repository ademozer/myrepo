DECLARE
   v_term   date;
   p_year   number := 2019;  
   p_month  number := 5;
   p_institute_code number := 1657;--1901;
   v_payment_group_code VARCHAR2(10);
   v_is_current_term     number := 0;
   v_start_date          date;
   v_end_date            date;
   v_pay_term            date;
   v_term_str            varchar2(6);
   v_prev_term_str       varchar2(6);
   p_is_tss NUMBER := 10;
BEGIN
   v_term := last_day (to_date ('01' || lpad (to_char (p_month), 2, '0') || to_char (p_year), 'DDMMYYYY'));
   dbms_output.put_line('v_term:'||v_term);
  
   v_payment_group_code  := '2';-- koc_clm_hlth_utils.getpaymentgroup (p_institute_code, v_term);
   dbms_output.put_line('v_payment_group_code:' || v_payment_group_code);
   
   v_term_str :=  TO_CHAR(p_year)||lpad (to_char (p_month), 2, '0');
   --v_prev_term_str :=  TO_CHAR(p_year)||lpad (to_char (p_month-1), 2, '0');
    IF p_month = 1 THEN
           v_prev_term_str :=  TO_CHAR(p_year-1)||'12';
       ELSE  
           v_prev_term_str :=  TO_CHAR(p_year)||lpad (to_char (p_month-1), 2, '0');
       END IF;
   dbms_output.put_line('v_term_str:'||v_term_str);
   dbms_output.put_line('v_prev_tern:'||v_prev_term_str);
      /* IF TO_CHAR(SYSDATE,'YYYYMM') = v_term_str THEN
           v_is_current_term := 1;
       END IF;*/
       IF p_is_tss IN (0, 10) THEN
           /*koc_clm_hlth_utils.getPaymentDate (trunc(sysdate), v_payment_group_code ,v_end_date, v_pay_term );
           koc_clm_hlth_utils.getPrvConfirmDate (v_payment_group_code ,v_end_date, v_start_date );
           v_start_date := v_start_date + 1;*/
            SELECT MAX(confirmation_date) + 1 prev_confirmation_date               
              INTO v_start_date
              FROM KOC_CC_MONTH_CONFIRM_DATES a
             WHERE TO_CHAR (a.payment_date, 'YYYYMM') = v_prev_term_str
               AND a.payment_group_code = v_payment_group_code;
            
            SELECT MIN(confirmation_date) confirmation_date               
              INTO v_end_date
              FROM KOC_CC_MONTH_CONFIRM_DATES a
             WHERE TO_CHAR (a.payment_date, 'YYYYMM') = v_term_str
               AND a.payment_group_code = v_payment_group_code;
          
       ELSIF p_is_tss = 11 THEN
           SELECT MIN(confirmation_date) + 1 prev_confirmation_date,
                  MAX(confirmation_date) confirmation_date
             INTO v_start_date, v_end_date
             FROM KOC_CC_MONTH_CONFIRM_DATES a
            WHERE TO_CHAR (a.payment_date, 'YYYYMM') = v_term_str
              AND a.payment_group_code = v_payment_group_code;
       END IF;
       
       IF SYSDATE BETWEEN v_start_date AND v_end_date THEN
            v_is_current_term := 1;
       END IF;
   dbms_output.put_line('v_pay_term:'||v_pay_term);
        
   dbms_output.put_line('v_start_date:'||v_start_date);
   
   dbms_output.put_line('v_end_date:'||v_end_date);
   
   dbms_output.put_line('v_is_current_term:'||v_is_current_term);
END;
 

 
