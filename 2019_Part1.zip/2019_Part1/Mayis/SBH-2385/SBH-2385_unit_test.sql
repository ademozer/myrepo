DECLARE 
  p_balance_list           KOC_CLM_HLTH_PHARMACY_UTILS.rc;
 p_transfer_detail         KOC_CLM_HLTH_PHARMACY_UTILS.rc;
 p_stoppage_amount         number;
 p_cutoff_piece_amount     number;
 TYPE balance_rec IS RECORD(
   invoice_date DATE,
   invoice_no   NUMBER,
   insured_name VARCHAR2(200),
   description  VARCHAR2(400),
   ext_reference VARCHAR2(10),
   debit NUMBER,
   credit NUMBER,
   stoppage_amount NUMBER,
   az_invoice_no NUMBER,
   az_invoice_date DATE,
   invoice_status_type NUMBER,
   uu_id VARCHAR2(100),
   profile_id NUMBER 
 );
 
 v_balance balance_rec;
 
 procedure get_balance_payment_list(p_institute_code         in number,
                                       p_month                  in number,
                                       p_year                   in number,
                                       p_is_tss                 in number default 0,
                                       p_balance_list           out KOC_CLM_HLTH_PHARMACY_UTILS.rc,
                                       p_transfer_detail        out KOC_CLM_HLTH_PHARMACY_UTILS.rc,
                                       p_stoppage_amount        out number,
                                       p_cutoff_piece_amount    out number) is

       v_payment_group_code  koc_clm_hlth_inst_trans.payment_group_code%type;
       v_term                date;
       v_stoppage_amount     number;
       v_cutoff_piece_amount number;
       v_current_term        number := 0; --ademo.SBH-2385
       v_start_date          date;
       v_end_date            date;
       v_pay_term            date;
       v_term_str            varchar2(6); 
       v_is_tss              NUMBER;
    begin
     
       v_term := last_day (to_date ('01' || lpad (to_char (p_month), 2, '0') || to_char (p_year), 'DDMMYYYY'));

       if nvl (p_is_tss, 0) = 0 then
          v_payment_group_code := koc_clm_hlth_utils.getpaymentgroup (p_institute_code, v_term);
       else
          v_payment_group_code := koc_clm_hlth_pharmacy_utils.gettsspaymentgroup (p_institute_code, v_term);
       end if;
       --[ademo.SBH-2385
       v_term_str :=  TO_CHAR(p_year)||lpad (to_char (p_month), 2, '0');       
       IF TO_CHAR(SYSDATE,'YYYYMM') = v_term_str THEN
           v_current_term := 1;
       END IF;
       
       IF p_is_tss IN (0,10) THEN
            koc_clm_hlth_utils.getPaymentDate (trunc(sysdate), v_payment_group_code ,v_end_date, v_pay_term );    
            koc_clm_hlth_utils.getPrvConfirmDate (v_payment_group_code ,v_end_date, v_start_date );
            v_start_date := v_start_date + 1;                   
       ELSIF p_is_tss = 11 THEN   
            dbms_output.put_line('term_str:'||v_term_str||':'||v_payment_group_code);               
            SELECT MIN(confirmation_date) + 1 prev_confirmation_date,
                   MAX(confirmation_date) confirmation_date
              INTO v_start_date, v_end_date
              FROM KOC_CC_MONTH_CONFIRM_DATES a
             WHERE TO_CHAR (a.payment_date, 'YYYYMM') = v_term_str
              AND a.payment_group_code = v_payment_group_code;                                             
       END IF;
       v_is_tss := CASE p_is_tss WHEN 0 THEN 0 ELSE 1 END;
       --v_start_date := TO_DATE('10/04/2019','DD/MM/YYYY');
       --v_end_date := TO_DATE('11/04/2019','DD/MM/YYYY');
       dbms_output.put_line('tarih1:'||v_start_date);
       dbms_output.put_line('tarih2:'||v_end_date);
       dbms_output.put_line('v_is_tss:'||v_is_tss);       
       --ademo]
       IF v_current_term = 0 THEN 
           open p_balance_list for
           select invoice_date,
                  invoice_no,
                  insured_name,
                  description,
                  ext_reference,
                  debit,
                  credit,
                  stoppage_amount,
                  az_invoice_no,
                  az_invoice_date,
                  invoice_status_type,
                  uu_id,
                  profile_id
             from (select hd.invoice_date,
                          hd.invoice_no,
                          cp.first_name || ' ' || cp.surname insured_name,
                          tr.description,
                          hd.ext_reference,
                          te.ticket_no,
                          sum(decode(tr.sign, -1, (nvl (ct.trans_amt, 0) - nvl (te.stoppage_amount, 0)) * nvl (te.currency_exchange_rate, 1), 0)) debit,
                          sum(decode(tr.sign, 1, (nvl (ct.trans_amt, 0) - nvl (te.stoppage_amount, 0)) * nvl (te.currency_exchange_rate, 1), 0)) credit,
                          sum(nvl (te.stoppage_amount, 0) * nvl (te.currency_exchange_rate, 1)) as stoppage_amount,
                          null as az_invoice_no,
                          null as az_invoice_date,
                          null as invoice_status_type,
                          null as uu_id,
                          null as profile_id
                     from koc_clm_hlth_inst_trans hit,
                          koc_clm_trans_ext te,
                          clm_trans ct,
                          koc_clm_hlth_detail hd,
                          koc_cc_inst_trans_ref tr,
                          cp_partners cp
                    where hit.inst_ext_id = te.inst_ext_id
                      and hit.payment_group_code = v_payment_group_code
                      and hit.institute_code = p_institute_code
                      and hit.pay_month = p_month
                      and hit.pay_year = p_year
                      and NVL(hit.batch_date, hit.trans_date) >= v_start_date
                      and NVL(hit.batch_date, hit.trans_date) <= v_end_date    
                      and hit.trans_type in (1, 21)
                      and te.claim_id = ct.claim_id
                      and te.sf_no = ct.sf_no
                      and te.trans_no = ct.trans_no
                      and ct.sf_total_type in (11, 12)
                      and hd.claim_id = te.claim_id
                      and hd.sf_no = te.sf_no
                      and hd.add_order_no = te.add_order_no
                      and hd.part_id = cp.part_id
                      and hit.trans_type = tr.trans_type
                      and rownum<3
                    group by hd.invoice_date,
                             hd.invoice_no,
                             cp.first_name || ' ' || cp.surname,
                             description,
                             hd.ext_reference,
                             te.ticket_no,
                             null,
                             null,
                             null,
                             null,
                             null
                    union all
                   select hd.invoice_date,
                          hd.invoice_no,
                          cp.first_name || ' ' || cp.surname insured_name,
                          tr.description,
                          hd.ext_reference,
                          null as ticket_no,
                          sum(hit.trans_amount) debit,
                          0 as credit,
                          null as stoppage_amount,
                          im.invoiceid as az_invoice_no,
                          im.issuedate as az_invoice_date,
                          ime.invoice_status_type as invoice_status_type,
                          im.uuid as uu_id,
                          im.profileid as profile_id
                     from koc_clm_hlth_inst_trans hit,
                          koc_clm_hlth_detail hd,
                          koc_cc_inst_trans_ref tr,
                          alz_invoice_master im,
                          alz_invoice_master_ext ime,
                          cp_partners cp
                    where hit.payment_group_code = v_payment_group_code
                      and hit.institute_code = p_institute_code
                      and hit.pay_month = p_month
                      and hit.pay_year = p_year
                      and NVL(hit.batch_date, hit.trans_date) >= v_start_date
                      and NVL(hit.batch_date, hit.trans_date) <= v_end_date    
                      and hit.trans_type in (2, 3, 4, 33, 51)
                      and hit.claim_id = hd.claim_id(+)
                      and hit.sf_no = hd.sf_no(+)
                      and hit.add_order_no = hd.add_order_no(+)
                      and hit.trans_type = tr.trans_type
                      and im.idx = ime.idx
                      and hit.batch_id = ime.acc_batch_id
                      and hd.part_id = cp.part_id(+)
                      and rownum<3
                    group by hd.invoice_date,
                             hd.invoice_no,
                             cp.first_name || ' ' || cp.surname,
                             tr.description,
                             hd.ext_reference,
                             null,
                             im.invoiceid,
                             im.issuedate,
                             ime.invoice_status_type,
                             im.uuid,
                             im.profileid
                   union all
                  select hd.invoice_date,
                         hd.invoice_no,
                         cp.first_name || ' ' || cp.surname insured_name,
                         tr.description,
                         hd.ext_reference,
                         null as ticket_no,
                         0 debit,
                         sum(hit.trans_amount) as credit,
                         null as stoppage_amount,
                         null as az_invoice_no,
                         null as az_invoice_date,
                         null as invoice_status_type,
                         null as uu_id,
                         null as profile_id
                    from koc_clm_hlth_inst_trans hit,
                         koc_clm_hlth_detail hd,
                         koc_cc_inst_trans_ref tr,
                         cp_partners cp
                   where hit.payment_group_code = v_payment_group_code
                     and hit.institute_code = p_institute_code
                     and hit.pay_month = p_month
                     and hit.pay_year = p_year
                     and NVL(hit.batch_date, hit.trans_date) >= v_start_date
                     and NVL(hit.batch_date, hit.trans_date) <= v_end_date    
                     and hit.trans_type in (5, 10, 11, 34, 52)
                     and hd.claim_id = hit.claim_id(+)
                     and hd.sf_no = hit.sf_no(+)
                     and hd.add_order_no = hit.add_order_no(+)
                     and hit.trans_type = tr.trans_type
                     and hd.part_id = cp.part_id(+)
                     and rownum<3
                   group by hd.invoice_date,
                            hd.invoice_no,
                            cp.first_name || ' ' || cp.surname,
                            description,
                            hd.ext_reference,
                            null,
                            null,
                            null,
                            null,
                            null,
                            null);                         
        ELSE
            
             open p_balance_list for
           select invoice_date,
                  invoice_no,
                  insured_name,
                  description,
                  ext_reference,
                  debit,
                  credit,
                  stoppage_amount,
                  null as az_invoice_no,
                      null as az_invoice_date,
                      null as invoice_status_type,
                      null as uu_id,
                      null as profile_id
            FROM (SELECT  det.invoice_date
                      ,det.invoice_no
                      ,KOC_CLM_HLTH_UTILS.Getpartnernamebypartid(det.part_id) insured_name 
                      ,DECODE(a.sf_total_type,'11','Tahakkuk','12','Tahakkuk �ptali','') description 
                      ,det.ext_reference ext_reference               
                      ,b.ticket_no      
                      ,SUM(DECODE(a.sf_total_type,'11',1,0)*(NVL(a.trans_amt,0)-NVL(b.stoppage_amount,0))*NVL(b.currency_exchange_rate,1)) credit
                      ,SUM(DECODE(a.sf_total_type,'12',1,0)*(NVL(a.trans_amt,0)-NVL(b.stoppage_amount,0))*NVL(b.currency_exchange_rate,1)) debit
                      ,sum(nvl (b.stoppage_amount, 0) * nvl (b.currency_exchange_rate, 1)) as stoppage_amount                     
                  FROM koc_clm_trans_ext b
                      ,clm_trans a                     
                      ,koc_clm_hlth_detail det
                 WHERE b.ticket_date >= v_start_date
                   AND b.ticket_date <= v_end_date
                   AND b.payment_type = '7'
                   AND a.claim_id = b.claim_id
                   AND a.sf_no = b.sf_no
                   AND a.trans_no = b.trans_no  
                   AND a.sf_total_type IN ('11','12')                
                   AND det.claim_id = b.claim_id
                   AND det.sf_no = b.sf_no
                   AND det.add_order_no = b.add_order_no   
                   AND det.institute_code = p_institute_code                  
                   AND NVL(det.is_complementary,0) = v_is_tss
                   AND det.ext_reference = '56646553'
               GROUP BY det.invoice_date
                      ,det.invoice_no
                      ,det.part_id          
                      ,a.sf_total_type
                      ,det.ext_reference                
                      ,b.ticket_no
                UNION
               select hd.invoice_date,
                       hd.invoice_no,
                       KOC_CLM_HLTH_UTILS.Getpartnernamebypartid(hd.part_id) insured_name, 
                       tr.description,
                       hd.ext_reference,
                       null as ticket_no,
                       0 debit,
                       sum(hit.trans_amount) as credit,
                       null as stoppage_amount                      
                  from koc_clm_hlth_inst_trans hit,
                       koc_clm_hlth_detail hd,
                       koc_cc_inst_trans_ref tr
                 where hit.payment_group_code = v_payment_group_code
                   and hit.institute_code = p_institute_code
                   and hit.pay_month = p_month
                   and hit.pay_year = p_year         
                   and NVL(hit.batch_date, hit.trans_date) >= v_start_date
                   and NVL(hit.batch_date, hit.trans_date) <= v_end_date             
                   AND hit.trans_type NOT IN (1,21,31,32,18) 
                   and hd.claim_id = hit.claim_id(+)
                   and hd.sf_no = hit.sf_no(+)
                   and hd.add_order_no = hit.add_order_no(+)
                   and hit.trans_type = tr.trans_type  
                   and hd.is_complementary = v_is_tss                         
                 group by hd.invoice_date,
                          hd.invoice_no,
                          hd.part_id,
                          tr.description,
                          hd.ext_reference
                              
            );        
                    
        END IF;     
       open p_transfer_detail for
       select hit.trans_date payment_date,
              sum(hit.trans_amount) payment_amount
         from koc_clm_hlth_inst_trans hit
        where hit.payment_group_code = v_payment_group_code
          and hit.institute_code = p_institute_code
          and hit.firm = '0'
          and hit.pay_month = p_month
          and hit.pay_year = p_year
          and hit.trans_type = 18
          and not exists(select 1
                           from koc_clm_hlth_inst_trans itr
                          where itr.payment_ref_id = hit.payment_ref_id
                            and itr.trans_type in (30, 50)
                            and itr.confirm_rem_id is null)
        group by hit.trans_date
        order by hit.trans_date asc;

       if (v_payment_group_code = '5') then
         select nvl(sum(te.stoppage_amount * nvl(te.currency_exchange_rate, 1)),0) stoppage_amount
           into p_stoppage_amount
           from koc_clm_hlth_inst_trans hit,
                koc_clm_trans_ext te,
                clm_trans ct
          where hit.payment_group_code = v_payment_group_code
            and hit.institute_code = p_institute_code
            and hit.firm = '0'
            and hit.pay_month = p_month
            and hit.pay_year = p_year
            and hit.trans_type in (1, 21)
            and te.inst_ext_id = hit.inst_ext_id
            and te.claim_id = ct.claim_id
            and te.sf_no = ct.sf_no
            and te.trans_no = ct.trans_no;
       end if;

       select nvl(sum(decode(itr.sign, -1, nvl(hit.trans_amount, 0), 0)),0) -
              nvl(sum(decode(itr.trans_type, 21, nvl(hit.trans_amount, 0), 0)), 0) cutoff_piece_amount
         into p_cutoff_piece_amount
         from koc_clm_hlth_inst_trans hit,
              koc_cc_inst_trans_ref itr
        where hit.trans_type = itr.trans_type
          and hit.payment_group_code = v_payment_group_code
          and hit.institute_code = p_institute_code
          and hit.firm = '0'
          and hit.pay_month = p_month
          and hit.pay_year = p_year
          and hit.trans_type not in (18, 28, 31, 32, 35, 36);

    end get_balance_payment_list;
    -- engine 16012019 HRCL2-494
    
    procedure print_cursor(p_cur IN  KOC_CLM_HLTH_PHARMACY_UTILS.rc) IS 
      v_data_msg CLOB;
      v_ndx NUMBER;
      v_keys_data VARCHAR2(32000);
    BEGIN
        v_data_msg := '{"data":[';
        FOR rec_1 IN (SELECT ROWNUM ROW_NO, 
                                      t1.column_value.getStringVal() ROW_DATA
                                 FROM (SELECT * FROM TABLE (XMLSEQUENCE(p_cur))) t1)    
                 LOOP                   
                     IF rec_1.ROW_NO>1 THEN
                         v_data_msg := v_data_msg || ',';
                     END IF;
                     v_data_msg := v_data_msg || '{';
                     v_ndx := 0;
                     FOR rec_2 IN (SELECT EXTRACTVALUE (t.COLUMN_VALUE, '/*') AS NODE_VALUE,
                                                        t.COLUMN_VALUE.getrootelement () AS NODE_NAME
                                     FROM TABLE (XMLSEQUENCE (EXTRACT(EXTRACT(XMLTYPE(rec_1.ROW_DATA), '//*'), '/ROW/*'))) t)
                     LOOP
                        IF v_ndx>0 THEN
                           v_data_msg := v_data_msg || ',';
               IF rec_1.ROW_NO = 1 THEN
                v_keys_data := v_keys_data || ',';
               END IF;
                        END IF;
            IF rec_1.ROW_NO = 1 THEN
              v_keys_data := v_keys_data || LOWER(rec_2.NODE_NAME);
            END IF;
                        v_data_msg := v_data_msg || '"' || LOWER(rec_2.NODE_NAME) || '":"' || TRIM(rec_2.Node_Value) || '"';
                        v_ndx := v_ndx + 1;                         
                     END LOOP;
                     v_data_msg := v_data_msg || '}';
                 END LOOP;   
          v_data_msg := v_data_msg||']}';
          DBMS_OUTPUT.PUT_LINE(v_data_msg);
    END print_cursor; 
 BEGIN
     get_balance_payment_list(1657,
                              4,
                              2019,
                              11,
                               p_balance_list,
                               p_transfer_detail,
                               p_stoppage_amount,
                               p_cutoff_piece_amount);
                                       
    print_cursor(p_balance_list);
                                           
 END;
