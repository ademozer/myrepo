select hd.invoice_date,
                        hd.invoice_no,
                        cp.first_name || ' ' || cp.surname insured_name,
                        tr.description,
                        hd.ext_reference,
                        te.ticket_no,
                        te.ticket_date,
                        hit.trans_date,
                        sum(decode(tr.sign, -1, (nvl (ct.trans_amt, 0) - nvl (te.stoppage_amount, 0)) * nvl (te.currency_exchange_rate, 1), 0)) debit,
                        sum(decode(tr.sign, 1, (nvl (ct.trans_amt, 0) - nvl (te.stoppage_amount, 0)) * nvl (te.currency_exchange_rate, 1), 0)) credit,
                        sum(nvl (te.stoppage_amount, 0) * nvl (te.currency_exchange_rate, 1)) as stoppage_amount,
                        null as az_invoice_no,
                        null as az_invoice_date,
                        null as invoice_status_type,
                        null as uu_id,
                        null as profile_id
                   from koc_clm_hlth_inst_trans hit,
                        koc_clm_trans_ext te,
                        clm_trans ct,
                        koc_clm_hlth_detail hd,
                        koc_cc_inst_trans_ref tr,
                        cp_partners cp
                  where hit.inst_ext_id = te.inst_ext_id
                    and hit.payment_group_code = 'T1'
                    and hit.institute_code = 1657
                    and hit.pay_month = 5
                    and hit.pay_year = 2019
                    and te.ticket_date >= TO_DATE('29/04/2019','DD/MM/YYYY') --ademo.SBH-2385
                    and te.ticket_date <= TO_DATE('13/05/2019','DD/MM/YYYY')   --ademo.SBH-2385
                    and hit.trans_type in (1, 21)
                    and te.claim_id = ct.claim_id
                    and te.sf_no = ct.sf_no
                    and te.trans_no = ct.trans_no
                    and ct.sf_total_type in (11, 12)
                    and hd.claim_id = te.claim_id
                    and hd.sf_no = te.sf_no
                    and hd.add_order_no = te.add_order_no
                    and hd.part_id = cp.part_id
                    and hit.trans_type = tr.trans_type
                    and hd.ext_reference = 56578017
                    group by hd.invoice_date,
                           hd.invoice_no,
                           cp.first_name || ' ' || cp.surname,
                           description,
                           hd.ext_reference,
                           te.ticket_no,
                           te.ticket_date,
                           hit.trans_date,
                           null,
                           null,
                           null,
                           null,
                           null
