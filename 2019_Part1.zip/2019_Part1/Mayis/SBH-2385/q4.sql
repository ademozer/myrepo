--select koc_clm_hlth_utils.getpaymentgroup (3311, '30042019') from dual      

 select invoice_date,
              invoice_no,
              insured_name,
              description,
              ext_reference,
              debit,
              credit,
              stoppage_amount,
              az_invoice_no,
              az_invoice_date,
              invoice_status_type,
              uu_id,
              profile_id
         from (select hd.invoice_date,
                      hd.invoice_no,
                      cp.first_name || ' ' || cp.surname insured_name,
                      tr.description,
                      hd.ext_reference,
                      te.ticket_no,
                      sum(decode(tr.sign, -1, (nvl (ct.trans_amt, 0) - nvl (te.stoppage_amount, 0)) * nvl (te.currency_exchange_rate, 1), 0)) debit,
                      sum(decode(tr.sign, 1, (nvl (ct.trans_amt, 0) - nvl (te.stoppage_amount, 0)) * nvl (te.currency_exchange_rate, 1), 0)) credit,
                      sum(nvl (te.stoppage_amount, 0) * nvl (te.currency_exchange_rate, 1)) as stoppage_amount,
                      null as az_invoice_no,
                      null as az_invoice_date,
                      null as invoice_status_type,
                      null as uu_id,
                      null as profile_id
                 from koc_clm_hlth_inst_trans hit,
                      koc_clm_trans_ext te,
                      clm_trans ct,
                      koc_clm_hlth_detail hd,
                      koc_cc_inst_trans_ref tr,
                      cp_partners cp
                where hit.inst_ext_id = te.inst_ext_id
                  and hit.payment_group_code = 2
                  and hit.institute_code = 3311
                  and hit.pay_month = 5
                  and hit.pay_year = 2019
                  and hit.trans_type in (1, 21)
                  and te.claim_id = ct.claim_id
                  and te.sf_no = ct.sf_no
                  and te.trans_no = ct.trans_no
                  and ct.sf_total_type in (11, 12)
                  and hd.claim_id = te.claim_id
                  and hd.sf_no = te.sf_no
                  and hd.add_order_no = te.add_order_no
                  and hd.part_id = cp.part_id
                  and hit.trans_type = tr.trans_type
                group by hd.invoice_date,
                         hd.invoice_no,
                         cp.first_name || ' ' || cp.surname,
                         description,
                         hd.ext_reference,
                         te.ticket_no,
                         null,
                         null,
                         null,
                         null,
                         null
                union all
               select hd.invoice_date,
                      hd.invoice_no,
                      cp.first_name || ' ' || cp.surname insured_name,
                      tr.description,
                      hd.ext_reference,
                      null as ticket_no,
                      sum(hit.trans_amount) debit,
                      0 as credit,
                      null as stoppage_amount,
                      im.invoiceid as az_invoice_no,
                      im.issuedate as az_invoice_date,
                      ime.invoice_status_type as invoice_status_type,
                      im.uuid as uu_id,
                      im.profileid as profile_id
                 from koc_clm_hlth_inst_trans hit,
                      koc_clm_hlth_detail hd,
                      koc_cc_inst_trans_ref tr,
                      alz_invoice_master im,
                      alz_invoice_master_ext ime,
                      cp_partners cp
                where hit.payment_group_code = 2
                  and hit.institute_code = 3311
                  and hit.pay_month = 4
                  and hit.pay_year = 2019
                  and hit.trans_type in (2, 3, 4, 33, 51)
                  and hit.claim_id = hd.claim_id(+)
                  and hit.sf_no = hd.sf_no(+)
                  and hit.add_order_no = hd.add_order_no(+)
                  and hit.trans_type = tr.trans_type
                  and im.idx = ime.idx
                  and hit.batch_id = ime.acc_batch_id
                  and hd.part_id = cp.part_id(+)
                group by hd.invoice_date,
                         hd.invoice_no,
                         cp.first_name || ' ' || cp.surname,
                         tr.description,
                         hd.ext_reference,
                         null,
                         im.invoiceid,
                         im.issuedate,
                         ime.invoice_status_type,
                         im.uuid,
                         im.profileid
               union all
              select hd.invoice_date,
                     hd.invoice_no,
                     cp.first_name || ' ' || cp.surname insured_name,
                     tr.description,
                     hd.ext_reference,
                     null as ticket_no,
                     0 debit,
                     sum(hit.trans_amount) as credit,
                     null as stoppage_amount,
                     null as az_invoice_no,
                     null as az_invoice_date,
                     null as invoice_status_type,
                     null as uu_id,
                     null as profile_id
                from koc_clm_hlth_inst_trans hit,
                     koc_clm_hlth_detail hd,
                     koc_cc_inst_trans_ref tr,
                     cp_partners cp
               where hit.payment_group_code = 2
                 and hit.institute_code = 3311
                 and hit.pay_month = 4
                 and hit.pay_year = 2019
                 and hit.trans_type in (5, 10, 11, 34, 52)
                 and hd.claim_id = hit.claim_id(+)
                 and hd.sf_no = hit.sf_no(+)
                 and hd.add_order_no = hit.add_order_no(+)
                 and hit.trans_type = tr.trans_type
                 and hd.part_id = cp.part_id(+)
               group by hd.invoice_date,
                        hd.invoice_no,
                        cp.first_name || ' ' || cp.surname,
                        description,
                        hd.ext_reference,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null);
                        
                       
               
                select * 
                  from koc_clm_hlth_inst_trans hit
                 where hit.payment_group_code = 2
                    and hit.institute_code=3311 
                    and hit.pay_year=2019 
                    and hit.pay_month=5
                    
                    
                    
                     select hd.invoice_date,
                     hd.invoice_no,
                     cp.first_name || ' ' || cp.surname insured_name,
                     tr.description,
                     hd.ext_reference,
                     null as ticket_no,
                     0 debit,
                     sum(hit.trans_amount) as credit,
                     null as stoppage_amount,
                     null as az_invoice_no,
                     null as az_invoice_date,
                     null as invoice_status_type,
                     null as uu_id,
                     null as profile_id
                from koc_clm_hlth_inst_trans hit,
                     koc_clm_hlth_detail hd,
                     koc_cc_inst_trans_ref tr,
                     cp_partners cp
               where hit.payment_group_code = 2
                 and hit.institute_code = 3311
                 and hit.pay_month = 5
                 and hit.pay_year = 2019
                 and hit.trans_type in (4, 5, 10, 11, 34, 52)
                 and hd.claim_id = hit.claim_id(+)
                 and hd.sf_no = hit.sf_no(+)
                 and hd.add_order_no = hit.add_order_no(+)
                 and hit.trans_type = tr.trans_type
                 and hd.part_id = cp.part_id(+)
               group by hd.invoice_date,
                        hd.invoice_no,
                        cp.first_name || ' ' || cp.surname,
                        description,
                        hd.ext_reference,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null
                    
                  --select * from koc_cc_inst_trans_ref where trans_type=4
                  
                   ; koc_clm_hlth_trnx2.genInstClmTrans
                    
                   
                   select * from  koc_cc_inst_trans_ref where trans_type in (5,10,11,34,52)
                   
                   select * from koc_clm_hlth_inst_trans where institute_code=3311 and pay_year = 2019 and pay_month=5
                   
                   select * from alz_hclm_institute_info for update
                   
                   
                   
                     select parameter,parameter_name 
     -- into :kontrol.TXT_HASTANE_TSS, :kontrol.TEXT_ITEM_TSS
      from koc_v_cp_health_look_up
     where look_up_code = 'PAYGRP'
       and validity_start <= trunc(sysdate)
       and nvl(validity_end ,trunc(sysdate))>= trunc(sysdate)
       and parameter = 'T1';
                   
       
       
       SELECT a.PAYMENT_DATE,a.confirmation_date
       ,(SELECT NVL(MAX(aa.confirmation_date),TO_DATE ('01/01/1900', 'dd/mm/yyyy')) + 1
            FROM KOC_CC_MONTH_CONFIRM_DATES aa
           WHERE aa.payment_group_code = a.payment_group_code
             AND aa.confirmation_date < a.confirmation_date) prev_confirmation_date
  FROM KOC_CC_MONTH_CONFIRM_DATES a
 WHERE TO_CHAR (a.payment_date, 'mmyyyy') = TO_CHAR (LAST_DAY (SYSDATE), 'mmyyyy')
   AND a.payment_group_code = 'T1'
   
   select * from koc_cc_month_confirm_dates where payment_group_code='T1' and TO_CHAR(payment_date,'YYYYMM') = '201905'
