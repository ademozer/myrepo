--ALZ_INV_PROCESS_UTILS

select * from web_statement_users@opusdev where user_id='ADMIN' 
select * from web_statement_users where user_id='ADMIN' for update
--7c222fb2927d828af22f592134e8932480637c0d
--a98077361ed1092b7a9aa969a557ce3d5f29bde7

select * from all_source where text like '%decrypt%';

KOC_CLM_HLTH_PHARMACY_UTILS

SELECT alz_web_user_security.decrypt() from web_statement_users where user_id='ADMIN'
