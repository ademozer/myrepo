SELECT  det.invoice_date
                            ,det.invoice_no
                            ,KOC_CLM_HLTH_UTILS.Getpartnernamebypartid(det.part_id) insured_name
                            ,DECODE(a.sf_total_type,'11','Tahakkuk','12','Tahakkuk �ptali','') description
                            ,det.ext_reference ext_reference
                            ,b.ticket_no
                            ,b.ticket_date
                            ,SUM(DECODE(a.sf_total_type,'11',1,0)*(NVL(a.trans_amt,0)-NVL(b.stoppage_amount,0))*NVL(b.currency_exchange_rate,1)) credit
                            ,SUM(DECODE(a.sf_total_type,'12',1,0)*(NVL(a.trans_amt,0)-NVL(b.stoppage_amount,0))*NVL(b.currency_exchange_rate,1)) debit
                            ,sum(nvl (b.stoppage_amount, 0) * nvl (b.currency_exchange_rate, 1)) as stoppage_amount
                        
                        FROM koc_clm_trans_ext b
                            ,clm_trans a
                            --,koc_clm_suppliers_ext c
                            ,koc_clm_hlth_detail det
                       WHERE b.ticket_date >= TO_DATE('09/04/2019','DD/MM/YYYY')
                         AND b.ticket_date <= TO_DATE('13/05/2019','DD/MM/YYYY')
                         AND b.payment_type = '7'
                         AND a.claim_id = b.claim_id
                         AND a.sf_no = b.sf_no
                         AND a.trans_no = b.trans_no
                         AND a.sf_total_type IN ('11','12')
                         --AND c.supp_id = a.supp_id
                         AND det.claim_id = b.claim_id
                         AND det.sf_no = b.sf_no
                         AND det.add_order_no = b.add_order_no
                         AND det.institute_code = 1657
                         AND det.ext_reference=56646553
                         --AND c.payment_group_code = v_payment_group_code
                         --AND det.is_complementary = v_is_tss
                     GROUP BY det.invoice_date
                            ,det.invoice_no
                            ,det.part_id
                            ,a.sf_total_type
                            ,det.ext_reference
                            ,b.ticket_no
                            ,b.ticket_date
                            
                            
                            SELECT MIN(confirmation_date) + 1 prev_confirmation_date,
                         MAX(confirmation_date) confirmation_date
                   -- INTO v_start_date, v_end_date
                    FROM KOC_CC_MONTH_CONFIRM_DATES a
                   WHERE TO_CHAR (a.payment_date, 'YYYYMM') = 201905
                    AND a.payment_group_code = '2';
                    
                    
                    select * from koc_clm_hlth_inst_trans where institute_code=1657
                   -- and claim_id=39987994
                    select * from koc_clm_hlth_detail where ext_reference='56646553'
                    
                    select * from hsevim.dm_table_column where column_name='TICKET_DATE'--table_name=upper('koc_clm_trans_ext') 
                    
                   -- select * from alz_hltprv_bre_log 
