DECLARE
   p_data KOC_CLM_HLTH_PHARMACY_UTILS.Rc;
  PROCEDURE Getconfirmdates (p_Institute_Code       NUMBER,
                              p_Month                NUMBER,
                              p_Year                 NUMBER,
                              Cur                OUT KOC_CLM_HLTH_PHARMACY_UTILS.Rc,
                              p_Is_Tss               NUMBER DEFAULT 0 -- kpamuk@kora TSS 12.03.2015
                                                                     )
   IS
      v_Result   KOC_CLM_HLTH_PHARMACY_UTILS.Rc;
   BEGIN
      IF NVL (p_Is_Tss, 0) = 0
      THEN
         OPEN v_Result FOR
            SELECT d.Confirmation_Date,
                   d.Payment_Date,
                   d.Last_Invoice_Send_Date Last_Prescr_Send_Date
              FROM Koc_Clm_Suppliers_Ext c, Koc_Cc_Month_Confirm_Dates d
             WHERE     Institute_Code = p_Institute_Code
                   AND c.Payment_Group_Code = d.Payment_Group_Code
                   AND TO_NUMBER (TO_CHAR (d.Payment_Date, 'yyyy')) = p_Year
                   AND (   NVL (p_Month, 0) = 0
                        OR (    NVL (p_Month, 0) != 0
                            AND TO_NUMBER (TO_CHAR (d.Payment_Date, 'mm')) =
                                   p_Month));
      END IF;

      IF NVL (p_Is_Tss, 0) = 1
      THEN
         -- kpamuk@kora TSS 12.03.2015
         OPEN v_Result FOR
            SELECT d.Confirmation_Date,
                   d.Payment_Date,
                   d.Last_Invoice_Send_Date Last_Prescr_Send_Date
              FROM Koc_Clm_Suppliers_Ext c, Koc_Cc_Month_Confirm_Dates d
             WHERE     Institute_Code = p_Institute_Code
                   AND c.Tss_Payment_Group_Code = d.Payment_Group_Code
                   AND TO_NUMBER (TO_CHAR (d.Payment_Date, 'yyyy')) = p_Year
                   AND (   NVL (p_Month, 0) = 0
                        OR (    NVL (p_Month, 0) != 0
                            AND TO_NUMBER (TO_CHAR (d.Payment_Date, 'mm')) =
                                   p_Month));
      END IF;

      Cur := v_Result;
   END Getconfirmdates;
   
   procedure print_cursor(p_cur IN  KOC_CLM_HLTH_PHARMACY_UTILS.rc) IS 
      v_data_msg CLOB;
      v_ndx NUMBER;
      v_keys_data VARCHAR2(32000);
    BEGIN
        v_data_msg := '{"data":[';
        FOR rec_1 IN (SELECT ROWNUM ROW_NO, 
                                      t1.column_value.getStringVal() ROW_DATA
                                 FROM (SELECT * FROM TABLE (XMLSEQUENCE(p_cur))) t1)    
                 LOOP                   
                     IF rec_1.ROW_NO>1 THEN
                         v_data_msg := v_data_msg || ',';
                     END IF;
                     v_data_msg := v_data_msg || '{';
                     v_ndx := 0;
                     FOR rec_2 IN (SELECT EXTRACTVALUE (t.COLUMN_VALUE, '/*') AS NODE_VALUE,
                                                        t.COLUMN_VALUE.getrootelement () AS NODE_NAME
                                     FROM TABLE (XMLSEQUENCE (EXTRACT(EXTRACT(XMLTYPE(rec_1.ROW_DATA), '//*'), '/ROW/*'))) t)
                     LOOP
                        IF v_ndx>0 THEN
                           v_data_msg := v_data_msg || ',';
               IF rec_1.ROW_NO = 1 THEN
                v_keys_data := v_keys_data || ',';
               END IF;
                        END IF;
            IF rec_1.ROW_NO = 1 THEN
              v_keys_data := v_keys_data || LOWER(rec_2.NODE_NAME);
            END IF;
                        v_data_msg := v_data_msg || '"' || LOWER(rec_2.NODE_NAME) || '":"' || TRIM(rec_2.Node_Value) || '"';
                        v_ndx := v_ndx + 1;                         
                     END LOOP;
                     v_data_msg := v_data_msg || '}';
                 END LOOP;   
          v_data_msg := v_data_msg||']}';
          DBMS_OUTPUT.PUT_LINE(v_data_msg);
    END print_cursor; 
    
    BEGIN
        
        Getconfirmdates(1657, 4, 2019, p_data, 1);
        print_cursor(p_data); 
    END;
   
   
