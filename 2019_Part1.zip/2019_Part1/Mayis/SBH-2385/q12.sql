            select hd.invoice_date,
                       hd.invoice_no,
                       cp.part_id,--cp.first_name || ' ' || cp.surname insured_name,
                       tr.description,
                       hd.ext_reference,
                       hit.trans_date,
                       null as ticket_no,                     
                       0 debit,
                       sum(hit.trans_amount) as credit,
                       null as stoppage_amount,
                       null as az_invoice_no,
                       null as az_invoice_date,
                       null as invoice_status_type,
                       null as uu_id,
                       null as profile_id
                  from koc_clm_hlth_inst_trans hit,
                       koc_clm_hlth_detail hd,
                       koc_cc_inst_trans_ref tr,
                       cp_partners cp
                 where hit.payment_group_code = '2'
                  -- and hit.institute_code = p_institute_code
                   and hit.pay_month = 5
                   and hit.pay_year = 2019
                  -- and hit.trans_date >= v_start_date --ademo.SBH-2385
                 --  and hit.trans_date <= v_end_date   --ademo.SBH-2385
                   and hd.realization_date >= TO_DATE('29/04/2019','DD/MM/YYYY') --ademo.SBH-2385
                   and hd.realization_date <= TO_DATE('13/05/2019','DD/MM/YYYY')
                   and hit.trans_type in (5, 10, 11, 34, 52)
                   and hd.claim_id = hit.claim_id(+)
                   and hd.sf_no = hit.sf_no(+)
                   and hd.add_order_no = hit.add_order_no(+)
                   and hit.trans_type = tr.trans_type
                   and hd.part_id = cp.part_id(+)
                   and rownum<3
                 group by hd.invoice_date,
                          hd.invoice_no,
                          cp.part_id,--cp.first_name || ' ' || cp.surname,
                          description,
                          hd.ext_reference,
                          hit.trans_date,
                          null,
                          null,
                          null,
                          null,
                          null,
                          null;
                          
                          
                           select * from koc_clm_hlth_detail where ext_reference='56679180'
