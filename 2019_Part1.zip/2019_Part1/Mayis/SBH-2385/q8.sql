select * from koc_clm_hlth_detail where ext_reference=32881690
--create table sbh_2046_cancel_claims(institute_code NUMBER,ext_reference VARCHAR2(20));

--grant SELECT ON sbh_2046_cancel_claims TO PUBLIC

SELECT * from sbh_2046_cancel_claims for update

select count(*) from sbh_2046_cancel_claims;


 SELECT d.Confirmation_Date,
                   d.Payment_Date,
                   d.Last_Invoice_Send_Date Last_Prescr_Send_Date
              FROM Koc_Clm_Suppliers_Ext c, Koc_Cc_Month_Confirm_Dates d
             WHERE     Institute_Code = 1657
                   AND c.Tss_Payment_Group_Code = d.Payment_Group_Code
                   AND TO_NUMBER (TO_CHAR (d.Payment_Date, 'yyyy')) = '2020'
                   AND (   NVL ('01', 0) = 0
                        OR (    NVL ('01', 0) != 0
                            AND TO_NUMBER (TO_CHAR (d.Payment_Date, 'mm')) =
                                   '01'));
