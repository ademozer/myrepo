select hd.invoice_date,
                        hd.invoice_no,
                        cp.part_id,--cp.first_name || ' ' || cp.surname insured_name,
                        tr.description,
                        hd.ext_reference,
                        null as ticket_no,                        
                        sum(hit.trans_amount) debit,
                        0 as credit,
                        null as stoppage_amount,
                        im.invoiceid as az_invoice_no,
                        im.issuedate as az_invoice_date,
                        ime.invoice_status_type as invoice_status_type,
                        im.uuid as uu_id,
                        im.profileid as profile_id
                   from koc_clm_hlth_inst_trans hit,
                        koc_clm_hlth_detail hd,
                        koc_cc_inst_trans_ref tr,
                        alz_invoice_master im,
                        alz_invoice_master_ext ime,
                        cp_partners cp
                  where hit.payment_group_code = 'T1'
                   -- and hit.institute_code = 1657
                   --- and hit.pay_month = 4
                    and hit.pay_year = 2019
                   -- and hit.batch_date >= TO_DATE('09/04/2019','DD/MM/YYYY') --ademo.SBH-2385
                  --  and hit.batch_date <= TO_DATE('28/04/2019','DD/MM/YYYY')   --ademo.SBH-2385
                    and hit.trans_type in (2, 3, 4, 33, 51)
                    and hit.trans_type != 4
                    and hit.claim_id = hd.claim_id(+)
                    and hit.sf_no = hd.sf_no(+)
                    and hit.add_order_no = hd.add_order_no(+)
                    and hit.trans_type = tr.trans_type
                    and im.idx = ime.idx
                    and hit.batch_id = ime.acc_batch_id
                    and hd.part_id = cp.part_id(+)
                  --  and hd.ext_reference='56023686'--'56578017'
                    and rownum<3
                  group by hd.invoice_date,
                           hd.invoice_no,
                           cp.part_id,--cp.first_name || ' ' || cp.surname,
                           tr.description,
                           hd.ext_reference,
                           null,
                           im.invoiceid,
                           im.issuedate,
                           ime.invoice_status_type,
                           im.uuid,
                           im.profileid
                           
                           
                        39896013    select * from koc_clm_hlth_detail where ext_reference='56023686'--'56578017'--'56679180' 
                           select * from koc_clm_hlth_inst_trans where claim_id =39147636-- 40030112--ext_reference='56679180'
                           
                           select * from koc_cc_inst_trans_ref where trans_type in (2, 3, 4, 33, 51)
