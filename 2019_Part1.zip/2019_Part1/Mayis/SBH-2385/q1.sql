﻿/*
 hd.invoice_date,
                      hd.invoice_no,
                      --cp.first_name || ' ' || cp.surname insured_name,
                      tr.description,
                      hd.ext_reference,
                      te.ticket_no,
                      sum(decode(tr.sign, -1, (nvl (ct.trans_amt, 0) - nvl (te.stoppage_amount, 0)) * nvl (te.currency_exchange_rate, 1), 0)) debit,
                      sum(decode(tr.sign, 1, (nvl (ct.trans_amt, 0) - nvl (te.stoppage_amount, 0)) * nvl (te.currency_exchange_rate, 1), 0)) credit,
                      sum(nvl (te.stoppage_amount, 0) * nvl (te.currency_exchange_rate, 1)) as stoppage_amount,
*/

 SELECT c.institute_code
        ,det.is_complementary
        ,b.ticket_date
        ,NULL approve_status
        ,d.policy_ref
        ,a.oar_no
        ,a.ext_reference
        ,det.part_id
        ,b.batch_id
        ,DECODE(a.sf_total_type,'11','Tahakkuk','12','Tahakkuk Ýptali','') description
        ,det.invoice_no
        ,det.invoice_date
        ,koc_clm_hlth_utils.getinstitutnamebycode(c.institute_code) instname
        ,SUM(DECODE(a.sf_total_type,'11',1,0)*(NVL(a.trans_amt,0)-NVL(b.stoppage_amount,0))*NVL(b.currency_exchange_rate,1)) credit_amount
        ,SUM(DECODE(a.sf_total_type,'12',1,0)*(NVL(a.trans_amt,0)-NVL(b.stoppage_amount,0))*NVL(b.currency_exchange_rate,1)) debit_amount
        ,c.payment_group_code
        ,NULL explanation
        ,det.specialty_subject
        ,SUM(DECODE(a.sf_total_type,'11',1,'12',-1,0)*NVL(b.stoppage_amount,0)) stoppage
    FROM koc_clm_trans_ext b
        ,clm_trans a
        ,koc_clm_suppliers_ext c
        ,clm_pol_bases d      
        ,koc_clm_hlth_detail det
   WHERE b.ticket_date >= &p_start_date--LEAST(NVL(:p_start_date,:p_start_date_tss),NVL(:p_start_date_tss,:p_start_date))
     AND b.ticket_date <= &p_end_date--GREATEST(NVL(:p_end_date,:p_end_date_tss),NVL(:p_end_date_tss,:p_end_date))
     AND b.payment_type = '7'
     AND a.claim_id = b.claim_id
     AND a.sf_no = b.sf_no
     AND a.trans_no = b.trans_no
     AND c.supp_id = a.supp_id
     AND d.claim_id = b.claim_id   
     AND det.claim_id = b.claim_id
     AND det.sf_no = b.sf_no
     AND det.add_order_no = b.add_order_no   
     AND det.institute_code = 1657
     --&p_where 
     AND (
          (
           &p_oss = 1 AND &p_tss = 1 AND 
           ((&p_oss = 1
              AND oss_agreement_status = 1 
              AND c.payment_group_code = DECODE(&p_payment_group_code,NULL,c.payment_group_code,&p_payment_group_code) 
              AND NVL(det.is_complementary,0) = 0
              AND b.ticket_date >= &p_start_date
              AND b.ticket_date <= &p_end_date
            ) OR    
            (&p_tss = 1 
              AND tss_agreement_status = 1 
              AND c.tss_payment_group_code = DECODE(&p_payment_group_code_tss,NULL,c.tss_payment_group_code,&p_payment_group_code_tss) 
              AND NVL(det.is_complementary,0) = 1
              AND b.ticket_date >= &p_start_date --_tss
              AND b.ticket_date <= &p_end_date   --_tss                  
            )
           )
          ) OR 
          (&p_oss = 1 AND &p_tss = 0 
                      AND oss_agreement_status = 1 
                      AND c.payment_group_code = DECODE(&p_payment_group_code,NULL,c.payment_group_code,&p_payment_group_code) 
                      AND NVL(det.is_complementary,0) = 0
                      AND b.ticket_date >= &p_start_date
                      AND b.ticket_date <= &p_end_date
          ) OR    
          (&p_oss = 0 AND &p_tss = 1 
                      AND tss_agreement_status = 1 
                      AND c.tss_payment_group_code = DECODE(&p_payment_group_code_tss,NULL,c.tss_payment_group_code,&p_payment_group_code_tss) 
                      AND NVL(det.is_complementary,0) = 1
                      AND b.ticket_date >= &p_start_date--_tss
                      AND b.ticket_date <= &p_end_date--_tss                      
          )
         )                                            
GROUP BY c.institute_code
        ,b.ticket_date
        ,d.policy_ref
        ,a.oar_no
        ,a.ext_reference
        ,det.part_id
        ,b.batch_id
        ,DECODE(b.payment_approved_date,NULL,'Onaysýz','')
        ,det.invoice_no
        ,det.invoice_date
        ,DECODE(a.sf_total_type,'11','Tahakkuk','12','Tahakkuk Ýptali','')
        ,c.payment_group_code
        ,det.is_complementary
        ,det.specialty_subject                                       
