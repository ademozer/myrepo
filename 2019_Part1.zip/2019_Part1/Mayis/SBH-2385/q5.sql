      select hd.invoice_date,
                       hd.invoice_no,
                       KOC_CLM_HLTH_UTILS.Getpartnernamebypartid(hd.part_id) insured_name, 
                       tr.description,
                       hd.ext_reference,
                       null as ticket_no,
                       hit.batch_date,
                       hit.trans_date,
                       0 debit,
                       sum(hit.trans_amount) as credit,
                       null as stoppage_amount                      
                  from koc_clm_hlth_inst_trans hit,
                       koc_clm_hlth_detail hd,
                       koc_cc_inst_trans_ref tr
                 where hit.payment_group_code = 'T1'
                   and hit.institute_code = 1657
                   and hit.pay_month = 5
                   and hit.pay_year = 2019              
                   AND hit.trans_type NOT IN (1,21,31,32,18) 
                   and hd.claim_id = hit.claim_id(+)
                   and hd.sf_no = hit.sf_no(+)
                   and hd.add_order_no = hit.add_order_no(+)
                   and hit.trans_type = tr.trans_type  
                   and hd.is_complementary = 1
                   and NVL(hit.batch_date, hit.trans_date) >= TO_DATE('29/04/2019','DD/MM/YYYY')
                   and NVL(hit.batch_date, hit.trans_date) <= TO_DATE('13/05/2019','DD/MM/YYYY')
                  -- and NVL(hit.batch_date, hit.trans_date) <= v_end_date           
                 group by hd.invoice_date,
                          hd.invoice_no,
                          hd.part_id,
                          tr.description,
                          hd.ext_reference,
                           hit.batch_date,
                       hit.trans_date
                       
                       
                       
                       
     SELECT  det.invoice_date
                      ,det.invoice_no
                      ,KOC_CLM_HLTH_UTILS.Getpartnernamebypartid(det.part_id) insured_name 
                      ,DECODE(a.sf_total_type,'11','Tahakkuk','12','Tahakkuk �ptali','') description 
                      ,det.ext_reference ext_reference               
                      ,b.ticket_no      
                      ,SUM(DECODE(a.sf_total_type,'11',1,0)*(NVL(a.trans_amt,0)-NVL(b.stoppage_amount,0))*NVL(b.currency_exchange_rate,1)) credit
                      ,SUM(DECODE(a.sf_total_type,'12',1,0)*(NVL(a.trans_amt,0)-NVL(b.stoppage_amount,0))*NVL(b.currency_exchange_rate,1)) debit
                      ,sum(nvl (b.stoppage_amount, 0) * nvl (b.currency_exchange_rate, 1)) as stoppage_amount                     
                  FROM koc_clm_trans_ext b
                      ,clm_trans a                     
                      ,koc_clm_hlth_detail det
                 WHERE  b.ticket_date >= TO_DATE('29/04/2019','DD/MM/YYYY')
                   and  b.ticket_date <= TO_DATE('13/05/2019','DD/MM/YYYY')                   
                   AND b.payment_type = '7'
                   AND a.claim_id = b.claim_id
                   AND a.sf_no = b.sf_no
                   AND a.trans_no = b.trans_no  
                   AND a.sf_total_type IN ('11','12')                
                   AND det.claim_id = b.claim_id
                   AND det.sf_no = b.sf_no
                   AND det.add_order_no = b.add_order_no   
                   AND det.institute_code = 1657               
                   AND NVL(det.is_complementary,0) = 1;
                   
                   
                  -- Koc_Clm_Hlth_Trnx.Find_Exemption_Limit
