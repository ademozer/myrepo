﻿ select hit.trans_date payment_date,
              sum(hit.trans_amount) payment_amount
         from koc_clm_hlth_inst_trans hit
        where hit.payment_group_code = 2
          and hit.institute_code = 3311
          and hit.firm = '0'
          and hit.pay_month = 5
          and hit.pay_year = 2019
          and hit.trans_type = 18
          and not exists(select 1
                           from koc_clm_hlth_inst_trans itr
                          where itr.payment_ref_id = hit.payment_ref_id
                            and itr.trans_type in (30, 50)
                            and itr.confirm_rem_id is null)
        group by hit.trans_date
        order by hit.trans_date asc;
        
        select * from all_source where lower(text) like '%get_balance_payment_list%'
        
        
        
        
        
        
        select hd.invoice_date,
                      hd.invoice_no,
                      --cp.first_name || ' ' || cp.surname insured_name,
                      tr.description,
                      hd.ext_reference,
                      te.ticket_no,
                      sum(decode(tr.sign, -1, (nvl (ct.trans_amt, 0) - nvl (te.stoppage_amount, 0)) * nvl (te.currency_exchange_rate, 1), 0)) debit,
                      sum(decode(tr.sign, 1, (nvl (ct.trans_amt, 0) - nvl (te.stoppage_amount, 0)) * nvl (te.currency_exchange_rate, 1), 0)) credit,
                      sum(nvl (te.stoppage_amount, 0) * nvl (te.currency_exchange_rate, 1)) as stoppage_amount,
                      null as az_invoice_no,
                      null as az_invoice_date,
                      null as invoice_status_type,
                      null as uu_id,
                      null as profile_id
                 from --koc_clm_hlth_inst_trans hit,
                      koc_clm_trans_ext te,
                      clm_trans ct,
                      koc_clm_hlth_detail hd,
                      koc_cc_inst_trans_ref tr--,
                     -- cp_partners cp
                where 1=1--hit.inst_ext_id = te.inst_ext_id
                  --and hit.payment_group_code = 2
                  --and hit.institute_code = 3311
                  --and hit.pay_month = 4
                  --and hit.pay_year = 2019
                  --and hit.trans_type in (1, 21)
                  
                  and te.claim_id = ct.claim_id
                  and te.sf_no = ct.sf_no
                  and te.trans_no = ct.trans_no
                  and ct.sf_total_type in (11, 12)
                  and hd.claim_id = te.claim_id
                  and hd.sf_no = te.sf_no
                  and hd.add_order_no = te.add_order_no
                  --and hd.part_id = cp.part_id
                  and ct.trans_type = tr.trans_type
                  and hd.institute_code = 3311
                  and te.ticket_date>TO_DATE('01/05/2019','DD/MM/YYYY')
                  and te.ticket_date<TO_DATE('02/05/2019','DD/MM/YYYY')
                 -- and hit.trans_type = tr.trans_type
                group by hd.invoice_date,
                         hd.invoice_no,
                         --cp.first_name || ' ' || cp.surname,
                         description,
                         hd.ext_reference,
                         te.ticket_no,
                         null,
                         null,
                         null,
                         null,
                         null
                         
                         
                   
                         select hd.invoice_date,
                                hd.invoice_no,
                                hd.ext_reference,
                                te.ticket_no,
                                te.ticket_date,
                                hd.institute_code,
                                nvl (te.stoppage_amount, 0) stoppage_amount, 
                                nvl (te.currency_exchange_rate, 1) currency_exchange_rate 
                          from koc_clm_hlth_detail hd,
                               koc_clm_trans_ext te                           
                         where hd.institute_code=4510 
                           and hd.is_complementary='1'
                           --and hd.ext_reference IN('56791179','56791181')
                           and hd.claim_id = te.claim_id
                           and hd.sf_no = te.sf_no
                           and hd.add_order_no = te.add_order_no
                           and te.ticket_date > TO_DATE('01/05/2019','DD/MM/YYYY')
                           and te.ticket_date < TO_DATE('02/05/2019','DD/MM/YYYY')
                         
                         SELECT c.institute_code
        ,det.is_complementary
        ,b.ticket_date
        ,NULL approve_status
        ,d.policy_ref
        ,a.oar_no
        ,a.ext_reference
        ,det.part_id
        ,b.batch_id
        ,DECODE(a.sf_total_type,'11','Tahakkuk','12','Tahakkuk Ýptali','') description
        ,det.invoice_no
        ,det.invoice_date
       -- ,koc_clm_hlth_utils.getinstitutnamebycode(c.institute_code) instname
       -- ,SUM(DECODE(a.sf_total_type,'11',1,0)*(NVL(a.trans_amt,0)-NVL(b.stoppage_amount,0))*NVL(b.currency_exchange_rate,1)) credit_amount
     --   ,SUM(DECODE(a.sf_total_type,'12',1,0)*(NVL(a.trans_amt,0)-NVL(b.stoppage_amount,0))*NVL(b.currency_exchange_rate,1)) debit_amount
        ,c.payment_group_code
        ,NULL explanation
        ,det.specialty_subject
     --   ,SUM(DECODE(a.sf_total_type,'11',1,'12',-1,0)*NVL(b.stoppage_amount,0)) stoppage
    FROM koc_clm_trans_ext b
        ,clm_trans a
        ,koc_clm_suppliers_ext c
        ,clm_pol_bases d      
        ,koc_clm_hlth_detail det
   WHERE b.ticket_date >= &p_start_date--LEAST(NVL(null,&p_start_date_tss),NVL(&p_start_date_tss,:p_start_date))
     AND b.ticket_date <= &p_end_date--GREATEST(NVL(null,&p_end_date_tss),NVL(&p_end_date_tss,:p_end_date))
     AND b.payment_type = '7'
     AND a.claim_id = b.claim_id
     AND a.sf_no = b.sf_no
     AND a.trans_no = b.trans_no
     AND c.supp_id = a.supp_id
     AND d.claim_id = b.claim_id   
     AND det.claim_id = b.claim_id
     AND det.sf_no = b.sf_no
     AND det.add_order_no = b.add_order_no 
     AND c.institute_code=&p_inst_code
     
     select * from koc_cc_inst_trans_ref
