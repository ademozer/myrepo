DECLARE 
v_data CLOB := '{
    "claimDetailDto" : {
      "claimId" : 38748778,
      "sfNo" : 1,
      "addOrderNo" : 1,
      "extReference" : "55712562",
      "policyDetailDto" : {
        "claimId" : 38748778,
        "contractId" : 388913504,
        "oarNo" : 3,
        "objectId" : null,
        "versionNo" : null
      },
}';
 v_ndx1 NUMBER;
 v_ndx2 NUMBER;
 v_policy_detail CLOB;
 
BEGIN
     v_data := TRIM(regexp_replace(v_data, '([^[:graph:] | ^[:blank:]])', ''));  
     v_ndx1 := INSTR(v_data,'claimDetailDto');
     v_ndx2 := INSTR(v_data,'policyDetailDto') - v_ndx1;
     v_policy_detail := SUBSTR(v_data, v_ndx1+21, v_ndx2-29);
     FOR rec_1 IN (
         SELECT trim(replace (Regexp_Substr (Element, '[^:]+', 1) , '"','')) KEY, 
                trim(replace (Regexp_Substr (Element, '[^:]+', 1, 2), '"','')) VALUE              
          FROM (Select Regexp_Substr (v_policy_detail,'[^,]+',1, Level) Element
                  From Dual
                Connect By Level <= Length (Regexp_Replace (v_policy_detail, '[^,]+')) + 1))  
     LOOP
         DBMS_OUTPUT.PUT_LINE('<'||rec_1.key||'>'||rec_1.value||'</'||rec_1.key||'>');
     END LOOP;
     /*v_data := SUBSTR(v_data, 1, v_ndx1-1);
     FOR rec_1 IN (SELECT COLUMN_VALUE FROM TABLE(CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.convertPayloadToTable(v_data))) LOOP
            v_ndx := 0;
            FOR rec_2 IN (SELECT FIELD_NAME, FIELD_VALUE FROM TABLE(rec_1.COLUMN_VALUE)) LOOP                       
                 IF rec_2.FIELD_NAME = 'partId' THEN
                     v_insured.part_id := rec_2.FIELD_VALUE;
                 END IF;
                 IF rec_2.FIELD_NAME = 'identityNo' THEN
                     v_insured.identity_No := rec_2.FIELD_VALUE;
                 END IF;
                 IF rec_2.FIELD_NAME = 'cardNo' THEN
                     v_insured.card_Info := rec_2.FIELD_VALUE;
                 END IF; 
                 IF rec_2.FIELD_NAME = 'firstName' THEN
                     v_insured.first_name := rec_2.FIELD_VALUE;
                 END IF;         
            END LOOP;               
            DBMS_OUTPUT.put_line(v_insured.first_name);                                           
     END LOOP;*/
      DBMS_OUTPUT.PUT_LINE('ndx1='||v_ndx1);
       DBMS_OUTPUT.PUT_LINE('ndx2='||v_ndx2);
     DBMS_OUTPUT.PUT_LINE('det='||v_policy_detail);
END;
     
