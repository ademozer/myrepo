DECLARE 
  v_data_msg CLOB;

  v_ndx NUMBER := 0;
  cur_ SYS_REFCURSOR; 
    
  
BEGIN
OPEN cur_ FOR 'SELECT ''Referral_Institute_Name'', 
''Personal_Notes'',  
''Patient_Admittance_Date'', 
''Request_Amount'',  
''Hlth_Srv_Pay'',
''Dh_Inst'', 
''Hospital_Ref_No'', 
''Request_System'',  
''Bre_Result_Code'', 
''Is_Complementary'',
''Sgk_Ref_No'',  
''Is_Ahek'', 
''Affluent_Flag'',   
''Cpa_Status'',  
''Is_Original'', 
''Has_Unreadable_Doc'',  
''Visiting_Reason'', 
''Is_Only_Examination_Fee'', 
''Is_Ok'',   
''Is_Ex_Gratia'',
''Ex_Gratia_Fee'',   
''Is_Automated'',
''Is_Suspense'', 
''Suspense_Date'',   
''Medula_Date'' FROM DUAL'; 
FOR rec_1 IN (SELECT ROWNUM ROW_NO, 
                                      t1.column_value.getStringVal() ROW_DATA
                                 FROM (SELECT * FROM TABLE (XMLSEQUENCE(cur_))) t1)    
                 LOOP                   
                    
                     FOR rec_2 IN (SELECT EXTRACTVALUE (t.COLUMN_VALUE, '/*') AS NODE_VALUE,
                                                        t.COLUMN_VALUE.getrootelement () AS NODE_NAME
                                     FROM TABLE (XMLSEQUENCE (EXTRACT(EXTRACT(XMLTYPE(rec_1.ROW_DATA), '//*'), '/ROW/*'))) t)
                     LOOP
                       
                        v_data_msg := v_data_msg ||'v_data := v_data || '''||rec_2.Node_Value||' = '' || p_Data(ndx).'|| rec_2.Node_Value||' || CHR(13);'||CHR(13);
                        --v_data_msg := v_data_msg || '"' || LOWER(rec_2.NODE_NAME) || '":"' || TRIM(rec_2.Node_Value) || '"';
                                            
                     END LOOP;
                    
                 END LOOP;   
DBMS_OUTPUT.PUT_LINE(v_data_msg);

END;

   
