DECLARE 
 v_cnt NUMBER := 0;
 v_comm_count NUMBER := 100;
BEGIN
   
   FOR rec IN (select document_id 
                        from alz_fn_mig_contracts 
                       where mig_status='DONE') LOOP
                       
       v_cnt := v_cnt + 1;
        
       DELETE alz_documents WHERE document_id = rec.document_id;
       
       UPDATE alz_fn_mig_contracts
          SET mig_status = 'DLTD'
         WHERE document_id = rec.document_id;
         
       IF v_cnt MOD v_comm_count = 0 THEN
           COMMIT;
       END IF;
   END LOOP;
   COMMIT;
   DBMS_OUTPUT.PUT_LINE(v_cnt||' adet kay�t silindi');
EXCEPTION 
  WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('Hata:'||SQLERRM);   
END;                
                 
