     SELECT * FROM XMLTABLE('/FIELD_LIST/FIELD'
                   PASSING XMLTYPE('<FIELD_LIST>
   <FIELD>
      <PROCESSCODEMAIN>17</PROCESSCODEMAIN>
      <PROCESSCODESUB1>0</PROCESSCODESUB1>
      <PROCESSCODESUB2>0</PROCESSCODESUB2>
   </FIELD>
   <FIELD>
      <PROCESSCODEMAIN>16</PROCESSCODEMAIN>
      <PROCESSCODESUB1>0</PROCESSCODESUB1>
      <PROCESSCODESUB2>0</PROCESSCODESUB2>
   </FIELD>
   <FIELD>
      <PROCESSCODEMAIN>18</PROCESSCODEMAIN>
      <PROCESSCODESUB1>0</PROCESSCODESUB1>
      <PROCESSCODESUB2>0</PROCESSCODESUB2>
   </FIELD>
</FIELD_LIST>')
                    COLUMNS 
                        PROCESS_CODE_MAIN  VARCHAR2(100) PATH 'PROCESSCODEMAIN',
                        PROCESS_CODE_SUB1  VARCHAR2(100) PATH 'PROCESSCODESUB1',
                        PROCESS_CODE_SUB2  VARCHAR2(100) PATH 'PROCESSCODESUB2')
                        
       WITH field_list AS (
        SELECT trim(replace (Regexp_Substr (Xt.Element, '[^:]+', 1) , '"','')) KEY, 
               trim(replace (Regexp_Substr (Xt.Element, '[^:]+', 1, 2), '"','')) VALUE              
          FROM (Select Regexp_Substr ('"CLAIM_ID" : "12345", "EXT_REFERENCE" : "67899"',
                                      '[^,]+',
                                      1,
                                      Level)
                              Element
                      From Dual
                Connect By Level <= Length (Regexp_Replace ('"CLAIM_ID" : "12345", "EXT_REFERENCE" : "67899"', '[^,]+')) + 1) Xt )
       SELECT FROM field_list 


