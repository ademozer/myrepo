declare
v_contract_id Koc_Clm_Hlth_Indem_Totals.Contract_Id%TYPE;
v_partition_no Koc_Clm_Hlth_Indem_Totals.Partition_No%TYPE;
v_partner_id  Koc_v_Hlth_Insured_Info_Indem.partner_id%TYPE;
v_cover_code  VARCHAR2(100);
v_is_special  NUMBER;
v_is_pool     NUMBER;
v_claim_inst_type VARCHAR2(100);
v_claim_inst_loc  VARCHAR2(100); 
v_date        VARCHAR2(100) := '15/11/2018';
Expackrow                KOC_OC_HLTH_EXPACK_COV_REL%ROWTYPE;
Policyinfo               Koc_v_Hlth_Insured_Info_Indem%ROWTYPE;
Indeminfo                Koc_Clm_Hlth_Indem_Totals%ROWTYPE;
Institutinfo             Koc_v_Clm_Suppliers%ROWTYPE;
v_Networkid      Koc_v_Hlth_Insured_Info_Indem.Network_Id%TYPE;
p_Country_Group            NUMBER;
p_Claim_Inst_Type          VARCHAR2(3);
p_Claim_Inst_Loc           VARCHAR2(3);
v_City_Code    VARCHAR2(3);
v_institute_code  NUMBER;
v_Country_Code VARCHAR2(3) := 'TR';
Vcoverpackageid             NUMBER;
Vcoverpackagedate           DATE;
p_Rsl_Number             NUMBER;
p_Rsl_Date               DATE;
p_Rsl_Char               VARCHAR2(2000);
Type Refcur Is Ref Cursor;
Cur                Refcur;
begin
    v_contract_id := 414324930;--382478449;--369584856;--371177825;--369035208;
    v_partition_no := 1;--383;--1;
   -- v_partner_id := 31813488;
    v_cover_code := 'S357';
    v_is_special := 0;
    v_is_pool := 0;
    v_claim_inst_type := 'AK';
    v_claim_inst_loc  := 'YI';
    v_institute_code := 2635;--26929;
    Koc_Clm_Hlth_Utils.Getpolinfoforindemnity(v_contract_id,v_partition_no, TO_DATE(v_date,'DD/MM/YYYY'),Cur);    
    FETCH Cur INTO Policyinfo;    
    CLOSE Cur;
    DBMS_OUTPUT.PUT_LINE('Policyinfo.Contract_Id : '||Policyinfo.Contract_Id);
    
    Koc_Clm_Hlth_Utils.Getinstitutinfobycode(v_institute_code,TO_DATE(v_date,'DD/MM/YYYY'),Cur);
    FETCH Cur INTO Institutinfo;
    CLOSE Cur;
    DBMS_OUTPUT.PUT_LINE('Institutinfo.Institute_Code : '||Institutinfo.Institute_Code);
    IF Institutinfo.Institute_Code IS NULL THEN
      Koc_Clm_Hlth_Utils.Getlastinstitutinfobycode(v_institute_code,Cur);
      FETCH Cur INTO Institutinfo;
      CLOSE Cur;
    END IF;
    v_city_code :=  --'16';--
    CUSTOMER.KOC_CLM_HLTH_UTILS.Getinstcitycodebyinstcode(Institutinfo.Institute_Code, SYSDATE);
    v_networkid := Policyinfo.Network_Id;
    DBMS_OUTPUT.PUT_LINE('Institutinfo.Institute_Code : '||Institutinfo.Institute_Code);
    DBMS_OUTPUT.PUT_LINE('Institutinfo.Inst_Cov_Type : '||Institutinfo.Inst_Cov_Type);
    DBMS_OUTPUT.PUT_LINE('Institutinfo.Inst_Validity_Type : '||Institutinfo.Inst_Validity_Type);
    DBMS_OUTPUT.PUT_LINE('Institutinfo.Institute_Type : '||Institutinfo.Institute_Type);
    DBMS_OUTPUT.PUT_LINE('Institutinfo.Claim_Inst_Type : '||Institutinfo.Claim_Inst_Type);
    DBMS_OUTPUT.PUT_LINE('Institutinfo.Claim_Inst_Loc : '||Institutinfo.Claim_Inst_Loc);
    DBMS_OUTPUT.PUT_LINE('City_Code : '||v_city_code);
    DBMS_OUTPUT.PUT_LINE('Network_Id : '||v_networkid);
    
    KOC_CLM_HLTH_TRNX.Getindemtotalsmdf(Policyinfo.Contract_Id,--p_Contract_Id,
                        Policyinfo.Partition_No,--p_Partition_No,
                        v_claim_inst_type,--Institutinfo.Claim_Inst_Type,--p_Claim_Inst_Type,
                        v_claim_inst_loc,--Institutinfo.Claim_Inst_Loc,--p_Claim_Inst_Loc,
                        '0',--p_Country_Group,
                        v_cover_code,--p_Cover_Code,
                        Policyinfo.Package_Id,--p_Policyinfo.Package_Id,
                        Policyinfo.Package_Date,--p_Policyinfo.Package_Date,
                        sysdate,--TO_DATE(v_date,'DD/MM/YYYY'),--sysdate,--Trunc(p_Date),
                        'MEDISER28',--p_User_Id,
                        v_is_pool,--p_Is_Pool_Cover,
                        v_is_special,--p_Is_Special_Cover,
                        Cur);
      FETCH Cur INTO Indeminfo;
      CLOSE Cur;
      DBMS_OUTPUT.PUT_LINE('Indeminfo.Cover_Code : '||Indeminfo.Cover_Code);
      DBMS_OUTPUT.PUT_LINE('Indeminfo.Sub_Package_Id : '||Indeminfo.Sub_Package_Id);
      DBMS_OUTPUT.PUT_LINE('Indeminfo.Package_Id : '||Indeminfo.Package_Id);
      DBMS_OUTPUT.PUT_LINE('Indeminfo.Validity_Start_Date : '||Indeminfo.Validity_Start_Date);
      IF NVL(Indeminfo.Sub_Package_Id,0) != 0  THEN
      Vcoverpackageid   := Indeminfo.Sub_Package_Id;
      Vcoverpackagedate := Indeminfo.Sub_Package_Date;
    ELSE
      Vcoverpackageid   := Policyinfo.Package_Id;
      Vcoverpackagedate := Policyinfo.Package_Date;
    END IF;
     DBMS_OUTPUT.PUT_LINE('Vcoverpackageid : '||Vcoverpackageid);
      DBMS_OUTPUT.PUT_LINE('Vcoverpackagedate : '||Vcoverpackagedate);
      Expackrow.Product_Id           := Policyinfo.Product_Id;
      Expackrow.Partition_Type       := Policyinfo.Partition_Type;
      Expackrow.Contract_Id          := Policyinfo.Contract_Id;
      Expackrow.Partition_No         := Policyinfo.Partition_No;
      Expackrow.Validity_Start_Date  := Nvl(Indeminfo.Validity_Start_Date, To_Date('01/01/1000',  'DD/MM/YYYY'));
      Expackrow.Part_Id              := Policyinfo.Partner_Id;
      Expackrow.Package_Id           := Vcoverpackageid;
      Expackrow.Package_Date         := Vcoverpackagedate;
      Expackrow.Claim_Inst_Type      := Nvl(p_Claim_Inst_Type, Institutinfo.Claim_Inst_Type);
      Expackrow.Claim_Inst_Loc       := Nvl(p_Claim_Inst_Loc, Institutinfo.Claim_Inst_Loc);
      Expackrow.Institute_Code       := Institutinfo.Institute_Code;
      Expackrow.Inst_Cov_Type        := Institutinfo.Inst_Cov_Type;
      Expackrow.Inst_Validity_Type   := Institutinfo.Inst_Validity_Type;
      Expackrow.Institute_Type       := Institutinfo.Institute_Type;
      Expackrow.Country_Group        := p_Country_Group;
      Expackrow.Child_Cover_Code     := Indeminfo.Cover_Code;
      Expackrow.Is_Pool_Cover        := Indeminfo.Is_Pool_Cover;
      Expackrow.Is_Special_Cover     := Indeminfo.Is_Special_Cover;
      Expackrow.Cover_Cat_Group      := Indeminfo.Cover_Cat_Group;
      Expackrow.Institude_Group_Code := Institutinfo.Institute_Group_Code_Type_2; -- selcenk TSS 03/03/2015
      Expackrow.Spec_Group_Code      := Institutinfo.Institute_Group_Code_Type_s; -- selcenk TSS 03/03/2015
      Expackrow.City_Code            := v_City_Code; --ibrahimk karma 21/09/2016
      Expackrow.Network_Id           := v_Networkid; --ibrahimk + kenanp 25012017 karma projesi

      KOC_CLM_HLTH_TRNX.Getinstexpackresult(Expackrow,
                          'IS_COVER_VAL',
                          p_Rsl_Number,
                          p_Rsl_Date,
                          p_Rsl_Char);
                          DBMS_OUTPUT.PUT_LINE('IS_COVER_VAL');
                          DBMS_OUTPUT.PUT_LINE('p_Rsl_Number : '||p_Rsl_Number);
                          DBMS_OUTPUT.PUT_LINE('p_Rsl_Date : '||p_Rsl_Date);
                          DBMS_OUTPUT.PUT_LINE('p_Rsl_Char : '||p_Rsl_Char);
                          
      KOC_CLM_HLTH_TRNX.Getinstexpackresult(Expackrow,
                          'EXEMPTION_RATE',
                          p_Rsl_Number,
                          p_Rsl_Date,
                          p_Rsl_Char);
                          DBMS_OUTPUT.PUT_LINE('EXEMPTION_RATE');
                          DBMS_OUTPUT.PUT_LINE('p_Rsl_Number : '||p_Rsl_Number);
                          DBMS_OUTPUT.PUT_LINE('p_Rsl_Date : '||p_Rsl_Date);
                          DBMS_OUTPUT.PUT_LINE('p_Rsl_Char : '||p_Rsl_Char);    
    
    KOC_CLM_HLTH_TRNX.Getinstexpackresult(Expackrow,
                          'EXEMPTION_RATE2',
                          p_Rsl_Number,
                          p_Rsl_Date,
                          p_Rsl_Char);
                          DBMS_OUTPUT.PUT_LINE('EXEMPTION_RATE2');
                          DBMS_OUTPUT.PUT_LINE('p_Rsl_Number : '||p_Rsl_Number);
                          DBMS_OUTPUT.PUT_LINE('p_Rsl_Date : '||p_Rsl_Date);
                          DBMS_OUTPUT.PUT_LINE('p_Rsl_Char : '||p_Rsl_Char);   
                          
     KOC_CLM_HLTH_TRNX.Getinstexpackresult(Expackrow,
                          'IS_NOT_VALID_EXEMP',
                          p_Rsl_Number,
                          p_Rsl_Date,
                          p_Rsl_Char);
                          DBMS_OUTPUT.PUT_LINE('IS_NOT_VALID_EXEMP');
                          DBMS_OUTPUT.PUT_LINE('p_Rsl_Number : '||p_Rsl_Number);
                          DBMS_OUTPUT.PUT_LINE('p_Rsl_Date : '||p_Rsl_Date);
                          DBMS_OUTPUT.PUT_LINE('p_Rsl_Char : '||p_Rsl_Char);
                                                                             
end;
