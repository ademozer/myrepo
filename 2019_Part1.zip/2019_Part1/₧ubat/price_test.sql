DECLARE      
       v_hltprv_Log          Hltprv_Log_Typ := Hltprv_Log_Typ();                   
       v_request CLOB;
       v_response CLOB;
       v_url VARCHAR2(200) := --'http://10.70.47.25:19101/hclm-health-claim-service/api/v1/provision/createProvision';
                              --'http://esb.allianz.com.tr:12000/hclm-service/api/v1/provision/createProvision'; 
                              --'http://10.70.47.55:19101/hclm-health-claim-service/api/v1/provision/createProvision';
                              --'http://esb.allianz.com.tr:12000/hclm-health-claim-service/api/v1/process/price';
                              'http://10.70.47.25:19101/hclm-health-claim-service/api/v1/process/price';
       v_status NUMBER;
       v_message VARCHAR2(1000); 
       v_institute_code NUMBER := 337;
       v_ndx1 NUMBER;
       v_ndx2 NUMBER;
       
       CURSOR crs_obj(p_data IN CLOB) IS 
          SELECT trim(replace (Regexp_Substr (Xt.Element, '[^:]+', 1) , '"',''))   KEY, 
                 trim(replace (Regexp_Substr (Xt.Element, '[^:]+', 1, 2), '"','')) VALUE              
           FROM (Select Regexp_Substr (p_data, '[^,]+', 1, Level) Element
                   From Dual
                Connect By Level <= Length (Regexp_Replace (p_data, '[^,]+')) + 1) Xt; 
                
       procedure callRestService(p_Url               In          Varchar2,
                              p_Method            In          Varchar2,                                                                           
                              p_Request           In          Clob,                    
                              p_Response          Out         Clob, 
                              p_Status            Out         Number, 
                              p_Message           Out         Varchar2) IS 
                              
        v_Req               utl_http.req;
        v_Req_Length        Number;
        v_Res               utl_http.resp;
        v_Buffer            Varchar2(32767);
        v_Offset            Number := 1;
        v_Amount            Number :=32767;
        v_Utl_Err           Varchar2(1000);
        v_value             varchar2(4000);
        hata_code           varchar2(10);
        v_output            varchar2(10);
        v_Response          CLOB;
        v_Line_Number       NUMBER := 0;
        
        Begin
          
            v_Req_Length := dbms_lob.getlength(p_Request);
            --v_Req := utl_http.begin_request(get_url_link(p_Url), p_Method, 'HTTP/1.1');   
            v_Req := utl_http.begin_request(p_Url, p_Method, 'HTTP/1.1');      
            utl_http.set_header(v_Req, 'Content-Length', v_Req_Length);
            utl_http.set_header(v_Req, 'Content-Type', 'application/json;charset=UTF-8');
            utl_http.set_header (v_Req,'Transfer-Encoding', 'chunked' );
            utl_http.set_body_charset(v_Req,'UTF-8');
           -- UTL_HTTP.set_response_error_check(false); 
            
            While (v_Offset < v_Req_Length)
            Loop
               dbms_lob.read(p_Request, v_Amount, v_Offset, v_Buffer);
               utl_http.write_text(r    => v_Req, data => v_Buffer);
               v_Offset := v_Offset + v_Amount;
            End Loop;
            
            v_Res := utl_http.get_response(v_Req);
            p_status := 0;
            p_message := v_Res.status_code || ':' || v_Res.reason_phrase;
            IF v_Res.status_code != 200  THEN 
                --DBMS_OUTPUT.PUT_LINE('Hata:'|| v_Res.status_code);
                --DBMS_OUTPUT.PUT_LINE('Hata:'|| v_Res.reason_phrase);
                --p_message := v_Res.status_code || ':' || v_Res.reason_phrase;
                p_Status := 1;
               -- utl_http.read_text(v_Res, p_message);
                DBMS_OUTPUT.PUT_LINE('Hata:'|| p_message);
               -- Raise_Application_Error(-20200, v_Res.status_code || ' - Hata Olu�tu');                                     
            END IF; 
            
            Begin
              
               loop                 
                  utl_http.read_line(v_Res, v_value);
                  v_value := TRIM(regexp_replace(v_value, '([^[:graph:] | ^[:blank:]])', ''));
                  v_Response := v_Response || v_value;                                                    
               end loop;               
               utl_http.end_response(v_Res);               
            Exception              
            When utl_http.end_of_body Then
                 utl_http.end_response(v_Res);
            When utl_http.too_many_requests Then
                 utl_http.end_response(v_Res);
            When Others Then
                 utl_http.end_response(v_Res);
           End;  
           DBMS_OUTPUT.PUT_LINE('response='||v_response);    
           /*IF p_Status = 1 THEN
               p_Response := '';
               RETURN;
           END IF;*/
           
           p_Response := TRIM(v_Response);
          
          
           
        EXCEPTION 
           WHEN OTHERS THEN
              utl_http.end_response(v_Res);
              v_utl_err:= Utl_Http.Get_Detailed_Sqlerrm;
              p_Status := 1;
              p_Response := '';
              p_Message := v_utl_err||' - '||p_url;
              
    END callRestService;
    
BEGIN
              
       --v_request := '{"instituteCode" : "1289","defaultCityCode" : "34","processCodeMain" : "130","processCodeSub1" : "20","processCodeSub2" : "116","validityDate" : "2018-12-04","groupCode" : "S11183","complementaryType" : "TSS","ulakPrice" : "1","ahekProvider" : "false","contractId" : "355577538","partitionNo" : "288","isReferral" : "false","doctorCode" : "0", "academicStaff": "true", "isRoboticSurgery" : "false","isLaparoscopicSurgery" : "false"}';
       v_request := '{
             "instituteCode" : "1289",
             "defaultCityCode" : "34",
             "processCodeMain" : "130",
             "processCodeSub1" : "20",
             "processCodeSub2" : "116",
             "validityDate" : "2018-12-04T00:00:00.000Z",
             "groupCode" : "S11183",
             "complementaryType" : "TSS",
             "ulakPrice" : "1",
             "ahekProvider" : "false",
             "contractId" : "355577538",
             "partitionNo" : "288",
             "referralProvision" : "false",
             "doctorCode" : "0",
             "academicStaff" : "true",
             "roboticSurgery" : "false",
             "laparoscopicSurgery" : "false"
          }';
       /*v_hltprv_Log.Log_Id := NULL;
       v_hltprv_Log.Servicename := 'HCLM_TEST';
       v_hltprv_Log.Processinfo := v_url;
       v_hltprv_Log.Note        := 'Request';
       v_hltprv_Log.Content     := v_request;
       v_hltprv_Log.Institutecode := v_institute_code;   
       v_hltprv_Log.Savelogwithpragma;*/
       
       --CUSTOMER.ALZ_HCLM_CONVERTER_UTILS.
       callRestService(v_url, 'POST', v_request, v_response, v_status, v_message);
       
       /*v_hltprv_Log.Servicename := 'HCLM_TEST';
       v_hltprv_Log.Processinfo := v_url;
       v_hltprv_Log.Note        := 'Response';
       v_hltprv_Log.Content     := v_response||v_status||v_message;
       v_hltprv_Log.Institutecode := v_institute_code;
       v_hltprv_Log.Savelogwithpragma;
       --DBMS_OUTPUT.PUT_LINE('resp:'||v_response);
       --v_response := TRIM(regexp_replace(v_response, '([^[:graph:] | ^[:blank:]])', ''));  
       IF v_status = 0 THEN
           v_ndx1 := INSTR(v_response,'{"claimDetailDto" : {');
           v_ndx2 := INSTR(v_response,',"provisionList"') - v_ndx1;         
           v_response := SUBSTR(v_response, v_ndx1+21, v_ndx2-21);          
       ELSE 
           v_ndx1 := INSTR(v_response,'{"errors" : [');
           v_ndx2 := INSTR(v_response,'],"warnings"') - v_ndx1;           
           v_response := SUBSTR(v_response, v_ndx1+15, v_ndx2-17);           
       END IF;*/
       v_response := replace(replace(replace(replace(v_response,'[{', ''),'}',''),'}]',''),'{','');      
       FOR rec IN (SELECT TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1) , '"',''))   KEY, 
                          TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1, 2), '"','')) VALUE              
                     FROM (SELECT Regexp_Substr (v_response, '[^,]+', 1, LEVEL) ELEMENT
                             FROM Dual
                          CONNECT BY LEVEL <= LENGTH (Regexp_Replace (v_response, '[^,]+')) + 1)) LOOP 
              DBMS_OUTPUT.PUT_LINE(rec.KEY||':'||rec.VALUE);                                  
           IF rec.KEY IN('data','message') THEN
                v_message := rec.value;
           END IF;
       END LOOP;
       IF v_status = 1 THEN 
           Raise_Application_Error(-20200,  v_message);
       END IF; 
       DBMS_OUTPUT.PUT_LINE('SUCCESS:'||v_message);
EXCEPTION WHEN OTHERS THEN
   --v_message := SQLERRM;
   /*v_message := v_message || dbms_utility.format_error_stack || dbms_utility.format_error_backtrace;
        v_hltprv_Log.Servicename := 'ALZ_HCLM_CONVERTER_UTILS';
        v_hltprv_Log.Processinfo := v_url;
        v_hltprv_Log.Note        := 'PROVISION_EXCEPTION';
        v_hltprv_Log.Content     := v_message;
        v_hltprv_Log.Institutecode := v_institute_code;
        v_hltprv_Log.Savelogwithpragma;
        --Raise_Application_Error(-20200,  'Provizyon S�ras�nda Beklenmedik Bir Hata Olu�tu:'||v_hltprv_Log.Log_Id); */     
   DBMS_OUTPUT.PUT_LINE('FAIL:'||v_message);
END;
