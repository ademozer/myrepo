DECLARE
  v_contract_id number := 290946947;--382478449;
  v_partition_no number := 1;--42;
  v_claim_inst_type VARCHAR2(100) := 'AK';
  v_claim_inst_loc  VARCHAR2(100) := 'YI'; 
  v_cover_code  VARCHAR2(100) := 'S357';
  v_is_special  NUMBER := 0;--1;
  v_is_pool     NUMBER := 0;
  v_package_id  NUMBER := 114682; --114684;--256871;
  v_package_date DATE := TO_DATE('03/03/2015','DD/MM/YYYY');
  Type Refcur Is Ref Cursor;
  Cur                Refcur;
  Indeminfo                Koc_Clm_Hlth_Indem_Totals%ROWTYPE;
BEGIN
  KOC_CLM_HLTH_TRNX.Getindemtotalsmdf(v_contract_id,--p_Contract_Id,
                        v_partition_no,--p_Partition_No,
                        v_claim_inst_type,--Institutinfo.Claim_Inst_Type,--p_Claim_Inst_Type,
                        v_claim_inst_loc,--Institutinfo.Claim_Inst_Loc,--p_Claim_Inst_Loc,
                        '0',--p_Country_Group,
                        v_cover_code,--p_Cover_Code,
                        v_package_id,--p_Policyinfo.Package_Id,
                        v_package_date,--p_Policyinfo.Package_Date,
                        sysdate,--TO_DATE(v_date,'DD/MM/YYYY'),--sysdate,--Trunc(p_Date),
                        'MEDISER28',--p_User_Id,
                        v_is_pool,--p_Is_Pool_Cover,
                        v_is_special,--p_Is_Special_Cover,
                        Cur);
      FETCH Cur INTO Indeminfo;
      CLOSE Cur;
      
      DBMS_OUTPUT.PUT_LINE('Indeminfo.Cover_Code : '||Indeminfo.Cover_Code);
      DBMS_OUTPUT.PUT_LINE('Indeminfo.Sub_Package_Id : '||Indeminfo.Sub_Package_Id);
      DBMS_OUTPUT.PUT_LINE('Indeminfo.Package_Id : '||Indeminfo.Package_Id);
      DBMS_OUTPUT.PUT_LINE('Indeminfo.Validity_Start_Date : '||Indeminfo.Validity_Start_Date);
END;
