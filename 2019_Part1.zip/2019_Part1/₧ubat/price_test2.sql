DECLARE
   v_price NUMBER := 0;
   FUNCTION booleanToString(p_boolean IN NUMBER) RETURN VARCHAR2 IS
    BEGIN
        RETURN (CASE NVL(p_boolean, 0) WHEN 1 THEN 'true' ELSE 'false' END);
    END booleanToString;

    FUNCTION dateToString(p_date IN DATE) RETURN VARCHAR2 IS
          v_date  DATE;
          v_timestamp TIMESTAMP;
          v_return VARCHAR2(100);
    BEGIN
        v_return := '';
        v_date := p_date;
        IF v_date IS NOT NULL THEN
           v_timestamp := CAST (v_date AS TIMESTAMP);
           v_return := TO_CHAR(v_date,'YYYY-MM-DD')||'T'||TO_CHAR(v_timestamp,'HH24:MI:SS.FF3')||'Z';
        END IF;
        RETURN v_return;
    END dateToString;

    FUNCTION numberToString(p_number IN NUMBER) RETURN VARCHAR2 IS
    BEGIN
        RETURN REPLACE(TO_CHAR(p_number),',','.');
    END numberToString;

    procedure callRestService(p_Url               In          Varchar2,
                              p_Method            In          Varchar2,
                              p_Request           In          Clob,
                              p_Response          Out         Clob,
                              p_Status            Out         Number,
                              p_Message           Out         Varchar2) IS

        v_Req               utl_http.req;
        v_Req_Length        Number;
        v_Res               utl_http.resp;
        v_Buffer            Varchar2(32767);
        v_Offset            Number := 1;
        v_Amount            Number :=32767;
        v_Utl_Err           Varchar2(1000);
        v_value             varchar2(4000);
        hata_code           varchar2(10);
        v_output            varchar2(10);
        v_Response          CLOB;
        v_Line_Number       NUMBER := 0;

        Begin

            v_Req_Length := dbms_lob.getlength(p_Request);
            v_Req := utl_http.begin_request(get_url_link(p_Url), p_Method, 'HTTP/1.1');
            utl_http.set_header(v_Req, 'Content-Length', v_Req_Length);
            utl_http.set_header(v_Req, 'Content-Type', 'application/json;charset=UTF-8');
            utl_http.set_header (v_Req,'Transfer-Encoding', 'chunked' );
            utl_http.set_body_charset(v_Req,'UTF-8');
            --utl_http.set_response_error_check(false);

            While (v_Offset < v_Req_Length)
            Loop
               dbms_lob.read(p_Request, v_Amount, v_Offset, v_Buffer);
               utl_http.write_text(r    => v_Req, data => v_Buffer);
               v_Offset := v_Offset + v_Amount;
            End Loop;

            v_Res := utl_http.get_response(v_Req);
            p_status := 0;
            p_message := v_Res.status_code || ':' || v_Res.reason_phrase;
            IF v_Res.status_code != 200  THEN
                p_Status := 1;
            END IF;
            Begin
               loop
                  utl_http.read_line(v_Res, v_value);
                  v_value := TRIM(regexp_replace(v_value, '([^[:graph:] | ^[:blank:]])', ''));
                  v_Response := v_Response || v_value;
               end loop;
               utl_http.end_response(v_Res);
            Exception
            When utl_http.end_of_body Then
                 utl_http.end_response(v_Res);
            When utl_http.too_many_requests Then
                 utl_http.end_response(v_Res);
            When Others Then
                 utl_http.end_response(v_Res);
           End;
           p_Response := TRIM(v_Response);
        EXCEPTION
           WHEN OTHERS THEN
              utl_http.end_response(v_Res);
              v_utl_err:= Utl_Http.Get_Detailed_Sqlerrm;
              p_Status := 1;
              p_Response := '';
              p_Message := v_utl_err||' - '||p_url;
    END callRestService;

    function calculateProcessPrice(p_Institute_Code          NUMBER,
                                   p_City_Code               VARCHAR2,
                                   p_Proc_Code_Main          NUMBER,
                                   p_Proc_Code_Sub1          NUMBER,
                                   p_Proc_Code_Sub2          NUMBER,
                                   p_Date                    DATE,
                                   p_Is_Vat_Included         NUMBER DEFAULT 1,
                                   p_Group_Code              VARCHAR2,
                                   p_Is_Tss_Oss              NUMBER DEFAULT 0,
                                   p_Is_Ahek                 NUMBER DEFAULT 0,
                                   p_Contract_Id             NUMBER,
                                   p_Partition_No            NUMBER,
                                   p_Is_Refferal             NUMBER DEFAULT 0,
                                   p_Doctor_Code             NUMBER,
                                   p_Is_Academic_Staff       NUMBER DEFAULT 0,
                                   p_Is_Robotic_Surgery      NUMBER DEFAULT 0,
                                   p_Is_Laparoscopic_Surgery NUMBER DEFAULT 0) return NUMBER IS

         v_hltprv_Log          Hltprv_Log_Typ := Hltprv_Log_Typ();
         v_request CLOB;
         v_response CLOB;
         v_url VARCHAR2(200) := 'http://esb.allianz.com.tr:12000/hclm-health-claim-service/api/v1/process/price';
                                --'http://10.70.47.55:19101/hclm-health-claim-service/api/v1/process/price';
                                --'http://esb.allianz.com.tr:12000/hclm-health-claim-service/api/v1/process/price';
         v_status NUMBER;
         v_message VARCHAR2(1000);
         v_complementary_type VARCHAR2(10);
         v_ulak_price NUMBER;
         v_price NUMBER := NULL;

     BEGIN
          IF p_Is_Tss_Oss = 0 THEN
              v_complementary_type := 'OSS';
              v_ulak_price         := 1;
          ELSE
              v_complementary_type := 'TSS';
              v_ulak_price         := p_Is_Tss_Oss;
          END IF;
          v_request := '{
             "instituteCode" : "'|| TO_CHAR(p_Institute_Code)||'",
             "defaultCityCode" : "'|| p_City_Code||'",
             "processCodeMain" : "'|| TO_CHAR(p_Proc_Code_Main)||'",
             "processCodeSub1" : "'|| TO_CHAR(p_Proc_Code_Sub1)||'",
             "processCodeSub2" : "'|| TO_CHAR(p_Proc_Code_Sub2)||'",
             "validityDate" : "'|| dateToString(p_Date)||'",
             "groupCode" : "'|| p_Group_Code||'",
             "complementaryType" : "'|| v_complementary_type||'",
             "ulakPrice" : "'|| numberToString(v_ulak_price)||'",
             "ahekProvider" : "'|| booleanToString(p_Is_Ahek)||'",
             "contractId" : "'|| TO_CHAR(p_Contract_Id)||'",
             "partitionNo" : "'|| TO_CHAR(p_Partition_No)||'",
             "referralProvision" : "'|| booleanToString(p_Is_Refferal)||'",
             "doctorCode" : "'|| TO_CHAR(p_Doctor_Code)||'",
             "academicStaff" : "'|| booleanToString(p_Is_Academic_Staff)||'",
             "roboticSurgery" : "'|| booleanToString(p_Is_Robotic_Surgery)||'",
             "laparoscopicSurgery" : "'|| booleanToString(p_Is_Laparoscopic_Surgery)||'"
          }';

          /*v_hltprv_Log.Log_Id        := NULL;
          v_hltprv_Log.Servicename   := 'ALZ_HCLM_CONVERTER_UTILS';
          v_hltprv_Log.Processinfo   := v_url;
          v_hltprv_Log.Note          := 'PROCESS_PRICE_REQUEST';
          v_hltprv_Log.Content       := v_request;
          v_hltprv_Log.Institutecode := p_Institute_Code;
          v_hltprv_Log.Log_Source    := 'PLSQL';
          v_hltprv_Log.Savelogwithpragma;*/

          callRestService(v_url, 'POST', v_request, v_response, v_status, v_message);

          /*v_hltprv_Log.Servicename   := 'ALZ_HCLM_CONVERTER_UTILS';
          v_hltprv_Log.Processinfo   := v_url;
          v_hltprv_Log.Note          := 'PROCESS_PRICE_RESPONSE';
          v_hltprv_Log.Content       := v_response;
          v_hltprv_Log.Institutecode := p_Institute_Code;
          v_hltprv_Log.Log_Source    := 'PLSQL';
          v_hltprv_Log.Savelogwithpragma;*/
           
          v_response := replace(replace(replace(replace(v_response,'[{', ''),'}',''),'}]',''),'{','');
          FOR rec IN (SELECT TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1) , '"',''))   KEY,
                             TRIM (REPLACE (Regexp_Substr (ELEMENT, '[^:]+', 1, 2), '"','')) VALUE
                       FROM (SELECT Regexp_Substr (v_response, '[^,]+', 1, LEVEL) ELEMENT
                               FROM Dual
                            CONNECT BY LEVEL <= LENGTH (Regexp_Replace (v_response, '[^,]+')) + 1)) LOOP
             IF rec.KEY IN('data', 'message') THEN
                  v_message := rec.value;
             END IF;
          END LOOP;
          IF v_status = 1 THEN
              Raise_Application_Error(-20200,  v_message);
          ELSE
              v_price := TO_NUMBER(TRIM(v_response),'999999.9999');
          END IF;
          RETURN v_price;
     EXCEPTION
     WHEN OTHERS THEN
         /* v_hltprv_Log.Servicename   := 'ALZ_HCLM_CONVERTER_UTILS';
          v_hltprv_Log.Processinfo   := v_url;
          v_hltprv_Log.Note          := 'PROCESS_PRICE_EXCEPTION';
          v_hltprv_Log.Content       := v_message || dbms_utility.format_error_stack || dbms_utility.format_error_backtrace;
          v_hltprv_Log.Institutecode := p_Institute_Code;
          v_hltprv_Log.Log_Source    := 'PLSQL';
          v_hltprv_Log.Savelogwithpragma;*/          
          dbms_output.put_line(v_message || dbms_utility.format_error_stack || dbms_utility.format_error_backtrace);
          RETURN -1;
          --Raise_Application_Error(-20200,  '��lem Fiyat� Hesaplama S�ras�nda Bir Hata Olu�tu:'||v_message);
     END calculateProcessPrice;
     
 BEGIN
      v_price := calculateProcessPrice(1289,  -- institute_code
                            '34',  -- city_code
                            130,
                            20,
                            116,
                            TO_DATE('04/12/2018','DD/MM/YYYY'),
                            1, -- is_vat_included
                            'S11183', -- group_code
                            0,
                            0,
                            355577538,
                            288,
                            0,
                            0,
                            0,
                            0,
                            0);
      DBMS_OUTPUT.PUT_LINE('fiyat='||v_price);
 END;
