select utl_http.request(get_url_link('http://esb.allianz.com.tr:12000/hclm-service/api/institute/13?channel=ws')) from dual

select * from Koc_Cc_Hlth_Tda_Proc_List where discount_group_code='EVG�V'--process_code_main = 75 and process_code_sub1 = 50 and process_code_sub2 IN(101,102,103)


select * from Koc_Cc_Hlth_Tda_Inst_Val where institute_code=337 and validity_end_date is null --discount_group_code='AMB/IST' and validity_end_date is null

select * from Koc_Mv_Skrm_Suppliers where institute_code=337
