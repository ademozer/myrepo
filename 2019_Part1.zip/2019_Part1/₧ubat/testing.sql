select * from alz_hltprv_log where log_id=105489900 and SERVICENAME='ALZ_HCLM_CONVERTER_UTILS'--LOG_SOURCE='PLSQL';--log_date>TO_DATE('19/02/2019','DD/MM/YYYY') and servicename='HCLM_TEST'

hclm-health-claim-service/api/v1/provision/updateProvision
hclm-health-claim-service/api/v1/provision/updateProvision
select * from koc_cp_health_look_up  WHERE Look_Up_Code = 'HCLM_USAGE' for update;

select customer.Alz_Hclm_Converter_Utils.getHclmUsageForOpus from dual;

  SELECT * --Partner_Id, Policy_Start_Date, Group_Code
    FROM CUSTOMER.Koc_v_Hlth_Insured_Info_Indem 
            where contract_id = 410654615  
              and partition_no = 333 
              and action_code != 'D'

	Koc_Pk_Hlth_Provision.Getprovisiondata;
select * from all_source where upper(text) like '%GETNETWORKCLAIMINSTTYPE%' and owner='CUSTOMER'

select count(*) from koc_clm_hlth_event_exempt where event_r_exemption != 5000--event_explanation is not null

select * from hsevim.dm_table where lower(table_name) = 'koc_clm_hlth_event_exempt'


select * from ocp_policy_bases where contract_id = 431959969

select * from alz_hltprv_log where log_id=105487128

KOC_CLM_HLTH_TRNX;

select * from koc_clm_hlth_indem_totals where contract_id = 410654615 and partition_no=2 and cover_code='S741'

select * from koc_ocp_risk_packages where contract_id = 410654615 and partition_no=2

KOC_CLM_HLTH_UTILS2.save_event

 WITH field_list AS (
        SELECT trim(replace (Regexp_Substr (Xt.Element, '[^:]+', 1) , '"','')) KEY, 
               trim(replace (Regexp_Substr (Xt.Element, '[^:]+', 1, 2), '"','')) VALUE              
          FROM (Select Regexp_Substr ('"extReference" : "55712562"',
                                      '[^,]+',
                                      1,
                                      Level)
                              Element
                      From Dual
                Connect By Level <= Length (Regexp_Replace ('"extReference" : "55712562"', '[^,]+')) + 1) Xt )
       SELECT * FROM field_list;


KOC_CLM_HLTH_TRNX

SELECT TO_NUMBER('971.31','9999.9999') FROM DUAL

select * from koc_clm_hlth_detail where ext_reference IN ('55709776','55709777','55709782','55709862','55709863','55710160') for update
select * from clm_pol_oar where claim_id=38749097;

  SELECT * --Partner_Id, Policy_Start_Date, Group_Code
    FROM CUSTOMER.Koc_v_Hlth_Insured_Info_Indem 
            where contract_id = 388913504--410654615  
              and partition_no = 2
              and action_code != 'D'
              
            SELECT * --Partner_Id, Policy_Start_Date, Group_Code
    FROM CUSTOMER.Koc_v_Hlth_Insured_Info_Indem   
              where policy_ref='0001171006127544'
              and partition_no=2
              
WEB_CLM_HLTH_HOSPT_UTILS

8054185  -- kart _no

Koc_Clm_Hlth_Utils2.Countvalidpolicy

30049860,
37210705
select * from cp_partners where part_id=37210705

select * from Koc_Cp_Comm_Dev_Type_Ref 
select * from cur_translations where desc_int_id='3693';

koc_clm_hlth_utils.getdiesaesnotesforprov;

koc_clm_hlth_utils.getnotestext ;

alz_hclm_converter_utils;

ALZ_HLTPRV_FORM_UTILS;

KOC_CLM_BORDRO;

ALZ_HLTH_CPA_COMM_UTILS;

ALZ_CLM_HLTH_CRON;

KOC_CLM_HLTH_HOSPT_UTILS;

KOC_CLM_HLTH_PHARMACY_UTILS;

KOC_CLM_HLTH_PHARMACY_ITS;

KOC_PK_HLTH_PROVISION;

select * from Koc_Cron_Script_Def where lower(explanation) like '%bordro%'

select * from koc_clm_hlth_detail where ext_reference = '55710208' for update;--claim_id = 38749635--38749209
select * from koc_clm_hlth_provisions where claim_id = 38749769
;
Koc_Pk_Hlth_Provision.Deleteprovisiondata

;

 koc_clm_hlth_bpm_utils.getAuthInf(:KOC_CLM_WEB_AUTH_POOL.claim_id,
                                          v_instance_id,
                                          v_is_authorized,
                                          v_user_name,
                                          v_state_date,
                                          v_is_emergency,
                                          v_status_code);
                                          
                                          ALZ_HCLM_CONVERTER_UTILS
select * from koc_oc_endorsements


select * from koc_cp_health_look_up  WHERE Look_Up_Code = 'DOCTORTYPE'
select * from alz_fn_mig_contracts where SRC_TYPE='OCQ' AND mig_status ='TODO' --NOT IN('TODO','DONE')


  SELECT  *
              FROM Koc_Clm_Web_Auth_Pool r
             WHERE r.Claim_Id = 40177456
             
             select * from koc_clm_hlth_detail where ext_reference='56788310';
             koc_clm_hlth_bpm_utils;
             web_provision
             
            
