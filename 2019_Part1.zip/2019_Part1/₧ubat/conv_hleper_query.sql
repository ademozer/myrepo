SELECT CASE  
          WHEN DATA_TYPE = 'DATE' THEN 'addDateParamToTable('''||TAG_NAME||''', rec.'||COLUMN_NAME||', v_converter_row_patient);'
          WHEN (DATA_TYPE = 'NUMBER' AND SUBSTR(COLUMN_NAME,1,2) = 'IS') THEN 'addParameterToTable('''||TAG_NAME||''', CASE rec.'||COLUMN_NAME||' WHEN 1 THEN ''true'' ELSE ''false'' END, v_converter_row_patient);'   
          WHEN (DATA_TYPE = 'NUMBER' AND SUBSTR(COLUMN_NAME,1,2) != 'IS') THEN 'addParameterToTable('''||TAG_NAME||''', TO_CHAR(rec.'||COLUMN_NAME||'), v_converter_row_patient);'
          WHEN DATA_TYPE = 'VARCHAR2' THEN 'addParameterToTable('''||TAG_NAME||''',rec.'||COLUMN_NAME||', v_converter_row_patient);'
       END TEXT    
  FROM (SELECT LOWER(SUBSTR(TAG_NAME, 1, 1)) || SUBSTR(TAG_NAME, 2) TAG_NAME,
               COLUMN_NAME,
               DATA_TYPE
          FROM (select REPLACE(INITCAP(CASE WHEN DATA_TYPE = 'NUMBER' AND SUBSTR(COLUMN_NAME,1,2) = 'IS' THEN SUBSTR(COLUMN_NAME,3) ELSE COLUMN_NAME END), '_', '') TAG_NAME,
                       COLUMN_NAME,
                       DATA_TYPE
                  FROM all_tab_columns
                 where table_name = UPPER('Koc_Clm_Vacc_Indem_Totals')))
 WHERE 1=1 --COLUMN_NAME = 'IS_EX_GRATIA' 
 AND TAG_NAME IN (
 'provDemandDate',
 'provisionDate',
 'provisionFeeChargeDate'
)

select * from KOC_CLM_HLTH_SURGERY_DETAIL where claim_id = 
